/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.daf.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

/** 
 * Description: PurgeDafRecordResponse Business object
 * File: PurgeDafRecordResponseBus.java
 * Module:  gov.ca.dmv.ease.bus.dl.response.impl
 * Created: Mar 4, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/02/18 01:01:08 $
 * Last Changed By: $Author: mwkfh $
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class PurgeDafRecordResponseBus extends AbstractResponse {
	private static final long serialVersionUID = 9009905233146769719L;

	/**
	 * Instantiates new PurgeDafRecordResponseBus.
	 */
	public PurgeDafRecordResponseBus() {
		super();
	}

	/**
	 * Instantiates new PurgeDafRecordResponseBus.
	 * 
	 * @param errorCollector Error Messages.
	 */
	public PurgeDafRecordResponseBus(IErrorCollector errorCollector) {
		super(errorCollector);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PurgeDafRecordResponseBus.java,v $
 *  Revision 1.1  2011/02/18 01:01:08  mwkfh
 *  moved purgeDafService to common
 *
 *  Revision 1.4  2010/03/26 23:05:39  mwyxg1
 *  add constructor
 *
 *  Revision 1.3  2010/03/25 21:39:32  mwyxg1
 *  add new
 *
 */
