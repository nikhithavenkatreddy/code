/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;

import java.math.BigDecimal;

/**
 * Description: This class represents the details of the Headquarter Refund if there is an over payment of the invoice 
 * File: HeadquarterRefundDetail.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Mar 4, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2010/12/07 22:08:33 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HeadquarterRefundDetail extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7651628249997930952L;
	/** Holds the name Or Address Line 1. This attribute is used for printing the refund check details from the Headquarter Refund Screen which dumps screen values
		in 2 lines on the printout without distinguishing if name OR address */
	private String nameOrAddressLine1;
	/** Holds the name Or Address Line 1. */
	private String nameOrAddressLine2;
	/** The Mailing Address to which the refund will be mailed .*/
	private Address refundAddress;
	/** Holds the refund amount. */
	private BigDecimal refundAmount;
	/** The name to which the refund will be made. */
	private PersonName refundToName;

	/**
	 * Default Constructor
	 */
	public HeadquarterRefundDetail() {
		super();
		//Empty Constructor
	}

	/**
	 * @return the nameOrAddressLine1
	 */
	public String getNameOrAddressLine1() {
		return nameOrAddressLine1;
	}

	/**
	 * @return the nameOrAddressLine2
	 */
	public String getNameOrAddressLine2() {
		return nameOrAddressLine2;
	}

	/**
	 * @return the refundAddress
	 */
	public Address getRefundAddress() {
		return refundAddress;
	}

	/**
	 * @return the refundAmount
	 */
	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	/**
	 * @return the refundToName
	 */
	public PersonName getRefundToName() {
		return refundToName;
	}

	/**
	 * @param nameOrAddressLine1 the nameOrAddressLine1 to set
	 */
	public void setNameOrAddressLine1(String nameOrAddressLine1) {
		this.nameOrAddressLine1 = nameOrAddressLine1;
	}

	/**
	 * @param nameOrAddressLine2 the nameOrAddressLine2 to set
	 */
	public void setNameOrAddressLine2(String nameOrAddressLine2) {
		this.nameOrAddressLine2 = nameOrAddressLine2;
	}

	/**
	 * @param refundAddress the refundAddress to set
	 */
	public void setRefundAddress(Address refundAddress) {
		this.refundAddress = refundAddress;
	}

	/**
	 * @param refundAmount the refundAmount to set
	 */
	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	/**
	 * @param refundToName the refundToName to set
	 */
	public void setRefundToName(PersonName refundToName) {
		this.refundToName = refundToName;
	}

	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("nameOrAddressLine1", nameOrAddressLine1, anIndent,
				aBuilder);
		outputKeyValue("nameOrAddressLine2", nameOrAddressLine2, anIndent,
				aBuilder);
		outputKeyValue("refundAddress", refundAddress, anIndent, aBuilder);
		outputKeyValue("refundAmount", refundAmount, anIndent, aBuilder);
		outputKeyValue("refundToName", refundToName, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
