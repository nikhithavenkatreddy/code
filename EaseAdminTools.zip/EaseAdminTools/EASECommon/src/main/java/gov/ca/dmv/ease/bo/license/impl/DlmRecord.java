/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.YEAR;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Description: I am Dlm Record.
 * File: DlmRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Aug 11, 2009
 * 
 * @author MWTJC1
 * @version $Revision: 1.47 $
 * Last Changed: $Date: 2012/08/15 16:22:57 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DlmRecord extends DlRecord {
	/** Constant to type of update value B. */
	public static final String TYPE_OF_UPDATE_B = "B";
	/** Constant to type of update value P. */
	public static final String TYPE_OF_UPDATE_P = "P";
	/** Constant to DUI completion code 2. */
	public static final String DUI_COMPLETION_CODE_2 = "2";
	/** Constant to DUI completion code 4. */
	public static final String DUI_COMPLETION_CODE_4 = "4";
	/** Constant to removal restriction code 1. */
	public static final String REMOVAL_OF_RESTRICTION_CODE_1 = "1";
	/** The Constant SR22_REQUIRED_CODE_1. */
	public static final String SR22_REQUIRED_CODE_1 = "1";
	/** The Constant SR22_REQUIRED_CODE_2. */
	public static final String SR22_REQUIRED_CODE_2 = "2";
	/** Constant to removal restriction code 1. */
	public static final String INELIGIBLE_RX_PROOF_ACCEPTABLE_IND_1 = "1";
	/** Constant to UNABLE TO CALCULATE ELIGIBILITY CODE 7. */
	public static final String UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_7 = "7";
	/** Constant to UNABLE TO CALCULATE ELIGIBILITY CODE 8. */
	public static final String UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_8 = "8";
	/** Constant to UNABLE TO CALCULATE ELIGIBILITY CODE 9. */
	public static final String UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_9 = "9";
	/**
	 * Constant to update HQ for new transactions.
	 */
	public static final String ORIGINAL_HEADQUARTERS_UPDATE = "ELB";
	/**
	 * Constant to update HQ for renewal transactions.
	 */
	public static final String RENEWAL_HEADQUARTERS_UPDATE = "EL1";
	/**
	 * Constant to update HQ for DL process transactions.
	 */
	public static final String DL_PROCESS_HEADQUARTERS_UPDATE = "EL2";
	/**
	 * Constant to update HQ for DL renewal by mail transactions.
	 */
	public static final String RENEWAL_BY_MAIL_HEADQUARTERS_UPDATE = "EL3";
	/**
	 * Constant to update HQ for ID process transactions.
	 */
	public static final String ID_PROCESS_HEADQUARTERS_UPDATE = "EL4";
	/** Constant to DLM response segment G. */
	public static final String DLM_RESPONSE_SEGMENT_G = "G";
	/** Constant to DLM response segment C. */
	public static final String DLM_RESPONSE_SEGMENT_C = "C";
	/** Constant to DLM return code for record not found. */
	public static final String DLM_RETURN_CODE_RECORD_NOT_FOUND = "RS";
	/** Constant to DLM Invalid Class Change. */
	public static final String DLM_INVLAID_CLASS_CHANGE = "1";
	
	/**
	 * The Class LicenseHistoryActionCode.
	 */
	public class LicenseHistoryActionCode implements Serializable {
		/** The DlmRecord.java */
		private static final long serialVersionUID = -2011773657967234743L;
		/** The authority section1. */
		private String authoritySection1;
		/** The authority section2. */
		private String authoritySection2;
		/** The authority section3. */
		private String authoritySection3;
		/** The effective date of order. */
		private Date effectiveDateOfOrder;
		/** The type of action. */
		private CodeSetElement typeOfAction;
		/** The action reason code. */
		private CodeSetElement actionReasonCode;
		
		/**
		 * Gets the action reason code.
		 * 
		 * @return the action reason code
		 */
		public CodeSetElement getActionReasonCode() {
			return actionReasonCode;
		}
		
		/**
		 * Sets the action reason code.
		 * 
		 * @param actionReasonCode the new action reason code
		 */
		public void setActionReasonCode(CodeSetElement actionReasonCode) {
			this.actionReasonCode = actionReasonCode;
		}
		
		/**
		 * Gets the authority section1.
		 * 
		 * @return the authoritySection1
		 */
		public String getAuthoritySection1() {
			return authoritySection1;
		}
		
		/**
		 * Gets the authority section2.
		 * 
		 * @return the authoritySection2
		 */
		public String getAuthoritySection2() {
			return authoritySection2;
		}
		
		/**
		 * Gets the authority section3.
		 * 
		 * @return the authoritySection3
		 */
		public String getAuthoritySection3() {
			return authoritySection3;
		}
		
		/**
		 * Gets the effective date of order.
		 * 
		 * @return the effectiveDateOfOrder
		 */
		public Date getEffectiveDateOfOrder() {
			return effectiveDateOfOrder;
		}
		
		/**
		 * Gets the type of action.
		 * 
		 * @return the type of action
		 */
		public CodeSetElement getTypeOfAction() {
			return typeOfAction;
		}
		
		/**
		 * Sets the authority section1.
		 * 
		 * @param authoritySection1 the authoritySection1 to set
		 */
		public void setAuthoritySection1(String authoritySection1) {
			this.authoritySection1 = authoritySection1;
		}
		
		/**
		 * Sets the authority section2.
		 * 
		 * @param authoritySection2 the authoritySection2 to set
		 */
		public void setAuthoritySection2(String authoritySection2) {
			this.authoritySection2 = authoritySection2;
		}
		
		/**
		 * Sets the authority section3.
		 * 
		 * @param authoritySection3 the authoritySection3 to set
		 */
		public void setAuthoritySection3(String authoritySection3) {
			this.authoritySection3 = authoritySection3;
		}
		
		/**
		 * Sets the effective date of order.
		 * 
		 * @param effectiveDateOfOrder the effectiveDateOfOrder to set
		 */
		public void setEffectiveDateOfOrder(Date effectiveDateOfOrder) {
			this.effectiveDateOfOrder = effectiveDateOfOrder;
		}
		
		/**
		 * Sets the type of action.
		 * 
		 * @param typeOfAction the new type of action
		 */
		public void setTypeOfAction(CodeSetElement typeOfAction) {
			this.typeOfAction = typeOfAction;
		}
	}
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2898057200122149567L;
	/** The Cert1 accident code. */
	private CodeSetElement cert1AccidentCode;
	/** The Cert1 conviction code. */
	private CodeSetElement cert1ConvictionCode;
	/** The Cert1 negligent operator code. */
	private CodeSetElement cert1NegligentOperatorCode;
	/** Segment C. */
	/** The Cert1 Outstanding Hearing code. */
	private CodeSetElement cert1OutstandingHearingCode;
	/** The Cert1 prior action code. */
	private CodeSetElement cert1PriorActionCode;
	/** The Cert2 accident code. */
	private CodeSetElement cert2AccidentCode;
	/** The Cert2 conviction code. */
	private CodeSetElement cert2ConvictionCode;
	/** The Cert2 prior action code. */
	private CodeSetElement cert2PriorActionCode;
	/** The Cert3 conviction code. */
	private CodeSetElement cert3ConvictionCode;
	/** The Cert3 prior action code. */
	private CodeSetElement cert3PriorActionCode;
	/** The Cert4 prior action code. */
	private CodeSetElement cert4PriorActionCode;
	/** The civil judgement code. */
	private CodeSetElement civilJudgementCode;
	/** The dl103 plus15 dui fee required code. */
	private CodeSetElement dl103Plus15DuiFeeRequiredCode;
	/** Segment G. */
	private CodeSetElement dsrReinstatementApprovalNeededCode;
	/** The dui completion required code. */
	private CodeSetElement duiCompletionRequiredCode;
	/** The echoed person. */
	private Person echoedPerson;
	/** The fr penalty fee due until date. */
	private Date frPenaltyFeeDueUntilDate;
	/** The fr proof on file code. */
	private CodeSetElement frProofOnFileCode;
	/** The fr suspense effective date. */
	private Date frSuspenseEffectiveDate;
	/** The ineligibility rx proof acceptable indicator code. */
	private CodeSetElement ineligibilityRxProofAcceptableIndicatorCode;
	/** The ineligible for tow truck cert code. */
	private CodeSetElement ineligibleForTowTruckCertCode;
	/** The license history action codes. */
	private List <LicenseHistoryActionCode> licenseHistoryActionCodes = new ArrayList <LicenseHistoryActionCode>();
	/** The license location and reason code. */
	private CodeSetElement licenseLocationAndReasonCode;
	/** The mandatory non proof action code. */
	private CodeSetElement mandatoryNonProofActionCode;
	/** The number of open unserved actions included. */
	private Integer numberOfOpenUnservedActionsIncluded;
	/** Segment F. */
	/** The number of open unserved actions remaining. */
	private Integer numberOfOpenUnservedActionsRemaining;
	/** The process dl action termination code. */
	private CodeSetElement processDlActionTerminationCode;
	/** The proof eligibility date. */
	private Date proofEligibilityDate;
	/** The proof on file code. */
	private CodeSetElement proofOnFileCode;
	/** The proof termination date. */
	private Date proofTerminationDate;
	/** The reinstated on proof code. */
	private CodeSetElement reinstatedOnProofCode;
	/** The sr1p or sr22 required code. */
	private CodeSetElement sr1pOrSr22RequiredCode;
	/** The sr22 req qualify for dui restriction. */
	private CodeSetElement sr22ReqQualifyForDuiRestriction;
	/** The sr22 required code. */
	private CodeSetElement sr22RequiredCode;
	/** The terminate fr suspension code. */
	private CodeSetElement terminateFrSuspensionCode;
	/** The unable to calculate eligibility code. */
	private CodeSetElement unableToCalculateEligibilityCode;
	/** The type of update. */
	private String typeOfUpdate;
	/** The pending applicationclass. */
	private String pendingApplicationclass;
	/** The pending motorcycle class. */
	private String pendingMotorcycleClass;
	/** The pending restriction codes. */
	private String pendingRestrictionCodes;
	
	/**
	 * Gets the cert1 accident code.
	 * 
	 * @return the cert1AccidentCode
	 */
	public CodeSetElement getCert1AccidentCode() {
		return cert1AccidentCode;
	}
	
	/**
	 * Gets the cert1 conviction code.
	 * 
	 * @return the cert1ConvictionCode
	 */
	public CodeSetElement getCert1ConvictionCode() {
		return cert1ConvictionCode;
	}
	
	/**
	 * Gets the cert1 negligent operator code.
	 * 
	 * @return the cert1NegligentOperatorCode
	 */
	public CodeSetElement getCert1NegligentOperatorCode() {
		return cert1NegligentOperatorCode;
	}
	
	/**
	 * Gets the cert1 outstanding hearing code.
	 * 
	 * @return the cert1OutstandingHearingCode
	 */
	public CodeSetElement getCert1OutstandingHearingCode() {
		return cert1OutstandingHearingCode;
	}
	
	/**
	 * Gets the cert1 prior action code.
	 * 
	 * @return the cert1PriorActionCode
	 */
	public CodeSetElement getCert1PriorActionCode() {
		return cert1PriorActionCode;
	}
	
	/**
	 * Gets the cert2 accident code.
	 * 
	 * @return the cert2AccidentCode
	 */
	public CodeSetElement getCert2AccidentCode() {
		return cert2AccidentCode;
	}
	
	/**
	 * Gets the cert2 conviction code.
	 * 
	 * @return the cert2ConvictionCode
	 */
	public CodeSetElement getCert2ConvictionCode() {
		return cert2ConvictionCode;
	}
	
	/**
	 * Gets the cert2 prior action code.
	 * 
	 * @return the cert2PriorActionCode
	 */
	public CodeSetElement getCert2PriorActionCode() {
		return cert2PriorActionCode;
	}
	
	/**
	 * Gets the cert3 conviction code.
	 * 
	 * @return the cert3ConvictionCode
	 */
	public CodeSetElement getCert3ConvictionCode() {
		return cert3ConvictionCode;
	}
	
	/**
	 * Gets the cert3 prior action code.
	 * 
	 * @return the cert3PriorActionCode
	 */
	public CodeSetElement getCert3PriorActionCode() {
		return cert3PriorActionCode;
	}
	
	/**
	 * Gets the cert4 prior action code.
	 * 
	 * @return the cert4PriorActionCode
	 */
	public CodeSetElement getCert4PriorActionCode() {
		return cert4PriorActionCode;
	}
	
	/**
	 * Gets the civil judgement code.
	 * 
	 * @return the civilJudgementCode
	 */
	public CodeSetElement getCivilJudgementCode() {
		return civilJudgementCode;
	}
	
	/**
	 * Gets the dl103 plus15 dui fee required code.
	 * 
	 * @return the dl103 plus15 dui fee required code
	 */
	public CodeSetElement getDl103Plus15DuiFeeRequiredCode() {
		return dl103Plus15DuiFeeRequiredCode;
	}
	
	/**
	 * Gets the dsr reinstatement approval needed code.
	 * 
	 * @return the dsrReinstatementApprovalNeededCode
	 */
	public CodeSetElement getDsrReinstatementApprovalNeededCode() {
		return dsrReinstatementApprovalNeededCode;
	}
	
	/**
	 * Gets the dui completion required code.
	 * 
	 * @return the duiCompletionRequiredCode
	 */
	public CodeSetElement getDuiCompletionRequiredCode() {
		return duiCompletionRequiredCode;
	}
	
	/**
	 * Gets the echoed person.
	 * 
	 * @return the echoedPerson
	 */
	public Person getEchoedPerson() {
		return echoedPerson;
	}
	
	/**
	 * Gets the fr penalty fee due until date.
	 * 
	 * @return the frPenaltyFeeDueUntilDate
	 */
	public Date getFrPenaltyFeeDueUntilDate() {
		return frPenaltyFeeDueUntilDate;
	}
	
	/**
	 * Gets the fr proof on file code.
	 * 
	 * @return the frProofOnFileCode
	 */
	public CodeSetElement getFrProofOnFileCode() {
		return frProofOnFileCode;
	}
	
	/**
	 * Gets the fr suspense effective date.
	 * 
	 * @return the frSuspenseEffectiveDate
	 */
	public Date getFrSuspenseEffectiveDate() {
		return frSuspenseEffectiveDate;
	}
	
	/**
	 * Gets the ineligibility rx proof acceptable indicator code.
	 * 
	 * @return the ineligibilityRxProofAcceptableIndicatorCode
	 */
	public CodeSetElement getIneligibilityRxProofAcceptableIndicatorCode() {
		return ineligibilityRxProofAcceptableIndicatorCode;
	}
	
	/**
	 * Gets the ineligible for tow truck cert code.
	 * 
	 * @return the ineligibleForTowTruckCertCode
	 */
	public CodeSetElement getIneligibleForTowTruckCertCode() {
		return ineligibleForTowTruckCertCode;
	}
	
	/**
	 * Gets the license history action codes.
	 * 
	 * @return the license history action codes
	 */
	public List <LicenseHistoryActionCode> getLicenseHistoryActionCodes() {
		return licenseHistoryActionCodes;
	}
	
	/**
	 * Gets the license location and reason code.
	 * 
	 * @return the license location and reason code
	 */
	public CodeSetElement getLicenseLocationAndReasonCode() {
		return licenseLocationAndReasonCode;
	}
	
	/**
	 * Gets the mandatory non proof action code.
	 * 
	 * @return the mandatoryNonProofActionCode
	 */
	public CodeSetElement getMandatoryNonProofActionCode() {
		return mandatoryNonProofActionCode;
	}
	
	/**
	 * Gets the number of open unserved actions included.
	 * 
	 * @return the number of open unserved actions included
	 */
	public Integer getNumberOfOpenUnservedActionsIncluded() {
		return numberOfOpenUnservedActionsIncluded;
	}
	
	/**
	 * Gets the number of open unserved actions remaining.
	 * 
	 * @return the number of open unserved actions remaining
	 */
	public Integer getNumberOfOpenUnservedActionsRemaining() {
		return numberOfOpenUnservedActionsRemaining;
	}
	
	/**
	 * Gets the process dl action termination code.
	 * 
	 * @return the processDlActionTerminationCode
	 */
	public CodeSetElement getProcessDlActionTerminationCode() {
		return processDlActionTerminationCode;
	}
	
	/**
	 * Gets the proof eligibility date.
	 * 
	 * @return the proofEligibilityDate
	 */
	public Date getProofEligibilityDate() {
		return proofEligibilityDate;
	}
	
	/**
	 * Gets the proof on file code.
	 * 
	 * @return the proofOnFileCode
	 */
	public CodeSetElement getProofOnFileCode() {
		return proofOnFileCode;
	}
	
	/**
	 * Gets the proof termination date.
	 * 
	 * @return the proofTerminationDate
	 */
	public Date getProofTerminationDate() {
		return proofTerminationDate;
	}
	
	/**
	 * Gets the reinstated on proof code.
	 * 
	 * @return the reinstatedOnProofCode
	 */
	public CodeSetElement getReinstatedOnProofCode() {
		return reinstatedOnProofCode;
	}
	
	/**
	 * Gets the sr1p or sr22 required code.
	 * 
	 * @return the sr1pOrSr22RequiredCode
	 */
	public CodeSetElement getSr1pOrSr22RequiredCode() {
		return sr1pOrSr22RequiredCode;
	}
	
	/**
	 * Gets the sr22 req qualify for dui restriction.
	 * 
	 * @return the sr22ReqQualifyForDuiRestriction
	 */
	public CodeSetElement getSr22ReqQualifyForDuiRestriction() {
		return sr22ReqQualifyForDuiRestriction;
	}
	
	/**
	 * Gets the sr22 required code.
	 * 
	 * @return the sr22RequiredCode
	 */
	public CodeSetElement getSr22RequiredCode() {
		return sr22RequiredCode;
	}
	
	/**
	 * Gets the terminate fr suspension code.
	 * 
	 * @return the terminateFrSuspensionCode
	 */
	public CodeSetElement getTerminateFrSuspensionCode() {
		return terminateFrSuspensionCode;
	}
	
	/**
	 * Gets the unable to calculate eligibility code.
	 * 
	 * @return the unableToCalculateEligibilityCode
	 */
	public CodeSetElement getUnableToCalculateEligibilityCode() {
		return unableToCalculateEligibilityCode;
	}
	
	/**
	 * Sets the cert1 accident code.
	 * 
	 * @param cert1AccidentCode the cert1AccidentCode to set
	 */
	public void setCert1AccidentCode(CodeSetElement cert1AccidentCode) {
		this.cert1AccidentCode = cert1AccidentCode;
	}
	
	/**
	 * Sets the cert1 conviction code.
	 * 
	 * @param cert1ConvictionCode the cert1ConvictionCode to set
	 */
	public void setCert1ConvictionCode(CodeSetElement cert1ConvictionCode) {
		this.cert1ConvictionCode = cert1ConvictionCode;
	}
	
	/**
	 * Sets the cert1 negligent operator code.
	 * 
	 * @param cert1NegligentOperatorCode the cert1NegligentOperatorCode to set
	 */
	public void setCert1NegligentOperatorCode(
			CodeSetElement cert1NegligentOperatorCode) {
		this.cert1NegligentOperatorCode = cert1NegligentOperatorCode;
	}
	
	/**
	 * Sets the cert1 outstanding hearing code.
	 * 
	 * @param cert1OutstandingHearingCode the cert1OutstandingHearingCode to set
	 */
	public void setCert1OutstandingHearingCode(
			CodeSetElement cert1OutstandingHearingCode) {
		this.cert1OutstandingHearingCode = cert1OutstandingHearingCode;
	}
	
	/**
	 * Sets the cert1 prior action code.
	 * 
	 * @param cert1PriorActionCode the cert1PriorActionCode to set
	 */
	public void setCert1PriorActionCode(CodeSetElement cert1PriorActionCode) {
		this.cert1PriorActionCode = cert1PriorActionCode;
	}
	
	/**
	 * Sets the cert2 accident code.
	 * 
	 * @param cert2AccidentCode the cert2AccidentCode to set
	 */
	public void setCert2AccidentCode(CodeSetElement cert2AccidentCode) {
		this.cert2AccidentCode = cert2AccidentCode;
	}
	
	/**
	 * Sets the cert2 conviction code.
	 * 
	 * @param cert2ConvictionCode the cert2ConvictionCode to set
	 */
	public void setCert2ConvictionCode(CodeSetElement cert2ConvictionCode) {
		this.cert2ConvictionCode = cert2ConvictionCode;
	}
	
	/**
	 * Sets the cert2 prior action code.
	 * 
	 * @param cert2PriorActionCode the cert2PriorActionCode to set
	 */
	public void setCert2PriorActionCode(CodeSetElement cert2PriorActionCode) {
		this.cert2PriorActionCode = cert2PriorActionCode;
	}
	
	/**
	 * Sets the cert3 conviction code.
	 * 
	 * @param cert3ConvictionCode the cert3ConvictionCode to set
	 */
	public void setCert3ConvictionCode(CodeSetElement cert3ConvictionCode) {
		this.cert3ConvictionCode = cert3ConvictionCode;
	}
	
	/**
	 * Sets the cert3 prior action code.
	 * 
	 * @param cert3PriorActionCode the cert3PriorActionCode to set
	 */
	public void setCert3PriorActionCode(CodeSetElement cert3PriorActionCode) {
		this.cert3PriorActionCode = cert3PriorActionCode;
	}
	
	/**
	 * Sets the cert4 prior action code.
	 * 
	 * @param cert4PriorActionCode the cert4PriorActionCode to set
	 */
	public void setCert4PriorActionCode(CodeSetElement cert4PriorActionCode) {
		this.cert4PriorActionCode = cert4PriorActionCode;
	}
	
	/**
	 * Sets the civil judgement code.
	 * 
	 * @param civilJudgementCode the civilJudgementCode to set
	 */
	public void setCivilJudgementCode(CodeSetElement civilJudgementCode) {
		this.civilJudgementCode = civilJudgementCode;
	}
	
	/**
	 * Sets the dl103 plus15 dui fee required code.
	 * 
	 * @param dl103Plus15DuiFeeRequiredCode the new dl103 plus15 dui fee required code
	 */
	public void setDl103Plus15DuiFeeRequiredCode(
			CodeSetElement dl103Plus15DuiFeeRequiredCode) {
		this.dl103Plus15DuiFeeRequiredCode = dl103Plus15DuiFeeRequiredCode;
	}
	
	/**
	 * Sets the dsr reinstatement approval needed code.
	 * 
	 * @param dsrReinstatementApprovalNeededCode the dsrReinstatementApprovalNeededCode to set
	 */
	public void setDsrReinstatementApprovalNeededCode(
			CodeSetElement dsrReinstatementApprovalNeededCode) {
		this.dsrReinstatementApprovalNeededCode = dsrReinstatementApprovalNeededCode;
	}
	
	/**
	 * Sets the dui completion required code.
	 * 
	 * @param duiCompletionRequiredCode the duiCompletionRequiredCode to set
	 */
	public void setDuiCompletionRequiredCode(
			CodeSetElement duiCompletionRequiredCode) {
		this.duiCompletionRequiredCode = duiCompletionRequiredCode;
	}
	
	/**
	 * Sets the echoed person.
	 * 
	 * @param echoedPerson the echoedPerson to set
	 */
	public void setEchoedPerson(Person echoedPerson) {
		this.echoedPerson = echoedPerson;
	}
	
	/**
	 * Sets the fr penalty fee due until date.
	 * 
	 * @param frPenaltyFeeDueUntilDate the frPenaltyFeeDueUntilDate to set
	 */
	public void setFrPenaltyFeeDueUntilDate(Date frPenaltyFeeDueUntilDate) {
		this.frPenaltyFeeDueUntilDate = frPenaltyFeeDueUntilDate;
	}
	
	/**
	 * Sets the fr proof on file code.
	 * 
	 * @param frProofOnFileCode the frProofOnFileCode to set
	 */
	public void setFrProofOnFileCode(CodeSetElement frProofOnFileCode) {
		this.frProofOnFileCode = frProofOnFileCode;
	}
	
	/**
	 * Sets the fr suspense effective date.
	 * 
	 * @param frSuspenseEffectiveDate the frSuspenseEffectiveDate to set
	 */
	public void setFrSuspenseEffectiveDate(Date frSuspenseEffectiveDate) {
		this.frSuspenseEffectiveDate = frSuspenseEffectiveDate;
	}
	
	/**
	 * Sets the ineligibility rx proof acceptable indicator code.
	 * 
	 * @param ineligibilityRxProofAcceptableIndicatorCode the ineligibilityRxProofAcceptableIndicatorCode to set
	 */
	public void setIneligibilityRxProofAcceptableIndicatorCode(
			CodeSetElement ineligibilityRxProofAcceptableIndicatorCode) {
		this.ineligibilityRxProofAcceptableIndicatorCode = ineligibilityRxProofAcceptableIndicatorCode;
	}
	
	/**
	 * Sets the ineligible for tow truck cert code.
	 * 
	 * @param ineligibleForTowTruckCertCode the ineligibleForTowTruckCertCode to set
	 */
	public void setIneligibleForTowTruckCertCode(
			CodeSetElement ineligibleForTowTruckCertCode) {
		this.ineligibleForTowTruckCertCode = ineligibleForTowTruckCertCode;
	}
	
	/**
	 * Sets the license history action codes.
	 * 
	 * @param licenseHistoryActionCodes the new license history action codes
	 */
	public void setLicenseHistoryActionCodes(
			List <LicenseHistoryActionCode> licenseHistoryActionCodes) {
		this.licenseHistoryActionCodes = licenseHistoryActionCodes;
	}
	
	/**
	 * Sets the license location and reason code.
	 * 
	 * @param licenseLocationAndReasonCode the new license location and reason code
	 */
	public void setLicenseLocationAndReasonCode(
			CodeSetElement licenseLocationAndReasonCode) {
		this.licenseLocationAndReasonCode = licenseLocationAndReasonCode;
	}
	
	/**
	 * Sets the mandatory non proof action code.
	 * 
	 * @param mandatoryNonProofActionCode the mandatoryNonProofActionCode to set
	 */
	public void setMandatoryNonProofActionCode(
			CodeSetElement mandatoryNonProofActionCode) {
		this.mandatoryNonProofActionCode = mandatoryNonProofActionCode;
	}
	
	/**
	 * Sets the number of open unserved actions included.
	 * 
	 * @param numberOfOpenUnservedActionsIncluded the new number of open unserved actions included
	 */
	public void setNumberOfOpenUnservedActionsIncluded(
			Integer numberOfOpenUnservedActionsIncluded) {
		this.numberOfOpenUnservedActionsIncluded = numberOfOpenUnservedActionsIncluded;
	}
	
	/**
	 * Sets the number of open unserved actions remaining.
	 * 
	 * @param numberOfOpenUnservedActionsRemaining the new number of open unserved actions remaining
	 */
	public void setNumberOfOpenUnservedActionsRemaining(
			Integer numberOfOpenUnservedActionsRemaining) {
		this.numberOfOpenUnservedActionsRemaining = numberOfOpenUnservedActionsRemaining;
	}
	
	/**
	 * Sets the process dl action termination code.
	 * 
	 * @param processDlActionTerminationCode the processDlActionTerminationCode to set
	 */
	public void setProcessDlActionTerminationCode(
			CodeSetElement processDlActionTerminationCode) {
		this.processDlActionTerminationCode = processDlActionTerminationCode;
	}
	
	/**
	 * Sets the proof eligibility date.
	 * 
	 * @param proofEligibilityDate the proofEligibilityDate to set
	 */
	public void setProofEligibilityDate(Date proofEligibilityDate) {
		this.proofEligibilityDate = proofEligibilityDate;
	}
	
	/**
	 * Sets the proof on file code.
	 * 
	 * @param proofOnFileCode the proofOnFileCode to set
	 */
	public void setProofOnFileCode(CodeSetElement proofOnFileCode) {
		this.proofOnFileCode = proofOnFileCode;
	}
	
	/**
	 * Sets the proof termination date.
	 * 
	 * @param proofTerminationDate the proofTerminationDate to set
	 */
	public void setProofTerminationDate(Date proofTerminationDate) {
		this.proofTerminationDate = proofTerminationDate;
	}
	
	/**
	 * Sets the reinstated on proof code.
	 * 
	 * @param reinstatedOnProofCode the reinstatedOnProofCode to set
	 */
	public void setReinstatedOnProofCode(CodeSetElement reinstatedOnProofCode) {
		this.reinstatedOnProofCode = reinstatedOnProofCode;
	}
	
	/**
	 * Sets the sr1p or sr22 required code.
	 * 
	 * @param sr1pOrSr22RequiredCode the sr1pOrSr22RequiredCode to set
	 */
	public void setSr1pOrSr22RequiredCode(CodeSetElement sr1pOrSr22RequiredCode) {
		this.sr1pOrSr22RequiredCode = sr1pOrSr22RequiredCode;
	}
	
	/**
	 * Sets the sr22 req qualify for dui restriction.
	 * 
	 * @param sr22ReqQualifyForDuiRestriction the sr22ReqQualifyForDuiRestriction to set
	 */
	public void setSr22ReqQualifyForDuiRestriction(
			CodeSetElement sr22ReqQualifyForDuiRestriction) {
		this.sr22ReqQualifyForDuiRestriction = sr22ReqQualifyForDuiRestriction;
	}
	
	/**
	 * Sets the sr22 required code.
	 * 
	 * @param sr22RequiredCode the sr22RequiredCode to set
	 */
	public void setSr22RequiredCode(CodeSetElement sr22RequiredCode) {
		this.sr22RequiredCode = sr22RequiredCode;
	}
	
	/**
	 * Sets the terminate fr suspension code.
	 * 
	 * @param terminateFrSuspensionCode the terminateFrSuspensionCode to set
	 */
	public void setTerminateFrSuspensionCode(
			CodeSetElement terminateFrSuspensionCode) {
		this.terminateFrSuspensionCode = terminateFrSuspensionCode;
	}
	
	/**
	 * Sets the unable to calculate eligibility code.
	 * 
	 * @param unableToCalculateEligibilityCode the unableToCalculateEligibilityCode to set
	 */
	public void setUnableToCalculateEligibilityCode(
			CodeSetElement unableToCalculateEligibilityCode) {
		this.unableToCalculateEligibilityCode = unableToCalculateEligibilityCode;
	}
	
	/**
	 * To string on.
	 * 
	 * @param aBuilder the a builder
	 * @param anIndent the an indent
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("Cert1AccidentCode", cert1AccidentCode, anIndent,
				aBuilder);
		outputKeyValue("Cert1ConvictionCode", cert1ConvictionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert1NegligentOperatorCode",
				cert1NegligentOperatorCode, anIndent, aBuilder);
		outputKeyValue("Cert1OutstandingHearingCode",
				cert1OutstandingHearingCode, anIndent, aBuilder);
		outputKeyValue("Cert1PriorActionCode", cert1PriorActionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert2AccidentCode", cert2AccidentCode, anIndent,
				aBuilder);
		outputKeyValue("Cert2ConvictionCode", cert2ConvictionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert2PriorActionCode", cert2PriorActionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert3ConvictionCode", cert3ConvictionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert3PriorActionCode", cert3PriorActionCode, anIndent,
				aBuilder);
		outputKeyValue("Cert4PriorActionCode", cert4PriorActionCode, anIndent,
				aBuilder);
		outputKeyValue("civilJudgementCode", civilJudgementCode, anIndent,
				aBuilder);
		outputKeyValue("dl103Plus15DuiFeeRequiredCode",
				dl103Plus15DuiFeeRequiredCode, anIndent, aBuilder);
		outputKeyValue("dsrReinstatementApprovalNeededCode",
				dsrReinstatementApprovalNeededCode, anIndent, aBuilder);
		outputKeyValue("duiCompletionRequiredCode", duiCompletionRequiredCode,
				anIndent, aBuilder);
		outputKeyValue("echoedPerson", echoedPerson, anIndent, aBuilder);
		outputKeyValue("frPenaltyFeeDueUntilDate", frPenaltyFeeDueUntilDate,
				anIndent, aBuilder);
		outputKeyValue("frProofOnFileCode", frProofOnFileCode, anIndent,
				aBuilder);
		outputKeyValue("frSuspenseEffectiveDate", frSuspenseEffectiveDate,
				anIndent, aBuilder);
		outputKeyValue("ineligibilityRxProofAcceptableIndicatorCode",
				ineligibilityRxProofAcceptableIndicatorCode, anIndent, aBuilder);
		outputKeyValue("ineligibleForTowTruckCertCode",
				ineligibleForTowTruckCertCode, anIndent, aBuilder);
		outputKeyValue("licenseHistoryActionCodes", licenseHistoryActionCodes,
				anIndent, aBuilder);
		outputKeyValue("licenseLocationAndReasonCode",
				licenseLocationAndReasonCode, anIndent, aBuilder);
		outputKeyValue("mandatoryNonProofActionCode",
				mandatoryNonProofActionCode, anIndent, aBuilder);
		outputKeyValue("numberOfOpenUnservedActionsIncluded",
				numberOfOpenUnservedActionsIncluded, anIndent, aBuilder);
		outputKeyValue("numberOfOpenUnservedActionsRemaining",
				numberOfOpenUnservedActionsRemaining, anIndent, aBuilder);
		outputKeyValue("processDlActionTerminationCode",
				processDlActionTerminationCode, anIndent, aBuilder);
		outputKeyValue("proofEligibilityDate", proofEligibilityDate, anIndent,
				aBuilder);
		outputKeyValue("proofOnFileCode", proofOnFileCode, anIndent, aBuilder);
		outputKeyValue("proofTerminationDate", proofTerminationDate, anIndent,
				aBuilder);
		outputKeyValue("reinstatedOnProofCode", reinstatedOnProofCode,
				anIndent, aBuilder);
		outputKeyValue("sr1pOrSr22RequiredCode", sr1pOrSr22RequiredCode,
				anIndent, aBuilder);
		outputKeyValue("sr22ReqQualifyForDuiRestriction",
				sr22ReqQualifyForDuiRestriction, anIndent, aBuilder);
		outputKeyValue("sr22RequiredCode", sr22RequiredCode, anIndent, aBuilder);
		outputKeyValue("terminateFrSuspensionCode", terminateFrSuspensionCode,
				anIndent, aBuilder);
		outputKeyValue("unableToCalculateEligibilityCode",
				unableToCalculateEligibilityCode, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * Set typeOfUpdate.
	 *
	 * @param typeOfUpdate the typeOfUpdate to set
	 */
	public void setTypeOfUpdate(String typeOfUpdate) {
		this.typeOfUpdate = typeOfUpdate;
	}
	
	/**
	 * Get the typeOfUpdate.
	 *
	 * @return the typeOfUpdate
	 */
	public String getTypeOfUpdate() {
		if (typeOfUpdate != null) {
			return typeOfUpdate;
		}
		else {
			typeOfUpdate = getTypeOfUpdateIndicator();
		}
		return typeOfUpdate;
	}
	
	/**
	 * Gets the type of update indicator.
	 * Requirements are documented in RemovalOfRestriction_Conditions.doc
	 * available in DLM tcode transformations folder.
	 *
	 * @return the type of update indicator
	 */
	public String getTypeOfUpdateIndicator() {
		String typeOfUpdateIndicator = TYPE_OF_UPDATE_B;
		if (checkRemovalOfRestrictionCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-0
		else if (checkDsrReinstatementApprovalNeededCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-1
		else if (checkDuiCompletionCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-2
		else if (checkCivilJudgementCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-3
		else if (checkFrPenaltyFeeDueUntilDateAndDuiCompletionCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-4
		else if (checkProofOfEligibilityDateAndUnableToCalculateEligibilityCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 3-5
		else if (checkMixedCondition()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 4-5,6,7
		else if (checkUnableToCalculateEligibilityCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		else if (checkIneligibilityRxProofAcceptableIndicatorCode()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		//Condition 4-1
		else if (checkSr22Required()) {
			typeOfUpdateIndicator = TYPE_OF_UPDATE_P;
		}
		return typeOfUpdateIndicator;
	}
	
	/**
	 * Check sr22 required.
	 *
	 * @return true, if successful
	 */
	protected boolean checkSr22Required() {
		//If both the following conditions are false
		//1. MDLSR22R = 1 or (MDLSR1PR is present and MDSR22R is not present or = 2) and
		//2. MDLSR22R is present and <> 1
		String sr22RequiredCode = null;
		String sr1psr22Required = null;
		if (!isNullOrBlank(getSr22RequiredCode())) {
			sr22RequiredCode = getSr22RequiredCode().getCode();
		}
		if (!isNullOrBlank(getSr1pOrSr22RequiredCode())) {
			sr1psr22Required = getSr1pOrSr22RequiredCode().getCode();
		}
		if (!(SR22_REQUIRED_CODE_1.equalsIgnoreCase(sr22RequiredCode) || (!isNullOrBlank(sr1psr22Required) && (isNullOrBlank(sr22RequiredCode) || SR22_REQUIRED_CODE_2
				.equalsIgnoreCase(sr22RequiredCode))))) {
			if (!(!isNullOrBlank(sr22RequiredCode) && !SR22_REQUIRED_CODE_1
					.equalsIgnoreCase(sr22RequiredCode))) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check removal of restriction code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkRemovalOfRestrictionCode() {
		CodeSetElement removalOfRestriction = getRestrictionRemovalFeeDue();
		if (!EaseUtil.isNullOrBlank(removalOfRestriction)
				&& REMOVAL_OF_RESTRICTION_CODE_1.equals(removalOfRestriction
						.getCode())) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check ineligibility rx proof acceptable indicator code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkIneligibilityRxProofAcceptableIndicatorCode() {
		CodeSetElement ineligibilityRxProofAcceptableIndicatorCode = getIneligibilityRxProofAcceptableIndicatorCode();
		if (!EaseUtil
				.isNullOrBlank(ineligibilityRxProofAcceptableIndicatorCode)
				&& INELIGIBLE_RX_PROOF_ACCEPTABLE_IND_1
						.equals(ineligibilityRxProofAcceptableIndicatorCode
								.getCode())) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check dsr reinstatement approval needed code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkDsrReinstatementApprovalNeededCode() {
		CodeSetElement dsrReinstatementApprovalNeededCode = getDsrReinstatementApprovalNeededCode();
		if (isSegmentgExist()
				&& !EaseUtil.isNullOrBlank(dsrReinstatementApprovalNeededCode)) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check dui completion code2.
	 *
	 * @return true, if successful
	 */
	protected boolean checkDuiCompletionCode() {
		if (isSegmentgExist()) {
			if (duiCompletionRequiredCode != null
					&& (!DUI_COMPLETION_CODE_2.equals(duiCompletionRequiredCode
							.getCode()) && !(DUI_COMPLETION_CODE_4
							.equals(duiCompletionRequiredCode.getCode())))) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check civil judgement code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkCivilJudgementCode() {
		if (isSegmentgExist() && !EaseUtil.isNullOrBlank(civilJudgementCode)) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check fr penalty fee due until date and dui completion code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkFrPenaltyFeeDueUntilDateAndDuiCompletionCode() {
		if (isSegmentgExist()) {
			if (!isNullOrBlank(getFrPenaltyFeeDueUntilDate())
					|| (!isNullOrBlank(getDuiCompletionRequiredCode()) && DUI_COMPLETION_CODE_2
							.equals(getDuiCompletionRequiredCode().getCode()))) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check proof of eligibility date and unable to calculate eligibility code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkProofOfEligibilityDateAndUnableToCalculateEligibilityCode() {
		if (!isNullOrBlank(getProofEligibilityDate())
				&& isNullOrBlank(getUnableToCalculateEligibilityCode())) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check mixed condition.
	 *
	 * @return true, if successful
	 */
	protected boolean checkMixedCondition() {
		if (!isSegmentgExist()
				|| (isNullOrBlank(unableToCalculateEligibilityCode)
						&& isNullOrBlank(sr22RequiredCode)
						&& isNullOrBlank(sr1pOrSr22RequiredCode)
						&& isNullOrBlank(sr22ReqQualifyForDuiRestriction) && isNullOrBlank(reinstatedOnProofCode))) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check unable to calculate eligibility code.
	 *
	 * @return true, if successful
	 */
	protected boolean checkUnableToCalculateEligibilityCode() {
		if (isSegmentgExist()) {
			if (unableToCalculateEligibilityCode != null
					&& (UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_7
							.equals(unableToCalculateEligibilityCode.getCode())
							|| (UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_8
									.equals(unableToCalculateEligibilityCode
											.getCode())) || (UNABLE_TO_CALCULATE_ELIGIBILITY_CODE_9
							.equals(unableToCalculateEligibilityCode.getCode())))) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Is segment G exist.
	 *
	 * @return a boolean
	 */
	public boolean isSegmentgExist() {
		List <CodeSetElement> segments = getSegments();
		boolean isSegmentgExist = false;
		if (segments != null) {
			for (CodeSetElement segmentCode : segments) {
				if (DLM_RESPONSE_SEGMENT_G.equals(segmentCode.getCode())) {
					isSegmentgExist = true;
					break;
				}
			}
		}
		return isSegmentgExist;
	}
	
	/**
	 * Check if Driver license not valid or never issued from DLM response.
	 * 
	 * @return a boolean
	 */
	public boolean isDlNotValidOrNeverIssued() {
		if (isInvalidClassChange() && isBirthExpDtBeforeOrEqDlExpDt()
				&& isDlRecordNotFound()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Check if invalid class change is not 1.
	 * 
	 * @return a boolean
	 */
	private boolean isInvalidClassChange() {
		if (getInvalidClassChange() != null) {
			if (!DLM_INVLAID_CLASS_CHANGE
					.equalsIgnoreCase(getInvalidClassChange().getCode())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check if birth date expiration calculated is prior process date.
	 * 
	 * @return a boolean
	 */
	private boolean isBirthExpDtBeforeOrEqDlExpDt() {
		Date birthExpDt = calculateBirthExpirationDt(getPerson());
		Date processDt = CurrentDateProvider.getInstance().getSystemDate();
		if (birthExpDt != null && processDt != null) {
			Calendar birthExpCal = Calendar.getInstance();
			Calendar processCal = Calendar.getInstance();
			birthExpCal.setTime(birthExpDt);
			processCal.setTime(processDt);
			if (birthExpCal.before(processCal)
					|| birthExpCal.equals(processCal)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Calculate birth date expiration date.
	 *
	 * @param applicant the applicant
	 * @return birth expiration date.
	 */
	private Date calculateBirthExpirationDt(Person applicant) {
		//	Example: From TCODE DLM logic
		//	Birth Date = 05/12/81
		//	Expiration Year = 11
		//	BirthExpDate = 05/12/11
		Date birthExpDt = null;
		if (applicant != null && applicant.getDriverLicense() != null) {
			Date dlExpirationDt = applicant.getDriverLicense()
					.getExpirationDate();
			Date birthDt = applicant.getBirthDate();
			if (dlExpirationDt != null && birthDt != null) {
				Calendar birthCal = Calendar.getInstance();
				Calendar dlExpirationCal = Calendar.getInstance();
				birthCal.setTime(birthDt);
				dlExpirationCal.setTime(dlExpirationDt);
				Calendar birthExpCal = Calendar.getInstance();
				birthExpCal.set(dlExpirationCal.get(YEAR), birthCal.get(MONTH),
						birthCal.get(DAY_OF_MONTH));
				birthExpDt = birthExpCal.getTime();
			}
		}
		return birthExpDt;
	}
	
	/**
	 *  Get a response code.
	 *  
	 * @return a return code set element value.
	 */
	private String getResponseCodeValue() {
		String code = null;
		if (getReturnCode() != null) {
			code = getReturnCode().getCode();
		}
		return code;
	}
	
	/**
	 * Check is response code value is blank.
	 * 
	 * @return a boolean 
	 */
	private boolean isResponseCodeValueBlank() {
		String code = null;
		if (getReturnCode() != null) {
			code = getReturnCode().getCode();
			if (code != null && code.trim().length() == 0) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check if DLM response has not DL record found response code.
	 * 
	 * @return a boolean
	 */
	public boolean isDlRecordNotFound() {
		if (DLM_RETURN_CODE_RECORD_NOT_FOUND
				.equalsIgnoreCase(getResponseCodeValue())
				|| isResponseCodeValueBlank()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Clear fr proof on file code.
	 */
	public void clearFrProofOnFileCode() {
		setFrProofOnFileCode(new CodeSetElement());
	}
	
	/**
	 * Sets the pending applicationclass.
	 *
	 * @param pendingApplicationclass the pendingApplicationclass to set
	 */
	public void setPendingApplicationclass(String pendingApplicationclass) {
		this.pendingApplicationclass = pendingApplicationclass;
	}
	
	/**
	 * Gets the pending applicationclass.
	 *
	 * @return the pendingApplicationclass
	 */
	public String getPendingApplicationclass() {
		return pendingApplicationclass;
	}
	
	/**
	 * Sets the pending motorcycle class.
	 *
	 * @param pendingMotorcycleClass the pendingMotorcycleClass to set
	 */
	public void setPendingMotorcycleClass(String pendingMotorcycleClass) {
		this.pendingMotorcycleClass = pendingMotorcycleClass;
	}
	
	/**
	 * Gets the pending motorcycle class.
	 *
	 * @return the pendingMotorcycleClass
	 */
	public String getPendingMotorcycleClass() {
		return pendingMotorcycleClass;
	}
	
	/**
	 * Sets the pending restriction codes.
	 *
	 * @param pendingRestrictionCodes the pendingRestrictionCodes to set
	 */
	public void setPendingRestrictionCodes(String pendingRestrictionCodes) {
		this.pendingRestrictionCodes = pendingRestrictionCodes;
	}
	
	/**
	 * Gets the pending restriction codes.
	 *
	 * @return the pendingRestrictionCodes
	 */
	public String getPendingRestrictionCodes() {
		return pendingRestrictionCodes;
	}
}
/**
 *  Modification History:
 *
 *  $Log: DlmRecord.java,v $
 *  Revision 1.47  2012/08/15 16:22:57  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.46  2012/08/14 20:45:49  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.45  2012/01/19 18:52:19  mwhys
 *  Updated getTypeOfUpdateIndicator(), condition 3-4. (Defect 1126)
 *
 *  Revision 1.44  2011/11/30 19:01:00  mwhys
 *  Updated SR22 related logic in getTypeOfUpdateIndicator(). (Defect 1003)
 *
 *  Revision 1.43  2011/10/12 21:01:17  mwkkc
 *  Performance Merge
 *
 *  Revision 1.42.6.1  2011/09/27 23:25:53  mwhys
 *  Added 3 properties which are set in SearchPersonByNameAndLastNameConverter.
 *
 *  Revision 1.42  2011/08/11 00:49:46  mwhys
 *  Added clearFrProofOnFileCode().
 *
 *  Revision 1.41  2011/08/06 00:05:59  mwhys
 *  Updated getTypeOfUpdateIndicator() with updated requirements. (Defect 6540)
 *
 *  Revision 1.40  2011/05/18 18:48:44  mwkfh
 *  methods which are not being called from outside this class are made private
 *
 *  Revision 1.39  2011/05/17 23:10:41  mwhxb3
 *  Added methods to see if DL not found or never issued.
 *
 *  Revision 1.38  2011/05/11 23:43:55  mwhxb3
 *  The code is refactored. No need to pass dlmRecord to calculate type of update.
 *
 *  Revision 1.37  2011/05/11 16:56:44  mwhxb3
 *  Added Get the type of update. Related to Defect 469.
 *
 *  Revision 1.36  2011/05/10 21:10:54  mwhxb3
 *  Added isSegmentGExist.
 *
 *  Revision 1.35  2011/05/03 23:22:38  mwhxb3
 *  Moved helper methods from ConverterHelper class.
 *
 *  Revision 1.34  2011/03/29 00:07:51  mwhxb3
 *  Added type of update with getter and setter.
 *
 *  Revision 1.33  2011/02/04 23:13:07  mwhys
 *  LicenseHistoryActionCode implements Serializable
 *
 *  Revision 1.32  2010/12/10 00:53:12  mwtjc1
 *  actionReasonCode added
 *
 *  Revision 1.31  2010/12/10 00:50:54  mwtjc1
 *  actionReasonCode added
 *
 *  Revision 1.30  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.29  2010/12/07 03:54:58  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.28  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.25.8.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.27  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.26  2010/06/03 16:48:51  mwuxb
 *  added variable echoedPerson
 *
 *  Revision 1.25  2010/05/01 17:06:47  mwuxb
 *  Updated
 *
 *  Revision 1.24  2010/04/30 00:49:45  mwtjc1
 *  updated
 *
 *  Revision 1.23  2010/04/29 22:50:58  mwtjc1
 *  updated
 *
 *  Revision 1.22  2010/04/29 21:30:54  mwtjc1
 *  updated
 *
 *  Revision 1.21  2010/04/29 21:27:30  mwtjc1
 *  updated
 *
 *  Revision 1.19  2010/04/29 20:40:31  mwtjc1
 *  updated
 *
 *  Revision 1.18  2010/04/29 20:38:25  mwtjc1
 *  updated
 *
 *  Revision 1.17  2010/04/29 20:37:27  mwtjc1
 *  typeOfActon variable is added
 *
 *  Revision 1.16  2010/04/29 20:34:16  mwtjc1
 *  updated
 *
 *  Revision 1.15  2010/04/29 20:32:15  mwtjc1
 *  licenseHistoryActionCodes is added
 *
 *  Revision 1.14  2010/04/29 20:30:58  mwtjc1
 *  inner class LicenseHistoryActionCode is created
 *
 *  Revision 1.13  2010/04/29 20:26:10  mwtjc1
 *  updated
 *
 *  Revision 1.12  2010/04/29 17:49:59  mwtjc1
 *  licenseLocationAndReasonCode added
 *
 *  Revision 1.11  2010/04/29 16:41:49  mwtjc1
 *  numberOfOpenUnservedActionsIncluded added
 *
 *  Revision 1.10  2010/04/28 20:38:17  mwuxb
 *  Added variables for Segment G
 *
 *  Revision 1.9  2010/04/28 20:14:20  mwuxb
 *  Added variables for Segment F
 *
 *  Revision 1.8  2010/04/28 19:50:54  mwuxb
 *  Added variables for Segment F
 *
 *  Revision 1.7  2010/04/24 20:54:20  mwuxb
 *  Additional variables for segment C
 *
 *  Revision 1.6  2010/04/21 01:12:11  mwuxb
 *  Moved segments to DlRecord
 *
 *  Revision 1.5  2010/04/21 01:05:45  mwuxb
 *  Moved person to DlRecord
 *
 *  Revision 1.4  2010/04/21 00:57:45  mwuxb
 *  Updated to extend DlRecord
 *
 *  Revision 1.3  2010/04/21 00:54:57  mwuxb
 *  Added AbstractDlRecord
 *
 *  Revision 1.2  2010/04/21 00:03:12  mwtjc1
 *  updated
 *
 *  Revision 1.1  2010/04/20 23:57:19  mwtjc1
 *  DlmRecord created
 *
 */
