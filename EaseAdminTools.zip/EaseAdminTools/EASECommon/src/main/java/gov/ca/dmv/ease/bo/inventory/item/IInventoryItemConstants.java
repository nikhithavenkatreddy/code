/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

/**
 * Description: //TODO - provide description!
 * File: IInventoryItemConstants.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/11/03 15:05:13 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryItemConstants {
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryItemConstants.java,v $
 *  Revision 1.4  2010/11/03 15:05:13  mwkfh
 *  removed TTC_ITEM_CODE
 *
 *  Revision 1.3  2010/10/29 20:13:23  mwkfh
 *  updated TTC_ITEM_CODE values
 *
 *  Revision 1.2  2010/10/28 21:22:39  mwkfh
 *  added TTC_ITEM_CODE
 *
 *  Revision 1.1  2010/09/14 18:07:58  mwpxp2
 *  Initial
 *
 */
