package gov.ca.dmv.ease.bo.financial;

public interface IExternalFeeRecord {
	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	String getDescription();

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	double getFee();

	/**
	 * Gets the amount code.
	 *
	 * @return the feeCode
	 */
	String getFeeCode();

	/**
	 * Get the feeIndicatorType.
	 *
	 * @return the feeIndicatorType
	 */
	String getFeeIndicatorType();
}
/**
 *  Modification History:
 *
 *  $Log: IExternalFeeRecord.java,v $
 *  Revision 1.1  2011/10/21 22:53:20  mwpxp2
 *  Initial - extracted from ApplicableFee
 *
 */
