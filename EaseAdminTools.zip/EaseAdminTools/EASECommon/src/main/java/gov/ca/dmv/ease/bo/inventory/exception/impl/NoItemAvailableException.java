/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: I am exception to be used when repository has no available items
 * File: NoItemAvailableException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Sep 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/22 20:56:36 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class NoItemAvailableException extends InventoryException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3935128426630699688L;

	/**
	 * Instantiates a new item no available exception.
	 */
	public NoItemAvailableException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public NoItemAvailableException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public NoItemAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public NoItemAvailableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: NoItemAvailableException.java,v $
 *  Revision 1.1  2010/09/22 20:56:36  mwpxp2
 *  renamed for readability
 *
 *  Revision 1.1  2010/09/22 20:45:10  mwpxp2
 *  Initial
 *
 */
