/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx;

import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Date;
import java.util.List;

/**
 * Description: This interface provides methods to fetch the Process History Information.
 * Typically used to retrieve prior user context, activities information.
 * File: IProcessHistory.java
 * Module:  gov.ca.dmv.ease.bo.tx
 * Created: Mar 9, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/04/05 21:25:00 $
 * Last Changed By: $Author: mwyxg1 $
 */
public interface IProcessHistory {
	/**
	 * Gets the application date.
	 * 
	 * @return the application date
	 */
	public Date getApplicationDate();

	/**
	 * Gets the Control Cashier Sequence #
	 * @return the controlCashierSeqNumber
	 */
	public String getControlCashierSeqNumber();

	/**
	 * Gets the DAF Number
	 * @return the transactionIdentifier
	 */
	public Integer getTransactionIdentifier();

	/**
	 * Gets the executed Activities.
	 * 
	 * @return the executedActivities
	 */
	public List <Activity> getExecutedActivities();

	/**
	 * Gets the failed Activities.
	 * 
	 * @return the failedActivities
	 */
	public List <Activity> getFailedActivities();

	/**
	 * Gets the non Executed Activities.
	 * 
	 * @return the nonExecutedActivities
	 */
	public List <Activity> getNonExecutedActivities();

	/**
	 * Gets the system date.
	 * 
	 * @return the system date
	 */
	public Date getSystemDate();

	/**
	 * Gets the User Context.
	 * 
	 * @return the userContext
	 */
	public IUserContext getUserContext();
}
/**
 *  Modification History:
 * 
 *  $Log: IProcessHistory.java,v $
 *  Revision 1.4  2011/04/05 21:25:00  mwyxg1
 *  remove processTimestamp
 *
 *  Revision 1.3  2010/07/27 00:21:46  mwjxa11
 *  Added DAF Number
 *
 *  Revision 1.2  2010/07/22 17:50:33  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/04/09 18:33:08  mwuxb
 *  Added Application date and system date
 *
 *  Revision 1.2  2010/03/23 16:49:23  mwpxr4
 *  Added  Control Cashier Sequence #
 *
 *  Revision 1.1  2010/03/09 22:37:37  mwhxa2
 *  Interface for process history
 *
*/
