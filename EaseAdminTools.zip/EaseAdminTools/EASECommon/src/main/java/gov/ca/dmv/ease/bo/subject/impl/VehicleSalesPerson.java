/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.license.impl.SalesPersonLicense;
import gov.ca.dmv.ease.bo.locator.NonAddressType;
import gov.ca.dmv.ease.fw.logging.IAuditable;

/**
 * Description: vehicle salesperson class encapsulates all the characteristics of a
 * vehicle salesperson who:
	�is employed as a salesperson by a dealer who sells or trades interest in vehicles required to be registered.
	�induces or attempts to induce any person to buy or exchange an interest in a vehicle required to be registered 
	for monetary gain or other thing of value from the seller or purchaser of a vehicle.
	�exercises managerial control over the business of a licensed vehicle dealer or supervises sales persons employed by the dealer. 
 * File: VehicleSalesPerson.java
 * Module: gov.ca.dmv.ease.bo.subject.impl 
 * Created: Apr 7, 2010
 * @author mwvxm6
 * @version $Revision: 1.5 $ 
 * Last Changed: $Date: 2010/12/07 22:11:39 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class VehicleSalesPerson extends Person implements IAuditable {
	// Please use Person for HQ inquiry and upcast to VehicleSalesPerson for SP transactions
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7864442830241831518L;
	/** The Sales Person license. */
	private SalesPersonLicense salesPersonLicense;

	/** This represents the AKA names of the person. */
	// Use attribute personNames in Person class which is equivalent to akaNames ?
	//private List<PersonName> akaNames;
	/** Default Constructor */
	public VehicleSalesPerson() {
	}

	/**
	 * Gets the home phone number.
	 * 
	 * @return the home phone number
	 */
	public String getHomePhoneNumber() {
		return getNonAddressType(NonAddressType.HOME_PHONE);
	}

	/**
	 * @return the spLicense
	 */
	public SalesPersonLicense getSalesPersonLicense() {
		return salesPersonLicense;
	}

	/**
	 * @param spLicense the spLicense to set
	 */
	public void setSalesPersonLicense(SalesPersonLicense spLicense) {
		this.salesPersonLicense = spLicense;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("salesPersonLicense", salesPersonLicense, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
