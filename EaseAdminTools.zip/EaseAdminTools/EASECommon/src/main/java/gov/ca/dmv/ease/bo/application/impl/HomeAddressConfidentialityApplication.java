/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.vr.record.impl.VehicleRecord;

/**
 * Description: This class captures information to update the Home Address Confidentiality on the driver record
 * Home address confidentiality is the suppression of an individual�s residence and mailing address 
 * on his/her DL or vehicle registration (VR) records. 
 * A person with a confidential status will not have his/her address released to a requester by DMV.
 * File: HomeAddressConfidentialityInquiry.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class HomeAddressConfidentialityApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7593365000588469248L;
	/** The name of an individual�s employing agency. */
	private String employingAgency;
	/** The current Vehicle information used in the inquiry provided by the applicant. */
	private VehicleRecord inquiredVehicleRecord;
	// VR Section
	/** The New Pending Vehicle information. */
	private VehicleRecord pendingVehicleRecord;
	/** The previous Vehicle information returned by the service TCODE C52. */
	private VehicleRecord previousVehicleRecord;
	/** The party for whom the Home Address Confidentiality is requested (can be the employee, spouse, and children.) */
	private CodeSetElement requestedForCode;
	/** R - Registered Owner, P - Pending Registered Owner, B - Both  */
	private CodeSetElement updateCode;

	/**
	 * @return the employingAgency
	 */
	public String getEmployingAgency() {
		return employingAgency;
	}

	/**
	 * @return the currentVehicleRecord
	 */
	public VehicleRecord getInquiredVehicleRecord() {
		return inquiredVehicleRecord;
	}

	/**
	 * @return the newPendingVehicleRecord
	 */
	public VehicleRecord getPendingVehicleRecord() {
		return pendingVehicleRecord;
	}

	/**
	 * @return the previousVehicleRecord
	 */
	public VehicleRecord getPreviousVehicleRecord() {
		return previousVehicleRecord;
	}

	/**
	 * @return the requestedForCode
	 */
	public CodeSetElement getRequestedForCode() {
		return requestedForCode;
	}

	/**
	 * @return the updateCode
	 */
	public CodeSetElement getUpdateCode() {
		return updateCode;
	}

	/**
	 * @param employingAgency the employingAgency to set
	 */
	public void setEmployingAgency(String employingAgency) {
		this.employingAgency = employingAgency;
	}

	/**
	 * @param currentVehicleRecord the currentVehicleRecord to set
	 */
	public void setInquiredVehicleRecord(VehicleRecord currentVehicleRecord) {
		this.inquiredVehicleRecord = currentVehicleRecord;
	}

	/**
	 * @param newPendingVehicleRecord the newPendingVehicleRecord to set
	 */
	public void setPendingVehicleRecord(VehicleRecord newPendingVehicleRecord) {
		this.pendingVehicleRecord = newPendingVehicleRecord;
	}

	/**
	 * @param previousVehicleRecord the previousVehicleRecord to set
	 */
	public void setPreviousVehicleRecord(VehicleRecord previousVehicleRecord) {
		this.previousVehicleRecord = previousVehicleRecord;
	}

	/**
	 * @param requestedForCode the requestedForCode to set
	 */
	public void setRequestedForCode(CodeSetElement requestedForCode) {
		this.requestedForCode = requestedForCode;
	}

	/**
	 * @param updateCode the updateCode to set
	 */
	public void setUpdateCode(CodeSetElement updateCode) {
		this.updateCode = updateCode;
	}
}
