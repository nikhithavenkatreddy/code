/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.math.BigDecimal;

/**
 * Description: This represents the single invoice item and it has information
 * related to fee and fee waived.
 * File: InvoiceItem.java
 * Module:  gov.ca.dmv.ease.bo.financial
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2012/09/15 00:42:12 $
 * Last Changed By: $Author: mwhys $
 */
public class InvoiceItem extends BaseBusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1205859503960504305L;
	/** The fee. */
	private Fee fee;
	// TO BE DELETED..
	/** The fee waived reason. */
	private String feeWaivedReason;
	/** The fee waived reason. 
	 * example. Armed Forces extension - A */
	private CodeSetElement feeWaivedReasonCode;
	/** Holds the discount amount. */
	private BigDecimal waivedAmount;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((fee == null) ? 0 : fee.hashCode());
		result = prime * result
				+ ((feeWaivedReason == null) ? 0 : feeWaivedReason.hashCode());
		result = prime
				* result
				+ ((feeWaivedReasonCode == null) ? 0 : feeWaivedReasonCode
						.hashCode());
		result = prime * result
				+ ((waivedAmount == null) ? 0 : waivedAmount.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		InvoiceItem other = (InvoiceItem) obj;
		if (fee == null) {
			if (other.fee != null)
				return false;
		}
		else if (!fee.equals(other.fee))
			return false;
		if (feeWaivedReason == null) {
			if (other.feeWaivedReason != null)
				return false;
		}
		else if (!feeWaivedReason.equals(other.feeWaivedReason))
			return false;
		if (feeWaivedReasonCode == null) {
			if (other.feeWaivedReasonCode != null)
				return false;
		}
		else if (!feeWaivedReasonCode.equals(other.feeWaivedReasonCode))
			return false;
		if (waivedAmount == null) {
			if (other.waivedAmount != null)
				return false;
		}
		else if (!waivedAmount.equals(other.waivedAmount))
			return false;
		return true;
	}
	
	/**
	 * Default Constructor.
	 */
	public InvoiceItem() {
	}
	
	/**
	 * Instantiates a new invoice item.
	 *
	 * @param invoiceItem the invoice item
	 */
	public InvoiceItem(InvoiceItem invoiceItem) {
		super();
		copy(invoiceItem);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#copy(gov.ca.dmv.ease.bo.impl.BusinessObject)
	 */
	@Override
	protected void copy(BusinessObject dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null InvoiceItem argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		InvoiceItem invoiceItem = (InvoiceItem) dataToCopy;
		//Copy fee
		if (isNotNull(invoiceItem.getFee())) {
			setFee(new Fee(invoiceItem.getFee()));
		}
		else {
			setFee(null);
		}
		//Copy feeWaivedReason
		if (isNotNull(invoiceItem.getFeeWaivedReason())) {
			setFeeWaivedReason(invoiceItem.getFeeWaivedReason());
		}
		//Copy feeWaivedReasonCode
		if (isNotNull(invoiceItem.getFeeWaivedReasonCode())) {
			setFeeWaivedReasonCode(new CodeSetElement(invoiceItem
					.getFeeWaivedReasonCode()));
		}
		else {
			setFeeWaivedReasonCode(null);
		}
		//Copy waivedAmount
		if (isNotNull(invoiceItem.getWaivedAmount())) {
			setWaivedAmount(new BigDecimal(invoiceItem.getWaivedAmount()
					.doubleValue()));
		}
		else {
			setWaivedAmount(null);
		}
	}
	
	/**
	 * This method will fetch the Driver License Fee Information.
	 * 
	 * @return the Driver License Fee Information
	 */
	public DriverLicenseFee getDriverLicenceFee() {
		DriverLicenseFee driverLicenseFee = null;
		if (fee instanceof DriverLicenseFee) {
			driverLicenseFee = (DriverLicenseFee) fee;
		}
		return driverLicenseFee;
	}
	
	/**
	 * Gets the fee.
	 * 
	 * @return the fee
	 */
	public Fee getFee() {
		return fee;
	}
	
	/**
	 * Gets the fee waived reason.
	 * 
	 * @return the feeWaivedReason
	 */
	public String getFeeWaivedReason() {
		if (getFeeWaivedReasonCode() == null) {
			return null;
		}
		else {
			return getFeeWaivedReasonCode().getCode();
		}
	}
	
	/**
	 * Gets the fee waived reason code.
	 *
	 * @return the feeWaivedReasonCode
	 */
	public CodeSetElement getFeeWaivedReasonCode() {
		return feeWaivedReasonCode;
	}
	
	/**
	 * Gets the waived amount.
	 * 
	 * @return the waivedAmount
	 */
	public BigDecimal getWaivedAmount() {
		return waivedAmount;
	}
	
	/**
	 * Checks if is fee waived.
	 * 
	 * @return true if fee waived amount is greater than zero.
	 */
	public Boolean isFeeWaived() {
		return ((waivedAmount != null && waivedAmount.doubleValue() > 0) ? true
				: false);
	}
	
	/**
	 * Sets the fee.
	 * 
	 * @param fee the fee to set
	 */
	public void setFee(Fee fee) {
		this.fee = fee;
	}
	
	/**
	 * Sets the fee waived reason.
	 * 
	 * @param feeWaivedReason the feeWaivedReason to set
	 */
	public void setFeeWaivedReason(String feeWaivedReason) {
		this.feeWaivedReason = feeWaivedReason;
	}
	
	/**
	 * Sets the fee waived reason code.
	 *
	 * @param feeWaivedReasonCode the feeWaivedReasonCode to set
	 */
	public void setFeeWaivedReasonCode(CodeSetElement feeWaivedReasonCode) {
		this.feeWaivedReasonCode = feeWaivedReasonCode;
	}
	
	/**
	 * Sets the waived amount.
	 * 
	 * @param waivedAmount the waivedAmount to set
	 */
	public void setWaivedAmount(BigDecimal waivedAmount) {
		this.waivedAmount = waivedAmount;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("fee", fee, anIndent, aBuilder);
		outputKeyValue("feeWaivedReason", feeWaivedReason, anIndent, aBuilder);
		outputKeyValue("feeWaivedReasonCode", feeWaivedReasonCode, anIndent,
				aBuilder);
		outputKeyValue("waivedAmount", waivedAmount, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: InvoiceItem.java,v $
 *  Revision 1.9  2012/09/15 00:42:12  mwhys
 *  Added copy constructor. (Defect 6900 - AN fatal)
 *
 *  Revision 1.8  2011/07/19 16:33:31  mwhys
 *  Generated hashCode and equals methods.
 *
 *  Revision 1.7  2010/12/07 22:08:32  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.6  2010/12/07 03:03:13  mwpxp2
 *  Added toStringOn/1; sorted
 *
 *  Revision 1.5  2010/12/03 19:07:30  mwpxp2
 *  Modified getFeeWaivedReason to operate with null reason code
 *
 *  Revision 1.4  2010/09/13 04:40:28  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/05/04 00:49:06  mwvxm6
 *  Modified attribute  feeWaivedReasonCode to CodeSetElement
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.9  2010/03/17 23:03:11  mwhxa2
 *  Add getDriverLicenceFee()
 *
 *  Revision 1.8  2010/03/05 00:49:10  mwuxb
 *  Update feeStatusCodes to feeStatusTypes
 *
 *  Revision 1.7  2010/03/04 22:40:09  mwuxb
 *  Updated feePaidCode to feePaidCodes
 *
 *  Revision 1.6  2010/02/18 18:29:33  mwuxb
 *  Added feePaidCode attribute
 *
 *  Revision 1.5  2010/02/04 19:09:28  mwvxm6
 *  Removed Autowired and configured explicitly in spring context xml
 *
 *  Revision 1.4  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/05 03:01:42  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/10/15 22:20:08  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.9  2009/10/03 21:06:33  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.8  2009/09/24 21:11:43  mwhxa2
 *  Extends BaseBusinessObject and Implements IValidatable
 *
 *  Revision 1.7  2009/08/27 05:39:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/08/22 23:21:45  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.5  2009/08/04 16:57:33  mwrsk
 *  Remove Hibernate annotations
 *
 *  Revision 1.4  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.3  2009/07/30 01:48:52  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:36  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:17  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
