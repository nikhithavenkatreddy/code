/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I am interface for interacting with Inventory of a specific item type -
 *  understood as collection of item sequences
 *  All sequences are for the same item type
 *  
 * File: ISingleTypeInventory.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2010/10/14 05:56:46 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISingleTypeInventory extends Serializable {
	/**
	 * Adds the.
	 * 
	 * @param aSequence the a sequence
	 */
	void add(IContiguousItemSequence aSequence);

	/**
	 * As item list.
	 * 
	 * @return the list< i item>
	 */
	List <IInventoryItem> asItemList();

	/**
	 * Gets the item count.
	 * 
	 * @return the item count
	 */
	int getItemCount();

	/**
	 * Gets the item type.
	 * 
	 * @return the item type
	 */
	IItemType getItemType();

	/**
	 * Checks for type.
	 * 
	 * @param type the type
	 * 
	 * @return true, if successful
	 */
	boolean hasType(IItemType type);

	/**
	 * Issue next available item.
	 * 
	 * @return the i inventory item
	 */
	IInventoryItem issueNextAvailableItem();
}
/**
 *  Modification History:
 *
 *  $Log: ISingleTypeInventory.java,v $
 *  Revision 1.8  2010/10/14 05:56:46  mwpxp2
 *  Added two methods
 *
 *  Revision 1.7  2010/10/05 17:38:45  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.6  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.5  2010/08/31 03:46:16  mwpxp2
 *  Added add/1, asItemList/0, getItemCount/0
 *
 *  Revision 1.4  2010/08/31 01:11:04  mwpxp2
 *  Extended Serializable
 *
 *  Revision 1.3  2010/08/30 23:25:35  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.2  2010/08/30 23:20:34  mwpxp2
 *  Renamed use~ to issue~
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
