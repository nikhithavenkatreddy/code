/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class is used to make a driver record inquiry and
 * capture information from the response. 
 * File: CounselorInquiryApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 10, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class CounselorInquiryApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8392805325002906038L;
}
