/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.math.BigDecimal;
import java.util.Date;

/** 
 * Description: This represents the payment information such as amount and date.
 * File: Payment.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Apr 28, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/01/14 21:55:06 $
 * Last Changed By: $Author: mwrrv3 $
 */
public abstract class Payment extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6657544205336540672L;
	/** The amount. */
	private BigDecimal amount;
	/** The date. */
	private Date date;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Payment other = (Payment) obj;
		if (amount == null) {
			if (other.amount != null) {
				return false;
			}
		}
		else if (!amount.equals(other.amount)) {
			return false;
		}
		if (date == null) {
			if (other.date != null) {
				return false;
			}
		}
		else if (!date.equals(other.date)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the amount.
	 * 
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Gets the date.
	 * 
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		return result;
	}

	/**
	 * Checks if is cash.
	 * 
	 * @return true, if is cash
	 */
	public boolean isCash() {
		return false;
	}

	/**
	 * Checks if is check.
	 * 
	 * @return true, if is check
	 */
	public boolean isCheck() {
		return false;
	}

	/**
	 * Checks if is credit.
	 * 
	 * @return true, if is credit
	 */
	public boolean isCredit() {
		return false;
	}

	/**
	 * Checks if is debit.
	 * 
	 * @return true, if is debit
	 */
	public boolean isDebit() {
		return false;
	}

	/**
	 * Checks if is voucher.
	 * 
	 * @return true, if is voucher
	 */
	public boolean isVoucher() {
		return false;
	}

	/**
	 * Sets the amount.
	 * 
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Sets the date.
	 * 
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("amount", amount, anIndent, aBuilder);
		outputKeyValue("date", date, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/**
	 * 
	 * @return
	 */
	public String getAmountAsString() {
		if (amount != null) {
			return amount.toString();
		}
		return null;
	}

	/**
	 * 
	 * @param amount
	 */
	public void setAmountAsString(String amount) {
		if (amount != null && !"".equals(amount.trim())) {
			this.amount = new BigDecimal(amount);
		}
		else {
			this.amount = null;
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Payment.java,v $
 *  Revision 1.6  2011/01/14 21:55:06  mwrrv3
 *  Added getAmountAsString and setAmountAsString methods to support validations.
 *
 *  Revision 1.5  2010/12/07 22:08:32  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 03:03:13  mwpxp2
 *  Added toStringOn/1; sorted
 *
 *  Revision 1.3  2010/07/07 18:48:11  mwpxp2
 *  Added is~ tests
 *
 *  Revision 1.2  2010/07/07 18:46:43  mwpxp2
 *  Added is~ redefinition from super
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/06 00:14:19  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/09/24 23:03:30  mwhxa2
 *  Payment now extends base businessObject
 *
 *  Revision 1.7  2009/08/27 05:39:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/08/22 23:21:46  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.5  2009/08/10 22:17:25  mwrrv3
 *  Changed to abstract class.
 *
 *  Revision 1.4  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.3  2009/07/14 23:44:37  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:51:19  ppalacz
 *  Removed shadowing of id from super
 *
 *  Revision 1.1  2009-07-12 07:35:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
