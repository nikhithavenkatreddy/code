/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: This class holds Photo Related Information
 * File: PhotoInformation.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Jan 29, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.11 $
 * Last Changed: $Date: 2012/02/29 18:37:31 $
 * Last Changed By: $Author: mwhys $
 */
public class PhotoInformation extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7726824788241970686L;
	/** The Constant BLANK. */
	private static final String BLANK = "";
	/** The active directory id .*/
	private String activeDirectoryId;
	/** The Bates Micrographics Number used in Photo Identification process for Travel Crew Mode.
	 * When a customer takes a photo the photo system generates magstripe number. 
	 * This photo number is like sequence number and is used as the photo id. 
	 * DMV uses this number to locate and/or update photo information.*/
	private String batesMicrographicsNumber;
	/** The camera station id .*/
	private String cameraStationId;
	/** The employee authorization code .*/
	private String employeeAuthorizationCode;
	/** The employee tech id .*/
	private String employeeTechId;
	/** The Photo Address .*/
	private Address photoAddress;
	/** The photo match indicator/code .*/
	private String photoMatchCode;
	/** The Photo Name .*/
	private String photoName;
	/** The Photo Office Id .*/
	private String photoOfficeId;
	/** The photo override indicator .*/
	private String photoOverrideIndicator;
	/** The Photo Sequence Number .*/
	private String photoSequenceNumber;
	/** The Photo Date .*/
	private Date photoTakenDate;
	/** The queue selection method .*/
	private String queueSelectionMethod;
	
	/**
	 * Default Constructor
	 */
	public PhotoInformation() {
		super();
	}
	
	/**
	 * Instantiates a new fingerprint information.
	 *
	 * @param dataToCopy the data to copy
	 */
	public PhotoInformation(PhotoInformation objectToCopy) {
		super();
		copy(objectToCopy);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(PhotoInformation objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy method for " + this);
		}
		super.copy(objectToCopy);
		setActiveDirectoryId(objectToCopy.getActiveDirectoryId());
		setBatesMicrographicsNumber(objectToCopy.getBatesMicrographicsNumber());
		setCameraStationId(objectToCopy.getCameraStationId());
		setEmployeeAuthorizationCode(objectToCopy
				.getEmployeeAuthorizationCode());
		setEmployeeTechId(objectToCopy.getEmployeeTechId());
		if (EaseUtil.isNotNull(objectToCopy.getPhotoAddress())) {
			setPhotoAddress(new Address(objectToCopy.getPhotoAddress()));
		}
		else {
			setPhotoAddress(null);
		}
		setPhotoMatchCode(objectToCopy.getPhotoMatchCode());
		setPhotoName(objectToCopy.getPhotoName());
		setPhotoOfficeId(objectToCopy.getPhotoOfficeId());
		setPhotoOverrideIndicator(objectToCopy.getPhotoOverrideIndicator());
		setPhotoSequenceNumber(objectToCopy.getPhotoSequenceNumber());
		if (EaseUtil.isNotNull(objectToCopy.getPhotoTakenDate())) {
			setPhotoTakenDate(new Date(objectToCopy.getPhotoTakenDate()
					.getTime()));
		}
		else {
			setPhotoTakenDate(null);
		}
		setQueueSelectionMethod(objectToCopy.getQueueSelectionMethod());
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PhotoInformation other = (PhotoInformation) obj;
		if (batesMicrographicsNumber == null) {
			if (other.batesMicrographicsNumber != null) {
				return false;
			}
		}
		else if (!batesMicrographicsNumber
				.equals(other.batesMicrographicsNumber)) {
			return false;
		}
		if (photoAddress == null) {
			if (other.photoAddress != null) {
				return false;
			}
		}
		else if (!photoAddress.equals(other.photoAddress)) {
			return false;
		}
		if (photoName == null) {
			if (other.photoName != null) {
				return false;
			}
		}
		else if (!photoName.equals(other.photoName)) {
			return false;
		}
		if (photoOfficeId == null) {
			if (other.photoOfficeId != null) {
				return false;
			}
		}
		else if (!photoOfficeId.equals(other.photoOfficeId)) {
			return false;
		}
		if (photoSequenceNumber == null) {
			if (other.photoSequenceNumber != null) {
				return false;
			}
		}
		else if (!photoSequenceNumber.equals(other.photoSequenceNumber)) {
			return false;
		}
		if (photoTakenDate == null) {
			if (other.photoTakenDate != null) {
				return false;
			}
		}
		else if (!photoTakenDate.equals(other.photoTakenDate)) {
			return false;
		}
		return true;
	}
	
	/**
	 * @return the activeDirectoryId
	 */
	public String getActiveDirectoryId() {
		return activeDirectoryId;
	}
	
	/**
	 * Sets the Bates Micrographics Number.
	 * 
	 * @return the batesMicrographicsNumber
	 */
	public String getBatesMicrographicsNumber() {
		return batesMicrographicsNumber;
	}
	
	/**
	 * @return the cameraStationId
	 */
	public String getCameraStationId() {
		return cameraStationId;
	}
	
	/**
	 * @return the employeeAuthorizationCode
	 */
	public String getEmployeeAuthorizationCode() {
		return employeeAuthorizationCode;
	}
	
	/**
	 * @return the employeeTechId
	 */
	public String getEmployeeTechId() {
		return employeeTechId;
	}
	
	/**
	 * Gets the Photo Address.
	 * 
	 * @return the photoAddress
	 */
	public Address getPhotoAddress() {
		return photoAddress;
	}
	
	/**
	 * @return the photoMatchCode
	 */
	public String getPhotoMatchCode() {
		return photoMatchCode;
	}
	
	/**
	 * Gets the Photo Name.
	 * 
	 * @return the photoName
	 */
	public String getPhotoName() {
		return photoName;
	}
	
	/**
	 * Gets the Photo Office Id.
	 * 
	 * @return the photoOfficeId
	 */
	public String getPhotoOfficeId() {
		return photoOfficeId;
	}
	
	/**
	 * @return the photoOverrideIndicator
	 */
	public String getPhotoOverrideIndicator() {
		return photoOverrideIndicator;
	}
	
	/**
	 * Gets the Photo Sequence Number.
	 * @return the photoSequenceNumber
	 */
	public String getPhotoSequenceNumber() {
		return photoSequenceNumber;
	}
	
	/**
	 * Gets the Photo Taken Date.
	 * 
	 * @return the photoTakenDate
	 */
	public Date getPhotoTakenDate() {
		return photoTakenDate;
	}
	
	/**
	 * @return the queueSelectionMethod
	 */
	public String getQueueSelectionMethod() {
		return queueSelectionMethod;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((batesMicrographicsNumber == null) ? 0
						: batesMicrographicsNumber.hashCode());
		result = prime * result
				+ ((photoAddress == null) ? 0 : photoAddress.hashCode());
		result = prime * result
				+ ((photoName == null) ? 0 : photoName.hashCode());
		result = prime * result
				+ ((photoOfficeId == null) ? 0 : photoOfficeId.hashCode());
		result = prime
				* result
				+ ((photoSequenceNumber == null) ? 0 : photoSequenceNumber
						.hashCode());
		result = prime * result
				+ ((photoTakenDate == null) ? 0 : photoTakenDate.hashCode());
		return result;
	}
	
	/**
	 * Reset photo sequence number.
	 */
	public void resetPhotoSequenceNumber() {
		setPhotoSequenceNumber(BLANK);
	}
	
	/**
	 * @param activeDirectoryId the activeDirectoryId to set
	 */
	public void setActiveDirectoryId(String activeDirectoryId) {
		this.activeDirectoryId = activeDirectoryId;
	}
	
	/**
	 * Gets the Bates Micrographics Number.
	 * 
	 * @param batesMicrographicsNumber the batesMicrographicsNumber to set
	 */
	public void setBatesMicrographicsNumber(String batesMicrographicsNumber) {
		this.batesMicrographicsNumber = batesMicrographicsNumber;
	}
	
	/**
	 * @param cameraStationId the cameraStationId to set
	 */
	public void setCameraStationId(String cameraStationId) {
		this.cameraStationId = cameraStationId;
	}
	
	/**
	 * @param employeeAuthorizationCode the employeeAuthorizationCode to set
	 */
	public void setEmployeeAuthorizationCode(String employeeAuthorizationCode) {
		this.employeeAuthorizationCode = employeeAuthorizationCode;
	}
	
	/**
	 * @param employeeTechId the employeeTechId to set
	 */
	public void setEmployeeTechId(String employeeTechId) {
		this.employeeTechId = employeeTechId;
	}
	
	/**
	 * Sets the Photo Address.
	 * 
	 * @param photoAddress the photoAddress to set
	 */
	public void setPhotoAddress(Address photoAddress) {
		this.photoAddress = photoAddress;
	}
	
	/**
	 * @param photoMatchCode the photoMatchCode to set
	 */
	public void setPhotoMatchCode(String photoMatchCode) {
		this.photoMatchCode = photoMatchCode;
	}
	
	/**
	 * Sets the Photo Name.
	 * 
	 * @param photoName the photoName to set
	 */
	public void setPhotoName(String photoName) {
		this.photoName = photoName;
	}
	
	/**
	 * Sets the Photo Office Id.
	 * 
	 * @param photoOfficeId the photoOfficeId to set
	 */
	public void setPhotoOfficeId(String photoOfficeId) {
		this.photoOfficeId = photoOfficeId;
	}
	
	/**
	 * @param photoOverrideIndicator the photoOverrideIndicator to set
	 */
	public void setPhotoOverrideIndicator(String photoOverrideIndicator) {
		this.photoOverrideIndicator = photoOverrideIndicator;
	}
	
	/**
	 * Sets the Photo Sequence Number.
	 * 
	 * @param photoSequenceNumber the photoSequenceNumber to set
	 */
	public void setPhotoSequenceNumber(String photoSequenceNumber) {
		this.photoSequenceNumber = photoSequenceNumber;
	}
	
	/**
	 * Sets the Photo Taken Date.
	 * 
	 * @param photoTakenDate the photoTakenDate to set
	 */
	public void setPhotoTakenDate(Date photoTakenDate) {
		this.photoTakenDate = photoTakenDate;
	}
	
	/**
	 * @param queueSelectionMethod the queueSelectionMethod to set
	 */
	public void setQueueSelectionMethod(String queueSelectionMethod) {
		this.queueSelectionMethod = queueSelectionMethod;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("cameraStationId", cameraStationId, anIndent, aBuilder);
		outputKeyValue("employeeAuthorizationCode", employeeAuthorizationCode,
				anIndent, aBuilder);
		outputKeyValue("employeeTechId", employeeTechId, anIndent, aBuilder);
		outputKeyValue("photoAddress", photoAddress, anIndent, aBuilder);
		outputKeyValue("photoMatchCode", photoMatchCode, anIndent, aBuilder);
		outputKeyValue("photoName", photoName, anIndent, aBuilder);
		outputKeyValue("photoOfficeId", photoOfficeId, anIndent, aBuilder);
		outputKeyValue("photoOverrideIndicator", photoOverrideIndicator,
				anIndent, aBuilder);
		outputKeyValue("photoSequenceNumber", photoSequenceNumber, anIndent,
				aBuilder);
		outputKeyValue("photoTakenDate", photoTakenDate, anIndent, aBuilder);
		outputKeyValue("batesMicrographicsNumber", batesMicrographicsNumber,
				anIndent, aBuilder);
		outputKeyValue("queueSelectionMethod", queueSelectionMethod, anIndent,
				aBuilder);
		outputKeyValue("activeDirectoryId", activeDirectoryId, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: PhotoInformation.java,v $
 *  Revision 1.11  2012/02/29 18:37:31  mwhys
 *  Added resetPhotoSequenceNumber(). (Defect 1262)
 *
 *  Revision 1.10  2011/04/07 04:04:52  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.9.10.9  2011/04/05 21:29:10  mwkfh
 *  updated copy method
 *
 *  Revision 1.9.10.8  2011/04/05 19:02:51  mwhys
 *  Updated.
 *
 *  Revision 1.9.10.7  2011/04/05 18:43:38  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.9.10.6  2011/04/04 20:35:06  mwkfh
 *  updated copy
 *
 *  Revision 1.9.10.5  2011/04/04 20:19:47  mwkfh
 *  added exception to copy constructor
 *
 *  Revision 1.9.10.4  2011/04/04 18:59:47  mwkfh
 *  added null check to copy
 *
 *  Revision 1.9.10.3  2011/04/04 18:31:22  mwkfh
 *  updated copy with null check
 *
 *  Revision 1.9.10.2  2011/04/04 18:30:37  mwkfh
 *  added super.copy to copy
 *
 *  Revision 1.9.10.1  2011/04/04 16:43:18  mwkfh
 *  added copy and copy constructor
 *
 *  Revision 1.9  2010/12/26 21:37:17  mwpxr4
 *  Updated type to String.
 *
 *  Revision 1.8  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.7  2010/12/07 03:57:07  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.6  2010/11/13 23:34:44  mwpxr4
 *  Added new fields, these are required to be sent to backend in ELB Tcode.
 *
 *  Revision 1.5  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.6.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.4  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/05/31 14:48:13  mwrsk
 *  Added equals and hashCode test mwlft1
 *
 *  Revision 1.2  2010/05/04 23:39:49  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.4  2010/03/01 21:30:20  mwuxb
 *  Added Bates Micrographics Number
 *
 *  Revision 1.3  2010/02/05 00:58:23  mwpxr4
 *  Added Photo Sequence Number
 *
 *  Revision 1.2  2010/01/30 00:12:03  mwhxa2
 *  Added Photo Office Id and Photo Address
 *
 *  Revision 1.1  2010/01/29 23:02:32  mwhxa2
 *  Initial Commit
 *
*/
