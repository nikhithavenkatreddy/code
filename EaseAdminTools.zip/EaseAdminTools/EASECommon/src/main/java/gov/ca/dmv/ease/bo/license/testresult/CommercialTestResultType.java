/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult;

/**
 * Description: Enumeration to determine commercial Test Result Type
 * 
 * File: CommercialTestResultType.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult
 * Created: Jan 28, 2010 
 * @author MWRSK  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum CommercialTestResultType {
	/** The Air Brakes Test Result. */
	AIR_BRAKES_TEST_RESULT,
	/** The Class A Combination Test Result. */
	CLASSA_COMBINATION_TEST_RESULT,
	/** The Doubles or Triples Test Result. */
	DOUBLES_OR_TRIPLES_TEST_RESULT,
	/** The Fire Fighter Class A Test Result. */
	FIREFIGHTER_CLASSA_TEST_RESULT,
	/** The Fire Fighter Test Result. */
	FIREFIGHTER_TEST_RESULT,
	/** The General Test Result. */
	GENERAL_TEST_RESULT,
	/** The Hazmat Test Result. */
	HAZMAT_TEST_RESULT,
	/** The Passenger Test Result. */
	PASSENGER_TEST_RESULT,
	/** The Performance Test Result. */
	PERFORMANCE_TEST_RESULT,
	/** The PreTrip Test Result. */
	PRETRIP_TEST_RESULT,
	/** The Tank Test Result. */
	TANK_TEST_RESULT,
	/** The Trailer Coach Test Result. */
	TRAILERCOACH_TEST_RESULT
}
/**
 *  Modification History:
 * 
 *  $Log: CommercialTestResultType.java,v $
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/02/04 23:46:14  mwhxa2
 *  Updated Enums to Upper Case
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
*/
