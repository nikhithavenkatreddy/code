/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

import java.util.Date;
import java.util.List;

/**
 * Description: The Service Of Order Application is used to collect the type and date of
 * Service Of Order and license location information.
 * File: ServiceOfOrderApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 6, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class ServiceOfOrderApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2462464193652675684L;
	/** The license is to be held in one of the specified Driver Safety Office. 
	 * (A - Concord, B - Bakersfield ..) */
	private CodeSetElement heldIn;
	/** The license location code. (S - Surrendered, L - Lost) */
	private CodeSetElement licenseLocation;
	/** This represents the current system date or service date. */
	private Date processDate;
	/** The Service Order list for the driver/applicant */
	private List <ServiceOrder> serviceOrders;
	/** License location status code */
	private CodeSetElement locationStatusCode;

	/**
	 * @return the heldIn
	 */
	public CodeSetElement getHeldIn() {
		return heldIn;
	}

	/**
	 * @return the licenseLocation
	 */
	public CodeSetElement getLicenseLocation() {
		return licenseLocation;
	}

	/**
	 * @return the processDate
	 */
	public Date getProcessDate() {
		return processDate;
	}

	/**
	 * @return the serviceOrders
	 */
	public List <ServiceOrder> getServiceOrders() {
		return serviceOrders;
	}

	/**
	 * @param heldIn the heldIn to set
	 */
	public void setHeldIn(CodeSetElement heldIn) {
		this.heldIn = heldIn;
	}

	/**
	 * @param licenseLocation the licenseLocation to set
	 */
	public void setLicenseLocation(CodeSetElement licenseLocation) {
		this.licenseLocation = licenseLocation;
	}

	/**
	 * @param processDate the processDate to set
	 */
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	/**
	 * @param serviceOrders the serviceOrders to set
	 */
	public void setServiceOrders(List <ServiceOrder> serviceOrders) {
		this.serviceOrders = serviceOrders;
	}

	/**
	 * @return The location Status Code
	 */
	public CodeSetElement getLocationStatusCode() {
		return locationStatusCode;
	}

	/**
	 * @param The location Status Code to set
	 */
	public void setLocationStatusCode(CodeSetElement locationStatusCode) {
		this.locationStatusCode = locationStatusCode;
	}

	/**
	 * Get a location status.
	 * 
	 * @return a location status
	 */
	public CodeSetElement getLocationStatus() {
		if (licenseLocation != null) {
			return licenseLocation;
		}
		else {
			return locationStatusCode;
		}
	}
}
