/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl;

import java.util.Date;

/**
 * Description: The purpose of this class is to encapsulate the CDU request information that is part of CDU response.
 * File: CduRequestInfo.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl
 * Created: Mar 23, 2010 
 * @author MWVKM  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/03/13 00:02:41 $
 * Last Changed By: $Author: mwhys $
 */
public class CduRequestInfo {
	/** Requested AKA1 name */
	private String rrAka1Name;
	/** Requested AKA2 name */
	private String rrAka2Name;
	/** Requested AKA3 name */
	private String rrAka3Name;
	/** Requested date of birth */
	private Date rrDateOfBirth;
	/** Requested driver license number */
	private String rrDriverLicenseNumber;
	/** Requested name */
	private String rrName;
	/** Requested out of state jurisdiction */
	private String rrOutOfStateJurisdictionState;
	/** Requested out of state last five digits of driver license number */
	private String rrOutOfStateLastFiveDigitsOfLicense;
	/** Requested out of state license number */
	private String rrOutOfStateLicenseNumber;
	/** Requested second inquiry indicator */
	private String rrSecondInquiryIndicator;
	/** Requested SSN */
	private String rrSocialSecurityNumber;

	/**
	 * Instantiates a new cdu request info.
	 *
	 * @param cduRequestInfo the cdu request info
	 */
	public CduRequestInfo(CduRequestInfo dataToCopy) {
		rrAka1Name = dataToCopy.getRrAka1Name();
		rrAka2Name = dataToCopy.getRrAka2Name();
		rrAka3Name = dataToCopy.getRrAka3Name();
		rrDateOfBirth = dataToCopy.getRrDateOfBirth();
		rrDriverLicenseNumber = dataToCopy.getRrDriverLicenseNumber();
		rrName = dataToCopy.getRrName();
		rrOutOfStateJurisdictionState = dataToCopy
				.getRrOutOfStateJurisdictionState();
		rrOutOfStateLastFiveDigitsOfLicense = dataToCopy
				.getRrOutOfStateLastFiveDigitsOfLicense();
		rrOutOfStateLicenseNumber = dataToCopy.getRrOutOfStateLicenseNumber();
		rrSecondInquiryIndicator = dataToCopy.getRrSecondInquiryIndicator();
		rrSocialSecurityNumber = dataToCopy.getRrSocialSecurityNumber();
	}

	/**
	 * Instantiates a new cdu request info.
	 */
	public CduRequestInfo() {
	}

	/**
	 * Simple getter for rrAka1Name.
	 * 
	 * @return
	 */
	public String getRrAka1Name() {
		return rrAka1Name;
	}

	/**
	 * Simple getter for rrAka2Name.
	 * 
	 * @return
	 */
	public String getRrAka2Name() {
		return rrAka2Name;
	}

	/**
	 * Simple getter for rrAka3Name.
	 * 
	 * @return
	 */
	public String getRrAka3Name() {
		return rrAka3Name;
	}

	/**
	 * Simple getter for rrDateOfBirth.
	 * 
	 * @return
	 */
	public Date getRrDateOfBirth() {
		return rrDateOfBirth;
	}

	/**
	 * Simple getter for rrDriverLicenseNumber.
	 * 
	 * @return
	 */
	public String getRrDriverLicenseNumber() {
		return rrDriverLicenseNumber;
	}

	/**
	 * Simple getter for rrName.
	 * 
	 * @return
	 */
	public String getRrName() {
		return rrName;
	}

	/**
	 * Simple getter for rrOutOfStateJurisdictionState.
	 * 
	 * @return
	 */
	public String getRrOutOfStateJurisdictionState() {
		return rrOutOfStateJurisdictionState;
	}

	/**
	 * Simple getter for rrOutOfStateLastFiveDigitsOfLicense.
	 * 
	 * @return
	 */
	public String getRrOutOfStateLastFiveDigitsOfLicense() {
		return rrOutOfStateLastFiveDigitsOfLicense;
	}

	/**
	 * Simple getter for rrOutOfStateLicenseNumber.
	 * 
	 * @return
	 */
	public String getRrOutOfStateLicenseNumber() {
		return rrOutOfStateLicenseNumber;
	}

	/**
	 * Simple getter for rrSecondInquiryIndicator.
	 * 
	 * @return
	 */
	public String getRrSecondInquiryIndicator() {
		return rrSecondInquiryIndicator;
	}

	/**
	 * Simple getter for rrSocialSecurityNumber.
	 * 
	 * @return
	 */
	public String getRrSocialSecurityNumber() {
		return rrSocialSecurityNumber;
	}

	/**
	 * Simple setter for rrAka1Name.
	 * 
	 * @param rrAka1Name
	 */
	public void setRrAka1Name(String rrAka1Name) {
		this.rrAka1Name = rrAka1Name;
	}

	/**
	 * Simple setter for rrAka2Name.
	 * 
	 * @param rrAka2Name
	 */
	public void setRrAka2Name(String rrAka2Name) {
		this.rrAka2Name = rrAka2Name;
	}

	/**
	 * Simple setter for rrAka3Name.
	 * 
	 * @param rrAka3Name
	 */
	public void setRrAka3Name(String rrAka3Name) {
		this.rrAka3Name = rrAka3Name;
	}

	/**
	 * Simple setter for rrDateOfBirth.
	 * 
	 * @param rrDateOfBirth
	 */
	public void setRrDateOfBirth(Date rrDateOfBirth) {
		this.rrDateOfBirth = rrDateOfBirth;
	}

	/**
	 * Simple setter for rrDriverLicenseNumber.
	 * 
	 * @param rrDriverLicenseNumber
	 */
	public void setRrDriverLicenseNumber(String rrDriverLicenseNumber) {
		this.rrDriverLicenseNumber = rrDriverLicenseNumber;
	}

	/**
	 * Simple setter for rrName.
	 * 
	 * @param rrName
	 */
	public void setRrName(String rrName) {
		this.rrName = rrName;
	}

	/**
	 * Simple setter for rrOutOfStateJurisdictionState.
	 * 
	 * @param rrOutOfStateJurisdictionState
	 */
	public void setRrOutOfStateJurisdictionState(
			String rrOutOfStateJurisdictionState) {
		this.rrOutOfStateJurisdictionState = rrOutOfStateJurisdictionState;
	}

	/**
	 * Simple setter for rrOutOfStateLastFiveDigitsOfLicense.
	 * 
	 * @param rrOutOfStateLastFiveDigitsOfLicense
	 */
	public void setRrOutOfStateLastFiveDigitsOfLicense(
			String rrOutOfStateLastFiveDigitsOfLicense) {
		this.rrOutOfStateLastFiveDigitsOfLicense = rrOutOfStateLastFiveDigitsOfLicense;
	}

	/**
	 * Simple setter for rrOutOfStateLicenseNumber.
	 * 
	 * @param rrOutOfStateLicenseNumber
	 */
	public void setRrOutOfStateLicenseNumber(String rrOutOfStateLicenseNumber) {
		this.rrOutOfStateLicenseNumber = rrOutOfStateLicenseNumber;
	}

	/**
	 * Simple setter for rrSecondInquiryIndicator.
	 * 
	 * @param rrSecondInquiryIndicator
	 */
	public void setRrSecondInquiryIndicator(String rrSecondInquiryIndicator) {
		this.rrSecondInquiryIndicator = rrSecondInquiryIndicator;
	}

	/**
	 * Simple setter for rrSocialSecurityNumber.
	 * 
	 * @param rrSocialSecurityNumber
	 */
	public void setRrSocialSecurityNumber(String rrSocialSecurityNumber) {
		this.rrSocialSecurityNumber = rrSocialSecurityNumber;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CduRequestInfo.java,v $
 *  Revision 1.3  2011/03/13 00:02:41  mwhys
 *  Added copy constructor.
 *
 *  Revision 1.2  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/03/25 19:11:03  mwvkm
 *  Modified the code for CDU as per the match logic document that the development had received.
 *
 */
