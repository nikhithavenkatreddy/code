/**
 * 
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: Defines the LPV code values that indicate that document scanning is required  
 * File: IDocScanConstants.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Jul 27, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.2.16.6 $
 * Last Changed: $Date: 2014/07/31 19:42:08 $
 * Last Changed By: $Author: mwlcr1 $
 */
public interface IDocScanConstants {
	/*
	C - Indian Blood Decree/ North. Mariana/ American Indian 
	G � Certificate of Naturalization
	H � Certificate of Citizenship 
	I - Mexican Passport
	J - Cleared INV Secondary Review
	K � US Citizen Identification Card
	L � Permanent Resident Card, Resident Alien Card, Alien    Registration Receipt Card
	M � Temporary Resident Identification Card
	Q - Nonresident Alien Canadian Border Crossing Card
	R � BD/LP Document did not verify electronically through Verification Information
	S � Record of Arrival or Departure, Permanent Resident Re-Entry Permit, Refugee Travel Document
	V � Employment Authorization Document
	W � �Temporary Evidence of Lawful Admission for Permanent Resident� Stamped on Record of Arrival and Departure
	X � Mexican Border Crossing Card
	Z - AB60 License Type Document(s)	 
	*/
	String INDIAN_BLOOD_DECREE_NORTH_MARIANA_AMERICAN_INDIAN = "C";
	/**2.2.3.5	System shall format and send SCAN T-code message when BD/LP code = �C�, �Z�, �8�, or �2�.  
	 * Also Added new definition for BD/LP code = �C�, Definition change was INDIAN_BLOOD_DECREE_NORTH_MARIANA_AMERICAN_INDIAN_CARD*/
	String CERTIFICATE_OF_CITIZENSHIP = "H";
	String MEXICAN_PASSPORT = "I";
	/**3.1.2.2 Add new definition for BD/LP code = �I�, Definition change was NORTHERN_MARIANA_CARD*/
	String CLEARED_INV_SECONDARY_REVIEW = "J";
	/**2.2.3.18 When new keyed BD/LP code = �J�, system shall display the message: 0013-DATA DOES NOT MATCH VALID CODES. 
	 * Definition change was AMERICAN_INDIAN_CARD*/
	String US_CITIZEN_ID_CARD = "K";
	String RESIDENT_ALIEN_CARD = "L";
	String TEMPORARY_RESIDENT_CARD = "M";
	String CANADIAN_PASSPORT = "O";
	String CANADIAN_BIRTH_CERT = "P";
	String NONRESIDENT_ALIEN_CANADIAN_BORDER_CROSSING_CARD = "Q";
	String NOT_VERIFIED_ELECTRONICALLY = "R";
	String RECORD_OF_ARRIVAL_OR_DEPARTURE_CARD = "S";
	String EMPLOYMENT_AUTHORIZATION_DOCUMENT = "V";
	String TEMPORARY_EVIDENCE_STAMP = "W";
	String MEXICAN_BORDER_CROSSING_CARD = "X";
	String AB60_LICENSE_TYPE_DOCUMENT_S = "Z";
	/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'*/
	String MEXICAN_IFE_VOTER_CARD = "2";
	/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8' OR '2'*/
	String RE_ENTRY_PERMIT = "3";
	String PERMANENT_RESIDENT_CARD = "4";
	String REFUGEE_TRAVEL_DOCUMENT = "5";
	String I688A_EMPLOYMENT_AUTHORIZATION_CARD = "6";
	String I688B_EMPLOYMENT_AUTHORIZATION_CARD = "7";
	String MEXICAN_CONSULAR_CARD_MEXICAN_VOTER_CARD = "8";
	/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'*/
}
/**
 *  Modification History:
 *
 *  $Log: IDocScanConstants.java,v $
 *  Revision 1.2.16.6  2014/07/31 19:42:08  mwlcr1
 *  2.2.3.5	System shall format and send SCAN T-code message when BD/LP code = �C�, �Z�, �8�, or �2�.
 *
 *  Revision 1.2.16.5  2014/07/31 18:10:49  mwlcr1
 *  3.1.2.2 Constants definition change from
 *  I - Northern Mariana Card TO
 *  I - Mexican Passport
 *
 *  3.1.2.2 Constants definition change from And Added to SCAN T-CODE
 *  C - Indian Blood Decree TO
 *  C - Indian Blood Decree/North. Mariana /American Indian
 *
 *  Revision 1.2.16.4  2014/07/16 20:25:43  mwlcr1
 *  **2.2.3.18 - 2.2.3.18 When new keyed BD/LP code = �J�, system shall display the message: 0013-DATA DOES NOT MATCH VALID CODES. definition change
 *
 *  Revision 1.2.16.3  2014/07/15 17:35:45  mwlcr1
 *  /**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8' or '2' - adding number 2
 *
 *  Revision 1.2.16.2  2014/07/07 15:16:14  mwlcr1
 *  Fixed comment error
 *
 *  Revision 1.2.16.1  2014/07/07 15:05:06  mwlcr1
 *  /**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'
 *
 *  Revision 1.2  2012/04/05 19:03:25  mwsec2
 *  removed ttc constants
 *
 *  Revision 1.1  2012/01/30 23:53:46  mwsec2
 *  FODI integration code merged to HEAD
 *
 */
