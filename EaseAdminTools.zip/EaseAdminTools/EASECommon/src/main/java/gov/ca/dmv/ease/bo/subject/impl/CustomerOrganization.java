/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.validate.IValidatable;

/**
 * Description: CustomerOrganization business object represents concrete 
 * organizations like Auto Clubs, Banks, Dealers in DMV business process. 
 * This business object captures the attributes such as customer type, 
 * disposition type and refund type.
 * File: CustomerOrganization.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: Jul 29, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/12/07 22:11:40 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CustomerOrganization extends Organization implements IValidatable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2100832169603360373L;
	/** The customer type code like Driving Schools, Auto Clubs, Banks, Dealers in DMV business process */
	private CodeSetElement customerTypeCode;
	/** This represents Disposition Type (M-Mail, P-Pickup) of a Bundle. */
	private CodeSetElement dispositionType;
	/** The License Number of the Organization relevant to DMV . */
	private String licenseNumber;
	/** This represents Refund Type (H-Headquarters, C-Credit) of a Bundle. */
	private CodeSetElement refundType;

	/** Default Constructor. */
	public CustomerOrganization() {
		super();
		/*		dispositionType = new CodeSetElement();
				refundType = new CodeSetElement();
				//Super class attributes
				setCurrentName(new OrganizationName());
				setLocators(new ArrayList <Locator>());*/
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CustomerOrganization other = (CustomerOrganization) obj;
		if (customerTypeCode == null) {
			if (other.customerTypeCode != null) {
				return false;
			}
		}
		else if (!customerTypeCode.equals(other.customerTypeCode)) {
			return false;
		}
		if (dispositionType == null) {
			if (other.dispositionType != null) {
				return false;
			}
		}
		else if (!dispositionType.equals(other.dispositionType)) {
			return false;
		}
		if (refundType == null) {
			if (other.refundType != null) {
				return false;
			}
		}
		else if (!refundType.equals(other.refundType)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the customer type code.
	 * 
	 * @return the customerTypeCode
	 */
	public CodeSetElement getCustomerTypeCode() {
		return customerTypeCode;
	}

	/**
	 * Gets the disposition type.
	 * 
	 * @return the dispositionType
	 */
	public CodeSetElement getDispositionType() {
		return dispositionType;
	}

	/**
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/**
	 * Gets the refund type.
	 * 
	 * @return the refundType
	 */
	public CodeSetElement getRefundType() {
		return refundType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((customerTypeCode == null) ? 0 : customerTypeCode.hashCode());
		result = prime * result
				+ ((dispositionType == null) ? 0 : dispositionType.hashCode());
		result = prime * result
				+ ((refundType == null) ? 0 : refundType.hashCode());
		return result;
	}

	/**
	 * Sets the customer type code.
	 * 
	 * @param customerTypeCode the customerTypeCode to set
	 */
	public void setCustomerTypeCode(CodeSetElement customerTypeCode) {
		this.customerTypeCode = customerTypeCode;
	}

	/**
	 * Sets the disposition type.
	 * 
	 * @param dispositionType the dispositionType to set
	 */
	public void setDispositionType(CodeSetElement dispositionType) {
		this.dispositionType = dispositionType;
	}

	/**
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	/**
	 * Sets the refund type.
	 * 
	 * @param refundType the refundType to set
	 */
	public void setRefundType(CodeSetElement refundType) {
		this.refundType = refundType;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("customerTypeCode", customerTypeCode, anIndent, aBuilder);
		outputKeyValue("dispositionType", dispositionType, anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("refundType", refundType, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BaseBusinessObject#validate()
	 */
	@Override
	public IErrorCollector validate() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BaseBusinessObject#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CustomerOrganization.java,v $
 *  Revision 1.5  2010/12/07 22:11:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 03:57:52  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.3  2010/09/13 04:40:28  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/04/14 01:19:52  mwvxm6
 *  Added attribute License Number of the Organization
 *
 *  Revision 1.4  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.3  2010/01/28 22:48:46  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.19  2009/10/15 22:16:22  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.18  2009/10/07 01:19:20  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.17  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.16  2009/09/29 02:20:47  mwhxa2
 *  Implements IValidatable
 *
 *  Revision 1.15  2009/09/13 20:45:38  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.14.2.1  2009/09/12 19:08:51  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.14  2009/09/08 17:59:33  mwsmg6
 *  removing CodeSetElement subclasses
 *
 *  Revision 1.13  2009/08/28 01:38:01  mwpxp2
 *  Added fixme
 *
 *  Revision 1.12  2009/08/28 01:28:29  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.11  2009/08/28 00:31:20  mwrrv3
 *  Implements IValidatable interface.
 *
 *  Revision 1.10  2009/08/27 05:39:48  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.8  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.7  2009/08/18 02:00:59  mwrrv3
 *  Added default constructor and initialized the objects.
 *
 *  Revision 1.6  2009/08/06 02:37:23  mwrrv2
 *  Udpated annotations
 *
 *  Revision 1.5  2009/08/05 05:23:52  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.4  2009/07/30 01:48:53  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.3  2009/07/14 23:44:25  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:29:53  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-12 00:55:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 */
