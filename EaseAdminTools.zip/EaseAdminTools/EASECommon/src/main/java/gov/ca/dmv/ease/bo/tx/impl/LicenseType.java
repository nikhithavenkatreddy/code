/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx.impl;

/**
 * Description: Enumeration of License types. Holds the license Type Code. Can be Id, DL or SP
 * 
 * File: LicenseType.java
 * Module:  gov.ca.dmv.ease.bo.tx.impl
 * Created: Feb 9, 2010
 * 
 * @author MWRSK
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/08/31 18:11:47 $
 * Last Changed By: $Author: mwkfh $
 */
public enum LicenseType {
	/** The DRIVER_LICENSE */
	DRIVER_LICENSE(0),
	/** The ID Card. */
	ID_CARD(1),
	/** The SALES_PERSON_LICENSE */
	SALES_PERSON_LICENSE(2);
	//
	/** The value. */
	private int value;

	/**
	 * Instantiates a new transaction status.
	 *
	 * @param value the value
	 */
	private LicenseType(int value) {
		this.value = value;
	}

	/**
	 * Returns the License Type from the int.
	 *
	 * @param value the value
	 */
	public static LicenseType getLicenseType(Integer value) {
		if (value == 0) {
			return DRIVER_LICENSE;
		}
		else if (value == 1) {
			return ID_CARD;
		}
		else if (value == 2) {
			return SALES_PERSON_LICENSE;
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @return status = DRIVER_LICENSE
	 */
	public boolean isDriversLicense() {
		return this == DRIVER_LICENSE;
	}

	/**
	 * @return status = ID_CARD
	 */
	public boolean isIdCard() {
		return this == ID_CARD;
	}

	/**
	 * @return status = SALES_PERSON_LICENSE
	 */
	public boolean isSalesPersonLicense() {
		return this == SALES_PERSON_LICENSE;
	}
}