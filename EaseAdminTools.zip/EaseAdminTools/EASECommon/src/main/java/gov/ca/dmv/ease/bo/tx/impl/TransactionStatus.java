/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx.impl;

/**
 * Description: I define the possible values for the status of the transaction
 * record in the transaction table (39U).
 * File: $ TransactionStatus.java $
 * Module:  gov.ca.dmv.ease.bo.tx.impl
 * Created: Aug 15, 2012
 * @author MWHYS  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/08/31 18:13:13 $
 * Last Changed By: $Author: mwkfh $
 */
public enum TransactionStatus {
	//  ACTIVE   = 1
	ACTIVE(1),
	//  INACTIVE = 0
	INACTIVE(0);
	//
	/** The value. */
	private int value;

	/**
	 * Instantiates a new transaction status.
	 *
	 * @param value the value
	 */
	private TransactionStatus(int value) {
		this.value = value;
	}

	/**
	 * Returns the transaction status from the int.
	 *
	 * @param value the value
	 */
	public static TransactionStatus getTransactionStatus(Integer value) {
		if (value == null) {
			return null;
		}
		if (value == 0) {
			return INACTIVE;
		}
		else {
			return ACTIVE;
		}
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @return status = ACTIVE
	 */
	public boolean isActive() {
		return this == ACTIVE;
	}

	/**
	 * @return status = INACTIVE
	 */
	public boolean isInactive() {
		return this == INACTIVE;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: TransactionStatus.java,v $
 *  Revision 1.3  2012/08/31 18:13:13  mwkfh
 *  changed EnumType to Integer for Trans table
 *
 *  Revision 1.2  2012/08/30 22:26:31  mwkfh
 *  added "is" methods
 *
 *  Revision 1.1  2012/08/16 00:20:49  mwhys
 *  Initial. (Defect 7150)
 *
 */
