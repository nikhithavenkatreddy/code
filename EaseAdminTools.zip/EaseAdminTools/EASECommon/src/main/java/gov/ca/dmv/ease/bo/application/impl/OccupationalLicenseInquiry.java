/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.fw.validate.IValidator;

import java.util.Date;

/**
 * Description: This class captures information required for Occupational License Inquiry
 * The 5 types of inquires available are captured in the corresponding sections  
 * File: OccupationalLicenseInquiry.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2010/09/13 04:40:28 $
 * Last Changed By: $Author: mwhys $
 */
public class OccupationalLicenseInquiry extends BaseBusinessObject {
	private static final long serialVersionUID = -6553058572997104236L;
	private String alphaXrefCity;
	private Date alphaXrefDate;
	private CodeSetElement alphaXrefFileCode;
	// Section 1
	private String alphaXrefFullName;
	// Section 3
	private String firmNumber;
	// Section 2
	private String individualNumber;
	private CodeSetElement makeOrPlateInfoCode;
	// Section 5
	private String makeOrPlateNumber;
	private CodeSetElement numericXrefFileCode;
	// Section 4
	private String numericXrefNumber;
	private CodeSetElement specialFirmBasicRecordCode;
	private CodeSetElement specialFirmCategoryCode;

	/**
	 * @return the alphaXrefCity
	 */
	public String getAlphaXrefCity() {
		return alphaXrefCity;
	}

	/**
	 * @return the alphaXrefDate
	 */
	public Date getAlphaXrefDate() {
		return alphaXrefDate;
	}

	/**
	 * @return the alphaXrefFileCode
	 */
	public CodeSetElement getAlphaXrefFileCode() {
		return alphaXrefFileCode;
	}

	/**
	 * @return the alphaXrefFullName
	 */
	public String getAlphaXrefFullName() {
		return alphaXrefFullName;
	}

	/**
	 * @return the firmNumber
	 */
	public String getFirmNumber() {
		return firmNumber;
	}

	/**
	 * @return the individualNumber
	 */
	public String getIndividualNumber() {
		return individualNumber;
	}

	/**
	 * @return the makeOrPlateInfoCode
	 */
	public CodeSetElement getMakeOrPlateInfoCode() {
		return makeOrPlateInfoCode;
	}

	/**
	 * @return the makeOrPlateNumber
	 */
	public String getMakeOrPlateNumber() {
		return makeOrPlateNumber;
	}

	/**
	 * @return the numericXrefFileCode
	 */
	public CodeSetElement getNumericXrefFileCode() {
		return numericXrefFileCode;
	}

	/**
	 * @return the numericXrefNumber
	 */
	public String getNumericXrefNumber() {
		return numericXrefNumber;
	}

	/**
	 * @return the specialFirmBasicRecordCode
	 */
	public CodeSetElement getSpecialFirmBasicRecordCode() {
		return specialFirmBasicRecordCode;
	}

	/**
	 * @return the specialFirmCategoryCode
	 */
	public CodeSetElement getSpecialFirmCategoryCode() {
		return specialFirmCategoryCode;
	}

	/**
	 * @param alphaXrefCity the alphaXrefCity to set
	 */
	public void setAlphaXrefCity(String alphaXrefCity) {
		this.alphaXrefCity = alphaXrefCity;
	}

	/**
	 * @param alphaXrefDate the alphaXrefDate to set
	 */
	public void setAlphaXrefDate(Date alphaXrefDate) {
		this.alphaXrefDate = alphaXrefDate;
	}

	/**
	 * @param alphaXrefFileCode the alphaXrefFileCode to set
	 */
	public void setAlphaXrefFileCode(CodeSetElement alphaXrefFileCode) {
		this.alphaXrefFileCode = alphaXrefFileCode;
	}

	/**
	 * @param alphaXrefFullName the alphaXrefFullName to set
	 */
	public void setAlphaXrefFullName(String alphaXrefFullName) {
		this.alphaXrefFullName = alphaXrefFullName;
	}

	/**
	 * @param firmNumber the firmNumber to set
	 */
	public void setFirmNumber(String firmNumber) {
		this.firmNumber = firmNumber;
	}

	/**
	 * @param individualNumber the individualNumber to set
	 */
	public void setIndividualNumber(String individualNumber) {
		this.individualNumber = individualNumber;
	}

	/**
	 * @param makeOrPlateInfoCode the makeOrPlateInfoCode to set
	 */
	public void setMakeOrPlateInfoCode(CodeSetElement makeOrPlateInfoCode) {
		this.makeOrPlateInfoCode = makeOrPlateInfoCode;
	}

	/**
	 * @param makeOrPlateNumber the makeOrPlateNumber to set
	 */
	public void setMakeOrPlateNumber(String makeOrPlateNumber) {
		this.makeOrPlateNumber = makeOrPlateNumber;
	}

	/**
	 * @param numericXrefFileCode the numericXrefFileCode to set
	 */
	public void setNumericXrefFileCode(CodeSetElement numericXrefFileCode) {
		this.numericXrefFileCode = numericXrefFileCode;
	}

	/**
	 * @param numericXrefNumber the numericXrefNumber to set
	 */
	public void setNumericXrefNumber(String numericXrefNumber) {
		this.numericXrefNumber = numericXrefNumber;
	}

	/**
	 * @param specialFirmBasicRecordCode the specialFirmBasicRecordCode to set
	 */
	public void setSpecialFirmBasicRecordCode(
			CodeSetElement specialFirmBasicRecordCode) {
		this.specialFirmBasicRecordCode = specialFirmBasicRecordCode;
	}

	/**
	 * @param specialFirmCategoryCode the specialFirmCategoryCode to set
	 */
	public void setSpecialFirmCategoryCode(
			CodeSetElement specialFirmCategoryCode) {
		this.specialFirmCategoryCode = specialFirmCategoryCode;
	}
}

/**
 * Modification History:
 * 
 * $Log: OccupationalLicenseInquiry.java,v $
 * Revision 1.6  2010/09/13 04:40:28  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 *
 */
