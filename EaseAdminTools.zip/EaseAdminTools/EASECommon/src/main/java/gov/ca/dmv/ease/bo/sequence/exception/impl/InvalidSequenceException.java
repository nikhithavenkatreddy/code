/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.exception.impl;

/**
 * Description: Exception to be used when a sequence is invalid wrt its constraints
 * File: InvalidSequenceException.java
 * Module:  gov.ca.dmv.ease.bo.sequence.exception.impl
 * Created: Oct 21, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/10/21 16:53:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InvalidSequenceException extends SequenceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8707431590338604382L;

	/**
	 * Instantiates a new invalid sequence exception.
	 */
	public InvalidSequenceException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public InvalidSequenceException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public InvalidSequenceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public InvalidSequenceException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InvalidSequenceException.java,v $
 *  Revision 1.1  2010/10/21 16:53:17  mwpxp2
 *  Initial
 *
 */
