/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.document.impl.DlApplication;
import gov.ca.dmv.ease.bo.document.impl.SalesPersonApplication;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.tx.ITransaction;
import gov.ca.dmv.ease.bo.tx.ITransactionForTrxService;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Blob;
import java.util.Date;

import org.hibernate.Hibernate;

/**
 * Description: This represents the type of transaction applied to the
 * business process. It has information related to the employee, office,
 * transaction info etc.
 * File: Transaction.java
 * Module:  gov.ca.dmv.ease.bo.tx.impl
 * Created: May 6, 2009
 * @author MWRRV3
 * @version $Revision: 1.23 $
 * Last Changed: $Date: 2012/08/31 18:12:43 $
 * Last Changed By: $Author: mwkfh $
 */
public class Transaction extends BusinessObject implements
		ITransactionForTrxService, ITransaction {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1887925404841018760L;
	/** The Constant SPC. */
	private static final String SPC = "SPC";
	/** The Constant SPD_TTC. */
	private static final String SPD = "SPD";
	/** The Constant SPO_TTC. */
	private static final String SPO = "SPO";
	/** The Constant SPR_TTC. */
	private static final String SPR = "SPR";
	/** The Constant SPX. */
	private static final String SPX = "SPX";
	/** The Constant SPX_TTC. */
	private static final String SRX = "SRX";
	// Holds the license birth date returned
	/** The birth date. */
	private Date birthDate;
	// Holds the license cna status returned
	/** The cna status. */
	private String cnaStatus;
	/** The employee. */
	private String employeeId;
	// Holds the license name returned
	/** The license name. */
	private String licenseName;
	// New..Denoralized attributes for searching Trans/DAF table
	/** The license number. */
	private String licenseNumber;
	// Holds the license Type Code. Can be Id, DL or SP
	/** The license type. */
	private LicenseType licenseType;
	private Integer licenseTypeInt;
	/** The office. */
	private String officeId;
	/** The station. Replaced with Id */
	private String stationId;
	/** The status. (1 = Active, 0 = Inactive) */
	private TransactionStatus status = TransactionStatus.ACTIVE;
	private Integer statusInt = 1;
	/** The transaction data. */
	private Blob transactionData;
	/** The transaction identification number. (aka --> DAF) */
	private Integer transactionIdentifier;
	/** This represents the type transaction description. */
	private String typeTransactionCode;

	/**
	 * Assign blob.
	 *
	 * @param application the application
	 */
	public void assignBlob(Application application) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(
					byteArrayOutputStream);
			objectOutputStream.writeObject(application);
			byte[] bytes = byteArrayOutputStream.toByteArray();
			this.setTransactionData(Hibernate.createBlob(bytes));
		}
		catch (IOException e) {
			throw new EaseException(e);
		}
	}

	/**
	 * Be active.
	 */
	public void beActive() {
		setStatus(TransactionStatus.ACTIVE);
	}

	/**
	 * Be inactive.
	 */
	public void beInactive() {
		setStatus(TransactionStatus.INACTIVE);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (birthDate == null) {
			if (other.birthDate != null)
				return false;
		}
		else if (!birthDate.equals(other.birthDate))
			return false;
		if (cnaStatus == null) {
			if (other.cnaStatus != null)
				return false;
		}
		else if (!cnaStatus.equals(other.cnaStatus))
			return false;
		if (employeeId == null) {
			if (other.employeeId != null)
				return false;
		}
		else if (!employeeId.equals(other.employeeId))
			return false;
		if (licenseName == null) {
			if (other.licenseName != null)
				return false;
		}
		else if (!licenseName.equals(other.licenseName))
			return false;
		if (licenseNumber == null) {
			if (other.licenseNumber != null)
				return false;
		}
		else if (!licenseNumber.equals(other.licenseNumber))
			return false;
		if (licenseType == null) {
			if (other.licenseType != null)
				return false;
		}
		else if (!licenseType.equals(other.licenseType))
			return false;
		if (licenseTypeInt == null) {
			if (other.licenseTypeInt != null)
				return false;
		}
		else if (!licenseTypeInt.equals(other.licenseTypeInt))
			return false;
		if (officeId == null) {
			if (other.officeId != null)
				return false;
		}
		else if (!officeId.equals(other.officeId))
			return false;
		if (stationId == null) {
			if (other.stationId != null)
				return false;
		}
		else if (!stationId.equals(other.stationId))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		}
		else if (!status.equals(other.status))
			return false;
		if (statusInt == null) {
			if (other.statusInt != null)
				return false;
		}
		else if (!statusInt.equals(other.statusInt))
			return false;
		if (transactionIdentifier == null) {
			if (other.transactionIdentifier != null)
				return false;
		}
		else if (!transactionIdentifier.equals(other.transactionIdentifier))
			return false;
		if (typeTransactionCode == null) {
			if (other.typeTransactionCode != null)
				return false;
		}
		else if (!typeTransactionCode.equals(other.typeTransactionCode))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getApplication()
	 */
	public Application getApplication() {
		Application application = null;
		try {
			byte[] bytes = transactionData.getBytes(1, (int) transactionData
					.length());
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
					bytes);
			ObjectInputStream objectInputStream = new ObjectInputStream(
					byteArrayInputStream);
			if (!ArrayUtils.contains(typeTransactionCode, SPC, SPD, SPO, SPR,
					SPX, SRX)) {
				application = (DlApplication) objectInputStream.readObject();
			}
			else {
				application = (SalesPersonApplication) objectInputStream
						.readObject();
			}
			byteArrayInputStream.close();
			return application;
		}
		catch (Exception e) {
			throw new EaseException(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getBirthDate()
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getCnaStatus()
	 */
	public String getCnaStatus() {
		return cnaStatus;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getDlApplication()
	 */
	/**
	 * Gets the dl application.
	 *
	 * @return the dl application
	 */
	public DlApplication getDlApplication() {
		try {
			byte[] bytes = transactionData.getBytes(1, (int) transactionData
					.length());
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
					bytes);
			ObjectInputStream objectInputStream = new ObjectInputStream(
					byteArrayInputStream);
			DlApplication dlApplication = (DlApplication) objectInputStream
					.readObject();
			byteArrayInputStream.close();
			return dlApplication;
		}
		catch (Exception e) {
			throw new EaseException(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getEmployeeId()
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getLicenseName()
	 */
	public String getLicenseName() {
		return licenseName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getLicenseNumber()
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.ITransaction#getLicenseType()
	 */
	public LicenseType getLicenseType() {
		return licenseType;
	}

	/**
	 * @return licenseTypeInt
	 */
	public Integer getLicenseTypeInt() {
		return licenseTypeInt;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getOfficeId()
	 */
	public String getOfficeId() {
		return officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getStationId()
	 */
	public String getStationId() {
		return stationId;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public TransactionStatus getStatus() {
		return status;
	}

	/**
	 * @return the statusInt
	 */
	public Integer getStatusInt() {
		return statusInt;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getTransactionData()
	 */
	public Blob getTransactionData() {
		return transactionData;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getTransactionIdentifier()
	 */
	public Integer getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.impl.ITransaction#getTypeTransactionCode()
	 */
	public String getTypeTransactionCode() {
		return typeTransactionCode;
	}

	/**
	 * Gets the typeTransactionCodeToDisplay.
	 *
	 * @return the typeTransactionCodeToDisplay
	 */
	public String getTypeTransactionCodeToDisplay() {
		if ("DLP".equals(typeTransactionCode)) {
			return "DLA";
		}
		return typeTransactionCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime * result
				+ ((cnaStatus == null) ? 0 : cnaStatus.hashCode());
		result = prime * result
				+ ((employeeId == null) ? 0 : employeeId.hashCode());
		result = prime * result
				+ ((licenseName == null) ? 0 : licenseName.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime * result
				+ ((licenseType == null) ? 0 : licenseType.hashCode());
		result = prime * result
				+ ((licenseTypeInt == null) ? 0 : licenseTypeInt.hashCode());
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((statusInt == null) ? 0 : statusInt.hashCode());
		result = prime
				* result
				+ ((transactionIdentifier == null) ? 0 : transactionIdentifier
						.hashCode());
		result = prime
				* result
				+ ((typeTransactionCode == null) ? 0 : typeTransactionCode
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.tx.ITransaction#isEmpty()
	 */
	public boolean isEmpty() {
		if (EaseUtil.isNullOrBlank(this.getLicenseNumber())) {
			return true;
		}
		if (this.getTransactionData() == null) {
			return true;
		}
		return false;
	}

	/**
	 * Sets the birth date.
	 *
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Sets the cna status.
	 *
	 * @param cnaStatus the cnaStatus to set
	 */
	public void setCnaStatus(String cnaStatus) {
		this.cnaStatus = cnaStatus;
	}

	/**
	 * Sets the employee.
	 *
	 * @param employee the new employee
	 */
	public void setEmployeeId(String employee) {
		this.employeeId = employee;
	}

	/**
	 * Sets the license name.
	 *
	 * @param licenseName the licenseName to set
	 */
	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

	/**
	 * Sets the license number.
	 *
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	/**
	 * Sets the license type.
	 *
	 * @param licenseType the licenseType to set
	 */
	public void setLicenseType(LicenseType licenseType) {
		this.licenseType = licenseType;
		if (licenseType == null) {
			this.licenseTypeInt = null;
		}
		else {
			this.licenseTypeInt = licenseType.getValue();
		}
	}

	/**
	 * @param licenseTypeInt the licenseTypeInt to set
	 */
	public void setLicenseTypeInt(Integer statusInt) {
		if (statusInt == null) {
			this.licenseType = null;
			this.licenseTypeInt = null;
		}
		else {
			this.licenseType = LicenseType.getLicenseType(statusInt);
			this.licenseTypeInt = this.licenseType.getValue();
		}
	}

	/**
	 * Sets the office.
	 *
	 * @param office the office to set
	 */
	public void setOfficeId(String office) {
		this.officeId = office;
	}

	/**
	 * Sets the station.
	 *
	 * @param station the new station
	 */
	public void setStationId(String station) {
		this.stationId = station;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(TransactionStatus status) {
		this.status = status;
		if (status == null) {
			this.statusInt = null;
		}
		else {
			this.statusInt = status.getValue();
		}
	}

	/**
	 * @param statusInt the statusInt to set
	 */
	public void setStatusInt(Integer statusInt) {
		if (statusInt == null) {
			this.status = null;
			this.statusInt = null;
		}
		else {
			this.status = TransactionStatus.getTransactionStatus(statusInt);
			this.statusInt = this.status.getValue();
		}
	}

	/**
	 * Sets the transaction data.
	 *
	 * @param transactionData the new transaction data
	 */
	public void setTransactionData(Blob transactionData) {
		this.transactionData = transactionData;
	}

	/**
	 * Sets the sequence number.
	 *
	 * @param transactionIdentifier the new transactionIdentifier
	 */
	public void setTransactionIdentifier(Integer transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}

	/**
	 * Sets the type transaction code.
	 *
	 * @param typeTransactionCode the new type transaction code
	 */
	public void setTypeTransactionCode(String typeTransactionCode) {
		this.typeTransactionCode = typeTransactionCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("transactionIdentifier", transactionIdentifier,
				anIndent, aBuilder);
		outputKeyValue("typeTransactionCode", typeTransactionCode, anIndent,
				aBuilder);
		outputKeyValue("employeeId", employeeId, anIndent, aBuilder);
		outputKeyValue("officeId", officeId, anIndent, aBuilder);
		outputKeyValue("stationId", stationId, anIndent, aBuilder);
		outputKeyValue("status", status.toString(), anIndent, aBuilder);
		outputKeyValue("birthDate", birthDate, anIndent, aBuilder);
		outputKeyValue("cnaStatus", cnaStatus, anIndent, aBuilder);
		outputKeyValue("licenseName", licenseName, anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("licenseType", licenseType.toString(), anIndent,
				aBuilder);
		outputKeyValue("transactionData", transactionData, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: Transaction.java,v $
 *  Revision 1.23  2012/08/31 18:12:43  mwkfh
 *  changed EnumType to Integer for Trans table
 *
 *  Revision 1.22  2012/08/16 00:21:31  mwhys
 *  Added field "status". (Defect 7150)
 *
 *  Revision 1.21  2011/06/10 23:13:33  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.20  2011/01/23 06:29:11  mwpxp2
 *  Cleanup
 *
 *  Revision 1.19  2011/01/22 18:30:12  mwyxg1
 *  add getTypeTransactionCodeToDisplay
 *
 *  Revision 1.18  2011/01/06 23:51:03  mwtjc1
 *  removed a check for this==null from isEmpty method
 *
 *  Revision 1.17  2011/01/05 22:29:20  mwtjc1
 *  javadoc for isEmpty updated
 *
 *  Revision 1.16  2011/01/05 22:24:34  mwtjc1
 *  isEmpty modified
 *
 *  Revision 1.15  2011/01/05 22:23:09  mwtjc1
 *  isEmpty added
 *
 *  Revision 1.14  2010/12/23 06:18:21  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.12.8.1  2010/12/23 03:13:55  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.13  2010/12/22 17:41:21  mwyxg1
 *  add assignBlob
 *
 *  Revision 1.12  2010/12/07 22:12:17  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.11  2010/12/07 03:57:31  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.10  2010/08/27 17:34:47  mwyxg1
 *  add getApplication
 *
 *  Revision 1.9  2010/08/18 17:36:09  mwyxg1
 *  reverse back the change
 *
 *  Revision 1.8  2010/08/18 17:25:51  mwyxg1
 *  Add fix for class cast exception
 *
 *  Revision 1.7  2010/07/22 17:50:26  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.6  2010/07/13 23:05:35  mwvxm6
 *  Updated hashcode method
 *
 *  Revision 1.5  2010/06/29 23:30:45  mwcsj3
 *  Deleted  getTypeTransactionCode method
 *
 *  Revision 1.4  2010/06/29 23:24:07  mwcsj3
 *  Changed typeTransactionCode mapping from code set to string
 *
 *  Revision 1.3  2010/06/22 23:31:06  mwvxm6
 *  Updated the attribute LicenseType per the new column DL_ID_SP_TYP_CD
 *
 *  Revision 1.2  2010/05/15 01:45:22  mwcsj3
 *  Added variable licenseTypeCodeSetElement with get and set methods
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.21  2010/04/07 17:51:58  mwvxm6
 *  Changed the type of attribute birthDate to Date
 *
 *  Revision 1.20  2010/04/02 01:24:28  mwvxm6
 *  Moved ControlCashierSeqNumber to userContext from transaction
 *
 *  Revision 1.19  2010/03/29 17:10:59  mwhxa2
 *  Changed setLicenseTypeCode() to setLicenseType()
 *
 *  Revision 1.18  2010/03/29 17:09:17  mwhxa2
 *  Changing LicenseTypeCode to LicenseType
 *
 *  Revision 1.17  2010/03/26 18:25:05  mwvxm6
 *  Updated bytestream close
 *
 *  Revision 1.16  2010/03/26 18:17:22  mwrsk
 *  Added ITransaction interface
 *
 *  Revision 1.15  2010/03/26 17:56:57  mwrsk
 *  add getApplication()
 *
 *  Revision 1.14  2010/03/26 17:36:48  mwrsk
 *  Make transaction work
 *
 *  Revision 1.13  2010/03/23 19:23:07  mwvxm6
 *  Station Replaced with stationId
 *
 *  Revision 1.12  2010/03/23 00:02:03  mwvxm6
 *  Changed Office to office_id
 *
 *  Revision 1.11  2010/03/16 20:32:11  mwvxm6
 *  Updated sequence number name to transaction identification number
 *
 *  Revision 1.10  2010/03/16 17:00:14  mwvxm6
 *  Updated sequence number name to transaction identification number
 *
 *  Revision 1.9  2010/03/09 19:38:50  mwvxm6
 *  Removed processDate, workDate, modeSettingCode, transactionNumber, Application attributed and added searchable fields to Transaction.
 *
 *  Revision 1.8  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.7  2010/02/17 02:36:39  mwuxb
 *  Added TODOs
 *
 *  Revision 1.6  2010/02/17 00:14:24  mwuxb
 *  Updated draft model
 *
 *  Revision 1.5  2010/01/30 01:14:36  mwrsk
 *  implements ITransactionForTrxService
 *
 *  Revision 1.4  2010/01/30 01:09:24  mwrsk
 *  Added new attributes
 *
 *  Revision 1.3  2010/01/28 22:38:42  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/05 03:01:42  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.22  2009/10/15 22:15:29  mwvxm6
 *  Updated annotation as per the modified DB2 schema which now has a join table for Inventory and Transaction
 *
 *  Revision 1.21  2009/10/11 16:41:22  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.20  2009/10/08 01:34:13  mwvxm6
 *  Deleted Obsolete classes TransactionCode, TypeTransactionCode from the gov.ca.dmv.ease.bo.dcs.code.impl package and replaced with CodeSetElement
 *
 *  Revision 1.19  2009/10/07 01:19:21  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.18  2009/10/03 21:06:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.17  2009/09/01 00:44:58  mwrsk
 *  Update annotation for transactionDetails
 *
 *  Revision 1.16  2009/09/01 00:11:54  mwrsk
 *  Update annotation for transactionDetails
 *
 *  Revision 1.15  2009/08/31 22:50:54  mwrsk
 *  Changed annotations & comment out trans_data (BLOB) for now
 *
 *  Revision 1.14  2009/08/27 05:39:57  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.12  2009/08/20 02:43:36  mwrrv3
 *  Added TypeTransactionCode object instead of String.
 *
 *  Revision 1.11  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.10  2009/08/13 16:33:01  mwrsk
 *  Remove camera and cashier data instance variables
 *
 *  Revision 1.9  2009/08/13 16:31:15  mwrsk
 *  Moved interface to a new package
 *
 *  Revision 1.8  2009/08/13 15:05:17  mwrsk
 *  Now implements ITransactionForTrxService interface
 *
 *  Revision 1.7  2009/08/13 02:03:19  mwrsk
 *  updated annotations
 *
 *  Revision 1.6  2009/08/13 00:35:43  mwrsk
 *  initialize TransactionTransformation list
 *
 *  Revision 1.5  2009/08/05 05:52:51  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.4  2009/07/28 01:57:34  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.3  2009/07/14 23:44:39  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:29:53  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-12 07:56:42  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:25  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
