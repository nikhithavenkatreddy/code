/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.impl;

import gov.ca.dmv.ease.bo.sequence.ISequenceElem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am default implementation of ISequenceElem
 * File: SequenceElem.java
 * Module:  gov.ca.dmv.ease.bo.sequence.impl
 * Created: Sep 8, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.17 $
 * Last Changed: $Date: 2012/08/15 16:23:51 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class SequenceElem implements ISequenceElem {
	/** The DEFAUL t_ char. */
	private static final char DEFAULT_CHAR = '#';
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory.getLog(SequenceElem.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 884811826089866241L;

	/**
	 * As int value.
	 * 
	 * @param aChar
	 *            the a char
	 * 
	 * @return the int
	 */
	protected static int asIntValue(char aChar) {
		return aChar;
	}

	/**
	 * Gets the char for int value.
	 * 
	 * @param aIntVal
	 *            the a int val
	 * 
	 * @return the char for int value
	 */
	protected static char getCharForIntValue(int aIntVal) {
		return (char) aIntVal;
	}

	/**
	 * Checks if is default.
	 * 
	 * @param aChar
	 *            the a char
	 * 
	 * @return true, if is default
	 */
	public static boolean isDefault(char aChar) {
		return aChar == DEFAULT_CHAR;
	}

	/** The char value. */
	private char charValue = DEFAULT_CHAR;
	/** The max char. */
	private char maxChar = DEFAULT_CHAR;
	/** The min char. */
	private char minChar = DEFAULT_CHAR;
	/** The pattern char. */
	private char patternChar = DEFAULT_CHAR;
	/** The went over. */
	private boolean wentOver = false;
	/** The went under. */
	private boolean wentUnder = false;

	/**
	 * Instantiates a new sequence elem.
	 */
	protected SequenceElem() {
		super();
	}

	/**
	 * Instantiates a new sequence elem.
	 * 
	 * @param aValueChar
	 *            the a value char
	 * @param aPatternChar
	 *            the a pattern char
	 */
	public SequenceElem(char aValueChar, char aPatternChar) {
		super();
		setCharValue(aValueChar);
		setPatternChar(aPatternChar);
	}

	/**
	 * Instantiates a new sequence elem.
	 * 
	 * @param aValueChar
	 *            the a value char
	 * @param aPatternChar
	 *            the a pattern char
	 * @param isOver
	 *            the is over
	 * @param isUnder
	 *            the is under
	 */
	public SequenceElem(char aValueChar, char aPatternChar, boolean isOver,
			boolean isUnder) {
		super();
		setCharValue(aValueChar);
		setPatternChar(aPatternChar);
		if (isOver) {
			setWentOver(isOver);
		}
		else if (isUnder) {
			setWentUnder(isUnder);
		}
	}

	/**
	 * Instantiates a new sequence elem.
	 * 
	 * @param aValueChar
	 *            the a value char
	 * @param aPatternChar
	 *            the a pattern char
	 * @param aMinChar
	 *            the a min char
	 * @param aMaxChar
	 *            the a max char
	 */
	public SequenceElem(char aValueChar, char aPatternChar, char aMinChar,
			char aMaxChar) {
		super();
		setCharValue(aValueChar);
		setPatternChar(aPatternChar);
		adjustAndSetMinChar(aMinChar);
		adjustAndSetMaxChar(aMaxChar);
	}

	/**
	 * Instantiates a new sequence elem.
	 * 
	 * @param anElem
	 *            the an elem
	 */
	public SequenceElem(ISequenceElem anElem) {
		super();
		setCharValue(anElem.getCharValue());
		setPatternChar(anElem.getPatternChar());
		setMaxChar(anElem.getMaxChar());
		setMinChar(anElem.getMinChar());
	}

	/**
	 * Adjust and set max char.
	 * 
	 * @param aMaxChar
	 *            the a max char
	 */
	protected void adjustAndSetMaxChar(char aMaxChar) {
		if (Character.isDigit(aMaxChar)) {
			if (aMaxChar < MAX_DIGIT) {
				setMaxChar(aMaxChar);
			}
			else {
				setMaxChar(DEFAULT_CHAR);
			}
			return;
		}
		if (Character.isLetter(aMaxChar)) {
			if (aMaxChar < MAX_ALPHA) {
				setMaxChar(aMaxChar);
			}
			else {
				setMaxChar(DEFAULT_CHAR);
			}
			return;
		}
		setMaxChar(aMaxChar);
	}

	/**
	 * Adjust and set min char.
	 * 
	 * @param aMinChar
	 *            the a min char
	 */
	protected void adjustAndSetMinChar(char aMinChar) {
		if (Character.isDigit(aMinChar)) {
			if (aMinChar > MIN_DIGIT && aMinChar < MAX_DIGIT) {
				setMinChar(aMinChar);
			}
			else {
				setMinChar(DEFAULT_CHAR);
			}
			return;
		}
		if (Character.isLetter(aMinChar)) {
			if (aMinChar > MIN_ALPHA && aMinChar < MAX_ALPHA) {
				setMinChar(aMinChar);
			}
			else {
				setMinChar(DEFAULT_CHAR);
			}
			return;
		}
		setMinChar(aMinChar);
	}

	/**
	 * Are min max equal.
	 * 
	 * @return true, if successful
	 */
	protected boolean areMinMaxEqual() {
		if (isDefault(maxChar) || isDefault(minChar)) {
			return false;
		}
		else {
			return getMaxChar() == getMinChar();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#asIntValue()
	 */
	public int asIntValue() {
		return asIntValue(getCharValue());
	}

	/**
	 * Did go over.
	 * 
	 * @return the wentOver
	 */
	protected boolean didGoOver() {
		return wentOver;
	}

	/**
	 * Did got under.
	 * 
	 * @return the wentUnder
	 */
	protected boolean didGotUnder() {
		return wentUnder;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SequenceElem)) {
			return false;
		}
		SequenceElem other = (SequenceElem) obj;
		if (charValue != other.charValue) {
			return false;
		}
		if (maxChar != other.maxChar) {
			return false;
		}
		if (minChar != other.minChar) {
			return false;
		}
		if (patternChar != other.patternChar) {
			return false;
		}
		if (wentOver != other.wentOver) {
			return false;
		}
		if (wentUnder != other.wentUnder) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the max char.
	 * 
	 * @return the maxChar
	 */
	public char getAbsoluteMaxChar() {
		if (isPatternCharAlpha()) {
			return MAX_ALPHA;
		}
		if (isPatternCharDigit()) {
			return MAX_DIGIT;
		}
		return getMaxChar();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#asCharValue()
	 */
	public char getCharValue() {
		return charValue;
	}

	/**
	 * Gets the max char.
	 * 
	 * @return the maxChar
	 */
	public char getMaxChar() {
		if (isDefault(maxChar)) {
			if (isPatternCharAlpha()) {
				return MAX_ALPHA;
			}
			if (isPatternCharDigit()) {
				return MAX_DIGIT;
			}
		}
		return maxChar;
	}

	/**
	 * Gets the max char int value.
	 * 
	 * @return the max char int value
	 */
	protected int getMaxCharIntValue() {
		return asIntValue(getMaxChar());
	}

	/**
	 * Gets the min char.
	 * 
	 * @return the minChar
	 */
	public char getMinChar() {
		if (isDefault(minChar)) {
			if (isPatternCharAlpha()) {
				return MIN_ALPHA;
			}
			if (isPatternCharDigit()) {
				return MIN_DIGIT;
			}
			return minChar;
		}
		else {
			return minChar;
		}
	}

	/**
	 * Gets the min char int value.
	 * 
	 * @return the min char int value
	 */
	protected int getMinCharIntValue() {
		return asIntValue(getMinChar());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#getNext()
	 */
	public ISequenceElem getNext() {
		LOGGER.debug("getNext() - start");
		if (isFixed()) {
			ISequenceElem returnSequenceElem = new SequenceElem(
					getCharValue(), getPatternChar(), isOver(), isUnder());
			LOGGER.debug("getNext() - end");
			return returnSequenceElem;
		}
		boolean isOver = false;
		char nowChar = getCharValue();
		int aVal = asIntValue(nowChar);
		int aNextVal = aVal + 1;
		if (aNextVal > getMaxCharIntValue()) {
			if (maxChar != getMinChar()) {
				aNextVal = getMinCharIntValue();
				isOver = true;
			}
		}
		char newChar = getCharForIntValue(aNextVal);
		ISequenceElem returnSequenceElem = new SequenceElem(newChar,
				getPatternChar(), isOver, false);
		//System.out.println("this: " + this + " next: " + returnISequenceElem);
		LOGGER.debug("this: " + this + " next: " + returnSequenceElem);
		LOGGER.debug("getNext() - end");
		return returnSequenceElem;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#getPatternChar()
	 */
	public char getPatternChar() {
		return patternChar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#getPrevious()
	 */
	public ISequenceElem getPrevious() {
		if (isFixed()) {
			return new SequenceElem(getCharValue(), getPatternChar(), isOver(),
					isUnder());
		}
		boolean isUnder = false;
		int aVal = asIntValue(getCharValue());
		int aNextVal = aVal - 1;
		if (aNextVal < getMinCharIntValue()) {
			aNextVal = getMaxCharIntValue();
			isUnder = true;
		}
		char newChar = getCharForIntValue(aNextVal);
		return new SequenceElem(newChar, getPatternChar(), false, isUnder);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + charValue;
		result = prime * result + maxChar;
		result = prime * result + minChar;
		result = prime * result + patternChar;
		result = prime * result + (wentOver ? 1231 : 1237);
		result = prime * result + (wentUnder ? 1231 : 1237);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#isFixed()
	 */
	public boolean isFixed() {
		return isFixed(getPatternChar());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#isFixed(char)
	 */
	public static boolean isFixed(char patternChar) {
		return patternChar == FIXED_DIGIT || patternChar == SPACE_FILLER;
	}

	/**
	 * Checks if is max default.
	 * 
	 * @return true, if is max default
	 */
	protected boolean isMaxDefault() {
		return isDefault(getMaxChar());
	}

	/**
	 * Checks if is min default.
	 * 
	 * @return true, if is min default
	 */
	protected boolean isMinDefault() {
		return isDefault(getMinChar());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#isOver()
	 */
	public boolean isOver() {
		return didGoOver();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#isOverOrUnder()
	 */
	public boolean isOverOrUnder() {
		return didGoOver() || didGotUnder();
	}

	/**
	 * Checks if is pattern char alpha.
	 * 
	 * @return true, if is pattern char alpha
	 */
	private boolean isPatternCharAlpha() {
		return getPatternChar() == ALPHA;
	}

	/**
	 * Checks if is pattern char digit.
	 * 
	 * @return true, if is pattern char digit
	 */
	private boolean isPatternCharDigit() {
		return getPatternChar() == INCREMENTING_DIGIT
				|| getPatternChar() == INCREMENTING_DIGIT_WITH_LEADING_SPACE
				|| getPatternChar() == FIXED_DIGIT;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElem#isUnder()
	 */
	public boolean isUnder() {
		return didGotUnder();
	}

	/**
	 * Sets the char value.
	 * 
	 * @param aVal
	 *            the a val
	 */
	protected void setCharValue(char aVal) {
		charValue = aVal;
	}

	/**
	 * Sets the max char.
	 * 
	 * @param aVal
	 *            the a val
	 */
	public void setMaxChar(char aVal) {
		maxChar = aVal;
	}

	/**
	 * Sets the min char.
	 * 
	 * @param aVal
	 *            the a val
	 */
	public void setMinChar(char aVal) {
		minChar = aVal;
	}

	/**
	 * Sets the pattern char.
	 * 
	 * @param aVal
	 *            the a val
	 */
	protected void setPatternChar(char aVal) {
		patternChar = aVal;
	}

	/**
	 * Sets the went over.
	 * 
	 * @param aFlag
	 *            the a flag
	 */
	protected void setWentOver(boolean aFlag) {
		wentOver = aFlag;
	}

	/**
	 * Sets the went under.
	 * 
	 * @param aFlag
	 *            the a flag
	 */
	protected void setWentUnder(boolean aFlag) {
		wentUnder = aFlag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(16);
		aBuilder.append(getCharValue()).append(" {");
		aBuilder.append(getPatternChar()).append(" [");
		aBuilder.append(getMinChar()).append(" ");
		aBuilder.append(getMaxChar()).append("]");
		if (isOver()) {
			aBuilder.append('+');
		}
		if (isUnder()) {
			aBuilder.append('-');
		}
		aBuilder.append(" }");
		return aBuilder.toString();
	}
}
/**
 * Modification History:
 * 
 * $Log: SequenceElem.java,v $
 * Revision 1.17  2012/08/15 16:23:51  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.16  2012/08/14 20:46:32  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.15  2011/03/23 23:51:41  mwyxk
 * Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 * Revision 1.14  2010/11/03 17:27:17  mwkfh
 * updated adjustAndSetMinChar
 *
 * Revision 1.13  2010/10/25 17:06:14  mwkfh
 * added static isFixed(char)
 *
 * Revision 1.12  2010/10/11 18:30:54  mwpxp2
 * system out commented out
 *
 * Revision 1.11  2010/10/09 00:10:04  mwpxp2
 * Made setting max and min chars public; added getAbsoluteMaxChar/0
 *
 * Revision 1.10  2010/10/08 20:18:13  mwpxp2
 * Added debug
 *
 * Revision 1.9  2010/10/08 19:05:37  mwbxg3
 * fixed getting next element on boundary
 * Revision 1.8 2010/10/06 00:35:12 mwpxp2 Added
 * protected default testing methods
 * 
 * Revision 1.7 2010/09/30 18:50:15 mwpxp2 Moved to obsolete package
 * 
 * Revision 1.6 2010/09/30 07:45:47 mwpxp2 Fixed isFixed/0
 * 
 * Revision 1.5 2010/09/11 00:09:02 mwpxp2 Added adjustments of boundary
 * conditions
 * 
 * Revision 1.4 2010/09/10 00:46:24 mwpxp2 Added 4-arg constructor
 * 
 * Revision 1.3 2010/09/09 00:46:46 mwpxp2 Added copy constructor
 * 
 * Revision 1.2 2010/09/08 23:41:21 mwpxp2 Unit tests fixes; checks ok
 * 
 * Revision 1.1 2010/09/08 21:32:45 mwpxp2 Initial, untested
 * 
 */
