/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryStateRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am abstract class for requests dealing with the state of the inventory as such, 
 * rather than specific items; e.g., regarding the low point thresholds
 * 
 * File: AbstractInventoryStateRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/20 23:18:53 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractInventoryStateRequest extends
		AbstractInventoryRequest implements IInventoryStateRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7722540583928962012L;
	/** The thresholds. */
	private List <IItemThreshold> thresholds;

	/**
	 * Instantiates a new abstract inventory state request.
	 */
	protected AbstractInventoryStateRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected AbstractInventoryStateRequest(IUserContext context) {
		super(context);
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	public AbstractInventoryStateRequest(IUserContext context,
			List <IItemThreshold> aThresholdList) {
		super(context);
		setThresholdsFrom(aThresholdList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.IInventoryRequest#execute()
	 */
	public abstract IInventoryStatusRequestResponse execute();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (thresholds == null) {
			return 0;
		}
		else {
			return thresholds.size();
		}
	}

	/**
	 * @return the thresholds
	 */
	public List <IItemThreshold> getThresholds() {
		if (thresholds == null) {
			setThresholds(new ArrayList <IItemThreshold>());
		}
		return thresholds;
	}

	/**
	 * @param thresholds the thresholds to set
	 */
	protected void setThresholds(List <IItemThreshold> aList) {
		thresholds = aList;
	}

	/**
	 * Sets the thresholds from.
	 * 
	 * @param aList the new thresholds from
	 */
	protected void setThresholdsFrom(List <IItemThreshold> aList) {
		getThresholds().addAll(aList);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractInventoryStateRequest.java,v $
 *  Revision 1.2  2010/09/20 23:18:53  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.2  2010/09/20 18:32:17  mwpxp2
 *  Speeling fix
 *
 *  Revision 1.1  2010/09/20 17:58:19  mwpxp2
 *  Initial
 *
 */
