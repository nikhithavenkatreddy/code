/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request for adding inventory assignment items to a station
 * File: AddStationInventoryAssignmentRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Jul 11, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/07/12 00:11:16 $
 * Last Changed By: $Author: mwkfh $
 */
public class AddStationInventoryAssignmentRequest extends
		AbstractMultipleItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6520820990503957790L;

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param items the items
	 */
	public AddStationInventoryAssignmentRequest(IUserContext context,
			IInventoryItem... items) {
		super(context, items);
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param listOfItems the list of items
	 */
	public AddStationInventoryAssignmentRequest(IUserContext context,
			List <IInventoryItem> listOfItems) {
		super(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AddStationInventoryAssignmentRequest.java,v $
 *  Revision 1.1  2011/07/12 00:11:16  mwkfh
 *  added AddStationInventoryAssignmentRequest
 *
 */
