/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.exception.impl;

/**
 * Description: I am to be used when no sequence is available given constraints
 * File: NoSequenceAvailableException.java
 * Module:  gov.ca.dmv.ease.bo.sequence.exception.impl
 * Created: Sep 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/30 17:44:52 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class NoSequenceAvailableException extends SequenceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4460577236621639639L;

	/**
	 * Instantiates a new no sequence available exception.
	 */
	public NoSequenceAvailableException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public NoSequenceAvailableException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public NoSequenceAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public NoSequenceAvailableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: NoSequenceAvailableException.java,v $
 *  Revision 1.1  2010/09/30 17:44:52  mwpxp2
 *  Initial
 *
 */
