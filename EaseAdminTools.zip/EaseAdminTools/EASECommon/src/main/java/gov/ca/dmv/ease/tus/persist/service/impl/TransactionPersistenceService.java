/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service.impl;

import gov.ca.dmv.ease.bo.document.impl.DlApplication;
import gov.ca.dmv.ease.bo.document.impl.SalesPersonApplication;
import gov.ca.dmv.ease.bo.license.impl.SalesPersonLicense;
import gov.ca.dmv.ease.bo.subject.impl.VehicleSalesPerson;
import gov.ca.dmv.ease.bo.tx.ITransactionForTrxService;
import gov.ca.dmv.ease.bo.tx.impl.LicenseType;
import gov.ca.dmv.ease.bo.tx.impl.Transaction;
import gov.ca.dmv.ease.bo.tx.impl.TransactionStatus;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.impl.AssignDafNumberRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.AuthorizeWorkDateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.AssignDafNumberResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.AuthorizeWorkDateResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.UpdateDafRecordPersistenceResponse;
import gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 * Description: I provide methods that used to assign daf record.
 * File: TransactionPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service.impl
 * Created: Dec 17, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.38 $
 * Last Changed: $Date: 2013/09/03 18:06:09 $
 * Last Changed By: $Author: mwsec2 $
 */
public class TransactionPersistenceService extends PersistenceService implements
		ITransactionPersistenceService {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(TransactionPersistenceService.class);
	/** The Constant TRANSACTION_ID_MAX. */
	private static final Integer TRANSACTION_ID_MAX = 999;
	/** The Constant DAILY_APP_FILE_FULL. */
	private static final String DAILY_APP_FILE_FULL = "0508";

	/**
	 * This method is used to insert the Transaction Data(BLOB) for existing daf record. 
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest)
	 */
	@SuppressWarnings("unchecked")
	public UpdateDafRecordPersistenceResponse execute(
			UpdateDafRecordPersistenceRequest request) {
		try {
			getSessionFactory().getCurrentSession().beginTransaction();
			//Get the DB entry to update.
			//Order the results by create date, to ensure we update the record that was reserved
			//for the current transaction (and not the old one with the same DAF#)
			Criteria criteria = getSessionFactory().getCurrentSession()
					.createCriteria(Transaction.class).add(
							Restrictions.eq("officeId", request
									.getUserContext().getOfficeId())).add(
							Restrictions.eq("transactionIdentifier", request
									.getAllocatedDafNumber())).addOrder(
							Order.desc("createdDate"));
			List <Transaction> transactions = criteria.list();
			if (transactions != null && transactions.size() > 0
					&& transactions.get(0) != null) {
				Transaction transactionObjectToBeModified = (Transaction) transactions
						.get(0);
				transactionObjectToBeModified.assignBlob(request
						.getApplication());
				getSessionFactory().getCurrentSession().update(
						transactionObjectToBeModified);
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
				return new UpdateDafRecordPersistenceResponse(
						transactionObjectToBeModified);
			}
			getSessionFactory().getCurrentSession().getTransaction().commit();
			return new UpdateDafRecordPersistenceResponse();
		}
		catch (HibernateException ex) {
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			getSessionFactory().getCurrentSession().getTransaction().rollback();
			ErrorCollector errorCollector = new ErrorCollector();
			errorCollector.register(ex);
			return new UpdateDafRecordPersistenceResponse(errorCollector);
		}
	}

	/**
	 * Assign and create empty daf.
	 *
	 * @param request the request
	 * @return the assign daf number response
	 */
	@SuppressWarnings("unchecked")
	private AssignDafNumberResponse assignAndCreateEmptyDaf(
			AssignDafNumberRequest request) {
		try {
			Transaction transaction = null;
			int transactionIdentifier = 1;
			getSessionFactory().getCurrentSession().beginTransaction();
			//Get all active DAF transactions (data != null or (status=active && today))
			//SQL Query:
			//select this_.TRANS_ID from VTDM039U_TRANS this_
			//where this_.OFFICE_ID=? and 
			//(this_.STATUS = active and this_.CREATE_TSTAMP >= today) or
			//this_.TRANS_DATA is not null 
			Criteria criteria = getSessionFactory()
					.getCurrentSession()
					.createCriteria(Transaction.class)
					.add(
							Restrictions.eq("officeId", request
									.getUserContext().getOfficeId()))
					.add(
							Restrictions
									.or(
											Restrictions
													.isNotNull("transactionData"),
											Restrictions
													.and(
															Restrictions
																	.eq(
																			"statusInt",
																			TransactionStatus.ACTIVE
																					.getValue()),
															Restrictions
																	.ge(
																			"createdDate",
																			getTodaysDateWithNoTime()))))
					.setProjection(
							Projections.projectionList().add(
									Projections
											.property("transactionIdentifier")));
			List <Integer> activeTransactionIds = criteria.list();
			if (!EaseUtil.isNullOrBlank(activeTransactionIds)) {
				//If the number of active transactions is 999, then display error message
				//0508 - DAILY APP FILE FULL
				if (TRANSACTION_ID_MAX.equals(activeTransactionIds.size())) {
					IErrorCollector errorCollector = new ErrorCollector();
					errorCollector.register(new EaseValidationException(
							DAILY_APP_FILE_FULL));
					return new AssignDafNumberResponse(errorCollector);
				}
			}
			//Else obtain an unused DAF number
			//Get the latest created DAF number
			//SQL Query:
			//select this_.TRANS_ID from VTDM039U_TRANS this_
			//where this_.OFFICE_ID=?
			//order by this_.CREATE_TSTAMP desc;
			criteria = getSessionFactory()
					.getCurrentSession()
					.createCriteria(Transaction.class)
					.add(
							Restrictions.eq("officeId", request
									.getUserContext().getOfficeId()))
					.addOrder(Order.desc("createdDate"))
					.setProjection(
							Projections.projectionList().add(
									Projections
											.property("transactionIdentifier")));
			List <Integer> existingTransactionIdsSorted = criteria.list();
			if (!EaseUtil.isNullOrBlank(existingTransactionIdsSorted)) {
				int latestDafNumber = existingTransactionIdsSorted.get(0);
				if (EaseUtil.isNullOrBlank(activeTransactionIds)) {
					latestDafNumber = incrementDafNumber(latestDafNumber);
					transactionIdentifier = latestDafNumber;
				}
				else {
					//Iterate a max of 999 times
					int tryNumber = TRANSACTION_ID_MAX;
					while (tryNumber != 0) {
						latestDafNumber = incrementDafNumber(latestDafNumber);
						//Check the incremented DAF number in the active list
						if (!activeTransactionIds.contains(latestDafNumber)) {
							transactionIdentifier = latestDafNumber;
							break;
						}
						tryNumber--;
					}
				}
			}
			transaction = getTransactionObject(request, transactionIdentifier);
			getSessionFactory().getCurrentSession().save(transaction); //Reserve a DAF record (save empty BLOB)
			getSessionFactory().getCurrentSession().getTransaction().commit();
			return new AssignDafNumberResponse(transactionIdentifier);
		}
		catch (HibernateException e) {
			LOGGER.error(ExceptionUtils.getStackTrace(e));
			getSessionFactory().getCurrentSession().getTransaction().rollback();
			return new AssignDafNumberResponse(e);
		}
	}

	/**
	 * Increment daf number.
	 *
	 * @param latestDafNumber the latest daf number
	 * @return the int
	 */
	private int incrementDafNumber(int latestDafNumber) {
		if (latestDafNumber == TRANSACTION_ID_MAX) {
			latestDafNumber = 1;
		}
		else {
			latestDafNumber++;
		}
		return latestDafNumber;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.AssignDafNumberRequest)
	 */
	public AssignDafNumberResponse execute(AssignDafNumberRequest request) {
		//This method gets max daf number for the office to allocate the incremented daf number to the transaction.
		//It also inserts a daf record without transaction data(BLOB).
		LOGGER.info("execute(AssignDafNumberRequest request=" + request
				+ ") - start");
		AssignDafNumberResponse assignDafNumberResponse = null;
		for (int i = 0; i < 4; i++) {// try to create Daf record 4 times.
			LOGGER.info("retrying " + i);
			assignDafNumberResponse = assignAndCreateEmptyDaf(request);
			if (assignDafNumberResponse != null
					&& !assignDafNumberResponse.hasErrors()) {
				break;
			}
		}
		return assignDafNumberResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest)
	 */
	/*
	 * This method is used to insert the Transaction Data(BLOB) for existing daf record. 
	 */
	@SuppressWarnings("unchecked")
	public AuthorizeWorkDateResponse execute(AuthorizeWorkDateRequest request) {
		List <Date> authorizedWorkDateList = new ArrayList <Date>();
		try {
			getSessionFactory().getCurrentSession().beginTransaction();
			/**
			SELECT * FROM MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL ewdc
			LEFT JOIN MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL owdc ON owdc.SYS_ID = ewdc.OFFICE_WRK_DT_CNTRL_SYSID
			LEFT JOIN MWKDB2MV.VSSM028U_OFFICE o ON owdc.OFFICE_SYSID = o.SYS_ID
			LEFT JOIN MWKDB2MV.VSSM026U_EMPLOYEE_A e ON e.SYS_ID = ewdc.EMPLOYEE_SYSID
			WHERE o.OFFICE_ID = '791'
			AND e.TECH_ID = 'AD'
			AND ewdc.AUTHD_WRK_DT_STATUS = 'A' AND owdc.AUTHD_WRK_DT_STATUS = 'A'
			--AND owdc.AUTHD_WRK_DT = '2011-10-20-00.00.00.000000'
			ORDER BY ewdc.CREATE_TSTAMP DESC
			FETCH FIRST 1 ROWS ONLY;
			 */
			//Select Query to get the authorized dates for a given Office Id and Technician Id
			StringBuilder query = new StringBuilder(
					"SELECT ewdc.AUTHD_WRK_DT_STATUS AS EMP_WD_STATUS, owdc.AUTHD_WRK_DT AS WRK_DT, owdc.AUTHD_WRK_DT_STATUS AS OFC_WD_STATUS FROM VTDM027U_EMP_WRK_DT_CNTRL ewdc ");
			query
					.append(" LEFT JOIN VTDM028U_OFFICE_WRK_DT_CNTRL owdc ON owdc.SYS_ID = ewdc.OFFICE_WRK_DT_CNTRL_SYSID ");
			query
					.append(" LEFT JOIN VSSM028U_OFFICE o ON owdc.OFFICE_SYSID = o.SYS_ID ");
			query
					.append(" LEFT JOIN VSSM026U_EMPLOYEE_A e ON e.SYS_ID = ewdc.EMPLOYEE_SYSID ");
			query.append(" WHERE e.TECH_ID = :tech_id");
			query.append(" AND o.OFFICE_ID = :office_id");
			//WHO FOR functionality has work date to validate, so add it to the query.
			//Sample Date Format 2011-10-20-00.00.00.000000
			SimpleDateFormat sdf = new SimpleDateFormat(
					"yyyy-MM-dd-HH.mm.ss.SSSSSS");
			if (request.isWorkDate()
					&& !EaseUtil.isNullOrBlank(request.getUserContext()
							.getWorkDate())) {
				query.append(" AND owdc.AUTHD_WRK_DT = :auth_wrk_dt");
			}
			else {
				query
						.append(" ORDER BY ewdc.CREATE_TSTAMP DESC FETCH FIRST 1 ROWS ONLY");
			}
			SQLQuery sqlQuery = getSessionFactory().getCurrentSession()
					.createSQLQuery(query.toString());
			LOGGER.debug(query.toString());
			sqlQuery.setParameter("tech_id", request.getUserContext()
					.getTechId());
			LOGGER.debug("tech_id='" + request.getUserContext().getTechId()
					+ "'");
			sqlQuery.setParameter("office_id", request.getUserContext()
					.getOfficeId());
			LOGGER.debug("office_id='" + request.getUserContext().getOfficeId()
					+ "'");
			if (request.isWorkDate()
					&& !EaseUtil.isNullOrBlank(request.getUserContext()
							.getWorkDate())) {
				sqlQuery.setParameter("auth_wrk_dt", sdf.format(request
						.getUserContext().getWorkDate()));
				LOGGER.debug("auth_wrk_dt='"
						+ sdf.format(request.getUserContext().getWorkDate())
						+ "'");
			}
			List <Object[]> results = sqlQuery.list();
			//If the results are not empty
			if (!EaseUtil.isNullOrBlank(results)) {
				char active = 'A'; //A - ACTIVE Status
				for (Object[] data : results) {
					Character empWrkDateStatus = (Character) data[0];
					Character officeWrkDateStatus = (Character) data[2];
					//If the status is false (no need to check the active status) or 
					//Employee Work Date Status is active and Office Woke Date Status 
					//is active then add the dates to the list.
					if (!request.isStatus()
							|| (empWrkDateStatus != null
									&& empWrkDateStatus.equals(active)
									&& officeWrkDateStatus != null && officeWrkDateStatus
									.equals(active))) {
						Timestamp authTimestamp = (Timestamp) data[1];
						authorizedWorkDateList.add(new Date(authTimestamp
								.getTime()));
					}
				}
			}
			getSessionFactory().getCurrentSession().getTransaction().commit();
		}
		catch (HibernateException ex) {
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			getSessionFactory().getCurrentSession().getTransaction().rollback();
			ErrorCollector errorCollector = new ErrorCollector();
			errorCollector.register(ex);
			return new AuthorizeWorkDateResponse(errorCollector);
		}
		return new AuthorizeWorkDateResponse(authorizedWorkDateList);
	}

	/**
	 * Gets the todays date with no time.
	 *
	 * @return the todays date with no time
	 */
	public Date getTodaysDateWithNoTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	/**
	 * This method gets the transaction domain object from the request.
	 *
	 * @param request the request
	 * @param transactionIdentifier the transaction identifier
	 * @return Null if the transaction request class does not have else the transaction domain object
	 */
	private Transaction getTransactionObject(AssignDafNumberRequest request,
			int transactionIdentifier) {
		Transaction transaction = new Transaction();
		transaction.setTransactionIdentifier(transactionIdentifier);
		IUserContext userContext = request.getUserContext();
		transaction.setOfficeId(userContext.getOfficeId());
		transaction.setEmployeeId(userContext.getTechId());
		transaction.setCnaStatus("N");
		String ttc = request.getUserContext().getTtc();
		transaction.setTypeTransactionCode(ttc);
		if (ArrayUtils.contains(ttc, "SPC", "SPD", "SPO", "SPR", "SRX")) {
			SalesPersonApplication salesPersonApplication = (SalesPersonApplication) request
					.getApplication();
			VehicleSalesPerson applicant = salesPersonApplication
					.getApplicant();
			SalesPersonLicense salesPersonLicense = applicant
					.getSalesPersonLicense();
			transaction
					.setLicenseName(applicant.getCurrentName().getFullName());
			transaction.setLicenseNumber(salesPersonLicense.getLicenseNumber());
			transaction.setLicenseType(LicenseType.SALES_PERSON_LICENSE);
			transaction.setBirthDate(applicant.getBirthDate());
			//transaction.assignBlob(salesPersonApplication);
		}
		else if (ArrayUtils.contains(ttc, "IDA", "IDC", "IDS", "IDP", "IRT")) {
			DlApplication dlApplication = (DlApplication) request
					.getApplication();
			transaction.setLicenseName(dlApplication.getApplicant()
					.getCurrentName().getFullName());
			if (EaseUtil.isNotNull(dlApplication.getApplicant().getIdCard())
					&& EaseUtil.isNotNull(dlApplication.getApplicant()
							.getIdCard().getIdNumber())) {
				transaction.setLicenseNumber(dlApplication.getApplicant()
						.getIdCard().getIdNumber());
			}
			else if (EaseUtil.isNotNull(dlApplication.getApplicant()
					.getDriverLicense())
					&& EaseUtil.isNotNull(dlApplication.getApplicant()
							.getDriverLicense().getLicenseNumber())) {
				transaction.setLicenseNumber(dlApplication.getApplicant()
						.getDriverLicense().getLicenseNumber());
			}
			transaction.setLicenseType(LicenseType.ID_CARD);
			transaction.setBirthDate(dlApplication.getApplicant()
					.getBirthDate());
			transaction.setTypeTransactionCode(ttc);
			//transaction.assignBlob(dlApplication);
		}
		else {
			DlApplication dlApplication = (DlApplication) request
					.getApplication();
			transaction.setLicenseName(dlApplication.getApplicant()
					.getCurrentName().getFullName());
			//if (dlApplication.getApplicant().getDriverLicense() != null && !EaseUtil.isNullOrBlank(dlApplication.getApplicant().getDriverLicense().getLicenseNumber()) ) {
			transaction.setLicenseNumber(dlApplication.getApplicant()
					.getDriverLicense().getLicenseNumber());
			//} else if (dlApplication.getApplicant().getIdCard() != null && !EaseUtil.isNullOrBlank(dlApplication.getApplicant().getIdCard().getLicenseNumber()) ) {
			//transaction.setLicenseNumber(dlApplication.getApplicant()
			//	.getIdCard().getLicenseNumber());
			//}
			transaction.setLicenseType(LicenseType.DRIVER_LICENSE);
			transaction.setBirthDate(dlApplication.getApplicant()
					.getBirthDate());
			//transaction.assignBlob(dlApplication);
		}
		transaction.setTransactionData(null);// setting null transaction data (BLOB)
		validateDlTransaction(transaction);
		return (transaction);
	}

	/**
	 * Validate dla transaction.
	 * 
	 * @param aTransaction the a transaction
	 */
	private void validateDlTransaction(ITransactionForTrxService aTransaction) {
		if ((aTransaction.getOfficeId() == null)
				|| (aTransaction.getTransactionIdentifier() == null)
				|| (aTransaction.getEmployeeId() == null)) {
			throw new EaseException("Validation error in transaction");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransactionPersistenceService.java,v $
 *  Revision 1.38  2013/09/03 18:06:09  mwsec2
 *  replaced printStackTrace with log statement
 *
 *  Revision 1.37  2012/11/08 18:25:52  mwkfh
 *  added single quotes
 *
 *  Revision 1.36  2012/11/08 17:29:04  mwkfh
 *  Added LOGGING to execute(AuthorizeWorkDateRequest)
 *
 *  Revision 1.35  2012/08/31 18:10:59  mwkfh
 *  changed EnumType to Integer for Trans table
 *
 *  Revision 1.34  2012/08/23 20:45:12  mwhys
 *  Undo revert and refactored updateDAF method to order the results by create tstamp. (ITM_TEST Defect 7150)
 *
 *  Revision 1.33  2012/08/17 17:34:59  mwhys
 *  Temporarily reverted to version 1.31 (until the status column is added to table 39U)
 *
 *  Revision 1.32  2012/08/16 00:22:48  mwhys
 *  Updated assignAndCreateEmptyDaf() to use the new "status" of transactions. (Defect 7150)
 *
 *  Revision 1.31  2012/08/02 23:11:05  mwkfh
 *  changed table name to VSSM026U_EMPLOYEE_A
 *
 *  Revision 1.30  2012/08/02 20:16:39  mwhys
 *  Updated assignAndCreateEmptyDaf() with entirely new logic to mimic DMVA's behavior of
 *  assigning DAF numbers. (ITM_TEST Defect 7150)
 *
 *  Revision 1.29  2012/06/18 18:17:53  mwhys
 *  Updated assignAndCreateEmptyDaf() to register error code 0508 - DAILY APP FILE FULL
 *  when the number of daf records reach the 999 limit. (ITM_TEST Defect 7150)
 *
 *  Revision 1.28  2011/12/11 19:11:53  mwkkc
 *  Performance Clean up
 *
 *  Revision 1.27  2011/11/15 18:28:44  mwrrv3
 *  Reverted to previous version, removed status flag from the query.
 *
 *  Revision 1.26  2011/11/10 01:46:44  mwrrv3
 *  Updated the query to add status fields for the authorize work set.
 *
 *  Revision 1.25  2011/10/28 00:18:18  mwrrv3
 *  Updated the SQL query for setting the alias names for conflict columns, defect#: 6910 & 6911.
 *
 *  Revision 1.24  2011/10/20 22:35:21  mwrrv3
 *  Updated for performance improvement for authorize work date.
 *
 *  Revision 1.23  2011/06/24 00:20:02  mwkkc
 *  Without Synchronized and looking into retry
 *
 *  Revision 1.22  2011/06/22 22:01:43  mwyxg1
 *  make sure Daf record is update properly by multiple users
 *
 *  Revision 1.21  2011/06/10 23:13:33  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.20  2011/04/08 23:33:50  mwtjc1
 *  assignAndCreateEmptyDaf is added to retry creating empty DAF record 3 more times.
 *
 *  Revision 1.19  2011/03/23 23:51:41  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.18  2011/01/15 19:09:17  mwtjc1
 *  comments updated
 *
 *  Revision 1.17  2011/01/15 19:06:56  mwtjc1
 *  comments updated
 *
 *  Revision 1.16  2011/01/15 18:52:01  mwtjc1
 *  AssignDafNumberResponse execute(AssignDafNumberRequest request) is changed to return daf number instead of Transaction object(Daf Record)
 *
 *  Revision 1.12  2011/01/14 17:38:18  mwtjc1
 *  execute(AssignDafNumberRequest request) updated
 *
 *  Revision 1.11  2011/01/14 17:37:56  mwtjc1
 *  execute(UpdateDafRecordPersistenceRequest request) added
 *
 *  Revision 1.10  2011/01/11 22:03:28  mwtjc1
 *  code in 'AssignDafNumberResponse execute' is corrected to avoid null pointer exception
 *
 *  Revision 1.9  2011/01/05 01:39:54  mwtjc1
 *  comment updated
 *
 *  Revision 1.8  2011/01/05 01:38:30  mwtjc1
 *  criteria query to retrieve the max daf number if modified to improve the performance
 *
 *  Revision 1.7  2011/01/05 01:33:39  mwtjc1
 *  criteria query to retrieve the max daf number if modified to improve the performance
 *
 *  Revision 1.6  2010/12/30 21:19:27  mwyxg1
 *  fix daf number problem
 *
 *  Revision 1.5  2010/12/24 22:34:34  mwtjc1
 *  ttc name is corrected from SPX to SRX
 *
 *  Revision 1.4  2010/12/22 23:06:34  mwyxg1
 *  use assignDafNumber service
 *
 *  Revision 1.3  2010/12/21 16:52:06  mwyxg1
 *  find trans id and increase by 1
 *
 *  Revision 1.2  2010/12/17 23:44:44  mwyxg1
 *  add transaction
 *
 *  Revision 1.1  2010/12/17 23:19:40  mwyxg1
 *  add new
 *
 */
