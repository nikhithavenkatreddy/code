/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.InterimPermitType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: Represents an Interim Permit that is issued for particular license class
 * File: InterimPermit.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Feb 18, 2010
 * @author MWRSK
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/04/07 04:04:51 $
 * Last Changed By: $Author: mwhys $
 */
public class InterimPermit implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6109729248840574611L;
	
	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}
	
	/** The permit expiration date. */
	private Date permitExpirationDate;
	/** The permit issue date. */
	private Date permitIssueDate;
	/** The permit license class code. */
	private CodeSetElement permitLicenseClassCode;
	/** The permit type. */
	private InterimPermitType permitType;
	
	/**
	 * @param permitType the permitType to set
	 */
	public void setPermitType(InterimPermitType permitType) {
		this.permitType = permitType;
	}
	
	/**
	 * Instantiates a new interim permit.
	 *
	 * @param permitLicenseClassCode the permit license class code
	 * @param permitType the permit type
	 */
	public InterimPermit(CodeSetElement permitLicenseClassCode,
			InterimPermitType permitType) {
		this.permitType = permitType;
		this.permitLicenseClassCode = permitLicenseClassCode;
	}
	
	/**
	 * Instantiates a new interim permit.
	 *
	 * @param permitLicenseClassCode the permit license class code
	 * @param permitType the permit type
	 * @param permitExpirationDate the permit expiration date
	 */
	public InterimPermit(CodeSetElement permitLicenseClassCode,
			InterimPermitType permitType, Date permitExpirationDate) {
		this.permitLicenseClassCode = permitLicenseClassCode;
		this.permitType = permitType;
		this.permitExpirationDate = permitExpirationDate;
	}
	
	/**
	 * Instantiates a new interim permit.
	 *
	 * @param objectToCopy the object to copy
	 */
	public InterimPermit(InterimPermit objectToCopy) {
		super();
		copy(objectToCopy);
	}
	
	/**
	 * Copies the data from the dataToCopy to a new object.
	 *
	 * @param objectToCopy the object to copy
	 */
	protected void copy(InterimPermit objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null InterimPermit argument expected in copy constructor in "
							+ this);
		}
		if (isNotNull(objectToCopy.getPermitExpirationDate())) {
			setPermitExpirationDate(new Date(objectToCopy
					.getPermitExpirationDate().getTime()));
		}
		else {
			setPermitExpirationDate(null);
		}
		if (isNotNull(objectToCopy.getPermitIssueDate())) {
			setPermitIssueDate(new Date(objectToCopy.getPermitIssueDate()
					.getTime()));
		}
		else {
			setPermitIssueDate(null);
		}
		if (isNotNull(objectToCopy.getPermitLicenseClassCode())) {
			setPermitLicenseClassCode(new CodeSetElement(objectToCopy
					.getPermitLicenseClassCode()));
		}
		else {
			setPermitLicenseClassCode(null);
		}
		if (isNotNull(objectToCopy.getPermitType())) {
			setPermitType(objectToCopy.getPermitType());
		}
		else {
			setPermitType(null);
		}
	}
	
	/**
	 * Gets the permit expiration date.
	 * 
	 * @return the permit expiration date
	 */
	public Date getPermitExpirationDate() {
		return permitExpirationDate;
	}
	
	/**
	 * Gets the permit issue date.
	 * 
	 * @return the permit issue date
	 */
	public Date getPermitIssueDate() {
		return permitIssueDate;
	}
	
	/**
	 * Gets the permit license class code.
	 * 
	 * @return the permit license class code
	 */
	public CodeSetElement getPermitLicenseClassCode() {
		return permitLicenseClassCode;
	}
	
	/**
	 * Gets the permit type.
	 * 
	 * @return the permit type
	 */
	public InterimPermitType getPermitType() {
		return permitType;
	}
	
	/**
	 * Sets the permit expiration date.
	 * 
	 * @param permitExpirationDate the new permit expiration date
	 */
	public void setPermitExpirationDate(Date permitExpirationDate) {
		this.permitExpirationDate = permitExpirationDate;
	}
	
	/**
	 * Sets the permit issue date.
	 * 
	 * @param permitIssueDate the new permit issue date
	 */
	public void setPermitIssueDate(Date permitIssueDate) {
		this.permitIssueDate = permitIssueDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(512);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}
	
	/**
	 * To string on.
	 *
	 * @param aBuilder the a builder
	 * @param anIndent the an indent
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("permitExpirationDate", permitExpirationDate, anIndent,
				aBuilder);
		outputKeyValue("permitIssueDate", permitIssueDate, anIndent, aBuilder);
		outputKeyValue("permitLicenseClassCode", permitLicenseClassCode,
				anIndent, aBuilder);
		outputKeyValue("permitType", permitType, anIndent, aBuilder);
	}
	
	/**
	 * Sets the permit license class code.
	 *
	 * @param permitLicenseClassCode the new permit license class code
	 */
	public void setPermitLicenseClassCode(CodeSetElement permitLicenseClassCode) {
		this.permitLicenseClassCode = permitLicenseClassCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((permitExpirationDate == null) ? 0 : permitExpirationDate
						.hashCode());
		result = prime * result
				+ ((permitIssueDate == null) ? 0 : permitIssueDate.hashCode());
		result = prime
				* result
				+ ((permitLicenseClassCode == null) ? 0
						: permitLicenseClassCode.hashCode());
		result = prime * result
				+ ((permitType == null) ? 0 : permitType.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InterimPermit other = (InterimPermit) obj;
		if (permitExpirationDate == null) {
			if (other.permitExpirationDate != null)
				return false;
		}
		else if (!permitExpirationDate.equals(other.permitExpirationDate))
			return false;
		if (permitIssueDate == null) {
			if (other.permitIssueDate != null)
				return false;
		}
		else if (!permitIssueDate.equals(other.permitIssueDate))
			return false;
		if (permitLicenseClassCode == null) {
			if (other.permitLicenseClassCode != null)
				return false;
		}
		else if (!permitLicenseClassCode.equals(other.permitLicenseClassCode))
			return false;
		if (permitType == null) {
			if (other.permitType != null)
				return false;
		}
		else if (!permitType.equals(other.permitType))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: InterimPermit.java,v $
 *  Revision 1.6  2011/04/07 04:04:51  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.5.18.6  2011/04/05 18:54:10  mwark
 *  Added null check for the interim permit type in the copy constructor.
 *
 *  Revision 1.5.18.5  2011/04/05 18:11:57  mwark
 *  Moved validation to copy method from the constructor code.
 *
 *  Revision 1.5.18.4  2011/04/05 17:08:06  mwhys
 *  Updated copy method.
 *
 *  Revision 1.5.18.3  2011/04/04 20:51:33  mwark
 *  Modified to follow the guidelines.
 *
 *  Revision 1.5.18.2  2011/04/04 18:12:37  mwark
 *  Modified to follow the guidelines.
 *
 *  Revision 1.5.18.1  2011/04/04 00:13:56  mwark
 *  Added getters and setters and also hashCOde and equals methods.
 *
 *  Revision 1.5  2010/12/07 22:08:54  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 03:56:23  mwpxp2
 *  Added toStringOn/1, toString/0; sorted
 *
 *  Revision 1.3  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.8.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/07 16:53:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/15 23:00:12  mwhxa2
 *  Implements serializable
 *
 *  Revision 1.1  2010/02/19 03:10:35  mwrsk
 *  Added InterimPermit changes
 *
*/
