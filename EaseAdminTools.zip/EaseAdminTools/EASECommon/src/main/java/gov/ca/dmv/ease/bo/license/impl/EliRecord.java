/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.ArrayUtils.contains;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.LegalPresenceDocument;
import gov.ca.dmv.ease.bo.financial.impl.InvoiceItem;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: Eli Record represents the response for search person by number inquiry.
 * File: EliRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Aug 11, 2009
 * 
 * @author MWRRV3
* @version $Revision: 1.48 $
 * Last Changed: $Date: 2012/11/01 21:49:47 $
 * Last Changed By: $Author: mwgxd3 $
 */
public class EliRecord extends DlRecord {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5985571096754258981L;
	/** The Constant SubRecordA. */
	private static final String SUB_RECORD_A = "A";
	/** The Constant SubRecordA2. */
	private static final String SUB_RECORD_A2 = "A2";
	/** The Constant SubRecordB. */
	private static final String SUB_RECORD_B = "B";
	/** The CDLIS notification date. */
	private Date cdlisNotificationDate;
	/** The CDLIS notification type. N=ADD; C=CHANGE STATE OF RECORD */
	private CodeSetElement cdlisNotificationType;
	/** The CDLIS transfer type. I=INTO CALIFORNIA; O=OUT OF CALIFORNIA */
	private CodeSetElement cdlisTransferType;
	/** The Disqualified For CDL. Action Message - DISQUALIF FOR COMM’L. */
	private CodeSetElement disqualifiedForCdl;
	/** The DL Card Request In Process. Action Message - DL CARD IN PROCESS. */
	private CodeSetElement dlCardRequestInProcess;
	/** The DL expiration date of previous record. Contains only Year in YY format. */
	private String dlExpirationDateOfPreviousRecord;
	/** The Driver Education Code. */
	private CodeSetElement driverEducationCode;
	/** The Driver Training Code. */
	private CodeSetElement driverTrainingCode;
	/** The echoed driver license. */
	private DriverLicense echoedDriverLicense;
	/** The echoed id card. */
	private IdCard echoedIdCard;
	/** The Eligible For Early CDS Renewal. Action Message - EARLY CDL RENEWAL. */
	private CodeSetElement eligibleForEarlyCdlRenewal;
	/** The Employee Authorization ID of previous record. */
	private String employeeAuthorizationIdOfPreviousRecord;
	/** The existing License Classes of previous record. */
	private List <CodeSetElement> existingLicenseClassesOfPreviousRecord;
	/** The Reason Code for Fee Required Value. */
	private CodeSetElement feeRequiredReasonCode;
	/** The FR Suspension Due Date. */
	private Date frSuspensionDueDate;
	/** The 10 Year History Record Check. */
	private CodeSetElement historyRecord10YearCheck;
	/** The ID Card Request In Process. Action Message - ID CARD IN PROCESS. */
	private CodeSetElement idCardRequestInProcess;
	/** The Invoice Item. Holds the previous Fee information. DLA activity will move this invoiceItem into a list of invoiceItems of Invoice class. */
	protected InvoiceItem invoiceItem;
	/** LEGAL PRESENCE PHASE 3 INDICATOR (SPACE OR Y) - Represents CDLIS/NDR Response available. */
	private Boolean isCdlisNdrResponseAvailable;
	/** The Credit Card Payment Indicator. */
	private Boolean isCreditCardPaymentIndicator;
	/** The ASVI Check Bypass Indicator. ASVI - Alien Status Verification Index is same as Legal Presence Inquiry. */
	private Boolean isLegalPresenceCheckBypassIndicator;
	/** The Indicator for Organ Donor. */
	private Boolean isOrganDonor;
	/** The Indicator for Original Application. */
	private Boolean isOriginalApplicationIndicator;
	/** The Military Duty Code. */
	private CodeSetElement militaryDutyCode;
	/** The MotorCycle Training Code. */
	private CodeSetElement motorCycleTrainingCode;
	/** DLA Activity shall copy values from the following fields to the appropriate fields in the DlApplication class. */
	/** The Current Application Reason Code. */
	private CodeSetElement newIncompleteApplicationReasonCode;
	/** The Non Commercial Drive Retest Fee. */
	private CodeSetElement nonCommercialDriveRetestFee;
	/** The Cashier Id of the original transaction. */
	private String originalApplicationCashierId;
	/** The Cashier Sequence Number of the original transaction. */
	private String originalApplicationCashierSequenceNumber;
	/** DLA activity shall copy following fields to ProcessHistory. */
	/** The Application Date or Process Date represents the date on which original application was filed.*/
	private Date originalApplicationDate;
	/** The Office Id of the original transaction. */
	private String originalApplicationOfficeId;
	/** The Type Transaction Code of the original transaction. */
	private String originalApplicationTtc;
	/** The Work Date of the original transaction. */
	private Date originalApplicationWorkDate;
	/** The Driver Education/Training waiver code. R/P code (R - Permits DE/DT to be waived). */
	private CodeSetElement outOfStateDriverEducationAndTrainingWaiveCode;
	/** The NDR/CDL O/S withdrawal action. Action Message - O/S W/DRAWAL ACTION. */
	private CodeSetElement outOfStateWithdrawalActionCode;
	/** The pending dl application user verified ssn code. */
	private CodeSetElement pendingDlApplicationUserVerifiedSsnCode;
	/** The pending id application user verified ssn code. */
	private CodeSetElement pendingIdApplicationUserVerifiedSsnCode;
	/** The Photo Taken Type. */
	private CodeSetElement photoTakenType;
	/** Segment E. */
	/** These field are used to determine the Action Message to be displayed on the DL Inquiry Response screen. */
	/** The Photo Type On File. */
	private CodeSetElement photoTypeOnFile;
	/** The Previous Photo Indicator. */
	private CodeSetElement previousPhotoIndicator;
	/** List of Segments. For E.g. segment C - Record Status Segment. segment E - Information Segment. */
	private List <CodeSetElement> segments = new ArrayList <CodeSetElement>();
	/* Do not copy following fields to DlApplication. Assumption - 
	 Following fields are not required in CDA and will not be part of object graph. */
	/** The transaction code. This represents TCode values for e.g: DLI, DLA etc. */
	private CodeSetElement transactionCode;
	/** The User Verified BD/LP code. This code denotes the type of BD or LP document that was captured by the user for the DL app /** Sample Codes: A-American Birth Cert etc.. */
	private CodeSetElement userVerifiedBdlpCode;
	/** The Valid SSN Required. */
	private CodeSetElement validSsnRequired;
	/** Segment C. */
	/** These field are used to determine the Action Message to be displayed on the DL Inquiry Response screen. *
	/** The Withheld Pending PDPS Clearance. Action Message - W/HELD PEND PDPS CLR. */
	private CodeSetElement withheldPendingPdpsClearance;
	/** The written Drive Test Indicator. */
	private CodeSetElement writtenDriveTestIndicator;
	/** The class of record. */
	private String classOfRecord;
	/** The photoRequired, derived from photoTakenType and photoTypeOnFile. */
	private CodeSetElement photoRequired;
	/** The previous photo required, derived from photoTakenType and photoTypeOnFile. */
	private CodeSetElement previousPhotoRequired;
	/** IID Installation Indicator. */
	private String iidInstallationIndicator;
	/**
	 * Instantiates a new eli record.
	 */
	public EliRecord() {
		super();
	}
	
	/**
	 * Instantiates a new eli record.
	 *
	 * @param eliRecord the eli record
	 */
	public EliRecord(EliRecord eliRecord) {
		super();
		copy(eliRecord);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(EliRecord dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null eliRecord argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		//Copy cdlisNotificationDate
		if (isNotNull(dataToCopy.getCdlisNotificationDate())) {
			setCdlisNotificationDate(new Date(dataToCopy
					.getCdlisNotificationDate().getTime()));
		}
		else {
			setCdlisNotificationDate(null);
		}
		//Copy cdlisNotificationType
		if (isNotNull(dataToCopy.getCdlisNotificationType())) {
			setCdlisNotificationType(new CodeSetElement(dataToCopy
					.getCdlisNotificationType()));
		}
		else {
			setCdlisNotificationType(null);
		}
		//Copy cdlisTransferType
		if (isNotNull(dataToCopy.getCdlisTransferType())) {
			setCdlisNotificationType(new CodeSetElement(dataToCopy
					.getCdlisTransferType()));
		}
		else {
			setCdlisNotificationType(null);
		}
		//Copy disqualifiedForCdl
		if (isNotNull(dataToCopy.getDisqualifiedForCdl())) {
			setDisqualifiedForCdl(new CodeSetElement(dataToCopy
					.getDisqualifiedForCdl()));
		}
		else {
			setDisqualifiedForCdl(null);
		}
		//Copy dlCardRequestInProcess
		if (isNotNull(dataToCopy.getDlCardRequestInProcess())) {
			setDlCardRequestInProcess(new CodeSetElement(dataToCopy
					.getDlCardRequestInProcess()));
		}
		else {
			setDlCardRequestInProcess(null);
		}
		//Copy dlExpirationDateOfPreviousRecord
		setDlExpirationDateOfPreviousRecord(dataToCopy
				.getDlExpirationDateOfPreviousRecord());
		//Copy driverEducationCode
		if (isNotNull(dataToCopy.getDriverEducationCode())) {
			setDriverEducationCode(new CodeSetElement(dataToCopy
					.getDriverEducationCode()));
		}
		else {
			setDriverEducationCode(null);
		}
		//Copy driverTrainingCode
		if (isNotNull(dataToCopy.getDriverTrainingCode())) {
			setDriverTrainingCode(new CodeSetElement(dataToCopy
					.getDriverTrainingCode()));
		}
		else {
			setDriverTrainingCode(null);
		}
		//Copy echoedDriverLicense
		if (isNotNull(dataToCopy.getEchoedDriverLicense())) {
			setEchoedDriverLicense(new DriverLicense(dataToCopy
					.getEchoedDriverLicense()));
		}
		else {
			setEchoedDriverLicense(null);
		}
		//Copy echoedIdCard
		if (isNotNull(dataToCopy.getEchoedIdCard())) {
			setEchoedIdCard(new IdCard(dataToCopy.getEchoedIdCard()));
		}
		else {
			setEchoedIdCard(null);
		}
		//Copy eligibleForEarlyCdlRenewal
		if (isNotNull(dataToCopy.getEligibleForEarlyCdlRenewal())) {
			setEligibleForEarlyCdlRenewal(new CodeSetElement(dataToCopy
					.getEligibleForEarlyCdlRenewal()));
		}
		else {
			setEligibleForEarlyCdlRenewal(null);
		}
		//Copy employeeAuthorizationIdOfPreviousRecord
		setEmployeeAuthorizationIdOfPreviousRecord(dataToCopy
				.getEmployeeAuthorizationIdOfPreviousRecord());
		//Copy existingLicenseClassesOfPreviousRecord
		if (isNotNull(dataToCopy.getExistingLicenseClassesOfPreviousRecord())) {
			setExistingLicenseClassesOfPreviousRecord(new ArrayList <CodeSetElement>());
			getExistingLicenseClassesOfPreviousRecord().addAll(
					dataToCopy.getExistingLicenseClassesOfPreviousRecord());
		}
		//Copy feeRequiredReasonCode
		if (isNotNull(dataToCopy.getFeeRequiredReasonCode())) {
			setFeeRequiredReasonCode(new CodeSetElement(dataToCopy
					.getFeeRequiredReasonCode()));
		}
		else {
			setFeeRequiredReasonCode(null);
		}
		//Copy frSuspensionDueDate
		if (isNotNull(dataToCopy.getFrSuspensionDueDate())) {
			setFrSuspensionDueDate(new Date(dataToCopy.getFrSuspensionDueDate()
					.getTime()));
		}
		else {
			setFrSuspensionDueDate(null);
		}
		//Copy historyRecord10YearCheck
		if (isNotNull(dataToCopy.getHistoryRecord10YearCheck())) {
			setHistoryRecord10YearCheck(new CodeSetElement(dataToCopy
					.getHistoryRecord10YearCheck()));
		}
		else {
			setHistoryRecord10YearCheck(null);
		}
		//Copy idCardRequestInProcess
		if (isNotNull(dataToCopy.getIdCardRequestInProcess())) {
			setIdCardRequestInProcess(new CodeSetElement(dataToCopy
					.getIdCardRequestInProcess()));
		}
		else {
			setIdCardRequestInProcess(null);
		}
		//Copy invoiceItem
		if (isNotNull(dataToCopy.getInvoiceItem())) {
			setInvoiceItem(new InvoiceItem(dataToCopy.getInvoiceItem()));
		}
		else {
			setInvoiceItem(null);
		}
		//Copy isCdlisNdrResponseAvailable
		if (isNotNull(dataToCopy.isCdlisNdrResponseAvailable())) {
			setCdlisNdrResponseAvailable(new Boolean(dataToCopy
					.isCdlisNdrResponseAvailable()));
		}
		else {
			setCdlisNdrResponseAvailable(null);
		}
		//Copy isCreditCardPaymentIndicator
		if (isNotNull(dataToCopy.isCreditCardPaymentIndicator())) {
			setCreditCardPaymentIndicator(new Boolean(dataToCopy
					.isCreditCardPaymentIndicator()));
		}
		else {
			setCreditCardPaymentIndicator(null);
		}
		//Copy isLegalPresenceCheckBypassIndicator
		if (isNotNull(dataToCopy.isLegalPresenceCheckBypassIndicator())) {
			setLegalPresenceCheckBypassIndicator(new Boolean(dataToCopy
					.isLegalPresenceCheckBypassIndicator()));
		}
		else {
			setLegalPresenceCheckBypassIndicator(null);
		}
		//Copy isOrganDonor
		if (isNotNull(dataToCopy.isOrganDonor())) {
			setOrganDonor(new Boolean(dataToCopy.isOrganDonor()));
		}
		else {
			setOrganDonor(null);
		}
		//Copy isOriginalApplicationIndicator
		if (isNotNull(dataToCopy.isOriginalApplicationIndicator())) {
			setOriginalApplicationIndicator(new Boolean(dataToCopy
					.isOriginalApplicationIndicator()));
		}
		else {
			setOriginalApplicationIndicator(null);
		}
		//Copy militaryDutyCode
		if (isNotNull(dataToCopy.getMilitaryDutyCode())) {
			setMilitaryDutyCode(new CodeSetElement(dataToCopy
					.getMilitaryDutyCode()));
		}
		else {
			setMilitaryDutyCode(null);
		}
		//Copy motorCycleTrainingCode
		if (isNotNull(dataToCopy.getMotorCycleTrainingCode())) {
			setMotorCycleTrainingCode(new CodeSetElement(dataToCopy
					.getMotorCycleTrainingCode()));
		}
		else {
			setMotorCycleTrainingCode(null);
		}
		//Copy newIncompleteApplicationReasonCode
		if (isNotNull(dataToCopy.getNewIncompleteApplicationReasonCode())) {
			setNewIncompleteApplicationReasonCode(new CodeSetElement(dataToCopy
					.getNewIncompleteApplicationReasonCode()));
		}
		else {
			setNewIncompleteApplicationReasonCode(null);
		}
		//Copy nonCommercialDriveRetestFee
		if (isNotNull(dataToCopy.getNonCommercialDriveRetestFee())) {
			setNonCommercialDriveRetestFee(new CodeSetElement(dataToCopy
					.getNonCommercialDriveRetestFee()));
		}
		else {
			setNonCommercialDriveRetestFee(null);
		}
		//Copy originalApplicationCashierId
		setOriginalApplicationCashierId(dataToCopy
				.getOriginalApplicationCashierId());
		//Copy originalApplicationCashierSequenceNumber
		setOriginalApplicationCashierSequenceNumber(dataToCopy
				.getOriginalApplicationCashierSequenceNumber());
		//Copy originalApplicationDate
		if (isNotNull(dataToCopy.getOriginalApplicationDate())) {
			setOriginalApplicationDate(new Date(dataToCopy
					.getOriginalApplicationDate().getTime()));
		}
		else {
			setOriginalApplicationDate(null);
		}
		//Copy originalApplicationOfficeId
		setOriginalApplicationOfficeId(dataToCopy
				.getOriginalApplicationOfficeId());
		//Copy originalApplicationTtc
		setOriginalApplicationTtc(dataToCopy.getOriginalApplicationTtc());
		//Copy originalApplicationWorkDate
		if (isNotNull(dataToCopy.getOriginalApplicationWorkDate())) {
			setOriginalApplicationWorkDate(new Date(dataToCopy
					.getOriginalApplicationWorkDate().getTime()));
		}
		else {
			setOriginalApplicationWorkDate(null);
		}
		//Copy outOfStateDriverEducationAndTrainingWaiveCode
		if (isNotNull(dataToCopy
				.getOutOfStateDriverEducationAndTrainingWaiveCode())) {
			setOutOfStateDriverEducationAndTrainingWaiveCode(new CodeSetElement(
					dataToCopy
							.getOutOfStateDriverEducationAndTrainingWaiveCode()));
		}
		else {
			setOutOfStateDriverEducationAndTrainingWaiveCode(null);
		}
		//Copy outOfStateWithdrawalActionCode
		if (isNotNull(dataToCopy.getOutOfStateWithdrawalActionCode())) {
			setOutOfStateWithdrawalActionCode(new CodeSetElement(dataToCopy
					.getOutOfStateWithdrawalActionCode()));
		}
		else {
			setOutOfStateWithdrawalActionCode(null);
		}
		//Copy pendingDlApplicationUserVerifiedSsnCode
		if (isNotNull(dataToCopy.getPendingDlApplicationUserVerifiedSsnCode())) {
			setPendingDlApplicationUserVerifiedSsnCode(new CodeSetElement(
					dataToCopy.getPendingDlApplicationUserVerifiedSsnCode()));
		}
		else {
			setPendingDlApplicationUserVerifiedSsnCode(null);
		}
		//Copy pendingIdApplicationUserVerifiedSsnCode
		if (isNotNull(dataToCopy.getPendingIdApplicationUserVerifiedSsnCode())) {
			setPendingIdApplicationUserVerifiedSsnCode(new CodeSetElement(
					dataToCopy.getPendingIdApplicationUserVerifiedSsnCode()));
		}
		else {
			setPendingIdApplicationUserVerifiedSsnCode(null);
		}
		//Copy photoTakenType
		if (isNotNull(dataToCopy.getPhotoTakenType())) {
			setPhotoTakenType(new CodeSetElement(dataToCopy.getPhotoTakenType()));
		}
		else {
			setPhotoTakenType(null);
		}
		//Copy photoTypeOnFile
		if (isNotNull(dataToCopy.getPhotoTypeOnFile())) {
			setPhotoTypeOnFile(new CodeSetElement(dataToCopy
					.getPhotoTypeOnFile()));
		}
		else {
			setPhotoTypeOnFile(null);
		}
		//Copy previousPhotoIndicator
		if (isNotNull(dataToCopy.getPreviousPhotoIndicator())) {
			setPreviousPhotoIndicator(new CodeSetElement(dataToCopy
					.getPreviousPhotoIndicator()));
		}
		else {
			setPreviousPhotoIndicator(null);
		}
		//Copy segments
		if (isNotNull(dataToCopy.getSegments())) {
			getSegments().addAll(dataToCopy.getSegments());
		}
		//Copy transactionCode
		if (isNotNull(dataToCopy.getTransactionCode())) {
			setTransactionCode(new CodeSetElement(dataToCopy
					.getTransactionCode()));
		}
		else {
			setTransactionCode(null);
		}
		//Copy userVerifiedBdlpCode
		if (isNotNull(dataToCopy.getUserVerifiedBdlpCode())) {
			setUserVerifiedBdlpCode(new CodeSetElement(dataToCopy
					.getUserVerifiedBdlpCode()));
		}
		else {
			setUserVerifiedBdlpCode(null);
		}
		//Copy validSsnRequired
		if (isNotNull(dataToCopy.getValidSsnRequired())) {
			setValidSsnRequired(new CodeSetElement(dataToCopy
					.getValidSsnRequired()));
		}
		else {
			setValidSsnRequired(null);
		}
		//Copy withheldPendingPdpsClearance
		if (isNotNull(dataToCopy.getWithheldPendingPdpsClearance())) {
			setWithheldPendingPdpsClearance(new CodeSetElement(dataToCopy
					.getWithheldPendingPdpsClearance()));
		}
		else {
			setWithheldPendingPdpsClearance(null);
		}
		//Copy writtenDriveTestIndicator
		if (isNotNull(dataToCopy.getWrittenDriveTestIndicator())) {
			setWrittenDriveTestIndicator(new CodeSetElement(dataToCopy
					.getWrittenDriveTestIndicator()));
		}
		else {
			setWrittenDriveTestIndicator(null);
		}
		//Copy classOfRecord
		if (isNotNull(dataToCopy.getClassOfRecord())) {
			setClassOfRecord(dataToCopy.getClassOfRecord());
		}
		//Copy photoRequired
		if (isNotNull(dataToCopy.getPhotoRequired())) {
			setPhotoRequired(new CodeSetElement(dataToCopy.getPhotoRequired()));
		}
		else {
			setPhotoRequired(null);
		}
		//Copy previousPhotoRequired
		if (isNotNull(dataToCopy.getPreviousPhotoRequired())) {
			setPreviousPhotoRequired(new CodeSetElement(dataToCopy
					.getPreviousPhotoRequired()));
		}
		else {
			setPreviousPhotoRequired(null);
		}
		
		//Copy idInstallationIndicator
		if (isNotNull(dataToCopy.getIidInstallationIndicator())) {
			setIidInstallationIndicator(dataToCopy
					.getIidInstallationIndicator());
		}
		else {
			setIidInstallationIndicator(null);
		}
	}
	
	/**
	 * Adds the segment.
	 * 
	 * @param segment the segment
	 */
	@Override
	public void addSegment(CodeSetElement segment) {
		segments.add(segment);
	}
	
	/**
	 * Gets the cdlis notification date.
	 * 
	 * @return the cdlisNotificationDate
	 */
	public Date getCdlisNotificationDate() {
		return cdlisNotificationDate;
	}
	
	/**
	 * Gets the cdlis notification type.
	 * 
	 * @return the cdlisNotificationType
	 */
	public CodeSetElement getCdlisNotificationType() {
		return cdlisNotificationType;
	}
	
	/**
	 * Gets the cdlis transfer type.
	 * 
	 * @return the cdlisTransferType
	 */
	public CodeSetElement getCdlisTransferType() {
		return cdlisTransferType;
	}
	
	/**
	 * Gets the disqualifiedForCdl.
	 * 
	 * @return the disqualifiedForCdl
	 */
	public CodeSetElement getDisqualifiedForCdl() {
		return disqualifiedForCdl;
	}
	
	/**
	 * Gets the dlCardRequestInProcess.
	 * 
	 * @return the dlCardRequestInProcess
	 */
	public CodeSetElement getDlCardRequestInProcess() {
		return dlCardRequestInProcess;
	}
	
	/**
	 * Gets the dl expiration date of previous record.
	 * 
	 * @return the dlExpirationDateOfPreviousRecord
	 */
	public String getDlExpirationDateOfPreviousRecord() {
		return dlExpirationDateOfPreviousRecord;
	}
	
	/**
	 * Gets the driver education code.
	 * 
	 * @return the driverEducationCode
	 */
	public CodeSetElement getDriverEducationCode() {
		return driverEducationCode;
	}
	
	/**
	 * Gets the Driver License.
	 * 
	 * @return the driverLicense
	 */
	public DriverLicense getDriverLicense() {
		return this.getPerson().getDriverLicense();
	}
	
	/**
	 * Gets the driver license number.
	 * 
	 * @return the driver license number
	 */
	public String getDriverLicenseNumber() {
		String licenseNumber = null;
		DriverLicense driverLicense = getDriverLicense();
		if (driverLicense != null) {
			licenseNumber = driverLicense.getLicenseNumber();
		}
		return licenseNumber;
	}
	
	/**
	 * Gets the driver training code.
	 * 
	 * @return the driverTrainingCode
	 */
	public CodeSetElement getDriverTrainingCode() {
		return driverTrainingCode;
	}
	
	/**
	 * Gets the echoed driver license.
	 *
	 * @return the echoedDriverLicense
	 */
	public DriverLicense getEchoedDriverLicense() {
		return echoedDriverLicense;
	}
	
	/**
	 * Gets the echoed id card.
	 *
	 * @return the echoedIdCard
	 */
	public IdCard getEchoedIdCard() {
		return echoedIdCard;
	}
	
	/**
	 * Gets the eligibleForEarlyCdlRenewal.
	 * 
	 * @return the eligibleForEarlyCdlRenewal
	 */
	public CodeSetElement getEligibleForEarlyCdlRenewal() {
		return eligibleForEarlyCdlRenewal;
	}
	
	/**
	 * Gets the employee authorization id of previous record.
	 * 
	 * @return the employeeAuthorizationIdOfPreviousRecord
	 */
	public String getEmployeeAuthorizationIdOfPreviousRecord() {
		return employeeAuthorizationIdOfPreviousRecord;
	}
	
	/**
	 * Gets the existing license classes of previous record.
	 * 
	 * @return the existingLicenseClassesOfPreviousRecord
	 */
	public List <CodeSetElement> getExistingLicenseClassesOfPreviousRecord() {
		return existingLicenseClassesOfPreviousRecord;
	}
	
	/**
	 * Gets the fee required reason code.
	 * 
	 * @return the feeRequiredReasonCode
	 */
	public CodeSetElement getFeeRequiredReasonCode() {
		return feeRequiredReasonCode;
	}
	
	/**
	 * Gets the fr suspension due date.
	 * 
	 * @return the frSuspensionDueDate
	 */
	public Date getFrSuspensionDueDate() {
		return frSuspensionDueDate;
	}
	
	/**
	 * Gets the historyRecord10YearCheck.
	 * 
	 * @return the historyRecord10YearCheck
	 */
	public CodeSetElement getHistoryRecord10YearCheck() {
		return historyRecord10YearCheck;
	}
	
	/**
	 * Gets the Id Card.
	 * 
	 * @return the driverLicense
	 */
	public IdCard getIdCard() {
		return this.getPerson().getIdCard();
	}
	
	/**
	 * Gets the id card number.
	 * 
	 * @return the id card number
	 */
	public String getIdCardNumber() {
		String licenseNumber = null;
		IdCard idCard = getIdCard();
		if (idCard != null) {
			licenseNumber = idCard.getLicenseNumber();
		}
		return licenseNumber;
	}
	
	/**
	 * Gets the idCardRequestInProcess.
	 * 
	 * @return the idCardRequestInProcess
	 */
	public CodeSetElement getIdCardRequestInProcess() {
		return idCardRequestInProcess;
	}
	
	/**
	 * Gets the invoice item.
	 * 
	 * @return the invoiceItem
	 */
	public InvoiceItem getInvoiceItem() {
		return invoiceItem;
	}
	
	/**
	 * Gets the Legal Presence Document.
	 * 
	 * @return the legalPresenceDocument
	 */
	public LegalPresenceDocument getLegalPresenceDocument() {
		return this.getPerson().getLegalPresenceDocument();
	}
	
	/**
	 * Gets the military duty code.
	 * 
	 * @return the militaryDutyCode
	 */
	public CodeSetElement getMilitaryDutyCode() {
		return militaryDutyCode;
	}
	
	/**
	 * Gets the motor cycle training code.
	 * 
	 * @return the motorCycleTrainingCode
	 */
	public CodeSetElement getMotorCycleTrainingCode() {
		return motorCycleTrainingCode;
	}
	
	/**
	 * Gets the new incomplete application reason code.
	 * 
	 * @return the newIncompleteApplicationReasonCode
	 */
	public CodeSetElement getNewIncompleteApplicationReasonCode() {
		return newIncompleteApplicationReasonCode;
	}
	
	/**
	 * Gets the non commercial drive retest fee.
	 * 
	 * @return the nonCommercialDriveRetestFee
	 */
	public CodeSetElement getNonCommercialDriveRetestFee() {
		return nonCommercialDriveRetestFee;
	}
	
	/**
	 * Gets the original application cashier id.
	 * 
	 * @return the originalApplicationCashierId
	 */
	public String getOriginalApplicationCashierId() {
		return originalApplicationCashierId;
	}
	
	/**
	 * Gets the original application cashier sequence number.
	 * 
	 * @return the originalApplicationCashierSequenceNumber
	 */
	public String getOriginalApplicationCashierSequenceNumber() {
		return originalApplicationCashierSequenceNumber;
	}
	
	/**
	 * Gets the original application date.
	 * 
	 * @return the originalApplicationDate
	 */
	public Date getOriginalApplicationDate() {
		return originalApplicationDate;
	}
	
	/**
	 * Gets the original application office id.
	 * 
	 * @return the originalApplicationOfficeId
	 */
	public String getOriginalApplicationOfficeId() {
		return originalApplicationOfficeId;
	}
	
	/**
	 * Gets the original application ttc.
	 * 
	 * @return the originalApplicationTtc
	 */
	public String getOriginalApplicationTtc() {
		return originalApplicationTtc;
	}
	
	/**
	 * Gets the original application work date.
	 * 
	 * @return the originalApplicationWorkDate
	 */
	public Date getOriginalApplicationWorkDate() {
		return originalApplicationWorkDate;
	}
	
	/**
	 * Gets the out of state driver education and training waive code.
	 * 
	 * @return the outOfStateDriverEducationAndTrainingWaiveCode
	 */
	public CodeSetElement getOutOfStateDriverEducationAndTrainingWaiveCode() {
		return outOfStateDriverEducationAndTrainingWaiveCode;
	}
	
	/**
	 * Gets the OutOfStateWithdrawalActionCode.
	 * 
	 * @return the outOfStateWithdrawalActionCode
	 */
	public CodeSetElement getOutOfStateWithdrawalActionCode() {
		return outOfStateWithdrawalActionCode;
	}
	
	/**
	 * Gets the pending dl application user verified ssn code.
	 * 
	 * @return the pendingDlApplicationUserVerifiedSsnCode
	 */
	public CodeSetElement getPendingDlApplicationUserVerifiedSsnCode() {
		return pendingDlApplicationUserVerifiedSsnCode;
	}
	
	/**
	 * Gets the pending id application user verified ssn code.
	 * 
	 * @return the pendingIdApplicationUserVerifiedSsnCode
	 */
	public CodeSetElement getPendingIdApplicationUserVerifiedSsnCode() {
		return pendingIdApplicationUserVerifiedSsnCode;
	}
	
	/**
	 * Gets the photo taken type.
	 * 
	 * @return the photoTakenType
	 */
	public CodeSetElement getPhotoTakenType() {
		return photoTakenType;
	}
	
	/**
	 * Gets the photo type on file.
	 * 
	 * @return the photoTypeOnFile
	 */
	public CodeSetElement getPhotoTypeOnFile() {
		return photoTypeOnFile;
	}
	
	/**
	 * Gets the previous photo indicator.
	 * 
	 * @return the previousPhotoIndicator
	 */
	public CodeSetElement getPreviousPhotoIndicator() {
		return previousPhotoIndicator;
	}
	
	/**
	 * Gets the segments.
	 * 
	 * @return the segments
	 */
	@Override
	public List <CodeSetElement> getSegments() {
		return segments;
	}
	
	/**
	 * Gets the transaction code.
	 *
	 * @return the transactionCode
	 */
	public CodeSetElement getTransactionCode() {
		return transactionCode;
	}
	
	/**
	 * Gets the user verified bdlp code.
	 * 
	 * @return the userVerifiedBdlpCode
	 */
	public CodeSetElement getUserVerifiedBdlpCode() {
		return userVerifiedBdlpCode;
	}
	
	/**
	 * Gets the valid ssn required.
	 * 
	 * @return the validSsnRequired
	 */
	public CodeSetElement getValidSsnRequired() {
		return validSsnRequired;
	}
	
	/**
	 * Gets the withheldPendingPdpsClearance.
	 * 
	 * @return the withheldPendingPdpsClearance
	 */
	public CodeSetElement getWithheldPendingPdpsClearance() {
		return withheldPendingPdpsClearance;
	}
	
	/**
	 * Gets the written drive test indicator.
	 * 
	 * @return the writtenDriveTestIndicator
	 */
	public CodeSetElement getWrittenDriveTestIndicator() {
		return writtenDriveTestIndicator;
	}
	
	/**
	 * Checks if is cdlis ndr response available.
	 * 
	 * @return the isCdlisNdrResponseAvailable
	 */
	public Boolean isCdlisNdrResponseAvailable() {
		return isCdlisNdrResponseAvailable;
	}
	
	/**
	 * Checks if is credit card payment indicator.
	 * 
	 * @return the isCreditCardPaymentIndicator
	 */
	public Boolean isCreditCardPaymentIndicator() {
		return isCreditCardPaymentIndicator;
	}
	
	/**
	 * Checks if is dl pending sub record segment a present.
	 * 
	 * @return true, if is dl pending sub record segment a present
	 */
	public boolean isDlPendingSubRecordSegmentaPresent() {
		if (!EaseUtil.isNullOrBlank(this.getSegments())) {
			List <String> segmentCodes = new ArrayList <String>();
			for (CodeSetElement segmentCode : this.getSegments()) {
				segmentCodes.add(segmentCode.getCode());
			}
			if (contains(segmentCodes, SUB_RECORD_A)
					&& contains(segmentCodes, SUB_RECORD_A2)
					&& !contains(segmentCodes, SUB_RECORD_B)) {
				//If Segments A and A2 are present and Segment B is not present.
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
	
	/**
	 * Checks if is dl pending sub record segment b present.
	 * 
	 * @return true, if is dl pending sub record segment b present
	 */
	public boolean isDlPendingSubRecordSegmentbPresent() {
		// TODO: It should be isIdPendingSubRecordSegmentBPresent
		if (!EaseUtil.isNullOrBlank(this.getSegments())) {
			List <String> segmentCodes = new ArrayList <String>();
			for (CodeSetElement segmentCode : this.getSegments()) {
				segmentCodes.add(segmentCode.getCode());
			}
			if (contains(segmentCodes, SUB_RECORD_A)
					&& contains(segmentCodes, SUB_RECORD_B)
					&& !contains(segmentCodes, SUB_RECORD_A2)) {
				//If Segments A and B are present and Segment A2 is not present.
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
	
	/**
	 * Checks if is legal presence check bypass indicator.
	 * 
	 * @return the isLegalPresenceCheckBypassIndicator
	 */
	public Boolean isLegalPresenceCheckBypassIndicator() {
		return isLegalPresenceCheckBypassIndicator;
	}
	
	/**
	 * Gets the Organ Donor Indicator.
	 * 
	 * @return the isOrganDonor
	 */
	public Boolean isOrganDonor() {
		return isOrganDonor;
	}
	
	/**
	 * Checks if is original application indicator.
	 * 
	 * @return the OriginalApplicationIndicator
	 */
	public Boolean isOriginalApplicationIndicator() {
		return isOriginalApplicationIndicator;
	}
	
	/**
	 * Sets the cdlis ndr response available.
	 * 
	 * @param isCdlisNdrResponseAvailable the isCdlisNdrResponseAvailable to set
	 */
	public void setCdlisNdrResponseAvailable(Boolean isCdlisNdrResponseAvailable) {
		this.isCdlisNdrResponseAvailable = isCdlisNdrResponseAvailable;
	}
	
	/**
	 * Sets the cdlis notification date.
	 * 
	 * @param cdlisNotificationDate the cdlisNotificationDate to set
	 */
	public void setCdlisNotificationDate(Date cdlisNotificationDate) {
		this.cdlisNotificationDate = cdlisNotificationDate;
	}
	
	/**
	 * Sets the cdlis notification type.
	 * 
	 * @param cdlisNotificationType the cdlisNotificationType to set
	 */
	public void setCdlisNotificationType(CodeSetElement cdlisNotificationType) {
		this.cdlisNotificationType = cdlisNotificationType;
	}
	
	/**
	 * Sets the cdlis transfer type.
	 * 
	 * @param cdlisTransferType the cdlisTransferType to set
	 */
	public void setCdlisTransferType(CodeSetElement cdlisTransferType) {
		this.cdlisTransferType = cdlisTransferType;
	}
	
	/**
	 * Sets the credit card payment indicator.
	 * 
	 * @param isCreditCardPaymentIndicator the isCreditCardPaymentIndicator to set
	 */
	public void setCreditCardPaymentIndicator(
			Boolean isCreditCardPaymentIndicator) {
		this.isCreditCardPaymentIndicator = isCreditCardPaymentIndicator;
	}
	
	/**
	 * Sets the disqualifiedForCdl.
	 *
	 * @param disqualifiedForCdl the new disqualified for cdl
	 */
	public void setDisqualifiedForCdl(CodeSetElement disqualifiedForCdl) {
		this.disqualifiedForCdl = disqualifiedForCdl;
	}
	
	/**
	 * Sets the dlCardRequestInProcess.
	 * 
	 * @param dlCardRequestInProcess the dlCardRequestInProcess to set
	 */
	public void setDlCardRequestInProcess(CodeSetElement dlCardRequestInProcess) {
		this.dlCardRequestInProcess = dlCardRequestInProcess;
	}
	
	/**
	 * Sets the dl expiration date of previous record.
	 * 
	 * @param dlExpirationDateOfPreviousRecord the dlExpirationDateOfPreviousRecord to set
	 */
	public void setDlExpirationDateOfPreviousRecord(
			String dlExpirationDateOfPreviousRecord) {
		this.dlExpirationDateOfPreviousRecord = dlExpirationDateOfPreviousRecord;
	}
	
	/**
	 * Sets the driver education code.
	 * 
	 * @param driverEducationCode the driverEducationCode to set
	 */
	public void setDriverEducationCode(CodeSetElement driverEducationCode) {
		this.driverEducationCode = driverEducationCode;
	}
	
	/**
	 * Sets the Driver License.
	 * 
	 * @param driverLicense the driverLicense to set
	 */
	public void setDriverLicense(DriverLicense driverLicense) {
		this.getPerson().setDriverLicense(driverLicense);
	}
	
	/**
	 * Sets the driver training code.
	 * 
	 * @param driverTrainingCode the driverTrainingCode to set
	 */
	public void setDriverTrainingCode(CodeSetElement driverTrainingCode) {
		this.driverTrainingCode = driverTrainingCode;
	}
	
	/**
	 * Sets the echoed driver license.
	 *
	 * @param echoedDriverLicense the echoedDriverLicense to set
	 */
	public void setEchoedDriverLicense(DriverLicense echoedDriverLicense) {
		this.echoedDriverLicense = echoedDriverLicense;
	}
	
	/**
	 * Sets the echoed id card.
	 *
	 * @param echoedIdCard the echoedIdCard to set
	 */
	public void setEchoedIdCard(IdCard echoedIdCard) {
		this.echoedIdCard = echoedIdCard;
	}
	
	/**
	 * Sets the eligibleForEarlyCdlRenewal.
	 *
	 * @param eligibleForEarlyCdlRenewal the new eligible for early cdl renewal
	 */
	public void setEligibleForEarlyCdlRenewal(
			CodeSetElement eligibleForEarlyCdlRenewal) {
		this.eligibleForEarlyCdlRenewal = eligibleForEarlyCdlRenewal;
	}
	
	/**
	 * Sets the employee authorization id of previous record.
	 * 
	 * @param employeeAuthorizationIdOfPreviousRecord the employeeAuthorizationIdOfPreviousRecord to set
	 */
	public void setEmployeeAuthorizationIdOfPreviousRecord(
			String employeeAuthorizationIdOfPreviousRecord) {
		this.employeeAuthorizationIdOfPreviousRecord = employeeAuthorizationIdOfPreviousRecord;
	}
	
	/**
	 * Sets the existing license classes of previous record.
	 * 
	 * @param existingLicenseClassesOfPreviousRecord the existingLicenseClassesOfPreviousRecord to set
	 */
	public void setExistingLicenseClassesOfPreviousRecord(
			List <CodeSetElement> existingLicenseClassesOfPreviousRecord) {
		this.existingLicenseClassesOfPreviousRecord = existingLicenseClassesOfPreviousRecord;
	}
	
	/**
	 * Sets the fee required reason code.
	 * 
	 * @param feeRequiredReasonCode the feeRequiredReasonCode to set
	 */
	public void setFeeRequiredReasonCode(CodeSetElement feeRequiredReasonCode) {
		this.feeRequiredReasonCode = feeRequiredReasonCode;
	}
	
	/**
	 * Sets the fr suspension due date.
	 * 
	 * @param frSuspensionDueDate the frSuspensionDueDate to set
	 */
	public void setFrSuspensionDueDate(Date frSuspensionDueDate) {
		this.frSuspensionDueDate = frSuspensionDueDate;
	}
	
	/**
	 * Sets the historyRecord10YearCheck.
	 * 
	 * @param historyRecord10YearCheck the historyRecord10YearCheck to set
	 */
	public void setHistoryRecord10YearCheck(
			CodeSetElement historyRecord10YearCheck) {
		this.historyRecord10YearCheck = historyRecord10YearCheck;
	}
	
	/**
	 * Sets the idCardRequestInProcess.
	 * 
	 * @param idCardRequestInProcess the idCardRequestInProcess to set
	 */
	public void setIdCardRequestInProcess(CodeSetElement idCardRequestInProcess) {
		this.idCardRequestInProcess = idCardRequestInProcess;
	}
	
	/**
	 * Sets the invoice item.
	 * 
	 * @param invoiceItem the invoiceItem to set
	 */
	public void setInvoiceItem(InvoiceItem invoiceItem) {
		this.invoiceItem = invoiceItem;
	}
	
	/**
	 * Sets the legal presence check bypass indicator.
	 * 
	 * @param isLegalPresenceCheckBypassIndicator the isLegalPresenceCheckBypassIndicator to set
	 */
	public void setLegalPresenceCheckBypassIndicator(
			Boolean isLegalPresenceCheckBypassIndicator) {
		this.isLegalPresenceCheckBypassIndicator = isLegalPresenceCheckBypassIndicator;
	}
	
	/**
	 * Sets the Legal Presence Document.
	 * 
	 * @param legalPresenceDocument the legalPresenceDocument to set
	 */
	public void setLegalPresenceDocument(
			LegalPresenceDocument legalPresenceDocument) {
		this.getPerson().getDocuments().add(legalPresenceDocument);
	}
	
	/**
	 * Sets the military duty code.
	 * 
	 * @param militaryDutyCode the militaryDutyCode to set
	 */
	public void setMilitaryDutyCode(CodeSetElement militaryDutyCode) {
		this.militaryDutyCode = militaryDutyCode;
	}
	
	/**
	 * Sets the motor cycle training code.
	 * 
	 * @param motorCycleTrainingCode the motorCycleTrainingCode to set
	 */
	public void setMotorCycleTrainingCode(CodeSetElement motorCycleTrainingCode) {
		this.motorCycleTrainingCode = motorCycleTrainingCode;
	}
	
	/**
	 * Sets the new incomplete application reason code.
	 * 
	 * @param newIncompleteApplicationReasonCode the newIncompleteApplicationReasonCode to set
	 */
	public void setNewIncompleteApplicationReasonCode(
			CodeSetElement newIncompleteApplicationReasonCode) {
		this.newIncompleteApplicationReasonCode = newIncompleteApplicationReasonCode;
	}
	
	/**
	 * Sets the non commercial drive retest fee.
	 * 
	 * @param nonCommercialDriveRetestFee the nonCommercialDriveRetestFee to set
	 */
	public void setNonCommercialDriveRetestFee(
			CodeSetElement nonCommercialDriveRetestFee) {
		this.nonCommercialDriveRetestFee = nonCommercialDriveRetestFee;
	}
	
	/**
	 * Sets the Organ Donor Indicator.
	 * 
	 * @param isOrganDonor the isOrganDonor to set
	 */
	public void setOrganDonor(Boolean isOrganDonor) {
		this.isOrganDonor = isOrganDonor;
	}
	
	/**
	 * Sets the original application cashier id.
	 * 
	 * @param originalApplicationCashierId the originalApplicationCashierId to set
	 */
	public void setOriginalApplicationCashierId(
			String originalApplicationCashierId) {
		this.originalApplicationCashierId = originalApplicationCashierId;
	}
	
	/**
	 * Sets the original application cashier sequence number.
	 * 
	 * @param originalApplicationCashierSequenceNumber the originalApplicationCashierSequenceNumber to set
	 */
	public void setOriginalApplicationCashierSequenceNumber(
			String originalApplicationCashierSequenceNumber) {
		this.originalApplicationCashierSequenceNumber = originalApplicationCashierSequenceNumber;
	}
	
	/**
	 * Sets the original application date.
	 * 
	 * @param originalApplicationDate the originalApplicationDate to set
	 */
	public void setOriginalApplicationDate(Date originalApplicationDate) {
		this.originalApplicationDate = originalApplicationDate;
	}
	
	/**
	 * Sets the original application indicator.
	 * 
	 * @param isOriginalApplicationIndicator the isOriginalApplicationIndicator to set
	 */
	public void setOriginalApplicationIndicator(
			Boolean isOriginalApplicationIndicator) {
		this.isOriginalApplicationIndicator = isOriginalApplicationIndicator;
	}
	
	/**
	 * Sets the original application office id.
	 * 
	 * @param originalApplicationOfficeId the originalApplicationOfficeId to set
	 */
	public void setOriginalApplicationOfficeId(
			String originalApplicationOfficeId) {
		this.originalApplicationOfficeId = originalApplicationOfficeId;
	}
	
	/**
	 * Sets the original application ttc.
	 * 
	 * @param originalApplicationTtc the originalApplicationTtc to set
	 */
	public void setOriginalApplicationTtc(String originalApplicationTtc) {
		this.originalApplicationTtc = originalApplicationTtc;
	}
	
	/**
	 * Sets the original application work date.
	 * 
	 * @param originalApplicationWorkDate the originalApplicationWorkDate to set
	 */
	public void setOriginalApplicationWorkDate(Date originalApplicationWorkDate) {
		this.originalApplicationWorkDate = originalApplicationWorkDate;
	}
	
	/**
	 * Sets the out of state driver education and training waive code.
	 * 
	 * @param outOfStateDriverEducationAndTrainingWaiveCode the driverEducationAndTrainingCode to set
	 */
	public void setOutOfStateDriverEducationAndTrainingWaiveCode(
			CodeSetElement outOfStateDriverEducationAndTrainingWaiveCode) {
		this.outOfStateDriverEducationAndTrainingWaiveCode = outOfStateDriverEducationAndTrainingWaiveCode;
	}
	
	/**
	 * Sets the OutOfStateWithdrawalActionCode.
	 * 
	 * @param outOfStateWithdrawalActionCode the outOfStateWithdrawalActionCode to set
	 */
	public void setOutOfStateWithdrawalActionCode(
			CodeSetElement outOfStateWithdrawalActionCode) {
		this.outOfStateWithdrawalActionCode = outOfStateWithdrawalActionCode;
	}
	
	/**
	 * Sets the pending dl application user verified ssn code.
	 * 
	 * @param pendingDlApplicationUserVerifiedSsnCode the pendingDlApplicationUserVerifiedSsnCode to set
	 */
	public void setPendingDlApplicationUserVerifiedSsnCode(
			CodeSetElement pendingDlApplicationUserVerifiedSsnCode) {
		this.pendingDlApplicationUserVerifiedSsnCode = pendingDlApplicationUserVerifiedSsnCode;
	}
	
	/**
	 * Sets the pending id application user verified ssn code.
	 * 
	 * @param pendingIdApplicationUserVerifiedSsnCode the pendingIdApplicationUserVerifiedSsnCode to set
	 */
	public void setPendingIdApplicationUserVerifiedSsnCode(
			CodeSetElement pendingIdApplicationUserVerifiedSsnCode) {
		this.pendingIdApplicationUserVerifiedSsnCode = pendingIdApplicationUserVerifiedSsnCode;
	}
	
	/**
	 * Sets the photo taken type.
	 * 
	 * @param photoTakenType the photoTakenType to set
	 */
	public void setPhotoTakenType(CodeSetElement photoTakenType) {
		this.photoTakenType = photoTakenType;
	}
	
	/**
	 * Sets the photo type on file.
	 * 
	 * @param photoTypeOnFile the photoTypeOnFile to set
	 */
	public void setPhotoTypeOnFile(CodeSetElement photoTypeOnFile) {
		this.photoTypeOnFile = photoTypeOnFile;
	}
	
	/**
	 * Sets the previous photo indicator.
	 * 
	 * @param previousPhotoIndicator the previousPhotoIndicator to set
	 */
	public void setPreviousPhotoIndicator(CodeSetElement previousPhotoIndicator) {
		this.previousPhotoIndicator = previousPhotoIndicator;
	}
	
	/**
	 * Sets the transaction code.
	 *
	 * @param transactionCode the transactionCode to set
	 */
	public void setTransactionCode(CodeSetElement transactionCode) {
		this.transactionCode = transactionCode;
	}
	
	/**
	 * Sets the user verified bdlp code.
	 * 
	 * @param userVerifiedBdlpCode the userVerifiedBdlpCode to set
	 */
	public void setUserVerifiedBdlpCode(CodeSetElement userVerifiedBdlpCode) {
		this.userVerifiedBdlpCode = userVerifiedBdlpCode;
	}
	
	/**
	 * Sets the valid ssn required.
	 * 
	 * @param validSsnRequired the validSsnRequired to set
	 */
	public void setValidSsnRequired(CodeSetElement validSsnRequired) {
		this.validSsnRequired = validSsnRequired;
	}
	
	/**
	 * Sets the withheldPendingPDPSClearance.
	 *
	 * @param withheldPendingPdpsClearance the new withheld pending pdps clearance
	 */
	public void setWithheldPendingPdpsClearance(
			CodeSetElement withheldPendingPdpsClearance) {
		this.withheldPendingPdpsClearance = withheldPendingPdpsClearance;
	}
	
	/**
	 * Sets the written drive test indicator.
	 * 
	 * @param writtenDriveTestIndicator the writtenDriveTestIndicator to set
	 */
	public void setWrittenDriveTestIndicator(
			CodeSetElement writtenDriveTestIndicator) {
		this.writtenDriveTestIndicator = writtenDriveTestIndicator;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.license.impl.DlRecord#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("SUB_RECORD_A", SUB_RECORD_A, anIndent, aBuilder);
		outputKeyValue("SUB_RECORD_A2", SUB_RECORD_A2, anIndent, aBuilder);
		outputKeyValue("SUB_RECORD_B", SUB_RECORD_B, anIndent, aBuilder);
		outputKeyValue("cdlisNotificationDate", cdlisNotificationDate,
				anIndent, aBuilder);
		outputKeyValue("cdlisNotificationType", cdlisNotificationType,
				anIndent, aBuilder);
		outputKeyValue("cdlisTransferType", cdlisTransferType, anIndent,
				aBuilder);
		outputKeyValue("disqualifiedForCDL", disqualifiedForCdl, anIndent,
				aBuilder);
		outputKeyValue("dlCardRequestInProcess", dlCardRequestInProcess,
				anIndent, aBuilder);
		outputKeyValue("dlExpirationDateOfPreviousRecord",
				dlExpirationDateOfPreviousRecord, anIndent, aBuilder);
		outputKeyValue("driverEducationCode", driverEducationCode, anIndent,
				aBuilder);
		outputKeyValue("driverTrainingCode", driverTrainingCode, anIndent,
				aBuilder);
		outputKeyValue("echoedDriverLicense", echoedDriverLicense, anIndent,
				aBuilder);
		outputKeyValue("echoedIdCard", echoedIdCard, anIndent, aBuilder);
		outputKeyValue("eligibleForEarlyCDLRenewal",
				eligibleForEarlyCdlRenewal, anIndent, aBuilder);
		outputKeyValue("employeeAuthorizationIdOfPreviousRecord",
				employeeAuthorizationIdOfPreviousRecord, anIndent, aBuilder);
		outputKeyValue("existingLicenseClassesOfPreviousRecord",
				existingLicenseClassesOfPreviousRecord, anIndent, aBuilder);
		outputKeyValue("feeRequiredReasonCode", feeRequiredReasonCode,
				anIndent, aBuilder);
		outputKeyValue("frSuspensionDueDate", frSuspensionDueDate, anIndent,
				aBuilder);
		outputKeyValue("historyRecord10YearCheck", historyRecord10YearCheck,
				anIndent, aBuilder);
		outputKeyValue("idCardRequestInProcess", idCardRequestInProcess,
				anIndent, aBuilder);
		outputKeyValue("invoiceItem", invoiceItem, anIndent, aBuilder);
		outputKeyValue("isCdlisNdrResponseAvailable",
				isCdlisNdrResponseAvailable, anIndent, aBuilder);
		outputKeyValue("isCreditCardPaymentIndicator",
				isCreditCardPaymentIndicator, anIndent, aBuilder);
		outputKeyValue("isLegalPresenceCheckBypassIndicator",
				isLegalPresenceCheckBypassIndicator, anIndent, aBuilder);
		outputKeyValue("isOrganDonor", isOrganDonor, anIndent, aBuilder);
		outputKeyValue("isOriginalApplicationIndicator",
				isOriginalApplicationIndicator, anIndent, aBuilder);
		outputKeyValue("militaryDutyCode", militaryDutyCode, anIndent, aBuilder);
		outputKeyValue("motorCycleTrainingCode", motorCycleTrainingCode,
				anIndent, aBuilder);
		outputKeyValue("newIncompleteApplicationReasonCode",
				newIncompleteApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("nonCommercialDriveRetestFee",
				nonCommercialDriveRetestFee, anIndent, aBuilder);
		outputKeyValue("originalApplicationCashierId",
				originalApplicationCashierId, anIndent, aBuilder);
		outputKeyValue("originalApplicationCashierSequenceNumber",
				originalApplicationCashierSequenceNumber, anIndent, aBuilder);
		outputKeyValue("originalApplicationDate", originalApplicationDate,
				anIndent, aBuilder);
		outputKeyValue("originalApplicationOfficeId",
				originalApplicationOfficeId, anIndent, aBuilder);
		outputKeyValue("originalApplicationTtc", originalApplicationTtc,
				anIndent, aBuilder);
		outputKeyValue("originalApplicationWorkDate",
				originalApplicationWorkDate, anIndent, aBuilder);
		outputKeyValue("outOfStateDriverEducationAndTrainingWaiveCode",
				outOfStateDriverEducationAndTrainingWaiveCode, anIndent,
				aBuilder);
		outputKeyValue("OutOfStateWithdrawalActionCode",
				outOfStateWithdrawalActionCode, anIndent, aBuilder);
		outputKeyValue("pendingDlApplicationUserVerifiedSsnCode",
				pendingDlApplicationUserVerifiedSsnCode, anIndent, aBuilder);
		outputKeyValue("pendingIdApplicationUserVerifiedSsnCode",
				pendingIdApplicationUserVerifiedSsnCode, anIndent, aBuilder);
		outputKeyValue("photoTakenType", photoTakenType, anIndent, aBuilder);
		outputKeyValue("photoTypeOnFile", photoTypeOnFile, anIndent, aBuilder);
		outputKeyValue("previousPhotoIndicator", previousPhotoIndicator,
				anIndent, aBuilder);
		outputKeyValue("segments", segments, anIndent, aBuilder);
		outputKeyValue("transactionCode", transactionCode, anIndent, aBuilder);
		outputKeyValue("userVerifiedBdlpCode", userVerifiedBdlpCode, anIndent,
				aBuilder);
		outputKeyValue("validSsnRequired", validSsnRequired, anIndent, aBuilder);
		outputKeyValue("withheldPendingPDPSClearance",
				withheldPendingPdpsClearance, anIndent, aBuilder);
		outputKeyValue("writtenDriveTestIndicator", writtenDriveTestIndicator,
				anIndent, aBuilder);
		outputKeyValue("photoRequired", photoRequired, anIndent, aBuilder);
		outputKeyValue("iidInstallationIndicator", iidInstallationIndicator, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * Get the classOfRecord.
	 *
	 * @return the classOfRecord
	 */
	public String getClassOfRecord() {
		return classOfRecord;
	}
	
	/**
	 * Set classOfRecord.
	 *
	 * @param classOfRecord the classOfRecord to set
	 */
	public void setClassOfRecord(String classOfRecord) {
		this.classOfRecord = classOfRecord;
	}
	
	/**
	 * Gets the photoRequired.
	 *
	 * @return the photoRequired
	 */
	public CodeSetElement getPhotoRequired() {
		return photoRequired;
	}
	
	/**
	 * Sets the photoRequired.
	 *
	 * @param photoRequired the photoRequired to set
	 */
	public void setPhotoRequired(CodeSetElement photoRequired) {
		this.photoRequired = photoRequired;
	}
	
	/**
	 * Sets the previous photo required.
	 *
	 * @param previousPhotoRequired the previousPhotoRequired to set
	 */
	public void setPreviousPhotoRequired(CodeSetElement previousPhotoRequired) {
		this.previousPhotoRequired = previousPhotoRequired;
	}
	
	/**
	 * Gets the previous photo required.
	 *
	 * @return the previousPhotoRequired
	 */
	public CodeSetElement getPreviousPhotoRequired() {
		return previousPhotoRequired;
	}

	/**
	 * @param iidInstallationIndicator the iidInstallationIndicator to set
	 */
	public void setIidInstallationIndicator(String iidInstallationIndicator) {
		this.iidInstallationIndicator = iidInstallationIndicator;
	}

	/**
	 * @return the iidInstallationIndicator
	 */
	public String getIidInstallationIndicator() {
		return iidInstallationIndicator;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EliRecord.java,v $
 *  Revision 1.48  2012/11/01 21:49:47  mwgxd3
 *  AB91 - add iidInstallationIndicator
 *
 *  Revision 1.47  2012/09/14 20:58:54  mwhys
 *  Added copy constructor. (Defect 6900 - AN fatal)
 *
 *  Revision 1.46  2012/08/15 17:10:50  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.45  2012/08/15 16:22:57  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.44  2012/08/14 20:58:48  mwhys
 *  Removed unused methods.
 *
 *  Revision 1.43  2012/08/14 20:46:02  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.42  2012/08/13 23:28:33  mwkfh
 *  Fixed null pointer issue in isRecordExist
 *
 *  Revision 1.41  2011/09/02 18:52:11  mwhys
 *  Added previousPhotoRequired field.
 *
 *  Revision 1.40  2011/06/10 23:13:33  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.39  2011/03/23 20:42:51  mwtjc1
 *  todo added
 *
 *  Revision 1.38  2011/03/15 17:44:44  mwyxg1
 *  add photoRequired
 *
 *  Revision 1.37  2011/01/30 09:04:07  mwhxb3
 *  Added new fields
 *
 *  Revision 1.36  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.35  2010/12/07 03:56:07  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.34  2010/12/02 00:15:46  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.33  2010/10/29 16:57:07  mwuxb
 *  Removed existingBirthDate. Person has now existing birth date.
 *
 *  Revision 1.32  2010/08/24 01:27:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.31  2010/08/21 21:12:36  mwtjc1
 *  getIdCardNumber and getDriverLicenseNumber method added
 *
 *  Revision 1.30  2010/08/17 19:24:01  mwcsj3
 *  Added helper method to get Id Card
 *
 *  Revision 1.29  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.28  2010/07/08 00:18:14  mwuxb
 *  Added variables transactionCode, existingBirthDate
 *
 *  Revision 1.27  2010/06/26 16:50:21  mwuxb
 *  Added methods to determine pending segments A and B
 *
 *  Revision 1.26  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.20.8.2  2010/06/20 18:07:13  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.25  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.24  2010/06/04 20:37:59  mwtjc1
 *  echoedHitCounter removed as hitCounter already exists in DlRecord
 *
 *  Revision 1.23  2010/06/04 20:25:10  mwtjc1
 *  echoedHitCounter added
 *
 *  Revision 1.22  2010/06/03 16:57:24  mwuxb
 *  added variable echoedIdCard
 *
 *  Revision 1.21  2010/06/03 16:48:25  mwuxb
 *  added variable echoedDriverLicense
 *
 *  Revision 1.20  2010/05/01 17:45:20  mwuxb
 *  Updated
 *
 *  Revision 1.19  2010/05/01 17:32:25  mwuxb
 *  Pushed down variables in segment E to EliRecord from DlRecord
 *
 *  Revision 1.18  2010/04/28 20:11:02  mwtjc1
 *  updated
 *
 *  Revision 1.17  2010/04/28 18:33:20  mwtjc1
 *  updated
 *
 *  Revision 1.16  2010/04/28 18:30:58  mwtjc1
 *  updated
 *
 *  Revision 1.15  2010/04/24 20:40:27  mwuxb
 *  updates for segment C
 *
 *  Revision 1.14  2010/04/24 20:31:58  mwuxb
 *  updates for segment C
 *
 *  Revision 1.13  2010/04/24 20:24:35  mwuxb
 *  updates for segment C
 *
 *  Revision 1.12  2010/04/24 19:14:36  mwuxb
 *  updates for segment C
 *
 *  Revision 1.11  2010/04/23 22:30:11  mwtjc1
 *  updated
 *
 *  Revision 1.10  2010/04/23 22:29:25  mwtjc1
 *  updated
 *
 *  Revision 1.9  2010/04/23 22:25:47  mwtjc1
 *  updated
 *
 *  Revision 1.8  2010/04/22 18:45:59  mwuxb
 *  Added SSN verification codes for pending segments.
 *
 *  Revision 1.7  2010/04/22 16:00:48  mwtjc1
 *  errorMessage field is moved from EliRecord to DlmRecord
 *
 *  Revision 1.6  2010/04/21 01:05:45  mwuxb
 *  Moved person to DlRecord
 *
 *  Revision 1.5  2010/04/21 00:57:45  mwuxb
 *  Updated to extend DlRecord
 *
 *  Revision 1.4  2010/04/21 00:54:57  mwuxb
 *  Added AbstractDlRecord
 *
 *  Revision 1.3  2010/04/20 17:08:36  mwtjc1
 *  setSegment is removed and addSegment method is added
 *
 *  Revision 1.2  2010/04/20 17:01:20  mwuxb
 *  Added attribute segments
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.84  2010/04/14 23:12:17  mwuxb
 *  Added helper methods
 *
 *  Revision 1.83  2010/04/14 18:55:53  mwuxb
 *  Added helper method for driver license record.
 *
 *  Revision 1.82  2010/04/10 01:04:21  mwuxb
 *  bulk cleanup
 *
 *  Revision 1.81  2010/04/09 23:48:47  mwuxb
 *  Updated
 *
 *  Revision 1.80  2010/04/08 02:40:05  mwuxb
 *  Removed legalPresenceInquiryIndicator
 *
 *  Revision 1.79  2010/04/06 00:50:44  mwuxb
 *  Removed deprecated entries.
 *
 *  Revision 1.78  2010/04/02 18:17:39  mwuxb
 *  Changed Date to year for attribute dlExpirationDateOfPreviousRecord
 *
 *  Revision 1.77  2010/04/01 23:18:28  mwuxb
 *  Removed suspenseDueDate
 *
 *  Revision 1.76  2010/04/01 22:36:55  mwuxb
 *  Updated DriverLicenseFee to InvoiceItem
 *
 *  Revision 1.75  2010/03/31 22:48:03  mwuxb
 *  Updated
 *
 *  Revision 1.74  2010/03/31 20:20:59  mwuxb
 *  Updated with type CodeSetElement
 *
 *  Revision 1.73  2010/03/31 18:53:33  mwuxb
 *  Updated segment C attributes from String to CodeSetElement
 *
 *  Revision 1.72  2010/03/31 18:47:14  mwuxb
 *  Updated segment C attributes from String to CodeSetElement
 *
 *  Revision 1.71  2010/03/31 18:39:53  mwuxb
 *  Updated segment C attributes from String to CodeSetElement
 *
 *  Revision 1.70  2010/03/31 18:19:19  mwtjc1
 *  updated
 *
 *  Revision 1.69  2010/03/31 18:15:31  mwtjc1
 *  updated
 *
 *  Revision 1.68  2010/03/31 18:12:07  mwtjc1
 *  updated
 *
 *  Revision 1.67  2010/03/31 17:57:31  mwtjc1
 *  updated
 *
 *  Revision 1.66  2010/03/31 17:54:49  mwtjc1
 *  updated
 *
 *  Revision 1.65  2010/03/31 17:36:50  mwtjc1
 *  updated
 *
 *  Revision 1.64  2010/03/31 17:34:08  mwtjc1
 *  updated
 *
 *  Revision 1.63  2010/03/31 17:31:20  mwtjc1
 *  updated
 *
 *  Revision 1.62  2010/03/31 17:29:25  mwtjc1
 *  updated
 *
 *  Revision 1.61  2010/03/31 17:27:21  mwtjc1
 *  updated
 *
 *  Revision 1.60  2010/03/31 17:25:04  mwtjc1
 *  updated
 *
 *  Revision 1.59  2010/03/31 17:21:57  mwtjc1
 *  updated
 *
 *  Revision 1.58  2010/03/31 17:19:20  mwtjc1
 *  updated
 *
 *  Revision 1.57  2010/03/31 17:17:14  mwtjc1
 *  updated
 *
 *  Revision 1.56  2010/03/31 17:15:23  mwtjc1
 *  updated
 *
 *  Revision 1.55  2010/03/31 17:12:44  mwtjc1
 *  updated
 *
 *  Revision 1.54  2010/03/31 17:10:59  mwtjc1
 *  updated
 *
 *  Revision 1.53  2010/03/31 16:59:40  mwtjc1
 *  updated
 *
 *  Revision 1.52  2010/03/31 16:57:15  mwtjc1
 *  updated
 *
 *  Revision 1.51  2010/03/31 16:52:38  mwtjc1
 *  updated
 *
 *  Revision 1.50  2010/03/31 16:51:02  mwtjc1
 *  updated
 *
 *  Revision 1.49  2010/03/31 16:48:07  mwtjc1
 *  updated
 *
 *  Revision 1.48  2010/03/31 16:45:33  mwtjc1
 *  updated
 *
 *  Revision 1.47  2010/03/31 16:41:49  mwtjc1
 *  updated
 *
 *  Revision 1.46  2010/03/31 16:36:07  mwtjc1
 *  updated
 *
 *  Revision 1.45  2010/03/30 21:57:00  mwuxb
 *  Moved isMailToTemporaryAddress from Dlapplication to License class so removed from this class.
 *
 *  Revision 1.44  2010/03/30 21:17:13  mwtjc1
 *  updated
 *
 *  Revision 1.43  2010/03/30 21:05:28  mwuxb
 *  Updated attribute isMailToTemporaryAddressIndicator to Boolean
 *
 *  Revision 1.42  2010/03/30 20:11:26  mwtjc1
 *  updated
 *
 *  Revision 1.41  2010/03/29 20:33:15  mwuxb
 *  Removed existing application reason codes. They should be accessed from DL or ID class.
 *
 *  Revision 1.40  2010/03/27 23:31:40  mwuxb
 *  Removed attribute previousRenewalIssueDate - will use DriverLicense. lastRenewalDate
 *
 *  Revision 1.39  2010/03/27 23:06:57  mwtjc1
 *  updated
 *
 *  Revision 1.38  2010/03/27 21:38:23  mwuxb
 *  Changed eligibleForEarlyCDSRenewal to eligibleForEarlyCDLRenewal
 *
 *  Revision 1.37  2010/03/27 21:25:18  mwuxb
 *  Changed discSuspensionOrRevocation to discretionarySuspensionOrRevocation
 *
 *  Revision 1.36  2010/03/27 20:24:03  mwtjc1
 *  updated
 *
 *  Revision 1.35  2010/03/27 18:33:14  mwuxb
 *  Updated existingIncompleteApplicationReasonCode to have two separate variables for DL and ID
 *
 *  Revision 1.34  2010/03/27 00:35:29  mwhxa2
 *  updated data types for Segment C
 *
 *  Revision 1.33  2010/03/26 23:45:18  mwhxa2
 *  updated data types for Segment C
 *
 *  Revision 1.32  2010/03/26 23:40:50  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.31  2010/03/26 23:32:36  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.30  2010/03/26 22:49:36  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.29  2010/03/26 22:31:18  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.28  2010/03/26 21:55:16  mwhxa2
 *  Added Segment C Attributes and Action Messages
 *
 *  Revision 1.26  2010/03/26 17:00:04  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.25  2010/03/26 00:05:21  mwtjc1
 *  errorCode is changed to errorMessage
 *
 *  Revision 1.24  2010/03/25 23:05:03  mwuxb
 *  Added more attributes for segment E
 *
 *  Revision 1.23  2010/03/22 20:51:39  mwuxb
 *  Added attribute militaryDutyCode
 *
 *  Revision 1.22  2010/03/22 17:19:22  mwuxb
 *  Added more attributes
 *
 *  Revision 1.21  2010/03/20 22:55:06  mwuxb
 *  Added more attributes
 *
 *  Revision 1.20  2010/03/20 21:41:28  mwuxb
 *  Added DriverLicenseFee attribute
 *
 *  Revision 1.19  2010/03/20 21:30:05  mwuxb
 *  Changed credit card payment attribute from String to Boolean
 *
 *  Revision 1.18  2010/03/20 20:26:59  mwuxb
 *  Added driver education and training codes
 *
 *  Revision 1.17  2010/03/20 18:44:35  mwuxb
 *  Added getters and setters for attributes.
 *
 *  Revision 1.16  2010/03/20 18:40:04  mwuxb
 *  Added many attributes for dl inquiry response
 *
 *  Revision 1.15  2010/03/20 17:59:00  mwuxb
 *  Added attribute writtenDriveTestIndicator
 *
 *  Revision 1.14  2010/03/19 01:14:19  mwvxm6
 *  Updated AniRecord to use only required attributes instead of Person
 *
 *  Revision 1.13  2010/03/19 00:30:00  mwuxb
 *  Added many attributes for dl inquiry response
 *
 *  Revision 1.12  2010/03/18 17:52:45  mwuxb
 *  Added attributes existingLicenseClassesOfPreviousRecord and dlExpirationDateOfPreviousRecord
 *
 *  Revision 1.11  2010/03/18 00:35:38  mwuxb
 *  Added attributes for cdlis and errorcode
 *
 *  Revision 1.10  2010/03/17 02:40:59  mwuxb
 *  Added many attributes for dl inquiry response
 *
 *  Revision 1.9  2010/03/15 23:00:13  mwhxa2
 *  Implements serializable
 *
 *  Revision 1.8  2010/03/03 16:08:26  mwrsk
 *  cleanup imports
 *
 *  Revision 1.7  2010/02/09 20:37:59  mwrsk
 *  Pull up person to DLRecord
 *
 *  Revision 1.6  2010/02/08 22:25:05  mwrsk
 *  Refactor person.applicantDocuments to person.documents
 *
 *  Revision 1.5  2010/02/08 17:31:55  mwrsk
 *  CHanged getApplicant to getPerson & setApplicant to setPerson
 *
 *  Revision 1.4  2010/01/28 22:21:40  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/12 01:08:40  mwhxa2
 *  Fixed compilation issues
 *
 *  Revision 1.2  2010/01/06 00:01:55  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/09/21 22:10:29  mwcsj3
 *  Removed IdCard variable
 *
 *  Revision 1.4  2009/09/16 18:03:43  mwsyk1
 *  ID card added
 *
 *  Revision 1.3  2009/08/27 05:39:52  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/13 22:50:18  mwcsj3
 *  Added SocialSecurityDocument and LegalPresenceDocument
 *
 *  Revision 1.1  2009/08/12 00:36:14  mwrrv3
 *  Refactored the code.
 *
 */
