/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: Organization is child of Subject and encapsulates ID of 
 * an organization.Organization is a super class for business entities like 
 * dealer, financial institutions, registration service, auto clubs etc.
 * File: OrganizationName.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: Aug 12, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/08/10 21:58:35 $
 * Last Changed By: $Author: mwhys $
 */
public class OrganizationName extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6934206577628149359L;
	/** The DBA Name.*/
	private String dbaName;
	/** The Name.*/
	private String name;
	
	/**
	 * Instantiates a new organization name.
	 */
	public OrganizationName() {
	}
	
	/**
	 * Instantiates a new organization name.
	 *
	 * @param organizationName the organization name
	 */
	public OrganizationName(OrganizationName organizationName) {
		super();
		copy(organizationName);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(OrganizationName dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null organizationName argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		//Copy dbaName
		setDbaName(dataToCopy.getDbaName());
		//Copy  name
		setName(dataToCopy.getName());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		OrganizationName other = (OrganizationName) obj;
		if (dbaName == null) {
			if (other.dbaName != null) {
				return false;
			}
		}
		else if (!dbaName.equals(other.dbaName)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		}
		else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the DBA Name.
	 * 
	 * @return the dbaName
	 */
	public String getDbaName() {
		return dbaName;
	}
	
	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((dbaName == null) ? 0 : dbaName.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	/**
	 * Sets the DBA Name.
	 * 
	 * @param dbaName the dbaName to set
	 */
	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}
	
	/**
	 * Sets the name.
	 * 
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("name", name, anIndent, aBuilder);
		outputKeyValue("dbaName", dbaName, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OrganizationName.java,v $
 *  Revision 1.7  2011/08/10 21:58:35  mwhys
 *  Added copy constructor.
 *
 *  Revision 1.6  2010/12/07 22:11:39  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 03:57:52  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.4  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/06/21 23:01:00  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.8.2  2010/06/20 18:07:11  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/03 00:22:28  mwvxm6
 *  Updated equals method
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/01/28 22:48:46  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/12 02:47:11  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.7  2009/09/10 04:35:58  mwsmg6
 *  LicenseClass
 *
 *  Revision 1.6  2009/08/27 05:39:48  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.4  2009/08/13 00:38:32  mwrrv3
 *  Formatted and added comments.
 *
 *  Revision 1.3  2009/07/14 23:44:26  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:29:53  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-12 00:55:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 4:40:01 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 4:40:01 PM  MWCSJ3
 *  $Initial
 *  $
 */
