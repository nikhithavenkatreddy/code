/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am request to Inventory Service to seed the repository with the data from DMVA
 * 
 * File: SeedInventoryFromDmvaRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2011/09/23 00:20:29 $
 * Last Changed By: $Author: mwkfh $
 */
public class SeedInventoryFromDmvaRequest extends AbstractInventoryItemsRequest
		implements IInventoryItemsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8395765673837938504L;
	/** The all sequences. */
	private List <IContiguousItemSequence> allSequences;
	/** Office Id to purge */
	private String officeId;
	/** Processor Id to purge */
	private String processorId;

	/**
	 * Instantiates a new seed inventory from dmva request.
	 */
	protected SeedInventoryFromDmvaRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected SeedInventoryFromDmvaRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Instantiates a new seed inventory from dmva request.
	 * 
	 * @param context the context
	 * @param sequences the sequences
	 */
	public SeedInventoryFromDmvaRequest(IUserContext context,
			IContiguousItemSequence[] sequences) {
		super(context);
		setAllSequencesFrom(sequences);
	}

	/**
	 * Instantiates a new seed inventory from dmva request.
	 * 
	 * @param aSequenceList the a sequence list
	 */
	public SeedInventoryFromDmvaRequest(IUserContext context,
			List <IContiguousItemSequence> aSequenceList) {
		super(context);
		setAllSequences(aSequenceList);
	}

	/**
	 * Instantiates a new seed inventory from dmva request.
	 * 
	 * @param context the context
	 * @param officeId the office id to purge
	 * @param sequences the sequences
	 */
	public SeedInventoryFromDmvaRequest(IUserContext context, String officeId,
			IContiguousItemSequence[] sequences) {
		super(context);
		setAllSequencesFrom(sequences);
		setOfficeId(officeId);
	}

	/**
	 * Instantiates a new seed inventory from dmva request.
	 * 
	 * @param context the context
	 * @param officeId the office id to purge
	 * @param processorId the processor id to purge
	 * @param aSequenceList the a sequence list
	 */
	public SeedInventoryFromDmvaRequest(IUserContext context, String officeId,
			String processorId, List <IContiguousItemSequence> aSequenceList) {
		super(context);
		setAllSequences(aSequenceList);
		setOfficeId(officeId);
		setProcessorId(processorId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}

	/**
	 * Gets the all sequences.
	 * 
	 * @return the all sequences
	 */
	public List <IContiguousItemSequence> getAllSequences() {
		if (allSequences == null)
			setAllSequences(new ArrayList <IContiguousItemSequence>());
		return allSequences;
	}

	/**
	 * Gets the all sequences item count.
	 * 
	 * @return the all sequences item count
	 */
	private int getAllSequencesItemCount() {
		if (allSequences == null) {
			return 0;
		}
		else {
			int count = 0;
			for (IContiguousItemSequence aSeq : getAllSequences()) {
				count += aSeq.getItemCount();
			}
			return count;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		return getAllSequencesItemCount();
	}

	/**
	 * Gets the item list.
	 * 
	 * @return the item list
	 */
	public List <IInventoryItem> getItemList() {
		List <IInventoryItem> anItemList = new ArrayList <IInventoryItem>(
				getAllSequencesItemCount());
		for (IContiguousItemSequence aSeq : getAllSequences()) {
			anItemList.addAll(aSeq.asItemList());
		}
		return anItemList;
	}

	/**
	 * Gets the office id
	 * 
	 * @return
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Gets the processor id
	 * 
	 * @return the processorId
	 */
	public String getProcessorId() {
		return processorId;
	}

	/**
	 * Sets the all sequences.
	 * 
	 * @param allSequences the new all sequences
	 */
	protected void setAllSequences(List <IContiguousItemSequence> allSequences) {
		this.allSequences = allSequences;
	}

	/**
	 * Sets the all sequences from.
	 * 
	 * @param sequences the new all sequences from
	 */
	private void setAllSequencesFrom(IContiguousItemSequence[] sequences) {
		for (IContiguousItemSequence sequence : sequences) {
			getAllSequences().add(sequence);
		}
	}

	/** 
	 * Sets the office id
	 * 
	 * @param officeId
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Sets the processor id
	 * 
	 * @param processorId the processorId to set
	 */
	public void setProcessorId(String processorId) {
		this.processorId = processorId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SeedInventoryFromDmvaRequest.java,v $
 *  Revision 1.8  2011/09/23 00:20:29  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.7  2011/01/10 21:48:06  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.6  2010/10/07 21:13:54  mwbxg3
 *  Added lazy initialization for allSequences in getAllSequences.
 *
 *  Revision 1.5  2010/10/07 17:15:48  mwkfh
 *  split getItem and getItemList into separate interfaces from IInventoryRequest
 *
 *  Revision 1.4  2010/10/05 17:40:57  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.3  2010/09/23 21:20:38  mwpxp2
 *  Added ... constructor
 *
 *  Revision 1.2  2010/09/20 23:19:30  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.7  2010/09/15 19:08:32  mwpxp2
 *  Added getItemList/0
 *
 *  Revision 1.6  2010/09/14 23:59:33  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.5  2010/09/14 19:00:26  mwpxp2
 *  Added 2-arg constructor, removed 1-arg one
 *
 *  Revision 1.4  2010/09/13 04:42:10  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/09/02 20:44:54  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.2  2010/09/01 00:36:05  mwpxp2
 *  Added concrete execute/0
 *
 *  Revision 1.1  2010/08/31 23:52:27  mwpxp2
 *  Initial
 *
 */
