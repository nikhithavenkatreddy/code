/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request for simple adding items to an inventory
 * Each item has information about its target location
 * 
 * File: AddInventoryItemRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/20 23:19:30 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AddInventoryItemRequest extends AbstractMultipleItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8448814063702987450L;

	/**
	 * Instantiates a new adds the inventory item request.
	 */
	protected AddInventoryItemRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param items the items
	 */
	public AddInventoryItemRequest(IUserContext context,
			IInventoryItem... items) {
		super(context, items);
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param listOfItems the list of items
	 */
	public AddInventoryItemRequest(IUserContext context,
			List <IInventoryItem> listOfItems) {
		super(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AddInventoryItemRequest.java,v $
 *  Revision 1.2  2010/09/20 23:19:30  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/14 18:59:36  mwpxp2
 *  Initial
 *
 */
