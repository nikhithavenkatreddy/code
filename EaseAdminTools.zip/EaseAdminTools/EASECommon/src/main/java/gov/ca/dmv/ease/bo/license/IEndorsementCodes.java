/**
 * 
 */
package gov.ca.dmv.ease.bo.license;


/**
 * Description: Interface to define the endorsement code constants
 * File: IEndorsementCodes.java
 * Module:  gov.ca.dmv.ease.bo.license
 * Created: Jan 4, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/04/17 22:26:47 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface IEndorsementCodes {

	/** The Constant DOUBLE_TRIPLE. */
	 String DOUBLE_TRIPLE = "DT";
	 /** The Constant HAZARDOUS_MATERIAL. */
	 String HAZARDOUS_MATERIAL = "HM";
	 /** The Constant PASSENGER_VEH. */
	 String PASSENGER_VEH = "PV";
	 /** The Constant SCHOOL_BUS. */
	 String SCHOOL_BUS = "SB";
	 /** The Constant TANK_VEHICLE. */
	 String TANK_VEHICLE = "TV";
	 
	 /** The Constant FIRE_FIGHTER_CLASSS_A. */
	 String FIRE_FIGHTER_CLASSS_A = "1";
	 /** The Constant FIRE_FIGHTER_CLASSS_B. */
	 String FIRE_FIGHTER_CLASSS_B = "2";
	 /** The Constant TRAILER_COACH. */
	 String TRAILER_COACH = "3";
}


/**
 *  Modification History:
 *
 *  $Log: IEndorsementCodes.java,v $
 *  Revision 1.2  2012/04/17 22:26:47  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/03/02 01:04:00  mwgxd3
 *  Added constants for categories
 *
 *  Revision 1.1.2.1  2012/02/15 19:39:39  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */