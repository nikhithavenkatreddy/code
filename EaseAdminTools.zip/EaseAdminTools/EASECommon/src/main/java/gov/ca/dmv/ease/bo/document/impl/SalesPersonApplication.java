/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.license.impl.SalesPersonLicense;
import gov.ca.dmv.ease.bo.subject.impl.VehicleSalesPerson;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: SalesPerson Application class is the subclass of Application and
 * represents the SalesPerson application document. SP Application object encapsulates
 * most of the attributes of SP Application used for obtaining sp license.
 * File: SpApplication.java
 * Module: gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 7, 2010
 * @author mwvxm6
 * @version $Revision: 1.14 $
 * Last Changed: $Date: 2013/02/06 18:42:26 $
 * Last Changed By: $Author: mwskh1 $
 */
public class SalesPersonApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7003276619308844896L;
	/** The acceptRecordIndicator */
	private CodeSetElement acceptRecordIndicator;
	/** The SalesPerson license applicant. */
	private VehicleSalesPerson applicant;
	// These attributes come from HQ inquiry for the SP applicant !!!
	/*	*//** The dl or Id Number. */
	/*
			private String dlOrIdNumber;
			*//** The dl Expiration Date. */
	/*
			private Date dlExpirationDate;
			*//** The id Expiration Date. */
	/*
			private Date idExpirationDate;*/
	/** The application types like Original/Renewal/Reinstatement. */
	private CodeSetElement applicationTypeCode;
	/** The finger Print required code for this license application. */
	private Boolean fingerPrintRequired;
	/** The Current Application Reason Code. */
	private CodeSetElement newIncompleteApplicationReasonCode;

	/**
	 * Default Constructor.
	 */
	public SalesPersonApplication() {
		super();
	}

	/**
	 * Get the acceptRecordIndicator.
	 *
	 * @return the acceptRecordIndicator
	 */
	public CodeSetElement getAcceptRecordIndicator() {
		return acceptRecordIndicator;
	}

	/**
	 * Gets the Applicant.
	 * 
	 * @return the applicant
	 */
	public VehicleSalesPerson getApplicant() {
		return applicant;
	}

	/**
	 * Gets the Application Type Code.
	 * 
	 * @return the applicationTypeCode
	 */
	@Override
	public CodeSetElement getApplicationTypeCode() {
		return applicationTypeCode;
	}

	/**
	 * Gets the Driver License.
	 * Driver License is associated with an Applicant.
	 * 
	 * @return the license
	 */
	public SalesPersonLicense getLicense() {
		if (EaseUtil.isNotNull(this.applicant)) {
			return this.applicant.getSalesPersonLicense();
		}
		else {
			return null;
		}
	}

	/**
	 * Gets New Incomplete Application Reason Code.
	 * 
	 * @return the newIncompleteApplicationReasonCode
	 */
	public CodeSetElement getNewIncompleteApplicationReasonCode() {
		return newIncompleteApplicationReasonCode;
	}

	/**
	 * @return the fingerPrintRequired
	 */
	public Boolean isFingerPrintRequired() {
		return fingerPrintRequired;
	}

	/**
	 * Set acceptRecordIndicator.
	 *
	 * @param acceptRecordIndicator the acceptRecordIndicator to set
	 */
	public void setAcceptRecordIndicator(CodeSetElement indicator) {
		acceptRecordIndicator = indicator;
	}

	/**
	 * Sets the Applicant.
	 * 
	 * @param applicant the applicant to set
	 */
	public void setApplicant(VehicleSalesPerson applicant) {
		this.applicant = applicant;
	}

	/**
	 * Sets the Application Type Code.
	 * 
	 * @param applicationTypeCode the applicationTypeCode to set
	 */
	@Override
	public void setApplicationTypeCode(CodeSetElement applicationTypeCode) {
		this.applicationTypeCode = applicationTypeCode;
	}

	/**
	 * @param fingerPrintRequired the fingerPrintRequired to set
	 */
	public void setFingerPrintRequired(Boolean fingerPrintRequired) {
		this.fingerPrintRequired = fingerPrintRequired;
	}

	/**
	 * Sets the Driver License.
	 * Driver License is associated with an Applicant.
	 * 
	 * @param license the license to set
	 */
	public void setLicense(SalesPersonLicense license) {
		this.applicant.setSalesPersonLicense(license);
	}

	/**
	 * Sets the New Incomplete Application Reason Code.
	 * @param newIncompleteApplicationReasonCode the newIncompleteApplicationReasonCode to set
	 */
	public void setNewIncompleteApplicationReasonCode(
			CodeSetElement newIncompleteApplicationReasonCode) {
		this.newIncompleteApplicationReasonCode = newIncompleteApplicationReasonCode;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("applicant", applicant, anIndent, aBuilder);
		outputKeyValue("applicationTypeCode", applicationTypeCode, anIndent,
				aBuilder);
		outputKeyValue("fingerPrintRequired", fingerPrintRequired, anIndent,
				aBuilder);
		outputKeyValue("newIncompleteApplicationReasonCode",
				newIncompleteApplicationReasonCode, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SalesPersonApplication.java,v $
 *  Revision 1.14  2013/02/06 18:42:26  mwskh1
 *  added $Log
 *
*/
