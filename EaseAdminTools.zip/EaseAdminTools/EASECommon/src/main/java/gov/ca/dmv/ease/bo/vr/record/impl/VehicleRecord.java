/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.vr.record.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Description: The Vehicle Record class to be used for the inquiry search criteria.
 * This is not the complete Vehicle bo that will be used in VR but a container to be used in DL
 * File: VehicleRecord.java
 * Module:  gov.ca.dmv.ease.bo.vr.record.impl
 * Created: May 4, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2010/11/19 19:02:39 $
 * Last Changed By: $Author: mwhys $
 */
public class VehicleRecord implements Serializable {
	/** The constant serialVersionUID */
	private static final long serialVersionUID = -654811522930114401L;
	private Boolean isVehicleRoHistoryIndicator;
	/** The Registered Owner of the Vehicle. */
	private List <String> registeredOwnerNames;
	private Date vehicleAsOfDate;
	private CodeSetElement vehicleFileCode;
	private String vehicleLicensePlateNumber;
	private String vehicleMake;
	private String vehicleVin;
	private String vehicleYearModel;

	/**
	 * @return the registeredOwnerNames
	 */
	public List <String> getRegisteredOwnerNames() {
		return registeredOwnerNames;
	}

	/**
	 * @return the vehicleAsOfDate
	 */
	public Date getVehicleAsOfDate() {
		return vehicleAsOfDate;
	}

	/**
	 * @return the vehicleFileCode
	 */
	public CodeSetElement getVehicleFileCode() {
		return vehicleFileCode;
	}

	/**
	 * @return the vehicleLicenseNumber
	 */
	public String getVehicleLicensePlateNumber() {
		return vehicleLicensePlateNumber;
	}

	/**
	 * @return the vehicleMake
	 */
	public String getVehicleMake() {
		return vehicleMake;
	}

	/**
	 * @return the vehicleVin
	 */
	public String getVehicleVin() {
		return vehicleVin;
	}

	/**
	 * @return the vehicleYearModel
	 */
	public String getVehicleYearModel() {
		return vehicleYearModel;
	}

	/**
	 * @return the isVehicleRoHistoryIndicator
	 */
	public boolean isVehicleRoHistoryIndicator() {
		return isVehicleRoHistoryIndicator;
	}

	/**
	 * @param registeredOwnerNames the registeredOwnerNames to set
	 */
	public void setRegisteredOwnerNames(List <String> registeredOwnerNames) {
		this.registeredOwnerNames = registeredOwnerNames;
	}

	/**
	 * @param vehicleAsOfDate the vehicleAsOfDate to set
	 */
	public void setVehicleAsOfDate(Date vehicleAsOfDate) {
		this.vehicleAsOfDate = vehicleAsOfDate;
	}

	/**
	 * @param vehicleFileCode the vehicleFileCode to set
	 */
	public void setVehicleFileCode(CodeSetElement vehicleFileCode) {
		this.vehicleFileCode = vehicleFileCode;
	}

	/**
	 * @param vehicleLicenseNumber the vehicleLicenseNumber to set
	 */
	public void setVehicleLicensePlateNumber(String vehicleLicenseNumber) {
		this.vehicleLicensePlateNumber = vehicleLicenseNumber;
	}

	/**
	 * @param vehicleMake the vehicleMake to set
	 */
	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	/**
	 * @param isVehicleRoHistoryIndicator the isVehicleRoHistoryIndicator to set
	 */
	public void setVehicleRoHistoryIndicator(boolean isVehicleRoHistoryIndicator) {
		this.isVehicleRoHistoryIndicator = isVehicleRoHistoryIndicator;
	}

	/**
	 * @param vehicleVin the vehicleVin to set
	 */
	public void setVehicleVin(String vehicleVin) {
		this.vehicleVin = vehicleVin;
	}

	/**
	 * @param vehicleYearModel the vehicleYearModel to set
	 */
	public void setVehicleYearModel(String vehicleYearModel) {
		this.vehicleYearModel = vehicleYearModel;
	}
}
/**
 *  Modification History:
 *
 *  $Log: VehicleRecord.java,v $
 *  Revision 1.9  2010/11/19 19:02:39  mwhys
 *  implements Serializable
 *
 *  
 */
