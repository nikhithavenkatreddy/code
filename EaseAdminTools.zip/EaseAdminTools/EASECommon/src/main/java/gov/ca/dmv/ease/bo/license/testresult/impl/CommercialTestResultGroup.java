/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.testresult.CommercialTestResultType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: This class holds Commercial Test Results Information.
 * File: CommercialTestResultGroup.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult.impl
 * Created: Jan 6, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.18 $
 * Last Changed: $Date: 2012/08/15 16:23:22 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class CommercialTestResultGroup extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2303974706334199952L;
	/** Holds Commercial Test Result Items. */
	private List <CommercialTestResult> commercialTestResults = new ArrayList <CommercialTestResult>();
	
	/**
	 * Default Constructor.
	 */
	public CommercialTestResultGroup() {
		super();
	}
	
	/**
	 * Instantiates a new commercial test result group.
	 *
	 * @param another the another
	 */
	public CommercialTestResultGroup(CommercialTestResultGroup objectToCopy) {
		super();
		copy(objectToCopy);
	}
	
	/**
	 * Adds the commercial test result.
	 * 
	 * @param commercialTestResult the commercial test result
	 */
	public void addCommercialTestResult(
			CommercialTestResult commercialTestResult) {
		//Check if Results is not null
		if (!EaseUtil.isNotNull(commercialTestResults)) {
			commercialTestResults = new ArrayList <CommercialTestResult>();
		}
		commercialTestResults.add(commercialTestResult);
	}
	
	/**
	 * Copy.
	 *
	 * @param another the another
	 */
	private void copy(CommercialTestResultGroup objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null CommercialTestResultGroup argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		if (EaseUtil.isNotNull(objectToCopy.getCommercialTestResults())) {
			for (CommercialTestResult commercialTestResult : objectToCopy
					.getCommercialTestResults()) {
				if (EaseUtil.isNotNull(commercialTestResult)) {
					commercialTestResults.add(new CommercialTestResult(
							commercialTestResult));
				}
			}
		}
	}
	
	/**
	 * Delete commercial test result.
	 *
	 * @param aCommercialTestResult the a commercial test result
	 * @return true, if successful
	 */
	public boolean deleteCommercialTestResult(
			CommercialTestResult aCommercialTestResult) {
		boolean isDeleted = false;
		//Check if Results is not null
		if (EaseUtil.isNotNull(aCommercialTestResult)) {
			isDeleted = commercialTestResults.remove(aCommercialTestResult);
		}
		return isDeleted;
	}
	
	/**
	 * This method removes the last commercial test result from the list of 
	 * test results; for input commercial test result type.
	 * 
	 * Removes the last commercial test result of the input type.
	 * 
	 * @param commercialTestResultType the input commercial test result type
	 * @return true if removed from the test results
	 */
	public boolean deleteCommercialTestResult(
			CommercialTestResultType commercialTestResultType) {
		boolean isDeleted = false;
		//Check if Results is not null
		if (!EaseUtil.isNullOrBlank(commercialTestResults)) {
			int lastIndex = commercialTestResults.size() - 1;
			//iterate in reverse
			for (int i = lastIndex; i >= 0; i--) {
				if (commercialTestResults.get(i).getCommercialTestResultType()
						.equals(commercialTestResultType)) {
					commercialTestResults.remove(i);
					isDeleted = true;
					break;
				}
			}
		}
		return isDeleted;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommercialTestResultGroup other = (CommercialTestResultGroup) obj;
		if (commercialTestResults == null) {
			if (other.commercialTestResults != null)
				return false;
		}
		else if (!commercialTestResults.equals(other.commercialTestResults))
			return false;
		return true;
	}
	
	/**
	 * Gets the commercial test results.
	 *
	 * @return the commercial test results
	 */
	private List <CommercialTestResult> getCommercialTestResults() {
		return commercialTestResults;
	}
	
	/**
	 * This method returns Commercial Results for the given Commercial Test Result Type.
	 *
	 * @param comercialTestResultType the comercial test result type
	 * @return list of Required Commercial Test Results
	 * @see CommercialTestResult
	 */
	public List <CommercialTestResult> getCommercialTestResults(
			CommercialTestResultType comercialTestResultType) {
		List <CommercialTestResult> requiredCommercialTestResults = new ArrayList <CommercialTestResult>();
		//Check if Results exist
		if (!EaseUtil.isNullOrBlank(commercialTestResults)) {
			//Iterate the Test Results
			for (CommercialTestResult commercialTestResult : commercialTestResults) {
				//Check if Result Type exists
				if (!EaseUtil.isNullOrBlank(commercialTestResult
						.getCommercialTestResultType())
						&& commercialTestResult.getCommercialTestResultType()
								.equals(comercialTestResultType)) {
					//Add to return list
					requiredCommercialTestResults.add(commercialTestResult);
				}
			}
		}
		return requiredCommercialTestResults;
	}
	

	
	/**
	 * This method returns Commercial Results for the given Commercial Test Result Type.
	 * To be used for AMCKTS waive tests only.
	 * @param comercialTestResultType the comercial test result type
	 * @return list of Required Commercial Test Results
	 * @see CommercialTestResult
	 */
	public boolean isCommercialTestWaived(
			CommercialTestResultType comercialTestResultType, String testResultType) {
		Object passedCodes [] = { "P", "S", "A"};
		//Check if Results exist
		if (!EaseUtil.isNullOrBlank(commercialTestResults)) {
			//Iterate the Test Results
			for (CommercialTestResult commercialTestResult : commercialTestResults) {
				//Check if Result Type exists
				if (!EaseUtil.isNullOrBlank(commercialTestResult
						.getCommercialTestResultType())
						&& commercialTestResult.getCommercialTestResultType()
								.equals(comercialTestResultType)
						&& (testResultType.equalsIgnoreCase(commercialTestResult.getTestResultCode().getCode())||
								//Do not waive exams previously failed;
								!(ArrayUtils.contains(commercialTestResult.getTestResultCode().getCode(), passedCodes)))) {
					//Add to return list
					return true;
				}
			}
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((commercialTestResults == null) ? 0 : commercialTestResults
						.hashCode());
		return result;
	}
	
	/**
	 * Return true if commercialTestResults list is Empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return commercialTestResults == null || commercialTestResults.isEmpty();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CommercialTestResultGroup.java,v $
 *  Revision 1.18  2012/08/15 16:23:22  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.17  2012/07/23 23:41:05  mwgxd3
 *  AKTS - defect 32
 *
 *  Revision 1.16  2012/07/18 01:12:07  mwgxd3
 *  AKTS defect 32
 *
 *  Revision 1.15  2011/04/07 04:04:56  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.14.2.5  2011/04/05 21:03:16  mwhys
 *  Refactored.
 *
 *  Revision 1.14.2.4  2011/04/05 19:14:07  mwark
 *  Modified the copy constructors for the null checks.
 *
 *  Revision 1.14.2.3  2011/04/03 20:39:19  mwrka1
 *  updated for cloning
 *
 *  Revision 1.14.2.2  2011/04/03 19:48:49  mwrka1
 *  modified varible name
 *
 *  Revision 1.14.2.1  2011/04/03 19:46:28  mwrka1
 *  added copy constructor
 *
 *  Revision 1.14  2011/02/11 23:03:46  mwkfh
 *  clean up
 *
 *  Revision 1.13  2011/02/11 23:02:13  mwkfh
 *  added isEmpty method
 *
 *  Revision 1.12  2010/12/24 22:09:16  mwrka1
 *  deleteCommercialTestResult added
 *
 *  Revision 1.11  2010/12/02 00:15:46  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.10  2010/08/10 17:52:26  mwhxa2
 *  Removing getter for commercialTestResults
 *
 *  Revision 1.9  2010/08/09 21:14:35  mwhxa2
 *  Added getter for commercialTestResults
 *
 *  Revision 1.8  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.7  2010/06/21 23:01:04  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.4.8.2  2010/06/20 18:07:14  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6  2010/06/02 20:41:57  mwrsk
 *  Remove clone()
 *
 *  Revision 1.5  2010/05/31 20:50:36  mwrsk
 *  corrected the delete for loop  mwlft1
 *
 *  Revision 1.4  2010/04/24 18:07:58  mwtjc1
 *  updated
 *
 *  Revision 1.3  2010/04/24 17:51:52  mwtjc1
 *  getCommercialTestResults method is updated
 *
 *  Revision 1.2  2010/04/23 21:45:30  mwrsk
 *  Keep it consistent with DriveAndLawtest
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.11  2010/04/07 23:55:21  mwtjc1
 *  updated
 *
 *  Revision 1.10  2010/04/07 23:48:30  mwtjc1
 *  addCommercialTestResult method is added
 *
 *  Revision 1.9  2010/04/07 22:39:39  mwhxa2
 *  Temporary fix for addCommercialTestResult()
 *
 *  Revision 1.8  2010/03/18 15:29:28  mwrsk
 *  updates to reflect test result changes
 *
 *  Revision 1.7  2010/03/10 19:21:52  mwuxb
 *  updates for getCommercialTestResults
 *
 *  Revision 1.6  2010/03/03 16:08:50  mwrsk
 *  cleanup imports
 *
 *  Revision 1.5  2010/02/24 19:00:41  mwuxb
 *  Changed method from  getCommercialTestResultItems(CommercialTestResultType coomercialTestResultType) to getCommercialTestResults(CommercialTestResultType comercialTestResultType)
 *
 *  Revision 1.4  2010/02/24 18:35:02  mwuxb
 *  Added method getCommercialTestResultItems(CommercialTestResultType coomercialTestResultType)
 *
 *  Revision 1.3  2010/02/18 23:12:40  mwrsk
 *  added addCommercialTestResultItem()
 *
 *  Revision 1.2  2010/01/29 15:29:33  mwrsk
 *  renamed "commercialTestResultItem" to "commercialTestResultItems"
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
 *  Revision 1.2  2010/01/08 03:19:22  mwrsk
 *  Keep it consistent with DriveAndLawtest
 *
 *  Revision 1.1  2010/01/07 18:29:48  mwhxa2
 *  Domain Model changes - Draft 1
 *
*/
