/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.bo.vr.record.impl.VehicleRecord;

/**
 * Description: This class is for the TTC DIR for vehicle information inquiry.
 * File: VrInformationRequest.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 4, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/10/19 17:27:53 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class VrInformationRequest extends DlInformationRequest {
	/**
	 * Instantiates a new vr information request.
	 *
	 * @param anApplicant the an applicant
	 */
	public VrInformationRequest(Person anApplicant) {
		super(anApplicant);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -8550580871086932203L;
	/** The Vehicle Record search criteria. */
	private VehicleRecord vehicleRecord;

	/**
	 * @return the vehicleRecord
	 */
	public VehicleRecord getVehicleRecord() {
		return vehicleRecord;
	}

	/**
	 * @param vehicleRecord the vehicleRecord to set
	 */
	public void setVehicleRecord(VehicleRecord vehicleRecord) {
		this.vehicleRecord = vehicleRecord;
	}
}
