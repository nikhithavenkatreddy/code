/**
 * 
 */
package gov.ca.dmv.ease.bo.license;


/**
 * Description: Interface defining the license class type constants.
 * File: ILicenseClassCodes.java
 * Module:  gov.ca.dmv.ease.bo.license
 * Created: Jan 4, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/04/17 22:26:47 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface ILicenseClassCodes {
	String COMMERCIAL_CLASS_A = "A";
	String COMMERCIAL_CLASS_B = "B";
	String COMMERCIAL_CLASS_C = "C";
	String NON_COMMERCIAL_CLASS_A = "D";
	String NON_COMMERCIAL_CLASS_B = "E";
	String NON_COMMERCIAL_CLASS_C = "F";
	String MOTORCYCLE = "M";
}


/**
 *  Modification History:
 *
 *  $Log: ILicenseClassCodes.java,v $
 *  Revision 1.2  2012/04/17 22:26:47  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.1  2012/02/15 19:39:39  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */