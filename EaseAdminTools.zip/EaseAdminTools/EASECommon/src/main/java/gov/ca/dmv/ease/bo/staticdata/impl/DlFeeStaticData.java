/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.staticdata.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.math.BigDecimal;

/**
 * Description: This class holds the DL and id application types fee details.
 * File: DlFeeStaticData.java
 * Module:  gov.ca.dmv.ease.bo.staticdata.impl
 * Created: Aug 22, 2009 
 * @author mwbxp5  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:30 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DlFeeStaticData extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1222165037221482561L;
	/** The fee. */
	private BigDecimal fee;
	/**
	 * The type of application. /** Application Type Code (A, B, G, H, J and Z))
	 */
	private String typeOfApplication;

	/**
	 * Constructor.
	 */
	public DlFeeStaticData() {
	}

	/**
	 * Instantiates a new dl fee static data.
	 * 
	 * @param aFeeAmount
	 *            the a fee amount
	 * @param aTypeOfApplication
	 *            the a type of application
	 */
	public DlFeeStaticData(BigDecimal aFeeAmount, String aTypeOfApplication) {
		super();
		this.fee = aFeeAmount;
		this.typeOfApplication = aTypeOfApplication;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DlFeeStaticData other = (DlFeeStaticData) obj;
		if (fee == null) {
			if (other.fee != null) {
				return false;
			}
		}
		else if (!fee.equals(other.fee)) {
			return false;
		}
		if (typeOfApplication == null) {
			if (other.typeOfApplication != null) {
				return false;
			}
		}
		else if (!typeOfApplication.equals(other.typeOfApplication)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the fee.
	 * 
	 * @return the fee
	 */
	public BigDecimal getFee() {
		return fee;
	}

	/**
	 * Gets the type of application.
	 * 
	 * @return the type of application
	 */
	public String getTypeOfApplication() {
		return typeOfApplication;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((fee == null) ? 0 : fee.hashCode());
		result = prime
				* result
				+ ((typeOfApplication == null) ? 0 : typeOfApplication
						.hashCode());
		return result;
	}

	public void setTypeOfApplication(String typeOfApplication) {
		this.typeOfApplication = typeOfApplication;
	}
}
/**
 * Modification History:
 * 
 * $Log: DlFeeStaticData.java,v $
 * Revision 1.2  2010/07/22 17:50:30  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.4  2010/02/23 22:52:19  mwvxm6
 * Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 * Revision 1.3  2010/01/28 22:36:48  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.2  2009/12/02 02:12:01  mwyxg1
 * Update comments
 *
 * Revision 1.1  2009/11/23 16:25:16  mwrsk
 * Intial commit
 *
 * Revision 1.2  2009/10/07 01:19:20  mwvxm6
 * DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 * Revision 1.1  2009/09/17 18:29:56  mwhxa2
 * Refactored to staticdata package
 *
 * Revision 1.6  2009/08/27 05:39:45  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.5  2009/08/22 23:22:09  mwrrv3
 * Implemented equals and hashCode methods.
 *
 * Revision 1.4  2009/08/18 01:29:54  mwkxk4
 * Added default constructor and class header
 * Revision 1.3 2009/08/17 23:40:33 mwkxk4 Added
 * Annotations
 * 
 * Revision 1.2 2009/08/17 21:33:14 mwbxp5 Enhancing DL fee related classes
 * 
 * Revision 1.1 2009/08/17 19:04:34 mwbxp5 Adding the DL fee related
 * classes--Initial
 * 
 */
