/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.util.Date;
import java.util.List;

/**
 * Description: The purpose of this class is to encapsulate the driver history information for CDLIS and PDPS.
 * File: CduDriverHistoryInfo.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl
 * Created: Mar 23, 2010 
 * @author MWVKM  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2012/02/09 01:41:47 $
 * Last Changed By: $Author: mwhys $
 */
public class CduDriverHistoryInfo {
	/** Application ID. */
	private int applicationId;
	/** The commercial class. */
	private String commercialStatus;
	/** The driver license class. */
	private String driverLicenseClass;
	/** The driver license endorsements. */
	private String driverLicenseEndorsements;
	/** The driver license expiration date. */
	private Date driverLicenseExpirationDate;
	/** The driver license restriction. */
	private List <CodeSetElement> driverLicenseRestrictionCode;
	/** Match sequence number ID. */
	private int matchSequenceNumberId;
	/** The non commercial class. */
	private String nonCommercialStatus;
	/** The state of origin. */
	private String stateOfOrigin;
	/** The gender code of the person. */
	private CodeSetElement genderCode;
	/** The height in feet of the person. */
	private Integer heightInFeet;
	/** The height in inches of the person. */
	private Integer heightInInch;
	/** The weight of the person. */
	private Integer weight;
	/** The eye color code. */
	private CodeSetElement eyeColorCode;
	/** The withdrawal pending indicator. */
	private String withdrawalPendingIndicator;
	/** The State of the DL number. */
	private CodeSetElement currentPrimaryDlNumberState;
	/** The License Number of the person. */
	private String licenseNumber;
	/** The cdlis pdps response code. */
	private CodeSetElement cdlisPdpsResponseCode;
	/** The cdl ndr hit record status. */
	private CodeSetElement cdlNdrHitRecordStatus = new CodeSetElement();
	
	/**
	 * Simple getter for applicationId.
	 *
	 * @return the application id
	 */
	public int getApplicationId() {
		return applicationId;
	}
	
	/**
	 * Simple getter for nonCommercialStatus.
	 *
	 * @return the commercial status
	 */
	public String getCommercialStatus() {
		return commercialStatus;
	}
	
	/**
	 * Simple getter for driverLicenseClass.
	 *
	 * @return the driver license class
	 */
	public String getDriverLicenseClass() {
		return driverLicenseClass;
	}
	
	/**
	 * Simple getter for driverLicenseEndorsements.
	 *
	 * @return the driver license endorsements
	 */
	public String getDriverLicenseEndorsements() {
		return driverLicenseEndorsements;
	}
	
	/**
	 * Simple getter for driverLicenseExpirationDate.
	 *
	 * @return the driver license expiration date
	 */
	public Date getDriverLicenseExpirationDate() {
		return driverLicenseExpirationDate;
	}
	
	/**
	 * Simple getter for driverLicenseRestrictionCode.
	 *
	 * @return the driver license restriction code
	 */
	public List <CodeSetElement> getDriverLicenseRestrictionCode() {
		return driverLicenseRestrictionCode;
	}
	
	/**
	 * Simple getter for matchSequenceNumberId.
	 *
	 * @return the match sequence number id
	 */
	public int getMatchSequenceNumberId() {
		return matchSequenceNumberId;
	}
	
	/**
	 * Simple getter for nonCommercialStatus.
	 *
	 * @return the non commercial status
	 */
	public String getNonCommercialStatus() {
		return nonCommercialStatus;
	}
	
	/**
	 * Simple getter for stateOfOrigin.
	 *
	 * @return the state of origin
	 */
	public String getStateOfOrigin() {
		return stateOfOrigin;
	}
	
	/**
	 * Simple setter for applicationId.
	 *
	 * @param applicationId the new application id
	 */
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	
	/**
	 * Simple setter for nonCommercialStatus.
	 *
	 * @param commercialStatus the new commercial status
	 */
	public void setCommercialStatus(String commercialStatus) {
		this.commercialStatus = commercialStatus;
	}
	
	/**
	 * Simple setter for driverLicenseClass.
	 *
	 * @param driverLicenseClass the new driver license class
	 */
	public void setDriverLicenseClass(String driverLicenseClass) {
		this.driverLicenseClass = driverLicenseClass;
	}
	
	/**
	 * Simple setter for driverLicenseEndorsements.
	 *
	 * @param driverLicenseEndorsements the new driver license endorsements
	 */
	public void setDriverLicenseEndorsements(String driverLicenseEndorsements) {
		this.driverLicenseEndorsements = driverLicenseEndorsements;
	}
	
	/**
	 * Simple setter for driverLicenseExpirationDate.
	 *
	 * @param driverLicenseExpirationDate the new driver license expiration date
	 */
	public void setDriverLicenseExpirationDate(Date driverLicenseExpirationDate) {
		this.driverLicenseExpirationDate = driverLicenseExpirationDate;
	}
	
	/**
	 * Simple setter for driverLicenseRestrictionCode.
	 *
	 * @param driverLicenseRestrictionCode the new driver license restriction code
	 */
	public void setDriverLicenseRestrictionCode(
			List <CodeSetElement> driverLicenseRestrictionCode) {
		this.driverLicenseRestrictionCode = driverLicenseRestrictionCode;
	}
	
	/**
	 * Simple setter for matchSequenceNumberId.
	 *
	 * @param matchSequenceNumberId the new match sequence number id
	 */
	public void setMatchSequenceNumberId(int matchSequenceNumberId) {
		this.matchSequenceNumberId = matchSequenceNumberId;
	}
	
	/**
	 * Simple setter for nonCommercialStatus.
	 *
	 * @param nonCommercialStatus the new non commercial status
	 */
	public void setNonCommercialStatus(String nonCommercialStatus) {
		this.nonCommercialStatus = nonCommercialStatus;
	}
	
	/**
	 * Simple setter for stateOfOrigin.
	 *
	 * @param stateOfOrigin the new state of origin
	 */
	public void setStateOfOrigin(String stateOfOrigin) {
		this.stateOfOrigin = stateOfOrigin;
	}
	
	/**
	 * Sets the gender code.
	 *
	 * @param genderCode the genderCode to set
	 */
	public void setGenderCode(CodeSetElement genderCode) {
		this.genderCode = genderCode;
	}
	
	/**
	 * Gets the gender code.
	 *
	 * @return the genderCode
	 */
	public CodeSetElement getGenderCode() {
		return genderCode;
	}
	
	/**
	 * Sets the height in feet.
	 *
	 * @param heightInFeet the heightInFeet to set
	 */
	public void setHeightInFeet(Integer heightInFeet) {
		this.heightInFeet = heightInFeet;
	}
	
	/**
	 * Gets the height in feet.
	 *
	 * @return the heightInFeet
	 */
	public Integer getHeightInFeet() {
		return heightInFeet;
	}
	
	/**
	 * Sets the height in inch.
	 *
	 * @param heightInInch the heightInInch to set
	 */
	public void setHeightInInch(Integer heightInInch) {
		this.heightInInch = heightInInch;
	}
	
	/**
	 * Gets the height in inch.
	 *
	 * @return the heightInInch
	 */
	public Integer getHeightInInch() {
		return heightInInch;
	}
	
	/**
	 * Sets the weight.
	 *
	 * @param weight the weight to set
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	
	/**
	 * Gets the weight.
	 *
	 * @return the weight
	 */
	public Integer getWeight() {
		return weight;
	}
	
	/**
	 * Sets the eye color code.
	 *
	 * @param eyeColorCode the eyeColorCode to set
	 */
	public void setEyeColorCode(CodeSetElement eyeColorCode) {
		this.eyeColorCode = eyeColorCode;
	}
	
	/**
	 * Gets the eye color code.
	 *
	 * @return the eyeColorCode
	 */
	public CodeSetElement getEyeColorCode() {
		return eyeColorCode;
	}
	
	/**
	 * Sets the withdrawal pending indicator.
	 *
	 * @param withdrawalPendingIndicator the withdrawalPendingIndicator to set
	 */
	public void setWithdrawalPendingIndicator(String withdrawalPendingIndicator) {
		this.withdrawalPendingIndicator = withdrawalPendingIndicator;
	}
	
	/**
	 * Gets the withdrawal pending indicator.
	 *
	 * @return the withdrawalPendingIndicator
	 */
	public String getWithdrawalPendingIndicator() {
		return withdrawalPendingIndicator;
	}
	
	/**
	 * Sets the current primary dl number state.
	 *
	 * @param currentPrimaryDlNumberState the currentPrimaryDlNumberState to set
	 */
	public void setCurrentPrimaryDlNumberState(
			CodeSetElement currentPrimaryDlNumberState) {
		this.currentPrimaryDlNumberState = currentPrimaryDlNumberState;
	}
	
	/**
	 * Gets the current primary dl number state.
	 *
	 * @return the currentPrimaryDlNumberState
	 */
	public CodeSetElement getCurrentPrimaryDlNumberState() {
		return currentPrimaryDlNumberState;
	}
	
	/**
	 * Sets the license number.
	 *
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	
	/**
	 * Gets the license number.
	 *
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}
	
	/**
	 * Sets the cdlis pdps response code.
	 *
	 * @param cdlisPdpsResponseCode the cdlisPdpsResponseCode to set
	 */
	public void setCdlisPdpsResponseCode(CodeSetElement cdlisPdpsResponseCode) {
		this.cdlisPdpsResponseCode = cdlisPdpsResponseCode;
	}
	
	/**
	 * Sets the cdl ndr hit record status.
	 *
	 * @param cdlNdrHitRecordStatus the cdlNdrHitRecordStatus to set
	 */
	public void setCdlNdrHitRecordStatus(CodeSetElement cdlNdrHitRecordStatus) {
		this.cdlNdrHitRecordStatus = cdlNdrHitRecordStatus;
	}
	
	/**
	 * Gets the cdlis pdps response code.
	 *
	 * @return the cdlisPdpsResponseCode
	 */
	public CodeSetElement getCdlisPdpsResponseCode() {
		return cdlisPdpsResponseCode;
	}
	
	/**
	 * Gets the cdl ndr hit record status.
	 *
	 * @return the cdlNdrHitRecordStatus
	 */
	public CodeSetElement getCdlNdrHitRecordStatus() {
		return cdlNdrHitRecordStatus;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + applicationId;
		result = prime
				* result
				+ ((cdlNdrHitRecordStatus == null) ? 0 : cdlNdrHitRecordStatus
						.hashCode());
		result = prime
				* result
				+ ((cdlisPdpsResponseCode == null) ? 0 : cdlisPdpsResponseCode
						.hashCode());
		result = prime
				* result
				+ ((commercialStatus == null) ? 0 : commercialStatus.hashCode());
		result = prime
				* result
				+ ((currentPrimaryDlNumberState == null) ? 0
						: currentPrimaryDlNumberState.hashCode());
		result = prime
				* result
				+ ((driverLicenseClass == null) ? 0 : driverLicenseClass
						.hashCode());
		result = prime
				* result
				+ ((driverLicenseEndorsements == null) ? 0
						: driverLicenseEndorsements.hashCode());
		result = prime
				* result
				+ ((driverLicenseExpirationDate == null) ? 0
						: driverLicenseExpirationDate.hashCode());
		result = prime
				* result
				+ ((driverLicenseRestrictionCode == null) ? 0
						: driverLicenseRestrictionCode.hashCode());
		result = prime * result
				+ ((eyeColorCode == null) ? 0 : eyeColorCode.hashCode());
		result = prime * result
				+ ((genderCode == null) ? 0 : genderCode.hashCode());
		result = prime * result
				+ ((heightInFeet == null) ? 0 : heightInFeet.hashCode());
		result = prime * result
				+ ((heightInInch == null) ? 0 : heightInInch.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime * result + matchSequenceNumberId;
		result = prime
				* result
				+ ((nonCommercialStatus == null) ? 0 : nonCommercialStatus
						.hashCode());
		result = prime * result
				+ ((stateOfOrigin == null) ? 0 : stateOfOrigin.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		result = prime
				* result
				+ ((withdrawalPendingIndicator == null) ? 0
						: withdrawalPendingIndicator.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CduDriverHistoryInfo other = (CduDriverHistoryInfo) obj;
		if (applicationId != other.applicationId)
			return false;
		if (cdlNdrHitRecordStatus == null) {
			if (other.cdlNdrHitRecordStatus != null)
				return false;
		}
		else if (!cdlNdrHitRecordStatus.equals(other.cdlNdrHitRecordStatus))
			return false;
		if (cdlisPdpsResponseCode == null) {
			if (other.cdlisPdpsResponseCode != null)
				return false;
		}
		else if (!cdlisPdpsResponseCode.equals(other.cdlisPdpsResponseCode))
			return false;
		if (commercialStatus == null) {
			if (other.commercialStatus != null)
				return false;
		}
		else if (!commercialStatus.equals(other.commercialStatus))
			return false;
		if (currentPrimaryDlNumberState == null) {
			if (other.currentPrimaryDlNumberState != null)
				return false;
		}
		else if (!currentPrimaryDlNumberState
				.equals(other.currentPrimaryDlNumberState))
			return false;
		if (driverLicenseClass == null) {
			if (other.driverLicenseClass != null)
				return false;
		}
		else if (!driverLicenseClass.equals(other.driverLicenseClass))
			return false;
		if (driverLicenseEndorsements == null) {
			if (other.driverLicenseEndorsements != null)
				return false;
		}
		else if (!driverLicenseEndorsements
				.equals(other.driverLicenseEndorsements))
			return false;
		if (driverLicenseExpirationDate == null) {
			if (other.driverLicenseExpirationDate != null)
				return false;
		}
		else if (!driverLicenseExpirationDate
				.equals(other.driverLicenseExpirationDate))
			return false;
		if (driverLicenseRestrictionCode == null) {
			if (other.driverLicenseRestrictionCode != null)
				return false;
		}
		else if (!driverLicenseRestrictionCode
				.equals(other.driverLicenseRestrictionCode))
			return false;
		if (eyeColorCode == null) {
			if (other.eyeColorCode != null)
				return false;
		}
		else if (!eyeColorCode.equals(other.eyeColorCode))
			return false;
		if (genderCode == null) {
			if (other.genderCode != null)
				return false;
		}
		else if (!genderCode.equals(other.genderCode))
			return false;
		if (heightInFeet == null) {
			if (other.heightInFeet != null)
				return false;
		}
		else if (!heightInFeet.equals(other.heightInFeet))
			return false;
		if (heightInInch == null) {
			if (other.heightInInch != null)
				return false;
		}
		else if (!heightInInch.equals(other.heightInInch))
			return false;
		if (licenseNumber == null) {
			if (other.licenseNumber != null)
				return false;
		}
		else if (!licenseNumber.equals(other.licenseNumber))
			return false;
		if (matchSequenceNumberId != other.matchSequenceNumberId)
			return false;
		if (nonCommercialStatus == null) {
			if (other.nonCommercialStatus != null)
				return false;
		}
		else if (!nonCommercialStatus.equals(other.nonCommercialStatus))
			return false;
		if (stateOfOrigin == null) {
			if (other.stateOfOrigin != null)
				return false;
		}
		else if (!stateOfOrigin.equals(other.stateOfOrigin))
			return false;
		if (weight == null) {
			if (other.weight != null)
				return false;
		}
		else if (!weight.equals(other.weight))
			return false;
		if (withdrawalPendingIndicator == null) {
			if (other.withdrawalPendingIndicator != null)
				return false;
		}
		else if (!withdrawalPendingIndicator
				.equals(other.withdrawalPendingIndicator))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CduDriverHistoryInfo.java,v $
 *  Revision 1.7  2012/02/09 01:41:47  mwhys
 *  Added a field cdlNdrHitRecordStatus. (Defect 7201)
 *
 *  Revision 1.6  2011/10/06 22:12:51  mwhys
 *  Added a field cdlisPdpsResponseCode.
 *
 *  Revision 1.5  2011/04/26 18:27:04  mwhys
 *  Fixed defect 4121.
 *
 *  Revision 1.4  2011/03/12 23:05:30  mwhys
 *  Added a field withdrawalPendingIndicator.
 *
 *  Revision 1.3  2011/02/25 17:46:02  mwhys
 *  Fixed defect 5105.
 *
 *  Revision 1.2  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/03/25 19:11:03  mwvkm
 *  Modified the code for CDU as per the match logic document that the development had received.
 *
 */
