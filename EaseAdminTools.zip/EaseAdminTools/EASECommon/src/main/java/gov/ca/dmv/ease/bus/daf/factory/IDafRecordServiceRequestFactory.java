/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.daf.factory;

import gov.ca.dmv.ease.bus.daf.request.impl.PurgeDafRecordRequestBus;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am the interface for DafRecordServiceRequestFactory
 * File: IDafRecordServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.bus.daf.factory
 * Created: Feb 17, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/02/18 01:01:23 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IDafRecordServiceRequestFactory {
	/**
	 * Creates a new PurgeDafRecordRequestBus object.
	 * 
	 * @param context the context
	 * @param dafNumber the daf number
	 * 
	 * @return the purge daf record request
	 */
	PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, Integer dafNumber);

	/**
	 * Creates a new PurgeDafRecordRequestBus object.
	 * 
	 * @param context the context
	 * @param dafNumber the daf number
	 * @param isItHardDelete
	 * 
	 * @return the purge daf record request
	 */
	PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, Integer dafNumber, boolean isItHardDelete);

	/**
	 * Creates a new PurgeDafRecordRequestBus object.
	 * 
	 * @param context the context
	 * @param dlNumber the license number
	 * 
	 * @return the purge daf record request
	 */
	PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, String dlNumber);

	/**
	 * Creates a new PurgeDafRecordRequestBus object.
	 * 
	 * @param context the context
	 * @param dlNumber the license number
	 * @param isItHardDelete
	 * 
	 * @return the purge daf record request
	 */
	PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, String dlNumber, boolean isItHardDelete);
}
/**
 *  Modification History:
 *
 *  $Log: IDafRecordServiceRequestFactory.java,v $
 *  Revision 1.1  2011/02/18 01:01:23  mwkfh
 *  added for use by purge daf service
 *
 */
