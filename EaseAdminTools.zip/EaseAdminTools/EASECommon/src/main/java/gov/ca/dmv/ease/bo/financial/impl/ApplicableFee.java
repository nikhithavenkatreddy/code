/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.financial.IExternalFeeRecord;

import java.io.Serializable;

/**
 * Description: This class contains the amount code and amount amount. IT will be encapsulated the the amount request response.
 * 
 * //FIXME - integrate with Fee and rename to follow naming conventions
 *  //FIXME - limit visibility of public constructors
 *  //FIXME - fee code should be an enum not a String
 *  //FIXME - fee indicator should be an enum not a String
 * 
 * File: ApplicableFee.java
 * Module:  gov.ca.dmv.ease.fee.impl
 * Created: Mar 30, 2010 
 * @author MWPZS3  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/10/21 22:53:46 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ApplicableFee implements Serializable, IExternalFeeRecord {
	public ApplicableFee() {
		super();
		// TODO reduce visbility
	}

	/**
	 * Instantiates a new applicable fee.
	 *
	 * @param aCode the a code
	 * @param anAmount the an amount
	 * @param anIndicatorType the an indicator type
	 * @param aDesc the a desc
	 */
	public ApplicableFee(String aCode, double anAmount, String anIndicatorType,
			String aDesc) {
		super();
		setFeeCode(aCode);
		setAmount(anAmount);
		setFeeIndicatorType(anIndicatorType);
		setDescription(aDesc);
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7556070397022270427L;
	/** The description. */
	private String description;
	/** The amount. */
	private double amount;
	/** The amount code. */
	private String feeCode;
	/** The amount indicator type used for 04M- Reissue Fee Payment */
	private String feeIndicatorType;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IExternalFeeRecord#getDescription()
	 */
	public String getDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IExternalFeeRecord#getFee()
	 */
	public double getFee() {
		return amount;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IExternalFeeRecord#getFeeCode()
	 */
	public String getFeeCode() {
		return feeCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IExternalFeeRecord#getFeeIndicatorType()
	 */
	public String getFeeIndicatorType() {
		return feeIndicatorType;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the description to set
	 */
	@Deprecated
	//public visibility
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	@Deprecated
	//public visibility
	public void setAmount(double anAmount) {
		amount = anAmount;
	}

	@Deprecated
	//misnamed
	public void setFee(double anAmount) {
		amount = anAmount;
	}

	/**
	 * Sets the amount code.
	 *
	 * @param feeCode the feeCode to set
	 */
	@Deprecated
	//public visibility
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	/**
	 * Set the feeIndicatorType.
	 *
	 * @param feeIndicatorType the feeIndicatorType to set
	 */
	@Deprecated
	//public visibility
	public void setFeeIndicatorType(String feeIndicatorType) {
		this.feeIndicatorType = feeIndicatorType;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ApplicableFee.java,v $
 *  Revision 1.3  2011/10/21 22:53:46  mwpxp2
 *  Implemented extracted interface
 *
 *  Revision 1.2  2011/10/21 22:39:58  mwpxp2
 *  Renamed "fee" inst var to "amount"; added constructor/4; added many fixmes; added deprecation markers for public setters to be retired
 *
 *  Revision 1.1  2011/03/23 20:42:02  mwtjc1
 *  moved from EaseDriverLicense to EaseCommon
 *
 *  Revision 1.4  2010/10/19 22:21:15  mwhys
 *  implements Serializable.
 *
 *  Revision 1.3  2010/10/13 23:09:25  mwhxb3
 *  Added feeIndicatorType.
 *
 *  Revision 1.2  2010/09/03 16:27:57  mwhxb3
 *  Java Doc fix and clean up.
 *
 *  Revision 1.1  2010/05/11 18:17:39  mwcsj3
 *  Fee engine classes moved from EASEFeeEngine project
 *
 *  Revision 1.4  2010/05/04 17:34:09  mwpxp2
 *  Removed obsolete todos
 *
 *  Revision 1.3  2010/05/04 17:32:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/04/21 16:35:26  mwbxp5
 *  Clean-up and added java doc.
 *
 *  Revision 1.1  2010/03/30 23:47:27  mwpzs3
 *  class for outside world
 *
 */
