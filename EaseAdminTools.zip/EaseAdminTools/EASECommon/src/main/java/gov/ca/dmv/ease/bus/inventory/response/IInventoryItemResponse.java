/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;

/**
 * Description: I am interface for responses from inventory for
 *  requests returning an inventory item
 * File: IInventoryItemResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response
 * Created: Nov 3, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/11/04 16:39:19 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryItemResponse extends IInventoryServiceResponse {
	/**
	 * Gets the item.
	 * 
	 * @return the item
	 */
	IInventoryItem getItem();
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryItemResponse.java,v $
 *  Revision 1.1  2011/11/04 16:39:19  mwkfh
 *  added GetLowestSequence
 *
 */
