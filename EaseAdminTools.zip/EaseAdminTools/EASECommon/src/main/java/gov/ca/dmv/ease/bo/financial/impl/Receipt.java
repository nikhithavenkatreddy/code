/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.admin.impl.Employee;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.Date;

/**
 * Description: Receipt class encapsulates the attributes specific to receipts
 * (Automated receipt number, Status, Work date, Office and Employee)
 * File: Receipt.java 
 * Module: gov.ca.dmv.ease.bo.financial.impl 
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.4 $ 
 * Last Changed: $Date: 2010/12/07 22:08:32 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class Receipt extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4314529436656848613L;
	/** The employee. */
	private Employee employee;
	/** The office. */
	private Office office;
	/** Receipt Number. */
	private Integer receiptNumber;
	/** Holds the sequence number. */
	private Integer sequenceNumber;
	/** The status. */
	private String status;
	/** The work date. */
	private Date workDate;

	/** Default Constructor */
	public Receipt() {
		//employee = new Employee();
		//office = new Office();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Receipt other = (Receipt) obj;
		if (employee == null) {
			if (other.employee != null) {
				return false;
			}
		}
		else if (!employee.equals(other.employee)) {
			return false;
		}
		if (office == null) {
			if (other.office != null) {
				return false;
			}
		}
		else if (!office.equals(other.office)) {
			return false;
		}
		if (receiptNumber == null) {
			if (other.receiptNumber != null) {
				return false;
			}
		}
		else if (!receiptNumber.equals(other.receiptNumber)) {
			return false;
		}
		if (sequenceNumber == null) {
			if (other.sequenceNumber != null) {
				return false;
			}
		}
		else if (!sequenceNumber.equals(other.sequenceNumber)) {
			return false;
		}
		if (status == null) {
			if (other.status != null) {
				return false;
			}
		}
		else if (!status.equals(other.status)) {
			return false;
		}
		if (workDate == null) {
			if (other.workDate != null) {
				return false;
			}
		}
		else if (!workDate.equals(other.workDate)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * Gets the next receipt number.
	 * 
	 * @return the next receipt number
	 */
	public void getNextReceiptNumber() {
	}

	/**
	 * Gets the office.
	 * 
	 * @return the office
	 */
	public Office getOffice() {
		return office;
	}

	/**
	 * Gets the receipt number.
	 * 
	 * @return the receipt number
	 */
	public Integer getReceiptNumber() {
		return receiptNumber;
	}

	/**
	 * Gets the sequence number.
	 * 
	 * @return the sequenceNumber
	 */
	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * Gets the status.
	 * 
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Gets the work date.
	 * 
	 * @return the workDate
	 */
	public Date getWorkDate() {
		return workDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((employee == null) ? 0 : employee.hashCode());
		result = prime * result + ((office == null) ? 0 : office.hashCode());
		result = prime * result
				+ ((receiptNumber == null) ? 0 : receiptNumber.hashCode());
		result = prime * result
				+ ((sequenceNumber == null) ? 0 : sequenceNumber.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((workDate == null) ? 0 : workDate.hashCode());
		return result;
	}

	/**
	 * Sets the employee.
	 * 
	 * @param employee the employee to set
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * Sets the office.
	 * 
	 * @param office the office to set
	 */
	public void setOffice(Office office) {
		this.office = office;
	}

	/**
	 * Sets the receipt number.
	 * 
	 * @param receiptNumber the new receipt number
	 */
	public void setReceiptNumber(Integer receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

	/**
	 * Sets the sequence number.
	 * 
	 * @param sequenceNumber the sequenceNumber to set
	 */
	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * Sets the status.
	 * 
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Sets the work date.
	 * 
	 * @param workDate the workDate to set
	 */
	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}

	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("employee", employee, anIndent, aBuilder);
		outputKeyValue("office", office, anIndent, aBuilder);
		outputKeyValue("receiptNumber", receiptNumber, anIndent, aBuilder);
		outputKeyValue("sequenceNumber", sequenceNumber, anIndent, aBuilder);
		outputKeyValue("workDate", workDate, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Receipt.java,v $
 *  Revision 1.4  2010/12/07 22:08:32  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.3  2010/12/07 03:03:13  mwpxp2
 *  Added toStringOn/1; sorted
 *
 *  Revision 1.2  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.4  2010/04/14 23:49:23  mwvxm6
 *  Removed DerNumber and DerType attributes
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/08/27 05:39:44  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2009/08/22 23:21:46  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.6  2009/08/06 01:40:07  mwrrv3
 *  Removed reference to invoice class.
 *
 *  Revision 1.5  2009/08/05 18:04:00  mwskd2
 *  Added new attributes related to DER
 *
 *  Revision 1.4  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.3  2009/07/22 21:24:47  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:37  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
