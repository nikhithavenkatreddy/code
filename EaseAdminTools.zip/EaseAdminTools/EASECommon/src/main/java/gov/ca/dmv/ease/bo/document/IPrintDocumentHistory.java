/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document;

import java.util.List;

import gov.ca.dmv.ease.app.constants.PrintRequestTypes;
import gov.ca.dmv.ease.bo.IBusinessObject;


/**
 * Description: //TODO - provide description!
 * File: IPrintDocumentHistory.java
 * Module:  gov.ca.dmv.ease.bo.document
 * Created: Apr 7, 2011 
 * @author MWXXW  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/04/29 00:49:35 $
 * Last Changed By: $Author: mwxxw $
 */
public interface IPrintDocumentHistory extends IBusinessObject {
	/**
	 * Calculate Print Class Code.
	 * @return String printClassCode
	 */
	String calculatePrintClassCode();
	
	/**
	 * Getter for PrintRequestType List
	 * @return
	 */
	List<PrintRequestTypes> getPrintRequestTypes();
		
}


/**
 *  Modification History:
 *
 *  $Log: IPrintDocumentHistory.java,v $
 *  Revision 1.2  2011/04/29 00:49:35  mwxxw
 *  Add new function getPrintRequestTypes() to this interface.
 *
 *  Revision 1.1  2011/04/08 00:57:57  mwxxw
 *  Use IPrintDocumentHistory instead of PrintDocumentHistory
 *
 */
