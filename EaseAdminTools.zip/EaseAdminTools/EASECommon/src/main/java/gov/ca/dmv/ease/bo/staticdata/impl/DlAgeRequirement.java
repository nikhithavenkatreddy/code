/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.staticdata.impl;

import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.fw.validate.IValidator;

/**
 * Description: I am holding data for DL Age.
 * File: DlAgeRequirement.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Aug 27, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/09/13 04:40:27 $
 * Last Changed By: $Author: mwhys $
 */
public class DlAgeRequirement extends BaseBusinessObject {
	private static final long serialVersionUID = -640047331036137536L;
	/** The license class. */
	private String licenseClass;
	/** The Minimum Age Limit in Months. */
	private int month;
	/** The Effective Age for License Eligibility. */
	/** The Minimum Age Limit in Years. */
	private int year;

	/**
	 * Default Constructor.
	 */
	public DlAgeRequirement() {
		// Empty Constructor
	}

	/**
	 * Overridden Constructor.
	 * 
	 * @param licenseClassCode the License Class Code
	 * @param effectiveAge the Effective Age
	 */
	public DlAgeRequirement(String licenseClassCode, int year, int month) {
		this.licenseClass = licenseClassCode;
		this.year = year;
		this.month = month;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DlAgeRequirement other = (DlAgeRequirement) obj;
		if (licenseClass == null) {
			if (other.licenseClass != null) {
				return false;
			}
		}
		else if (!licenseClass.equals(other.licenseClass)) {
			return false;
		}
		if (year < other.year) {
			return false;
		}
		if (month < other.month) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the License Class.
	 * 
	 * @return the licenseClass
	 */
	public String getLicenseClass() {
		return licenseClass;
	}

	/**
	 * Gets the Month.
	 * 
	 * @return the month
	 */
	public int getMonth() {
		return month;
	}

	/**
	 * Gets the Month.
	 * 
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((licenseClass == null) ? 0 : licenseClass.hashCode());
		result = prime * result + (year);
		result = prime * result + (month);
		return result;
	}

	/**
	 * Sets the License Class.
	 * 
	 * @param licenseClass the licenseClass to set
	 */
	public void setLicenseClass(String licenseClass) {
		this.licenseClass = licenseClass;
	}

	/**
	 * Sets the Month.
	 * 
	 * @param month the month to set
	 */
	public void setMonth(int month) {
		this.month = month;
	}

	/**
	 * Sets the Year.
	 * 
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DlAgeRequirement.java,v $
 *  Revision 1.3  2010/09/13 04:40:27  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/02/11 18:16:46  mwhxa2
 *  Renamed from DlAgeRequirment to DlAgeRequirement
 *
 *  Revision 1.2  2010/01/28 22:36:48  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/15 22:17:31  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.4  2009/10/03 21:06:31  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/29 20:58:16  mwhxa2
 *  Removed unused imports
 *
 *  Revision 1.2  2009/09/29 18:07:10  mwhxa2
 *  Implements IValidatable
 *
 *  Revision 1.1  2009/09/17 18:29:56  mwhxa2
 *  Refactored to staticdata package
 *
 *  Revision 1.3  2009/09/13 20:45:35  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.2.2.1  2009/09/12 19:08:47  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.2  2009/09/08 23:28:19  mwsmg6
 *  removing CodeSetElement subclasses
 *
 *  Revision 1.1  2009/08/28 01:00:44  mwhxa2
 *  Rename DlAge to DlAgeRequirment
 *
 *  Revision 1.1  2009/08/27 20:56:12  mwhxa2
 *  Driver License Eligibility Age - Load data from Database
 *
*/
