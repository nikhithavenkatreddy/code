/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl;

import gov.ca.dmv.ease.bo.dl.record.impl.DrivingRecord;

/**
 * Description: The purpose of this class is to encapsulate the CDU response for the CDLIS and PDPS information
 * File: CduResponseInfo.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl
 * Created: Mar 23, 2010 
 * @author MWVKM  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/02/25 17:47:09 $
 * Last Changed By: $Author: mwhys $
 */
public class CduResponseInfo {
	/** The CDLIS/PDPS header info record */
	private CdlisPdpsHeaderInfo cdlisPdpsHeaderInfo;
	/** The CDLIS/PDPS driver history info record */
	private CduDriverHistoryInfo cduDriverHistoryInfo;
	/** The CDLIS/PDPS request info record */
	private CduRequestInfo cduRequestInfo;
	/** The CDLIS/PDPS data record */
	private DrivingRecord drivingRecord;
	/** The match indicator to determine if the record is matched */
	private boolean matchIndicator;
	/** The message type to determine if the record is for the CDLIS/PDPS header/data/driver history info  */
	private String messageType;
	/** The applicationId determines if the record is for the CDLIS or PDPS. */
	private String applicationId;

	/**
	 * Default Constructor.
	 */
	public CduResponseInfo() {
		cdlisPdpsHeaderInfo = new CdlisPdpsHeaderInfo();
		drivingRecord = new DrivingRecord();
		cduRequestInfo = new CduRequestInfo();
		cduDriverHistoryInfo = new CduDriverHistoryInfo();
	}

	/**
	 * Simple getter for cdlisPdpsHeaderInfo.
	 * 
	 * @return
	 */
	public CdlisPdpsHeaderInfo getCdlisPdpsHeaderInfo() {
		return cdlisPdpsHeaderInfo;
	}

	/**
	 * Simple getter for cduDriverHistoryInfo.
	 * 
	 * @return
	 */
	public CduDriverHistoryInfo getCduDriverHistoryInfo() {
		return cduDriverHistoryInfo;
	}

	/**
	 * Simple getter for cduRequestInfo.
	 * 
	 * @return
	 */
	public CduRequestInfo getCduRequestInfo() {
		return cduRequestInfo;
	}

	/**
	 * Simple getter for drivingRecord.
	 * 
	 * @return
	 */
	public DrivingRecord getDrivingRecord() {
		return drivingRecord;
	}

	/**
	 * Simple getter for messageType.
	 * 
	 * @return
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * Simple getter for matchIndicator.
	 * 
	 * @return
	 */
	public boolean isMatchIndicator() {
		return matchIndicator;
	}

	/**
	 * Simple setter for cdlisPdpsHeaderInfo.
	 * 
	 * @param cdlisPdpsHeaderInfo
	 */
	public void setCdlisPdpsHeaderInfo(CdlisPdpsHeaderInfo cdlisPdpsHeaderInfo) {
		this.cdlisPdpsHeaderInfo = cdlisPdpsHeaderInfo;
	}

	/**
	 * Simple setter for cduDriverHistoryInfo.
	 * 
	 * @param cduDriverHistoryInfo
	 */
	public void setCduDriverHistoryInfo(
			CduDriverHistoryInfo cduDriverHistoryInfo) {
		this.cduDriverHistoryInfo = cduDriverHistoryInfo;
	}

	/**
	 * Simple setter for cduRequestInfo.
	 * 
	 * @param cduRequestInfo
	 */
	public void setCduRequestInfo(CduRequestInfo cduRequestInfo) {
		this.cduRequestInfo = cduRequestInfo;
	}

	/**
	 * Simple setter for drivingRecord.
	 * 
	 * @param drivingRecord
	 */
	public void setDrivingRecord(DrivingRecord drivingRecord) {
		this.drivingRecord = drivingRecord;
	}

	/**
	 * Simple setter for matchIndicator.
	 * 
	 * @param matchIndicator
	 */
	public void setMatchIndicator(boolean matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	/**
	 * Simple setter for messageType.
	 * 
	 * @param messageType
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CduResponseInfo.java,v $
 *  Revision 1.3  2011/02/25 17:47:09  mwhys
 *  Fixed defect 5105.
 *
 *  Revision 1.2  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/26 00:10:40  mwvkm
 *  Fixed the errors that I had found in jUnit
 *
 *  Revision 1.1  2010/03/25 19:11:03  mwvkm
 *  Modified the code for CDU as per the match logic document that the development had received.
 *
 */
