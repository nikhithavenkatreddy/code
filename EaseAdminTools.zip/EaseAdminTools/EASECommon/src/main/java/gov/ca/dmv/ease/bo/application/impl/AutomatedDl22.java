/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class captures information required to denote if DL22 is a Pending Application
 * File: AutomatedDl22.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class AutomatedDl22 extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5330380990625341028L;
	/** The Flag to denote if DL22 is a Pending Application. */
	private Boolean dl22mPendingApplication;
	/** The Stop Bypass*/
	private String stopBypass;
	/** The Length Of Temp*/
	private String lengthOfTemp;

	/**
	 * Default Constructor.
	 */
	public AutomatedDl22() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the dl22mPendingApplication
	 */
	public boolean isDl22mPendingApplication() {
		return dl22mPendingApplication;
	}

	/**
	 * @return the stopBypass
	 */
	public String getStopBypass() {
		return stopBypass;
	}

	/**
	 * @return the lengthOfTemp
	 */
	public String getLengthOfTemp() {
		return lengthOfTemp;
	}

	/**
	 * @param dl22mPendingApplication the dl22mPendingApplication to set
	 */
	public void setDl22mPendingApplication(boolean dl22mPendingApplication) {
		this.dl22mPendingApplication = dl22mPendingApplication;
	}

	/**
	 * @param stopBypass the stopBypass to set
	 */
	public void setStopBypass(String stopBypass) {
		this.stopBypass = stopBypass;
	}

	/**
	 * @param lengthOfTemp the lengthOfTemp to set
	 */
	public void setLengthOfTemp(String lengthOfTemp) {
		this.lengthOfTemp = lengthOfTemp;
	}
}
/**
 *  Modification History:
 *
 *  $$Log: AutomatedDl22.java,v $
 *  $Revision 1.7  2012/03/14 01:57:56  mwxxw
 *  $Pull up attribute: applicant to Application class.
 *  $
 *  $Revision 1.6  2011/01/29 22:51:55  mwrrv2
 *  $Initializing isFeeRequired to true in the constructor.
 *  $
 *  $Revision 1.5  2010/10/12 20:15:37  mwrxn3
 *  $Added lengthOfTemp and stopbyPass methods
 *  $$
 *
 */
