/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service.impl;

import gov.ca.dmv.ease.app.constants.ICommonErrorMessageConstants;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.inventory.item.impl.LocalInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.impl.OfficeLocalInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.conversion.impl.ContiguousItemSequenceConverter;
import gov.ca.dmv.ease.bo.sequence.impl.ContiguousItemSequence;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.impl.AddLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueMultipleLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MoveLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveLowestSequenceRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SeedLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.AddLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueMultipleLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MoveLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveLowestSequenceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SeedLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

/**
 * Description: I provide methods that manage inventory
 * business objects in the persistence store
 * File: LocalPersistenceService.java 
 * Module: gov.ca.dmv.ease.tus.persist.service.impl 
 * Created: Sep 12, 2010
 * @author MWKFH
 * @version $Revision: 1.59 $ 
 * Last Changed: $Date: 2012/02/23 19:43:42 $ 
 * Last Changed By: $Author: mwkfh $
 */
public class LocalPersistenceService extends PersistenceService implements
		ILocalPersistenceService {
	/** The Constant INV_AVAILABLE_FLAG_FIELD_NAME. */
	private static final String INV_AVAILABLE_FLAG_FIELD_NAME = "isAvailable";
	/** The Constant INV_INVALIDATED_ITEM_CODE_FIELD_NAME. */
	private static final String INV_INVALIDATED_ITEM_CODE_FIELD_NAME = "invalidationCode";
	/** The Constant INV_ITEM_TYPE_CODE_FIELD_NAME. */
	private static final String INV_ITEM_TYPE_CODE_FIELD_NAME = "typeCode";
	/** The Constant INV_FETCH_RETRIES **/
	private static final int INV_FETCH_RETRIES = 0;
	/** The Constant INV_OFFICE_FIELD_NAME. */
	private static final String INV_OFFICE_FIELD_NAME = "officeId";
	/** The Constant INV_SEQUENCE_NUMBER_FIELD_NAME. */
	private static final String INV_LOWER_BOUNDARY_FIELD_NAME = "lowerBoundary";
	private static final String INV_UPPER_BOUNDARY_FIELD_NAME = "upperBoundary";
	private static final String INV_SEQUENCE_NUMBER_FIELD_NAME = "sequenceNoValue";
	/** The Constant INV_STATION_FIELD_NAME. */
	private static final String INV_STATION_FIELD_NAME = "stationId";
	/** The Constant ISSUE_UPDATE_ERROR. */
	private static final String ISSUE_UPDATE_ERROR = "UNABLE TO ISSUE ITEM(S) - PLEASE TRY AGAIN";
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(PersistenceService.class);
	/** The Constant MAX_ISSUE_TRIES. */
	private static final int MAX_ISSUE_TRIES = 10;
	/** The Constant MODIFIED_DATE. */
	private static final String MODIFIED_DATE = "modifiedDate";
	/** The Constant NOTHING_TO_ISSUE_ERROR. */
	private static final String NOTHING_TO_ISSUE_ERROR = "NOTHING TO ISSUE";
	/** The Constant SYS_ID. */
	private static final String SYS_ID = "SYS_ID";

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.AddLocalInventoryRequest)
	 */
	public AddLocalInventoryResponse execute(AddLocalInventoryRequest request) {
		LOGGER.debug("execute(AddLocalInventoryRequest request=" + request
				+ ") - start");
		try {
			IErrorCollector aCollector = new ErrorCollector();
			IContiguousItemSequence contiguousItemSequence = request
					.getContiguousItemSequence();
			//purge table data
			purgeInventory(contiguousItemSequence);
			int affectedItemsCount = 0;
			//validate & insert new data
			ArrayList <IContiguousItemSequence> itemSequenceList = new ArrayList <IContiguousItemSequence>();
			itemSequenceList.add(contiguousItemSequence);
			affectedItemsCount += executeValidateAndPersistItemRange(
					aCollector, itemSequenceList);
			LOGGER.debug("execute(AddLocalInventoryRequest) - end");
			if (aCollector.hasErrors()) {
				return new AddLocalInventoryResponse(aCollector,
						affectedItemsCount);
			}
			else {
				return new AddLocalInventoryResponse(affectedItemsCount);
			}
		}
		catch (Exception e) {
			LOGGER.error("execute(AddLocalInventoryRequest)", e);
			return new AddLocalInventoryResponse(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.DeleteLocalInventoryRequest)
	 */
	public DeleteLocalInventoryResponse execute(
			DeleteLocalInventoryRequest request) {
		LOGGER.debug("execute(DeleteLocalInventoryRequest request=" + request
				+ ") - start");
		try {
			IErrorCollector aCollector = new ErrorCollector();
			IContiguousItemSequence contiguousItemSequence = request
					.getContiguousItemSequence();
			//purge table data
			int affectedItemsCount = purgeInventory(contiguousItemSequence);
			LOGGER.debug("execute(DeleteLocalInventoryRequest) - end");
			if (aCollector.hasErrors()) {
				return new DeleteLocalInventoryResponse(aCollector,
						affectedItemsCount);
			}
			else {
				return new DeleteLocalInventoryResponse(affectedItemsCount);
			}
		}
		catch (Exception e) {
			LOGGER.error("execute(DeleteLocalInventoryRequest)", e);
			return new DeleteLocalInventoryResponse(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.IssueLocalInventoryRequest)
	 */
	public IssueLocalInventoryResponse execute(
			IssueLocalInventoryRequest request) {
		LOGGER.debug("execute(IssueLocalInventoryRequest request=" + request
				+ ") - start");
		IssueMultipleLocalInventoryResponse multipleResponse = issueInventory(
				(LocalInventoryItem) request.getInventoryItem(), 1);
		IssueLocalInventoryResponse response;
		if (multipleResponse.hasErrors()) {
			response = new IssueLocalInventoryResponse(multipleResponse
					.getErrorCollector());
		}
		else {
			List <IInventoryItem> issuedItemList = multipleResponse
					.getIssuedItemList();
			if (EaseUtil.isNullOrBlank(issuedItemList)) {
				//NOTE: this should be unreachable because it comes back as an error above
				response = new IssueLocalInventoryResponse(
						new ApplicationException(
								ICommonErrorMessageConstants.NOT_ENOUGH_INVENTORY_TO_ISSUE));
			}
			else {
				response = new IssueLocalInventoryResponse(issuedItemList
						.get(0));
			}
		}
		LOGGER.debug("execute(IssueLocalInventoryRequest) - end");
		return response;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.IssueMultipleLocalInventoryRequest)
	 */
	public IssueMultipleLocalInventoryResponse execute(
			IssueMultipleLocalInventoryRequest request) {
		LOGGER.debug("execute(IssueMultipleLocalInventoryRequest request="
				+ request + ") - start");
		IssueMultipleLocalInventoryResponse response = issueInventory(
				(LocalInventoryItem) request.getInventoryItem(), request
						.getQuantity());
		LOGGER.debug("execute(IssueMultipleLocalInventoryRequest) - end");
		return response;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.SeedInventoryPersistenceRequest)
	 */
	public MoveLocalInventoryResponse execute(MoveLocalInventoryRequest request) {
		LOGGER.debug("execute(MoveLocalInventoryRequest request=" + request
				+ ") - start");
		try {
			IErrorCollector aCollector = new ErrorCollector();
			int itemsUpdated = executeMoveLocationPersistence(aCollector,
					request.getTargetLocation(), request
							.getContiguousItemSequence());
			MoveLocalInventoryResponse returnMoveLocalInventoryResponse = new MoveLocalInventoryResponse(
					itemsUpdated);
			LOGGER.debug("execute(MoveLocalInventoryRequest) - end");
			return returnMoveLocalInventoryResponse;
		}
		catch (Exception e) {
			LOGGER.error("execute(MoveLocalInventoryRequest)", e);
			return new MoveLocalInventoryResponse(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.RetrieveLowestSequenceRequest)
	 */
	public RetrieveLowestSequenceResponse execute(
			RetrieveLowestSequenceRequest request) {
		LOGGER.debug("execute(RetrieveLowestSequenceRequest request=" + request
				+ ") - start");
		List <IContiguousItemSequence> itemSequenceRanges = retrieveInventoryRange(
				request.getItemTypeCode(), request.getOfficeId());
		RetrieveLowestSequenceResponse response;
		if (EaseUtil.isNullOrBlank(itemSequenceRanges)) {
			response = new RetrieveLowestSequenceResponse(
					new ApplicationException(
							ICommonErrorMessageConstants.NOT_ENOUGH_INVENTORY_TO_ISSUE));
		}
		else {
			response = new RetrieveLowestSequenceResponse(itemSequenceRanges
					.get(0).asItemList().get(0));
		}
		LOGGER.debug("execute(RetrieveLowestSequenceRequest) - end");
		return response;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.SeedInventoryPersistenceRequest)
	 */
	public SeedLocalInventoryResponse execute(SeedLocalInventoryRequest request) {
		LOGGER.debug("execute(SeedLocalInventoryRequest request=" + request
				+ ") - start");
		try {
			IErrorCollector aCollector = new ErrorCollector();
			List <IContiguousItemSequence> sequenceList = request
					.getContiguousItemSequenceList();
			//retrieve office(s)
			List <String> officeIdList = new ArrayList <String>();
			if (!request.hasOfficeId() || !request.hasProcessorId()) {
				throw new ApplicationException(
						"Both office and processor id are required to seed!");
			}
			//purge table data
			purgeOfficeInventory(request.getOfficeId(), request
					.getProcessorId());
			//save data
			int affectedItemsCount = 0;
			affectedItemsCount += executeValidateAndPersistItemRange(
					aCollector, sequenceList);
			LOGGER.debug("execute(SeedLocalInventoryRequest) - end");
			if (aCollector.hasErrors()) {
				return new SeedLocalInventoryResponse(aCollector,
						affectedItemsCount);
			}
			else {
				return new SeedLocalInventoryResponse(affectedItemsCount);
			}
		}
		catch (Exception e) {
			LOGGER.error("execute(SeedLocalInventoryRequest)", e);
			return new SeedLocalInventoryResponse(e);
		}
	}

	/**
	 * Validates inventory list and saves items that pass validation and returns the errors for items that don't pass.
	 * 
	 * @param domainObjects the domain objects
	 */
	private int executeValidateAndPersistItemRange(
			IErrorCollector errorCollector,
			List <IContiguousItemSequence> itemSequenceList) {
		LOGGER
				.debug("executeValidateAndPersistInventoryList(IErrorCollector, List<IInventoryItem> domainObjects="
						+ itemSequenceList + ") - start");
		getSessionFactory().getCurrentSession().beginTransaction();
		int affectItemSequenceCount = 0;
		try {
			IErrorCollector aNewCollector = new ErrorCollector();
			for (IContiguousItemSequence itemSequence : itemSequenceList) {
				//validate
				itemSequence.validateUsing(aNewCollector);
				//itemSequence
				if (aNewCollector.hasErrors()) {
					//save error
					LOGGER.info(itemSequence.toString());
					LOGGER.info(aNewCollector.getEntries());
					errorCollector.addEntries(aNewCollector.getEntries());
					aNewCollector = new ErrorCollector();
				}
				else {
					//insert						
					getSessionFactory().getCurrentSession().saveOrUpdate(
							itemSequence);
					affectItemSequenceCount += itemSequence.getItemCount();
				}
			}
			getSessionFactory().getCurrentSession().getTransaction().commit();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			getSessionFactory().getCurrentSession().getTransaction().rollback();
		}
		LOGGER
				.debug("executeValidateAndPersistInventoryList(IErrorCollector, List<IInventoryItem>) - end");
		return affectItemSequenceCount;
	}

	/**
	 * Updates the location of an inventory item.
	 * 
	 * @param targetLocation the target location
	 * @param domainObjects the domain objects
	 */
	private int executeMoveLocationPersistence(IErrorCollector errorCollector,
			IItemLocation targetLocation,
			IContiguousItemSequence sequenceToUpdate) {
		LOGGER
				.debug("executeUpdateLocationPersistence(List<IInventoryItem> itemSequence="
						+ sequenceToUpdate
						+ ") - started "
						+ (new Date()).toString());
		int itemsMoved = 0;
		if (EaseUtil.isNotNull(sequenceToUpdate)) {
			IErrorCollector aNewCollector = new ErrorCollector();
			sequenceToUpdate.validateUsing(aNewCollector);
			if (aNewCollector.hasErrors()) {
				//save error
				LOGGER.info(sequenceToUpdate.toString());
				LOGGER.info(aNewCollector.getEntries());
				errorCollector.addEntries(aNewCollector.getEntries());
			}
			else {
				List <IInventoryItem> domainObjects = sequenceToUpdate
						.asItemList();
				int totalItems = domainObjects.size();
				//update ranged item table
				itemsMoved += moveInventoryItemRangeLocation(targetLocation,
						sequenceToUpdate);
				if (itemsMoved < totalItems) {
					//update single item table
					itemsMoved += moveInventoryItemLocation(targetLocation,
							domainObjects);
				}
			}
		}
		LOGGER
				.debug("executeUpdateLocationPersistence(List<IInventoryItem>) - ended "
						+ (new Date()).toString());
		return itemsMoved;
	}

	/**
	 * Issues inventory items based on passed in conditions.
	 * 
	 * @param inventoryItem
	 * @param itemQuantity
	 * 
	 * @return IssueMultipleLocalInventoryResponse
	 */
	private IssueMultipleLocalInventoryResponse issueInventory(
			LocalInventoryItem inventoryItem, int itemQuantity) {
		LOGGER.info("issueInventory inventoryItem=" + inventoryItem
				+ ", itemQuantity=" + itemQuantity + ") - start");
		IssueMultipleLocalInventoryResponse issueMultipleLocalInventoryResponse = null;
		List <IInventoryItem> issuedItemList = new ArrayList <IInventoryItem>();
		if ((itemQuantity < 1) || EaseUtil.isNullOrBlank(inventoryItem)) {
			//both of these statement should never be false
			issueMultipleLocalInventoryResponse = new IssueMultipleLocalInventoryResponse(
					new ApplicationException(NOTHING_TO_ISSUE_ERROR));
		}
		else {
			boolean recordsUpdated = false;
			int count = 1;
			List <IInventoryItem> itemList = null;
			do {
				LOGGER.info("Try " + count);
				getSessionFactory().getCurrentSession().beginTransaction();
				try {
					//retrieve inventory for office/station
					Criteria criteria = getSessionFactory().getCurrentSession()
							.createCriteria(ContiguousItemSequence.class);
					criteria.add(Restrictions.eq(INV_OFFICE_FIELD_NAME,
							inventoryItem.getOfficeId()));
					criteria.add(Restrictions.eq(INV_ITEM_TYPE_CODE_FIELD_NAME,
							inventoryItem.getTypeCode()));
					if (EaseUtil.isNullOrBlank(inventoryItem.getStationId())) {
						criteria.add(Restrictions
								.eq(INV_STATION_FIELD_NAME, ""));
					}
					else {
						criteria.add(Restrictions.eq(INV_STATION_FIELD_NAME,
								inventoryItem.getStationId()));
					}
					criteria.addOrder(Property.forName(
							INV_LOWER_BOUNDARY_FIELD_NAME).asc());
					List <IContiguousItemSequence> availableInventoryList = criteria
							.list();
					//issue inventory
					int itemsToIssue = itemQuantity;
					Query hibernateQuery;
					for (IContiguousItemSequence availableItemSequence : availableInventoryList) {
						itemList = availableItemSequence.asItemList();
						if (itemList.size() <= itemsToIssue) {
							// remove sequence record
							issuedItemList.addAll(itemList);
							/*
							getSessionFactory().getCurrentSession().delete(
									availableItemSequence);
							*/
							String query = "DELETE FROM "
									+ availableItemSequence.getClass()
											.getName() + " WHERE " + SYS_ID
									+ " = :SysId" + " AND " + MODIFIED_DATE
									+ " = :OldModifiedDate";
							hibernateQuery = getSessionFactory()
									.getCurrentSession().createQuery(query);
							hibernateQuery.setLong("SysId",
									availableItemSequence.getId());
							hibernateQuery.setTimestamp("OldModifiedDate",
									availableItemSequence.getModifiedDate());
							itemsToIssue -= itemList.size();
						}
						else {
							// update sequence record
							issuedItemList.addAll(itemList.subList(0,
									itemsToIssue));
							/*
							availableItemSequence.setLowerBoundary(itemList
									.get(itemsToIssue).getSequenceNo()
									.getValue());
							getSessionFactory().getCurrentSession().update(
									availableItemSequence);
							*/
							String query = "UPDATE "
									+ availableItemSequence.getClass()
											.getName() + " SET "
									+ INV_LOWER_BOUNDARY_FIELD_NAME
									+ " = :LowerBoundary, " + MODIFIED_DATE
									+ " = :NewModifiedDate" + " WHERE "
									+ SYS_ID + " = :SysId" + " AND "
									+ MODIFIED_DATE + " = :OldModifiedDate";
							hibernateQuery = getSessionFactory()
									.getCurrentSession().createQuery(query);
							hibernateQuery.setString("LowerBoundary", itemList
									.get(itemsToIssue).getSequenceNo()
									.getValue());
							hibernateQuery.setTimestamp("NewModifiedDate",
									CurrentDateProvider.getInstance()
											.getSystemDate());
							hibernateQuery.setLong("SysId",
									availableItemSequence.getId());
							hibernateQuery.setTimestamp("OldModifiedDate",
									availableItemSequence.getModifiedDate());
							itemsToIssue = 0;
						}
						int rows = hibernateQuery.executeUpdate();
						LOGGER.info("Rows affected = " + rows);
						if (rows < 1) {
							throw new HibernateException(ISSUE_UPDATE_ERROR);
						}
						if (itemsToIssue < 1) {
							break;
						}
					}
					//update database
					if (itemsToIssue < 1) {
						getSessionFactory().getCurrentSession()
								.getTransaction().commit();
						issueMultipleLocalInventoryResponse = new IssueMultipleLocalInventoryResponse(
								issuedItemList, issuedItemList.size());
						LOGGER.info("Issued: " + issuedItemList);
						recordsUpdated = true;
					}
					else {
						getSessionFactory().getCurrentSession()
								.getTransaction().rollback();
						issueMultipleLocalInventoryResponse = new IssueMultipleLocalInventoryResponse(
								new ApplicationException(
										ICommonErrorMessageConstants.NOT_ENOUGH_INVENTORY_TO_ISSUE),
								issuedItemList.size());
						recordsUpdated = true;
					}
				}
				catch (HibernateException e) {
					LOGGER.error(e);
					getSessionFactory().getCurrentSession().getTransaction()
							.rollback();
					issuedItemList.clear();
					issueMultipleLocalInventoryResponse = new IssueMultipleLocalInventoryResponse(
							new ApplicationException(e));
				}
			}
			while (!recordsUpdated && count++ < MAX_ISSUE_TRIES);
			if (issueMultipleLocalInventoryResponse == null) {
				//It should never be able to enter this statement so no need to move up
				LOGGER.info("issueInventory - current transaction not closed!");
				issueMultipleLocalInventoryResponse = new IssueMultipleLocalInventoryResponse(
						new ApplicationException("UNABLE TO ISSUE INVENTORY"));
			}
		}
		if (issueMultipleLocalInventoryResponse.hasErrors()) {
			LOGGER.info("issueInventory - end: "
					+ issueMultipleLocalInventoryResponse.getErrorCollector()
							.getEntries().get(0).getExceptionMessage());
		}
		else {
			LOGGER.info("issueInventory - end: count=" + issuedItemList.size());
		}
		return issueMultipleLocalInventoryResponse;
	}

	/**
	 * Updates the location of an inventory item range.
	 * 
	 * @param targetLocation the target location
	 * @param domainObjects the domain objects
	 */
	private int moveInventoryItemRangeLocation(IItemLocation targetLocation,
			IContiguousItemSequence sequenceToUpdate) {
		int itemsMoved = 0;
		List <IContiguousItemSequence> dbSequences = retrieveOrderedInventoryItemRangesFor(
				sequenceToUpdate.getItemType(), sequenceToUpdate.getOfficeId(),
				sequenceToUpdate.getProcessorId(), sequenceToUpdate
						.getLowerBoundary(), sequenceToUpdate
						.getUpperBoundary());
		if (!dbSequences.isEmpty()) {
			for (IContiguousItemSequence dbSequence : dbSequences) {
				if ((sequenceToUpdate.getLowerBoundary().compareTo(
						dbSequence.getLowerBoundary()) < 1)
						&& (sequenceToUpdate.getUpperBoundary().compareTo(
								dbSequence.getUpperBoundary()) > -1)) {
					//update all
					dbSequence.setItemLocation(targetLocation);
					executeSaveOrUpdateBusinessObject(dbSequence);
					itemsMoved += dbSequence.getItemCount();
				}
				else if ((sequenceToUpdate.getLowerBoundary().compareTo(
						dbSequence.getLowerBoundary()) < 1)
						&& (sequenceToUpdate.getUpperBoundary().compareTo(
								dbSequence.getUpperBoundary()) < 0)) {
					//split into 2
					IContiguousItemSequence newDbRecord = new ContiguousItemSequence(
							dbSequence.getItemType().getCode(), targetLocation
									.getOfficeId(), targetLocation
									.getStationId(), dbSequence
									.getLowerBoundary(), sequenceToUpdate
									.getUpperBoundary(), dbSequence
									.isDrawnFromHq());
					List <ISequence> dbItemSequenceList = dbSequence
							.getSequenceNoList();
					for (int index = dbItemSequenceList.size() - 1; index >= 0; index--) {
						//find new lower boundary
						if (dbItemSequenceList.get(index).getSequenceNo()
								.equals(sequenceToUpdate.getUpperBoundary())) {
							break;
						}
						else {
							dbSequence.setLowerBoundary(dbItemSequenceList.get(
									index).getSequenceNo());
						}
					}
					executeSaveOrUpdateBusinessObject(dbSequence);
					executeSaveOrUpdateBusinessObject(newDbRecord);
					itemsMoved += newDbRecord.getItemCount();
				}
				else if ((sequenceToUpdate.getLowerBoundary().compareTo(
						dbSequence.getLowerBoundary()) > 0)
						&& (sequenceToUpdate.getUpperBoundary().compareTo(
								dbSequence.getUpperBoundary()) > -1)) {
					//split into 2
					IContiguousItemSequence newDbRecord = new ContiguousItemSequence(
							dbSequence.getItemType().getCode(), targetLocation
									.getOfficeId(), targetLocation
									.getStationId(), sequenceToUpdate
									.getLowerBoundary(), dbSequence
									.getUpperBoundary(), dbSequence
									.isDrawnFromHq());
					List <ISequence> dbItemSequenceList = dbSequence
							.getSequenceNoList();
					for (ISequence itemSequence : dbItemSequenceList) {
						//find new upper boundary
						if (itemSequence.getSequenceNo().equals(
								sequenceToUpdate.getLowerBoundary())) {
							break;
						}
						else {
							dbSequence.setUpperBoundary(itemSequence
									.getSequenceNo());
						}
					}
					executeSaveOrUpdateBusinessObject(dbSequence);
					executeSaveOrUpdateBusinessObject(newDbRecord);
					itemsMoved += newDbRecord.getItemCount();
				}
				else {
					//if ((sequenceToUpdate.getLowerBoundary().compareTo(
					//	dbSequence.getLowerBoundary()) > 0)
					//	&& (sequenceToUpdate.getUpperBoundary().compareTo(
					//	dbSequence.getUpperBoundary()) < 0))
					//split into 3
					List <ISequence> dbItemSequenceList = dbSequence
							.getSequenceNoList();
					String newUpperBoundary = "";
					String newLowerBoundary = "";
					for (ISequence itemSequence : dbItemSequenceList) {
						//find new upper & lower boundaries
						if (itemSequence.getSequenceNo().compareTo(
								sequenceToUpdate.getLowerBoundary()) < 0) {
							newUpperBoundary = itemSequence.getSequenceNo();
						}
						else if (itemSequence.getSequenceNo().compareTo(
								sequenceToUpdate.getUpperBoundary()) > 0) {
							newLowerBoundary = itemSequence.getSequenceNo();
							break;
						}
					}
					IContiguousItemSequence newDbRecord1 = new ContiguousItemSequence(
							dbSequence.getItemType().getCode(), targetLocation
									.getOfficeId(), targetLocation
									.getStationId(), sequenceToUpdate
									.getLowerBoundary(), sequenceToUpdate
									.getUpperBoundary(), dbSequence
									.isDrawnFromHq());
					IContiguousItemSequence newDbRecord2 = new ContiguousItemSequence(
							dbSequence.getItemType().getCode(), dbSequence
									.getOfficeId(), dbSequence.getStationId(),
							newLowerBoundary, dbSequence.getUpperBoundary(),
							dbSequence.isDrawnFromHq());
					dbSequence.setUpperBoundary(newUpperBoundary);
					executeSaveOrUpdateBusinessObject(dbSequence);
					executeSaveOrUpdateBusinessObject(newDbRecord1);
					executeSaveOrUpdateBusinessObject(newDbRecord2);
					itemsMoved += newDbRecord1.getItemCount();
				}
			}
		}
		return itemsMoved;
	}

	/**
	 * Updates the location of an inventory item.
	 * 
	 * @param targetLocation the target location
	 * @param domainObjects the domain objects
	 */
	private int moveInventoryItemLocation(IItemLocation targetLocation,
			List <IInventoryItem> domainObjects) {
		int itemsMoved = 0;
		getSessionFactory().getCurrentSession().beginTransaction();
		try {
			int readTry = 0; //only retry on the first item then assume all exist
			for (IInventoryItem domainObject : domainObjects) {
				//update table data
				if ((domainObject instanceof StationLocalInventoryItem && !EaseUtil
						.isNullOrBlank(targetLocation.getStationId()))
						|| (domainObject instanceof OfficeLocalInventoryItem && EaseUtil
								.isNullOrBlank(targetLocation.getStationId()))) {
					if (!domainObject.getOfficeId().equals(
							targetLocation.getOfficeId())
							|| (domainObject instanceof StationLocalInventoryItem && !domainObject
									.getStationId().equals(
											targetLocation.getStationId()))) {
						//move from office to office or station to station
						String query = "UPDATE "
								+ LocalInventoryItem.class.getName() + " SET "
								+ INV_OFFICE_FIELD_NAME + " = ? ";
						if (domainObject instanceof StationLocalInventoryItem) {
							query += ", " + INV_STATION_FIELD_NAME + " = ?";
						}
						query += ", " + MODIFIED_DATE + " = ?";
						String whereClause = " WHERE "
								+ INV_OFFICE_FIELD_NAME
								+ " = ? AND sequenceNoValue = ? AND typeCode = ? AND isAvailable = ?";
						if (domainObject instanceof StationLocalInventoryItem) {
							whereClause += " AND " + INV_STATION_FIELD_NAME
									+ " = ?";
							itemsMoved += getSessionFactory()
									.getCurrentSession()
									.createQuery(query + whereClause)
									.setString(0, targetLocation.getOfficeId())
									.setString(1, targetLocation.getStationId())
									.setTimestamp(
											2,
											CurrentDateProvider.getInstance()
													.getSystemDate())
									.setString(3, domainObject.getOfficeId())
									.setString(
											4,
											domainObject.getSequenceNo()
													.getValue()).setString(5,
											domainObject.getType().getCode())
									.setBoolean(6, true).setString(7,
											domainObject.getStationId())
									.executeUpdate();
						}
						else {
							itemsMoved += getSessionFactory()
									.getCurrentSession().createQuery(
											query + whereClause).setString(0,
											targetLocation.getOfficeId())
									.setString(1, domainObject.getOfficeId())
									.setTimestamp(
											2,
											CurrentDateProvider.getInstance()
													.getSystemDate())
									.setString(
											3,
											domainObject.getSequenceNo()
													.getValue()).setString(4,
											domainObject.getType().getCode())
									.setBoolean(5, true).executeUpdate();
						}
					}
				}
				else {
					//move from office to station or station to office
					List <IInventoryItem> aList = null;
					readTry--; //go in at least once each time
					while ((readTry < INV_FETCH_RETRIES)
							&& (aList == null || aList.isEmpty())) {
						readTry++;
						//get object
						Criteria criteria = getSessionFactory()
								.getCurrentSession()
								.createCriteria(domainObject.getClass())
								.setResultTransformer(
										CriteriaSpecification.DISTINCT_ROOT_ENTITY);
						criteria.add(Example.create(domainObject));
						aList = criteria.list();
						if (aList.isEmpty()) {
							IInventoryItem sameItem;
							if (domainObject instanceof OfficeLocalInventoryItem) {
								//look in station
								sameItem = new StationLocalInventoryItem(
										domainObject.getSequenceNo(),
										domainObject.getType(), domainObject
												.getOfficeId(), domainObject
												.getStationId());
							}
							else {
								//look in office
								sameItem = new OfficeLocalInventoryItem(
										domainObject.getSequenceNo(),
										domainObject.getType(), domainObject
												.getOfficeId());
							}
							criteria = getSessionFactory()
									.getCurrentSession()
									.createCriteria(sameItem.getClass())
									.setResultTransformer(
											CriteriaSpecification.DISTINCT_ROOT_ENTITY);
							criteria.add(Example.create(sameItem));
							aList = criteria.list();
						}
						/*
						if ((aList == null || aList.isEmpty())
								&& (readTry < INV_FETCH_RETRIES)) {
							LOGGER.info("Inventory Item not found.  Waiting "
									+ INV_PAUSE_SECONDS
									+ " seconds before trying again.");
								wait(INV_PAUSE_SECONDS * 1000);
						}
						*/
						if (readTry < (INV_FETCH_RETRIES - 1)
								&& (aList == null || aList.isEmpty())) {
							LOGGER
									.info("Inventory Item not found.  Trying again.");
						}
					}
					if (aList == null || aList.isEmpty()) {
						LOGGER.info("Inventory Item not found.");
					}
					else {
						IInventoryItem retrievedItem = (IInventoryItem) aList
								.get(0);
						LocalInventoryItem saveItem = (LocalInventoryItem) LocalInventoryItem
								.newInstanceFor(retrievedItem, targetLocation);
						//insert new object
						getSessionFactory().getCurrentSession().saveOrUpdate(
								saveItem);
						//delete old object
						getSessionFactory().getCurrentSession().delete(
								retrievedItem);
						//increment update count
						itemsMoved++;
					}
				}
			}
			LOGGER.info(itemsMoved + " inventory items have been moved.");
			getSessionFactory().getCurrentSession().getTransaction().commit();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			getSessionFactory().getCurrentSession().getTransaction().rollback();
			throw new ApplicationException(e);
		}
		return itemsMoved;
	}

	/**
	 * Deletes specific sequence from an office.
	 * 
	 * @param domainObjects the domain objects
	 * 
	 * @return records deleted
	 */
	private int purgeInventory(IContiguousItemSequence sequenceToDelete) {
		int itemsToDelete = sequenceToDelete.getItemCount();
		int count = purgeInventoryItemRange(sequenceToDelete, itemsToDelete);
		if (count < itemsToDelete) {
			count += purgeInventoryItemsFor(sequenceToDelete, itemsToDelete);
		}
		return count;
	}

	/**
	 * Deletes data from the office and then inserts new business objects.
	 * 
	 * @param domainObjects the domain objects
	 * 
	 * @return records deleted
	 */
	private int purgeInventoryItemRange(
			IContiguousItemSequence sequenceToDelete, int itemsToDelete) {
		int purgedItems = 0;
		if (!EaseUtil.isNullOrBlank(sequenceToDelete)) {
			if (itemsToDelete > 0) {
				int deleteCount = itemsToDelete;
				int resultCount;
				int seqCount;
				//retrieve DB records
				List <IContiguousItemSequence> dbSequences = retrieveOrderedInventoryItemRangesFor(
						sequenceToDelete.getItemType(), sequenceToDelete
								.getOfficeId(), sequenceToDelete
								.getProcessorId(), sequenceToDelete
								.getLowerBoundary(), sequenceToDelete
								.getUpperBoundary());
				if (!dbSequences.isEmpty()) {
					//find overlap
					for (IContiguousItemSequence dbSequence : dbSequences) {
						seqCount = dbSequence.getItemCount();
						List <IContiguousItemSequence> resultSequences = ContiguousItemSequenceConverter
								.getInstance().removeItemSequenceFrom(
										dbSequence, sequenceToDelete);
						if (resultSequences.isEmpty()) {
							//delete db sequence
							executeDeleteBusinessObject(dbSequence);
							deleteCount -= seqCount;
						}
						else if ((resultSequences.size() > 1)
								|| (!sequenceToDelete.equals(resultSequences
										.get(0)))) {
							//count and delete overlap
							resultCount = 0;
							for (IContiguousItemSequence resultSequence : resultSequences) {
								if (resultCount == 0) {
									dbSequence.setLowerBoundary(resultSequence
											.getLowerBoundary());
									dbSequence.setUpperBoundary(resultSequence
											.getUpperBoundary());
									executeSaveOrUpdateBusinessObject(dbSequence);
								}
								else {
									executeSaveOrUpdateBusinessObject(resultSequence);
								}
								resultCount += resultSequence.getItemCount();
							}
							deleteCount -= seqCount - resultCount;
						}
						if (deleteCount < 1) {
							break;
						}
					}
					purgedItems = itemsToDelete - deleteCount;
				}
			}
		}
		else {
			throw new ApplicationException("UNABLE TO PURGE INVENTORY ITEMS");
		}
		return purgedItems;
	}

	/**
	 * Deletes data from the office and then inserts new business objects.
	 * 
	 * @param domainObjects the domain objects
	 * 
	 * @return records deleted
	 */
	private int purgeInventoryItemsFor(
			IContiguousItemSequence sequenceToDelete, int itemsToDelete) {
		int purgedItems = 0;
		if (!EaseUtil.isNullOrBlank(sequenceToDelete) && (itemsToDelete > 0)) {
			List <IInventoryItem> dbItems = retrieveOrderedInventoryItemsFor(
					sequenceToDelete.getItemType(), sequenceToDelete
							.getItemLocation(), sequenceToDelete
							.getLowerBoundary(), sequenceToDelete
							.getUpperBoundary());
			for (IInventoryItem dbItem : dbItems) {
				if (sequenceToDelete.contains(dbItem)) {
					executeDeleteBusinessObject(dbItem);
					purgedItems++;
				}
				if (purgedItems >= itemsToDelete) {
					break;
				}
			}
		}
		else {
			throw new ApplicationException("UNABLE TO PURGE INVENTORY ITEMS");
		}
		return purgedItems;
	}

	/**
	 * Deletes data from the office and then inserts new business objects.
	 * 
	 * @param domainObjects the domain objects
	 * 
	 * @return records deleted
	 */
	private int purgeOfficeInventory(String officeId, String processorId) {
		int rows = 0;
		if (!EaseUtil.isNullOrBlank(officeId)
				&& !EaseUtil.isNullOrBlank(processorId)) {
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				//delete from item range
				String query = "DELETE FROM "
						+ ContiguousItemSequence.class.getName();
				String whereClause = " WHERE ";
				whereClause += INV_OFFICE_FIELD_NAME + " = '" + officeId + "'";
				whereClause += " AND (";
				whereClause += INV_STATION_FIELD_NAME + " LIKE '" + processorId
						+ "%'";
				whereClause += " OR ";
				whereClause += INV_STATION_FIELD_NAME + " = ''";
				whereClause += ")";
				rows += getSessionFactory().getCurrentSession().createQuery(
						query + whereClause).executeUpdate();
				//delete from single item
				query = "DELETE FROM " + LocalInventoryItem.class.getName();
				whereClause = " WHERE ";
				whereClause += INV_OFFICE_FIELD_NAME + " = '" + officeId + "'";
				whereClause += " AND ";
				whereClause += INV_STATION_FIELD_NAME + " LIKE '" + processorId
						+ "%'";
				whereClause += " AND " + INV_INVALIDATED_ITEM_CODE_FIELD_NAME
						+ " = '" + LocalInventoryItem.UNKNOWN_CODE + "'";
				rows += getSessionFactory().getCurrentSession().createQuery(
						query + whereClause).executeUpdate();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
				LOGGER.info(rows + " records have been deleted for office "
						+ officeId + " and processor " + processorId + ".");
			}
			catch (HibernateException e) {
				LOGGER.error(e);
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new ApplicationException(e);
			}
		}
		else {
			throw new ApplicationException("NO OFFICES TO SEED");
		}
		return rows;
	}

	/**
	 * Return the list of inventory item range of the passed in type and location
	 * 
	 * @return list of ContiguousItemSequence
	 */
	private List <IContiguousItemSequence> retrieveOrderedInventoryItemRangesFor(
			IItemType aType, String officeId, String processorId,
			String lowerBoundary, String upperBoundary) {
		if (EaseUtil.isNotNull(aType) && EaseUtil.isNotNull(officeId)
				&& EaseUtil.isNotNull(lowerBoundary)
				&& EaseUtil.isNotNull(upperBoundary)) {
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				Criteria criteria = getSessionFactory().getCurrentSession()
						.createCriteria(ContiguousItemSequence.class);
				criteria.add(Restrictions.eq(INV_ITEM_TYPE_CODE_FIELD_NAME,
						aType.getCode()));
				criteria.add(Restrictions.eq(INV_OFFICE_FIELD_NAME, officeId));
				criteria.add(Restrictions.like(INV_STATION_FIELD_NAME,
						processorId + "%"));
				criteria.add(Restrictions.le(INV_LOWER_BOUNDARY_FIELD_NAME,
						upperBoundary));
				criteria.add(Restrictions.ge(INV_UPPER_BOUNDARY_FIELD_NAME,
						lowerBoundary));
				criteria.addOrder(Property.forName(
						INV_LOWER_BOUNDARY_FIELD_NAME).asc());
				List <IContiguousItemSequence> aList = (List <IContiguousItemSequence>) criteria
						.list();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
				return aList;
			}
			catch (HibernateException e) {
				LOGGER.error(e);
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new ApplicationException(e);
			}
		}
		else {
			return new ArrayList <IContiguousItemSequence>();
		}
	}

	/**
	 * Return the list of inventory items of the passed in type and location
	 * 
	 * @param aType
	 * @param aLocation
	 * @param lowerBoundary
	 * @param upperBoundary
	 * 
	 * @return IInventoryItem list
	 */
	private List <IInventoryItem> retrieveOrderedInventoryItemsFor(
			IItemType aType, IItemLocation aLocation, String lowerBoundary,
			String upperBoundary) {
		if (EaseUtil.isNotNull(aType) && EaseUtil.isNotNull(aLocation)) {
			//IInventoryItem invItem = LocalInventoryItem.newInstanceFor(aType.getCode(),
			//		aLocation.getOfficeId(), aLocation.getStationId());
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				Criteria criteria = getSessionFactory().getCurrentSession()
						.createCriteria(LocalInventoryItem.class);
				criteria.add(Restrictions.eq(INV_ITEM_TYPE_CODE_FIELD_NAME,
						aType.getCode()));
				criteria.add(Restrictions.eq(
						INV_INVALIDATED_ITEM_CODE_FIELD_NAME,
						LocalInventoryItem.UNKNOWN_CODE));
				criteria.add(Restrictions.eq(INV_OFFICE_FIELD_NAME, aLocation
						.getOfficeId()));
				if (!EaseUtil.isNullOrBlank(aLocation.getStationId())) {
					criteria.add(Restrictions.eq(INV_STATION_FIELD_NAME,
							aLocation.getStationId()));
				}
				//else {
				//	criteria.add(Restrictions.eq(INV_STATION_FIELD_NAME, ""));
				//}
				if (!EaseUtil.isNullOrBlank(lowerBoundary)) {
					criteria.add(Restrictions.ge(
							INV_SEQUENCE_NUMBER_FIELD_NAME, lowerBoundary));
				}
				if (!EaseUtil.isNullOrBlank(upperBoundary)) {
					criteria.add(Restrictions.le(
							INV_SEQUENCE_NUMBER_FIELD_NAME, upperBoundary));
				}
				criteria.addOrder(Property.forName(
						INV_SEQUENCE_NUMBER_FIELD_NAME).asc());
				List <IInventoryItem> aList = (List <IInventoryItem>) criteria
						.list();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
				return aList;
			}
			catch (HibernateException e) {
				LOGGER.error(e);
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new ApplicationException(e);
			}
		}
		else {
			return new ArrayList <IInventoryItem>();
		}
	}

	/**
	 * Return the list of inventory item range of the passed in type and office
	 * 
	 * @return list of inventory items
	 */
	private List <IContiguousItemSequence> retrieveInventoryRange(
			String itemTypeCode, String officeId) {
		getSessionFactory().getCurrentSession().beginTransaction();
		try {
			Criteria criteria = getSessionFactory().getCurrentSession()
					.createCriteria(ContiguousItemSequence.class);
			criteria.add(Restrictions.eq(INV_OFFICE_FIELD_NAME, officeId));
			criteria.add(Restrictions.eq(INV_ITEM_TYPE_CODE_FIELD_NAME,
					itemTypeCode));
			criteria.addOrder(Property.forName(INV_LOWER_BOUNDARY_FIELD_NAME)
					.asc());
			List <IContiguousItemSequence> aList = (List <IContiguousItemSequence>) criteria
					.list();
			getSessionFactory().getCurrentSession().getTransaction().commit();
			return aList;
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			getSessionFactory().getCurrentSession().getTransaction().rollback();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Validate.
	 * 
	 * @param domainObjects the domain objects
	 * 
	 * @return the i error collector
	 */
	private IErrorCollector validate(List <IBusinessObject> domainObjects) {
		IErrorCollector aCollector = new ErrorCollector();
		for (IBusinessObject aBO : domainObjects) {
			aBO.validateUsing(aCollector);
		}
		return aCollector;
	}
}
/**
 *  Modification History:
 *
 *  $Log: LocalPersistenceService.java,v $
 *  Revision 1.59  2012/02/23 19:43:42  mwkfh
 *  updated delete in issueInventory
 *
 *  Revision 1.58  2011/11/19 00:59:18  mwkfh
 *  changed error message
 *
 *  Revision 1.57  2011/11/19 00:56:24  mwkfh
 *  Clean Up
 *
 *  Revision 1.56  2011/11/18 23:29:10  mwkfh
 *  updated issueInventory fixed duplicate inventory defect
 *
 *  Revision 1.55  2011/11/18 23:02:45  mwkfh
 *  update issueInventory to check for 0 rows updated
 *
 *  Revision 1.54  2011/11/18 19:23:10  mwkfh
 *  Clean Up
 *
 *  Revision 1.53  2011/11/18 02:00:00  mwkfh
 *  updated issueInventory for defect duplicating inventory
 *
 *  Revision 1.52  2011/11/07 21:10:43  mwkfh
 *  added comments
 *
 *  Revision 1.51  2011/11/05 00:42:55  mwkfh
 *  added retry on HibernateException in issueInventory and removed single inv table checking
 *
 *  Revision 1.50  2011/11/03 23:42:28  mwkfh
 *  added execute RetrieveLowestSequenceRequest
 *
 *  Revision 1.49  2011/10/27 18:30:18  mwkfh
 *  synchronized issueInventory
 *
 *  Revision 1.48  2011/10/27 00:05:44  mwkfh
 *  updated issueInventory
 *
 *  Revision 1.47  2011/10/27 00:04:58  mwkfh
 *  updated issueInventory
 *
 *  Revision 1.46  2011/10/27 00:03:00  mwkfh
 *  refactored issueInventory
 *
 *  Revision 1.45  2011/09/23 22:03:17  mwkfh
 *  updated retrieveInventoryItemRangeToIssue
 *
 *  Revision 1.44  2011/09/23 21:22:23  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.43  2011/09/23 00:20:29  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.42  2011/07/08 22:47:18  mwkfh
 *  updated orderby in retrieveInventoryItemListToIssue
 *
 *  Revision 1.41  2011/07/07 22:32:41  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.40  2011/07/07 16:02:05  mwkfh
 *  updated issue single to delete items after issuing
 *
 *  Revision 1.39  2011/07/06 21:46:45  mwkfh
 *  updated retrieveOrderedInventoryItemsFor
 *
 *  Revision 1.38  2011/07/06 18:50:36  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.37  2011/07/06 17:10:49  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.36  2011/07/02 00:02:05  mwkfh
 *  updated seed, add, delete to work with redesign
 *
 *  Revision 1.35  2011/06/29 20:46:02  mwkfh
 *  updated purge inventory
 *
 *  Revision 1.34  2011/06/28 21:01:59  mwxxw
 *  Add more logic for issue station level items.
 *
 *  Revision 1.33  2011/06/24 23:00:11  mwxxw
 *  Add more issue item logic.
 *
 *  Revision 1.32  2011/06/23 23:13:09  mwxxw
 *  Add more logic for Local Inventory improvement.
 *
 *  Revision 1.31  2011/06/09 21:54:34  mwkfh
 *  reverted order by
 *
 *  Revision 1.30  2011/06/09 18:32:22  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.29  2011/06/08 20:47:23  mwkfh
 *  updated order by in retrieveInventoryItemListToIssue
 *
 *  Revision 1.28  2011/06/08 17:33:29  mwkfh
 *  added AddLocalInventoryRequest
 *
 *  Revision 1.27  2011/03/23 23:51:41  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.26  2011/02/01 18:53:43  mwkfh
 *  updated retries in executeUpdateLocationPersistence
 *
 *  Revision 1.25  2011/01/28 23:59:23  mwkkc
 *  Looping for ever
 *
 *  Revision 1.24  2011/01/28 23:08:40  mwkkc
 *  Looping for ever
 *
 *  Revision 1.23  2011/01/28 22:52:08  mwkkc
 *  Looping for ever
 *
 *  Revision 1.22  2011/01/20 17:15:31  mwkfh
 *  added pause and retry to wait for needed data possibly not commited yet
 *
 *  Revision 1.21  2011/01/10 21:48:06  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.20  2011/01/07 17:45:51  mwkfh
 *  updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 *  Revision 1.19  2010/12/23 06:18:24  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.17.2.1  2010/12/23 03:13:56  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.18  2010/12/19 21:44:43  mwtjc1
 *  availableInventoryCount is populated with issuedItems
 *
 *  Revision 1.17  2010/12/18 00:38:39  mwtjc1
 *  imports adjusted
 *
 *  Revision 1.16  2010/12/17 18:33:10  mwtjc1
 *  set max results in retrieveInventoryItemListToIssue
 *
 *  Revision 1.15  2010/12/13 20:48:19  mwkfh
 *  added availableInventoryCount for multiple issue response
 *
 *  Revision 1.14  2010/12/09 22:30:55  mwkfh
 *  added check for item already in location
 *
 *  Revision 1.13  2010/12/08 18:11:49  mwkfh
 *  changed to InventoryException and used constants
 *
 *  Revision 1.12  2010/12/05 00:03:16  mwkfh
 *  added IssueMultipleLocalInventoryReequest/Response
 *
 *  Revision 1.11  2010/12/03 18:54:04  mwkfh
 *  updated executeUpdateLocationPersistence to work from office to station and station to office
 *
 *  Revision 1.10  2010/12/03 16:52:08  mwkfh
 *  added move local inventory
 *
 *  Revision 1.9  2010/12/02 16:39:22  mwkfh
 *  allowed seeding with empty list
 *
 *  Revision 1.8  2010/10/15 22:02:53  mwkfh
 *  commented out code not needed
 *
 *  Revision 1.7  2010/10/12 22:25:07  mwpxp2
 *  Added validating of objects before persisting
 *
 *  Revision 1.6  2010/10/11 18:31:08  mwpxp2
 *  More logging added
 *
 *  Revision 1.5  2010/10/11 16:21:41  mwkfh
 *  added functionality for OfficeLocalInventoryItem
 *
 *  Revision 1.4  2010/10/06 22:42:09  mwkfh
 *  updated IssueLocalInventoryResponse to use getInventoryItem()
 *
 *  Revision 1.3  2010/09/30 23:31:05  mwkfh
 *  fixed problem issuing StationInvItem
 *
 *  Revision 1.2  2010/09/21 18:49:50  mwkfh
 *  updated execute(IssueLocalInventoryRequest)
 *
 *  Revision 1.1  2010/09/20 18:25:45  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.5  2010/09/20 16:49:52  mwkfh
 *  added issue local inv item
 *
 *  Revision 1.4  2010/09/14 16:31:34  mwkfh
 *  updated local inventory persistence
 *
 *  Revision 1.3  2010/09/14 00:44:03  mwkfh
 *  made LocalPersistenceService non-static
 *
 *  Revision 1.2  2010/09/13 16:56:58  mwkfh
 *  removed implements
 *
 *  Revision 1.1  2010/09/13 16:54:40  mwkfh
 *  added LocalPersistenceService and Seed for inventory
 *
 */
