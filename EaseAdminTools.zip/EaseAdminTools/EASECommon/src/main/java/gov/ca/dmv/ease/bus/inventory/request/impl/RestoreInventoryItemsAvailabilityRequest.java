/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request for restoring the availability of items in an inventory
 * File: RestoreInventoryItemsAvailabilityRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Dec 8, 2010 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/07/07 22:32:42 $
 * Last Changed By: $Author: mwkfh $
 */
public class RestoreInventoryItemsAvailabilityRequest extends
		AbstractMultipleSequenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4706779317861419926L;

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param listOfItems the list of items
	 */
	public RestoreInventoryItemsAvailabilityRequest(IUserContext context,
			List <IContiguousItemSequence> listOfItems) {
		super(context, listOfItems);
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param listOfItems the list of items
	 */
	public RestoreInventoryItemsAvailabilityRequest(IUserContext context,
			IContiguousItemSequence listOfItems) {
		super(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: RestoreInventoryItemsAvailabilityRequest.java,v $
 *  Revision 1.2  2011/07/07 22:32:42  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.1  2010/12/08 19:03:13  mwkfh
 *  added RestoreInventoryItemsAvailabilityRequest
 *
 */
