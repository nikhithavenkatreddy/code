/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.subject.impl.CustomerOrganization;
import gov.ca.dmv.ease.bo.subject.impl.VehicleSalesPerson;

import java.math.BigDecimal;

/**
 * Description: This class captures information pertaining to fee for Miscellaneous collections
 * File: MiscellaneousVariedFeeCollections.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class MiscellaneousVariedFeeApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1219406201092934039L;
	/** (Verify?) If the applicant is a company like driving school. */
	private CustomerOrganization applicantCompany;
	/** The collectionCode (10 - Phone charges). */
	private CodeSetElement collectionCode;
	/** The fee to be collected for the collection code - varies depending on code  */
	private BigDecimal feeAmount;
	/** The customer last name or name of customer submitting phone charges or sp license nbr or the companys name */
	private String otherIdentifyingInformation;
	/** If the applicant is a Sales Person. */
	private VehicleSalesPerson vehicleSalesPerson;

	/**
	 * Default Constructor.
	 */
	public MiscellaneousVariedFeeApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the applicantCompany
	 */
	public CustomerOrganization getApplicantCompany() {
		return applicantCompany;
	}

	/**
	 * @return the collectionCode
	 */
	public CodeSetElement getCollectionCode() {
		return collectionCode;
	}

	/**
	 * @return the feeAmount
	 */
	public BigDecimal getFeeAmount() {
		return feeAmount;
	}

	/**
	 * @return the otherIdentifyingInformation
	 */
	public String getOtherIdentifyingInformation() {
		return otherIdentifyingInformation;
	}

	/**
	 * @return the vehicleSalesPerson
	 */
	public VehicleSalesPerson getVehicleSalesPerson() {
		return vehicleSalesPerson;
	}

	/**
	 * @param applicantCompany the applicantCompany to set
	 */
	public void setApplicantCompany(CustomerOrganization applicantCompany) {
		this.applicantCompany = applicantCompany;
	}

	/**
	 * @param collectionCode the collectionCode to set
	 */
	public void setCollectionCode(CodeSetElement collectionCode) {
		this.collectionCode = collectionCode;
	}

	/**
	 * @param feeAmount the feeAmount to set
	 */
	public void setFeeAmount(BigDecimal feeAmount) {
		this.feeAmount = feeAmount;
	}

	/**
	 * @param otherIdentifyingInformation the otherIdentifyingInformation to set
	 */
	public void setOtherIdentifyingInformation(
			String otherIdentifyingInformation) {
		this.otherIdentifyingInformation = otherIdentifyingInformation;
	}

	/**
	 * @param vehicleSalesPerson the vehicleSalesPerson to set
	 */
	public void setVehicleSalesPerson(VehicleSalesPerson vehicleSalesPerson) {
		this.vehicleSalesPerson = vehicleSalesPerson;
	}
}
