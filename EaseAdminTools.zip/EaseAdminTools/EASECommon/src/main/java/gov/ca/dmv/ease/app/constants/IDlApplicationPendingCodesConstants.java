/**
 * 
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: These are the Dl Application Pending Codes: Refer to Table 18
 * from DL manuals IDlApplicationPendingCodesConstants.java Module:
 * gov.ca.dmv.ease.app.constants Created: Mar 26, 2010
 * 
 * @author MWBXP5
 * @version $Revision: 1.2 $ Last Changed: $Date: 2011/05/26 16:22:19 $ Last
 *          Changed By: $Author: mwkfh $
 */
public interface IDlApplicationPendingCodesConstants {
	/** The Constant _3_D_T_FAILURES_OR_DISAPPROVALS. */
	String _3_D_T_FAILURES_OR_DISAPPROVALS = "*8";
	/** The Constant BIRTH_DATE_DISCREPANCY. */
	String BIRTH_DATE_DISCREPANCY = "**3";
	/** The Constant LOST_APPLICATION. */
	String LOST_APPLICATION = "**2";
	/** The Constant PENDING_APP_SUBMITTED_TO_EDP_BY_ISSUANCE. */
	String PENDING_APP_SUBMITTED_TO_EDP_BY_ISSUANCE = " **1";
	/** The Constant PENDING_APPLICATION_FILE. */
	String PENDING_APPLICATION_FILE = "*4";
	/** The Constant PENDING_AUTOMATED_APPLICATIONS. */
	String PENDING_AUTOMATED_APPLICATIONS = "8";
	/** The Constant PENDING_RBM_CDL_TEMP_ISSUED. */
	String PENDING_RBM_CDL_TEMP_ISSUED = "9";
	/** The Constant PENDING_RENEWAL_BY_MAIL. */
	String PENDING_RENEWAL_BY_MAIL = "5";
	/** The Constant RENEWAL_BY_MAIL_PENDING_MEDICAL_HEALTH_QUESTIONNAIRE. */
	String RENEWAL_BY_MAIL_PENDING_MEDICAL_HEALTH_QUESTIONNAIRE = "7";
	/** The Constant RENEWAL_BY_MAIL_PENDING_SSN. */
	String RENEWAL_BY_MAIL_PENDING_SSN = "6";
	/** The Constant VOIDED_APPLICATION. */
	String VOIDED_APPLICATION = "*0";
	/** The Constant DRIVER_LICENSE_PENDED. This represents only DL was pended. */
	String DRIVER_LICENSE_PENDED = "D";
	/** The Constant ID_CARD_PENDED. This represents only ID was pended. */
	String ID_CARD_PENDED = "I";
	/** The Constant DL_ID_PENDED. This represents both DL & ID was pended. */
	String DL_ID_PENDED = "B";
}
/**
 *  Modification History:
 *
 *  $Log: IDlApplicationPendingCodesConstants.java,v $
 *  Revision 1.2  2011/05/26 16:22:19  mwkfh
 *  updated history comments
 *
 *  Revision 1.1  2011/05/26 00:49:38  mwxxw
 *  Fix defect 644.
 *
 *  Revision 1.4  2011/04/28 15:50:24  mwuxb
 *  Added pending constants for DL & ID.
 *
 *  Revision 1.3  2010/11/18 23:42:15  mwpxp2
 *  Added missing javadoc; sorted; deleted redundant modifiers; added file footer
 *
 *  Revision 1.2  2010/07/26 15:34:00  mwpxp2
 *  Bulk cleanup
 *  
 *  Revision 1.1.2.1  2010/03/29 12:59:00  mwgrk
 *  Rebased to Head version
 *  
 *  Revision 1.1  2010/03/26 17:48:00  mwbxp5
 *  Initial Commit --> Need to add javadoc
 *
 */
