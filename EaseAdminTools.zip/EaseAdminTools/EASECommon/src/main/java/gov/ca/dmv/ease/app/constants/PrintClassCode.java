/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

import java.util.HashMap;
import java.util.Map;


/**
 * Description: Enum class for print class code.
 * File: PrintClassCode.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Apr 4, 2011 
 * @author MWXXW  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/08/14 20:42:49 $
 * Last Changed By: $Author: mwrrv3 $
 */
public enum PrintClassCode {
	CLASS_CODE_60("60", PrintRequestTypes.INTERIM_LICENSE_LDD0602),
	CLASS_CODE_61("61", PrintRequestTypes.INSTRUCTION_PERMIT_LDD0611),
	CLASS_CODE_61_1("61", PrintRequestTypes.ADDL_INSTRUCTION_PERMIT_LIMITATIONS_LDD0612),
	CLASS_CODE_62("62", PrintRequestTypes.TEMP_LICENSE_LDD0602),
	CLASS_CODE_63("63", PrintRequestTypes.TEST_RESULTS_1_LDD0631),
	CLASS_CODE_63_2("63", PrintRequestTypes.TEST_RESULTS_2_LDD0632),
	CLASS_CODE_64("64", PrintRequestTypes.ADD_COURT_RESTRICTION_PAYMENT_RECEIPT),
	CLASS_CODE_64_1("64", PrintRequestTypes.DL_RECEIPT),
	CLASS_CODE_64_2("64", PrintRequestTypes.FR_PENALITY_FEE_PAYMENT),
	CLASS_CODE_64_3("64", PrintRequestTypes.MISCELLANEOUS_VARIED_FEE_DOCUMENT),
	CLASS_CODE_64_4("64", PrintRequestTypes.MISC_FIXED_FEE_ITEMS_DOCUMENT),
	CLASS_CODE_64_5("64", PrintRequestTypes.REISSUE_FEE_RECEIPT),
	CLASS_CODE_64_6("64", PrintRequestTypes.REMOVE_COURT_RESTRICTION_PAYMENT_RECEIPT),
	CLASS_CODE_64_7("64", PrintRequestTypes.SPECIAL_CERTIFICATE_PAYMENT_RECEIPT),
	CLASS_CODE_64_8("64", PrintRequestTypes.TRANSACTION_RECEIPT),
	CLASS_CODE_64_9("64", PrintRequestTypes.TRANSIT_TRAINING_RECEIPT),
	CLASS_CODE_65("65", PrintRequestTypes.PHOTO_RETAKE_NOTIFICATION_DOCUMENT),
	CLASS_CODE_72("72", PrintRequestTypes.OCCUPATIONAL_LICENSING_SALES_PERSON_NUMBER_ASSIGNMENT_DOCUMENT),
	CLASS_CODE_74("74", PrintRequestTypes.ISSUANCE_REFERRAL_DOUBLES_LDP0741),
	CLASS_CODE_74_1("74", PrintRequestTypes.ISSUANCE_REFERRAL_FOR_UPDATE_LDP0742),
	CLASS_CODE_74_2("74", PrintRequestTypes.ISSUANCE_REFERRAL_LDP0742),
	CLASS_CODE_75("75", PrintRequestTypes.FTA_FTP_DOCUMENT),
	CLASS_CODE_75_1("75", PrintRequestTypes.FTA_RELEASE_CERT_UPDATE_DOCUMENT),
	CLASS_CODE_75_2("75", PrintRequestTypes.FTP_RELEASE_CERT_UPDATE_DOCUMENT),
	CLASS_CODE_77("77", PrintRequestTypes.PRT_RECEIPT_OF_PROOF_OF_FILING_DOCUMENT),
	CLASS_CODE_78("78", PrintRequestTypes.AUTOMATED_DL22_LICENSE),
	CLASS_CODE_78_1("78", PrintRequestTypes.MISC_TEMPORARY_LICENSE),
	CLASS_CODE_80("80", PrintRequestTypes.FTA_FTP_PAYMENT_RECEIPT_DOCUMENT),
	CLASS_CODE_81("81", PrintRequestTypes.MEDICAL_REPORT_UPDATE_DOCUMENT),
	CLASS_CODE_82("82", PrintRequestTypes.STATE_OF_RECORD_DOCUMENT),
	CLASS_CODE_83("83", PrintRequestTypes.CDLIS_AND_NDR_MATCHES_REPORT),
	CLASS_CODE_83_1("83", PrintRequestTypes.PDPS_AND_NDR_MATCHES_REPORT),
	CLASS_CODE_84("84", PrintRequestTypes.ID_CARD_VOLUNTARY_CANCELLATION),
	CLASS_CODE_85("85", PrintRequestTypes.ORGAN_DONOR_1_LDD0851),
	CLASS_CODE_85_1("85", PrintRequestTypes.ORGAN_DONOR_2_LDD0852),
	CLASS_CODE_86("86", PrintRequestTypes.VOTER_REGISTRATION_LDD0861);
	
	private final String classCode;
	private final PrintRequestTypes printRequestType;
	private static Map <PrintRequestTypes, PrintClassCode> REQ_TYPE_TO_CLASS_CODE_MAP;
	
	// Make the mapping
	static
	{
		REQ_TYPE_TO_CLASS_CODE_MAP = new HashMap <PrintRequestTypes, PrintClassCode>();
		for (PrintClassCode classCode : PrintClassCode.values() ) {
			REQ_TYPE_TO_CLASS_CODE_MAP.put(classCode.getPrintRequestType(),
					classCode);
		}
	}
	
	/**
	 * Instantiates a new issuance referral messages type.
	 * 
	 * @param indicator the indicator
	 * @param description the description
	 */
	private PrintClassCode(String classCode, PrintRequestTypes printRequestType) {
		this.classCode = classCode;
		this.printRequestType = printRequestType;
	}

	/**
	 * Getter for classCode.
	 * @return
	 */
	public String getClassCode() {
		return classCode;
	}

	/**
	 * Setter for PrintRequestType.
	 * @return
	 */
	public PrintRequestTypes getPrintRequestType() {
		return printRequestType;
	}
	
	public static PrintClassCode getClassCodeByPrintRequestType(PrintRequestTypes printRequestType) {
		PrintClassCode printClassCode = null;
		if (REQ_TYPE_TO_CLASS_CODE_MAP.containsKey(printRequestType)) {
			printClassCode = REQ_TYPE_TO_CLASS_CODE_MAP.get(printRequestType);
		}
		return printClassCode;
	}
}


/**
 *  Modification History:
 *
 *  $Log: PrintClassCode.java,v $
 *  Revision 1.4  2012/08/14 20:42:49  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.3  2011/04/07 18:17:16  mwxxw
 *  Add new enum: TEMP_LICENSE_LDD0602.
 *
 *  Revision 1.2  2011/04/06 22:19:07  mwxxw
 *  Add more printClassCode mapping according requirement.
 *
 *  Revision 1.1  2011/04/06 00:32:16  mwxxw
 *  New files add for calculation printClassCode for printed docs.
 *
 */
