package gov.ca.dmv.ease.admintool.servlet;

import gov.ca.dmv.ease.admintool.bo.Office;
import gov.ca.dmv.ease.admintool.dao.AdminToolDao;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Description: Servlet implementation class AdminTool.
 * File: Office.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 19, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/10/24 00:33:45 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class AdminToolServlet extends HttpServlet {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	/** The offices. */
	private List <Office> offices = null;

	@Override
	public void init() throws ServletException {
		super.init();
		//IAdminToolPersistenceService adminDAO = new AdminToolDao();
		//offices = adminDAO.getAllOffices();
	}

	/**
	 * Instantiates a new admin tool.
	 *
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminToolServlet() {
		super();
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * Process request.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.setAttribute("allOffices", offices);
		RequestDispatcher rd = request.getRequestDispatcher("");
		rd.forward(request, response);
	}
}