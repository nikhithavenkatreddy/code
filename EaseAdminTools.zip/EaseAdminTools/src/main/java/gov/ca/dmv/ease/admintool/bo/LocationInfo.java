/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;

/**
 * Description: I reperesent the business object, LOCATION
 * File: LocationInfo.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Sep 5, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class LocationInfo {
	/** The sys id. */
	private Integer sysId;
	/** The station sys id. */
	private Integer stationSysId;
	/** The station ip addr. */
	private String stationIpAddr;
	/** The office id. */
	private String officeId;
	/** The office mnemonic. */
	private String officeMnemonic;
	/** The l1 server cd. */
	private String l1ServerCd;
	/** The l1 server sufx. */
	private String l1ServerSufx;
	/** The business object desc. */
	private String businessObjectDesc;

	/**
	 * Gets the sys id.
	 *
	 * @return the sys id
	 */
	public Integer getSysId() {
		return sysId;
	}

	/**
	 * Sets the sys id.
	 *
	 * @param sysId the new sys id
	 */
	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}

	/**
	 * Gets the station sys id.
	 *
	 * @return the station sys id
	 */
	public Integer getStationSysId() {
		return stationSysId;
	}

	/**
	 * Sets the station sys id.
	 *
	 * @param stationSysId the new station sys id
	 */
	public void setStationSysId(Integer stationSysId) {
		this.stationSysId = stationSysId;
	}

	/**
	 * Gets the station ip addr.
	 *
	 * @return the station ip addr
	 */
	public String getStationIpAddr() {
		return stationIpAddr;
	}

	/**
	 * Sets the station ip addr.
	 *
	 * @param stationIpAddr the new station ip addr
	 */
	public void setStationIpAddr(String stationIpAddr) {
		this.stationIpAddr = stationIpAddr;
	}

	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the office mnemonic.
	 *
	 * @return the office mnemonic
	 */
	public String getOfficeMnemonic() {
		return officeMnemonic;
	}

	/**
	 * Sets the office mnemonic.
	 *
	 * @param officeMnemonic the new office mnemonic
	 */
	public void setOfficeMnemonic(String officeMnemonic) {
		this.officeMnemonic = officeMnemonic;
	}

	/**
	 * Gets the l1 server cd.
	 *
	 * @return the l1 server cd
	 */
	public String getL1ServerCd() {
		return l1ServerCd;
	}

	/**
	 * Sets the l1 server cd.
	 *
	 * @param serverCd the new l1 server cd
	 */
	public void setL1ServerCd(String serverCd) {
		l1ServerCd = serverCd;
	}

	/**
	 * Gets the l1 server sufx.
	 *
	 * @return the l1 server sufx
	 */
	public String getL1ServerSufx() {
		return l1ServerSufx;
	}

	/**
	 * Sets the l1 server sufx.
	 *
	 * @param serverSufx the new l1 server sufx
	 */
	public void setL1ServerSufx(String serverSufx) {
		l1ServerSufx = serverSufx;
	}

	/**
	 * Gets the business object desc.
	 *
	 * @return the business object desc
	 */
	public String getBusinessObjectDesc() {
		return businessObjectDesc;
	}

	/**
	 * Sets the business object desc.
	 *
	 * @param businessObjectDesc the new business object desc
	 */
	public void setBusinessObjectDesc(String businessObjectDesc) {
		this.businessObjectDesc = businessObjectDesc;
	}
}
