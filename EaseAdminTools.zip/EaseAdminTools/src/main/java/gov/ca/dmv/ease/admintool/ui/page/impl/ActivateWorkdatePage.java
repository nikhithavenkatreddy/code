package gov.ca.dmv.ease.admintool.ui.page.impl;

import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.dao.AdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.response.impl.SaveWorkDateStatusResponse;
import gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.admin.impl.OfficeWorkdate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
//import javax.faces.component.UIData;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

/**
 * The Class UpdateWorkDateStatusPage.
 */
public class ActivateWorkdatePage {
	/** The data. */
	public List <EmployeeWorkdateControl> data = new ArrayList <EmployeeWorkdateControl>();
	/** The data to be modified. */
	public List <String> authorizedWorkDateStatuses = new ArrayList <String>();
	/** The admin dao. */
	private static IAdminToolPersistenceService adminDAO = new AdminToolPersistenceService();
	/** The office data. */
	public List <Office> officeData = new ArrayList <Office>();
	/** The office id. */
	private String officeId;
	/** The select items. */
	private List <SelectItem> selectItems = new ArrayList <SelectItem>();
	/** The tech id. */
	private String techId;
	/** The data table. */
	private HtmlDataTable dataTable;
	/** The load. */
	private boolean load = true;
	/** The result office id. */
	private String resultOfficeId;
	/** The result office name. */
	private String resultOfficeName;
	/** The result tech id. */
	private String resultTechId;
	/** The result work date. */
	private String resultWorkDate;
	/** The status. */
	private String status;
	/** The work date. */
	private Date workDate;
	List<Boolean> checkboxList;

	/** The show tech id. */
	private boolean showTechId;	

	/**
	 * Gets the faces context.
	 *
	 * @return the faces context
	 */
	private FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}
	
	/**
	 * Copy from.
	 *
	 * @param aList the a list
	 * @return the list
	 */
	protected List <String> copyFrom(List <EmployeeWorkdateControl> aList) {
		if (aList == null || aList.isEmpty()) {
			return new ArrayList <String>(0);
		}
		else {
			List <String> aCopy = new ArrayList <String>(aList.size());
			for (EmployeeWorkdateControl employeeOfficeDetails : aList) {
				if(showTechId)
					aCopy.add(employeeOfficeDetails.getOfficeWorkdate().getStatus());
				else
					aCopy.add(employeeOfficeDetails.getStatus());
			}
			return aCopy;
		}
	}

	//Getters and Setters  -------------------------------------------------
	/**
	 * Checks if is show tech id.
	 *
	 * @return true, if is show tech id
	 */
	public boolean isShowTechId() {
		return showTechId;
	}

	/**
	 * Sets the show tech id.
	 *
	 * @param showTechId the new show tech id
	 */
	public void setShowTechId(boolean showTechId) {
		this.showTechId = showTechId;
	}

	/**
	 * Gets the result office id.
	 *
	 * @return the result office id
	 */
	public String getResultOfficeId() {
		return resultOfficeId;
	}

	/**
	 * Sets the result office id.
	 *
	 * @param resultOfficeId the new result office id
	 */
	public void setResultOfficeId(String resultOfficeId) {
		this.resultOfficeId = resultOfficeId;
	}

	/**
	 * Gets the result office name.
	 *
	 * @return the result office name
	 */
	public String getResultOfficeName() {
		return resultOfficeName;
	}

	/**
	 * Sets the result office name.
	 *
	 * @param resultOfficeName the new result office name
	 */
	public void setResultOfficeName(String resultOfficeName) {
		this.resultOfficeName = resultOfficeName;
	}

	/**
	 * Gets the result tech id.
	 *
	 * @return the result tech id
	 */
	public String getResultTechId() {
		return resultTechId;
	}

	/**
	 * Sets the result tech id.
	 *
	 * @param resultTechId the new result tech id
	 */
	public void setResultTechId(String resultTechId) {
		this.resultTechId = resultTechId;
	}

	/**
	 * Gets the result work date.
	 *
	 * @return the result work date
	 */
	public String getResultWorkDate() {
		return resultWorkDate;
	}

	/**
	 * Sets the result work date.
	 *
	 * @param resultWorkDate the new result work date
	 */
	public void setResultWorkDate(String resultWorkDate) {
		this.resultWorkDate = resultWorkDate;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the work date.
	 *
	 * @return the work date
	 */
	public Date getWorkDate() {
		return workDate;
	}

	/**
	 * Sets the work date.
	 *
	 * @param workDate the new work date
	 */
	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}

	/**
	 * Gets the data table.
	 *
	 * @return the data table
	 */
	public HtmlDataTable getDataTable() {
		return dataTable;
	}

	/**
	 * Sets the data table.
	 *
	 * @param dataTable the new data table
	 */
	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}

	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the tech id.
	 *
	 * @return the tech id
	 */
	public String getTechId() {
		return techId;
	}

	/**
	 * Sets the tech id.
	 *
	 * @param techId the new tech id
	 */
	public void setTechId(String techId) {
		this.techId = techId;
	}

	//Get Drop Down Select Items  -------------------------------------------------
	/**
	 * Gets the select office tech id info.
	 *
	 * @return the select office tech id info
	 */
	public List <EmployeeWorkdateControl> getSelectOfficeTechIdInfo() {
		return data;
	}

	/**
	 * Gets the office info.
	 *
	 * @return the office info
	 */
	public List <Office> getOfficeInfo() {
		officeData = adminDAO.getAllOffices();
		return officeData;
	}

	/**
	 * Gets the select offices.
	 *
	 * @return the select offices
	 */
	public List <SelectItem> getSelectOffices() {
		if (load) {
			for (Office data : getOfficeInfo())
				selectItems.add(new SelectItem(data.getOfficeId(), data
						.getOfficeId()
						+ " - " + data.getName()));
		}
		load = false;
		return selectItems;
	}

	//Action methods -------------------------------------------------	 
	/**
	 * Continue to search action.
	 */
	public String continueToSearchAction() {
		System.out.println(officeId);
		System.out.println(techId);
		InputData inputData = new InputData();
		inputData.setOfficeId(officeId);
		inputData.setTechId(techId);
		if (techId == null || techId.isEmpty()) {
			showTechId = false;
			data = adminDAO.getEmployeeOfficeDetailsByOfficeId(inputData);
			
		}
		else {
			showTechId = true;
			data = adminDAO.getEmployeeOfficeDetails(inputData);
		}
		System.out.println(showTechId);
		authorizedWorkDateStatuses = copyFrom(data);
		if (data.size() == 0){
			getFacesContext().addMessage(null, new FacesMessage("NO RECORDS FOUND" + "-brErrorMsg"));
		}
		else {
			if(getSystemGeneratedCount() > 1 && !showTechId) {
				getFacesContext().addMessage(null, new FacesMessage("PLEASE CONTACT ISD" + "-brErrorMsg"));
			} else {
				getFacesContext().addMessage(null, new FacesMessage(data.size() + " RECORD(S) FOUND" + "-brErrorMsg"));
			}
		}		
		return "";
	}

	/**
	 * Continue to reset action.
	 *
	 * @return the string
	 */
	public String continueToResetAction() {
		reset();
		return "";
	}

	/**
	 * Continue to update work date status action.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String continueToUpdateWorkDateStatusAction() throws IOException {
		if (data != null) {
			List <EmployeeWorkdateControl> detailsToUpdate = new ArrayList <EmployeeWorkdateControl>();
			boolean statusForTechId = isShowTechId();
			for (int index = 0; index < data.size(); index++) {
				if (statusForTechId) {
					if (authorizedWorkDateStatuses.get(index) != data
							.get(index).getStatus()) {
						// Employee Status
						/*if (data.get(index).getStatus() != null
								&& !data.get(index).getStatus()
										.equalsIgnoreCase("S")) {
							detailsToUpdate.add(data.get(index));
						}*/
						
						if (data.get(index).getToAuthorizeWrkDt() != null && data.get(index).getToAuthorizeWrkDt()) {
							detailsToUpdate.add(data.get(index));
						}
					}
				} else {
					// Office Status
					/*if (data.get(index).getOfficeWorkdate().getStatus() != null
							&& data.get(index).getOfficeWorkdate().getStatus()
									.equalsIgnoreCase("A")) {
						detailsToUpdate.add(data.get(index));
					}*/
					if (data.get(index).getToAuthorizeWrkDt() != null && data.get(index).getToAuthorizeWrkDt()) {
						detailsToUpdate.add(data.get(index));
					}
				}
			}
			if(detailsToUpdate == null || detailsToUpdate.size() == 0) {
				getFacesContext().addMessage(null, new FacesMessage("PLEASE UPDATE AT LEAST ONE RECORD" + "-brErrorMsg"));
				return null;
			}
			boolean updateBoth = true;
			if (techId == null || techId.isEmpty()) {
				updateBoth = false;
			}
			SaveWorkDateStatusResponse status = null;
			if (statusForTechId) {
				status = adminDAO.updateWorkDateStatus(detailsToUpdate,
						updateBoth);
			} else {
				List<OfficeWorkdate> officeWorkdateList = new ArrayList<OfficeWorkdate>();
				for (EmployeeWorkdateControl empCntrl : detailsToUpdate) {
					officeWorkdateList.add(empCntrl.getOfficeWorkdate());
				}
				status = adminDAO
						.updateOfficeWorkDateStatus(officeWorkdateList);
			}
			
			if (status != null && !status.getErrorCollector().hasErrors()) {
				reset();
				getFacesContext().addMessage(null, new FacesMessage("RECORDS WERE UPDATED SUCCESSFULLY" + "-brErrorMsg"));
				return null;
			}
		}
		return "";
	}

	/**
	 * Continue to home action.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public String continueToHomeAction() throws IOException {
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"/EaseAdminTools");
		return "";
	}

	//General purpose local methods ----------------------------------------------
	/**
	 * Reset.
	 */
	private void reset() {
		data = new ArrayList <EmployeeWorkdateControl>();
		officeData = new ArrayList <Office>();
		officeId = "";
		selectItems = new ArrayList <SelectItem>();
		techId = "";
		load = true;
		resultOfficeId = "";
		resultOfficeName = "";
		resultTechId = "";
		resultWorkDate = "";
		status = "";
		showTechId = false;		
	}
	
	/**
	 * 
	 * @param e
	 */
	public void statusChangeMethod(ValueChangeEvent e){
		//String selectedOffice1 = e.getNewValue().toString();
		//System.out.println(" selectedOffice1 value is : " + selectedOffice1);
		EmployeeWorkdateControl empWkDtCntrl = (EmployeeWorkdateControl) getDataTable().getRowData();
	}
	
	public int getSystemGeneratedCount() {
		int count = 0;
		if(data != null) {
			for(EmployeeWorkdateControl control : data) {
				if("S".equalsIgnoreCase(control.getOfficeWorkdate().getStatus())) {
					count++;
				}
			}
		}
		return count;
	}

	public List<Boolean> getCheckboxList() {
		return checkboxList;
	}

	public void setCheckboxList(List<Boolean> checkboxList) {
		this.checkboxList = checkboxList;
	}
	
	
//	public void statusChangeMethod1(ValueChangeEvent e){
//	    //UIData data = (UIData) e.getComponent().findComponent("dt1");
//	    int rowIndex = data.getRowIndex();
//	    System.out.println(" rowIndex value is : " + rowIndex);
//	    Object myNewValue = e.getNewValue();
//	    System.out.println(" myNewValue value is : " + myNewValue);
//	    Object myOldValue = e.getOldValue();
//	    System.out.println(" myOldValue value is : " + myOldValue);
//	}
}
	
