/**
 * 
 */
package gov.ca.dmv.ease.admintool.ui.page.impl;

import gov.ca.dmv.ease.admintool.dao.CodeSetPersistenceService;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.ibm.icu.util.Calendar;


/**
 * Description: Backing bean for manage code set function
 * File: ManageCodeSetPage.java
 * Module:  gov.ca.dmv.ease.admintool.ui.page.impl
 * Created: Oct 25, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/31 23:06:32 $
 * Last Changed By: $Author: mwsec2 $
 */
public class ManageCodeSetPage {
	
	/* Used by JSF, this map holds entries where CodeSetElement IDs as the keys and a Boolean value 
	 * is used to indicate whether the elements have been checked for deletion */
	private Map<Long, Boolean> checked = new HashMap<Long, Boolean>();
	private String messages;
	private String newElementCode;
	private String newElementDescription;
	private String newElementName;
	private String selectedCodeSetId;
	
	/**
	 * Adds an item to the selected code set, using the values assigned to
	 * the 'new element'.
	 * 
	 * @return
	 */
	public String addElementAction() {
		if (getSelectedCodeSetId() == null) {
			return null;
		}
		String msg = null;
		if (EaseUtil.isNullOrBlank(newElementCode)) {
			msg = "CODE FIELD IS REQUIRED";
		}
		if (EaseUtil.isNullOrBlank(newElementName)) {
			if (EaseUtil.isNullOrBlank(msg)) {
				msg = "NAME FIELD IS REQUIRED";
			} else {
				msg += " - NAME FIELD IS REQUIRED";
			}
			
		}
		if (EaseUtil.isNullOrBlank(newElementDescription)) {
			if (EaseUtil.isNullOrBlank(msg)) {
				msg = "DESCRIPTION FIELD IS REQUIRED";
			} else {
				msg += " - DESCRIPTION FIELD IS REQUIRED";
			}
		}
		messages = msg;
		if (messages != null) {
			return null;
		}
		long selectedCodeSetId = Long.parseLong(getSelectedCodeSetId());
		CodeSet codeSet = CodeSetPersistenceService.getInstance()
				.getCodeSetById(selectedCodeSetId);
		CodeSetElement element = new CodeSetElement(newElementName, newElementCode, 
				newElementDescription);
		element.setEffectiveDate(new Date());
		Calendar c = Calendar.getInstance();		
		c.add(Calendar.YEAR, 100);  
		element.setEndDate(c.getTime());
		element.setCodeCategory(codeSet.getCodeSetName());
		codeSet.add(element);
		CodeSetPersistenceService.getInstance().updateCodeSet(codeSet);
		setNewElementCode(null);
		setNewElementName(null);
		setNewElementDescription(null);
		return null;
	}
	
	/**
	 * Deletes the checked elements from the selected code set. If the element is used by another
	 * code set, then only the association between the selected code set and the element is deleted.
	 * If the element is not used by another code set, then it is completely deleted.
	 * @return
	 */
	public String deleteElementsAction() {
		setMessages(null);
		if (getSelectedCodeSetId() == null) {
			return null;
		}
		List<CodeSetElement> checkedElements = new ArrayList<CodeSetElement>();
		for (ICodeSetElement e : getElementsOfSelectedCodeSet()) {
			CodeSetElement element = (CodeSetElement) e;
			if (checked.get(element.getId())) {
				checkedElements.add(element);
			}
		}
		checked.clear();
		if (checkedElements.isEmpty()) {
			return null;
		}
		long selectedCodeSetId = Long.parseLong(getSelectedCodeSetId());
		CodeSet codeSet = CodeSetPersistenceService.getInstance()
				.getCodeSetById(selectedCodeSetId);
		for (CodeSetElement element : checkedElements) {
			codeSet.getCodeSetElements().remove(element);
		}
		CodeSetPersistenceService.getInstance().updateCodeSet(codeSet);
		for (CodeSetElement element : checkedElements) {
			long id = ((IBusinessObject) element).getId();
			boolean isOrphan = CodeSetPersistenceService.getInstance()
					.getCodeSetsUsingElement(id).isEmpty();
			if (isOrphan) {
				CodeSetPersistenceService.getInstance()
						.deleteOrphanedCodeSetElement(element);
			}
		}
		return null;
	}
	
	/**
	 * retrieves the entire list of code sets as SelectItem type
	 * 
	 * @return
	 */
	public List<SelectItem> getAllCodeSetItems() {
		List<CodeSet> codeSets = CodeSetPersistenceService.getInstance()
				.getAllCodeSets();
		Collections.sort(codeSets, new Comparator<CodeSet>() {
			public int compare(CodeSet set1, CodeSet set2) {
				return set1.getCodeSetName().compareTo(set2.getCodeSetName());
			}
		});
		List<SelectItem> codeSetItems = new ArrayList<SelectItem>();
		for (CodeSet codeSet : codeSets) {
			long id = ((IBusinessObject) codeSet).getId();
			codeSetItems
					.add(new SelectItem(id, codeSet.getCodeSetName().trim()));
		}
		return codeSetItems;
	}
	
	/**
	 * @return the checked
	 */
	public Map<Long, Boolean> getChecked() {
		return checked;
	}
	
	/**
	 * returns the list of elements that belong to the code set that is 
	 * the current 'selected codeset'
	 * 
	 * @return
	 */
	public List<ICodeSetElement> getElementsOfSelectedCodeSet() {
		if (getSelectedCodeSetId() == null) {
			return null;
		}
		long selectedCodeSetId = Long.parseLong(getSelectedCodeSetId());
		CodeSet codeSet = CodeSetPersistenceService.getInstance()
				.getCodeSetById(selectedCodeSetId);
		return codeSet.getCodeSetElements();
	}

	/**
	 * @return
	 */
	public String getNewElementCode() {
		return newElementCode;
	}
	
	
	/**
	 * @return
	 */
	public String getNewElementDescription() {
		return newElementDescription;
	}

	/**
	 * @return
	 */
	public String getNewElementName() {
		return newElementName;
	}

	/**
	 * @return
	 */
	public String getSelectedCodeSetId() {
		return selectedCodeSetId;
	}

	/**
	 * @param checked the checked to set
	 */
	public void setChecked(Map<Long, Boolean> checked) {
		this.checked = checked;
	}

	/**
	 * @param newElementCode
	 */
	public void setNewElementCode(String newElementCode) {
		this.newElementCode = newElementCode;
	}

	/**
	 * @param newElementDescription
	 */
	public void setNewElementDescription(String newElementDescription) {
		this.newElementDescription = newElementDescription;
	}

	/**
	 * @param newElementName
	 */
	public void setNewElementName(String newElementName) {
		this.newElementName = newElementName;
	}

	/**
	 * @param selectedCodeSetId
	 */
	public void setSelectedCodeSetId(String selectedCodeSetId) {
		this.selectedCodeSetId = selectedCodeSetId;
		setMessages(null); // this is a hack, to get the messages to go away after a code set change.
	}

	/**
	 * @param messages the messages to set
	 */
	public void setMessages(String messages) {
		this.messages = messages;
	}

	/**
	 * @return the messages
	 */
	public String getMessages() {
		return messages;
	}

}


/**
 *  Modification History:
 *
 *  $Log: ManageCodeSetPage.java,v $
 *  Revision 1.1  2012/10/31 23:06:32  mwsec2
 *  adding manage-codeset function
 *
 */