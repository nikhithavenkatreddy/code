/**
 * 
 */
package gov.ca.dmv.ease.admintool.dao;

import gov.ca.dmv.ease.admintool.bo.EmployeeOfficeDetails;
import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.bo.admin.impl.Office;

import java.util.List;

/**
 * Description: //TODO - provide description!
 * File: IAdminToolDao.java
 * Module:  gov.ca.dmv.ease.admintool.dao
 * Created: Oct 15, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public interface IAdminToolDao {
	/**
	 * Gets the employee office details.
	 *
	 * @param inputData the input data
	 * @return the employee office details
	 */
	public abstract List <EmployeeOfficeDetails> getEmployeeOfficeDetails(
			InputData inputData);

	/**
	 * Gets the office details.
	 *
	 * @return the office details
	 */
	public abstract List <Office> getOfficeDetails();

	/**
	 * Update work date status.
	 *
	 * @param input the input
	 * @return true, if successful
	 */
	public abstract boolean updateWorkDateStatus(EmployeeOfficeDetails input);
}
/**
 *  Modification History:
 *
 *  $Log: IAdminToolDao.java,v $
 *  Revision 1.1  2012/10/18 18:57:53  mwpkc2
 *  Made changes as EASE Portal standards
 *
 *  Revision 1.1  2012/10/15 18:36:57  mwsec2
 *  initial check in
 *
 */
