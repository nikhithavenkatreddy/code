/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;


/**
 * Description: I reperesent the business object, OFFICE 
 * File: Office.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 17, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class Office implements Comparable <Office> {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4268748040850392119L;
	/** The office id. */
	private String officeId;
	/** The office name. */
	private String officeName;
	
	private String authdWrkDtStatus;
	private String officeSysId;
	private String authdWrkDt;


	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the office name.
	 *
	 * @return the office name
	 */
	public String getOfficeName() {
		return officeName;
	}

	/**
	 * Sets the office name.
	 *
	 * @param officeName the new office name
	 */
	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	
	public String getAuthdWrkDtStatus() {
		return authdWrkDtStatus;
	}

	public void setAuthdWrkDtStatus(String authdWrkDtStatus) {
		this.authdWrkDtStatus = authdWrkDtStatus;
	}

	public String getOfficeSysId() {
		return officeSysId;
	}

	public void setOfficeSysId(String officeSysId) {
		this.officeSysId = officeSysId;
	}

	public String getAuthdWrkDt() {
		return authdWrkDt;
	}

	public void setAuthdWrkDt(String authdWrkDt) {
		this.authdWrkDt = authdWrkDt;
	}

	public int compareTo(Office anotherOffice) {
		return this.officeId.compareTo(anotherOffice.getOfficeId());
	}
}