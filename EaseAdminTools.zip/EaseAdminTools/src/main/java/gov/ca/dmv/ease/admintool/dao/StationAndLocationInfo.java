package gov.ca.dmv.ease.admintool.dao;

import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;
// TODO: Auto-generated Javadoc
/**
 * Description: The Class StationAndLocationInfo 
 * File: StationAndLocationInfo.java
 * Module:  gov.ca.dmv.ease.admintool.dao;
 * Created:  
 * @author   
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/12/21 18:04:15 $
 * Last Changed By: $Author: mwnrk $
 */
public class StationAndLocationInfo {
	
	/** The station. */
	private Station station;
	
	/** The location. */
	private Location location;
	
	/**
	 * Gets the station.
	 *
	 * @return the station
	 */
	public Station getStation() {
		return station;
	}
	
	/**
	 * Sets the station.
	 *
	 * @param station the new station
	 */
	public void setStation(Station station) {
		this.station = station;
	}
	
	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	public Location getLocation() {
		return location;
	}
	
	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(Location location) {
		this.location = location;
	}
	
	
}
/**
 *  Modification History:
 *
 *  $Log: StationAndLocationInfo.java,v $
 *  Revision 1.1  2012/12/21 18:04:15  mwnrk
 *  initial version.
 * 
 *
 */