package gov.ca.dmv.ease.admintool.ui.page.impl;

import gov.ca.dmv.ease.admintool.dao.AdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.dao.StationAndLocationInfo;
import gov.ca.dmv.ease.admintool.response.impl.SaveLocationAndStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveStationResponse;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

/**
 * The Class LocationEnforcementPage.
 */
public class LocationEnforcementPage {
	/** The admin dao. */
	private static IAdminToolPersistenceService adminDAO = new AdminToolPersistenceService();
	/** The select office ids. */
	private List <SelectItem> selectOfficeIds = new ArrayList <SelectItem>();
	/** The station sys ids. */
	private List <SelectItem> stationSysIds = new ArrayList <SelectItem>();
	/** The office id. */
	private String officeId;
	/** The station sys id. */
	private String stationSysId;
	/** The ip address. */
	private String ipAddress;
	/** The load. */
	private boolean load = true;
	/** The disable station edit box. */
	private boolean showNewStationItems = false;
	/** The new sstation id. */
	private String newStationId;
	/** The new primary printer id. */
	private String newPrimaryPrinterId;
	/** The new alternate printer id. */
	private String newAlternatePrinterId;
	/** The new inventory assigned flg. */
	private String newInventoryAssignedFlg;
	/** The selected option. */
	private String selectedOption;
	private boolean dataExist = false;
	private String officeMnemoniccode;
	private String l1ServerCode;

	public String getOfficeMnemoniccode() {
		return officeMnemoniccode;
	}

	public void setOfficeMnemoniccode(String officeMnemoniccode) {
		this.officeMnemoniccode = officeMnemoniccode;
	}

	public LocationEnforcementPage() {
		
	}
	
	public String getSelectedOption() {
		if(selectedOption == null || "".equals(selectedOption)) {
			selectedOption = "N";
			//stationSysId = "0";
		}
		return selectedOption;
	}

	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}

	//Getter and Setter methods -------------------------------------------------
	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Checks if is show new station items.
	 *
	 * @return true, if is show new station items
	 */
	public boolean isShowNewStationItems() {
		return showNewStationItems;
	}

	/**
	 * Sets the show new station items.
	 *
	 * @param showNewStationItems the new show new station items
	 */
	public void setShowNewStationItems(boolean showNewStationItems) {
		this.showNewStationItems = showNewStationItems;
	}

	/**
	 * Gets the station sys ids.
	 *
	 * @return the station sys ids
	 */
	public List <SelectItem> getStationSysIds() {
		return stationSysIds;
	}

	/**
	 * Sets the station sys ids.
	 *
	 * @param stationSysIds the new station sys ids
	 */
	public void setStationSysIds(List <SelectItem> stationSysIds) {
		this.stationSysIds = stationSysIds;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the station sys id.
	 *
	 * @return the station sys id
	 */
	public String getStationSysId() {
		return stationSysId;
	}

	/**
	 * Sets the station sys id.
	 *
	 * @param stationSysId the new station sys id
	 */
	public void setStationSysId(String stationSysId) {
		this.stationSysId = stationSysId;
	}

	/**
	 * Gets the ip address.
	 *
	 * @return the ip address
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the new ip address
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Gets the new station id.
	 *
	 * @return the new station id
	 */
	public String getNewStationId() {
		return newStationId;
	}

	/**
	 * Sets the new station id.
	 *
	 * @param newStationId the new new station id
	 */
	public void setNewStationId(String newStationId) {
		this.newStationId = newStationId;
	}

	/**
	 * Gets the new primary printer id.
	 *
	 * @return the new primary printer id
	 */
	public String getNewPrimaryPrinterId() {
		return newPrimaryPrinterId;
	}

	/**
	 * Sets the new primary printer id.
	 *
	 * @param newPrimaryPrinterId the new new primary printer id
	 */
	public void setNewPrimaryPrinterId(String newPrimaryPrinterId) {
		this.newPrimaryPrinterId = newPrimaryPrinterId;
	}

	/**
	 * Gets the new alternate printer id.
	 *
	 * @return the new alternate printer id
	 */
	public String getNewAlternatePrinterId() {
		return newAlternatePrinterId;
	}

	/**
	 * Sets the new alternate printer id.
	 *
	 * @param newAlternatePrinterId the new new alternate printer id
	 */
	public void setNewAlternatePrinterId(String newAlternatePrinterId) {
		this.newAlternatePrinterId = newAlternatePrinterId;
	}

	/**
	 * Gets the new inventory assigned flg.
	 *
	 * @return the new inventory assigned flg
	 */
	public String getNewInventoryAssignedFlg() {
		return newInventoryAssignedFlg;
	}

	/**
	 * Sets the new inventory assigned flg.
	 *
	 * @param newInventoryAssignedFlg the new new inventory assigned flg
	 */
	public void setNewInventoryAssignedFlg(String newInventoryAssignedFlg) {
		this.newInventoryAssignedFlg = newInventoryAssignedFlg;
	}

	//Get List <SelectItem> methods  -------------------------------------------------
	/**
	 * Gets the select office ids.
	 *
	 * @return the select office ids
	 */
	public List <SelectItem> getSelectOfficeIds() {
		if (load) {
			List <Office> offices = adminDAO.getAllOffices();
			for (Office office : offices)
				selectOfficeIds.add(new SelectItem(office.getOfficeId(), office
						.getOfficeId()
						+ " - " + office.getName()));
			if (selectOfficeIds.size() != 0) {
				officeIdChanged((String) selectOfficeIds.get(0).getValue());
			}
		}
		load = false;
		return selectOfficeIds;
	}

	/**
	 * Gets the select station id ids.
	 *
	 * @param event the event
	 * @return the select station id ids
	 */
	public void onOfficeIdChange(ValueChangeEvent event) {
		String selectedOffice = (String) event.getNewValue();
		setOfficeId(selectedOffice);
		officeIdChanged(selectedOffice);
	}

	/**
	 * Office id changed.
	 *
	 * @param newValue the new value
	 */
	private void officeIdChanged(String newValue) {
		if (newValue != null) {
			List <Station> stations = adminDAO
					.getStationInfoByOfficeId(newValue);
			stationSysIds = new ArrayList <SelectItem>();
			stationSysIds.add(new SelectItem(0, "SELECT"));
			for (Station station : stations)
				stationSysIds.add(new SelectItem(station.getId(), station
						.getId()
						+ " | "
						+ station.getStationId()
						+ " | "
						+ station.getPrimaryPrinterId()
						+ " | "
						+ station.getAlternatePrinterId()));
			if (stations.size() == 0) {
				setShowNewStationItems(false);
				stationSysIds.add(new SelectItem(0, "SELECT"));
			}

			
			if (getSelectedOption().equalsIgnoreCase("N"))
				stationSysIds.add(new SelectItem(-1, "OTHER"));
			setStationSysIds(stationSysIds);
		}
	}

	/**
	 * On station sys id change.
	 *
	 * @param event the event
	 * @throws IOException 
	 */
	public void onStationSysIdChange(ValueChangeEvent event) throws IOException {
			String selectedStationId = (String) event.getNewValue();
		this.stationSysId = selectedStationId;		
		if (!"0".equals(selectedStationId)) {
			if (selectedStationId != null) {
				if ("-1".equals(selectedStationId)
						|| getSelectedOption().equalsIgnoreCase("Y")) {
					setShowNewStationItems(true);
					populatePrinterIPAdressInfo(selectedStationId);
					
				} else
					setShowNewStationItems(false);
			}
		} else
			setShowNewStationItems(false);
	}
	
	/**
	 * 
	 * @param selectedStationId
	 * @throws IOException
	 */
	public void populatePrinterIPAdressInfo(String selectedStationId)
			throws IOException {
		StationAndLocationInfo dataForSelectedStation = adminDAO
				.getStationAndLocationInfo(selectedStationId);
		if (dataForSelectedStation != null) {
			if (dataForSelectedStation.getLocation() != null
					&& dataForSelectedStation.getLocation().getIpAddress() != null)
				setIpAddress(dataForSelectedStation.getLocation()
						.getIpAddress().trim());
			//L1 Server
			if (dataForSelectedStation.getLocation() != null
					&& dataForSelectedStation.getLocation().getL1ServerCode() != null)
				setL1ServerCode(dataForSelectedStation.getLocation()
						.getL1ServerCode().trim());
			
			// L1 Office Mnemonic
			if (dataForSelectedStation.getLocation() != null
					&& dataForSelectedStation.getLocation().getOfficeMnemonic() != null)
				setOfficeMnemoniccode(dataForSelectedStation.getLocation()
						.getOfficeMnemonic().trim());
			
			if (dataForSelectedStation.getStation() != null
					&& dataForSelectedStation.getStation()
							.getAlternatePrinterId() != null)
				setNewAlternatePrinterId(dataForSelectedStation.getStation()
						.getAlternatePrinterId().trim());
			if (dataForSelectedStation.getStation() != null
					&& dataForSelectedStation.getStation()
							.getPrimaryPrinterId() != null)
				setNewPrimaryPrinterId(dataForSelectedStation.getStation()
						.getPrimaryPrinterId().trim());
			FacesContext.getCurrentInstance().getExternalContext().redirect(
					"locationEnforcement.jsf");
			
			
		}
	}

	public boolean isIPAddressExist(){
		
		if (ipAddress != null && adminDAO.isIpAddressExisted(ipAddress) && selectedOption != null && selectedOption.equalsIgnoreCase("S")) {
			getFacesContext().addMessage(
					null,
					new FacesMessage(
							//"IP ADDRESS IS ALREADY EXISTED , COULD NOT BE ADDED"
							"IP ADDRESS EXIST AS IDENTITY ABOVE. TO UPDATE, USE THE UPDATE EASE BUTTON"
									+ "-brErrorMsg"));
			return true;
		}else {
			getFacesContext().addMessage(
					null,
					new FacesMessage(
							//"IP ADDRESS IS NOT EXIST IN THE DATABASE FOR THIS OFFICE"
							"IP ADDRESS DOES NOT EXIST. USE THE NEW EASE BUTTON TO ADD"
									+ "-brErrorMsg"));
			return false;
		}
		
		
	}
	public boolean isDataExist(){
		if (ipAddress == null || ipAddress.isEmpty()) {
			getFacesContext().addMessage(
					null,
					new FacesMessage("IP ADDRESS SHOULD NOT BE NULL OR BLANK"
							+ "-brErrorMsg"));
			return true;
		}
		
		if (officeMnemoniccode == null || officeMnemoniccode.isEmpty()) {
			getFacesContext().addMessage(
					null,
					new FacesMessage("OFFICE MNEMONIC CODE SHOULD NOT BE NULL OR BLANK"
							+ "-brErrorMsg"));
			return true;
		}
		
		if (ipAddress != null && adminDAO.isIpAddressExisted(ipAddress) && selectedOption != null && selectedOption.equalsIgnoreCase("N")) {
			getFacesContext().addMessage(
					null,
					new FacesMessage(
							"IP ADDRESS IS ALREADY EXISTED , COULD NOT BE ADDED"
									+ "-brErrorMsg"));
			return true;
		}
		if ("0".equals(stationSysId)) {
			getFacesContext().addMessage(
					null,
					new FacesMessage("PLEASE SELECT A VALID STATION SYS ID"
							+ "-brErrorMsg"));
			return true;
		}
		if (newStationId != null && !newStationId.isEmpty()) {
			if (!"-1".equals(stationSysId)
					&& adminDAO.isNewStationIdExisted(newStationId)) {
				getFacesContext().addMessage(
						null,
						new FacesMessage(
								"STATION ID IS ALREADY EXISTED , COULD NOT BE ADDED"
										+ "-brErrorMsg"));
				return true;
			}
		}
		return false;
	}
	//Action Methods  -------------------------------------------------
	/**
	 * Continue to insert action.
	 *
	 * @return the string
	 */
	public String continueToInsertAction() {
		
		String buttonValue = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("buttonSelect");

		if (!isDataExist()) {
			if (getSelectedOption().equalsIgnoreCase("Y")) {
				StationAndLocationInfo input = new StationAndLocationInfo();
				Station station = new Station();
				station.setId(new Long(stationSysId));
				station.setPrimaryPrinterId(newPrimaryPrinterId.toLowerCase());
				station.setAlternatePrinterId(newAlternatePrinterId.toLowerCase());
				Location loc = new Location();
				loc.setStation(station);
				loc.setIpAddress(ipAddress);
				input.setLocation(loc);
				input.setStation(station);
				SaveLocationAndStationResponse response = adminDAO
						.updateStationAndLocationInfo(input);
				if (!response.getErrorCollector().hasErrors()) {
					reset();
					return null;
				} else {
					getFacesContext().addMessage(
							null,
							new FacesMessage(
									"INFO COULD NOT BE ADDED..PLEASE SEE THE LOG"
											+ "-brErrorMsg"));
				}
			}
			System.out.println(officeId);
			System.out.println(stationSysId);
			System.out.println(ipAddress);
			// Create default station
			Station station = new Station(stationSysId);
			station.setPrimaryPrinterId("");
			station.setAlternatePrinterId("");
			station.setInventoryAssigned(false);
			// Create a Station
			Location inputData = new Location();
			inputData.setIpAddress(ipAddress);
			inputData.setOfficeId(officeId);
			//inputData.setL1ServerCode(l1ServerInfo);
			//inputData.setL1ServerSuffix("");
			inputData.setOfficeMnemonic(officeMnemoniccode);
			
			inputData.setStation(station);
			if ("-1".equals(stationSysId)) {
				Station newStation = new Station();
				newStation.setStationId(newStationId);
				newStation.setPrimaryPrinterId(newPrimaryPrinterId.toLowerCase());
				newStation.setAlternatePrinterId(newAlternatePrinterId.toLowerCase());
				newStation.setInventoryAssigned(Boolean
						.valueOf(newInventoryAssignedFlg));
				SaveStationResponse response = adminDAO
						.addStationInfo(newStation);
				if (response.getErrorCollector().hasErrors()) {
					getFacesContext().addMessage(
							null,
							new FacesMessage("COULD NOT ADD STATION"
									+ "-brErrorMsg"));
					return null;
				}
				inputData.setStation(newStation);

			}
			SaveLocationAndStationResponse response = adminDAO
					.addLocationAndStationDetails(inputData);
			if (!response.getErrorCollector().hasErrors()) {
				reset();
				return null;
			} else {
				if(response.getErrorCollector().hasExceptionMessageContaining("PLEASE CONTACT ISD: FRONT-END GROUP")) {
					getFacesContext().addMessage(
							null,
							new FacesMessage(
									"PLEASE CONTACT ISD: FRONT-END GROUP" 
							+ "-brErrorMsg"));
				} else { 
				getFacesContext().addMessage(
						null,
						new FacesMessage(
								"LOCATION INFO COULD NOT BE ADDED. PLEASE SEE THE LOG"
										+ "-brErrorMsg"));
				}
			}
		}
		return "";

	}

	/**
	 * Continue to home action.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void continueToHomeAction() throws IOException {
		reset();
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"/EaseAdminTools"); ///jspx/adminTool.jsf
	}

	/**
	 * Continue to reset action.
	 *
	 * @return the string
	 * @throws IOException 
	 */
	public String continueToResetAction() throws IOException {
		reset();
		FacesContext.getCurrentInstance().getExternalContext().redirect(
		"locationEnforcement.jsf");
		return "";
	}

	//General local methods  -------------------------------------------------
	/**
	 * Reset.
	 */
	private void reset() {
		//try {
			//To hide the office drop down list on UI screen.
		    selectedOption = "O";
			ipAddress = "";
			newStationId = "";
			newPrimaryPrinterId = "";
			newAlternatePrinterId = "";
			newInventoryAssignedFlg = "";
			showNewStationItems = false;
			stationSysIds = new ArrayList <SelectItem>();
			getFacesContext().addMessage(
					null,
					new FacesMessage("LOCATION INFO ADDED/UPDATED SUCCESSFULLY"
							+ "-brErrorMsg"));
			load=true;
			getSelectOfficeIds();
			officeIdChanged(officeId);
			setSelectedOption("N");
			setStationSysId("0");
			//Get the fresh list of station ids
			officeIdChanged(getOfficeId());
	}

	/**
	 * Gets the faces context.
	 *
	 * @return the faces context
	 */
	private FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}
	
	public void change(ValueChangeEvent event) throws IOException {
		load = true;
		selectedOption = (String) event.getNewValue();

		ipAddress = "";
		newStationId = "";
		newPrimaryPrinterId = "";
		newAlternatePrinterId = "";
		newInventoryAssignedFlg = "";
		showNewStationItems = false;
		stationSysIds = new ArrayList <SelectItem>();
		selectOfficeIds = new ArrayList <SelectItem>();
		setSelectedOption(selectedOption.trim());
		getSelectOfficeIds();
		officeIdChanged(officeId);
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"locationEnforcement.jsf");

	}

	/**
	 * @return the l1ServerCode
	 */
	public String getL1ServerCode() {
		return l1ServerCode;
	}

	/**
	 * @param l1ServerCode the l1ServerCode to set
	 */
	public void setL1ServerCode(String l1ServerCode) {
		this.l1ServerCode = l1ServerCode;
	}
}
