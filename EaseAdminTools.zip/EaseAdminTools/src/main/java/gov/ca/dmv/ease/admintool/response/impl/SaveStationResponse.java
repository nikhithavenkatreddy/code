/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;


/**
 * Description: I am this and that
 * File: SaveStationResponse.java
 * Module:  gov.ca.dmv.ease.admintool.response.impl
 * Created: Oct 19, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/19 17:37:01 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class SaveStationResponse extends AbstractResponse {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5190589963605312180L;

	/**
	 * Default constructor
	 */
	public SaveStationResponse() {
		super();
	}

	/**
	 * Constructor that takes an error collector instance
	 * 
	 * @param collector
	 */
	public SaveStationResponse(IErrorCollector collector) {
		super(collector);
	}
}
