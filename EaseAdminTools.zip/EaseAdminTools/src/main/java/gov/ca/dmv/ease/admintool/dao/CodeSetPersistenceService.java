/**
 * 
 */
package gov.ca.dmv.ease.admintool.dao;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.fw.exception.impl.EasePersistenceServiceException;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveAllBusinessObjectsResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SaveOrUpdateBusinessObjectResponse;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * Description: Persistence service providing methods to maintain code sets.
 * File: CodeSetPersistenceService.java
 * Module:  gov.ca.dmv.ease.admintool.dao
 * Created: Oct 18, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/31 23:06:32 $
 * Last Changed By: $Author: mwsec2 $
 */
public class CodeSetPersistenceService {
	
	
	/** Logger. */
	private static final Log LOGGER = LogFactory
			.getLog(CodeSetPersistenceService.class);
	
	/** The SINGLETON. */
	private static CodeSetPersistenceService SINGLETON;
	
	/**
	 * Gets the single instance of CodeSetPersistenceService.
	 *
	 * @return single instance of CodeSetPersistenceService
	 */
	public static CodeSetPersistenceService getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new CodeSetPersistenceService();
		}
		return SINGLETON;
	}
	
	/**
	 * Private constructor to enforce singleton access
	 */
	private CodeSetPersistenceService() {}
	
	/**
	 * Retrieves all code sets
	 * 
	 * @return the list of CodeSet objects
	 */
	public List <CodeSet> getAllCodeSets() {
		IPersistenceServiceRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveAllBusinessObjectsRequest(
						UserContext.getDefaultInstanceForDb(), CodeSet.class);
		RetrieveAllBusinessObjectsResponse response = (RetrieveAllBusinessObjectsResponse) request
				.execute();
		if (response.hasErrors()) {
			throw new EasePersistenceServiceException(response
					.getErrorCollector().getEntries().get(0)
					.getExceptionMessage());
		}
		List <IBusinessObject> listOfBusinessObjects = response.getResults();
		List <CodeSet> codeSets = new ArrayList <CodeSet>();
		for (IBusinessObject obj : listOfBusinessObjects) {
			CodeSet codeSet = (CodeSet) obj;
			codeSets.add(codeSet);
		}
		return codeSets;
	}

	/**
	 * Retrieves the specified code set
	 * @param id
	 * @return the identified CodeSet object, or null if not found
	 */
	public CodeSet getCodeSetById(long id) {
		SessionFactory sessionFactory = (SessionFactory) EaseApplicationContext
				.getApplicationContext().getBean("sessionFactory");
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		CodeSet codeSet = null;
		try {
			codeSet = (CodeSet) session.get(CodeSet.class, id);
			session.getTransaction().commit();
		}
		catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
			throw new EasePersistenceServiceException(e);
		}
		return codeSet;
	}

	/**
	 * Persists the code set, including its elements
	 * 
	 * @param codeSet
	 */
	public void updateCodeSet(CodeSet codeSet) {
		IPersistenceServiceRequest request = PersistenceServiceRequestFactory
				.getInstance().createSaveOrUpdateBusinessObjectRequest(
						UserContext.getDefaultInstanceForDb(), codeSet);
		SaveOrUpdateBusinessObjectResponse response = (SaveOrUpdateBusinessObjectResponse) request
				.execute();
		if (response.hasErrors()) {
			throw new EasePersistenceServiceException(response
					.getErrorCollector().getEntries().get(0)
					.getExceptionMessage());
		}
	}
	
	/**
	 * Retrieves the code sets that contain a specified element
	 * 
	 * @param elementId
	 * @return the list of code sets that contain the specified element
	 */
	public List <CodeSet> getCodeSetsUsingElement(long elementId) {
		List <CodeSet> allCodesets = getAllCodeSets();
		List <CodeSet> codesetsWithElement = new ArrayList<CodeSet>();
		for (CodeSet codeset : allCodesets) {
			for (ICodeSetElement e : codeset.getCodeSetElements()) {
				CodeSetElement element = (CodeSetElement) e;
				if (element.getId() == elementId) {
					codesetsWithElement.add(codeset);
				} 
			}
		}
		return codesetsWithElement;
	}

	/**
	 * Deletes an orphaned code set element. A check is made to make sure the 
	 * element is orphaned, before the deletion. If the element is found to belong
	 * to a code set, an EasePersistenceServiceException is thrown.
	 * 
	 * @param element
	 */
	public void deleteOrphanedCodeSetElement(CodeSetElement element) {
		if (getCodeSetsUsingElement(element.getId()).isEmpty()) {
			IPersistenceServiceRequest request = PersistenceServiceRequestFactory
					.getInstance().createDeleteBusinessObjectRequest(
							UserContext.getDefaultInstanceForDb(), element);
			DeleteBusinessObjectResponse response = (DeleteBusinessObjectResponse) request
					.execute();
			if (response.hasErrors()) {
				throw new EasePersistenceServiceException(response
						.getErrorCollector().getEntries().get(0)
						.getExceptionMessage());
			}
		}
		else {
			throw new EasePersistenceServiceException(
					"The CodeSetElement was not deleted because it is not an orphan");
		}
	}
	
	/**
	 * Retrieves the specified code set element
	 * @param id
	 * @return the identified CodeSetElement object, or null if not found
	 */
	public CodeSetElement getCodeSetElementById(long id) {
		SessionFactory sessionFactory = (SessionFactory) EaseApplicationContext
				.getApplicationContext().getBean("sessionFactory");
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		CodeSetElement codeSetElement = null;
		try {
			codeSetElement = (CodeSetElement) session.get(CodeSetElement.class, id);
			session.getTransaction().commit();
		}
		catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
			throw new EasePersistenceServiceException(e);
		}
		return codeSetElement;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CodeSetPersistenceService.java,v $
 *  Revision 1.1  2012/10/31 23:06:32  mwsec2
 *  adding manage-codeset function
 *
 */
