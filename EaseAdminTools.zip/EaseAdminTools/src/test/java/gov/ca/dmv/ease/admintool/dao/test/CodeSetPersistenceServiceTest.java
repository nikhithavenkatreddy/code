/**
 * 
 */
package gov.ca.dmv.ease.admintool.dao.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import gov.ca.dmv.ease.admintool.dao.CodeSetPersistenceService;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Description: //TODO - provide description!
 * File: CodeSetPersistenceServiceTest.java
 * Module:  gov.ca.dmv.ease.admintool.dao.test
 * Created: Oct 18, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/31 23:06:32 $
 * Last Changed By: $Author: mwsec2 $
 */
public class CodeSetPersistenceServiceTest {
	
	CodeSetPersistenceService fixture;
	
	@Before
	public void setUp() throws Exception {
		String[] configLocations = { "classpath:test-applicationContext-fw-services.xml" };
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(configLocations);
		assertNotNull(applicationContext);
		fixture = CodeSetPersistenceService.getInstance();
	}
	
	/**
	 * Test method for {@link gov.ca.dmv.ease.admintool.dao.CodeSetPersistenceService#getAllCodeSets()}.
	 */
	@Test
	public void testGetAllCodeSets() {
		List <CodeSet> codesets = fixture.getAllCodeSets();
		//findMultiUsedElement(codesets);
		assertNotNull(codesets);
	}
	
	private void findMultiUsedElement(List <CodeSet> codesets) {
		Map<Long, CodeSetElement> elements = new HashMap<Long, CodeSetElement>();
		for (CodeSet codeset : codesets) {
			for (ICodeSetElement e : codeset.getCodeSetElements()) {
				CodeSetElement element = (CodeSetElement) e;
				if (elements.containsKey(element.getId())) {
					System.out.println("already found this element: " + element);
				} else {
					elements.put(element.getId(), element);
				}
			}
		}
	}
	
	@Test
	public void testGetCodeSetById() {
		CodeSet codeset = fixture.getCodeSetById(10053);
		assertNotNull(codeset);
	}
	
	@Test
	public void testUpdateCodeSet() {
		// clear the test codeset
		CodeSet codeset = fixture.getCodeSetById(10053);
		codeset.getCodeSetElements().clear();
		fixture.updateCodeSet(codeset);
		// add an element to the codeset
		CodeSetElement element = new CodeSetElement();
		element.setCodeCategory("UNIT_TEST_ONLY");
		element.setCode("TEST_ELEMENT_1");
		element.setName("TEST_ELEMENT_1_NAME");
		element.setDescription("an element for unit testing");
		element.setEffectiveDate(new Date());
		element.setEndDate(new Date());
		codeset = fixture.getCodeSetById(10053);
		codeset.add(element);
		fixture.updateCodeSet(codeset);
		// check db for new element
		codeset = fixture.getCodeSetById(10053);
		assertTrue(codeset.getCodeSetElements().size() > 0);
		element = (CodeSetElement)codeset.getCodeSetElements().get(0);
		long elementId = ((BusinessObject) element).getId();
		// remove the new element
		codeset.getCodeSetElements().clear();
		fixture.updateCodeSet(codeset);
		codeset = fixture.getCodeSetById(10053);
		// check to see new element is removed from codeset
		assertTrue(codeset.getCodeSetElements().size() == 0);
		fixture.deleteOrphanedCodeSetElement(element);
		assertNull(fixture.getCodeSetElementById(elementId));
	}
	
	@Test
	public void testGetCodeSetsUsingElement() {
		List<CodeSet> codesets = fixture.getCodeSetsUsingElement(43633);
		assertTrue(codesets.size() == 2);
	}
	
	@Test
	public void testDeleteOrphanedCodeSetElement() {
		// clear the test codeset
		CodeSet codeset = fixture.getCodeSetById(10053);
		codeset.getCodeSetElements().clear();
		fixture.updateCodeSet(codeset);
		// add an element to the codeset
		CodeSetElement element = new CodeSetElement();
		element.setCodeCategory("UNIT_TEST_ONLY");
		element.setCode("TEST_ELEMENT_1");
		element.setName("TEST_ELEMENT_1_NAME");
		element.setDescription("an element for unit testing");
		element.setEffectiveDate(new Date());
		element.setEndDate(new Date());
		codeset = fixture.getCodeSetById(10053);
		codeset.add(element);
		fixture.updateCodeSet(codeset);
		// check db for new element
		codeset = fixture.getCodeSetById(10053);
		assertTrue(codeset.getCodeSetElements().size() > 0);
		element = (CodeSetElement)codeset.getCodeSetElements().get(0);
		long elementId = ((BusinessObject) element).getId();
		// remove the new element
		codeset.getCodeSetElements().clear();
		fixture.updateCodeSet(codeset);
		codeset = fixture.getCodeSetById(10053);
		// check to see new element is removed
		assertTrue(codeset.getCodeSetElements().size() == 0);
		assertNotNull(fixture.getCodeSetElementById(elementId));
		fixture.deleteOrphanedCodeSetElement(element);
		assertNull(fixture.getCodeSetElementById(elementId));
	}
	
	@Test
	public void testGetCodeSetElementById() {
		assertNotNull(fixture.getCodeSetElementById(43633));
		assertNull(fixture.getCodeSetElementById(4363300));
	}
}


/**
 *  Modification History:
 *
 *  $Log: CodeSetPersistenceServiceTest.java,v $
 *  Revision 1.1  2012/10/31 23:06:32  mwsec2
 *  adding manage-codeset function
 *
 */