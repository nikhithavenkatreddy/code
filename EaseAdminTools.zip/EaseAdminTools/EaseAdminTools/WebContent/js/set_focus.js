//If any business rule error occur we need to highlight the UI field with red border.
function setFocusToElement() {
	var errorField = document.getElementById("brErrorField");				
	if(errorField != null) {
		var errorFieldName = errorField.value;//alert("errorFieldName: " + errorFieldName);
		var errorFields = errorFieldName.split(",");//alert("SPLIT: " + errorFields.length);
		for(var index = 0; index < errorFields.length; index++) {
			if(errorFields[index] != null && errorFields[index].indexOf("MAIN_FORM:") >= 0) { 
				if(document.getElementById(errorFields[index]) != null) {
					document.getElementById(errorFields[index]).className += " requiredStyle ";			
				}			
			} else if(document.getElementById("MAIN_FORM:" + errorFields[index]) != null) {
				document.getElementById("MAIN_FORM:" + errorFields[index]).className += " requiredStyle ";			
			}
		}		
	}
}
