
// util functions
function getFrameSet() {
   return document.getElementsByTagName("frameset").item(0);
}

function getFrames() {
	return getFrameSet().getElementsByTagName("frame"); 
}

function sendRequest(url) {
	getFrames().namedItem("hidden").src = url; 
}

function getActiveTab() {
	return getFrames()[NAVBAR_FRAME_NAME].contentWindow.getCurrentChoice();
}

function resetToDefaultPage(frame) {
   getFrames()[frame].src = DEFAULT_PAGE;
}
// to be called by event handlers in the frames
function syncSessions(notifier) { 
    if (notifier.document.title) { 
    	document.title = notifier.document.title;
    }
	lastPageLoadTime = new Date().getTime();
}
// Checks if there is latest load time in the URL. If so, compares it to the global variable and returns the latest.
// Note, the URL-updating approach is used for situations involving multiple domains and older browsers 
function getLastPageLoadTime() {
   var latestLoad = lastPageLoadTime;
   var urlTime = self.document.location.hash.substring(1);
   if (urlTime.length > 0) {
      latestLoad = Math.max(urlTime, lastPageLoadTime); 
   }
   return latestLoad;   
}

// passes an event to a specified (framed) window. 
function passKeyEventToFrame(frameId, event) {
	var frameSet = getFrameSet();
	var frames = getFrames();
    if (frames.namedItem(frameId)) {
    	if (frames.namedItem(frameId).contentWindow.captureKeyCode) {
    		frames.namedItem(frameId).contentWindow.captureKeyCode(event);
    	}
    }
}

var NAV_BAR_HEIGHT = null;
function getNavBarHeight() {
	if (NAV_BAR_HEIGHT == null) {
		NAV_BAR_HEIGHT = getFrameSet().rows.substring(0,getFrameSet().rows.indexOf(","));
	}
	return NAV_BAR_HEIGHT;
}
//'maximizes' a frame 
function maxFrame(frameId,targetUri,hideNavBar) {
	var frameSet = getFrameSet();
	var frames = getFrames();
    if (frames.namedItem(frameId)) { // if frame exists
    	// unhide the frame
    	var s = getNavBarHeight();
    	if (hideNavBar) { 
    	   s = "0";
        }
        for (var i = 1; i < frames.length; ++i) {
    	   if (frames[i].name == frameId) {
              s += ",100%";
           } else {
              s += ",0";
           }   
        }
        frameSet.rows = s;
        // change title to the child title (only works if child is in parent's domain)
        try {
        	document.title = frames.namedItem(frameId).contentWindow.document.title;
        } catch (err) { /* x-domain title copy not supported */}
        // if the chosen frame's src is still the default url (e.g. default.html)
        // then we point it to the targetUri 
        // (note: in FF, the src is the entire url, but in IE it is just the page name)
        if (frames[frameId].src.indexOf(DEFAULT_PAGE) != -1) {
           if (isXDomainAndOlderBrowser(targetUri)) {
        	   targetUri = addReplyUrl(targetUri); // for x-domain communication support in older browsers
           }
           frames[frameId].src = targetUri;
        }
        // reset focus on active frame element
        var activeWindow = frames.namedItem(frameId).contentWindow;
        if (activeWindow.focusedElement && activeWindow.focusedElement.focus) {
        	activeWindow.focusedElement.focus();
        }

    } 
}


function isXDomainAndOlderBrowser(targetUri) {
	if (typeof window.postMessage == "undefined") {
		if (targetUri.indexOf(self.document.domain) == -1) {
	       return true;	   
       }
    }
	return false;
}

function addReplyUrl(targetUri) {
	var replyUrl = self.document.location.href;
	if (replyUrl.indexOf('#') != -1) {
	   replyUrl = replyUrl.substring(0, replyUrl.indexOf('#'));    
	}
	return targetUri + '#' + replyUrl;
}

function startHeartbeat() {
	// version without timeout warning
	//heartbeatTimer = setInterval("heartbeatService()", HEARTBEAT_INTERVAL); 
	// version with timeout warning
	//heartbeatTimer = setInterval("heartbeatServiceWithWarning()", HEARTBEAT_INTERVAL_WITH_WARNING); 
	// irregular heartbeat with timeout warning
	heartbeatTimer = setTimeout("recursiveHeartbeat()", HEARTBEAT_INTERVAL_WITH_WARNING);
}

function recursiveHeartbeat() {
    var now = new Date().getTime();
    var lastLoad = getLastPageLoadTime();
    // if no new activity since last heartbeat (allowing 5 secs for lag)
    if (lastHeartbeatTime + 5000 >= lastLoad) {
       maxFrame(COUNTDOWN_FRAME_NAME, COUNTDOWN_PAGE, true);
       warningTimer = setTimeout("doTimeout()", COUNTDOWN_LENGTH * 1000);         
    } else {
        var delay = 1000;
        var accumulator = 0; 
 	   setTimeout("sendRequest('" + LOCAL_REFRESH_URL + "')", accumulator += delay);
 	   var frames = getFrames();
 	   if (frames.namedItem(MAIN_FRAME_NAME)) {
 	      setTimeout("sendRequest('" + DL_REFRESH_URL + "')", accumulator += delay);
 	   }
 	   var courtFrame = frames.namedItem(COURT_FRAME_NAME);
        if (courtFrame && courtFrame.src.indexOf(DEFAULT_PAGE) == -1) {
 	      setTimeout("sendRequest('" + COURT_REFRESH_URL + "')", accumulator += delay);
 	   }
 	   var dcsFrame = frames.namedItem(DCS_FRAME_NAME);
 	   if (dcsFrame && dcsFrame.src.indexOf(DEFAULT_PAGE) == -1) {
 	     setTimeout("sendRequest('" + DCS_REFRESH_URL + "')", accumulator += delay);
 	   }
 	   lastHeartbeatTime = now;
 	   var nextBeat = HEARTBEAT_INTERVAL_WITH_WARNING - (now - lastLoad);
 	   heartbeatTimer = setTimeout("recursiveHeartbeat()", nextBeat); 
    }
}

function stopHeartbeat() {
	clearInterval(heartbeatTimer);
}

// to be called at regular intervals to keep server sessions alive
function heartbeatService() {
    var now = new Date().getTime();
    var lastLoad = getLastPageLoadTime();
    // if inactivity period is greater than session timeout period or no page loads since last heartbeat
    if (now - lastLoad > SESSION_TIMEOUT_INTERVAL || lastHeartbeatTime >= lastLoad) {
       // stop heartbeating
       stopHeartbeat();
       logOffFromServers();
       setTimeout("goToTimeoutPage()", 1000);  
    } else {
       var delay = 1000;
       var accumulator = 0; 
	   setTimeout("sendRequest('" + LOCAL_REFRESH_URL + "')", accumulator += delay);
	   var frames = getFrames();
	   if (frames.namedItem(MAIN_FRAME_NAME)) {
	      setTimeout("sendRequest('" + DL_REFRESH_URL + "')", accumulator += delay);
	   }
	   var courtFrame = frames.namedItem(COURT_FRAME_NAME);
       if (courtFrame && courtFrame.src.indexOf(DEFAULT_PAGE) == -1) {
	      setTimeout("sendRequest('" + COURT_REFRESH_URL + "')", accumulator += delay);
	   }
	   var dcsFrame = frames.namedItem(DCS_FRAME_NAME);
	   if (dcsFrame && dcsFrame.src.indexOf(DEFAULT_PAGE) == -1) {
	     setTimeout("sendRequest('" + DCS_REFRESH_URL + "')", accumulator += delay);
	   }
	   lastHeartbeatTime = now;
	}
}
var warningTimer = null;

// version of heartbeat service that gives the user a warning page before timeout occurs 
function heartbeatServiceWithWarning() {
    var now = new Date().getTime();
    var lastLoad = getLastPageLoadTime();
    // if inactivity period is greater than session timeout period or no page loads since last heartbeat
    if (now - lastLoad > SESSION_TIMEOUT_INTERVAL - COUNTDOWN_LENGTH * 1000 || lastHeartbeatTime >= lastLoad) {
       // stop heartbeating
       stopHeartbeat();
       maxFrame(COUNTDOWN_FRAME_NAME, COUNTDOWN_PAGE, true);
       warningTimer = setTimeout("doTimeout()", COUNTDOWN_LENGTH * 1000);
         
    } else {
       var delay = 1000;
       var accumulator = 0; 
	   setTimeout("sendRequest('" + LOCAL_REFRESH_URL + "')", accumulator += delay);
	   var frames = getFrames();
	   if (frames.namedItem(MAIN_FRAME_NAME)) {
	      setTimeout("sendRequest('" + DL_REFRESH_URL + "')", accumulator += delay);
	   }
	   var courtFrame = frames.namedItem(COURT_FRAME_NAME);
       if (courtFrame && courtFrame.src.indexOf(DEFAULT_PAGE) == -1) {
	      setTimeout("sendRequest('" + COURT_REFRESH_URL + "')", accumulator += delay);
	   }
	   var dcsFrame = frames.namedItem(DCS_FRAME_NAME);
	   if (dcsFrame && dcsFrame.src.indexOf(DEFAULT_PAGE) == -1) {
	     setTimeout("sendRequest('" + DCS_REFRESH_URL + "')", accumulator += delay);
	   }
	   lastHeartbeatTime = now;
	}
}

function doTimeout() {
	logOffFromServers();
    setTimeout("goToTimeoutPage()", 1000);	
}

/* old version for non-recursive heartbeat
function extendSession() {
	// stop the timer
	clearTimeout(warningTimer);
	// update the lastPageLoadTime to now
	lastPageLoadTime = new Date().getTime();
	// this will refresh the active sessions
	heartbeatServiceWithWarning();
	// restart the heartbeat service
	startHeartbeat();
	// maximize the tab that was previously active 
	maxFrame(getActiveTab());
	// reset the countdown counter for the next time
	var count = COUNTDOWN_LENGTH;
	// reset the frame source
	resetToDefaultPage(COUNTDOWN_FRAME_NAME);	
} */

// version using recursive heartbeat
function extendSession() {
	// cancel the timeout
	clearTimeout(warningTimer);
	// update the lastPageLoadTime to now
	lastPageLoadTime = new Date().getTime();
	// restart the recursive heartbeat
	recursiveHeartbeat();
	// maximize the tab that was previously active 
	maxFrame(getActiveTab());
	// reset the countdown counter for the next time
	var count = COUNTDOWN_LENGTH;
	// reset the frame source
	resetToDefaultPage(COUNTDOWN_FRAME_NAME);
}

function goToTimeoutPage() {
   window.location = TIMEOUT_PAGE;
}

// countdown functions used by the countdown page
var count = top.COUNTDOWN_LENGTH;
var countdownTimer = null;
function startCountdown() {
   document.getElementById("counter").innerHTML = count;
   countdownTimer = setInterval("countdown()", 1000);   
}
function countdown() {
   if (count == 0) {
      clearInterval(countdownTimer);
   } else {
      --count;
   }
   document.getElementById("counter").innerHTML = count;
}

// Ease log out functions for same-domain and multiple-domain situations.

// global variables
var logOffAllowed = true;
var logOffNotAllowedFrame = null;
var logOffDmv = false;

function logOffAllDmv() {
   logOffDmv = true;
   logOffEase();
}
function logOffEase() {
   // if in multiple domains, we delegate log out to cross-domain version of log scripts
   if (isXDomain()) {
       logOffEaseXDomain();
   } else {
	   // otherwise we see if any frame is trying to prevent log out
	   var frames = getFrames();
	   var logOffAllowed = true;
	   for (var i = 1; i < frames.length; ++i) { // start at 1 to skip the first frame, which is the menu bar
		   if (!canLogOff(frames[i])) {
	         logOffAllowed = false;
	         logOffNotAllowedFrame = frames[i].name;
	         break;
	      }
	   }
	   // if OK to log out, we prompt user to confirm.
	   if (logOffAllowed) {
		   confirmLogOff();
	   // otherwise we prevent the log out attempt
	   } else { 
		   preventLogOff();
	   }  
   }
}
// evaluates 'the isLogOffAllowed var is not defined in the frame's page or the value is set to true'
function canLogOff(frame) { 
	return typeof frame.contentWindow.isLogOffAllowed == "undefined" || frame.contentWindow.isLogOffAllowed;
} 
/*
function confirmLogOff() {
	var yes = confirm("You are about to end your EASE session. Please select �EXIT EASE� to confirm your action, or select �Cancel� to return to your session");
    if (yes) {
       logOffFromServers();
       setTimeout("window.close()", 1000);
    } else {
       logOffDmv = false;
    }
}


function preventLogOff() {
	alert("You must finish or cancel your transaction before exiting EASE.");
	var frames = getFrames();
    // make the frame that is preventing logout the active frame, to bring it to the user's attention
    frames[NAVBAR_FRAME_NAME].contentWindow.serviceMenuChoice(logOffNotAllowedFrame);
    // reset this so it doesn't get stuck at false
    logOffAllowed = true; 
    logOffNotAllowedFrame = null;
    logOffDmv = false;
}
*/

function confirmLogOff() {
	maxFrame(LOGOUT_CONFIRM_FRAME_NAME, LOGOUT_CONFIRM_PAGE, true);
}
//to be invoked from confirm-logout page
function doLogOff() {
	logOffFromServers();
    setTimeout("window.close()", 1000);
}
//to be invoked from confirm-logout page
function cancelLogOff() {
	maxFrame(getActiveTab());
	resetToDefaultPage(LOGOUT_CONFIRM_FRAME_NAME);
}

function preventLogOff() {
	resetToDefaultPage(LOGOUT_CONFIRM_FRAME_NAME);
	maxFrame(LOGOUT_PREVENT_FRAME_NAME, LOGOUT_PREVENT_PAGE, true);
	// restart the heartbeat in case it has been stopped
	stopHeartbeat();
	startHeartbeat();
}
// to be invoked from prevent-logout page
function abortLogOff() {
	var frames = getFrames();
    // make the frame that is preventing logout the active frame, to bring it to the user's attention
    frames[NAVBAR_FRAME_NAME].contentWindow.serviceMenuChoice(logOffNotAllowedFrame);
    // reset this so it doesn't get stuck at false
    logOffAllowed = true; 
    logOffNotAllowedFrame = null;
    logOffDmv = false;
    resetToDefaultPage(LOGOUT_CONFIRM_FRAME_NAME);
}

function logOffFromServers() {
   var delay = 100; 
   var accumulator = 0; 
   var frames = getFrames();
   if (frames.namedItem("main")) {
       setTimeout("sendRequest('" + DL_LOGOUT_URL + "')", accumulator += delay);
   }
   var courtFrame = frames.namedItem("court");
   if (courtFrame && courtFrame.src.indexOf(DEFAULT_PAGE) == -1) {
	    setTimeout("sendRequest('" + COURT_LOGOUT_URL + "')", accumulator += delay);
   }
   var dcsFrame = frames.namedItem("dcs");
   if (dcsFrame && dcsFrame.src.indexOf(DEFAULT_PAGE) == -1) {
       setTimeout("sendRequest('" + DCS_LOGOUT_URL + "')", accumulator += delay);
   }
   if (logOffDmv) { // log off from webseal ?
      setTimeout("sendRequest('XXX')", accumulator += delay);
   } 
}
/*
function logOffEaseFromCountdownPage() {
	clearTimeout("warningTimer");
	logOffEase();
}
*/
//////////// X-DOMAIN LOGOUT FUNCTIONS ///////////////////

function isXDomain() {
   var isXDom = false; 
   var frames = getFrames();
   var dom = null;
   try {
      for (var i = 1; i < frames.length; ++i) {
         // will throw exception if cross domains - tested in FF3.6 and IE8 only - TODO test in all supported browsers   	  
         dom = frames[i].contentWindow.document.domain;
      }
   } catch (err) {
      isXDom = true;
   }
   return isXDom;
}

function logOffEaseXDomain() {
   //see if any frame is trying to prevent log out
   var frames = getFrames();
   var logOffAllowed = true;
   for (var i = 1; i < frames.length; ++i) { // start at 1 to skip the first frame, which is the menu bar
      requestXDomainLogOut(frames[i]);
   }
   var extraDelay = 0;
   if (typeof window.postMessage == "undefined") { extraDelay = 500; }
   setTimeout("doLogOffDecisionXDomain()", 500 + extraDelay);
}

function requestXDomainLogOut(frame) {
   if (typeof frame.contentWindow.postMessage != "undefined") {
       frame.contentWindow.postMessage("logOutRequest", "*"); 
   } else { // resort to x-domain hack to get data from the frame
	   requestXDomainLogOutViaProxy(frame);
   }
}
// receive messages from child frames
if (window.addEventListener) {window.addEventListener("message", receiveMessage, false);}
function receiveMessage(event) {   
  if ("syncSessions" == event.data) {
     syncSessions();
  } else if (event.data.indexOf("isLogOffAllowed") != -1) {
     var reply = event.data.substring(event.data.indexOf("=")+1, event.data.indexOf(","));
     if (reply == "false") {
        // if you are stepping here in debug mode, this code will execute too late to prevent log out
        logOffAllowed = false;
        logOffNotAllowedFrame = event.data.substring(event.data.indexOf(",")+1, event.data.length);
     }
  }  
}
// uses iframe and cookie to get cross-domain data from a child frame
function requestXDomainLogOutViaProxy(frame) {
    // create iframe pointed at the child domain 
    var frames = getFrames();
    if (frame.name == MAIN_FRAME_NAME) {
       frames[NAVBAR_FRAME_NAME].contentWindow.document.getElementById(PROXY_IFRAME_ID).src = 
    	   DL_REQUEST_PROXY_URL + "?" + REPLY_URL_PARAM_NAME + "=" + REPLY_PROXY_URL;
    }
    // TODO handle other frames that might want to prevent log out (besides the main/DL frame)
}

function doLogOffDecisionXDomain() {
   // check whether a cookie was set from a frame in another domain 
   if (readCookie("isLogOffAllowed") == "false") {
      logOffAllowed = false;
      logOffNotAllowedFrame = MAIN_FRAME_NAME; // TODO preferably this would be determined dynamically, so that non-main frames can control log out as well  
   }
   if (logOffAllowed) {
	   confirmLogOff();
   } else { 
	   preventLogOff();
   }  
}   

/////////////////////// utils //////////////////

// returns the value of a URL parameter
function readParam( name ) {
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return results[1];
}

function createCookie(name,value,seconds) {
	var expires = null;
	if (seconds) {
		var date = new Date();
		date.setTime(date.getTime()+(seconds*1000));
		expires = "; expires="+date.toGMTString();
	}
	else expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}