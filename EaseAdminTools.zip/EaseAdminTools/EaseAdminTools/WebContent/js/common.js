function openHelpText(){
	document.getElementById('helpText').style.visibility = 'visible';
	document.getElementById('helpText').style.display = 'inline';
}

function hideHelpText(){
	document.getElementById('helpText').style.visibility = 'hidden';
	document.getElementById('helpText').style.display = 'none';
}

function helpPopupWidow(pageName){}

//When you click on the button this function is invoked in order to show 
//status message at the bottom of the page. 
function processButtonAction() {
	document.getElementById("panelGrid_messages").style.visibility = 'hidden';
	document.getElementById("panelGrid_messages").style.display = 'none';
	
	document.getElementById("statusBar").style.visibility = 'visible';
	document.getElementById('statusBar').style.display = 'inline';
	$("#statusBar").html("<span class='uiErrorMessage'>PLEASE WAIT WHILE YOUR REQUEST IS BEING PROCESSED ...</span>");
	return true;
}
//For Informational Message we need to find out whether value got changed or not.
//Function to update fields when one is changed
function controlChange(obj){
	var id = obj.id;
	var newValue = document.getElementById(id).value;
	var originalValue = document.getElementById(id).defaultValue;
	newValue = newValue.toUpperCase();
	//alert(obj.id+" :: " + newValue + " >> " + originalValue);
	if(newValue != originalValue){
		  document.getElementById("MAIN_FORM:valueChange").value = "true";
	}
	else{
		document.getElementById("MAIN_FORM:valueChange").value = "false";
	}
}
//For OutOfStateLicence Page
function scrollDivDown()
{
	mydiv = document.getElementById("MAIN_FORM:editOutOfStateDlCollectionDiv");
	// var debug = "ScrollTop: " + mydiv.scrollTop;
	for (i = 50; i < mydiv.scrollHeight; i += 50) {
		var tmp = mydiv.scrollTop;
		// pre-store scrollTop
		mydiv.scrollTop += i;
		// update scrollTop
		if (tmp == mydiv.scrollTop) {
			break;
		}
	}
}

//Trim the white spaces
function trim(str) {
	return str.replace(/^\s+|\s+$/g, '');
}

function setTextSize(chgsize) {
	if (!document.documentElement || !document.body) return;
	var newSize = 100;
	var startSize = 100; //parseInt(getTextCookie("ease-textsize"));
	switch (chgsize) {
		case "incr":
			newSize = startSize + 35;
			break;
		case "decr":
			newSize = startSize - 25;
			break;
		case "reset":
			newSize = 100;
			break;
		default:
			newSize = startSize;
			break;
	}	
	document.getElementById("page").style.fontSize  = newSize + "%";
	//document.getElementById("court").style.fontSize  = newSize;
	//document.getElementById("dcs").style.fontSize  = newSize;
	setTextCookie("ease-textsize",newSize,365);
}

function getTextSize() {
	if (!document.getElementById("page")) return 0;
	var size = 0;
	if (document.getElementById("page").style && document.getElementById("page").style.fontSize) {
		size = document.getElementById("page").style.fontSize;
	}	
	else if (document.getElementById("page").currentStyle) {
		size = document.getElementById("page").currentStyle.fontSize;
	}
	return size;
}

function setTextCookie(name,value,days) {
	var expires = "";
	if (days) {
		var myDate=new Date();
		myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
		expires = "; expires=" + myDate.toGMTString();
	}
	else { 
		expires = "";
	}
	document.cookie = name + "=" + value + expires + "; path=/";
}

//Get the browser cookies for the increase/decrease text size.
function getTextCookie(name) {
	var nameEQ = name + "=";
	var cookies = document.cookie.split(";");
	for(var cnt = 0; cnt < cookies.length; cnt++) {
		var cookie = cookies[cnt];
		while (cookie.charAt(0) == " ") cookie = cookie.substring(1, cookie.length);
		if (cookie.indexOf(nameEQ) == 0) return cookie.substring(nameEQ.length, cookie.length);
	}
	return null;
}

//Load all the required resources on body function.
function load(contextPathName){
	loadCss(contextPathName);
	onloadHandler();	
}
var isLogOffAllowed = true; //true for all pages
//x-domain support function
function onloadHandler() {  
   if (notifyTopOnLoad) notifyTopOnLoad();
   // handleLogoutPrevention is an x-domain support function
   //if (handleLogoutPrevention) handleLogoutPrevention();  
}
// Called by onload event. Sends a message to top frameset so that it can manage session timers
function notifyTopOnLoad() {
   if (top != self) {
      try {
         // throws exception if cross-domain situation is encountered
         if (top.syncSessions) top.syncSessions(this);
      } catch (err) {
         if (typeof notifyTopOnLoadXDomain != "undefined") {
            notifyTopOnLoadXDomain();
         } else {
            alert("Warning: Cross-domain situation detected but cross-domain client script not loaded. Session synchronization may not work.");
         }
      }
   }
}

//Load all the required CSS files when load the screen.
function loadCss(contextPathName){
	var x = parseInt(getTextCookie("ease-textsize"));
	if (x && x!=0) {
		if(x == 100){
			unLoadCssTheme("smallerTheme.css");
			unLoadCssTheme("largerTheme.css");
			loadCssTheme("regularTheme.css", contextPathName);
		} else if(x == 75){
			unLoadCssTheme("regularTheme.css");
			unLoadCssTheme("largerTheme.css");
			loadCssTheme("smallerTheme.css", contextPathName);
		} else if(x == 135){
			unLoadCssTheme("smallerTheme.css");
			unLoadCssTheme("regularTheme.css");
			loadCssTheme("largerTheme.css", contextPathName);
		}
	}
	else{
		//no cookie value available, load regular theme
		unLoadCssTheme("smallerTheme.css");
		unLoadCssTheme("largerTheme.css");
		loadCssTheme("regularTheme.css", contextPathName);
	}
}
/*Load the argument css file using the context path param*/
function loadCssTheme(themeName, contextPathName){
	fileref=document.createElement("link");
	fileref.setAttribute("rel", "stylesheet");
	fileref.setAttribute("type", "text/css");
	
	if(contextPathName != null){
		var urlpath = contextPathName + "/css/" + themeName;
		fileref.setAttribute("href", urlpath);
		if (typeof fileref!= "undefined"){
			document.getElementsByTagName("head")[0].appendChild(fileref);
		}
	}
}

/*Unload the argument css file*/
function unLoadCssTheme(file){
	var allcss = document.getElementsByTagName("link");
	for (var i = allcss.length; i >= 0; i--) {
		if (allcss[i] && allcss[i].getAttribute("href")!= null && allcss[i].getAttribute("href").indexOf(file)!=-1){
			allcss[i].parentNode.removeChild(allcss[i]);
		}
	}
}
//This function will invoke before submitting form (for all the submit buttons)
//Make all the form fields read-only after submit.
function makeReadonlyOnSubmit() {
	var form = document.forms['MAIN_FORM'];
    for (var i=0; i < form.elements.length; i++){
    	if(isInputType(form.elements[i])) {
    		form.elements[i].readOnly = true;
    	}    	
    }
    return true;
}

function isInputType(formElement){
	var inputType = formElement.type;
	if (inputType == "text" || inputType == "select-one" || inputType == "textarea" || inputType == "button" || 
			inputType == "select" || inputType == "checkbox" ||	inputType == "radio" || inputType == "submit" || 
			inputType == "reset" || inputType == "password") {
		return true;
	}
	return false;
}