/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;

/**
 * Description: I reperesent the business object, STATION 
 * File: StationInfo.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Sep 5, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class StationInfo {
	/** The sys id. */
	private Integer sysId;
	/** The station id. */
	private String stationId;
	/** The primary printer id. */
	private String primaryPrinterId;
	/** The alternate printer id. */
	private String alternatePrinterId;
	/** The inventory assigned flg. */
	private String inventoryAssignedFlg;

	/**
	 * Gets the sys id.
	 *
	 * @return the sys id
	 */
	public Integer getSysId() {
		return sysId;
	}

	/**
	 * Sets the sys id.
	 *
	 * @param sysId the new sys id
	 */
	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}

	/**
	 * Gets the station id.
	 * 
	 * @return the station id
	 */
	public String getStationId() {
		return stationId;
	}

	/**
	 * Sets the station id.
	 * 
	 * @param stationId
	 *            the new station id
	 */
	public void setStationId(String stationId) {
		this.stationId = stationId;
	}

	/**
	 * Gets the primary printer id.
	 * 
	 * @return the primary printer id
	 */
	public String getPrimaryPrinterId() {
		return primaryPrinterId;
	}

	/**
	 * Sets the primary printer id.
	 * 
	 * @param primaryPrinterId
	 *            the new primary printer id
	 */
	public void setPrimaryPrinterId(String primaryPrinterId) {
		this.primaryPrinterId = primaryPrinterId;
	}

	/**
	 * Gets the alternate printer id.
	 * 
	 * @return the alternate printer id
	 */
	public String getAlternatePrinterId() {
		return alternatePrinterId;
	}

	/**
	 * Sets the alternate printer id.
	 * 
	 * @param alternatePrinterId
	 *            the new alternate printer id
	 */
	public void setAlternatePrinterId(String alternatePrinterId) {
		this.alternatePrinterId = alternatePrinterId;
	}

	/**
	 * Gets the inventory assigned flg.
	 * 
	 * @return the inventory assigned flg
	 */
	public String getInventoryAssignedFlg() {
		return inventoryAssignedFlg;
	}

	/**
	 * Sets the inventory assigned flg.
	 * 
	 * @param inventoryAssignedFlg
	 *            the new inventory assigned flg
	 */
	public void setInventoryAssignedFlg(String inventoryAssignedFlg) {
		this.inventoryAssignedFlg = inventoryAssignedFlg;
	}
}
