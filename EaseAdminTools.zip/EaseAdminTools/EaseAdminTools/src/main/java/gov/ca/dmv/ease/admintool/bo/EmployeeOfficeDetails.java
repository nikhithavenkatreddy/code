/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;

import java.io.Serializable;

/**
 * Description: This class is serves as a BO to hold Employee and Office details. 
 * File: EmployeeOfficeDetails.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 17, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class EmployeeOfficeDetails implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2718399703442408089L;
	/** The office work date control sys id. */
	private Integer officeWrkDtCntrlSysId;
	/** The employee work date control sys id. */
	private Integer employeeWrkDtCntrlSysId;
	/** The tech id. */
	private String techId;
	/** The user sys id. */
	private String userSysId;
	/** The office id. */
	private String officeId;
	/** The office sys id. */
	private String officeSysId;
	/** The office name. */
	private String officeName;
	/** The work date. */
	private String workDate;
	/** The authorized work date status. */
	private boolean authorizedWorkDateStatus;
	


	/**
	 * Gets the office wrk dt cntrl sys id.
	 *
	 * @return the office wrk dt cntrl sys id
	 */
	public Integer getOfficeWrkDtCntrlSysId() {
		return officeWrkDtCntrlSysId;
	}

	/**
	 * Sets the office wrk dt cntrl sys id.
	 *
	 * @param officeWrkDtCntrlSysId the new office wrk dt cntrl sys id
	 */
	public void setOfficeWrkDtCntrlSysId(Integer officeWrkDtCntrlSysId) {
		this.officeWrkDtCntrlSysId = officeWrkDtCntrlSysId;
	}

	/**
	 * Gets the employee wrk dt cntrl sys id.
	 *
	 * @return the employee wrk dt cntrl sys id
	 */
	public Integer getEmployeeWrkDtCntrlSysId() {
		return employeeWrkDtCntrlSysId;
	}

	/**
	 * Sets the employee wrk dt cntrl sys id.
	 *
	 * @param employeeWrkDtCntrlSysId the new employee wrk dt cntrl sys id
	 */
	public void setEmployeeWrkDtCntrlSysId(Integer employeeWrkDtCntrlSysId) {
		this.employeeWrkDtCntrlSysId = employeeWrkDtCntrlSysId;
	}

	/**
	 * Gets the tech id.
	 *
	 * @return the tech id
	 */
	public String getTechId() {
		return techId;
	}

	/**
	 * Sets the tech id.
	 *
	 * @param techId the new tech id
	 */
	public void setTechId(String techId) {
		this.techId = techId;
	}

	/**
	 * Gets the user sys id.
	 *
	 * @return the user sys id
	 */
	public String getUserSysId() {
		return userSysId;
	}

	/**
	 * Sets the user sys id.
	 *
	 * @param userSysId the new user sys id
	 */
	public void setUserSysId(String userSysId) {
		this.userSysId = userSysId;
	}

	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the office sys id.
	 *
	 * @return the office sys id
	 */
	public String getOfficeSysId() {
		return officeSysId;
	}

	/**
	 * Sets the office sys id.
	 *
	 * @param officeSysId the new office sys id
	 */
	public void setOfficeSysId(String officeSysId) {
		this.officeSysId = officeSysId;
	}

	/**
	 * Gets the office name.
	 *
	 * @return the office name
	 */
	public String getOfficeName() {
		return officeName;
	}

	/**
	 * Sets the office name.
	 *
	 * @param officeName the new office name
	 */
	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}

	/**
	 * Gets the work date.
	 *
	 * @return the work date
	 */
	public String getWorkDate() {
		return workDate;
	}

	/**
	 * Sets the work date.
	 *
	 * @param workDate the new work date
	 */
	public void setWorkDate(String workDate) {
		this.workDate = workDate;
	}

	/**
	 * Gets the authorized work date status.
	 *
	 * @return the authorized work date status
	 */
	public boolean getAuthorizedWorkDateStatus() {
		return authorizedWorkDateStatus;
	}

	/**
	 * Sets the authorized work date status.
	 *
	 * @param authorizedWorkDateStatus the new authorized work date status
	 */
	public void setAuthorizedWorkDateStatus(boolean authorizedWorkDateStatus) {
		this.authorizedWorkDateStatus = authorizedWorkDateStatus;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("officeWorkDateControlSysId: " + officeWrkDtCntrlSysId);
		sb.append("employeeWorkDateControlSysId: " + employeeWrkDtCntrlSysId);
		sb.append("techId: " + techId);
		sb.append("userSysId: " + userSysId);
		sb.append("officeId: " + officeId);
		sb.append("officeSysId:" + officeSysId);
		sb.append("officeName: " + officeName);
		sb.append("workDate: " + workDate);
		sb.append("authorizedWorkDateStatus: " + authorizedWorkDateStatus);
		return sb.toString();
	}
}