/**
 * 
 */
package gov.ca.dmv.ease.admintool.logging.impl;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.xml.DOMConfigurator;


/**
 * Description: Servlet Context Listener class that loads the log4j XML file, using the EASE_ENV system 
 * variable to pick the right file for the environment.
 * 
 * File: EaseLog4JInitServletContextListener.java
 * Module:  gov.ca.dmv.ease.fw.logging.impl
 * Created: Aug 4, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2013/06/25 21:43:07 $
 * Last Changed By: $Author: mwsec2 $
 */
public class EaseLog4JInitServletContextListener implements
		ServletContextListener {
	
	private static final String ENVIRONMENT;
	
	static {
		String env = null;
		try {
			Context initCtx = new InitialContext();
			env = initCtx.lookup("EASE_ENV").toString();
		} catch (NamingException namingexception) {
			System.err.println("Error getting the EASE_ENV jndi variable. " +
								"Check the server config: "
								+ namingexception.getMessage());
		}
		ENVIRONMENT = env;
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent arg0) {
		// not implemented
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {
		String log4jConfigLocation = sce.getServletContext().getInitParameter(
				"log4jConfigLocation");
		log4jConfigLocation = sce.getServletContext().getRealPath(
				log4jConfigLocation);
		String log4jConfigFileName = "log4j-" + ENVIRONMENT + ".xml";
		DOMConfigurator.configure(log4jConfigLocation + log4jConfigFileName);
		System.out
				.println("EaseLog4JInitServletContextListener has configured log4j to use "
						+ log4jConfigFileName);
	}
}


/**
 *  Modification History:
 *
 *  $Log: EaseLog4JInitServletContextListener.java,v $
 *  Revision 1.1  2013/06/25 21:43:07  mwsec2
 *  WAS7 upgrade and conversion to log4j app logging
 *
 *  Revision 1.1.2.1  2012/11/15 20:55:44  mwsec2
 *  added for log4j support
 *
 *  Revision 1.1.6.1  2012/09/04 22:27:03  mwsec2
 *  logging & jmx enhancements
 *
 *  Revision 1.1.4.1  2012/08/01 21:17:49  mwsec2
 *  initial commit to new branch
 *
 *  Revision 1.1.2.1  2012/07/31 17:21:36  mwsec2
 *  checking in logging enhancements
 *
 */
