package gov.ca.dmv.ease.admintool.dao;

import static gov.ca.dmv.ease.admintool.common.IConstants.DATASOURCE_CONTEXT;
import gov.ca.dmv.ease.admintool.bo.EmployeeOfficeDetails;
import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.bo.LocationInfo;
import gov.ca.dmv.ease.admintool.bo.StationInfo;
import gov.ca.dmv.ease.admintool.common.TableNamesEnum;
import gov.ca.dmv.ease.admintool.response.impl.SaveLocationAndStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveWorkDateStatusResponse;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Description: This class is serves as a Data Access Layer. File:
 * EmployeeOfficeDetails.java Module: gov.ca.dmv.ease.admintool.bo 
 * Created: Aug 17, 2012
 * @author mwpkc2
 * @version $Revision: 1.5 $ 
 * Last Changed: 
 * $Date: 2012/09/07 20:50:26 
 * $ Last Changed By: 
 * $Author: mwpkc2 $
 */
public class AdminToolDao { //implements IAdminToolPersistenceService {
	/**
	 * Gets the connection.
	 * 
	 * @return the connection
	 */
	public Connection getConnection() {
		Context initialContext;
		try {
			initialContext = new InitialContext();
			if (initialContext == null) {
				throw new NullPointerException(
						"JNDI problem. Cannot create InitialContext.");
			}
			DataSource datasource = (DataSource) initialContext
					.lookup(DATASOURCE_CONTEXT);
			if (datasource != null) {
				return datasource.getConnection();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch (NamingException e) {
			e.printStackTrace();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getEmployeeOfficeDetails(gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getEmployeeOfficeDetails(gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	public List <EmployeeOfficeDetails> getEmployeeOfficeDetails(
			InputData inputData) {
		StringBuilder sqlQuery = new StringBuilder();
		List <EmployeeOfficeDetails> resultList = new ArrayList <EmployeeOfficeDetails>();
		PreparedStatement statement = null;
		Connection connection = null;
		ResultSet resultset = null;
		try {
			connection = getConnection();
			sqlQuery
					.append(" SELECT EWDC.SYS_ID AS EWDC_SYS_ID, EWDC.OFFICE_WRK_DT_CNTRL_SYSID AS EWDC_OFFICE_WRK_DT_CNTRL_SYSID, EWDC.AUTHD_WRK_DT_STATUS, OWDC.AUTHD_WRK_DT_STATUS, OWDC.OFFICE_SYSID, OWDC.AUTHD_WRK_DT, EMP.TECH_ID, OFC.OFFICE_ID, OFC.OFFICE_NME ");
			sqlQuery.append(" FROM MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL EWDC ");
			sqlQuery
					.append(" LEFT JOIN MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL OWDC ON OWDC.SYS_ID = EWDC.OFFICE_WRK_DT_CNTRL_SYSID ");
			sqlQuery
					.append(" LEFT JOIN MWKDB2MV.VSSM028U_OFFICE OFC ON OWDC.OFFICE_SYSID = OFC.SYS_ID ");
			sqlQuery
					.append(" LEFT JOIN MWKDB2MV.VSSM026U_EMPLOYEE_A EMP ON EMP.SYS_ID = EWDC.EMPLOYEE_SYSID ");
			sqlQuery.append(" WHERE OFC.OFFICE_ID = ? ");
			boolean isAllTechIds = "*".equals(inputData.getTechId());
			if (!isAllTechIds)
				sqlQuery.append(" AND EMP.TECH_ID = ? ");
			//sqlQuery.append(" AND EWDC.AUTHD_WRK_DT_STATUS = 'S'  AND OWDC.AUTHD_WRK_DT_STATUS = 'S' ");
			sqlQuery.append(" ORDER BY EWDC.CREATE_TSTAMP DESC ");
			if (!isAllTechIds)
				sqlQuery.append(" FETCH FIRST 1 ROWS ONLY; ");
			System.out.println(sqlQuery);
			//-------------- End of build query
			statement = connection.prepareStatement(sqlQuery.toString());
			statement.setString(1, inputData.getOfficeId());
			if (!isAllTechIds)
				statement.setString(2, inputData.getTechId().toUpperCase());
			resultset = statement.executeQuery();
			EmployeeOfficeDetails details = null;
			while (resultset.next()) {
				details = new EmployeeOfficeDetails();
				details.setEmployeeWrkDtCntrlSysId(resultset
						.getInt("EWDC_SYS_ID"));
				details.setOfficeWrkDtCntrlSysId(resultset
						.getInt("EWDC_OFFICE_WRK_DT_CNTRL_SYSID"));
				details.setAuthorizedWorkDateStatus(isStatusNotS(resultset
						.getString("AUTHD_WRK_DT_STATUS")));
				details.setOfficeSysId(resultset.getString("OFFICE_SYSID"));
				details.setWorkDate(resultset.getString("AUTHD_WRK_DT"));
				details.setTechId(resultset.getString("TECH_ID"));
				details.setOfficeId(resultset.getString("OFFICE_ID"));
				details.setOfficeName(resultset.getString("OFFICE_NME"));
				resultList.add(details);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllOffices()
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllOffices()
	 */
	public List <Office> getAllOffices() {
		String sqlQuery = "SELECT DISTINCT * FROM MWKDB2MV.VSSM028U_OFFICE";
		List <Office> resultList = new ArrayList <Office>();
		/*PreparedStatement statement = null;
		Connection connection = null;
		ResultSet resultset = null;
		try {
			connection = getConnection();
			statement = connection.prepareStatement(sqlQuery);
			resultset = statement.executeQuery();
			Office office = null;
			while (resultset.next()) {
				office = new Office();
				office.setOfficeId(resultset.getString("OFFICE_ID"));
				office.setOfficeName(resultset.getString("OFFICE_NME"));
				resultList.add(office);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		Collections.sort(resultList);*/
		return resultList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllStations()
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllStations()
	 */
	public List <Station> getAllStations() {
		String sqlQuery = "SELECT * FROM MWKDB2MV.VSSM060U_STATION_INFO ORDER BY SYS_ID;";
		List <Station> resultList = new ArrayList <Station>();
		PreparedStatement statement = null;
		Connection connection = null;
		ResultSet resultset = null;
		try {
			connection = getConnection();
			statement = connection.prepareStatement(sqlQuery);
			resultset = statement.executeQuery();
			Station station = null;
			while (resultset.next()) {
				station = new Station();
				//station.setSysId(resultset.getInt("SYS_ID"));
				station.setStationId(resultset.getString("STATION_ID"));
				station.setPrimaryPrinterId(resultset
						.getString("PRIMARY_PRINTER_ID"));
				station.setAlternatePrinterId(resultset
						.getString("ALTERNATE_PRINTER_ID"));
				//station.setInventoryAssignedFlg(resultset.getString("INVENTORY_ASSIGNED_FLG"));
				resultList.add(station);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateWorkDateStatus(java.util.List, boolean)
	 */
	public SaveWorkDateStatusResponse updateWorkDateStatus(
			List <EmployeeOfficeDetails> input, boolean updateBoth) {
		Statement statement1 = null;
		Statement statement2 = null;
		Connection connection = null;
		try {
			connection = getConnection();
			connection.setAutoCommit(false);
			if (updateBoth) {
				String updateQuerty1 = getUpdateQueryEmpWrkDtCntrl(input);
				System.out.println(updateQuerty1);
				// Update VTDM027U_EMP_WRK_DT_CNTRL
				statement1 = connection.createStatement();
				statement1.executeUpdate(updateQuerty1);
			}
			// Update VTDM028U_OFFICE_WRK_DT_CNTRL
			String updateQuerty2 = getUpdateQueryOfficeWrkDtCntrl(input);
			System.out.println(updateQuerty2);
			statement2 = connection.createStatement();
			statement2.executeUpdate(updateQuerty2);
			// Commit transaction
			connection.commit();
			return null;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (statement1 != null) {
					statement1.close();
				}
				if (statement2 != null) {
					statement2.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addLocationAndStationDetails(gov.ca.dmv.ease.admintool.bo.LocationInfo)
	 */
	/**
	 * Adds the location and station details.
	 *
	 * @param input the input
	 * @return the integer
	 */
	public Integer addLocationAndStationDetails(LocationInfo input) {
		PreparedStatement statement1 = null;
		Connection connection = null;
		Integer nextSysId = null;
		try {
			String insertQuerty = "INSERT INTO MWKDB2MV.VSSM059U_LOCATION_INFO(SYS_ID, STATION_SYSID, STATION_IP_ADDR, OFFICE_ID, OFFICE_MNEMONIC, L1_SERVER_CD, L1_SERVER_SUFX) VALUES (?, ?, ?, ?, ?, ?, ?);";
			nextSysId = getNextSysId(TableNamesEnum.LOCATION_INFO_TABLE);
			if (nextSysId == null) {
				System.err.println("Could not get nextsysid for location_info");
				return null;
			}
			System.out.println(nextSysId);
			connection = getConnection();
			connection.setAutoCommit(false);
			statement1 = connection.prepareStatement(insertQuerty);
			statement1.setInt(1, nextSysId);
			statement1.setInt(2, input.getStationSysId());
			statement1.setString(3, input.getStationIpAddr());
			statement1.setString(4, input.getOfficeId());
			statement1.setString(5, "XX");
			statement1.setString(6, "IT1");
			statement1.setString(7, "D01");
			statement1.executeUpdate();
			connection.commit();
		}
		catch (Exception e) {
			nextSysId = null;
			e.printStackTrace();
		}
		finally {
			try {
				if (statement1 != null) {
					statement1.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return nextSysId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateLocationAndStationDetails(gov.ca.dmv.ease.admintool.bo.LocationInfo)
	 */
	/**
	 * Update location and station details.
	 *
	 * @param input the input
	 * @return true, if successful
	 */
	public boolean updateLocationAndStationDetails(LocationInfo input) {
		PreparedStatement statement1 = null;
		PreparedStatement statement2 = null;
		Connection connection = null;
		boolean retValue = false;
		try {
			String updateQuerty1 = "UPDATE MWKDB2MV.VSSM059U_LOCATION_INFO SET STATION_IP_ADDR = ? WHERE OFFICE_ID = ? AND STATION_SYSID = ? AND STATION_IP_ADDR = ?";
			connection = getConnection();
			connection.setAutoCommit(false);
			statement1 = connection.prepareStatement(updateQuerty1);
			//statement1.setString(1, newValue.getStationIpAddr());
			statement1.setString(1, input.getStationIpAddr());
			statement1.setString(2, input.getOfficeId());
			statement1.setInt(3, input.getStationSysId());
			connection.commit();
			retValue = true;
		}
		catch (Exception e) {
			retValue = false;
			e.printStackTrace();
		}
		finally {
			try {
				if (statement1 != null) {
					statement1.close();
				}
				if (statement2 != null) {
					statement2.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#deleteLocationAndStationDetails(gov.ca.dmv.ease.admintool.bo.LocationInfo)
	 */
	/**
	 * Delete location and station details.
	 *
	 * @param input the input
	 * @return true, if successful
	 */
	public boolean deleteLocationAndStationDetails(LocationInfo input) {
		PreparedStatement statement1 = null;
		PreparedStatement statement2 = null;
		Connection connection = null;
		boolean retValue = false;
		try {
			String updateQuerty1 = "DELETE FROM MWKDB2MV.VSSM059U_LOCATION_INFO WHERE OFFICE_ID = ? AND STATION_SYSID = ? AND STATION_IP_ADDR = ?";
			connection = getConnection();
			connection.setAutoCommit(false);
			statement1 = connection.prepareStatement(updateQuerty1);
			statement1.setString(1, input.getOfficeId());
			statement1.setInt(2, input.getStationSysId());
			statement1.setString(3, input.getStationIpAddr());
			connection.commit();
			retValue = true;
		}
		catch (Exception e) {
			retValue = false;
			e.printStackTrace();
		}
		finally {
			try {
				if (statement1 != null) {
					statement1.close();
				}
				if (statement2 != null) {
					statement2.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getStationInfoByOfficeId(java.lang.String)
	 */
	public List <StationInfo> getStationInfoByOfficeId(String officeId) {
		List <StationInfo> retValue = null;
		PreparedStatement statement1 = null;
		Connection connection = null;
		ResultSet resultSet = null;
		try {
			String sqlQuerty = "SELECT * FROM MWKDB2MV.VSSM060U_STATION_INFO"
					+ " WHERE SYS_ID IN (SELECT DISTINCT STATION_SYSID FROM MWKDB2MV.VSSM059U_LOCATION_INFO WHERE OFFICE_ID = ?);";
			connection = getConnection();
			statement1 = connection.prepareStatement(sqlQuerty);
			statement1.setString(1, officeId);
			resultSet = statement1.executeQuery();
			StationInfo station = new StationInfo();
			retValue = new ArrayList <StationInfo>();
			while (resultSet.next()) {
				station = new StationInfo();
				station.setSysId(resultSet.getInt("SYS_ID"));
				station.setStationId(resultSet.getString("STATION_ID"));
				station.setPrimaryPrinterId(resultSet
						.getString("PRIMARY_PRINTER_ID"));
				station.setAlternatePrinterId(resultSet
						.getString("ALTERNATE_PRINTER_ID"));
				station.setInventoryAssignedFlg(resultSet
						.getString("INVENTORY_ASSIGNED_FLG"));
				retValue.add(station);
			}
		}
		catch (Exception e) {
			retValue = null;
			e.printStackTrace();
		}
		finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement1 != null) {
					statement1.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#doesStationExist(java.lang.String)
	 */
	public boolean doesStationExist(String stationSysId) {
		/*if (stationSysId == null) {
			throw new NullPointerException("STATION_SYS_ID cannot be null");
		}
		PreparedStatement statement = null;
		Connection connection = null;
		ResultSet resultset = null;
		boolean retValue = false;
		try {
			String sqlQuery = "SELECT * FROM MWKDB2MV.VSSM060U_STATION_INFO "
					+ " WHERE SYS_ID = ? "
					+ " ORDER BY CREATE_TSTAMP DESC "
					+ " FETCH FIRST 1 ROWS ONLY;";
			connection = getConnection();
			statement = connection.prepareStatement(sqlQuery);
			statement.setLong(1, stationSysId);
			resultset = statement.executeQuery();
			while (resultset.next()) {
				retValue = true;
			}
		}
		catch (Exception e) {
			retValue = false;
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;*/
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addStationInfo(gov.ca.dmv.ease.admintool.bo.StationInfo)
	 */
	public void addStationInfo(StationInfo input) {
		PreparedStatement statement1 = null;
		Connection connection = null;
		Integer nextSysId = null;
		try {
			String updateQuerty1 = "INSERT INTO MWKDB2MV.VSSM060U_STATION_INFO(SYS_ID, STATION_ID, PRIMARY_PRINTER_ID, ALTERNATE_PRINTER_ID, INVENTORY_ASSIGNED_FLG) VALUES(?, ?, ?, ?, ?);";
			nextSysId = getNextSysId(TableNamesEnum.STATION_INFO_TABLE);
			if (nextSysId == null) {
				System.err.println("Could not get nextsysid for location_info");
				return;
			}
			System.out.println(nextSysId);
			connection = getConnection();
			connection.setAutoCommit(false);
			statement1 = connection.prepareStatement(updateQuerty1);
			statement1.setInt(1, nextSysId);
			statement1.setString(2, input.getStationId());
			statement1.setString(3, input.getPrimaryPrinterId());
			statement1.setString(4, input.getAlternatePrinterId());
			statement1.setString(5, input.getInventoryAssignedFlg());
			statement1.executeUpdate();
			connection.commit();
		}
		catch (Exception e) {
			nextSysId = null;
			e.printStackTrace();
		}
		finally {
			try {
				if (statement1 != null) {
					statement1.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getNextSysId(gov.ca.dmv.ease.admintool.common.TableNamesEnum)
	 */
	/**
	 * Gets the next sys id.
	 *
	 * @param tableName the table name
	 * @return the next sys id
	 */
	public Integer getNextSysId(TableNamesEnum tableName) {
		Statement statement = null;
		Connection connection = null;
		ResultSet resultset = null;
		Integer retValue = null;
		try {
			String sqlQuery = "SELECT MAX(SYS_ID) + 1 AS NEXT_SYSID FROM "
					+ tableName.getTableName() + ";";
			connection = getConnection();
			statement = connection.createStatement();
			resultset = statement.executeQuery(sqlQuery);
			while (resultset.next()) {
				retValue = resultset.getInt("NEXT_SYSID");
			}
		}
		catch (Exception e) {
			retValue = null;
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getEmployeeOfficeDetailsByOfficeId(gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	public List <EmployeeOfficeDetails> getEmployeeOfficeDetailsByOfficeId(
			InputData input) {
		List <EmployeeOfficeDetails> retValue = null;
		PreparedStatement statement1 = null;
		Connection connection = null;
		ResultSet resultSet = null;
		try {
			String sqlQuerty = " SELECT OFC.SYS_ID AS OFC_SYS_ID, OFC.OFFICE_ID, OFC.OFFICE_NME, OWDC.SYS_ID AS OWDC_SYS_ID, OWDC.AUTHD_WRK_DT, OWDC.AUTHD_WRK_DT_STATUS "
					+ " FROM MWKDB2MV.VSSM028U_OFFICE OFC "
					+ " LEFT JOIN MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL OWDC ON OFC.SYS_ID = OWDC.OFFICE_SYSID "
					+ " WHERE OFC.OFFICE_ID = ? AND OWDC.AUTHD_WRK_DT_STATUS = 'S' "
					+ " ORDER BY OFC.CREATE_TSTAMP DESC";
			System.out.println(sqlQuerty);
			connection = getConnection();
			statement1 = connection.prepareStatement(sqlQuerty);
			statement1.setString(1, input.getOfficeId());
			resultSet = statement1.executeQuery();
			EmployeeOfficeDetails details = new EmployeeOfficeDetails();
			retValue = new ArrayList <EmployeeOfficeDetails>();
			while (resultSet.next()) {
				details = new EmployeeOfficeDetails();
				details.setOfficeSysId(resultSet.getString("OFC_SYS_ID"));
				details.setOfficeId(resultSet.getString("OFFICE_ID"));
				details.setOfficeName(resultSet.getString("OFFICE_NME"));
				details.setOfficeWrkDtCntrlSysId(resultSet
						.getInt("OWDC_SYS_ID"));
				details.setWorkDate(resultSet.getString("AUTHD_WRK_DT"));
				details.setAuthorizedWorkDateStatus(isStatusNotS(resultSet
						.getString("AUTHD_WRK_DT_STATUS")));
				retValue.add(details);
			}
		}
		catch (Exception e) {
			retValue = null;
			e.printStackTrace();
		}
		finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement1 != null) {
					statement1.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retValue;
	}

	/**
	 * Gets the update query emp wrk dt cntrl.
	 *
	 * @param input the input
	 * @return the update query emp wrk dt cntrl
	 */
	private String getUpdateQueryEmpWrkDtCntrl(
			List <EmployeeOfficeDetails> input) {
		List <Integer> unique = new ArrayList <Integer>();
		StringBuilder sb = new StringBuilder();
		String query = "UPDATE MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL SET AUTHD_WRK_DT_STATUS = 'A' WHERE SYS_ID IN ";
		sb.append("(");
		EmployeeOfficeDetails details = null;
		for (int index = 0; index < input.size(); index++) {
			details = input.get(index);
			Integer id = details.getEmployeeWrkDtCntrlSysId();
			if (details.getAuthorizedWorkDateStatus() && !unique.contains(id)) {
				unique.add(id);
				sb.append(id + ",");
			}
		}
		sb.append(")");
		return query + sb.toString().replace(",)", ")");
	}

	/**
	 * Gets the update query office wrk dt cntrl.
	 *
	 * @param input the input
	 * @return the update query office wrk dt cntrl
	 */
	private String getUpdateQueryOfficeWrkDtCntrl(
			List <EmployeeOfficeDetails> input) {
		String query = "UPDATE MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL SET AUTHD_WRK_DT_STATUS = 'A' WHERE SYS_ID IN ";
		StringBuilder sb = new StringBuilder();
		List <Integer> unique = new ArrayList <Integer>();
		EmployeeOfficeDetails details = null;
		sb.append("(");
		for (int index = 0; index < input.size(); index++) {
			details = input.get(index);
			Integer id = details.getOfficeWrkDtCntrlSysId();
			if (details.getAuthorizedWorkDateStatus() && !unique.contains(id)) {
				unique.add(id);
				sb.append(id + ",");
			}
		}
		sb.append(")");
		return query + sb.toString().replace(",)", ")");
	}

	/**
	 * Checks if is status s.
	 *
	 * @param status the status
	 * @return true, if is status s
	 */
	private boolean isStatusNotS(String status) {
		return !"S".equals(status);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addLocationAndStationDetails(gov.ca.dmv.ease.bo.app.impl.Location)
	 */
	public SaveLocationAndStationResponse addLocationAndStationDetails(
			Location input) {
		return null;
	}
}