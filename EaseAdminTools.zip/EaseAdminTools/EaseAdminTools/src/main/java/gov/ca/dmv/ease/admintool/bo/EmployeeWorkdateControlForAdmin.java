/**
 * 
 */
package gov.ca.dmv.ease.admintool.bo;

import gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl;

/**
 * @author mwsxv5
 *
 */
public class EmployeeWorkdateControlForAdmin extends EmployeeWorkdateControl {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8590399174869425493L;
	private Boolean ToAuthorizeWrkDt;

	public Boolean getToAuthorizeWrkDt() {
		return ToAuthorizeWrkDt;
	}

	public void setToAuthorizeWrkDt(Boolean toAuthorizeWrkDt) {
		ToAuthorizeWrkDt = toAuthorizeWrkDt;
	}
}
