/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Description: This class is serves as a BO to hold Employee and Office details. 
 * File: EmployeeOfficeDetails.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 17, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class EmployeeOfficeDetails1 implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2718399703442408089L;
	/** The office wrk dt cntrl sys id. */
	private List <Integer> officeWrkDtCntrlSysIds;
	/** The employee wrk dt cntrl sys id. */
	private List <Integer> employeeWrkDtCntrlSysIds;
	/** The tech id. */
	private List <String> techIds;
	/** The user sys id. */
	private List <String> userSysIds;
	/** The office id. */
	private List <String> officeIds;
	/** The office sys id. */
	private List <String> officeSysIds;
	/** The office name. */
	private List <String> officeNames;
	/** The work date. */
	private List <String> workDates;
	/** The authorized work date status. */
	private List <String> authorizedWorkDateStatuses;

	/**
	 * Adds the authorized work date status.
	 *
	 * @param authorizedWorkDateStatus the authorized work date status
	 */
	public void addAuthorizedWorkDateStatus(String authorizedWorkDateStatus) {
		if (authorizedWorkDateStatuses == null)
			authorizedWorkDateStatuses = new ArrayList <String>();
		authorizedWorkDateStatuses.add(authorizedWorkDateStatus);
	}

	/**
	 * Adds the employee wrk dt cntrl sys id.
	 *
	 * @param employeeWrkDtCntrlSysId the employee wrk dt cntrl sys id
	 */
	public void addEmployeeWrkDtCntrlSysId(Integer employeeWrkDtCntrlSysId) {
		if (employeeWrkDtCntrlSysIds == null)
			employeeWrkDtCntrlSysIds = new ArrayList <Integer>();
		employeeWrkDtCntrlSysIds.add(employeeWrkDtCntrlSysId);
	}

	/**
	 * Adds the office id.
	 *
	 * @param officeId the office id
	 */
	public void addOfficeId(String officeId) {
		if (officeIds == null)
			officeIds = new ArrayList <String>();
		officeIds.add(officeId);
	}

	/**
	 * Adds the office name.
	 *
	 * @param officeName the office name
	 */
	public void addOfficeName(String officeName) {
		if (officeNames == null)
			officeNames = new ArrayList <String>();
		officeNames.add(officeName);
	}

	/**
	 * Adds the office sys id.
	 *
	 * @param officeSysId the office sys id
	 */
	public void addOfficeSysId(String officeSysId) {
		if (officeSysIds == null)
			officeSysIds = new ArrayList <String>();
		officeSysIds.add(officeSysId);
	}

	/**
	 * Adds the office wrk dt cntrl sys id.
	 *
	 * @param officeWrkDtCntrlSysId the office wrk dt cntrl sys id
	 */
	public void addOfficeWrkDtCntrlSysId(Integer officeWrkDtCntrlSysId) {
		if (officeWrkDtCntrlSysIds == null)
			officeWrkDtCntrlSysIds = new ArrayList <Integer>();
		officeWrkDtCntrlSysIds.add(officeWrkDtCntrlSysId);
	}

	/**
	 * Adds the tech id.
	 *
	 * @param techId the tech id
	 */
	public void addTechId(String techId) {
		if (techIds == null)
			techIds = new ArrayList <String>();
		techIds.add(techId);
	}

	/**
	 * Adds the user sys id.
	 *
	 * @param userSysId the user sys id
	 */
	public void addUserSysId(String userSysId) {
		if (userSysIds == null)
			userSysIds = new ArrayList <String>();
		userSysIds.add(userSysId);
	}

	/**
	 * Adds the work date.
	 *
	 * @param workDate the work date
	 */
	public void addWorkDate(String workDate) {
		if (workDates == null)
			workDates = new ArrayList <String>();
		workDates.add(workDate);
	}

	/**
	 * Gets the authorized work date statuses.
	 *
	 * @return the authorized work date statuses
	 */
	public List <String> getAuthorizedWorkDateStatuses() {
		return authorizedWorkDateStatuses;
	}

	/**
	 * Gets the employee wrk dt cntrl sys ids.
	 *
	 * @return the employee wrk dt cntrl sys ids
	 */
	public List <Integer> getEmployeeWrkDtCntrlSysIds() {
		return employeeWrkDtCntrlSysIds;
	}

	/**
	 * Gets the office ids.
	 *
	 * @return the office ids
	 */
	public List <String> getOfficeIds() {
		return officeIds;
	}

	/**
	 * Gets the office names.
	 *
	 * @return the office names
	 */
	public List <String> getOfficeNames() {
		return officeNames;
	}

	/**
	 * Gets the office sys ids.
	 *
	 * @return the office sys ids
	 */
	public List <String> getOfficeSysIds() {
		return officeSysIds;
	}

	/**
	 * Gets the office wrk dt cntrl sys ids.
	 *
	 * @return the office wrk dt cntrl sys ids
	 */
	public List <Integer> getOfficeWrkDtCntrlSysIds() {
		return officeWrkDtCntrlSysIds;
	}

	/**
	 * Gets the tech ids.
	 *
	 * @return the tech ids
	 */
	public List <String> getTechIds() {
		return techIds;
	}

	/**
	 * Gets the user sys ids.
	 *
	 * @return the user sys ids
	 */
	public List <String> getUserSysIds() {
		return userSysIds;
	}

	/**
	 * Gets the work dates.
	 *
	 * @return the work dates
	 */
	public List <String> getWorkDates() {
		return workDates;
	}

	/**
	 * Sets the authorized work date statuses.
	 *
	 * @param authorizedWorkDateStatuses the new authorized work date statuses
	 */
	public void setAuthorizedWorkDateStatuses(
			List <String> authorizedWorkDateStatuses) {
		this.authorizedWorkDateStatuses = authorizedWorkDateStatuses;
	}

	/**
	 * Sets the employee wrk dt cntrl sys ids.
	 *
	 * @param employeeWrkDtCntrlSysIds the new employee wrk dt cntrl sys ids
	 */
	public void setEmployeeWrkDtCntrlSysIds(
			List <Integer> employeeWrkDtCntrlSysIds) {
		this.employeeWrkDtCntrlSysIds = employeeWrkDtCntrlSysIds;
	}

	/**
	 * Sets the office ids.
	 *
	 * @param officeIds the new office ids
	 */
	public void setOfficeIds(List <String> officeIds) {
		this.officeIds = officeIds;
	}

	/**
	 * Sets the office names.
	 *
	 * @param officeNames the new office names
	 */
	public void setOfficeNames(List <String> officeNames) {
		this.officeNames = officeNames;
	}

	/**
	 * Sets the office sys ids.
	 *
	 * @param officeSysIds the new office sys ids
	 */
	public void setOfficeSysIds(List <String> officeSysIds) {
		this.officeSysIds = officeSysIds;
	}

	/**
	 * Sets the office wrk dt cntrl sys ids.
	 *
	 * @param officeWrkDtCntrlSysIds the new office wrk dt cntrl sys ids
	 */
	public void setOfficeWrkDtCntrlSysIds(List <Integer> officeWrkDtCntrlSysIds) {
		this.officeWrkDtCntrlSysIds = officeWrkDtCntrlSysIds;
	}

	/**
	 * Sets the tech ids.
	 *
	 * @param techIds the new tech ids
	 */
	public void setTechIds(List <String> techIds) {
		this.techIds = techIds;
	}

	/**
	 * Sets the user sys ids.
	 *
	 * @param userSysIds the new user sys ids
	 */
	public void setUserSysIds(List <String> userSysIds) {
		this.userSysIds = userSysIds;
	}

	/**
	 * Sets the work dates.
	 *
	 * @param workDates the new work dates
	 */
	public void setWorkDates(List <String> workDates) {
		this.workDates = workDates;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("officeWorkDateControlSysId: " + officeWrkDtCntrlSysIds);
		sb.append("employeeWorkDateControlSysId: " + employeeWrkDtCntrlSysIds);
		sb.append("techId: " + techIds);
		sb.append("userSysId: " + userSysIds);
		sb.append("officeId: " + officeIds);
		sb.append("officeSysId:" + officeSysIds);
		sb.append("officeName: " + officeNames);
		sb.append("workDate: " + workDates);
		sb.append("authorizedWorkDateStatus: " + authorizedWorkDateStatuses);
		return sb.toString();
	}
}