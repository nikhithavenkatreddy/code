package gov.ca.dmv.ease.admintool.ui.page.activateworkdate.impl;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

/**
 * Description: 
 * File: $ BrowseLinks.java $
 * Module:  gov.ca.dmv.ease.admintool.ui.page.activateworkdate.impl
 * Created: August 27, 2012
 * @author MWJMF6  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class AdminToolPage {
	private List<SelectItem> selectLinks= new ArrayList<SelectItem>();
	String selectedLink;
	boolean load=true;
	

	public List<SelectItem> getSelectLinks() {
		if(load){
			selectLinks.add(new SelectItem("activateWorkdate.faces","activate work date"));
		    selectLinks.add(new SelectItem("activateWorkdate.faces","location enforcement"));
		    selectLinks.add(new SelectItem("activateWorkdate.faces","other admin tool"));
		}
		load=false;
		return selectLinks;
	}

	public void setSelectLinks(List<SelectItem> selectLinks) {
		this.selectLinks = selectLinks;
	}
	
	public void change1(ValueChangeEvent event) throws IOException{
		selectedLink=(String) event.getNewValue();
		System.out.println(selectedLink);
		FacesContext.getCurrentInstance().getExternalContext().redirect(selectedLink);
	}
}


/**
 *  Modification History:
 * 
 *  $Log: AdminToolPage.java,v $
 *  Revision 1.1  2012/10/18 18:57:53  mwpkc2
 *  Made changes as EASE Portal standards
 *
 *  Revision 1.1  2012/08/30 17:07:00  mwpkc2
 *  Added new project for Work date, location enforcement and other admin tools
 *
 *  Revision 1.1  2012/08/28 18:06:15  mwjmf6
 *  initial commit
 *
 *
 */

 

