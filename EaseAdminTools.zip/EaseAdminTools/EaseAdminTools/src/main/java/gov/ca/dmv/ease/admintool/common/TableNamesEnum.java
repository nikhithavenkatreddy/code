package gov.ca.dmv.ease.admintool.common;

public enum TableNamesEnum {
	//TABLE NAMES
	LOCATION_INFO_TABLE("MWKDB2MV.VSSM059U_LOCATION_INFO"), STATION_INFO_TABLE(
			"MWKDB2MV.VSSM060U_STATION_INFO");
	private String tableName;

	TableNamesEnum(String tableName) {
		this.tableName = tableName;
	}

	public String getTableName() {
		return tableName;
	}
}