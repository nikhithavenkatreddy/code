/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.bo;

/**
 * Description: I am this and that
 * File: InputData.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 17, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class InputData {
	/** The office id. */
	private String officeId;
	/** The tech id. */
	private String techId;

	/**
	 * Gets the office id.
	 *
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 *
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Gets the tech id.
	 *
	 * @return the tech id
	 */
	public String getTechId() {
		return techId;
	}

	/**
	 * Sets the tech id.
	 *
	 * @param techId the new tech id
	 */
	public void setTechId(String techId) {
		this.techId = techId;
	}
}
