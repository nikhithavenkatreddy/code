package gov.ca.dmv.ease.admintool.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;
import gov.ca.dmv.ease.ui.validator.impl.ValidatorBase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: The Class IpAddressValidator 
 * File: IpAddressValidator.java
 * Module:  gov.ca.dmv.ease.admintool.ui.validator.impl
 * Created:  
 * @author   
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/29 16:57:01 $
 * Last Changed By: $Author: mwnrk $
 */
public class IpAddressValidator extends ValidatorBase {
	
	/** The Constant IPADDRESS_PATTERN. */
	private static final String IPADDRESS_PATTERN = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|[0-9][0-9][0-9])$";
	
	/** The Constant ERROR_MESSAGE. */
	private static final String ERROR_MESSAGE = "INVALID IPADDRESS";

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public void validate(FacesContext context, UIComponent component,
			Object value) throws ValidatorException {
		/*IP address that match:
		1. 1.1.1.1, 255.255.255.255, 192.168.1.1,
		2. 10.10.1.1, 132.254.111.10, 26.10.2.10,
		3. 127.0.0.1
	*/
		Pattern pattern = Pattern.compile(IPADDRESS_PATTERN);
		Matcher matcher = pattern.matcher((String) value);
		if (!matcher.matches()) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString(), ERROR_MESSAGE));
		}
	}

}

/**
 *  Modification History:
 *
 *  $Log: IpAddressValidator.java,v $
 *  Revision 1.1  2012/10/29 16:57:01  mwnrk
 *  intial version.
 * 
 *
 */
