/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.criterion.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: I am this and that
 * File: StationCriteria.java
 * Module:  gov.ca.dmv.ease.bo.criterion.impl
 * Created: Oct 17, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/18 18:57:53 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class StationCriteria extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -983048511018470502L;
	
}
