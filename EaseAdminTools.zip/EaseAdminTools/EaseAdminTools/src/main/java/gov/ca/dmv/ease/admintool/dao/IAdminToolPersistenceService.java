package gov.ca.dmv.ease.admintool.dao;

import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.response.impl.SaveLocationAndStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveOfficeResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveWorkDateStatusResponse;
import gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.admin.impl.OfficeWorkdate;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;

import java.util.List;

/**
 * Description: //TODO - provide description!
 * File: IAdminToolPersistenceService.java
 * Module:  gov.ca.dmv.ease.admintool.dao
 * Created: Oct 16, 2012 
 * @author MWPKC2  
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2012/12/21 18:03:50 $
 * Last Changed By: $Author: mwnrk $
 */
public interface IAdminToolPersistenceService {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getEmployeeOfficeDetails(gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	/**
	 * Gets the employee office details.
	 *
	 * @param inputData the input data
	 * @return the employee office details
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetails(
			InputData inputData);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllOffices()
	 */
	/**
	 * Gets the all offices.
	 *
	 * @return the all offices
	 */
	public abstract List <Office> getAllOffices();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getHostOfficesExcept(java.lang.Long)
	 */
	/**
	 * Gets the host offices except.
	 *
	 * @param id the id
	 * @return the host offices except
	 */
	public abstract List <Office> getHostOfficesExcept(Long id);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllStations()
	 */
	/**
	 * Gets the all stations.
	 *
	 * @return the all stations
	 */
	public abstract List <Station> getAllStations();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateWorkDateStatus(java.util.List, boolean)
	 */
	/**
	 * Update work date status.
	 *
	 * @param input the input
	 * @param updateBoth the update both
	 * @return the save work date status response
	 */
	public abstract SaveWorkDateStatusResponse updateWorkDateStatus(
			List <EmployeeWorkdateControl> input, boolean updateBoth);
	
	public abstract SaveWorkDateStatusResponse updateOfficeWorkDateStatus(
			List <OfficeWorkdate> input);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addLocationAndStationDetails(gov.ca.dmv.ease.bo.app.impl.Location)
	 */
	/**
	 * Adds the location and station details.
	 *
	 * @param input the input
	 * @return the save location and station response
	 */
	public abstract SaveLocationAndStationResponse addLocationAndStationDetails(
			Location input);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getStationInfoByOfficeId(java.lang.String)
	 */
	/**
	 * Gets the station info by office id.
	 *
	 * @param officeId the office id
	 * @return the station info by office id
	 */
	public abstract List <Station> getStationInfoByOfficeId(String officeId);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#doesStationExist(java.lang.String)
	 */
	/**
	 * Does station exist.
	 *
	 * @param stationSysId the station sys id
	 * @return true, if successful
	 */
	public abstract boolean doesStationExist(String stationSysId);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addStationInfo(gov.ca.dmv.ease.bo.app.impl.Station)
	 */
	/**
	 * Adds the station info.
	 *
	 * @param input the input
	 * @return the save station response
	 */
	public abstract SaveStationResponse addStationInfo(Station input);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addOffice(gov.ca.dmv.ease.bo.admin.impl.Office)
	 */
	/**
	 * Adds the office.
	 *
	 * @param newOffice the new office
	 * @return the save office response
	 */
	public abstract SaveOfficeResponse addOffice(Office newOffice);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getEmployeeOfficeDetailsByOfficeId(gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	/**
	 * Gets the employee office details by office id.
	 *
	 * @param input the input
	 * @return the employee office details by office id
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetailsByOfficeId(
			InputData input);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getHostOffices()
	 */
	/**
	 * Gets the host offices.
	 *
	 * @return the host offices
	 */
	public abstract List <Office> getHostOffices();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getSatelliteOffices()
	 */
	/**
	 * Gets the satellite offices.
	 *
	 * @return the satellite offices
	 */
	public abstract List <Office> getSatelliteOffices();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateSatelliteOfficeIndicator(gov.ca.dmv.ease.bo.admin.impl.Office, java.lang.Long)
	 */
	/**
	 * Update satellite office indicator.
	 *
	 * @param targetOffice the target office
	 * @param satelliteOfficeSysId the satellite office sys id
	 * @return the save office response
	 */
	public abstract SaveOfficeResponse updateSatelliteOfficeIndicator(
			Office targetOffice, Long satelliteOfficeSysId);

	/**
	 * Update office indicator to n.
	 *
	 * @param targetOffice the target office
	 * @param indicator the indicator
	 * @return the save office response
	 */
	public abstract SaveOfficeResponse updateOfficeIndicatorToN(Office targetOffice,
			String indicator);

	/**
	 * Checks if is ip address existed.
	 *
	 * @param ipAddress the ip address
	 * @return true, if is ip address existed
	 */
	public abstract boolean isIpAddressExisted(String ipAddress);
	
	/**
	 * Checks if is new station id existed.
	 *
	 * @param newStationId the new station id
	 * @return true, if is new station id existed
	 */
	public abstract boolean isNewStationIdExisted(String newStationId);


	/**
	 * Gets the station and location info.
	 *
	 * @param id the id
	 * @return the station and location info
	 */
	public abstract  StationAndLocationInfo getStationAndLocationInfo(String id);

	/**
	 * Update station and location info.
	 *
	 * @param info the info
	 * @return the save location and station response
	 */
	public abstract SaveLocationAndStationResponse updateStationAndLocationInfo(StationAndLocationInfo info);

	/**
	 * Gets the station by id test.
	 *
	 * @param stationId the station id
	 * @return the station by id test
	 */
	public abstract Station getStationByIdTest(String stationId);

	public StationAndLocationInfo lookupIpAddress(String ipAddress);
	
}
/**
 *  Modification History:
 *
 *  $Log: IAdminToolPersistenceService.java,v $
 *  Revision 1.10  2012/12/21 18:03:50  mwnrk
 *  Modified file.
 * 
 *
 */