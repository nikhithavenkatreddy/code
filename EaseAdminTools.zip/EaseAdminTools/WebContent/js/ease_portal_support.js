/* Scripts for integration with Ease Portal.
 * Supports refocus on the last focused element.
 * Supports updating the EasePortal page title when this page reloads.
 * Supports help page functionality by setting a 'document.pageName' variable.
 * Supports logout prevention (pages that allow log out should set isLogOffAllowed to true).
 * Supports auto-submit of Set Mode and Who For pages, if these pages have been submitted already in another app
 * Depends on JQuery. Import of JQuery library should be before the import of this file. 
 * Tested to be compatible with Firefox 3.x, IceWeasel 3.0 and Internet Explorer 8.
 */
var isLogOffAllowed = true; // can be overwritten page-by-page
var focusedElement = document;
// called by EasePortal when this page's tab is clicked
function refocus() {
	if (focusedElement.focus) {
       	setTimeout("focusedElement.focus()", 300);
    }
}

$(function() {
	$(':input').bind('focus', function(e) {focusedElement = e.target; });
	document.pageName = getPageName();
	if (top != self) { 
		if (top.handleFrameLoad) {			
			top.handleFrameLoad(this);
		}
	}
});

$(document).ready(function () {	
	if (top != self) {
		if (top.modeData &&  getPageName() == 'modeSelection') {
			handleModeDataLoad();
			$("#MAIN_FORM").submit(handleModeDataSubmit);
		} else if (top.whoForData && getPageName() == 'whoForPage') {
			handleWhoForDataLoad();
			$("#MAIN_FORM").submit(handleWhoForDataSubmit);
		}
	}
});

function handleModeDataLoad() {
	if (getPageName() == 'modeSelection') {
		if (top.modeData.isAllDataPresent()) {
			if (top.modeData.lastTouchedBy != self) {
				$("#MAIN_FORM:officeId").val(top.modeData.officeId);
				$("#MAIN_FORM:operationalMode").val(top.modeData.operationalMode);
				$("#MAIN_FORM:functionalMode").val(top.modeData.functionalMode);
				$("#MAIN_FORM:workDate").val(top.modeData.workDate);
				setInterval(function() { $('#MAIN_FORM:button1').trigger('click'); }, 200);
			} else { // this case when the setMode page reloads due to validation error
				top.modeData.officeId = null;
				top.modeData.operationalMode = null;
				top.modeData.functionalMode = null;
				top.modeData.workDate = null;
			}
		}
		top.modeData.lastTouchedBy = self;
	}
	return true;
}

function handleModeDataSubmit() {
	top.modeData.officeId = $("#MAIN_FORM:officeId").val();
	top.modeData.operationalMode = $("#MAIN_FORM:operationalMode").val();
	top.modeData.functionalMode = $("#MAIN_FORM:functionalMode").val();
	top.modeData.workDate = $("#MAIN_FORM:workDate").val();
	top.modeData.lastTouchedBy = self;
}

function handleWhoForDataLoad() {
	if (getPageName() == 'whoForPage') {
		if (top.whoForData.isAllDataPresent()) {
			if (top.whoForData.lastTouchedBy != self) {
				if (isPresent(top.whoForData.officeId)) {
					$("#MAIN_FORM:officeId").val(top.whoForData.officeId);
				}
				if (isPresent(top.whoForData.keyingForEmployeeId)) {
					$("#MAIN_FORM:keyingForEmployeeId").val(top.whoForData.keyingForEmployeeId);
				}
				if (isPresent(top.whoForData.keyingForWorkdate)) {
					$("#MAIN_FORM:keyingForWorkdate").val(top.whoForData.keyingForWorkdate);
				}
				setInterval(function() { $('#MAIN_FORM:button1').trigger('click'); }, 200);
			} else { // this case when the whoFor page reloads due to validation error
				top.whoForData.officeId = null;
				top.whoForData.keyingForEmployeeId = null;
				top.whoForData.keyingForWorkdate = null;
			}
		}
	}
	top.whoForData.lastTouchedBy = self;
	return true;
}

function handleWhoForDataSubmit() {
	top.whoForData.officeId = $("#MAIN_FORM:officeId").val();
	top.whoForData.keyingForEmployeeId = $("#MAIN_FORM:keyingForEmployeeId").val();
	top.whoForData.keyingForWorkdate = $("#MAIN_FORM:keyingForWorkdate").val();
	top.whoForData.lastTouchedBy == self;
}

function isPresent(value) {
	return !(value == null || value == '');
}

function getPageName() {
	return $('#MAIN_FORM\\:PageName').val();
}