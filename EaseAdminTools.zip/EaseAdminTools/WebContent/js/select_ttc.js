
//When you select the TTC from the menu then auto submit the page.
function selectTtc(ttc, index){
	document.getElementById("MAIN_FORM:child-" + index).style.visibility = "visible";
	document.getElementById("MAIN_FORM:child-" + index).style.display = "block";
	document.getElementById("MAIN_FORM:typeTransactionCode").value = ttc;
	document.getElementById("MAIN_FORM:button1").click();
}