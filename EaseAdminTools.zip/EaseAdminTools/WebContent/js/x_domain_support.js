// start X-domain functions ///////////

// Version of notifyTop that works across domains
function notifyTopOnLoadXDomain() {
   if (typeof window.postMessage != "undefined") { 
       top.postMessage("syncSessions", "*"); 
   } else {
      // x-domain communication hack for older browsers
	  // on first page load the local url should include the top url after the hash  
	  var topUrl = readCookie("topUrl");
	  if (topUrl == null) {
         topUrl = self.document.location.hash.substring(1);
		 createCookie("topUrl", topUrl);	 
	  }
	  top.location.href = topUrl + "#" + new Date().getTime();
   }
}

var cookieLife = 5; // seconds
function handleLogoutPrevention() {
	// only need to do this if in an x-domain situation and if 'isLogOffAllowed' is defined
	if (top != self && typeof isLogOffAllowed != "undefined") {
	   try {
	      // throws exception if cross-domain situation is encountered
	      top.logOffAllowed;
	   } catch (err) {
	      createCookie("isLogOffAllowed", isLogOffAllowed, cookieLife);
	      // In effect, the cookie stays alive as long as this page exists, 
	      // but expires within a few seconds after the page is gone
	      setInterval("manageLogOffCookie()", cookieLife * 1000);
	   }
	}
}

function manageLogOffCookie() {
   createCookie("isLogOffAllowed",isLogOffAllowed,cookieLife);
}


if (window.addEventListener) { window.addEventListener("message", receiveMessage, false); }
// receives messages from other windows via postMessage calls   
function receiveMessage(event) {   
  if (event.data == "logOutRequest" && typeof isLogOffAllowed != "undefined") {
     event.source.postMessage("isLogOffAllowed=" + isLogOffAllowed + "," + window.name, event.origin);
  }   
} 

//window.onunload = function() {
	//createCookie("isLogOffAllowed", "true", cookieLife);
//}

// end X-domain functions ///////////

/////////////////////// cookie utils //////////////////
//returns the value of a URL parameter
function readParam( name ) {
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return results[1];
}

function createCookie(name,value,seconds) {
	if (seconds) {
		var date = new Date();
		date.setTime(date.getTime()+(seconds*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}
////////////////////////////////////////////////////////////