/*UnCheck the previous radio buttons selected and Check the new radio button and HiLight it.*/
function radioButton(radio) {
	var id = radio.name.substring(radio.name.lastIndexOf(':'));
	var row = radio.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	var rows = document.getElementById('MAIN_FORM:dt1').getElementsByTagName(
			'TR');

	var el = radio.form.elements;
	for ( var i = 0; i < el.length; i++) {
		if (el[i].name.substring(el[i].name.lastIndexOf(':')) == id) {
			el[i].checked = false;
		}
	}
	// reset all the rows to default CSS(ROW1,ROW2)
	for ( var j = 1; j < rows.length; j++) {
		if (rows[j].rowIndex % 2 == 0) {
			rows[j].className = "ROW2";
		} else {
			rows[j].className = "ROW1";
		}
	}

	radio.checked = true;
	// HiLight the one selected
	row.className = "rowHighlighted";
}

// Check whether at least one radio button selected or not
function radioButtonSelected(radio) {

	var element = document.getElementById('MAIN_FORM:dt1')
			.getElementsByTagName('input');
	var count = 0;
	for ( var i = 0; i < element.length; i++) {

		if (element[i].getAttribute('type') == 'radio') {
			if (element[i].checked)
				count++;
		}
	}
	if (count == 0) {
		alert("Please select OfficeId");
		return false;
	}
	return true;
}

function selectDropDown(select) {
	var rows = document.getElementById('MAIN_FORM:dt1').getElementsByTagName(
			'select');
	var count = 0;

	for ( var i = 0; i < rows.length; i++) {
		var text = rows[i].options[rows[i].selectedIndex].text;
		if (text != 'SELECT') {
			count++;
		}
	}
	if (count == 0) {
		alert("PLEASE SELECT AN OPTION");
		return false;
	}
	return true;
}

function reSize(selectBox){
	
	var rows = document.getElementById('MAIN_FORM:dt1').getElementsByTagName(
	'select');
	
	for ( var i = 0; i < rows.length; i++) 
		  rows[i].width="100px";
	
}


function confirmation(element) {
	var selectedValue = element.options[element.selectedIndex].text;
	var answer;
	//alert("selectedValue:"+selectedValue)
	if (selectedValue == 'ACTIVATE')
		answer = confirm("Are you sure you want to Activate?");
	else if(selectedValue == 'TRANSMIT NOW')
		answer = confirm("Are you sure you want to Transmit Now?");
	else 
		document.forms["MAIN_FORM"].submit();
	//else if(selectedValue == 'UNBALANCE OFFICE')
	//	answer=confirm("Are you sure you want to un balance the Office?");
		
	if (answer) {
		document.forms["MAIN_FORM"].submit();
	}
	document.forms["MAIN_FORM"].reset();
	return false;
}

function confirmAuth(){
	answer = confirm("Are you sure you want to Authorize all?");
	if (answer) 
		document.forms["MAIN_FORM"].submit();
	
}


// Highlighting or unHighlighting the all the rows when Check or unCheck the
// header check box
function selectAll(checkbox, page) {
	var count = 0;
	// alert("inside selectALL");
	var elements = document.getElementById('MAIN_FORM:dt1')
			.getElementsByTagName('input');
	// alert(elements.length);
	for ( var i = 0; i < elements.length; i++) {
		var element = elements[i];
		if (element.getAttribute('type') == 'checkbox') {
			element.checked = checkbox.checked;
			count++;
			if (checkbox.checked) {
				if (count > 1)
					hiLightAllCheckBox(element);
				disableButtons(page);

			} else {
				if (count > 1)
					unHiLightAllCheckBox(element);
				enableButtons(page);
			}
		}
	}
}

// Disable the buttons when more than one check boxe selected
function disableButtons(page) {
	var node_list = document.getElementById('panelGrid_command')
			.getElementsByTagName('input');
	for ( var i = 0; i < node_list.length; i++) {
		// alert(node_list[i]);
		var node = node_list[i];
		// alert(node.getAttribute('type'));
		if (node.getAttribute('type') == 'submit') {
			// If page is BrowseWorkDate then disable all buttons except ACTIVE.
			if (page == 'workdate') {
				if (node.getAttribute('value') != 'ACTIVATE')
					node.disabled = true;
				// If page is BrowseEmployee then disable all buttons except
				// AUTHORIZE.
			} else if (page == 'employee') {
				if (node.getAttribute('value') != 'AUTHORIZE')
					node.disabled = true;
			}
		}
	}
}

// Enable the buttons when unselect the check boxes
function enableButtons(page) {
	var node_list = document.getElementById('panelGrid_command')
			.getElementsByTagName('input');
	for ( var i = 0; i < node_list.length; i++) {
		// alert(node_list[i]);
		var node = node_list[i];
		// alert(node.getAttribute('type'));
		if (node.getAttribute('type') == 'submit') {
			node.disabled = false;
		}
	}
}

// HiLight the row check boxes
function hiLightAllCheckBox(element) {
	var row = element.parentNode.parentNode;
	row.className = "rowHighlighted";
}

// unHighLighting the row when un-check the check box and
// applying default CSS.
function unHiLightAllCheckBox(element) {
	var row = element.parentNode.parentNode;

	if (row.rowIndex % 2 == 0) {
		row.className = "ROW2";
	} else {
		row.className = "ROW1";
	}
}

// count the check boxes count to pop-up alert messages
function countcheckbox(checkbox) {
	var count = 0;
	var elements = checkbox.form.elements;
	for ( var i = 0; i < elements.length; i++) {
		var element = elements[i];
		// alert(element+" "+element.id);
		if (/CheckBox$/.test(element.id)) {
			if (element.checked == true) {
				count++;
			}
		}
	}

	if (count > 1) {
		alert("PLEASE SELECT ONLY ONE ROW");
		/*
		 * for (i = 0; i < elements.length; i++) { element = elements[i]; if
		 * (/CheckBox$/.test(element.id)) { element.checked=false; } }
		 */
		return false;
	}
	if (count == 0) {
		alert("PLEASE SELECT ONE ROW");
		return false;
	}
	return true;
}

// HiLight or UnHiLight a row when checked or unchecked row check box
function hiLightCheckBox(checkBox, page) {

	var row = checkBox.parentNode.parentNode;

	if (row.className == "rowHighlighted") {
		if (row.rowIndex % 2 == 0) {
			row.className = "ROW2";
		} else {
			row.className = "ROW1";
		}

	} else {
		row.className = "rowHighlighted";
	}
	/*
	 * If more than one check box selected disable the buttons except ACTIVE
	 * button. if check boxes disabled individually then check number of checked
	 * is one then enable all the buttons disabled.
	 */
	if (countRowsChecked() > 1) {
		disableButtons(page);
	} else
		enableButtons(page);
}

// Count the number of check boxes selected
function countRowsChecked() {
	var elements = document.getElementById('MAIN_FORM:dt1')
			.getElementsByTagName('input');
	var count = 0;
	for ( var i = 0; i < elements.length; i++) {
		var element = elements[i];
		if (element.getAttribute('type') == 'checkbox') {
			if (element.checked)
				count++;
		}
	}
	return count;
}


function hilightRow(){
   //alert("Inside");
	var rows = document.getElementById('MAIN_FORM:dt1').getElementsByTagName('TR');
	//alert(rows.length);
	for(var i=0;i<rows.length;i++){
		var e=document.getElementById('MAIN_FORM:dt1:'+i+':item1date');
		
		if(e.innerHTML=='*'){
			 hilightTD(rows[i+1]);
		}	
	}
}

function hilightTD(row){
	    var tds=row.getElementsByTagName("span");
		for(var i=0;i<tds.length;i++){
			     tds[i].className="hilightTD";
		}
}
