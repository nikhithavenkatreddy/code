//This function allows only numbers for the numeric field, can be used for fee or amount related field validations.
function allowNumbers(event) {
	var theEvent = event || window.event;
	var keyCode = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(keyCode);
	if (keyCode == 8 || keyCode == 45 || keyCode == 46 || keyCode == 37
			|| keyCode == 39 || keyCode == 36 || keyCode == 190
			|| keyCode == 109 || keyCode == 189 || keyCode == 9
			|| keyCode == 13) {
		return true;
	}
	if (keyCode > 31 && (keyCode < 48 || keyCode > 57)) {
		return false;
	}
	return true;
}