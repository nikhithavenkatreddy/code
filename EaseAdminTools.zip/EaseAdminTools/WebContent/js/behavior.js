var isNN = (navigator.appName.indexOf("Netscape") != -1); 
var formName = "MAIN_FORM:";

function enableDisable(input, target, list,onload){	
	if (input.type == "text" || input.type == "textarea" || input.type == "password"){
		if(input.value == null || input.value == "")
			disable(list, target,onload);
		else
			enable(list, target,onload);
	}
	else if(input.type == 'checkbox'){
		if(input.checked)
			enable(list, target,onload);
		else
			disable(list, target, onload);
	}
}
//Set focus to the input field
function setFocusElement(){
		document.getElementById("MAIN_FORM:"+$("#focusField").val()).focus();
}
function enable(list, target, onload){
	if(list != null){
		var listValue=  list.split(",");
		for(var i = 0; i < listValue.length; i++){
			if(!onload){
				document.getElementById(formName+listValue[i]).value = "";
			}
			document.getElementById(formName+listValue[i]).disabled = false;
			document.getElementById(formName+listValue[i]).readonly = false;
		}
	} else {
		if(!onload){
			document.getElementById(formName+target).value = "";
		}
		document.getElementById(formName+target).disabled = false;
		document.getElementById(formName+target).readonly = false;
	}
}

function disable(list, target, onload){
	if(list != null){
		var listValue=  list.split(",");
		for(var i = 0; i < listValue.length; i++){
			if(!onload){
				document.getElementById(formName+listValue[i]).value = "";
			}
			document.getElementById(formName+listValue[i]).disabled = true;
			document.getElementById(formName+listValue[i]).readonly = true;
		}
	} else {
		if(!onload){
			document.getElementById(formName+target).value = "";
		}
		document.getElementById(formName+target).disabled = true;
		document.getElementById(formName+target).readonly = true;
	}
}

function visibleHidden(input, target, list, onload){	
	setNextFocus(input);
}

function check(list, target, input, onload){}

function contains(a, obj){
	  for(var i = 0; i < a.length; i++) {
	    if(a[i] === obj.toUpperCase()){
	      return true;
	    }
	  }
	  return false;
}

function visible(list, target, onload){
	if(list != null){
		var listValue=  list.split(",");
		for(var i = 0; i < listValue.length; i++){
			var nval = document.getElementById(formName+listValue[i]);
			try{
				children = document.getElementById(formName+listValue[i]).childNodes;
				if(!onload){
					children[0].value= "";
				}
			}catch(err){
					
			}
			$('.'+listValue[i].trim()+'Style').show();			
		}
	} else {
		if(!onload){
			document.getElementById(formName+target).value = "";
		}
		$('.'+target.trim()+'Style').hide();		
	}
}

function hidden(list, target, onload){
	if(list != null){
		var listValue=  list.split(",");
		for(var i = 0; i < listValue.length; i++){
			try{
				var children1 = document.getElementById(formName + listValue[i]).childNodes;
				children = document.getElementById(formName + listValue[i]);
				if(!onload){
					// We need to verify children1 is required or not and delete
					// if it is not needed
					if(children1 != null && children1[0] != null && children1[0] != undefined) {
						children1[0].value= "";
					}
					if(children != null) {
						children.value = "";
					}
				}
			}catch(err){				
			}
			$('.'+listValue[i].trim()+'Style').hide();			
		}
	} else {
		if(!onload){// onload parameter is to know is the method is calling from
					// ready function or on change function.
			document.getElementById(formName+target).value = "";
		}
		$('.'+target.trim()+'Style').hide();		
	}
}

function preloadHiddenFields(copyFromList, copyToList){
	if((copyFromList != null)&&(copyToList != null)){
		var fromListValue = copyFromList.split(",");
		var toListValue = copyToList.split(",");
		if(fromListValue.length==toListValue.length){
			for(var i = 0; i < fromListValue.length; i++){
				var toval = document.getElementById(formName+toListValue[i]);
				if(toval.value==""){
					toval.value=document.getElementById(formName+fromListValue[i]).value;
				}
			}
		}
	}
}

function setNextFocus(input) {
	index = getIndex(input);
	nextElement = input.form[index % input.form.length];
	var focusElement = getFocusElement(nextElement, index);
	if(isFocus(focusElement))
		focusElement.focus();
	else
		focusElement.select();
}

function getIndex(input) {
	var index = -1, i = 0;
    while (i < input.form.length && index == -1){
    	if (input.form[i] == input){
    		index = i + 1;
    		for (index; index < input.form.length; index++){
    			if(isInputType(input, index))
    				return index;
    		}
    	}
    	else 
    		i++;
    }
    return index;
}

function isInputType(input, index){
	var inputType = input.form[index].type;
	if (inputType == "text" || inputType == "select-one" || inputType == "textarea" || inputType == "button" || 
			inputType == "select" || inputType == "checkbox" ||	inputType == "radio" || inputType == "submit" || 
			inputType == "reset" || inputType == "password")
		return true;
	return false;
}

function isFocus(focusElement){
	if(focusElement.value == null || focusElement.value == ''
		|| focusElement.type == "button" || focusElement.type == "submit" || focusElement.type == "checkbox")
		return true;
	else
		false;
	return false;
}

function getFocusElement(input, index){
	if(input.id.indexOf("_HXB_GHOST") != -1 || 
			input.id.indexOf("_HXB_HPBTN") != -1 ){
		index = index + 1;
		for (index; index < input.form.length; index++){
			if(isInputType(input, index)){
				return input.form[index % input.form.length];
			}
		}
	}
	else{
		return input.form[index % input.form.length];
	}
	return null;
}
function manageVrSearchFieldsWithVinOrHin() {
	var vinOrHin = $("#MAIN_FORM:vinOrHin").val();
	vinOrHin = vinOrHin.replace(/^\s+|\s+$/g, ''); // trim
	var vRSearchFields = ["generateVinOrHin","licenseNumber","lastThreePosVin","fileCode","licensePlate","","engineNumber"];
	if(vinOrHin != "") {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).val("");
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', true);

		} 
		
	}
	else {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', false);
		}
	}

}

function manageVrSearchFieldsWithEngine() {
	var engineNumber = $("#MAIN_FORM:engineNumber").val();
	engineNumber = engineNumber.replace(/^\s+|\s+$/g, ''); // trim
	var vRSearchFields = ["generateVinOrHin","fileCode","licensePlate"];
	if(engineNumber != "") {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).val("");
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', true);

		} 
		
	} else {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', false);
		}
	}
}

function manageVrSearchFieldsWithPlate() {
	var licensePlate = $("#MAIN_FORM:licensePlate").val();
	licensePlate = licensePlate.replace(/^\s+|\s+$/g, ''); // trim
	var vRSearchFields = ["vinOrHin","vin","makeOrBuilder","make","engineNumber"];
	if(licensePlate != "") {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).val("");
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', true);

		} 
		
	} else {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', false);
		}
	}
	
	
}
function manageVrSearchFieldsWithLicense() {
	var licenseNumber= $("#MAIN_FORM:licenseNumber").val();
	licenseNumber = licenseNumber.replace(/^\s+|\s+$/g, ''); // trim
	var vRSearchFields = ["dateFeeReceived","amountToBePosted","vin","cashAmount","make","engineNumber","pwoLicenseNumber","pwoFileCode","dateFirstOperated","checkAmount","dealerNumber","derNumber","otherPayments"];
	if(licenseNumber != "") {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).val("");
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', true);

		} 
		
	} 
	else {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', false);
		}
	}
}
function manageVrSearchFieldsWithVin(){
	var vin= $("#MAIN_FORM:vin").val();
	vin = vin.replace(/^\s+|\s+$/g, ''); // trim
	var vRSearchFields = ["generateVinOrHin","licenseNumber","lastThreePosVin","fileCode","licensePlate","","engineNumber"];
	if(vin != "") {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).val("");
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', true);

		} 
		
	} 
	else {
		for ( i=0; i < vRSearchFields.length; i++ ) {
			$("#MAIN_FORM:" + vRSearchFields[i]).attr('disabled', false);
		}
	}
}

