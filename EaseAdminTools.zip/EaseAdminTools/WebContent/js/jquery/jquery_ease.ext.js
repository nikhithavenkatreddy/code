/*
 * jQuery extensions for the EASE project
 * 
 * Extensions:
 *   suggest: provides a suggest window for input text fields
 *  
 */
$.fn.extend({
	suggest: function(data, options) {
		options = $.extend({}, $.Suggest.defaults, {
			data: data,  
			maxItems: options.scroll ? 10 : 150
		}, options);
		
		return this.each(function() {
			new $.Suggest(this, options);
		});
	}
});
var formName = "MAIN_FORM:";

$.Suggest = function(input, options) {

	var KEY = {UP: 38, DOWN: 40, DEL: 46, TAB: 9, RETURN: 13, ESC: 27, COMMA: 188, PAGEUP: 33, PAGEDOWN: 34, BACKSPACE: 8 };

	var $input = $(input).attr("autocomplete", "off");

	var timeout;
	var previousValue = "";
	var cache = $.Suggest.Cache(options);
	var hasFocus = 0;
	var lastKeyPressCode;
	var mouseDownOnSelect = false;
	var select = $.Suggest.Select(options, input, selectCurrent);
	var blockSubmit;
	
	// Opera - prevent form submit with return key
	$.browser.opera && $(input.form).bind("submit.autocomplete", function() {
		if (blockSubmit) {
			blockSubmit = false;
			return false;
		}
	});
	
	// Opera doesn't trigger keydown multiple times while pressed
	$input.bind(($.browser.opera ? "keypress" : "keydown") + ".autocomplete", function(event) {
		hasFocus = 1;
		lastKeyPressCode = event.keyCode;
		switch(event.keyCode) {
		
			case KEY.UP:
				event.preventDefault();
				if ( select.visible() ) {
					select.prev();
				} else {
					onChange(0, true);
				}
				break;
				
			case KEY.DOWN:
				event.preventDefault();
				if ( select.visible() ) {
					select.next();
				} else {
					onChange(0, true);
				}
				break;
				
			case KEY.PAGEUP:
				event.preventDefault();
				if ( select.visible() ) {
					select.pageUp();
				} else {
					onChange(0, true);
				}
				break;
				
			case KEY.PAGEDOWN:
				event.preventDefault();
				if ( select.visible() ) {
					select.pageDown();
				} else {
					onChange(0, true);
				}
				break;
			
			case KEY.TAB:
			case KEY.RETURN:
				if( selectCurrent() ) {
					event.preventDefault();
					blockSubmit = true;
					return false;
				}
				break;
				
			case KEY.ESC:
				select.hide();
				break;
				
			default:
				clearTimeout(timeout);
				timeout = setTimeout(onChange, 10);
				break;
		}
	}).focus(function(){
		hasFocus++;
	}).blur(function() {
		hasFocus = 0;
		if (!mouseDownOnSelect) {
			hideResults();
		}
	}).click(function() {
		// Show select when clicking in a focused field
		if ( hasFocus++ > 1 && !select.visible() ) {
			onChange(0, true);
		}
	});
	
	function selectCurrent() {
		var selected = select.selected();
		if( !selected ) {
			return false;
		}
		var value = selected.value;
		previousValue = value;
		
		$input.val(value);
		hideResultsNow();
		$input.trigger("result", [selected.data, selected.value]);
		return true;
	}

	function onChange(crap, skipPrevCheck) {
		/*if( lastKeyPressCode == KEY.DEL ) {
			select.hide();
			return;
		}*/
		
		var currentValue = $input.val();
		
		if ( !skipPrevCheck && currentValue == previousValue )
			return;
		
		previousValue = currentValue;
		
		if ( currentValue.length >= options.minChars) {
			$input.addClass(options.loadingClass);
			if (!options.matchCase)
				currentValue = currentValue.toLowerCase();
			request(currentValue, receiveData, hideResultsNow);
		} else {
			stopLoading();
			select.hide();
		}
	};
	
	function hideResults() {
		clearTimeout(timeout);
		timeout = setTimeout(hideResultsNow, 200);
	};

	function hideResultsNow() {
		var wasVisible = select.visible();
		select.hide();
		clearTimeout(timeout);
		stopLoading();
	};

	function receiveData(q, data) {
		if ( data && data.length && hasFocus ) {
			stopLoading();
			select.display(data, q);
			select.show();
		} else {
			hideResultsNow();
		}
	};

	function request(term, success, failure) {
		if (!options.matchCase)
			term = term.toLowerCase();
		var data = cache.load(term);
		if (data && data.length) {
			success(term, data); // It's receiveData()
		} else {
			// Failure to empty the list, to prevent the the [TAB] key from selecting the last successful match
			select.emptyList();
			failure(term);
		}
	};
	
	function parse(data) {
		var parsed = [];
		var rows = data.split("\n");
		for (var i=0; i < rows.length; i++) {
			var row = $.trim(rows[i]);
			if (row) {
				row = row.split("|");
				parsed[parsed.length] = {
					data: row,
					value: row[0],
					result: options.formatResult && options.formatResult(row, row[0]) || row[0]
				};
			}
		}
		return parsed;
	};

	function stopLoading() {
		$input.removeClass(options.loadingClass);
	};

};

$.Suggest.defaults = {
	resultsClass: "suggest-results",
	loadingClass: "suggest-loading",
	minChars: 1,
	matchCase: false,
	cacheLength: 10,
	selectFirst: false,
	formatItem: function(row) { return row; },
	width: 0,
	highlight: true,
    scroll: true,
    scrollHeight: 180
};

$.Suggest.Cache = function(options) {

	// Leave the cache here for future use with Ajax 
	var data = options.data;
	var length = data.length;
	
	function matchSubset(s, sub) {
		if (!options.matchCase) 
			s = s.toLowerCase();
		/*var i = s.indexOf(sub);
		if (i == -1) return false;
		return true;*/
		if(s.startsWith(sub))
			return true;
		return false;
	};
	
	function add(q, value) {
		if (length > options.cacheLength){
			flush();
		}
		if (!data[q]){ 
			length++;
		}
		data[q] = value;
	}
	
	function flush(){
		data = {};
		length = 0;
	}
	
	return {
		flush: flush,
		add: add,
		load: function(q) {
			if (!options.cacheLength || !length) {
				return null;
			}
			// track all matches
			var csub = [];
			for (var k = 0; k < data.length; k++) {
				if (matchSubset(data[k].value, q)) {
					csub.push(data[k]);
				}
			}
			return csub;
		}
	};
};

$.Suggest.Select = function (options, input, select) {
	var classOver = "over";
	
	var listItems,
		active = -1,
		data,
		term = "",
		needsInit = true,
		element,
		list;
	
	// Create results
	function init() {
		if (!needsInit)
			return;
		element = $("<div/>").hide().addClass(options.resultsClass).css("position", "absolute").appendTo(document.body);
	
		list = $("<ul/>").appendTo(element).mouseover( function(event) {
			if(target(event).nodeName && target(event).nodeName.toUpperCase() == 'LI') {
	            active = $("li", list).removeClass(classOver).index(target(event));
			    $(target(event)).addClass(classOver);            
	        }
		}).click(function(event) {
			$(target(event)).addClass(classOver);
			select();
			setNextFocus(input);
			return false;
		}).mousedown(function() {
			mouseDownOnSelect = true;
		}).mouseup(function() {
			mouseDownOnSelect = false;
		});
		
		if( options.width > 0 )
			element.css("width", options.width);
			
		needsInit = false;
	} 
	
	function target(event) {
		var element = event.target;
		while(element && element.tagName != "LI") {
			element = element.parentNode;
		}
		// For IE, sometimes event.target is empty, ignore it
		if(!element)
			return [];
		return element;
	}

	function moveSelect(step) {
		listItems.slice(active, active + 1).removeClass(classOver);
		movePosition(step);
        var activeItem = listItems.slice(active, active + 1).addClass(classOver);
        if(options.scroll) {
            var offset = 0;
            listItems.slice(0, active).each(function() {
				offset += this.offsetHeight;
			});
            if((offset + activeItem[0].offsetHeight - list.scrollTop()) > list[0].clientHeight) {
                list.scrollTop(offset + activeItem[0].offsetHeight - list.innerHeight());
            } else if(offset < list.scrollTop()) {
                list.scrollTop(offset);
            }
        }
	};
	
	function movePosition(step) {
		active += step;
		if (active < 0) {
			active = listItems.size() - 1;
		} else if (active >= listItems.size()) {
			active = 0;
		}
	}
	
	function limitNumberOfItems(available) {
		return options.maxItems && options.maxItems < available
			? options.maxItems
			: available;
	}
	
	function fillList() {
		list.empty();
		var max = limitNumberOfItems(data.length);
		for (var i=0; i < max; i++) {
			if (!data[i]) {
				continue;
			}
			var formatted = options.formatItem(data[i].data);
			if ( formatted === false ) {
				continue;
			}
			if (options.highlight) {
				formatted = highlight(formatted, term);
			}
			var li = $("<li/>").html(formatted).addClass(i%2 == 0 ? "even" : "odd").appendTo(list)[0];
			$.data(li, "suggest_data", data[i]);
		}
		listItems = list.find("li");
		if ( options.selectFirst ) {
			listItems.slice(0, 1).addClass(classOver);
			active = 0;
		}
	}
	
	function highlight(value, term) {
		return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term.replace(/([\^\$\(\)\[\]\{\}\*\.\+\?\|\\])/gi, "\\$1") + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>");
	}
	return {
		display: function(d, q) {
			init();
			data = d;
			term = q;
			fillList();
		},
		next: function() {
			moveSelect(1);
		},
		prev: function() {
			moveSelect(-1);
		},
		pageUp: function() {
			if (active != 0 && active - 8 < 0) {
				moveSelect( -active );
			} else {
				moveSelect(-8);
			}
		},
		pageDown: function() {
			if (active != listItems.size() - 1 && active + 8 > listItems.size()) {
				moveSelect( listItems.size() - 1 - active );
			} else {
				moveSelect(8);
			}
		},
		hide: function() {
			element && element.hide();
			listItems && listItems.removeClass(classOver);
			active = -1;
		},
		visible : function() {
			return element && element.is(":visible");
		},
		current: function() {
			return this.visible() && (listItems.filter("." + classOver)[0] || options.selectFirst && listItems[0]);
		},
		show: function() {
			var offset = $(input).offset();
			element.css({
				width: typeof options.width == "string" || options.width > 0 ? options.width : $(input).width(),
				top: offset.top + input.offsetHeight,
				left: offset.left
			}).show();
            if(options.scroll) {
                list.scrollTop(0);
                list.css({
					maxHeight: options.scrollHeight,
					overflow: 'auto'
				});
				
                if($.browser.msie && typeof document.body.style.maxHeight === "undefined") {
					var listHeight = 0;
					listItems.each(function() {
						listHeight += this.offsetHeight;
					});
					var scrollbarsVisible = listHeight > options.scrollHeight;
                    list.css('height', scrollbarsVisible ? options.scrollHeight : listHeight );
					if (!scrollbarsVisible) {
						// IE doesn't recalculate width when scrollbar disappears
						listItems.width( list.width() - parseInt(listItems.css("padding-left")) - parseInt(listItems.css("padding-right")) );
					}
                }
                
            }
		},
		selected: function() {
			var selected = listItems && listItems.filter("." + classOver).removeClass(classOver);
			return selected && selected.length && $.data(selected[0], "suggest_data");
		},
		emptyList: function (){
			list && list.empty();
		},
		unbind: function() {
			element && element.remove();
		}
	};
};

/*
 * Attache suggest
 */
$(document).ready(function () {
	// Turn off autocomplete for forms
	$("form").attr("autocomplete", "off");
			
	// Select suggest text and attach to input text fields
	$(".suggest-hidden").each(function() { 
		var text = this.innerHTML;
		//Example: [MAIN_FORM:classMLawTestResultCode;Y;250[[*;*][1;1][2;2][3;3][9;9][P;P][S;S][W;W]]]
		var regex = /^\[([\w|:]+);(\w+);(\w*)\[(.+)\]\]$/;
		var match = regex.exec(text);
		if (match) {
			var id = "#" + match[1];
			var highlight = (match[2] == "Y" ? true : false);
			var width = (match[3] ? match[3] : 0);
			var options = match[4];
			//Example: [*;*][1;1][2;2][3;3][9;9][P;P][S;S][W;W]]
			regex = /\[([A-Z0-9\\*]*);(.+?)\]/g;	
			var data = [];
			while ((match = regex.exec(options)) != null) { 
				data.push({value: match[1], data: match[2]});
			}
			$(id).suggest(data, {minChars: 0, highlight: highlight, width: width});
		}
	});
});

String.prototype.trim = function(){
	return (this.replace(/^[\s\xA0]+/, "").replace(/[\s\xA0]+$/, ""));
};

String.prototype.startsWith = function(str){ 
	return (this.match("^"+str)==str);
};

String.prototype.endsWith = function(str){ 
	return (this.match(str+"$")==str);
};