/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import java.util.List;

/** 
 * Description: Organization is child of Subject and encapsulates ID of an 
 * organization. Organization is a super class for business entities like 
 * dealer, financial institutions, registration service, auto clubs, Court etc.
 * File: Organization.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: May 6, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2010/12/07 22:11:39 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class Organization extends Subject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9159889033141152326L;
	/** The current name. */
	private OrganizationName currentName;
	/** The names. */
	private List <OrganizationName> names;
	/** This represent an organization id. */
	private String organizationId;
	/** This represents the prior organization id. */
	private String priorOrganizationId;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Organization other = (Organization) obj;
		if (organizationId == null) {
			if (other.organizationId != null) {
				return false;
			}
		}
		else if (!organizationId.equals(other.organizationId)) {
			return false;
		}
		if (priorOrganizationId == null) {
			if (other.priorOrganizationId != null) {
				return false;
			}
		}
		else if (!priorOrganizationId.equals(other.priorOrganizationId)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the current name.
	 * 
	 * @return the current name
	 */
	public OrganizationName getCurrentName() {
		return currentName;
	}

	/**
	 * Gets the dba (Doing Business As) name.
	 * 
	 * @return the dba name
	 */
	public String getDbaName() {
		if (getCurrentName() != null
				&& getCurrentName() instanceof OrganizationName) {
			return (getCurrentName()).getDbaName();
		}
		else {
			return "";
		}
	}

	/**
	 * Gets the Names.
	 * 
	 * @return the names
	 */
	public List <OrganizationName> getNames() {
		return names;
	}

	/**
	 * Gets the organization id.
	 * 
	 * @return the organization id
	 */
	public String getOrganizationId() {
		return organizationId;
	}

	/**
	 * Gets the previous names.
	 * 
	 * @return the previous names
	 */
	public void getPreviousNames() {
	}

	/**
	 * Gets the Prior Organization Id.
	 * 
	 * @return the priorOrganizationId
	 */
	public String getPriorOrganizationId() {
		return priorOrganizationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((organizationId == null) ? 0 : organizationId.hashCode());
		result = prime
				* result
				+ ((priorOrganizationId == null) ? 0 : priorOrganizationId
						.hashCode());
		return result;
	}

	/**
	 * Sets the Current Name.
	 * 
	 * @param currentName the currentName to set
	 */
	public void setCurrentName(OrganizationName currentName) {
		this.currentName = currentName;
	}

	/**
	 * Sets the Names.
	 * 
	 * @param names the names to set
	 */
	public void setNames(List <OrganizationName> names) {
		this.names = names;
	}

	/**
	 * Sets the organization id.
	 * 
	 * @param organizationId the new organization id
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	/**
	 * Sets the Prior Organization Id.
	 * 
	 * @param priorOrganizationId the priorOrganizationId to set
	 */
	public void setPriorOrganizationId(String priorOrganizationId) {
		this.priorOrganizationId = priorOrganizationId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("currentName", currentName, anIndent, aBuilder);
		outputKeyValue("names", names, anIndent, aBuilder);
		outputKeyValue("organizationId", organizationId, anIndent, aBuilder);
		outputKeyValue("priorOrganizationId", priorOrganizationId, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Organization.java,v $
 *  Revision 1.7  2010/12/07 22:11:39  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.6  2010/12/07 03:57:52  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.5  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.4  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.8.2  2010/06/20 18:07:11  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/03 17:13:09  mwvxm6
 *  Moved NonAddressLocator methods to Subject
 *
 *  Revision 1.2  2010/04/29 17:08:25  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.6  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.5  2010/02/04 19:09:28  mwvxm6
 *  Removed Autowired and configured explicitly in spring context xml
 *
 *  Revision 1.4  2010/01/28 22:48:46  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/12 02:47:11  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.17  2009/10/11 16:41:24  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.16  2009/10/07 01:19:20  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.15  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.14  2009/09/09 03:04:31  mwrrv3
 *  Modified the logic for formatted phone number.
 *
 *  Revision 1.13  2009/09/02 15:55:26  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.12  2009/09/02 15:43:42  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.11  2009/08/27 05:39:48  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.9  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.8  2009/08/18 02:01:51  mwrrv3
 *  Updated the helper methods.
 *
 *  Revision 1.7  2009/08/14 01:15:57  mwrrv3
 *  Added new helper methods.
 *
 *  Revision 1.6  2009/08/13 00:38:32  mwrrv3
 *  Formatted and added comments.
 *
 *  Revision 1.5  2009/08/13 00:04:07  mwrrv3
 *  Added one new helper method to get the formatted phone number.
 *
 *  Revision 1.4  2009/07/30 01:48:53  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.3  2009/07/14 23:44:25  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:29:53  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-12 00:55:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 10:53:24 AM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 10:53:24 AM  MWCSJ3
 *  $Initial
 *  $
 */
