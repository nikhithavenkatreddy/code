/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.impl.AssignDafNumberRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.AuthorizeWorkDateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest;

/**
 * Description: Interface for an object producing service requests. This factory
 * is to be called by Persistence service clients. The requests produces by the
 * factory follow the Command Pattern and they can be executed directly.
 * 
 * File: ITransactionPersistenceServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.factory
 * Created: Dec 20, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/10/20 22:35:21 $
 * Last Changed By: $Author: mwrrv3 $
 */
public interface ITransactionPersistenceServiceRequestFactory {
	/**
	 * Creates a new AssignDafNumberRequest object.
	 * 
	 * @param userContext the user context
	 * @param domainObject the domain object
	 * 
	 * @return the persistence service request
	 */
	AssignDafNumberRequest createAssignDafNumberRequest(
			IUserContext userContext, Application application);

	/**
	 * Creates a new ITransactionPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param application the application
	 * @param allocatedDafNumber the allocated daf number
	 * 
	 * @return the update daf record persistence request
	 */
	UpdateDafRecordPersistenceRequest createUpdateDafRecordPersistenceRequest(
			IUserContext userContext, Application application,
			int allocatedDafNumber);

	/**
	 * Creates a new AuthorizeWorkDateRequest object.
	 * 
	 * @param userContext the user context
	 * @param isWorkDate
	 * @return the persistence service request
	 */
	AuthorizeWorkDateRequest createWorkDateRequest(IUserContext userContext,
			boolean isWorkDate, boolean status);
}
/**
 *  Modification History:
 *
 *  $Log: ITransactionPersistenceServiceRequestFactory.java,v $
 *  Revision 1.6  2011/10/20 22:35:21  mwrrv3
 *  Updated for performance improvement for authorize work date.
 *
 *  Revision 1.5  2011/01/14 18:28:12  mwtjc1
 *  createUpdateDafRecordPersistenceRequest added
 *
 *  Revision 1.4  2010/12/23 06:18:24  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.3.2.1  2010/12/23 03:13:57  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.3  2010/12/22 17:34:02  mwyxg1
 *  add application
 *
 *  Revision 1.2  2010/12/21 16:55:24  mwyxg1
 *  remove transaction
 *
 *  Revision 1.1  2010/12/20 17:52:02  mwyxg1
 *  add new
 *
 */
