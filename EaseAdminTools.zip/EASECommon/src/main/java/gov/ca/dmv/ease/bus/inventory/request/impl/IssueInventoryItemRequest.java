/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am request to issue an inventory item for particular location, for item of a given type
 * File: IssueInventoryItemRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 16, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2011/09/23 21:45:45 $
 * Last Changed By: $Author: mwkfh $
 */
public class IssueInventoryItemRequest extends AbstractInventoryRequest
		implements IInventoryItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3744251126703468641L;
	/** The item type code. */
	private String itemTypeCode;
	/** The location. */
	private IItemLocation location;

	/**
	 * Instantiates a new issue inventory item request.
	 */
	protected IssueInventoryItemRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected IssueInventoryItemRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Instantiates a new issue inventory item request.
	 * 
	 * @param context the context
	 * @param forLocation the for location
	 * @param anItemTypeCode the an item type code
	 */
	public IssueInventoryItemRequest(IUserContext context,
			IItemLocation forLocation, String anItemTypeCode) {
		super(context);
		setLocation(forLocation);
		setItemTypeCode(anItemTypeCode);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	public IIssuedInventoryItemResponse execute() {
		return getService().execute(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (itemTypeCode == null) {
			return 0;
		}
		else {
			return 1;
		}
	}

	/**
	 * @deprecated
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.IInventoryRequest#getItemList()
	 */
	public IInventoryItem getItem() {
		//TODO: add check to see if inventory should be issued by workstation
		//		if (getLocation().isAssignedToStation()) {
		return new StationLocalInventoryItem(getItemTypeCode(), getLocation());
		//		}
		//		else {
		//return new OfficeLocalInventoryItem(getItemTypeCode(), getLocation());
		//		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.IInventoryRequest#getItemList()
	 */
	//	public List <IInventoryItem> getItemList() {
	//		//NOTE this is provided for completeness - the item is not valid - it has no sequence no!
	//		List <IInventoryItem> aList = new ArrayList <IInventoryItem>(1);
	//		IInventoryItem anItem = new LocalInventoryItem(getItemTypeCode(),
	//				getLocation());
	//		aList.add(anItem);
	//		return aList;
	//	}
	/**
	 * Gets the item type code.
	 * 
	 * @return the itemTypeCode
	 */
	public String getItemTypeCode() {
		return itemTypeCode;
	}

	/**
	 * Gets the location.
	 * 
	 * @return the location
	 */
	public IItemLocation getLocation() {
		return location;
	}

	/**
	 * Sets the item type code.
	 * 
	 * @param itemTypeCode the itemTypeCode to set
	 */
	protected void setItemTypeCode(String aCodeString) {
		itemTypeCode = aCodeString;
	}

	/**
	 * Sets the location.
	 * 
	 * @param location the location to set
	 */
	protected void setLocation(IItemLocation aLocation) {
		location = aLocation;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueInventoryItemRequest.java,v $
 *  Revision 1.10  2011/09/23 21:45:45  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.9  2011/04/12 16:40:23  mwkfh
 *  deprecated getItem
 *
 *  Revision 1.8  2011/01/21 01:04:37  mwkfh
 *  changed getItem to only return Office items for issuing
 *
 *  Revision 1.7  2010/10/20 18:49:58  mwkfh
 *  made IUserContext constructor protected
 *
 *  Revision 1.6  2010/10/15 18:42:27  mwkfh
 *  added IIssuedInventoryItemResponse
 *
 *  Revision 1.5  2010/10/11 17:57:51  mwpxp2
 *  Fixed getItem/0 implementation
 *
 *  Revision 1.4  2010/10/07 17:57:10  mwkfh
 *  added implements
 *
 *  Revision 1.3  2010/10/06 22:33:07  mwkfh
 *  updated for single object
 *
 *  Revision 1.2  2010/09/20 23:19:31  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/16 22:25:40  mwpxp2
 *  Original implementation
 *
 */
