/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2010
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the reponse to move an inventory item location.
 * File: MoveLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Dec 3, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/12/03 16:52:09 $
 * Last Changed By: $Author: mwkfh $
 */
public class MoveLocalInventoryResponse extends PersistenceServiceResponse {
	/**
	 * Instantiates a new move location business object response.
	 * 
	 */
	protected MoveLocalInventoryResponse() {
		super();
	}

	/**
	 * Instantiates a new move location business object response.
	 * 
	 * @param ex
	 */
	public MoveLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new move location business object response.
	 * 
	 * @param ex the ex
	 */
	public MoveLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new move location business object response.
	 * 
	 * @param collector
	 */
	public MoveLocalInventoryResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new move location business object response.
	 * 
	 * @param aCount
	 */
	public MoveLocalInventoryResponse(int aCount) {
		super();
		setAffectedItemsCount(aCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MoveLocalInventoryResponse.java,v $
 *  Revision 1.1  2010/12/03 16:52:09  mwkfh
 *  added move local inventory
 *
 */
