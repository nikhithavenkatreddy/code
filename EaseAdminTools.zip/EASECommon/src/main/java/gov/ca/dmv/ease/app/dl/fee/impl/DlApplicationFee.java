/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.dl.fee.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.io.Serializable;

/**
 * Description: This represents Driver License Application Fee Information.
 * File: DlApplicationFee.java
 * Module:  gov.ca.dmv.ease.bo.dl.fee.impl.DlApplicationFee
 * Created: Dec 22, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/08/31 22:04:00 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DlApplicationFee extends BusinessObject implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 318786173536281401L;
	/** The Add Endorsement Fee. */
	private FeeRateCode addEndorsementFee;
	/** The Category 1 - Fire fighter Class A Original Fee. */
	private FeeRateCode category1OriginalFee;
	/** The Category 1 - Fire fighter Class A Renewal Fee. */
	private FeeRateCode category1RenewalFee;
	/** The Category 1 - Fire fighter Class A Upgrade Fee. */
	private FeeRateCode category1UpgradeFee;
	/** The Category 1 - Fire fighter Class A Upgrade Renewal Fee. */
	private FeeRateCode category1UpgradeRenewalFee;
	/** The Category 2 - Fire fighter Class B Original Fee. */
	private FeeRateCode category2OriginalFee;
	/** The Category 2 - Fire fighter Class B Renewal Fee. */
	private FeeRateCode category2RenewalFee;
	/** The Category 2 - Fire fighter Class B Upgrade Fee. */
	private FeeRateCode category2UpgradeFee;
	/** The Category 2 - Fire fighter Class B Upgrade Renewal Fee. */
	private FeeRateCode category2UpgradeRenewalFee;
	/** The Category 3 - Trailer Coach Original Fee. */
	private FeeRateCode category3OriginalFee;
	/** The Category 3 - Trailer Coach Original Renewal Fee. */
	private FeeRateCode category3RenewalFee;
	/** The Category 3 - Trailer Coach Upgrade Fee. */
	private FeeRateCode category3UpgradeFee;
	/** The Category 3 - Trailer Coach Upgrade Renewal Fee. */
	private FeeRateCode category3UpgradeRenewalFee;
	/** The Duplicate Issuance Fee. */
	private FeeRateCode duplicateIssuanceFee;
	/** The License Class Type. */
	private String licenseClassType;
	/** The License Fee. */
	private FeeRateCode licenseFee;
	/** The Name Change Fee. */
	private FeeRateCode nameChangeFee;
	/** The Original Application Fee. */
	private FeeRateCode originalApplicationFee;
	/** The Remove Restriction Fee. */
	private FeeRateCode removeRestrictionFee;
	/** The Renewal DL Application Fee. */
	private FeeRateCode renewalApplicationFee;
	/** The Renewal By Internet Fee. */
	private FeeRateCode renewalByInternetFee;
	/** The Renewal By Mail Fee. */
	private FeeRateCode renewalByMailFee;
	/** The Skill Test Fee. */
	private FeeRateCode skillTestFee;
	/** The Upgrade Fee. */
	private FeeRateCode upgradeFee;

	/**
	 * Default Constructor.
	 */
	public DlApplicationFee() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		if (object == null) {
			return false;
		}
		if (!(object instanceof DlApplicationFee)) {
			return false;
		}
		DlApplicationFee other = (DlApplicationFee) object;
		if (licenseClassType != null && other.getLicenseClassType() == null
				|| licenseClassType == null
				&& other.getLicenseClassType() != null) {
			return false;
		}
		else if (licenseClassType != null
				&& other.getLicenseClassType() != null
				&& !licenseClassType.equals(other.getLicenseClassType())) {
			return false;
		}
		if (originalApplicationFee != null
				&& other.getOriginalApplicationFee() == null
				|| originalApplicationFee == null
				&& other.getOriginalApplicationFee() != null) {
			return false;
		}
		else if (originalApplicationFee != null
				&& other.getOriginalApplicationFee() != null
				&& !originalApplicationFee.equals(other
						.getOriginalApplicationFee())) {
			return false;
		}
		if (renewalByMailFee != null && other.getRenewalByMailFee() == null
				|| renewalByMailFee == null
				&& other.getRenewalByMailFee() != null) {
			return false;
		}
		else if (renewalByMailFee != null
				&& other.getRenewalByMailFee() != null
				&& !renewalByMailFee.equals(other.getRenewalByMailFee())) {
			return false;
		}
		if (renewalByInternetFee != null
				&& other.getRenewalByInternetFee() == null
				|| renewalByInternetFee == null
				&& other.getRenewalByInternetFee() != null) {
			return false;
		}
		else if (renewalByInternetFee != null
				&& other.getRenewalByInternetFee() != null
				&& !renewalByInternetFee
						.equals(other.getRenewalByInternetFee())) {
			return false;
		}
		if (duplicateIssuanceFee != null
				&& other.getDuplicateIssuanceFee() == null
				|| duplicateIssuanceFee == null
				&& other.getDuplicateIssuanceFee() != null) {
			return false;
		}
		else if (duplicateIssuanceFee != null
				&& other.getDuplicateIssuanceFee() != null
				&& !duplicateIssuanceFee
						.equals(other.getDuplicateIssuanceFee())) {
			return false;
		}
		if (nameChangeFee != null && other.getNameChangeFee() == null
				|| nameChangeFee == null && other.getNameChangeFee() != null) {
			return false;
		}
		else if (nameChangeFee != null && other.getNameChangeFee() != null
				&& !nameChangeFee.equals(other.getNameChangeFee())) {
			return false;
		}
		if (skillTestFee != null && other.getSkillTestFee() == null
				|| skillTestFee == null && other.getSkillTestFee() != null) {
			return false;
		}
		else if (skillTestFee != null && other.getSkillTestFee() != null
				&& !skillTestFee.equals(other.getSkillTestFee())) {
			return false;
		}
		if (upgradeFee != null && other.getUpgradeFee() == null
				|| upgradeFee == null && other.getUpgradeFee() != null) {
			return false;
		}
		else if (upgradeFee != null && other.getUpgradeFee() != null
				&& !upgradeFee.equals(other.getUpgradeFee())) {
			return false;
		}
		if (addEndorsementFee != null && other.getAddEndorsementFee() == null
				|| addEndorsementFee == null
				&& other.getAddEndorsementFee() != null) {
			return false;
		}
		else if (addEndorsementFee != null
				&& other.getAddEndorsementFee() != null
				&& !addEndorsementFee.equals(other.getAddEndorsementFee())) {
			return false;
		}
		if (removeRestrictionFee != null
				&& other.getRemoveRestrictionFee() == null
				|| removeRestrictionFee == null
				&& other.getRemoveRestrictionFee() != null) {
			return false;
		}
		else if (removeRestrictionFee != null
				&& other.getRemoveRestrictionFee() != null
				&& !removeRestrictionFee
						.equals(other.getRemoveRestrictionFee())) {
			return false;
		}
		if (licenseFee != null && other.getLicenseFee() == null
				|| licenseFee == null && other.getLicenseFee() != null) {
			return false;
		}
		else if (licenseFee != null && other.getLicenseFee() != null
				&& !licenseFee.equals(other.getLicenseFee())) {
			return false;
		}
		if (category1OriginalFee != null
				&& other.getCategory1OriginalFee() == null
				|| category1OriginalFee == null
				&& other.getCategory1OriginalFee() != null) {
			return false;
		}
		else if (category1OriginalFee != null
				&& other.getCategory1OriginalFee() != null
				&& !category1OriginalFee
						.equals(other.getCategory1OriginalFee())) {
			return false;
		}
		if (category2OriginalFee != null
				&& other.getCategory2OriginalFee() == null
				|| category2OriginalFee == null
				&& other.getCategory2OriginalFee() != null) {
			return false;
		}
		else if (category2OriginalFee != null
				&& other.getCategory2OriginalFee() != null
				&& !category2OriginalFee
						.equals(other.getCategory2OriginalFee())) {
			return false;
		}
		if (category3OriginalFee != null
				&& other.getCategory3OriginalFee() == null
				|| category3OriginalFee == null
				&& other.getCategory3OriginalFee() != null) {
			return false;
		}
		else if (category3OriginalFee != null
				&& other.getCategory3OriginalFee() != null
				&& !category3OriginalFee
						.equals(other.getCategory3OriginalFee())) {
			return false;
		}
		if (category1UpgradeFee != null
				&& other.getCategory1UpgradeFee() == null
				|| category1UpgradeFee == null
				&& other.getCategory1UpgradeFee() != null) {
			return false;
		}
		else if (category1UpgradeFee != null
				&& other.getCategory1UpgradeFee() != null
				&& !category1UpgradeFee.equals(other.getCategory1UpgradeFee())) {
			return false;
		}
		if (category2UpgradeFee != null
				&& other.getCategory2UpgradeFee() == null
				|| category2UpgradeFee == null
				&& other.getCategory2UpgradeFee() != null) {
			return false;
		}
		else if (category2UpgradeFee != null
				&& other.getCategory2UpgradeFee() != null
				&& !category2UpgradeFee.equals(other.getCategory2UpgradeFee())) {
			return false;
		}
		if (category3UpgradeFee != null
				&& other.getCategory3UpgradeFee() == null
				|| category3UpgradeFee == null
				&& other.getCategory3UpgradeFee() != null) {
			return false;
		}
		else if (category3UpgradeFee != null
				&& other.getCategory3UpgradeFee() != null
				&& !category3UpgradeFee.equals(other.getCategory3UpgradeFee())) {
			return false;
		}
		if (renewalApplicationFee != null
				&& other.getRenewalApplicationFee() == null
				|| renewalApplicationFee == null
				&& other.getRenewalApplicationFee() != null) {
			return false;
		}
		else if (renewalApplicationFee != null
				&& other.getRenewalApplicationFee() != null
				&& !renewalApplicationFee.equals(other
						.getRenewalApplicationFee())) {
			return false;
		}
		if (category1UpgradeRenewalFee != null
				&& other.getCategory1UpgradeRenewalFee() == null
				|| category1UpgradeRenewalFee == null
				&& other.getCategory1UpgradeRenewalFee() != null) {
			return false;
		}
		else if (category1UpgradeRenewalFee != null
				&& other.getCategory1UpgradeRenewalFee() != null
				&& !category1UpgradeRenewalFee.equals(other
						.getCategory1UpgradeRenewalFee())) {
			return false;
		}
		if (category2UpgradeRenewalFee != null
				&& other.getCategory2UpgradeRenewalFee() == null
				|| category2UpgradeRenewalFee == null
				&& other.getCategory2UpgradeRenewalFee() != null) {
			return false;
		}
		else if (category2UpgradeRenewalFee != null
				&& other.getCategory2UpgradeRenewalFee() != null
				&& !category2UpgradeRenewalFee.equals(other
						.getCategory2UpgradeRenewalFee())) {
			return false;
		}
		if (category3UpgradeRenewalFee != null
				&& other.getCategory3UpgradeRenewalFee() == null
				|| category3UpgradeRenewalFee == null
				&& other.getCategory3UpgradeRenewalFee() != null) {
			return false;
		}
		else if (category3UpgradeRenewalFee != null
				&& other.getCategory3UpgradeRenewalFee() != null
				&& !category3UpgradeRenewalFee.equals(other
						.getCategory3UpgradeRenewalFee())) {
			return false;
		}
		if (category1RenewalFee != null
				&& other.getCategory1RenewalFee() == null
				|| category1RenewalFee == null
				&& other.getCategory1RenewalFee() != null) {
			return false;
		}
		else if (category1RenewalFee != null
				&& other.getCategory1RenewalFee() != null
				&& !category1RenewalFee.equals(other.getCategory1RenewalFee())) {
			return false;
		}
		if (category2RenewalFee != null
				&& other.getCategory2RenewalFee() == null
				|| category2RenewalFee == null
				&& other.getCategory2RenewalFee() != null) {
			return false;
		}
		else if (category2RenewalFee != null
				&& other.getCategory2RenewalFee() != null
				&& !category2RenewalFee.equals(other.getCategory2RenewalFee())) {
			return false;
		}
		if (category3RenewalFee != null
				&& other.getCategory3RenewalFee() == null
				|| category3RenewalFee == null
				&& other.getCategory3RenewalFee() != null) {
			return false;
		}
		else if (category3RenewalFee != null
				&& other.getCategory3RenewalFee() != null
				&& !category3RenewalFee.equals(other.getCategory3RenewalFee())) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the Add Endorsement Fee.
	 * 
	 * @return the addEndorsementFee
	 */
	public FeeRateCode getAddEndorsementFee() {
		return addEndorsementFee;
	}

	/**
	 * Gets the Category 1 Original Fee.
	 * 
	 * @return the category1OriginalFee
	 */
	public FeeRateCode getCategory1OriginalFee() {
		return category1OriginalFee;
	}

	/**
	 * Gets the Category 1 Renewal Fee.
	 * 
	 * @return the category1RenewalFee
	 */
	public FeeRateCode getCategory1RenewalFee() {
		return category1RenewalFee;
	}

	/**
	 * Gets the Category 1 Upgrade Fee.
	 * 
	 * @return the category1UpgradeFee
	 */
	public FeeRateCode getCategory1UpgradeFee() {
		return category1UpgradeFee;
	}

	/**
	 * Gets the Category 1 Upgrade Renewal Fee.
	 * 
	 * @return the category1UpgradeRenewalFee
	 */
	public FeeRateCode getCategory1UpgradeRenewalFee() {
		return category1UpgradeRenewalFee;
	}

	/**
	 * Gets the Category 2 Original Fee.
	 * 
	 * @return the category2OriginalFee
	 */
	public FeeRateCode getCategory2OriginalFee() {
		return category2OriginalFee;
	}

	/**
	 * Gets the Category 2 Renewal Fee.
	 * 
	 * @return the category2RenewalFee
	 */
	public FeeRateCode getCategory2RenewalFee() {
		return category2RenewalFee;
	}

	/**
	 * Gets the Category 2 Upgrade Fee.
	 * 
	 * @return the category2UpgradeFee
	 */
	public FeeRateCode getCategory2UpgradeFee() {
		return category2UpgradeFee;
	}

	/**
	 * Gets the Category 2 Upgrade Renewal Fee.
	 * 
	 * @return the category2UpgradeRenewalFee
	 */
	public FeeRateCode getCategory2UpgradeRenewalFee() {
		return category2UpgradeRenewalFee;
	}

	/**
	 * Gets the Category 3 Original Fee.
	 * 
	 * @return the category3OriginalFee
	 */
	public FeeRateCode getCategory3OriginalFee() {
		return category3OriginalFee;
	}

	/**
	 * Gets the Category 3 Renewal Fee.
	 * 
	 * @return the category3RenewalFee
	 */
	public FeeRateCode getCategory3RenewalFee() {
		return category3RenewalFee;
	}

	/**
	 * Gets the Category 3 Upgrade Fee.
	 * 
	 * @return the category3UpgradeFee
	 */
	public FeeRateCode getCategory3UpgradeFee() {
		return category3UpgradeFee;
	}

	/**
	 * Gets the Category 3 Upgrade Renewal Fee.
	 * 
	 * @return the category3UpgradeRenewalFee
	 */
	public FeeRateCode getCategory3UpgradeRenewalFee() {
		return category3UpgradeRenewalFee;
	}

	/**
	 * Gets the Duplicate Issuance Fee.
	 * 
	 * @return the duplicateIssuanceFee
	 */
	public FeeRateCode getDuplicateIssuanceFee() {
		return duplicateIssuanceFee;
	}

	/**
	 * Gets the License Class.
	 * 
	 * @return the licenseClassType
	 */
	public String getLicenseClassType() {
		return licenseClassType;
	}

	/**
	 * Gets the License Fee.
	 * 
	 * @return the licenseFee
	 */
	public FeeRateCode getLicenseFee() {
		return licenseFee;
	}

	/**
	 * Gets the Name Change Fee.
	 * 
	 * @return the nameChangeFee
	 */
	public FeeRateCode getNameChangeFee() {
		return nameChangeFee;
	}

	/**
	 * Gets the Original Application Fee.
	 * 
	 * @return the originalApplicationFee
	 */
	public FeeRateCode getOriginalApplicationFee() {
		return originalApplicationFee;
	}

	/**
	 * Gets the Remove Restriction Fee.
	 * 
	 * @return the removeRestrictionFee
	 */
	public FeeRateCode getRemoveRestrictionFee() {
		return removeRestrictionFee;
	}

	/**
	 * Gets the Renewal Application Fee.
	 * 
	 * @return the renewalApplicationFee
	 */
	public FeeRateCode getRenewalApplicationFee() {
		return renewalApplicationFee;
	}

	/**
	 * Gets the Renewal By Internet Fee.
	 * 
	 * @return the renewalByInternetFee
	 */
	public FeeRateCode getRenewalByInternetFee() {
		return renewalByInternetFee;
	}

	/**
	 * Gets the Renewal By Mail Fee.
	 * 
	 * @return the renewalByMailFee
	 */
	public FeeRateCode getRenewalByMailFee() {
		return renewalByMailFee;
	}

	/**
	 * Gets the Skill Test Fee.
	 * 
	 * @return the skillTestFee
	 */
	public FeeRateCode getSkillTestFee() {
		return skillTestFee;
	}

	/**
	 * Gets the Upgrade Fee.
	 * 
	 * @return the upgradeFee
	 */
	public FeeRateCode getUpgradeFee() {
		return upgradeFee;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((licenseClassType == null) ? 0 : licenseClassType.hashCode());
		result = prime
				* result
				+ ((originalApplicationFee == null) ? 0
						: originalApplicationFee.hashCode());
		result = prime
				* result
				+ ((renewalByMailFee == null) ? 0 : renewalByMailFee.hashCode());
		result = prime
				* result
				+ ((renewalByInternetFee == null) ? 0 : renewalByInternetFee
						.hashCode());
		result = prime
				* result
				+ ((duplicateIssuanceFee == null) ? 0 : duplicateIssuanceFee
						.hashCode());
		result = prime * result
				+ ((nameChangeFee == null) ? 0 : nameChangeFee.hashCode());
		result = prime * result
				+ ((skillTestFee == null) ? 0 : skillTestFee.hashCode());
		result = prime * result
				+ ((upgradeFee == null) ? 0 : upgradeFee.hashCode());
		result = prime
				* result
				+ ((addEndorsementFee == null) ? 0 : addEndorsementFee
						.hashCode());
		result = prime
				* result
				+ ((removeRestrictionFee == null) ? 0 : removeRestrictionFee
						.hashCode());
		result = prime * result
				+ ((licenseFee == null) ? 0 : licenseFee.hashCode());
		result = prime
				* result
				+ ((category1OriginalFee == null) ? 0 : category1OriginalFee
						.hashCode());
		result = prime
				* result
				+ ((category2OriginalFee == null) ? 0 : category2OriginalFee
						.hashCode());
		result = prime
				* result
				+ ((category3OriginalFee == null) ? 0 : category3OriginalFee
						.hashCode());
		result = prime
				* result
				+ ((category1UpgradeFee == null) ? 0 : category1UpgradeFee
						.hashCode());
		result = prime
				* result
				+ ((category2UpgradeFee == null) ? 0 : category2UpgradeFee
						.hashCode());
		result = prime
				* result
				+ ((category3UpgradeFee == null) ? 0 : category3UpgradeFee
						.hashCode());
		result = prime
				* result
				+ ((renewalApplicationFee == null) ? 0 : renewalApplicationFee
						.hashCode());
		result = prime
				* result
				+ ((category1UpgradeRenewalFee == null) ? 0
						: category1UpgradeRenewalFee.hashCode());
		result = prime
				* result
				+ ((category2UpgradeRenewalFee == null) ? 0
						: category2UpgradeRenewalFee.hashCode());
		result = prime
				* result
				+ ((category3UpgradeRenewalFee == null) ? 0
						: category3UpgradeRenewalFee.hashCode());
		result = prime
				* result
				+ ((category1RenewalFee == null) ? 0 : category1RenewalFee
						.hashCode());
		result = prime
				* result
				+ ((category2RenewalFee == null) ? 0 : category2RenewalFee
						.hashCode());
		result = prime
				* result
				+ ((category3RenewalFee == null) ? 0 : category3RenewalFee
						.hashCode());
		return result;
	}

	/**
	 * Sets the Add Endorsement Fee.
	 * 
	 * @param addEndorsementFee the addEndorsementFee to set
	 */
	public void setAddEndorsementFee(FeeRateCode addEndorsementFee) {
		this.addEndorsementFee = addEndorsementFee;
	}

	/**
	 * Sets the Category 1 Original Fee.
	 * 
	 * @param category1OriginalFee the category1OriginalFee to set
	 */
	public void setCategory1OriginalFee(FeeRateCode category1OriginalFee) {
		this.category1OriginalFee = category1OriginalFee;
	}

	/**
	 * Sets the Category 1 Renewal Fee.
	 * 
	 * @param category1RenewalFee the category1RenewalFee to set
	 */
	public void setCategory1RenewalFee(FeeRateCode category1RenewalFee) {
		this.category1RenewalFee = category1RenewalFee;
	}

	/**
	 * Sets the Category 1 Upgrade Fee.
	 * 
	 * @param category1UpgradeFee the category1UpgradeFee to set
	 */
	public void setCategory1UpgradeFee(FeeRateCode category1UpgradeFee) {
		this.category1UpgradeFee = category1UpgradeFee;
	}

	/**
	 * Sets the Category 1 Upgrade Renewal Fee.
	 * 
	 * @param category1UpgradeRenewalFee the category1UpgradeRenewalFee to set
	 */
	public void setCategory1UpgradeRenewalFee(
			FeeRateCode category1UpgradeRenewalFee) {
		this.category1UpgradeRenewalFee = category1UpgradeRenewalFee;
	}

	/**
	 * Gets the Category 2 Original Fee.
	 * 
	 * @param category2OriginalFee the category2OriginalFee to set
	 */
	public void setCategory2OriginalFee(FeeRateCode category2OriginalFee) {
		this.category2OriginalFee = category2OriginalFee;
	}

	/**
	 * Sets the Category 2 Renewal Fee.
	 * 
	 * @param category2RenewalFee the category2RenewalFee to set
	 */
	public void setCategory2RenewalFee(FeeRateCode category2RenewalFee) {
		this.category2RenewalFee = category2RenewalFee;
	}

	/**
	 * Sets the Category 2 Upgrade Fee.
	 * 
	 * @param category2UpgradeFee the category2UpgradeFee to set
	 */
	public void setCategory2UpgradeFee(FeeRateCode category2UpgradeFee) {
		this.category2UpgradeFee = category2UpgradeFee;
	}

	/**
	 * Sets the Category 2 Upgrade Renewal Fee.
	 * 
	 * @param category2UpgradeRenewalFee the category2UpgradeRenewalFee to set
	 */
	public void setCategory2UpgradeRenewalFee(
			FeeRateCode category2UpgradeRenewalFee) {
		this.category2UpgradeRenewalFee = category2UpgradeRenewalFee;
	}

	/**
	 * Sets the Category 3 Original Fee.
	 * 
	 * @param category3OriginalFee the category3OriginalFee to set
	 */
	public void setCategory3OriginalFee(FeeRateCode category3OriginalFee) {
		this.category3OriginalFee = category3OriginalFee;
	}

	/**
	 * Sets the Category 3 Renewal Fee.
	 * 
	 * @param category3RenewalFee the category3RenewalFee to set
	 */
	public void setCategory3RenewalFee(FeeRateCode category3RenewalFee) {
		this.category3RenewalFee = category3RenewalFee;
	}

	/**
	 * Sets the Category 3 Upgrade Fee.
	 * 
	 * @param category3UpgradeFee the category3UpgradeFee to set
	 */
	public void setCategory3UpgradeFee(FeeRateCode category3UpgradeFee) {
		this.category3UpgradeFee = category3UpgradeFee;
	}

	/**
	 * Sets the Category 3 Upgrade Renewal Fee.
	 * 
	 * @param category3UpgradeRenewalFee the category3UpgradeRenewalFee to set
	 */
	public void setCategory3UpgradeRenewalFee(
			FeeRateCode category3UpgradeRenewalFee) {
		this.category3UpgradeRenewalFee = category3UpgradeRenewalFee;
	}

	/**
	 * Sets the Duplicate Issuance Fee.
	 * 
	 * @param duplicateIssuanceFee the duplicateIssuanceFee to set
	 */
	public void setDuplicateIssuanceFee(FeeRateCode duplicateIssuanceFee) {
		this.duplicateIssuanceFee = duplicateIssuanceFee;
	}

	/**
	 * Sets the License Class.
	 * 
	 * @param licenseClassType the licenseClassType to set
	 */
	public void setLicenseClassType(String licenseClassType) {
		this.licenseClassType = licenseClassType;
	}

	/**
	 * Sets the License Fee.
	 * 
	 * @param licenseFee the licenseFee to set
	 */
	public void setLicenseFee(FeeRateCode licenseFee) {
		this.licenseFee = licenseFee;
	}

	/**
	 * Sets the Name Change Fee.
	 * 
	 * @param nameChangeFee the nameChangeFee to set
	 */
	public void setNameChangeFee(FeeRateCode nameChangeFee) {
		this.nameChangeFee = nameChangeFee;
	}

	/**
	 * Sets the Original Application Fee.
	 * 
	 * @param originalApplicationFee the originalApplicationFee to set
	 */
	public void setOriginalApplicationFee(FeeRateCode originalApplicationFee) {
		this.originalApplicationFee = originalApplicationFee;
	}

	/**
	 * Sets the Remove Restriction Fee.
	 * 
	 * @param removeRestrictionFee the removeRestrictionFee to set
	 */
	public void setRemoveRestrictionFee(FeeRateCode removeRestrictionFee) {
		this.removeRestrictionFee = removeRestrictionFee;
	}

	/**
	 * Sets the Renewal Application Fee.
	 * 
	 * @param renewalApplicationFee the renewalApplicationFee to set
	 */
	public void setRenewalApplicationFee(FeeRateCode renewalApplicationFee) {
		this.renewalApplicationFee = renewalApplicationFee;
	}

	/**
	 * Sets the Renewal By Internet Fee.
	 * 
	 * @param renewalByInternetFee the renewalByInternetFee to set
	 */
	public void setRenewalByInternetFee(FeeRateCode renewalByInternetFee) {
		this.renewalByInternetFee = renewalByInternetFee;
	}

	/**
	 * Sets the Renewal By Mail Fee.
	 * 
	 * @param renewalByMailFee the renewalByMailFee to set
	 */
	public void setRenewalByMailFee(FeeRateCode renewalByMailFee) {
		this.renewalByMailFee = renewalByMailFee;
	}

	/**
	 * Sets the Skill Test Fee.
	 * 
	 * @param skillTestFee the skillTestFee to set
	 */
	public void setSkillTestFee(FeeRateCode skillTestFee) {
		this.skillTestFee = skillTestFee;
	}

	/**
	 * Sets the Upgrade Fee.
	 * 
	 * @param upgradeFee the upgradeFee to set
	 */
	public void setUpgradeFee(FeeRateCode upgradeFee) {
		this.upgradeFee = upgradeFee;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DlApplicationFee.java,v $
 *  Revision 1.1  2012/08/31 22:04:00  mwrrv3
 *  Fixed PMD issues and moved to .impl package.
 *
 *  Revision 1.2  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/10 01:35:24  mwhxa2
 *  Changed from code set element to fee rate code
 *
 *  Revision 1.1  2010/02/25 22:53:04  mwsyk1
 *  Added new package for fee (place holder)
 *
 *  Revision 1.1.2.2  2009/12/24 18:19:24  mwhxa2
 *  Updated Code Set Element Mapping to use ALL instead of MERGE
 *
 *  Revision 1.1.2.1  2009/12/24 17:35:45  mwhxa2
 *  Adding Dl Fee Classes
 *
*/
