/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.sequence;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;

import java.util.List;

/**
 * Description: I am interface for accessing a contiguous sequence of inventory items
 * File: IContiguousItemSequence.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.15 $
 * Last Changed: $Date: 2011/11/22 23:03:41 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IContiguousItemSequence extends IBusinessObject {
	/** The ORG CODES */
	//String ORG_CODE_HEADQUARTERS = "H";
	String ORG_CODE_MANUAL = "M";
	String ORG_CODE_OFFICE = "O";
	String ORG_CODE_WORKSTATION = "W";

	/**
	 * Gets the sequence no list.
	 * @return
	 */
	List <ISequence> getSequenceNoList();

	/**
	* As item list.
	* 
	* @return the list< i item>
	*/
	List <IInventoryItem> asItemList();

	/**
	 * Contains.
	 * 
	 * @param aSequenceNo the a sequence no
	 * 
	 * @return true, if successful
	 */
	boolean contains(IInventoryItem aSequenceNo);

	/**
	 * Contains.
	 * 
	 * @param aSequenceNo the a sequence no
	 * 
	 * @return true, if successful
	 */
	boolean contains(ISequence aSequenceNo);

	/**
	 * Gets the item count.
	 * 
	 * @return the item count
	 */
	int getItemCount();

	/**
	* Gets the item location.
	* 
	* @return the IItemLocation
	*/
	IItemLocation getItemLocation();

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	IItemType getItemType();

	/**
	 * Gets the type code.
	 * 
	 * @return the type code
	 */
	String getTypeCode();

	/**
	 * Gets the lower boundary.
	 * 
	 * @return the lower boundary
	 */
	String getLowerBoundary();

	/**
	 * Gets the low point count.
	 * 
	 * @return the low point count
	 */
	int getLowPointCount();

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();

	/**
	 * Gets the org code.
	 * 
	 * @return the org code
	 */
	String getOrgCode();

	/**
	 * Gets the pattern.
	 * 
	 * @return the pattern
	 */
	ISequencePattern getPattern();

	/**
	 * Gets the processor id.
	 * 
	 * @return the processor id
	 */
	String getProcessorId();

	/**
	 * Gets the sequence count.
	 * 
	 * @return the sequence count
	 */
	int getSequenceCount();

	/**
	 * Gets the sequence pattern.
	 * 
	 * @return the sequence pattern
	 */
	ISequencePattern getSequencePattern();

	/**
	 * Gets the station id.
	 * 
	 * @return the station id
	 */
	String getStationId();

	/**
	 * Gets the upper boundary.
	 * 
	 * @return the upper boundary
	 */
	String getUpperBoundary();

	/**
	 * Checks for low point defined.
	 * 
	 * @return true, if successful
	 */
	boolean hasLowPointDefined();

	/**
	 * checks if the sequence count is set.
	 * 
	 * @return true, if successful
	 */
	boolean hasSequenceCount();

	/**
	 * Checks for upper boundary set.
	 * 
	 * @return true, if successful
	 */
	public boolean hasUpperBoundary();

	/**
	 * Checks if is drawn from hq.
	 * 
	 * @return true, if is drawn from hq
	 */
	boolean isDrawnFromHq();

	/**
	 * Checks if is for station.
	 * 
	 * @return true, if is for station
	 */
	boolean isForStation();

	/**
	 * Sets the location.
	 * 
	 * @param location the new location
	 */
	void setItemLocation(IItemLocation location);

	/**
	 * Sets the lower boundary.
	 * 
	 * @param lowerBoundary the new lower boundary
	 */
	void setLowerBoundary(String lowerBoundary);

	/**
	 * Sets the upper boundary.
	 * 
	 * @param upperBoundary the new upper boundary
	 */
	void setUpperBoundary(String upperBoundary);
}
/**
 *  Modification History:
 *
 *  $Log: IContiguousItemSequence.java,v $
 *  Revision 1.15  2011/11/22 23:03:41  mwkfh
 *  added constants
 *
 *  Revision 1.14  2011/11/21 21:17:38  mwkfh
 *  added getOrgCode to fix defect 6961
 *
 *  Revision 1.13  2011/09/27 21:36:39  mwkfh
 *  added getTypeCode
 *
 *  Revision 1.12  2011/09/23 21:21:21  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.11  2011/07/06 17:10:49  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.10  2011/07/01 23:59:07  mwkfh
 *  added methods
 *
 *  Revision 1.9  2011/06/28 21:02:00  mwxxw
 *  Add more logic for issue station level items.
 *
 *  Revision 1.8  2011/06/25 01:16:19  mwxxw
 *  Add few more interface functions.
 *
 *  Revision 1.7  2010/12/28 21:29:13  mwkfh
 *  added hasSequenceCount
 *
 *  Revision 1.6  2010/12/04 20:05:31  mwkfh
 *  changed name to getSequenceCount
 *
 *  Revision 1.5  2010/12/04 01:45:53  mwkfh
 *  added MaxItemCount
 *
 *  Revision 1.4  2010/10/14 23:27:03  mwkfh
 *  changed upper and lower boundary to String
 *
 *  Revision 1.3  2010/10/08 01:53:26  mwpxp2
 *  Added getPattern/0
 *
 *  Revision 1.2  2010/10/05 20:39:29  mwpxp2
 *  Adjusted references to sequence types
 *
 *  Revision 1.1  2010/10/05 17:40:02  mwpxp2
 *  Moved to sequence package
 *
 *  Revision 1.6  2010/09/14 01:19:59  mwpxp2
 *  Added getters for office id, station id, low point, drawn from hq.
 *
 *  Revision 1.5  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.4  2010/08/31 03:47:40  mwpxp2
 *  Reworked to function as a virtual collection of items rather than actual one
 *
 *  Revision 1.3  2010/08/30 23:19:31  mwpxp2
 *  Added getNextAvailableItemSequenceNo/0, getHowManyAvailableItems();
 *
 *  Revision 1.2  2010/08/30 23:01:24  mwpxp2
 *  Added size/0 and hasNoAvailableItems/0
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
