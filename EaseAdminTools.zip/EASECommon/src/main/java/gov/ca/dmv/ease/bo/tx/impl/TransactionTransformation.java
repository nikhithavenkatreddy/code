/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: This class represents the transaction details such as 
 * transaction record length, type, data etc for each transaction.
 * File: TransactionTransformation.java
 * Module:  gov.ca.dmv.ease.bo.tx.impl
 * Created: Aug 13, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/12/07 22:12:18 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class TransactionTransformation extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2715446943466308125L;
	/** The transaction record data. */
	private Object transactionRecordData;
	/** The transaction record length. */
	private Integer transactionRecordLength;
	/** The transaction record type. */
	private String transactionRecordType;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TransactionTransformation other = (TransactionTransformation) obj;
		if (transactionRecordData == null) {
			if (other.transactionRecordData != null) {
				return false;
			}
		}
		else if (!transactionRecordData.equals(other.transactionRecordData)) {
			return false;
		}
		if (transactionRecordLength == null) {
			if (other.transactionRecordLength != null) {
				return false;
			}
		}
		else if (!transactionRecordLength.equals(other.transactionRecordLength)) {
			return false;
		}
		if (transactionRecordType == null) {
			if (other.transactionRecordType != null) {
				return false;
			}
		}
		else if (!transactionRecordType.equals(other.transactionRecordType)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the transaction record data.
	 * 
	 * @return the transactionRecordData
	 */
	public Object getTransactionRecordData() {
		return transactionRecordData;
	}

	/**
	 * Gets the transaction record length.
	 * 
	 * @return the transactionRecordLength
	 */
	public Integer getTransactionRecordLength() {
		return transactionRecordLength;
	}

	/**
	 * Gets the transaction record type.
	 * 
	 * @return the transactionRecordType
	 */
	public String getTransactionRecordType() {
		return transactionRecordType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((transactionRecordData == null) ? 0 : transactionRecordData
						.hashCode());
		result = prime
				* result
				+ ((transactionRecordLength == null) ? 0
						: transactionRecordLength.hashCode());
		result = prime
				* result
				+ ((transactionRecordType == null) ? 0 : transactionRecordType
						.hashCode());
		return result;
	}

	/**
	 * @param transactionRecordData
	 *            the transactionRecordData to set
	 */
	public void setTransactionRecordData(Object transactionRecordData) {
		this.transactionRecordData = transactionRecordData;
	}

	/**
	 * Sets the transaction record length.
	 * 
	 * @param transactionRecordLength the transactionRecordLength to set
	 */
	public void setTransactionRecordLength(Integer transactionRecordLength) {
		this.transactionRecordLength = transactionRecordLength;
	}

	/**
	 * Sets the transaction record type.
	 * 
	 * @param transactionRecordType the transactionRecordType to set
	 */
	public void setTransactionRecordType(String transactionRecordType) {
		this.transactionRecordType = transactionRecordType;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("transactionRecordData", transactionRecordData,
				anIndent, aBuilder);
		outputKeyValue("transactionRecordLength", transactionRecordLength,
				anIndent, aBuilder);
		outputKeyValue("transactionRecordType", transactionRecordType,
				anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: TransactionTransformation.java,v $
 *  Revision 1.3  2010/12/07 22:12:18  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.2  2010/12/07 03:57:31  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.1  2010/01/30 01:09:24  mwrsk
 *  Added new attributes
 *
 *  Revision 1.1  2009/11/23 16:25:15  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/07 01:19:21  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.8  2009/08/27 05:39:57  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.6  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.5  2009/08/13 16:15:33  mwrrv3
 *  Added comments.
 *
*/
