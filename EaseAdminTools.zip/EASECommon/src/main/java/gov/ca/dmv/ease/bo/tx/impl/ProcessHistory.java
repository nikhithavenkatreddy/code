/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx.impl;

import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.tx.IProcessHistory;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Description: This class maintains information on prior User Context, Activities History.
 * It will be populated only by Transaction Service at the time of persistence.
 * It will be used in CDA etc to retrieve prior Process History Information.
 * File: ProcessHistory.java
 * Module:  gov.ca.dmv.ease.bo.tx.impl
 * Created: Mar 9, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2011/04/05 22:04:10 $
 * Last Changed By: $Author: mwyxg1 $
 */
public class ProcessHistory implements IProcessHistory, ITreePrintable,
		Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2639290373414677764L;

	/**
	 * Output key value.
	 * 
	 * @param aKey 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/** The Application Date. */
	private Date applicationDate;
	/** The Control Cashier Sequence number */
	private String controlCashierSeqNumber;
	/** The Successfully executed Activities pertaining to the Business Process. */
	private List <Activity> executedActivities;
	/** The Activities which failed while executing a Business Process. */
	private List <Activity> failedActivities;
	/** The non executed Activities while executing a Business Process. */
	private List <Activity> nonExecutedActivities;
	/** The System Date. Holds the date and time on application was started.*/
	private Date systemDate;
	/** The Transaction Identifier - aka DAF Number. */
	private Integer transactionIdentifier;
	/** The User Context. */
	private IUserContext userContext;

	/**
	 * Private Constructor.
	 * Forcing to use the requisite constructor.
	 */
	private ProcessHistory() {
		//Empty Constructor 
	}

	/**
	 * Default Constructor.
	 * 
	 * @param userContext the input User Context
	 * @param executedActivities the executed Activities
	 * @param failedActivities the failed Activities
	 * @param nonExecutedActivities the non executed Activities
	 * @param processTimeStamp the Process TimeStamp
	 * @param transactionIdentifier the DAF number
	 */
	public ProcessHistory(IUserContext userContext,
			List <Activity> executedActivities,
			List <Activity> failedActivities,
			List <Activity> nonExecutedActivities, Date applicationDate,
			Integer transactionIdentifier, String controlCashierSeqNumber) {
		this.userContext = userContext;
		this.executedActivities = executedActivities;
		this.failedActivities = failedActivities;
		this.nonExecutedActivities = nonExecutedActivities;
		this.applicationDate = applicationDate;
		this.transactionIdentifier = transactionIdentifier;
		this.controlCashierSeqNumber = controlCashierSeqNumber;
	}

	/**
	 * Gets the Application Date.
	 * 
	 * @return the applicationDate
	 * 
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}

	/**
	 * Gets the Control Cashier Sequence #.
	 * 
	 * @return the controlCashierSeqNumber
	 */
	public final String getControlCashierSeqNumber() {
		return controlCashierSeqNumber;
	}

	/**
	 * Gets the executed Activities.
	 * 
	 * @return the executedActivities
	 */
	public final List <Activity> getExecutedActivities() {
		return executedActivities;
	}

	/**
	 * Gets the failed Activities.
	 * 
	 * @return the failedActivities
	 */
	public final List <Activity> getFailedActivities() {
		return failedActivities;
	}

	/**
	 * Gets the non Executed Activities.
	 * 
	 * @return the nonExecutedActivities
	 */
	public final List <Activity> getNonExecutedActivities() {
		return nonExecutedActivities;
	}

	/**
	 * Gets the systemDate.
	 * 
	 * @return the systemDate
	 */
	public Date getSystemDate() {
		return systemDate;
	}

	/**
	 * Gets the DAF Number.
	 * 
	 * @return the transactionIdentifier
	 */
	public final Integer getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/**
	 * Gets the User Context.
	 * 
	 * @return the userContext
	 */
	public IUserContext getUserContext() {
		return userContext;
	}

	/**
	 * Sets the Application Date.
	 * 
	 * @param applicationDate the applicationDate to set
	 * 	 
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	/**
	 * Sets the systemDate Date.
	 * 
	 * @param systemDate the systemDate to set
	 */
	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(512);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}

	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("applicationDate", applicationDate, anIndent, aBuilder);
		outputKeyValue("controlCashierSeqNumber", controlCashierSeqNumber,
				anIndent, aBuilder);
		outputKeyValue("executedActivities", executedActivities, anIndent,
				aBuilder);
		outputKeyValue("failedActivities", failedActivities, anIndent, aBuilder);
		outputKeyValue("nonExecutedActivities", nonExecutedActivities,
				anIndent, aBuilder);
		outputKeyValue("systemDate", systemDate, anIndent, aBuilder);
		outputKeyValue("transactionIdentifier", transactionIdentifier,
				anIndent, aBuilder);
		outputKeyValue("userContext", userContext, anIndent, aBuilder);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ProcessHistory.java,v $
 *  Revision 1.9  2011/04/05 22:04:10  mwyxg1
 *  remove processTimestamp, add applicationDate to constructor
 *
 *  Revision 1.8  2011/04/05 21:26:58  mwyxg1
 *  remove processTimestamp
 *
 *  Revision 1.7  2011/04/05 20:14:28  mwyxg1
 *  applicationDate is set in GenerateDafNoActivity
 *
 *  Revision 1.6  2011/04/05 18:21:02  mwyxg1
 *  applicationDate is only used in test classes
 *
 *  Revision 1.5  2010/12/07 22:12:18  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 03:57:40  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.3  2010/07/22 17:50:26  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/05/09 22:01:21  mwyxg1
 *  implements Serializable
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.7  2010/04/12 17:08:47  mwhxa2
 *  Added set for System Date
 *
 *  Revision 1.6  2010/04/09 18:35:39  mwuxb
 *  Removed set system date
 *
 *  Revision 1.5  2010/04/08 21:32:38  mwuxb
 *  added attribute systemDate
 *
 *  Revision 1.4  2010/04/01 23:40:52  mwuxb
 *  Added attribute applicationDate
 *
 *  Revision 1.3  2010/03/22 23:23:34  mwhxa2
 *  Added controlCashierSeqNumber#
 *
 *  Revision 1.2  2010/03/22 23:19:35  mwhxa2
 *  Added DAF#
 *
 *  Revision 1.1  2010/03/09 22:37:52  mwhxa2
 *  holds process history
 *
*/
