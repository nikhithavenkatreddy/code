/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.license.impl.DrivingSchoolInstructorLicense;
import gov.ca.dmv.ease.fw.logging.IAuditable;

/**
 * Description: Driving School Instructor is a persons employed by the Driving School. 
 * File: DrivingSchoolInstructor.java
 * Module: gov.ca.dmv.ease.bo.subject.impl 
 * Created: Apr 7, 2010
 * @author mwvxm6
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2010/07/22 17:50:30 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class DrivingSchoolInstructor extends Person implements IAuditable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7864442830241831518L;
	/** The Driving School Instructor License. */
	private DrivingSchoolInstructorLicense drivingSchoolInstructorLicense;

	/** Default Constructor */
	public DrivingSchoolInstructor() {
	}

	/**
	 * @return the drivingSchoolInstructorLicense
	 */
	public DrivingSchoolInstructorLicense getDrivingSchoolInstructorLicense() {
		return drivingSchoolInstructorLicense;
	}

	/**
	 * @param drivingSchoolInstructorLicense the drivingSchoolInstructorLicense to set
	 */
	public void setDrivingSchoolInstructorLicense(
			DrivingSchoolInstructorLicense drivingSchoolInstructorLicense) {
		this.drivingSchoolInstructorLicense = drivingSchoolInstructorLicense;
	}
}
