package gov.ca.dmv.ease.bo.admin;

import gov.ca.dmv.ease.bo.app.impl.Station;
import gov.ca.dmv.ease.bo.cc.impl.InventoryItem;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.staticdata.impl.CityCodeDetail;
import gov.ca.dmv.ease.bo.subject.impl.CustomerOrganization;
import gov.ca.dmv.ease.bo.tx.impl.Transaction;

import java.util.List;

/**
 * Description: I am interface for office implementations
 * File: IOffice.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/10/21 23:25:05 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOffice {
	/**
	 * Gets the CityCodeDetail for the specified city code.
	 * 
	 * @return the CityCodeDetail
	 */
	CityCodeDetail getCityCodeDetail(String cityCode);

	/**
	 * Gets the City Code Details.
	 * 
	 * @return the City Code Details
	 */
	List <CityCodeDetail> getCityCodeDetails();

	/**
	 * @return the cityCodes
	 */
	List <ICodeSetElement> getCityCodes();

	/**
	 * Gets the control cashier.
	 * 
	 * @return the controlCashier
	 */
	List <IEmployee> getControlCashiers();

	/**
	 * Gets the current bundle log number.
	 * 
	 * @return the currentBundleLogNumber
	 */
	Long getCurrentBundleLogNumber();

	/**
	 * @return the driveTestWindow
	 */
	String getDriveTestWindow();

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	List <IEmployee> getEmployees();

	/**
	 * Gets the inventory item.
	 * 
	 * @return the inventory item
	 */
	InventoryItem getInventoryItem();

	/**
	 * @return the mainOfficeId
	 */
	Long getMainOfficeId();

	/**
	 * Gets the managers.
	 * 
	 * @return the managers
	 */
	List <IEmployee> getManagers();

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	String getName();

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();

	/**
	 * @return the officeWorkdates
	 */
	/*public List <OfficeWorkdate> getOfficeWorkdates() {
		return officeWorkdates;
	}*/
	/**
	 * Gets the organization.
	 * 
	 * @return the organization
	 */
	List <CustomerOrganization> getOrganizations();

	/**
	 * @return the phoneNumber
	 */
	String getPhoneNumber();

	/**
	 * @return the satelliteOffice
	 */
	String getSatelliteOffice();

	/**
	 * Gets the station.
	 * 
	 * @return the station
	 */
	List <Station> getStations();

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 */
	List <Transaction> getTransactions();
}
/**
 *  Modification History:
 *
 *  $Log: IOffice.java,v $
 *  Revision 1.2  2011/10/21 23:25:05  mwpxp2
 *  Changed referenced types to interfaces where possible
 *
 *  Revision 1.1  2011/10/21 23:21:51  mwpxp2
 *  Extracted from existing implementation
 *
 */
