/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.parse.impl;

import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequenceElem;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequenceParsingException;
import gov.ca.dmv.ease.bo.sequence.impl.SequenceElem;
import gov.ca.dmv.ease.bo.sequence.parse.ISequenceElemList;
import gov.ca.dmv.ease.bo.sequence.parse.ISequenceParser;

// TODO: Auto-generated Javadoc
/**
 * Description: I am default implementation of ISequenceParserNew
 * I produce instances of ISequenceElemList from ISequence
 * File: SequenceParserNew.java
 * Module:  gov.ca.dmv.ease.bo.sequence.parse.impl
 * Created: Sep 9, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.11 $
 * Last Changed: $Date: 2010/10/25 17:03:55 $
 * Last Changed By: $Author: mwkfh $
 */
public class SequenceParser implements ISequenceParser {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4555934293358810231L;

	/**
	 * Instantiates a new sequence parser new.
	 */
	public SequenceParser() {
		super();
	}

	/**
	 * Adjust boundaries.
	 * 
	 * @param aSequenceElemList the a sequence elem list
	 */
	private void adjustBoundaries(SequenceElemList aSequenceElemList) {
		adjustBoundaries(aSequenceElemList, aSequenceElemList.getSize());
	}

	/**
	 * Adjust boundaries.
	 * 
	 * @param aSequenceElemList the a sequence elem list
	 * @param aPos the a pos
	 */
	private void adjustBoundaries(SequenceElemList aSequenceElemList, int aPos) {
		ISequenceElem anElem = null;
		for (int i = aPos - 1; i >= 0; i--) {
			anElem = aSequenceElemList.getElemAt(i);
			if (isCandidateForLowerBoundaryAdjusting(anElem)) {
				if (canAdjustLowerBoundary(aSequenceElemList, aPos - 1)) {
					adjustLowerBoundary(anElem, anElem.getMinChar());
				}
			}
			if (isCandidateForUpperBoundaryAdjusting(anElem)) {
				if (canAdjustUpperBoundary(aSequenceElemList, aPos - 1)) {
					adjustUpperBoundary(anElem, anElem.getAbsoluteMaxChar());
				}
			}
		}
	}

	/**
	 * Adjust lower boundary.
	 * 
	 * @param anElem the an elem
	 * @param aChar the a char
	 */
	private void adjustLowerBoundary(ISequenceElem anElem, char aChar) {
		anElem.setMinChar(aChar);
	}

	/**
	 * Adjust upper boundary.
	 * 
	 * @param anElem the an elem
	 * @param aChar the a char
	 */
	private void adjustUpperBoundary(ISequenceElem anElem, char aChar) {
		anElem.setMaxChar(aChar);
	}

	/**
	 * Can adjust lower boundary.
	 * 
	 * @param aSequenceElemList the a sequence elem list
	 * @param aPos the a pos
	 * 
	 * @return true, if successful
	 */
	private boolean canAdjustLowerBoundary(SequenceElemList aSequenceElemList,
			int aPos) {
		ISequenceElem anElem = null;
		for (int i = aPos - 1; i >= 0; i--) {
			anElem = aSequenceElemList.getElemAt(i);
			if (anElem.getMinChar() > anElem.getMaxChar()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Can adjust upper boundary.
	 * 
	 * @param aSequenceElemList the a sequence elem list
	 * @param aPos the a pos
	 * 
	 * @return true, if successful
	 */
	private boolean canAdjustUpperBoundary(SequenceElemList aSequenceElemList,
			int aPos) {
		ISequenceElem anElem = null;
		for (int i = aPos - 1; i >= 0; i--) {
			anElem = aSequenceElemList.getElemAt(i);
			if (anElem.getMaxChar() > anElem.getMinChar()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks if is candidate for lower boundary adjusting.
	 * 
	 * @param anElem the an elem
	 * 
	 * @return true, if is candidate for lower boundary adjusting
	 */
	private boolean isCandidateForLowerBoundaryAdjusting(ISequenceElem anElem) {
		char aMaxChar = anElem.getMaxChar();
		return aMaxChar == anElem.getMinChar();
	}

	/**
	 * Checks if is upper for lower boundary adjusting.
	 * 
	 * @param anElem the an elem
	 * 
	 * @return true, if is upper for lower boundary adjusting
	 */
	private boolean isCandidateForUpperBoundaryAdjusting(ISequenceElem anElem) {
		char aMinChar = anElem.getMinChar();
		return aMinChar == anElem.getMaxChar();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceParser#parse(gov.ca.dmv.ease.bo.sequence.ISequence)
	 */
	public ISequenceElemList parse(ISequence aSequence) {
		validate(aSequence);
		String sequenceVal = aSequence.getValue();
		ISequencePattern aPattern = aSequence.getPattern();
		validate(aPattern);
		String patternVal = aPattern.getValue();
		int aPatternValueSize = patternVal.length();
		int aSequenceValueSize = sequenceVal.length();
		if (aPatternValueSize != aSequenceValueSize) {
			throw new SequenceParsingException("Pattern length is "
					+ aPatternValueSize + " and sequence length is: "
					+ aSequenceValueSize + " (pattern is: \"" + patternVal
					+ "\" and sequence is: \"" + sequenceVal + "\")");
		}
		//validated ok, proceed
		SequenceElemList sequenceElemList = new SequenceElemList();
		char patternChar;
		char sequenceChar;
		char minChar;
		char maxChar;
		String minVal = aPattern.getLowerSequenceBoundary();
		String maxVal = aPattern.getUpperSequenceBoundary();
		int aSequenceSize = sequenceVal.length();
		if (minVal.length() != aSequenceSize) {
			throw new SequenceParsingException("The size of lower boundary: \""
					+ minVal
					+ "\" is different from the size of input sequence: \""
					+ sequenceVal + "\"");
		}
		if (maxVal.length() != aSequenceSize) {
			throw new SequenceParsingException("The size of upper boundary: \""
					+ maxVal
					+ "\" is different from the size of input sequence: \""
					+ sequenceVal + "\"");
		}
		ISequenceElem anElem;
		boolean previousCharMaxed = true;
		for (int index = 0; index < aSequenceSize; index++) {
			patternChar = patternVal.charAt(index);
			sequenceChar = sequenceVal.charAt(index);
			minChar = minVal.charAt(index);
			maxChar = maxVal.charAt(index);
			if (previousCharMaxed || SequenceElem.isFixed(patternChar)) {
				anElem = new SequenceElem(sequenceChar, patternChar, minChar,
						maxChar);
			}
			else {
				anElem = new SequenceElem(sequenceChar, patternChar);
			}
			sequenceElemList.addElem(anElem);
			if (previousCharMaxed && (sequenceChar >= maxChar)) {
				previousCharMaxed = true;
			}
			else {
				previousCharMaxed = false;
			}
		}
		//adjustBoundaries(sequenceElemList);
		return sequenceElemList;
	}

	/**
	 * Validate.
	 * 
	 * @param sequence the sequence
	 */
	private void validate(ISequence sequence) {
		//validate first
		if (sequence == null) {
			throw new SequenceParsingException("null sequence in " + this);
		}
		String sequenceVal = sequence.getValue();
		if (sequenceVal == null) {
			throw new SequenceParsingException("null sequence value in "
					+ sequence);
		}
	}

	/**
	 * Validate.
	 * 
	 * @param aPattern the a pattern
	 */
	private void validate(ISequencePattern aPattern) {
		if (aPattern == null) {
			throw new SequenceParsingException("null pattern in " + this);
		}
		String patternVal = aPattern.getValue();
		if (patternVal == null) {
			throw new SequenceParsingException("null pattern value in "
					+ aPattern);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequenceParser.java,v $
 *  Revision 1.11  2010/10/25 17:03:55  mwkfh
 *  commented adjustBoundaries in parse method
 *
 *  Revision 1.10  2010/10/22 16:18:31  mwkfh
 *  updated previousCharMaxed in parse
 *
 *  Revision 1.9  2010/10/20 22:52:01  mwkfh
 *  fixed seq problem with min value in parse
 *
 *  Revision 1.8  2010/10/09 00:19:05  mwpxp2
 *  Added boundary adjustments for special  cases
 *
 *  Revision 1.7  2010/10/07 01:13:05  mwpxp2
 *  Extended validation to checking size of boundaries vs. sequence
 *
 *  Revision 1.6  2010/10/06 01:40:10  mwpxp2
 *  Added debug info to the exception in parse/1
 *
 *  Revision 1.5  2010/09/30 18:51:26  mwpxp2
 *  Cleaned imports
 *
 *  Revision 1.4  2010/09/30 07:46:37  mwpxp2
 *  Added validation in parse/1
 *
 *  Revision 1.3  2010/09/11 00:09:15  mwpxp2
 *  Formatting
 *
 *  Revision 1.2  2010/09/10 21:03:27  mwbxg3
 *  Clean up.
 *
 *  Revision 1.1  2010/09/10 21:00:22  mwbxg3
 *  Renamed from SequenceParserNew().
 *
 *  Revision 1.4  2010/09/10 01:06:19  mwpxp2
 *  Fixed for patterns/sequence values with trailing blanks
 *
 *  Revision 1.3  2010/09/10 00:45:41  mwpxp2
 *  Modified impl of parse/1
 *
 *  Revision 1.2  2010/09/10 00:30:18  mwbxg3
 *  *** empty log message ***
 *
 *  Revision 1.1  2010/09/09 21:07:21  mwpxp2
 *  Initial stub
 *
 */
