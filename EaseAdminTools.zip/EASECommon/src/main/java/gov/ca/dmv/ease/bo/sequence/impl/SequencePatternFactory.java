/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.impl;

import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequencePatternException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description: I am default implementation of ISequencePatternFactory
 * File: SequencePatternFactory.java
 * Module:  gov.ca.dmv.ease.bo.sequence.impl
 * Created: Sep 7, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.17 $
 * Last Changed: $Date: 2011/11/29 19:58:49 $
 * Last Changed By: $Author: mwkfh $
 */
public class SequencePatternFactory implements ISequencePatternFactory {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3283233257588071095L;
	/** The MAX_TRIES */
	private static final int MAX_TRIES = 4;
	/** The SINGLETON. */
	private static SequencePatternFactory SINGLETON;

	/**
	 * Gets the single instance of SequencePatternFactory.
	 * 
	 * @return single instance of SequencePatternFactory
	 */
	public static SequencePatternFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new SequencePatternFactory();
		SINGLETON.register("000", new SequencePattern("STATION ASSIGNMENTS",
				"NNNSSSSS", "000", "ZZZ"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "2DQA000", "2VES999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "2VEU000", "2VSZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "2VUA000", "2ZZZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "3AAA000", "3HZZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "3JAA000", "3ZZZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "4AAA000", "4ZZZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "5AAA000", "5ZZZ999"));
		SINGLETON.register("01R", new SequencePattern("REFL AUTO PLATE",
				"NAAAIIIS", "6AAA000", "6ZZZ999"));
		SINGLETON.register("02R", new SequencePattern("REFL COML PLATE",
				"NAIIIIIS", "5A00000", "5Z99999"));
		SINGLETON.register("02R", new SequencePattern("REFL COML PLATE",
				"NAIIIIIS", "6A00000", "6H99999"));
		SINGLETON.register("02R", new SequencePattern("REFL COML PLATE",
				"NAIIIIIS", "6J00000", "6Z99999"));
		SINGLETON.register("02R", new SequencePattern("REFL COML PLATE",
				"NAIIIIIS", "7A00000", "7Z99999"));
		SINGLETON.register("02R", new SequencePattern("REFL COML PLATE",
				"NAIIIIIS", "8A00000", "8Z99999"));
		SINGLETON.register("02S", new SequencePattern("SINGLE COML PLATE",
				"NAIIIIIS", "9A00000", "9E99999"));
		SINGLETON.register("02T", new SequencePattern("REFL COML PLATE",
				"IIIIIANS", "00000A1", "99999Z1"));
		SINGLETON.register("03R", new SequencePattern("REFL TRLR PLATE",
				"NAAIIIIS", "1AA1000", "1HZ9999"));
		SINGLETON.register("03R", new SequencePattern("REFL TRLR PLATE",
				"NAAIIIIS", "1JA1000", "1JH9999"));
		SINGLETON.register("03R", new SequencePattern("REFL TRLR PLATE",
				"NAAIIIIS", "1JJ1000", "1JN9999"));
		SINGLETON.register("03R", new SequencePattern("REFL TRLR PLATE",
				"NAAIIIIS", "1JP1000", "1JP9999"));
		SINGLETON.register("03R", new SequencePattern("REFL TRLR PLATE",
				"NAAIIIIS", "1JR1000", "1TZ9999"));
		SINGLETON.register("04R", new SequencePattern("REFL COML TRLR PLT",
				"NAAIIIIS", "1UA1000", "1YZ9999"));
		SINGLETON.register("04S", new SequencePattern("PTI PLT", "NAAIIIIS",
				"4AA1000", "4ZZ9999"));
		SINGLETON.register("057", new SequencePattern("INVALID CODE",
				"NNAIIIIS", "21A0000", "29E9999"));
		SINGLETON.register("05A", new SequencePattern("ANTIQUE MC PLATE",
				"SSSSZZIS", "1", "999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "12A0000", "14Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "15A0000", "15Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "16A0000", "16Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "17A0000", "17Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "18A0000", "18Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "19A0000", "19Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "20A0000", "20Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "21A0000", "21Z9999"));
		SINGLETON.register("05R", new SequencePattern("REFL MC PLATE",
				"NNAIIIIS", "22A0000", "22Z9999"));
		SINGLETON.register("060", new SequencePattern("INVALID CODE",
				"AIIIIIIS", "B010001", "B899999"));
		SINGLETON.register("06D", new SequencePattern("DLR MOPED PLATE",
				"AIIIIIIS", "B900000", "B999999"));
		SINGLETON.register("06D", new SequencePattern("DLR MOPED PLATE",
				"AIIIIIIS", "C012900", "C012999"));
		SINGLETON.register("06E", new SequencePattern("INVALID CODE",
				"AIIIIIIS", "B000001", "B010000"));
		SINGLETON.register("06R", new SequencePattern("REFL MOPED PLATE",
				"AIIIIIIS", "C013000", "C999999"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "017033", "056771"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "200000", "209999"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "272427", "282505"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "282507", "302506"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "330001", "374371"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "374375", "381401"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "437001", "439793"));
		SINGLETON.register("070", new SequencePattern("OCT E AUTO/COML PLT",
				"SIIIIIIS", "987778", "999999"));
		SINGLETON.register("071", new SequencePattern("CA EXEMPT PLATE",
				"IIIIIIIS", "1000000", "1999999"));
		SINGLETON.register("080", new SequencePattern("OCT E TRLR PLATE",
				"SIIIIIIS", "320001", "330000"));
		SINGLETON.register("080", new SequencePattern("OCT E TRLR PLATE",
				"SIIIIIIS", "374372", "374374"));
		SINGLETON.register("080", new SequencePattern("OCT E TRLR PLATE",
				"SIIIIIIS", "912499", "917498"));
		SINGLETON.register("080", new SequencePattern("OCT E TRLR PLATE",
				"SIIIIIIS", "946041", "955000"));
		SINGLETON.register("090", new SequencePattern("OCT E MC PLATE",
				"SSNNAIIS", "  00J00", "  99L99"));
		SINGLETON.register("100", new SequencePattern("DIAMOND E A/C PLT",
				"SIIIIIIS", "381401", "437000"));
		SINGLETON.register("100", new SequencePattern("DIAMOND E A/C PLT",
				"SIIIIIIS", "439794", "439999"));
		SINGLETON.register("100", new SequencePattern("DIAMOND E A/C PLT",
				"SIIIIIIS", "800001", "912498"));
		SINGLETON.register("100", new SequencePattern("DIAMOND E A/C PLT",
				"SIIIIIIS", "917499", "946040"));
		SINGLETON.register("100", new SequencePattern("DIAMOND E A/C PLT",
				"SIIIIIIS", "955001", "965000"));
		SINGLETON.register("110", new SequencePattern("DIAMOND E TRLR PLT",
				"SSIIIIIS", "00001", "03000"));
		SINGLETON.register("110", new SequencePattern("DIAMOND E TRLR PLT",
				"SSIIIIIS", "14600", "19999"));
		SINGLETON.register("110", new SequencePattern("DIAMOND E TRLR PLT",
				"SSIIIIIS", "50001", "99999"));
		SINGLETON.register("120", new SequencePattern("DIAMOND E MC PLATE",
				"SSNNAIIS", "  00A00", "  99A99"));
		SINGLETON.register("130", new SequencePattern("SPECIAL EQUIP PLT",
				"AIIIIIIS", "E300000", "E899999"));
		SINGLETON.register("131", new SequencePattern("TOW DOLLY PLATE",
				"AIIIIIIS", "E900000", "E999999"));
		SINGLETON.register("13F", new SequencePattern("DIAMOND E MC PLATE",
				"IIIAASSS", "000AA  ", "999ZZ  "));
		SINGLETON.register("152", new SequencePattern("DP TEMP PLACARD",
				"AIIIIIIS", "I000000", "I999999"));
		SINGLETON.register("153", new SequencePattern("DP TEMP PLACARD",
				"IIIIIIAS", "000001I", "999999I"));
		SINGLETON.register("153", new SequencePattern("DP TEMP PLACARD",
				"IIIIIIAS", "000001M", "999999M"));
		SINGLETON.register("155", new SequencePattern("DP MC PLATE",
				"IIIIAASS", "0000DP ", "2999DP "));
		SINGLETON.register("155", new SequencePattern("DP MC PLATE",
				"IIIIAASS", "3000DP ", "9999DP "));
		SINGLETON.register("157", new SequencePattern("DP AUTO/COML PLATE",
				"AAAIIIIS", "DPA0000", "DPY9999"));
		SINGLETON.register("157", new SequencePattern("DP AUTO/COML PLATE",
				"AAAIIIIS", "DPZ0000", "DPZ9999"));
		SINGLETON.register("158", new SequencePattern("DP AUTO/COML PLATE",
				"IIIIAAAS", "0000ADP", "9999ZDP"));
		SINGLETON.register("170", new SequencePattern("CA EXMPT MC",
				"IIIIIIIS", "3000000", "3019999"));
		SINGLETON.register("180", new SequencePattern("DV AUTO/COML PLATE",
				"AAIIIIIS", "DV00001", "DV99499"));
		SINGLETON.register("185", new SequencePattern("DV MC PLATE",
				"IIIIAASS", "0000DV ", "9999DV "));
		SINGLETON.register("186", new SequencePattern("DV AUTO/COML PLATE",
				"IIIIIAAS", "00000DV", "99999DV"));
		SINGLETON.register("18M", new SequencePattern("DV MC PLATE",
				"AAIIIIIS", "DV99500", "DV99999"));
		SINGLETON.register("190", new SequencePattern("HISTORICAL VEH PLT",
				"SAAZZZIS", " HV   1", " HV9899"));
		SINGLETON.register("191", new SequencePattern("HISTORICAL VEH PLT",
				"SAAIIIAS", " HV000J", " HV999Z"));
		SINGLETON.register("19M", new SequencePattern("HISTORICAL MC PLT",
				"SAAIIIAS", " HV000B", " HV999B"));
		SINGLETON.register("200", new SequencePattern("HON CON A/C PLATE",
				"AIIIISSS", "H0100  ", "H6999  "));
		SINGLETON.register("20M", new SequencePattern("HON CON MC PLT",
				"AIIIISSS", "H7000  ", "H7999  "));
		SINGLETON.register("20T", new SequencePattern("HON CON TRLR PLT",
				"AIIIISSS", "H8000  ", "H9899  "));
		SINGLETON.register("210", new SequencePattern("INVALID CODE",
				"SAAIIIIS", " PP1001", " PP9999"));
		SINGLETON.register("21R", new SequencePattern("REFL PRES PHOTO PLT",
				"SAAIIIIS", " PP0001", " PP9999"));
		SINGLETON.register("220", new SequencePattern("PFR STICKER",
				"AIIIIIII", "A0000000", "Z9999999"));
		SINGLETON.register("230", new SequencePattern("HORSELESS CARR PLT",
				"SAAZZZIS", " HC   1", " HC9999"));
		SINGLETON.register("240", new SequencePattern("'0' OHV PLTS GREEN",
				"SNNAIIAS", " 00E00A", " 99E99Z"));
		SINGLETON.register("240", new SequencePattern("'0' OHV PLTS GREEN",
				"SNNAIIAS", " 00F00A", " 99F99Z"));
		SINGLETON.register("240", new SequencePattern("'0' OHV PLTS GREEN",
				"SNNAIIAS", " 00G00A", " 99G99N"));
		SINGLETON.register("241", new SequencePattern("'1' OHV PLTS GREEN",
				"SNNAIIAS", " 00H00D", " 99H99Z"));
		SINGLETON.register("241", new SequencePattern("'1' OHV PLTS GREEN",
				"SNNAIIAS", " 00J00A", " 99J99Z"));
		SINGLETON.register("241", new SequencePattern("'1' OHV PLTS GREEN",
				"SNNAIIAS", " 00K00A", " 99K99T"));
		SINGLETON.register("242", new SequencePattern("2' OHV PLTS GREEN",
				"SNNAIIAS", " 00L00K", " 99L99Z"));
		SINGLETON.register("242", new SequencePattern("2' OHV PLTS GREEN",
				"SNNAIIAS", " 00M00A", " 99M99Z"));
		SINGLETON.register("242", new SequencePattern("2' OHV PLTS GREEN",
				"SNNAIIAS", " 00N00A", " 99N99Z"));
		SINGLETON.register("243", new SequencePattern("HV GRN TEST ONLY",
				"SNNAIIAS", " 00P00S", " 99P99Z"));
		SINGLETON.register("243", new SequencePattern("HV GRN TEST ONLY",
				"SNNAIIAS", " 00R00A", " 99R99Z"));
		SINGLETON.register("243", new SequencePattern("HV GRN TEST ONLY",
				"SNNAIIAS", " 00S00A", " 99S99Z"));
		SINGLETON.register("243", new SequencePattern("HV GRN TEST ONLY",
				"SNNAIIAS", " 00T00A", " 99T99B"));
		SINGLETON.register("243", new SequencePattern("HV GRN TEST ONLY",
				"SNNAIIAS", " 00X00A", " 99X99Z"));
		SINGLETON.register("248", new SequencePattern("'08' OHV PLTS GREEN",
				"SNNAIIAS", " 00A00A", " 99A99F"));
		SINGLETON.register("248", new SequencePattern("'08' OHV PLTS GREEN",
				"SNNAIIAS", " 00D00K", " 99D99P"));
		SINGLETON.register("249", new SequencePattern("'09' OHV PLTS GREEN",
				"SNNAIIAS", " 00A00K", " 99C99U"));
		SINGLETON.register("249", new SequencePattern("'09' OHV PLTS GREEN",
				"SNNAIIAS", " 00D00R", " 99D99Z"));
		SINGLETON.register("250", new SequencePattern("00 APP/PRO STKR",
				"AIIIIIIS", "A000001", "B999999"));
		SINGLETON.register("251", new SequencePattern("01 APP/PRO STKR",
				"AIIIIIIS", "C000001", "D999999"));
		SINGLETON.register("252", new SequencePattern("02 APP/PRO STKR",
				"AIIIIIIS", "E000001", "F999999"));
		SINGLETON.register("253", new SequencePattern("03 APP/PRO STKR",
				"AIIIIIIS", "G000001", "H999999"));
		SINGLETON.register("253", new SequencePattern("03 APP/PRO STKR",
				"AIIIIIIS", "P000001", "P999999"));
		SINGLETON.register("254", new SequencePattern("04 APP/PRO STKR",
				"AIIIIIIS", "F000001", "F200000"));
		SINGLETON.register("254", new SequencePattern("04 APP/PRO STKR",
				"AIIIIIIS", "J000001", "K999999"));
		SINGLETON.register("255", new SequencePattern("05 APP/PRO STKR",
				"AIIIIIIS", "L000001", "M999999"));
		SINGLETON.register("256", new SequencePattern("06 APP/PRO STKR",
				"AIIIIIIS", "N000001", "N999999"));
		SINGLETON.register("256", new SequencePattern("06 APP/PRO STKR",
				"AIIIIIIS", "P000001", "P999999"));
		SINGLETON.register("257", new SequencePattern("07 APP/PRO STKR",
				"AIIIIIIS", "R000001", "S999999"));
		SINGLETON.register("258", new SequencePattern("08 APP/PRO STKR",
				"AIIIIIIS", "T000001", "U999999"));
		SINGLETON.register("259", new SequencePattern("09 APP/PRO STKR",
				"AIIIIIIS", "V000001", "W999999"));
		SINGLETON.register("260", new SequencePattern("'1' DP PERM PLCRD",
				"IIIIIIAS", "000001A", "999999A"));
		SINGLETON.register("260", new SequencePattern("'1' DP PERM PLCRD",
				"IIIIIIAS", "000001H", "999999H"));
		SINGLETON.register("260", new SequencePattern("'1' DP PERM PLCRD",
				"IIIIIIAS", "000001N", "700000N"));
		SINGLETON.register("262", new SequencePattern("03 DPP TEST ONLY",
				"IIIIIIAS", "000001C", "999999C"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "A000001", "A999999"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "D000001", "D999999"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "F000001", "F999999"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "G000001", "G999999"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "H000001", "H844999"));
		SINGLETON.register("263", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "N000001", "N999999"));
		SINGLETON.register("265", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "J000001", "J999999"));
		SINGLETON.register("265", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "A000001", "A999999"));
		SINGLETON.register("265", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "D000001", "D999999"));
		SINGLETON.register("265", new SequencePattern("'3' DP PERM PLCRD",
				"AIIIIIIS", "H845000", "H999999"));
		SINGLETON.register("266", new SequencePattern("'7' DP PERM PLCRD",
				"IIIIIIAS", "000001D", "999999D"));
		SINGLETON.register("266", new SequencePattern("'7' DP PERM PLCRD",
				"IIIIIIAS", "000001F", "999999F"));
		SINGLETON.register("266", new SequencePattern("'7' DP PERM PLCRD",
				"IIIIIIAS", "000001G", "999999G"));
		SINGLETON.register("268", new SequencePattern("09 DP PERM PLCRD",
				"IIIIIIAS", "000001J", "999999J"));
		SINGLETON.register("268", new SequencePattern("09 DP PERM PLCRD",
				"IIIIIIAS", "000001K", "999999K"));
		SINGLETON.register("268", new SequencePattern("09 DP PERM PLCRD",
				"IIIIIIAS", "000001L", "999999L"));
		SINGLETON.register("270", new SequencePattern("'0' SPC EQUIP STKR",
				"IIIIIIAS", "000001Y", "999999Y"));
		SINGLETON.register("275", new SequencePattern("'5' SPC EQUIP STKR",
				"IIIIIIAS", "000001Z", "999999Z"));
		SINGLETON.register("283", new SequencePattern("3' OHV GRN", "SANNAIIS",
				" V00A00", " V99A99"));
		SINGLETON.register("284", new SequencePattern("4' OHV GRN", "SANNAIIS",
				" W00A00", " W99A99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " K00A00", " K99H99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " K00J00", " K99P99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " K00R00", " K99U99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " K00V00", " K99Z99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " N00E00", " N99H99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " N00J00", " N99P99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " N00R00", " N99Z99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " R00S00", " R99S99"));
		SINGLETON.register("285", new SequencePattern("'5' OHV GRN",
				"SANNAIIS", " T00W00", " T99Y99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " R00U00", " R99Z99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " V00X00", " V99Y99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " V00H00", " V99H99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " V00J00", " V99N99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " V00W00", " V99W99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Y00A00", " Y99H99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Y00J00", " Y99P99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Y00R00", " Y99Z99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Z00D00", " Z99H99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Z00J00", " Z99P99"));
		SINGLETON.register("286", new SequencePattern("2006 OHV STKR GREEN",
				"SANNAIIS", " Z00R00", " Z99S99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " F00F00", " F99H99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " F00J00", " F99N99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " F00P00", " F99V99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " F00X00", " F99Z99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " G00X00", " G99X99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " G00Z00", " G99Z99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " I00A00", " I99Z99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " L00U00", " L99U99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " L00Q00", " L99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " M00Q00", " M99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " N00C00", " N99C99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " N00Q00", " N99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " P00Q00", " P99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " R00Q00", " R99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " S00Q00", " S99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " S00Z00", " S99Z99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " T00F00", " T99H99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " T00Q00", " T99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " V00Z00", " V99Z99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " W00Q00", " W99Q99"));
		SINGLETON.register("287", new SequencePattern("2007 OHV STKR GREEN",
				"SANNAIIS", " X00Q00", " X99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " E00Q00", " E99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " F00Q00", " F99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " G00Q00", " G99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " H00Q00", " H99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " J00Q00", " J99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " K00I00", " K99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " K00Q00", " K99Q99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " L00I00", " L99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " M00I00", " M99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " N00I00", " N99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " P00I00", " P99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " Q00A00", " Q99Z99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " R00I00", " R99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " R00T00", " R99T99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " S00I00", " S99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " T00I00", " T99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " T00Z00", " T99Z99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " U00I00", " U99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " V00I00", " V99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " W00I00", " W99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " X00I00", " X99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " Y00I00", " Y99I99"));
		SINGLETON.register("288", new SequencePattern("2008 OHV STKR GREEN",
				"SANNAIIS", " Z00I00", " Z99I99"));
		SINGLETON.register("290", new SequencePattern("'0' ACTM STICKER",
				"AIIIIIII", "V0000001", "V9999999"));
		SINGLETON.register("290", new SequencePattern("'0' ACTM STICKER",
				"AIIIIIII", "W0000001", "W9999999"));
		SINGLETON.register("290", new SequencePattern("'0' ACTM STICKER",
				"AIIIIIII", "X0000001", "X9999999"));
		SINGLETON.register("290", new SequencePattern("'0' ACTM STICKER",
				"AIIIIIII", "Y0000001", "Y9999999"));
		SINGLETON.register("291", new SequencePattern("ACTM STICKERS",
				"AIIIIIII", "A0000001", "A9999999"));
		SINGLETON.register("291", new SequencePattern("ACTM STICKERS",
				"AIIIIIII", "B0000001", "B9999999"));
		SINGLETON.register("291", new SequencePattern("ACTM STICKERS",
				"AIIIIIII", "C0000001", "C9999999"));
		SINGLETON.register("291", new SequencePattern("ACTM STICKERS",
				"AIIIIIII", "Z0000001", "Z9999999"));
		SINGLETON.register("292", new SequencePattern("'   ACTM STICKERS",
				"AIIIIIII", "D0000001", "D9999999"));
		SINGLETON.register("292", new SequencePattern("'   ACTM STICKERS",
				"AIIIIIII", "E0000001", "E9999999"));
		SINGLETON.register("292", new SequencePattern("'   ACTM STICKERS",
				"AIIIIIII", "F0000001", "F9999999"));
		SINGLETON.register("292", new SequencePattern("'   ACTM STICKERS",
				"AIIIIIII", "G0000001", "G9999999"));
		SINGLETON.register("292", new SequencePattern("'   ACTM STICKERS",
				"AIIIIIII", "Q0000001", "Q9999999"));
		SINGLETON.register("293", new SequencePattern("' ACTM STICKER",
				"AIIIIIII", "T0000001", "T0001000"));
		SINGLETON.register("294", new SequencePattern("'4' ACTM", "AIIIIIII",
				"V0000001", "V0001000"));
		SINGLETON.register("295", new SequencePattern("'5'ACTM STKR",
				"AIIIIIII", "Y0000001", "Y9999999"));
		SINGLETON.register("296", new SequencePattern("'6' ACTM STKR",
				"AIIIIIII", "D0000001", "D9999999"));
		SINGLETON.register("297", new SequencePattern("2007 A/C/T/M STKR",
				"AIIIIIII", "G0000000", "H9999999"));
		SINGLETON.register("297", new SequencePattern("2007 A/C/T/M STKR",
				"AIIIIIII", "J0000000", "K9999999"));
		SINGLETON.register("298", new SequencePattern("2008 A/C/T/M STKR",
				"AIIIIIII", "L0000000", "P9999999"));
		SINGLETON.register("299", new SequencePattern("2009 A/C/T/M STKR",
				"AIIIIIII", "R0000001", "U9999999"));
		SINGLETON.register("2CT", new SequencePattern("HON CON C/TRLR PLT",
				"AIIIISSS", "H9900  ", "H9999  "));
		SINGLETON.register("300", new SequencePattern("YOSEMITE AUTO PLT",
				"NAAAIIIS", "1UAA000", "1UDZ999"));
		SINGLETON.register("300", new SequencePattern("YOSEMITE AUTO PLT",
				"NAAAIIIS", "1VBA000", "1VBZ999"));
		SINGLETON.register("301", new SequencePattern("ARTS AUTO PLT",
				"SAAAIIIS", " SAT000", " SAT999"));
		SINGLETON.register("302", new SequencePattern("VETERANS PLT",
				"SAAAIIIS", " PET000", " PET999"));
		SINGLETON.register("303", new SequencePattern("KIDS HEART PLATE",
				"SAAAIIIS", " LAX000", " LAX999"));
		SINGLETON.register("304", new SequencePattern("KIDS HAND PLATE",
				"SAAAIIIS", " HUN000", " HUN999"));
		SINGLETON.register("304", new SequencePattern("KIDS HAND PLATE",
				"SAAAIIIS", " LAP000", " LAP999"));
		SINGLETON.register("305", new SequencePattern("KIDS STAR PLATE",
				"SAAAIIIS", " LUG000", " LUG999"));
		SINGLETON.register("305", new SequencePattern("KIDS STAR PLATE",
				"SAAAIIIS", " YES000", " YES999"));
		SINGLETON.register("306", new SequencePattern("KIDS PLUS PLATE",
				"SAAAIIIS", " LYN000", " LYN999"));
		SINGLETON.register("307", new SequencePattern("FIREFIGHTERS PLT*",
				"SAAAIIIS", " PPA000", " PPA999"));
		SINGLETON.register("307", new SequencePattern("FIREFIGHTERS PLT*",
				"SAAAIIIS", " PUE000", " PUE999"));
		SINGLETON.register("307", new SequencePattern("FIREFIGHTERS PLT*",
				"SAAAIIIS", " PUG000", " PUG999"));
		SINGLETON.register("307", new SequencePattern("FIREFIGHTERS PLT*",
				"SAAAIIIS", " PUP000", " PUP999"));
		SINGLETON.register("308", new SequencePattern("PUC LIMO PLATE",
				"NAAAIIIS", "1ZZA000", "1ZZZ999"));
		SINGLETON.register("309", new SequencePattern("FOREIGN ORG PLATE",
				"AAIIISSS", "FO000  ", "FO999  "));
		SINGLETON.register("30C", new SequencePattern("YOSEMITE COML PLATE",
				"NAIIIIIS", "2Z00000", "2Z35999"));
		SINGLETON.register("30C", new SequencePattern("YOSEMITE COML PLATE",
				"NAIIIIIS", "2Z80000", "2Z89999"));
		SINGLETON.register("30D", new SequencePattern("COASTAL AUTO PLATE",
				"NAAAIIIS", "1VAA000", "1VAZ999"));
		SINGLETON.register("30D", new SequencePattern("COASTAL AUTO PLATE",
				"NAAAIIIS", "1VDA000", "1VDZ999"));
		SINGLETON.register("30D", new SequencePattern("COASTAL AUTO PLATE",
				"NAAAIIIS", "1VEA000", "1VEZ999"));
		SINGLETON.register("30E", new SequencePattern("COASTAL COML PLATE",
				"NAIIIIIS", "2Z48000", "2Z59999"));
		SINGLETON.register("30F", new SequencePattern("COASTAL TRLR PLATE",
				"NAAIIIIS", "2HE1000", "2HE9999"));
		SINGLETON.register("30F", new SequencePattern("COASTAL TRLR PLATE",
				"NAAIIIIS", "2HH1000", "2HH9999"));
		SINGLETON.register("30G", new SequencePattern("COASTAL C/TRLR PLT",
				"NAAIIIIS", "1ZW1000", "1ZW9999"));
		SINGLETON.register("30H", new SequencePattern("CA MEMORIAL PLT",
				"IIIIAASS", "0000MA ", "9999MZ "));
		SINGLETON.register("30M", new SequencePattern("SPEC INTRST M/C PLT",
				"NNAIISSS", "00A00  ", "99Z99  "));
		SINGLETON.register("30T", new SequencePattern("YOSEMITE TRLR PLT",
				"NAAIIIIS", "2HA0000", "2HC9999"));
		SINGLETON.register("310", new SequencePattern("GOLD STAR TEST",
				"SIIIAAAS", " 101HUY", " 300HUY"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000ALE", " 999ALE"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000APA", " 999APA"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000BAR", " 999BAR"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000BEG", " 999BEG"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000BET", " 999BET"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000BLA", " 999BLA"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000BUB", " 999BUB"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000HUJ", " 999HUJ"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000HUN", " 999HUN"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000HUT", " 999HUT"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000JUG", " 999JUG"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000KAD", " 999KAD"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000KEG", " 999KEG"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000LAF", " 999LAF"));
		SINGLETON.register("311", new SequencePattern("ARTS PLATE", "SIIIAAAS",
				" 000LAP", " 999LAP"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000BUD", " 999BUD"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000BUG", " 999BUG"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000CAD", " 999CAD"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000CAN", " 999CAN"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000HAD", " 999HAD"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000HEX", " 999HEX"));
		SINGLETON.register("312", new SequencePattern("VETERANS PLATE",
				"SIIIAAAS", " 000HUG", " 999HUG"));
		SINGLETON.register("313", new SequencePattern("KIDS HEART PLATE",
				"SIIIAAAS", " 000CAT", " 999CAT"));
		SINGLETON.register("313", new SequencePattern("KIDS HEART PLATE",
				"SIIIAAAS", " 000CIP", " 999CIP"));
		SINGLETON.register("314", new SequencePattern("KIDS HAND PLATE",
				"SIIIAAAS", " 000DEW", " 999DEW"));
		SINGLETON.register("314", new SequencePattern("KIDS HAND PLATE",
				"SIIIAAAS", " 000DUB", " 999DUB"));
		SINGLETON.register("315", new SequencePattern("KIDS STAR PLATE",
				"SIIIAAAS", " 000EAK", " 999EAK"));
		SINGLETON.register("315", new SequencePattern("KIDS STAR PLATE",
				"SIIIAAAS", " 000EEK", " 999EEK"));
		SINGLETON.register("315", new SequencePattern("KIDS STAR PLATE",
				"SIIIAAAS", " 000YES", " 999YES"));
		SINGLETON.register("316", new SequencePattern("KIDS PLUS PLATE",
				"SIIIAAAS", " 000EEW", " 999EEW"));
		SINGLETON.register("316", new SequencePattern("KIDS PLUS PLATE",
				"SIIIAAAS", " 000END", " 999END"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000EVE", " 999EVE"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000EZP", " 999EZP"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000GAG", " 999GAG"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000GPU", " 999GPU"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000PAP", " 999PAP"));
		SINGLETON.register("317", new SequencePattern("FIREFIGHTERS PLATE",
				"SIIIAAAS", " 000PAT", " 999PAT"));
		SINGLETON.register("320", new SequencePattern("'0' METAL TABS",
				"AIIIIIII", "D9000001", "D9999999"));
		SINGLETON.register("321", new SequencePattern("'1' METAL TABS",
				"AIIIIIII", "E9000001", "E9999999"));
		SINGLETON.register("322", new SequencePattern("'2' METAL TABS",
				"AIIIIIII", "F9000001", "F9999999"));
		SINGLETON.register("323", new SequencePattern("'3' METAL TABS",
				"AIIIIIII", "W9000001", "W9999999"));
		SINGLETON.register("324", new SequencePattern("'4' METAL TABS",
				"AIIIIIII", "X9000001", "X9999999"));
		SINGLETON.register("325", new SequencePattern("'5' METAL TABS",
				"AIIIIIII", "Y9000001", "Y9999999"));
		SINGLETON.register("326", new SequencePattern("'6' METAL TABS",
				"AIIIIIII", "Z9000001", "Z9999999"));
		SINGLETON.register("327", new SequencePattern("'7' METAL TABS",
				"AIIIIIII", "A9000001", "A9999999"));
		SINGLETON.register("328", new SequencePattern("'8' METAL TABS",
				"AIIIIIII", "B9000001", "B9999999"));
		SINGLETON.register("329", new SequencePattern("'9' METAL TABS",
				"AIIIIIII", "C9000001", "C9999999"));
		SINGLETON.register("341", new SequencePattern("'1' VESSEL STKR",
				"AIIIIIIS", "A000001", "A999999"));
		SINGLETON.register("341", new SequencePattern("'1' VESSEL STKR",
				"AIIIIIIS", "B000001", "B999999"));
		SINGLETON.register("341", new SequencePattern("'1' VESSEL STKR",
				"AIIIIIIS", "C000001", "C999999"));
		SINGLETON.register("341", new SequencePattern("'1' VESSEL STKR",
				"AIIIIIIS", "D000001", "D999999"));
		SINGLETON.register("343", new SequencePattern("'3' VESSEL STKR",
				"AIIIIIIS", "E000001", "E999999"));
		SINGLETON.register("343", new SequencePattern("'3' VESSEL STKR",
				"AIIIIIIS", "F000001", "F999999"));
		SINGLETON.register("343", new SequencePattern("'3' VESSEL STKR",
				"AIIIIIIS", "G000001", "G999999"));
		SINGLETON.register("343", new SequencePattern("'3' VESSEL STKR",
				"AIIIIIIS", "H000001", "H999999"));
		SINGLETON.register("343", new SequencePattern("'3' VESSEL STKR",
				"AIIIIIIS", "M000000", "N999999"));
		SINGLETON.register("345", new SequencePattern("'5' VESSEL STKR",
				"AIIIIIIS", "J000001", "J999999"));
		SINGLETON.register("345", new SequencePattern("'5' VESSEL STKR",
				"AIIIIIIS", "K000001", "K999999"));
		SINGLETON.register("345", new SequencePattern("'5' VESSEL STKR",
				"AIIIIIIS", "L000001", "L999999"));
		SINGLETON.register("345", new SequencePattern("'5' VESSEL STKR",
				"AIIIIIIS", "M000001", "M999999"));
		SINGLETON.register("347", new SequencePattern("'7' VESSEL STKR",
				"AIIIIIIS", "R000001", "R999999"));
		SINGLETON.register("347", new SequencePattern("'7' VESSEL STKR",
				"AIIIIIIS", "S000001", "S999999"));
		SINGLETON.register("347", new SequencePattern("'7' VESSEL STKR",
				"AIIIIIIS", "T000001", "T999999"));
		SINGLETON.register("347", new SequencePattern("'7' VESSEL STKR",
				"AIIIIIIS", "U000001", "U999999"));
		SINGLETON.register("349", new SequencePattern("'9' VESSEL STKR",
				"AIIIIIIS", "W000001", "W999999"));
		SINGLETON.register("349", new SequencePattern("'9' VESSEL STKR",
				"AIIIIIIS", "X000001", "X999999"));
		SINGLETON.register("349", new SequencePattern("'9' VESSEL STKR",
				"AIIIIIIS", "Y000001", "Y999999"));
		SINGLETON.register("349", new SequencePattern("'9' VESSEL STKR",
				"AIIIIIIS", "Z000001", "Z999999"));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000AA ", "9999CZ "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000EA ", "9999KZ "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000NA ", "9999WZ "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000YC ", "9999YH "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000YJ ", "9999YN "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000YP ", "9999YP "));
		SINGLETON.register("350", new SequencePattern("BOAT 102", "IIIIAASS",
				"0000YR ", "9999YZ "));
		SINGLETON.register("365", new SequencePattern("'5' NC MC/ATV",
				"SANNAIIS", " G00T00", " G99W99"));
		SINGLETON.register("365", new SequencePattern("'5' NC MC/ATV",
				"SANNAIIS", " T00K00", " T99P99"));
		SINGLETON.register("365", new SequencePattern("'5' NC MC/ATV",
				"SANNAIIS", " T00R00", " T99S99"));
		SINGLETON.register("366", new SequencePattern("2006 NC MC/ATV",
				"SANNAIIS", " P00Y00", " P99Y99"));
		SINGLETON.register("366", new SequencePattern("2006 NC MC/ATV",
				"SANNAIIS", " V00P00", " V99P99"));
		SINGLETON.register("366", new SequencePattern("2006 NC MC/ATV",
				"SANNAIIS", " V00R00", " V99U99"));
		SINGLETON.register("366", new SequencePattern("2006 NC MC/ATV",
				"SANNAIIS", " Z00T00", " Z99Z99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " J00X00", " J99Z99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " P00Z00", " P99Z99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " T00T00", " T99V99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " U00Q00", " U99Q99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " V00Q00", " V99Q99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " X00T00", " X99T99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " X00V00", " X99Z99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " Y00Q00", " Y99Q99"));
		SINGLETON.register("367", new SequencePattern("2007 OHV COMP STKR",
				"SANNAIIS", " Z00Q00", " Z99Q99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " A00I00", " A99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " A00Q00", " A99Q99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " B00I00", " B99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " B00Q00", " B99Q99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " C00I00", " C99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " C00Q00", " C99Q99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " D00I00", " D99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " D00Q00", " D99Q99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " E00I00", " E99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " F00I00", " F99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " G00I00", " G99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " H00I00", " H99I99"));
		SINGLETON.register("368", new SequencePattern("2008 OHV STKR RED",
				"SANNAIIS", " J00I00", " J99I99"));
		SINGLETON.register("370", new SequencePattern("ULEV STKR", "AAIIIIII",
				"UL000000", "UL999999"));
		SINGLETON.register("380", new SequencePattern("'0' NC MC/ATV RED",
				"SNNAIIAS", " 00G00P", " 99G99Z"));
		SINGLETON.register("380", new SequencePattern("'0' NC MC/ATV RED",
				"SNNAIIAS", " 00H00A", " 99H99C"));
		SINGLETON.register("381", new SequencePattern("'1' NC MC/ATV RED",
				"SNNAIIAS", " 00K00U", " 99K99Z"));
		SINGLETON.register("381", new SequencePattern("'1' NC MC/ATV RED",
				"SNNAIIAS", " 00L00A", " 99L99J"));
		SINGLETON.register("382", new SequencePattern("' NC MC/ATV RED",
				"SNNAIIAS", " 00P00A", " 99P99R"));
		SINGLETON.register("383", new SequencePattern("MC/ATV TEST ONLY",
				"SNNAIIAS", " 00T00C", " 99T99S"));
		SINGLETON.register("383", new SequencePattern("MC/ATV TEST ONLY",
				"SNNAIIAS", " 00Z00A", " 99Z99Z"));
		SINGLETON.register("388", new SequencePattern("'08' NC MC/ATV RED",
				"SNNAIIAS", " 00A00G", " 99A99J"));
		SINGLETON.register("389", new SequencePattern("'09' NC MC/ATV RED",
				"SNNAIIAS", " 00C00V", " 99D99J"));
		SINGLETON.register("3CT", new SequencePattern("YOSEMITE C/TRLR PLT",
				"NAAIIIIS", "1ZX0000", "1ZX9999"));
		SINGLETON.register("3T1", new SequencePattern("TAHOE AUTO PLATE",
				"NAAAIIIS", "1UEA000", "1UEZ999"));
		SINGLETON.register("3T1", new SequencePattern("TAHOE AUTO PLATE",
				"NAAAIIIS", "1VCA000", "1VCZ999"));
		SINGLETON.register("3T2", new SequencePattern("TAHOE COML PLATE",
				"NAIIIIIS", "2Z36000", "2Z40999"));
		SINGLETON.register("3T2", new SequencePattern("TAHOE COML PLATE",
				"NAIIIIIS", "2Z70000", "2Z79999"));
		SINGLETON.register("3T3", new SequencePattern("TAHOE TRLR PLATE",
				"NAAIIIIS", "2HD0000", "2HD0999"));
		SINGLETON.register("3T3", new SequencePattern("TAHOE TRLR PLATE",
				"NAAIIIIS", "2HG1000", "2HG9999"));
		SINGLETON.register("3T4", new SequencePattern("TAHOE C/TRLR PLATE",
				"NAAIIIIS", "1ZY0000", "1ZY9999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "A1000001", "A1999999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "A3000000", "A9999999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "B3000000", "B9999999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "D1000000", "D9999999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "E1000000", "E4999999"));
		SINGLETON.register("400", new SequencePattern("DL/ID NUMBER",
				"AIIIIIII", "I0000001", "I9999999"));
		SINGLETON.register("401", new SequencePattern("PSEUDO DL NUMBER",
				"AIIIIIII", "A0001001", "A9999999"));
		SINGLETON.register("401", new SequencePattern("PSEUDO DL NUMBER",
				"AIIIIIII", "B0000000", "Y9999999"));
		SINGLETON.register("401", new SequencePattern("PSEUDO DL NUMBER",
				"AIIIIIII", "Z0000000", "Z9633380"));
		SINGLETON.register("410", new SequencePattern("DL APP", "AIIIIIII",
				"A0000001", "A8999999"));
		SINGLETON.register("41C", new SequencePattern("COML DL APP",
				"AIIIIIII", "C0000001", "C8999999"));
		SINGLETON.register("41P", new SequencePattern("PROV DL APP",
				"AIIIIIII", "P0000001", "P8999999"));
		SINGLETON.register("42R", new SequencePattern("REGULAR ID", "AIIIIIII",
				"I0000001", "I8999999"));
		SINGLETON.register("42S", new SequencePattern("SENIOR ID", "AIIIIIII",
				"S0000001", "S8999999"));
		SINGLETON.register("430", new SequencePattern("SLS PERSON LIC NUM",
				"AIIIIIIS", "I000001", "I999999"));
		SINGLETON.register("430", new SequencePattern("SLS PERSON LIC NUM",
				"AIIIIIIS", "Q000001", "Q999999"));
		SINGLETON.register("430", new SequencePattern("SLS PERSON LIC NUM",
				"AIIIIIIS", "S000001", "S999999"));
		SINGLETON.register("431", new SequencePattern("SLS PERSON APP",
				"IIIIIINS", "000001S", "999999S"));
		SINGLETON.register("460", new SequencePattern("TRANSIT TRNG, DL260A",
				"AIIIIIII", "V0000001", "V9999999"));
		SINGLETON.register("461", new SequencePattern("SPEC CERT, DL-61",
				"AIIIIIII", "D0000001", "D9999999"));
		SINGLETON.register("464", new SequencePattern("TOW TRUCK DRV, DL-64",
				"AAIIIISS", "TT0001 ", "TT9999 "));
		SINGLETON.register("465", new SequencePattern("TOW TRUCK DRV, DL-64",
				"AAIIIIIS", "TT10000", "TT99975"));
		SINGLETON.register("471", new SequencePattern("TOUR BUS PERMIT",
				"AIIIIIII", "B0010001", "B9999999"));
		SINGLETON.register("474", new SequencePattern("TVS CERTS, DL-730",
				"IIIIIIII", "10000000", "99999999"));
		SINGLETON.register("480", new SequencePattern("MDI CERTS, DL-801",
				"AIIIIIIS", "M000001", "M999999"));
		SINGLETON.register("481", new SequencePattern("STUDENT LIC, OL-800",
				"AIIIIIIS", "A000001", "A999999"));
		SINGLETON.register("497", new SequencePattern("DSL DER", "IIIIIIII",
				"90000000", "99999999"));
		SINGLETON.register("500", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "BP00000", "BP99999"));
		SINGLETON.register("500", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "CP00000", "CP99999"));
		SINGLETON.register("500", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "EP00000", "EP99999"));
		SINGLETON.register("50S", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "SP00000", "SP99999"));
		SINGLETON.register("50S", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "TP00000", "TP09999"));
		SINGLETON.register("50S", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "UP00000", "UP99999"));
		SINGLETON.register("50S", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "WP00000", "WP99999"));
		SINGLETON.register("50S", new SequencePattern("APPOR POWER UNIT",
				"AAIIIIIS", "VP00000", "VP99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "AT00000", "AT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "BT00000", "BT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "CT00000", "CT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "DT00000", "DT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "FT00000", "FT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "GT00001", "GT99999"));
		SINGLETON.register("510", new SequencePattern("APPOR TRAILER PLT",
				"AAIIIIIS", "HT00000", "HT29999"));
		SINGLETON.register("600", new SequencePattern("'0' PYR YEARLY STKR",
				"IIIIIIIS", "0000001", "0999999"));
		SINGLETON.register("601", new SequencePattern("'1' PYR YEARLY STKR",
				"IIIIIIIS", "1000001", "1999999"));
		SINGLETON.register("602", new SequencePattern("'2' PYR YEARLY STKR",
				"IIIIIIIS", "2000001", "2999999"));
		SINGLETON.register("603", new SequencePattern("'3' PYR YEARLY STKR",
				"IIIIIIIS", "3000001", "3999999"));
		SINGLETON.register("604", new SequencePattern("'4' PYR YEARLY STKR",
				"IIIIIIIS", "4000001", "4999999"));
		SINGLETON.register("605", new SequencePattern("'5' PYR YEARLY STKR",
				"IIIIIIIS", "5000001", "5999999"));
		SINGLETON.register("606", new SequencePattern("'6' PYR YEARLY STKR",
				"IIIIIIIS", "6000001", "6999999"));
		SINGLETON.register("607", new SequencePattern("'7' PYR YEARLY STKR",
				"IIIIIIIS", "7000001", "7999999"));
		SINGLETON.register("608", new SequencePattern("'8' PYR YEARLY STKR",
				"IIIIIIIS", "8000001", "8999999"));
		SINGLETON.register("609", new SequencePattern("'9'PYR YEARLY STKR",
				"IIIIIIIS", "9000001", "9999999"));
		SINGLETON.register("703", new SequencePattern("00 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("706", new SequencePattern("00 JUNE PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("709", new SequencePattern("00 SEPT PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("70C", new SequencePattern("00 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("713", new SequencePattern("01 MARCH PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("716", new SequencePattern("01 JUNE PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("719", new SequencePattern("01 SEPT PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("71C", new SequencePattern("01 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("723", new SequencePattern("02 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("726", new SequencePattern("02 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("729", new SequencePattern("02 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("72C", new SequencePattern("02 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("733", new SequencePattern("93 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("736", new SequencePattern("93 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("739", new SequencePattern("93 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("73C", new SequencePattern("93 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("743", new SequencePattern("94 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("746", new SequencePattern("94 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("749", new SequencePattern("94 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("74C", new SequencePattern("94 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("753", new SequencePattern("95 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("756", new SequencePattern("95 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("759", new SequencePattern("95 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("75C", new SequencePattern("95 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("763", new SequencePattern("06 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("766", new SequencePattern("06 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("769", new SequencePattern("06 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("76C", new SequencePattern("06 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("773", new SequencePattern("07 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("776", new SequencePattern("07 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("779", new SequencePattern("07 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("77C", new SequencePattern("07 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("783", new SequencePattern("98 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("786", new SequencePattern("98 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("789", new SequencePattern("98 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("78C", new SequencePattern("98 NOV PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("793", new SequencePattern("99 MAR PYR MTAB",
				"NIIIIISS", "390001", "399999"));
		SINGLETON.register("796", new SequencePattern("99 JUN PYR MTAB",
				"NIIIIISS", "690001", "699999"));
		SINGLETON.register("799", new SequencePattern("99 SEP PYR MTAB",
				"NIIIIISS", "990001", "999999"));
		SINGLETON.register("79C", new SequencePattern("99 DEC PYR MTAB",
				"NNIIIIIS", "1290001", "1299999"));
		SINGLETON.register("818", new SequencePattern("Q SERIES 7 DIGIT",
				"NAAAIIIS", "1QAA000", "3QZZ999"));
		SINGLETON.register("818", new SequencePattern("Q SERIES 7 DIGIT",
				"NAAAIIIS", "4QAA000", "5QZZ999"));
		SINGLETON.register("819", new SequencePattern("Q SERIES 7 DIGIT",
				"SAAAIIIS", " QAA000", " QZZ999"));
		SINGLETON.register("820", new SequencePattern("Q SERIES 7 DIGIT",
				"SIIIAAAS", " 000QAA", " 999QZZ"));
		SINGLETON.register("821", new SequencePattern("APPOR TITLE ONLY",
				"SIIIIIIS", "900000", "999999"));
		SINGLETON.register("822", new SequencePattern("PRORATE ID", "SIIIIIIS",
				"000000", "899999"));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000AA ", "9999CZ "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000EA ", "9999KZ "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000NA ", "9999WZ "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XE ", "9999XE "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XG ", "9999XH "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XJ ", "9999XN "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XP ", "9999XP "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XR ", "9999XR "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000XT ", "9999XZ "));
		SINGLETON.register("830", new SequencePattern("PLEASURE/COML CF #",
				"IIIIAASS", "0000ZA ", "9999ZZ "));
		SINGLETON.register("83D", new SequencePattern("DEALER CF #",
				"IIIIAASS", "0000DA ", "9999DZ "));
		SINGLETON.register("83G", new SequencePattern("GOVT EXEMPT CF #",
				"IIIIAASS", "0000LC ", "9999LC "));
		SINGLETON.register("83G", new SequencePattern("GOVT EXEMPT CF #",
				"IIIIAASS", "0000XC ", "9999XC "));
		SINGLETON.register("83G", new SequencePattern("GOVT EXEMPT CF #",
				"IIIIAASS", "0000XF ", "9999XF "));
		SINGLETON.register("83G", new SequencePattern("GOVT EXEMPT CF #",
				"IIIIAASS", "0000XS ", "9999XS "));
		SINGLETON.register("83L", new SequencePattern("LIVERY CF #",
				"IIIIAASS", "0000LA ", "9999LZ "));
		SINGLETON.register("83M", new SequencePattern("MANUFACTURER CF #",
				"IIIIAASS", "0000MA ", "9999MZ "));
		SINGLETON.register("83Y", new SequencePattern("YOUTH EXEMPT CF #",
				"IIIIAASS", "0000YA ", "9999YB "));
		SINGLETON.register("905", new SequencePattern("PEARL HARBOR PLATE",
				"AAAIIIIS", "PHS0000", "PHS9999"));
		SINGLETON.register("911", new SequencePattern("OLYMPIC TRNG PLT",
				"AAIIIIIS", "CA00000", "CA99999"));
		SINGLETON.register("916", new SequencePattern("PURPLE HRT A/C PLT",
				"AAIIIISS", "PH0000 ", "PH7999 "));
		SINGLETON.register("916", new SequencePattern("PURPLE HRT A/C PLT",
				"AAIIIISS", "PH9000 ", "PH9999 "));
		SINGLETON.register("91M", new SequencePattern("PURPLE HRT M/C PLT",
				"IIIIAASS", "9300PH ", "9599PH "));
		SINGLETON.register("91M", new SequencePattern("PURPLE HRT M/C PLT",
				"IIIIAASS", "9900PH ", "9999PH "));
		SINGLETON.register("91N", new SequencePattern("PURPLE HRT M/C PLT",
				"AAIIIISS", "PH8000 ", "PH8999 "));
		//		SINGLETON.register("920", new SequencePattern("MEDAL HONOR PLT",
		//				"SAAAAIIS", " CMO 01", " CMO 99"));
		//		SINGLETON.register("93R", new SequencePattern("REFL HAM PLATE",
		//				"SXXXXXXS", " ", " "));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSSZIS", " A    1", " A   99"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSSZIS", " C    1", " C   99"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSSZIS", " S    1", " S   99"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " A   1A", " A  99A"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " A   1B", " A  99B"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " A   1R", " A  99R"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASZIANS", " A  1R1", " A 99R9"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " C   1A", " C  99A"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " C   1B", " C  99B"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASZIANS", " C  1R1", " C 99R9"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " S   1S", " S  99S"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASZIANS", " S  1R1", " S 99R9"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASZIANS", " A  1R1", " A 99R1"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " C   1R", " C  99R"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASZIANS", " S  1S1", " S 99S1"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SASSZIAS", " S   1R", " S  99R"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SAASSSIS", " US   1", " US   2"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SAASSIAS", " US  1A", " US  2A"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SAASSIAS", " US  1B", " US  2B"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SAASSIAS", " US  1R", " US  9R"));
		SINGLETON.register("94R", new SequencePattern("REFL LEGIS PLATE",
				"SAASIANS", " US 1R1", " US 9R1"));
		SINGLETON.register("950", new SequencePattern("TEMP ID #", "AIIIIIIS",
				"P000000", "Z999999"));
		SINGLETON.register("951", new SequencePattern("TEMP ID #", "IIIIIIAS",
				"000001P", "999999P"));
		SINGLETON.register("951", new SequencePattern("TEMP ID #", "IIIIIIAS",
				"000001R", "999999Y"));
		SINGLETON.register("960", new SequencePattern("INVALID CODE",
				"AAIIISSS", "CN100  ", "CN999  "));
		SINGLETON.register("970", new SequencePattern("DATA ENTRY RECPT",
				"IIIIIIII", "00000000", "07999999"));
		SINGLETON.register("971", new SequencePattern("DATA ENTRY RCPT AC",
				"IIIIIIII", "08000000", "99999999"));
		SINGLETON.register("980", new SequencePattern("LEGION VALOR PLT",
				"AAIIISSS", "LV000  ", "LV999  "));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " APA000", " APA999"));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " APU000", " APU999"));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " BAH000", " BAH999"));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " BAK000", " BAK999"));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " BAR000", " BAR999"));
		SINGLETON.register("C01", new SequencePattern("COLLEGIATE PLT",
				"SAAAIIIS", " BEG000", " BEG999"));
		SINGLETON.register("C11", new SequencePattern("COLLEGIATE PLT",
				"SIIIAAAS", " 000GYP", " 999GYP"));
		SINGLETON.register("E10", new SequencePattern("COML PERMIT TRACTOR",
				"IIIIIIIS", "7987001", "9999999"));
		SINGLETON.register("E11", new SequencePattern("LADEN TRLR PERMIT",
				"IIIIIISS", "000000", "999999"));
		SINGLETON.register("E1T", new SequencePattern("COML PERMIT TRLR",
				"IIIIIIIS", "0000001", "9999999"));
		SINGLETON.register("E23", new SequencePattern("USE FUEL TAX PERMIT",
				"IIIIIISS", "000000", "999999"));
		SINGLETON.register("E24", new SequencePattern("USE FUEL TAX PERMIT",
				"IIIIIIIS", "0000000", "9999999"));
		SINGLETON.register("E27", new SequencePattern("ONE TRIP PERMIT",
				"IIIIIIIS", "1000000", "9999999"));
		SINGLETON.register("E2T", new SequencePattern("COML PERMIT TRLR",
				"IIIIIIII", "10000000", "29999999"));
		SINGLETON.register("E33", new SequencePattern("OL-33", "IIIIIISS",
				"000000", "999999"));
		SINGLETON.register("E41", new SequencePattern("'1'  COMMUTER STKR",
				"AIIIIISS", "A00001 ", "A99999 "));
		SINGLETON.register("E41", new SequencePattern("'1'  COMMUTER STKR",
				"AIIIIISS", "J00001 ", "J99999 "));
		SINGLETON.register("E43", new SequencePattern("'3'  COMMUTER STKR",
				"AIIIIISS", "D00000 ", "D99999 "));
		SINGLETON.register("E43", new SequencePattern("'3'  COMMUTER STKR",
				"AIIIIISS", "K00001 ", "K99999 "));
		SINGLETON.register("E45", new SequencePattern("'5'  COMMUTER STKR",
				"AIIIIISS", "B00001 ", "B99999 "));
		SINGLETON.register("E45", new SequencePattern("'5'  COMMUTER STKR",
				"AIIIIISS", "F00000 ", "F99999 "));
		SINGLETON.register("E47", new SequencePattern("'7'  COMMUTER STKR",
				"AIIIIISS", "C00001 ", "C99999 "));
		SINGLETON.register("E47", new SequencePattern("'7'  COMMUTER STKR",
				"AIIIIISS", "G00000 ", "G99999 "));
		SINGLETON.register("E49", new SequencePattern("'9'  COMMUTER STKR",
				"AIIIIISS", "E00001 ", "E99999 "));
		SINGLETON.register("E49", new SequencePattern("'9'  COMMUTER STKR",
				"AIIIIISS", "H00001 ", "H99999 "));
		SINGLETON.register("E71", new SequencePattern("TMP COML REG/PERMIT",
				"IIIIIISS", "000001", "999999"));
		SINGLETON.register("E72", new SequencePattern("TEMP COML REG",
				"IIIIIISS", "000001", "999999"));
		SINGLETON.register("E89", new SequencePattern("NON REPAIRABLE CERT",
				"IIIIIIIS", "0000001", "9999999"));
		SINGLETON.register("E90", new SequencePattern("SALVAGE CERT",
				"IIIIIIIS", "0000000", "9999999"));
		SINGLETON.register("H13", new SequencePattern("OHV MC TRANS PERMT",
				"IIIIISSS", "00000", "99999"));
	}

	/** The map. */
	private Map <String, ISequencePattern> map;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory#getKnownCodes()
	 */
	public List <String> getKnownCodes() {
		List <String> aList = new ArrayList <String>(size());
		aList.addAll(getMap().keySet());
		return aList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory#getKnownSequencePatterns()
	 */
	public List <ISequencePattern> getKnownSequencePatterns() {
		List <ISequencePattern> aList = new ArrayList <ISequencePattern>(size());
		aList.addAll(getMap().values());
		return aList;
	}

	/**
	 * Gets the map.
	 * 
	 * @return the map
	 */
	protected Map <String, ISequencePattern> getMap() {
		if (map == null) {
			setMap(new HashMap <String, ISequencePattern>());
		}
		return map;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory#getSequencePatternForCode(java.lang.String)
	 */
	public ISequencePattern getSequencePatternForCode(String aCode) {
		int count = 1;
		ISequencePattern aPattern;
		do {
			aPattern = getMap().get(aCode);
		}
		while ((aPattern == null) && (count++ < MAX_TRIES));
		if (aPattern == null) {
			throw new SequencePatternException("ITEM CODE '" + aCode
					+ "' NOT AVAILABLE");
		}
		else {
			return aPattern;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory#getSequencePatternForCode(java.lang.String, java.lang.String, java.lang.String)
	 */
	public ISequencePattern getSequencePatternForCode(String aCode,
			String aLowerBoundary, String anUpperBoundary) {
		ISequencePattern aPatternPrototype = getSequencePatternForCode(aCode);
		//public SequencePattern(String aDesc, String aPatternValue,String aSeqStart, String aSeqEnd) {
		if (EaseUtil.isNullOrBlank(anUpperBoundary)
				&& !EaseUtil.isNullOrBlank(aLowerBoundary)) {
			anUpperBoundary = aPatternPrototype.getUpperSequenceBoundary();
		}
		SequencePattern aPattern = new SequencePattern(aPatternPrototype
				.getDescription(), aPatternPrototype.getValue(),
				aLowerBoundary, anUpperBoundary);
		return aPattern;
	}

	/**
	 * Register.
	 * 
	 * @param aCode the a code
	 * @param aPattern the a pattern
	 */
	public void register(String aCode, ISequencePattern aPattern) {
		getMap().put(aCode, aPattern);
	}

	/**
	 * Sets the map.
	 * 
	 * @param aMap the a map
	 */
	protected void setMap(Map <String, ISequencePattern> aMap) {
		map = aMap;
	}

	/**
	 * Size.
	 * 
	 * @return the int
	 */
	public int size() {
		if (map == null || map.isEmpty()) {
			return 0;
		}
		else {
			return map.size();
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		int aSize = size();
		if (aSize == 0) {
			return getClass().getSimpleName() + "[ empty ]";
		}
		else {
			StringBuilder aBuilder = new StringBuilder(aSize * 16);
			aBuilder.append(getClass().getSimpleName()).append(" [ ");
			int index = 0;
			for (String aCode : getMap().keySet()) {
				index++;
				aBuilder.append("\n\t").append(index).append("\t");
				aBuilder.append(map.get(aCode));
			}
			aBuilder.append(" ]");
			return aBuilder.toString();
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequencePatternFactory.java,v $
 *  Revision 1.17  2011/11/29 19:58:49  mwkfh
 *  add retry to getSequencePatternForCode
 *
 *  Revision 1.16  2011/11/29 18:47:57  mwkfh
 *  updated getSequencePatternForCode exception
 *
 *  Revision 1.15  2011/10/27 18:21:27  mwkfh
 *  updated description for item code 465
 *
 *  Revision 1.14  2011/03/18 17:25:19  mwkfh
 *  Added 000 sequence for use by inv assignments
 *
 *  Revision 1.13  2011/01/19 18:56:41  mwrrv2
 *  Updated local inventory desc.
 *
 *  Revision 1.12  2011/01/18 17:50:07  mwrrv2
 *  Updated Item desc.
 *
 *  Revision 1.11  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.9.4.1  2010/12/23 03:13:55  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.10  2010/12/22 18:27:03  mwrrv3
 *  Changed the description of item code 480 and 481.
 *
 *  Revision 1.9  2010/12/14 22:06:18  mwkfh
 *  changed pattern for type 431
 *
 *  Revision 1.8  2010/12/07 00:18:08  mwkfh
 *  updated getSequencePatternForCode
 *
 *  Revision 1.7  2010/12/04 20:06:56  mwkfh
 *  updated getSequencePatternForCode to use prototype upper bound if real one is blank
 *
 *  Revision 1.6  2010/10/29 17:27:26  mwkfh
 *  added proceeding zeros and commented out two invalid patterns
 *
 *  Revision 1.5  2010/10/14 23:26:35  mwkfh
 *  removed deprecated getSequencePatternForCode
 *
 *  Revision 1.4  2010/10/14 17:19:20  mwkfh
 *  updated constructors
 *
 *  Revision 1.3  2010/10/08 01:54:06  mwpxp2
 *  Added getSequencePatternForCode/3
 *
 *  Revision 1.2  2010/09/08 00:35:07  mwpxp2
 *  Added getKnownCodes/0; unit tests ok
 *
 *  Revision 1.1  2010/09/07 22:59:36  mwpxp2
 *  Initial; untested
 *
 */
