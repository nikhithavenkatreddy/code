/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import static gov.ca.dmv.ease.app.constants.IApplicationPendingCodeConstants.DL_AND_ID_PENDING;
import static gov.ca.dmv.ease.app.constants.IApplicationPendingCodeConstants.DL_PENDING;
import static gov.ca.dmv.ease.app.constants.IApplicationPendingCodeConstants.ID_PENDING;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import gov.ca.dmv.ease.app.constants.IPhotoRequiredCodeConstants;
import gov.ca.dmv.ease.bo.application.IssuanceReferralMessagesType;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.IPrintDocumentHistory;
import gov.ca.dmv.ease.bo.financial.impl.ApplicableFee;
import gov.ca.dmv.ease.bo.financial.impl.Invoice;
import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.bo.license.CnaConditionType;
import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.bo.tx.IProcessHistory;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/** 
 * Description: Application class is the child of Document and superclass 
 * of all types of applications (DL Application, VR Application, etc...)
 * File: Application.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 28, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.67 $
 * Last Changed: $Date: 2012/08/15 16:16:26 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class Application extends BaseBusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1728364620331286178L;
	/** The Constant PHOTO_REQUIRED_CODE_Y. */
	private static final CodeSetElement PHOTO_REQUIRED_CODE_Y = new CodeSetElement(
			"Y", "Y", "Y");
	/** The Application Date represents current/system date i.e. real date of the server. For pending 
	 * transactions Original Application Date is returned from the Back End in the pending segment of DLA/DLI TCode response.
	 */
	private Date applicationDate;
	/** The application number. DL#44/BarCode number. */
	private String applicationNumber;
	/** The Application Pending Indicator (D = DL; I = ID; B = BOTH). */
	private CodeSetElement applicationPendingIndicatorCode;
	/** The Application Type Code (A, B, G, H, J and Z)). Prefix of the DL44/BarCode */
	private CodeSetElement applicationType;
	/** The application types like Renewal/Correction/Pending. */
	private CodeSetElement applicationTypeCode;
	/** This is the Application Text to Display on UI/Print Documents. */
	private String applicationTypeText;
	/** The manager password. //FIX ME - questionable field */
	private String authorizingPassword;
	/** Holds CNA conditions. */
	private List <CnaConditionType> cnaConditions;
	/** The control cashier seq number. */
	private Integer controlCashierSeqNumber;
	/** This is the date & time that the application writes to the DAF.  Used to calculate CDA processing time. */
	private Date dafSaveTime;
	/** The Data Entry Receipt Code. Holds Data Entry Receipt Entry Number */
	private String dataEntryReceiptNumber;
	/** The data entry receipt type code. */
	private CodeSetElement dataEntryReceiptTypeCode;
	/** This represents the current system date in counter mode or the 6 position payment date. */
	private Date dateFeePaidOverride;
	/** The List of all non supporting documents - documents to be printed during transaction. */
	private List <Document> documents;
	/** The is fee reason needed. */
	private String feeReasonNeeded;
	/** The Reason Code for Fee Required Value. */
	private CodeSetElement feeRequiredReasonCode;
	/** The Invoice Information. */
	private Invoice invoice;
	/** The is address correction only. */
	private Boolean isAddressCorrectionOnly;
	/** The Indicator for Fee Required. */
	private Boolean isFeeRequired = Boolean.TRUE;
	/** The is fee required system generated. */
	private Boolean isFeeRequiredSystemGenerated = Boolean.TRUE;
	/** Is inventory auto assignment made, used in BCTR, bridge call for cashier transaction record. */
	private Boolean isInventoryAutoAssignmentMade = Boolean.FALSE;
	/** Is inventory auto assignment required, used in BCTR, bridge call for cashier transaction record.  */
	private Boolean isInventoryAutoAssignmentRequired = Boolean.FALSE;
	/** The List of Issuance Referral Messages. This holds the list of messages
	 *  to be printed on the Issuance Referral Document. Issuance referrals are 
	 *  set for certain conditions when issuing a DL , Identification Card or a 
	 *  Salesperson License. In several circumstances, the incomplete 
	 *  application reason code is set due to the Issuance Referral code. */
	private List <IssuanceReferralMessagesType> issuanceReferralMessages;
	/** The DL 44 Bar Code Number. TODO - Do we need this? applicationNumber - represents DL#44. */
	private String microGraphicsNumber;
	/** The photo required code for DL application. */
	private CodeSetElement photoRequiredCode = PHOTO_REQUIRED_CODE_Y;
	/** The previous photo required, derived from photoTakenType and photoTypeOnFile. */
	private CodeSetElement previousPhotoRequired;
	/** This is same as work date. For Manual or Postal or Travel Crew mode this could be change by technician. */
	private Date processDate;
	/** The Process History Information. */
	private List <IProcessHistory> processHistoryList;
	/** The System Date represents the date on which transaction was processed. */
	private Date systemDate = new Date();
	/** The List of Action Messages. This holds the list of messages determined on the Headquarters Inquiry response process.*/
	private List <String> actionMessages;
	/** The original type transaction code. This is the original TTC which returned in the HQ Inquiry response.*/
	private String originalTypeTransactionCode;// this is the original ttc coming from DLA tcode
	/** The applicable fee list. */
	private List <ApplicableFee> applicableFeeList;
	/** DL Renew, vision only, completed CDA, photo not taken. */
	private boolean thirdRbmConditionSatisfied;
	/** Print Document History for this TTC. */
	private IPrintDocumentHistory printDocumentHistory;
	/**Application Office Id only for issuance offices.*/
	private String appOfficeId;
	/** The application office issuance. */
	private boolean appOfficeIssuance;
	/** The Applicant. */
	private Person applicant;
	
	/**
	 * Instantiates a new application.
	 */
	public Application() {
		super();
	}
	
	/**
	 * Adds the application document.
	 * 
	 * @param applicationDocument the application document
	 */
	public void addApplicationDocument(Document applicationDocument) {
		//fixme - misplaced code - belong to the lazy getter
		//		if (EaseUtil.isNullOrBlank(this.documents)) {
		//			setDocuments(new ArrayList <Document>());
		//		}
		//		this.documents.add(applicationDocument);
		getDocuments().add(applicationDocument);
	}
	
	/**
	 * Adds the CNA condition type to the list.
	 * 
	 * @param cnaConditionType the cna condition type
	 */
	public void addCnaCondition(CnaConditionType cnaConditionType) {
		//misplaced code
		//		this.cnaConditions.add(cnaConditionType);
		getCnaConditions().add(cnaConditionType);
	}
	
	/**
	 * Adds the issuance referral message.
	 * 
	 * @param issuanceReferralMessagesType the issuance referral messages type
	 */
	public void addIssuanceReferralMessage(
			IssuanceReferralMessagesType issuanceReferralMessagesType) {
		//Troubled code to check if a message type is alredy there
		//		boolean addMessage = true;
		//		if (!EaseUtil.isNotNull(this.getIssuanceReferralMessages())) {
		//			this.issuanceReferralMessages = new ArrayList <IssuanceReferralMessagesType>();
		//		}
		//		for (IssuanceReferralMessagesType issuanceReferralMessage : this
		//				.getIssuanceReferralMessages()) {
		//			//Check if message already exists.
		//			if (issuanceReferralMessage == issuanceReferralMessagesType) {
		//				addMessage = false;
		//				break;
		//			}
		//		}
		//		if (addMessage) {
		//			//If message does not exist in the list then add it.
		//			this.issuanceReferralMessages.add(issuanceReferralMessagesType);
		//		}
		if (!hasIssuanceReferralMessage(issuanceReferralMessagesType)) {
			getIssuanceReferralMessages().add(issuanceReferralMessagesType);
		}
	}
	
	/**
	 * Adds the Process History to the list.
	 * 
	 * @param processHistory the process history
	 */
	public void addProcessHistory(IProcessHistory processHistory) {
		getProcessHistory().add(processHistory);
	}
	
	/**
	 * Clears all the cna conditions from the list.
	 */
	public void clearAllCnaConditions() {
		getCnaConditions().clear();
	}
	
	/**
	 * Gets the applicable fee list.
	 *
	 * @return the applicable fee list
	 */
	public List <ApplicableFee> getApplicableFeeList() {
		return applicableFeeList;
	}
	
	/**
	 * Sets the applicable fee list.
	 *
	 * @param applicableFeeList the new applicable fee list
	 */
	public void setApplicableFeeList(List <ApplicableFee> applicableFeeList) {
		this.applicableFeeList = applicableFeeList;
	}
	
	/**
	 * Checks if is fee rate code exist.
	 *
	 * @return true, if is fee rate code exist
	 */
	public boolean isFeeRateCodeExist() {
		List <ApplicableFee> generatedApplicableFeeList = getApplicableFeeList();
		if (!EaseUtil.isNullOrBlank(generatedApplicableFeeList)) {
			for (ApplicableFee applicableFee : generatedApplicableFeeList) {
				if (!EaseUtil.isNullOrBlank(applicableFee)
						&& !EaseUtil.isNullOrBlank(applicableFee.getFeeCode())) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Gets the action messages.
	 * 
	 * @return the actionMessages
	 */
	public List <String> getActionMessages() {
		if (actionMessages == null) {
			setActionMessages(new ArrayList <String>());
		}
		return actionMessages;
	}
	
	/**
	 * Gets the Application Date.
	 * 
	 * @return the applicationDate
	 */
	public Date getApplicationDate() {
		return applicationDate;
	}
	
	/**
	 * Gets the application number.
	 * 
	 * @return the applicationNumber
	 */
	public String getApplicationNumber() {
		return applicationNumber;
	}
	
	/**
	 * Gets the Pending Indicator Code.
	 * 
	 * @return the applicationPendingIndicatorCode
	 */
	public CodeSetElement getApplicationPendingIndicatorCode() {
		//FIXME - this should not be a public method - use a boolean return method
		// like hasDlApplicationPendingCode, etc.
		return applicationPendingIndicatorCode;
	}
	
	/**
	 * Gets the application type.
	 * 
	 * @return the applicationType
	 */
	public CodeSetElement getApplicationType() {
		//FIXME - CodeSetElement should not be public return type
		return applicationType;
	}
	
	/**
	 * Gets the Application Type Code.
	 * 
	 * @return the applicationTypeCode
	 */
	public CodeSetElement getApplicationTypeCode() {
		//FIXME - CodeSetElement should not be public return type
		return applicationTypeCode;
	}
	
	/**
	 * Gets the Application Type Text.
	 * 
	 * @return the applicationTypeText
	 */
	public String getApplicationTypeText() {
		return applicationTypeText;
	}
	
	/**
	 * Sets the Manager Password.
	 * 
	 * @return the authorizingPassword
	 */
	public String getAuthorizingPassword() {
		return authorizingPassword;
	}
	
	/**
	 * Gets the cna conditions.
	 * 
	 * @return the cna conditions
	 */
	public List <CnaConditionType> getCnaConditions() {
		if (cnaConditions == null) {
			setCnaConditions(new ArrayList <CnaConditionType>());
		}
		return cnaConditions;
	}
	
	/**
	 * Gets the control cashier seq number.
	 *
	 * @return the control cashier seq number
	 */
	public Integer getControlCashierSeqNumber() {
		return controlCashierSeqNumber;
	}
	
	/**
	 * Gets the dafSaveTime.
	 * 
	 * @return the dafSaveTime
	 */
	public Date getDafSaveTime() {
		return dafSaveTime;
	}
	
	/**
	 * Gets the data entry receipt number.
	 * 
	 * @return the dataEntryReceiptNumber
	 */
	public String getDataEntryReceiptNumber() {
		return dataEntryReceiptNumber;
	}
	
	/**
	 * Gets the data entry receipt type code.
	 * 
	 * @return the dataEntryReceiptTypeCode
	 */
	public CodeSetElement getDataEntryReceiptTypeCode() {
		//FIXME - CodeSetElement should not be public return type
		return dataEntryReceiptTypeCode;
	}
	
	/**
	 * Gets the date fee paid override.
	 * 
	 * @return the dateFeePaidOverride
	 */
	public Date getDateFeePaidOverride() {
		return dateFeePaidOverride;
	}
	
	/**
	 * Gets the Documents.
	 * 
	 * @return the documents
	 */
	public List <Document> getDocuments() {
		if (documents == null) {
			setDocuments(new ArrayList <Document>());
		}
		return documents;
	}
	
	/**
	 * Gets the fee reason needed.
	 *
	 * @return the fee reason needed
	 */
	public String getFeeReasonNeeded() {
		return feeReasonNeeded;
	}
	
	/**
	 * Gets the Fee Required Reason Code.
	 * 
	 * @return the feeRequiredReasonCode
	 */
	public CodeSetElement getFeeRequiredReasonCode() {
		//FIXME - CodeSetElement should not be public return type
		return feeRequiredReasonCode;
	}
	
	/**
	 * Gets the Invoice Information.
	 * 
	 * @return the invoice
	 */
	public Invoice getInvoice() {
		return invoice;
	}
	
	/**
	 * Gets the checks if is address correction only.
	 * 
	 * @return the checks if is address correction only
	 */
	protected Boolean getIsAddressCorrectionOnly() {
		return isAddressCorrectionOnly;
	}
	
	/**
	 * Gets the issuance referral messages.
	 * 
	 * @return the issuance referral messages
	 */
	public List <IssuanceReferralMessagesType> getIssuanceReferralMessages() {
		if (issuanceReferralMessages == null) {
			setIssuanceReferralMessages(new ArrayList <IssuanceReferralMessagesType>());
		}
		return issuanceReferralMessages;
	}
	
	/**
	 * Gets the Micro Graphics Number.
	 * 
	 * @return the microGraphicsNumber
	 */
	public String getMicroGraphicsNumber() {
		return microGraphicsNumber;
	}
	
	/**
	 * Gets the original process history.
	 * 
	 * Original Process History represents the history of the process which started the transaction originally.
	 * This process information is received from the back-end as a part of the initial DL# inquiry or in case of a
	 * brand new application this process information holds the information keyed during DLA process.
	 * 
	 * @return the original process history
	 */
	public IProcessHistory getOriginalProcessHistory() {
		if (processHistoryList == null || processHistoryList.isEmpty()) {
			// If there is no process history the caller expects a null.
			return null;
		}
		else {
			if (getProcessHistory().size() > 0) {
				//FIXME - the code is cryptic and unmaintainable - separate into two distinct instance variables:
				//one for the original, one for the current
				// Return the first element which is the in the OriginalProcessHistory from array.
				return getProcessHistory().get(0);
			}
		}
		//TODO - returning null in this case is questionable - exception would be better
		return null;
	}
	
	/**
	 * This method returns the original ttc from process history.
	 *
	 * @return String the original ttc from process history
	 */
	public String getOriginalTtcFromProcessHistory() {
		IProcessHistory processHistory = getOriginalProcessHistory();
		if (EaseUtil.isNotNull(processHistory)
				&& EaseUtil.isNotNull(processHistory.getUserContext())) {
			return processHistory.getUserContext().getTtc();
		}
		return null;
	}
	
	/**
	 * Gets the original type transaction code.
	 * 
	 * @return the originalTypeTransactionCode
	 */
	public String getOriginalTypeTransactionCode() {
		return originalTypeTransactionCode;
	}
	
	/**
	 * Gets the photo required code.
	 *
	 * @return the photoRequiredCode
	 */
	public CodeSetElement getPhotoRequiredCode() {
		return photoRequiredCode;
	}
	
	/**
	 * Checks if is photo required.
	 *
	 * @return true, if is photo required
	 */
	public boolean isPhotoRequired() {
		if (!EaseUtil.isNullOrBlank(getPhotoRequiredCode())
				&& IPhotoRequiredCodeConstants.REQUIRED
						.equalsIgnoreCase(getPhotoRequiredCode().getCode())) {
			return true;
		}
		return false;
	}
	
	/**
	 * Gets the previous process history.
	 * 
	 * Previous Process History represents the history of the process which was processed in the TTC before processing TTC CDA.
	 * This represents the information of the driver record which was keyed/updated by the technician
	 * before processing TTC CDA.
	 * 
	 * @return the previous process history
	 */
	public IProcessHistory getPreviousProcessHistory() {
		if (processHistoryList == null || processHistoryList.isEmpty()) {
			// If there is no process history the caller expects a null.
			return null;
		}
		else {
			if (getProcessHistory().size() > 0) {
				//Both Original and Previous Process Histories are available.
				// Return the second element which is the in the PreviousProcessHistory from array.
				return getProcessHistory().get(getProcessHistory().size() - 1);
			}
		}
		//TODO - returning null in this case is questionable - exception would be better
		return null;
	}
	
	/**
	 * Gets the ttc from previous process history.
	 *
	 * @return the ttc from previous process history
	 */
	public String getTtcFromPreviousProcessHistory() {
		IProcessHistory previousProcessHistory = getPreviousProcessHistory();
		if (EaseUtil.isNotNull(previousProcessHistory)
				&& EaseUtil.isNotNull(previousProcessHistory.getUserContext())) {
			return previousProcessHistory.getUserContext().getTtc();
		}
		return null;
	}
	
	/**
	 * Gets the Process Date.
	 * 
	 * @return the processDate
	 */
	public Date getProcessDate() {
		return processDate;
	}
	
	/**
	 * Gets the Process History Information.
	 * Returns unmodifiable List.
	 * 
	 * @return the processHistoryList
	 */
	public List <IProcessHistory> getProcessHistory() {
		return getProcessHistoryList();
	}
	
	/**
	 * Gets the process history list.
	 * 
	 * @return the process history list
	 */
	public List <IProcessHistory> getProcessHistoryList() {
		if (processHistoryList == null) {
			setProcessHistoryList(new ArrayList <IProcessHistory>());
		}
		return processHistoryList;
	}
	
	/**
	 * Gets the System Date.
	 * 
	 * @return the systemDate
	 */
	public Date getSystemDate() {
		return systemDate;
	}
	
	/**
	 * Checks for issuance referral message.
	 * 
	 * @param issuanceReferralMessagesType the issuance referral messages type
	 * 
	 * @return true, if successful
	 */
	public boolean hasIssuanceReferralMessage(
			IssuanceReferralMessagesType issuanceReferralMessagesType) {
		//TODO - wouldn't be simpler to use a set instead of a list?
		if (issuanceReferralMessages == null
				|| issuanceReferralMessages.isEmpty()) {
			return false;
		}
		else {
			for (IssuanceReferralMessagesType issuanceReferralMessage : getIssuanceReferralMessages()) {
				if (issuanceReferralMessage == issuanceReferralMessagesType) {
					return true;
				}
			}
			return false;
		}
	}
	
	/**
	 * Checks if is address correction only.
	 * 
	 * @return the isAddressCorrectionOnly
	 */
	public Boolean isAddressCorrectionOnly() {
		return isAddressCorrectionOnly;
	}
	
	/**
	 * Checks if is application pending.
	 *
	 * @return true, if is application pending
	 */
	public boolean isApplicationPending() {
		if (!isNullOrBlank(getApplicationPendingIndicatorCode())
				&& getApplicationPendingIndicatorCode().hasCodeEqualToAnyOf(
						DL_PENDING, ID_PENDING, DL_AND_ID_PENDING)) {
			return true;
		}
		return false;
	}
	
	/**
	 * Gets the CNA Condition.
	 * 
	 * @return the cnaCondition
	 */
	public Boolean isCnaCondition() {
		//FIXME - method name is illegal
		//has~ would be better than is~
		return cnaConditions != null && !cnaConditions.isEmpty();
	}

	/**
	 * Checks if CNA (Communication Not Available) condition of given type is present.
	 * 
	 * @param cnaConditionType the CNA condition type
	 * 
	 * @return the boolean
	 */
	public Boolean isCnaCondition(CnaConditionType cnaConditionType) {
		//FIXME - method name is illegal
		if (isCnaCondition()) {
			List <CnaConditionType> allCnaConditions = getCnaConditions();
			for (CnaConditionType cnaCondition : allCnaConditions) {
				if (cnaCondition.equals(cnaConditionType)) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Gets the Fee Required Indicator.
	 * 
	 * @return the isFeeRequired
	 */
	public Boolean isFeeRequired() {
		return isFeeRequired;
	}
	
	/**
	 * Gets the checks if is fee required system generated.
	 *
	 * @return the isFeeRequiredSystemGenerated
	 */
	public Boolean getIsFeeRequiredSystemGenerated() {
		return isFeeRequiredSystemGenerated;
	}
	
	/**
	 * Checks if is inventory auto assignment made.
	 *
	 * @return the isInventoryAutoAssignmentMade
	 */
	public Boolean isInventoryAutoAssignmentMade() {
		return isInventoryAutoAssignmentMade;
	}
	
	/**
	 * Checks if is inventory auto assignment required.
	 *
	 * @return the isInventoryAutoAssignmentRequired
	 */
	public Boolean isInventoryAutoAssignmentRequired() {
		return isInventoryAutoAssignmentRequired;
	}
	
	/**
	 * Removes the matching CNA condition from the list.
	 * 
	 * @param cnaConditionType the CNA condition type to match
	 */
	public void removeCnaCondition(CnaConditionType cnaConditionType) {
		//TODO - having a set would be better here, as remove happens on equality
		for (int index = 0; index < getCnaConditions().size(); index++) {
			CnaConditionType aCnaConditionType = cnaConditions.get(index);
			if (aCnaConditionType.equals(cnaConditionType)) {
				cnaConditions.remove(index);
				break;
			}
		}
	}
	
	/**
	 * Removes the issuance referral message.
	 *
	 * @param aType the a type
	 */
	public void removeIssuanceReferralMessage(IssuanceReferralMessagesType aType) {
		if (issuanceReferralMessages != null
				&& !issuanceReferralMessages.isEmpty()) {
			issuanceReferralMessages.remove(aType);
		}
	}
	
	/**
	 * Sets the action messages.
	 * 
	 * @param actionMessages the actionMessages to set
	 */
	public void setActionMessages(List <String> actionMessages) {
		if (actionMessages == null) {
			setActionMessages(new ArrayList <String>());
		}
		this.actionMessages = actionMessages;
	}
	
	/**
	 * Sets the address correction only.
	 * 
	 * @param isAddressCorrectionOnly the isAddressCorrectionOnly to set
	 */
	public void setAddressCorrectionOnly(Boolean isAddressCorrectionOnly) {
		this.isAddressCorrectionOnly = isAddressCorrectionOnly;
	}
	
	/**
	 * Sets the Application Date.
	 * 
	 * @param applicationDate the applicationDate to set
	 */
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	
	/**
	 * Sets the application number.
	 * 
	 * @param applicationNumber the applicationNumber to set
	 */
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	
	/**
	 * Sets the Pending Indicator Code.
	 * 
	 * @param applicationPendingIndicatorCode the applicationPendingIndicatorCode to set
	 */
	public void setApplicationPendingIndicatorCode(
			CodeSetElement applicationPendingIndicatorCode) {
		//FIXME - settign of the flag should not happen by using a CodeSetElement 
		this.applicationPendingIndicatorCode = applicationPendingIndicatorCode;
	}
	
	/**
	 * Sets the application type.
	 * 
	 * @param applicationType the applicationType to set
	 */
	public void setApplicationType(CodeSetElement applicationType) {
		//FIXME - settign of the flag should not happen by using a CodeSetElement 
		this.applicationType = applicationType;
	}
	
	/**
	 * Sets the Application Type Code.
	 * 
	 * @param applicationTypeCode the applicationTypeCode to set
	 */
	public void setApplicationTypeCode(CodeSetElement applicationTypeCode) {
		//FIXME - settign of the flag should not happen by using a CodeSetElement 
		this.applicationTypeCode = applicationTypeCode;
	}
	
	/**
	 * Sets the Application Type Text.
	 * 
	 * @param applicationTypeText the applicationTypeText to set
	 */
	public void setApplicationTypeText(String applicationTypeText) {
		this.applicationTypeText = applicationTypeText;
	}
	
	/**
	 * Gets the Manager Password.
	 * 
	 * @param managerPassword the manager password
	 */
	public void setAuthorizingPassword(String managerPassword) {
		this.authorizingPassword = managerPassword;
	}
	
	/**
	 * Sets the cna conditions.
	 *
	 * @param aList the new cna conditions
	 */
	public void setCnaConditions(List <CnaConditionType> aList) {
		cnaConditions = aList;
	}
	
	/**
	 * Sets the control cashier seq number.
	 *
	 * @param controlCashierSeqNumber the new control cashier seq number
	 */
	public void setControlCashierSeqNumber(Integer controlCashierSeqNumber) {
		this.controlCashierSeqNumber = controlCashierSeqNumber;
	}
	
	/**
	 * Sets the dafSaveTime to the current time.
	 */
	public void setDafSaveTime() {
		this.dafSaveTime = CurrentDateProvider.getInstance().getSystemDate();
	}
	
	/**
	 * Sets the dafSaveTime.
	 * 
	 * @param dafSaveTime the dafSaveTime to set
	 */
	public void setDafSaveTime(Date dafSaveTime) {
		this.dafSaveTime = dafSaveTime;
	}
	
	/**
	 * Sets the data entry receipt number.
	 * 
	 * @param dataEntryReceiptNumber the dataEntryReceiptNumber to set
	 */
	public void setDataEntryReceiptNumber(String dataEntryReceiptNumber) {
		this.dataEntryReceiptNumber = dataEntryReceiptNumber;
	}
	
	/**
	 * Sets the data entry receipt type code.
	 * 
	 * @param dataEntryReceiptTypeCode the dataEntryReceiptTypeCode to set
	 */
	public void setDataEntryReceiptTypeCode(
			CodeSetElement dataEntryReceiptTypeCode) {
		//FIXME - settign of the flag should not happen by using a CodeSetElement 
		this.dataEntryReceiptTypeCode = dataEntryReceiptTypeCode;
	}
	
	/**
	 * Sets the date fee paid override.
	 * 
	 * @param dateFeePaidOverride the dateFeePaidOverride to set
	 */
	public void setDateFeePaidOverride(Date dateFeePaidOverride) {
		this.dateFeePaidOverride = dateFeePaidOverride;
	}
	
	/**
	 * Sets the Documents.
	 * 
	 * @param documents the documents to set
	 */
	public void setDocuments(List <Document> documents) {
		this.documents = documents;
	}
	
	/**
	 * Sets the fee reason needed.
	 *
	 * @param feeReasonNeeded the new fee reason needed
	 */
	public void setFeeReasonNeeded(String feeReasonNeeded) {
		this.feeReasonNeeded = feeReasonNeeded;
	}
	
	/**
	 * Sets the Fee Required Indicator.
	 * 
	 * @param isFeeRequired the isFeeRequired to set
	 */
	public void setFeeRequired(Boolean isFeeRequired) {
		this.isFeeRequired = isFeeRequired;
	}
	
	/**
	 * Sets the Fee Required Reason Code.
	 * 
	 * @param feeRequiredReasonCode the feeRequiredReasonCode to set
	 */
	public void setFeeRequiredReasonCode(CodeSetElement feeRequiredReasonCode) {
		this.feeRequiredReasonCode = feeRequiredReasonCode;
	}
	
	/**
	 * Sets the Invoice Information.
	 * 
	 * @param invoice the invoice to set
	 */
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	
	/**
	 * Sets the checks if is address correction only.
	 * 
	 * @param isAddressCorrectionOnly the new checks if is address correction only
	 */
	protected void setIsAddressCorrectionOnly(Boolean isAddressCorrectionOnly) {
		this.isAddressCorrectionOnly = isAddressCorrectionOnly;
	}
	
	/**
	 * Sets the checks if is fee required.
	 * 
	 * @param isFeeRequired the new checks if is fee required
	 */
	protected void setIsFeeRequired(Boolean isFeeRequired) {
		this.isFeeRequired = isFeeRequired;
	}
	
	/**
	 * Sets the checks if is fee required system generated.
	 *
	 * @param isFeeRequiredSystemGenerated the isFeeRequiredSystemGenerated to set
	 */
	public void setIsFeeRequiredSystemGenerated(
			Boolean isFeeRequiredSystemGenerated) {
		this.isFeeRequiredSystemGenerated = isFeeRequiredSystemGenerated;
	}
	
	/**
	 * Sets the checks if is inventory auto assignment made.
	 *
	 * @param isInventoryAutoAssignmentMade the isInventoryAutoAssignmentMade to set
	 */
	public void setIsInventoryAutoAssignmentMade(
			Boolean isInventoryAutoAssignmentMade) {
		this.isInventoryAutoAssignmentMade = isInventoryAutoAssignmentMade;
	}
	
	/**
	 * Sets the checks if is inventory auto assignment required.
	 *
	 * @param isInventoryAutoAssignmentRequired the isInventoryAutoAssignmentRequired to set
	 */
	public void setIsInventoryAutoAssignmentRequired(
			Boolean isInventoryAutoAssignmentRequired) {
		this.isInventoryAutoAssignmentRequired = isInventoryAutoAssignmentRequired;
	}
	
	/**
	 * Sets the issuance referral messages.
	 *
	 * @param aList the new issuance referral messages
	 */
	public void setIssuanceReferralMessages(
			List <IssuanceReferralMessagesType> aList) {
		issuanceReferralMessages = aList;
	}
	
	/**
	 * Sets the Micro Graphics Number.
	 * 
	 * @param microGraphicsNumber the microGraphicsNumber to set
	 */
	public void setMicroGraphicsNumber(String microGraphicsNumber) {
		this.microGraphicsNumber = microGraphicsNumber;
	}
	
	/**
	 * Sets the original type transaction code.
	 * 
	 * @param originalTypeTransactionCode the originalTypeTransactionCode to set
	 */
	public void setOriginalTypeTransactionCode(
			String originalTypeTransactionCode) {
		this.originalTypeTransactionCode = originalTypeTransactionCode;
	}
	
	/**
	 * Sets the photo required code.
	 *
	 * @param photoRequiredCode the photoRequiredCode to set
	 */
	public void setPhotoRequiredCode(CodeSetElement photoRequiredCode) {
		this.photoRequiredCode = photoRequiredCode;
	}
	
	/**
	 * Sets the Process Date.
	 * 
	 * @param processDate the processDate to set
	 */
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
	
	/**
	 * Sets the process history.
	 * 
	 * @param processHistoryList the new process history
	 */
	public void setProcessHistory(List <IProcessHistory> processHistoryList) {
		this.processHistoryList = processHistoryList;
	}
	
	/**
	 * Sets the Process History Information.
	 * 
	 * @param aList the a list
	 */
	protected void setProcessHistoryList(List <IProcessHistory> aList) {
		this.processHistoryList = aList;
	}
	
	/**
	 * Gets the prints the document history.
	 *
	 * @return the prints the document history
	 */
	public IPrintDocumentHistory getPrintDocumentHistory() {
		return printDocumentHistory;
	}
	
	/**
	 * Sets the prints the document history.
	 *
	 * @param printDocumentHistory the new prints the document history
	 */
	public void setPrintDocumentHistory(
			IPrintDocumentHistory printDocumentHistory) {
		this.printDocumentHistory = printDocumentHistory;
	}
	
	/**
	 * Sets the System Date.
	 * 
	 * @param systemDate the systemDate to set
	 */
	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}
	
	/**
	 * Gets the thirdRbmConditionSatisfied.
	 *
	 * @return the thirdRbmConditionSatisfied
	 */
	public boolean isThirdRbmConditionSatisfied() {
		return thirdRbmConditionSatisfied;
	}
	
	/**
	 * Sets the thirdRbmConditionSatisfied.
	 *
	 * @param thirdRbmConditionSatisfied the thirdRbmConditionSatisfied to set
	 */
	public void setThirdRbmConditionSatisfied(boolean thirdRbmConditionSatisfied) {
		this.thirdRbmConditionSatisfied = thirdRbmConditionSatisfied;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((actionMessages == null) ? 0 : actionMessages.hashCode());
		result = prime * result
				+ ((appOfficeId == null) ? 0 : appOfficeId.hashCode());
		result = prime * result + (appOfficeIssuance ? 1231 : 1237);
		result = prime
				* result
				+ ((applicableFeeList == null) ? 0 : applicableFeeList
						.hashCode());
		result = prime * result
				+ ((applicationDate == null) ? 0 : applicationDate.hashCode());
		result = prime
				* result
				+ ((applicationNumber == null) ? 0 : applicationNumber
						.hashCode());
		result = prime
				* result
				+ ((applicationPendingIndicatorCode == null) ? 0
						: applicationPendingIndicatorCode.hashCode());
		result = prime * result
				+ ((applicationType == null) ? 0 : applicationType.hashCode());
		result = prime
				* result
				+ ((applicationTypeCode == null) ? 0 : applicationTypeCode
						.hashCode());
		result = prime
				* result
				+ ((applicationTypeText == null) ? 0 : applicationTypeText
						.hashCode());
		result = prime
				* result
				+ ((authorizingPassword == null) ? 0 : authorizingPassword
						.hashCode());
		result = prime * result
				+ ((cnaConditions == null) ? 0 : cnaConditions.hashCode());
		result = prime
				* result
				+ ((controlCashierSeqNumber == null) ? 0
						: controlCashierSeqNumber.hashCode());
		result = prime * result
				+ ((dafSaveTime == null) ? 0 : dafSaveTime.hashCode());
		result = prime
				* result
				+ ((dataEntryReceiptNumber == null) ? 0
						: dataEntryReceiptNumber.hashCode());
		result = prime
				* result
				+ ((dataEntryReceiptTypeCode == null) ? 0
						: dataEntryReceiptTypeCode.hashCode());
		result = prime
				* result
				+ ((dateFeePaidOverride == null) ? 0 : dateFeePaidOverride
						.hashCode());
		result = prime * result
				+ ((documents == null) ? 0 : documents.hashCode());
		result = prime * result
				+ ((feeReasonNeeded == null) ? 0 : feeReasonNeeded.hashCode());
		result = prime
				* result
				+ ((feeRequiredReasonCode == null) ? 0 : feeRequiredReasonCode
						.hashCode());
		result = prime * result + ((invoice == null) ? 0 : invoice.hashCode());
		result = prime
				* result
				+ ((isAddressCorrectionOnly == null) ? 0
						: isAddressCorrectionOnly.hashCode());
		result = prime * result
				+ ((isFeeRequired == null) ? 0 : isFeeRequired.hashCode());
		result = prime
				* result
				+ ((isFeeRequiredSystemGenerated == null) ? 0
						: isFeeRequiredSystemGenerated.hashCode());
		result = prime
				* result
				+ ((isInventoryAutoAssignmentMade == null) ? 0
						: isInventoryAutoAssignmentMade.hashCode());
		result = prime
				* result
				+ ((isInventoryAutoAssignmentRequired == null) ? 0
						: isInventoryAutoAssignmentRequired.hashCode());
		result = prime
				* result
				+ ((issuanceReferralMessages == null) ? 0
						: issuanceReferralMessages.hashCode());
		result = prime
				* result
				+ ((microGraphicsNumber == null) ? 0 : microGraphicsNumber
						.hashCode());
		result = prime
				* result
				+ ((originalTypeTransactionCode == null) ? 0
						: originalTypeTransactionCode.hashCode());
		result = prime
				* result
				+ ((photoRequiredCode == null) ? 0 : photoRequiredCode
						.hashCode());
		result = prime
				* result
				+ ((previousPhotoRequired == null) ? 0 : previousPhotoRequired
						.hashCode());
		result = prime
				* result
				+ ((printDocumentHistory == null) ? 0 : printDocumentHistory
						.hashCode());
		result = prime * result
				+ ((processDate == null) ? 0 : processDate.hashCode());
		result = prime
				* result
				+ ((processHistoryList == null) ? 0 : processHistoryList
						.hashCode());
		result = prime * result
				+ ((systemDate == null) ? 0 : systemDate.hashCode());
		result = prime * result + (thirdRbmConditionSatisfied ? 1231 : 1237);
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Application other = (Application) obj;
		if (actionMessages == null) {
			if (other.actionMessages != null)
				return false;
		}
		else if (!actionMessages.equals(other.actionMessages))
			return false;
		if (appOfficeId == null) {
			if (other.appOfficeId != null)
				return false;
		}
		else if (!appOfficeId.equals(other.appOfficeId))
			return false;
		if (appOfficeIssuance != other.appOfficeIssuance)
			return false;
		if (applicableFeeList == null) {
			if (other.applicableFeeList != null)
				return false;
		}
		else if (!applicableFeeList.equals(other.applicableFeeList))
			return false;
		if (applicationDate == null) {
			if (other.applicationDate != null)
				return false;
		}
		else if (!applicationDate.equals(other.applicationDate))
			return false;
		if (applicationNumber == null) {
			if (other.applicationNumber != null)
				return false;
		}
		else if (!applicationNumber.equals(other.applicationNumber))
			return false;
		if (applicationPendingIndicatorCode == null) {
			if (other.applicationPendingIndicatorCode != null)
				return false;
		}
		else if (!applicationPendingIndicatorCode
				.equals(other.applicationPendingIndicatorCode))
			return false;
		if (applicationType == null) {
			if (other.applicationType != null)
				return false;
		}
		else if (!applicationType.equals(other.applicationType))
			return false;
		if (applicationTypeCode == null) {
			if (other.applicationTypeCode != null)
				return false;
		}
		else if (!applicationTypeCode.equals(other.applicationTypeCode))
			return false;
		if (applicationTypeText == null) {
			if (other.applicationTypeText != null)
				return false;
		}
		else if (!applicationTypeText.equals(other.applicationTypeText))
			return false;
		if (authorizingPassword == null) {
			if (other.authorizingPassword != null)
				return false;
		}
		else if (!authorizingPassword.equals(other.authorizingPassword))
			return false;
		if (cnaConditions == null) {
			if (other.cnaConditions != null)
				return false;
		}
		else if (!cnaConditions.equals(other.cnaConditions))
			return false;
		if (controlCashierSeqNumber == null) {
			if (other.controlCashierSeqNumber != null)
				return false;
		}
		else if (!controlCashierSeqNumber.equals(other.controlCashierSeqNumber))
			return false;
		if (dafSaveTime == null) {
			if (other.dafSaveTime != null)
				return false;
		}
		else if (!dafSaveTime.equals(other.dafSaveTime))
			return false;
		if (dataEntryReceiptNumber == null) {
			if (other.dataEntryReceiptNumber != null)
				return false;
		}
		else if (!dataEntryReceiptNumber.equals(other.dataEntryReceiptNumber))
			return false;
		if (dataEntryReceiptTypeCode == null) {
			if (other.dataEntryReceiptTypeCode != null)
				return false;
		}
		else if (!dataEntryReceiptTypeCode
				.equals(other.dataEntryReceiptTypeCode))
			return false;
		if (dateFeePaidOverride == null) {
			if (other.dateFeePaidOverride != null)
				return false;
		}
		else if (!dateFeePaidOverride.equals(other.dateFeePaidOverride))
			return false;
		if (documents == null) {
			if (other.documents != null)
				return false;
		}
		else if (!documents.equals(other.documents))
			return false;
		if (feeReasonNeeded == null) {
			if (other.feeReasonNeeded != null)
				return false;
		}
		else if (!feeReasonNeeded.equals(other.feeReasonNeeded))
			return false;
		if (feeRequiredReasonCode == null) {
			if (other.feeRequiredReasonCode != null)
				return false;
		}
		else if (!feeRequiredReasonCode.equals(other.feeRequiredReasonCode))
			return false;
		if (invoice == null) {
			if (other.invoice != null)
				return false;
		}
		else if (!invoice.equals(other.invoice))
			return false;
		if (isAddressCorrectionOnly == null) {
			if (other.isAddressCorrectionOnly != null)
				return false;
		}
		else if (!isAddressCorrectionOnly.equals(other.isAddressCorrectionOnly))
			return false;
		if (isFeeRequired == null) {
			if (other.isFeeRequired != null)
				return false;
		}
		else if (!isFeeRequired.equals(other.isFeeRequired))
			return false;
		if (isFeeRequiredSystemGenerated == null) {
			if (other.isFeeRequiredSystemGenerated != null)
				return false;
		}
		else if (!isFeeRequiredSystemGenerated
				.equals(other.isFeeRequiredSystemGenerated))
			return false;
		if (isInventoryAutoAssignmentMade == null) {
			if (other.isInventoryAutoAssignmentMade != null)
				return false;
		}
		else if (!isInventoryAutoAssignmentMade
				.equals(other.isInventoryAutoAssignmentMade))
			return false;
		if (isInventoryAutoAssignmentRequired == null) {
			if (other.isInventoryAutoAssignmentRequired != null)
				return false;
		}
		else if (!isInventoryAutoAssignmentRequired
				.equals(other.isInventoryAutoAssignmentRequired))
			return false;
		if (issuanceReferralMessages == null) {
			if (other.issuanceReferralMessages != null)
				return false;
		}
		else if (!issuanceReferralMessages
				.equals(other.issuanceReferralMessages))
			return false;
		if (microGraphicsNumber == null) {
			if (other.microGraphicsNumber != null)
				return false;
		}
		else if (!microGraphicsNumber.equals(other.microGraphicsNumber))
			return false;
		if (originalTypeTransactionCode == null) {
			if (other.originalTypeTransactionCode != null)
				return false;
		}
		else if (!originalTypeTransactionCode
				.equals(other.originalTypeTransactionCode))
			return false;
		if (photoRequiredCode == null) {
			if (other.photoRequiredCode != null)
				return false;
		}
		else if (!photoRequiredCode.equals(other.photoRequiredCode))
			return false;
		if (previousPhotoRequired == null) {
			if (other.previousPhotoRequired != null)
				return false;
		}
		else if (!previousPhotoRequired.equals(other.previousPhotoRequired))
			return false;
		if (printDocumentHistory == null) {
			if (other.printDocumentHistory != null)
				return false;
		}
		else if (!printDocumentHistory.equals(other.printDocumentHistory))
			return false;
		if (processDate == null) {
			if (other.processDate != null)
				return false;
		}
		else if (!processDate.equals(other.processDate))
			return false;
		if (processHistoryList == null) {
			if (other.processHistoryList != null)
				return false;
		}
		else if (!processHistoryList.equals(other.processHistoryList))
			return false;
		if (systemDate == null) {
			if (other.systemDate != null)
				return false;
		}
		else if (!systemDate.equals(other.systemDate))
			return false;
		if (thirdRbmConditionSatisfied != other.thirdRbmConditionSatisfied)
			return false;
		return true;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("actionMessages", actionMessages, anIndent, aBuilder);
		outputKeyValue("applicationDate", applicationDate, anIndent, aBuilder);
		outputKeyValue("applicationNumber", applicationNumber, anIndent,
				aBuilder);
		outputKeyValue("applicationPendingIndicatorCode",
				applicationPendingIndicatorCode, anIndent, aBuilder);
		outputKeyValue("applicationType", applicationType, anIndent, aBuilder);
		outputKeyValue("applicationTypeCode", applicationTypeCode, anIndent,
				aBuilder);
		outputKeyValue("applicationTypeText", applicationTypeText, anIndent,
				aBuilder);
		outputKeyValue("authorizingPassword", authorizingPassword, anIndent,
				aBuilder);
		outputKeyValue("cnaConditions", cnaConditions, anIndent, aBuilder);
		outputKeyValue("dataEntryReceiptNumber", dataEntryReceiptNumber,
				anIndent, aBuilder);
		outputKeyValue("dataEntryReceiptTypeCode", dataEntryReceiptTypeCode,
				anIndent, aBuilder);
		outputKeyValue("dateFeePaidOverride", dateFeePaidOverride, anIndent,
				aBuilder);
		outputKeyValue("documents", documents, anIndent, aBuilder);
		outputKeyValue("feeRequiredReasonCode", feeRequiredReasonCode,
				anIndent, aBuilder);
		outputKeyValue("isFeeReasonNeeded", feeReasonNeeded, anIndent, aBuilder);
		outputKeyValue("invoice", invoice, anIndent, aBuilder);
		outputKeyValue("isAddressCorrectionOnly", isAddressCorrectionOnly,
				anIndent, aBuilder);
		outputKeyValue("isFeeRequired", isFeeRequired, anIndent, aBuilder);
		outputKeyValue("isFeeRequiredSystemGenerated",
				isFeeRequiredSystemGenerated, anIndent, aBuilder);
		outputKeyValue("issuanceReferralMessages", issuanceReferralMessages,
				anIndent, aBuilder);
		outputKeyValue("microGraphicsNumber", microGraphicsNumber, anIndent,
				aBuilder);
		outputKeyValue("originalTypeTransactionCode",
				originalTypeTransactionCode, anIndent, aBuilder);
		outputKeyValue("processHistoryList", processHistoryList, anIndent,
				aBuilder);
		outputKeyValue("systemDate", systemDate, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * Sets the previous photo required.
	 *
	 * @param previousPhotoRequired the previousPhotoRequired to set
	 */
	public void setPreviousPhotoRequired(CodeSetElement previousPhotoRequired) {
		this.previousPhotoRequired = previousPhotoRequired;
	}
	
	/**
	 * Gets the previous photo required.
	 *
	 * @return the previousPhotoRequired
	 */
	public CodeSetElement getPreviousPhotoRequired() {
		return previousPhotoRequired;
	}
	
	/**
	 * Sets the app office id.
	 *
	 * @param appOfficeId the appOfficeId to set
	 */
	public void setAppOfficeId(String appOfficeId) {
		this.appOfficeId = appOfficeId;
	}
	
	/**
	 * Gets the app office id.
	 *
	 * @return the appOfficeId
	 */
	public String getAppOfficeId() {
		return appOfficeId;
	}
	
	/**
	 * Sets the app office issuance.
	 *
	 * @param appOfficeIssuance the appOfficeIssuance to set
	 */
	public void setAppOfficeIssuance(boolean appOfficeIssuance) {
		this.appOfficeIssuance = appOfficeIssuance;
	}
	
	/**
	 * Checks if is app office issuance.
	 *
	 * @return the appOfficeIssuance
	 */
	public boolean isAppOfficeIssuance() {
		return appOfficeIssuance;
	}

	/**
	 * @return the applicant
	 */
	public Person getApplicant() {
		return applicant;
	}

	/**
	 * @param applicant the applicant to set
	 */
	public void setApplicant(Person applicant) {
		this.applicant = applicant;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Application.java,v $
 *  Revision 1.67  2012/08/15 16:16:26  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.66  2012/03/14 01:57:02  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.65  2011/12/11 21:08:31  mwhys
 *  Updated isApplicationPending().
 *
 *  Revision 1.64  2011/12/11 20:09:08  mwhys
 *  Added method isApplicationPending().
 *
 *  Revision 1.63  2011/09/02 19:51:40  mwrrv3
 *  Added code related to app office issuance office.
 *
 *  Revision 1.62  2011/09/02 18:52:35  mwhys
 *  Added previousPhotoRequired field.
 *
 *  Revision 1.61  2011/08/19 15:47:52  mwhys
 *  Removed deprecated field (isInventoryInvolved).
 *
 *  Revision 1.60  2011/06/15 20:45:41  mwhys
 *  Set the default value of photoRequiredCode to "Y".
 *
 *  Revision 1.59  2011/06/11 00:23:17  mwhys
 *  Updated hasCode and equals methods.
 *
 *  Revision 1.58  2011/06/11 00:07:16  mwhys
 *  Added a field isFeeRequiredSystemGenerated to hold on to the system generated value when the user changes it multiple times.
 *
 *  Revision 1.57  2011/05/25 17:40:24  mwtjc1
 *  getTtcFromPreviousProcessHistory added
 *
 *  Revision 1.56  2011/05/25 00:16:07  mwtjc1
 *  isPhotoRequired added
 *
 *  Revision 1.55  2011/05/18 16:53:27  mwkfh
 *  getOriginalTtcFromProcessHistory is added as an utility method
 *
 *  Revision 1.54  2011/04/21 20:19:23  mwuxb
 *  Removed the initialization of fee reason code needed field.
 *
 *  Revision 1.53  2011/04/08 00:57:57  mwxxw
 *  Use IPrintDocumentHistory instead of PrintDocumentHistory
 *
 *  Revision 1.52  2011/04/06 00:50:11  mwxxw
 *  Add new field PrintDocumentHistory for calculating printClassCode for BCTR.
 *
 *  Revision 1.51  2011/03/29 20:55:31  mwyxg1
 *  add 3rd RBM condition, fix 5642
 *
 *  Revision 1.50  2011/03/23 21:48:28  mwtjc1
 *  isFeeRateCodeExist is moved from DlFeeProcessContext
 *
 *  Revision 1.49  2011/03/23 21:45:26  mwtjc1
 *  applicableFeeList is moved from DlFeeProcessContext to Application
 *
 *  Revision 1.48  2011/03/09 00:47:35  mwkfh
 *  added dafSaveTime for defect 5202
 *
 *  Revision 1.47  2011/02/14 19:00:07  mwtjc1
 *  isInventoryInvolved is deprecated
 *
 *  Revision 1.46  2011/02/12 20:49:44  mwrrv2
 *  feeReasonNeeded is initialized to Y inside the constructor
 *
 *  Revision 1.45  2011/02/12 03:08:08  mwuxb
 *  Initialized feeReasonNeeded
 *
 *  Revision 1.44  2011/02/08 02:23:07  mwhxb3
 *  Set isFeeRe to true
 *
 *  Revision 1.43  2011/01/29 00:30:16  mwtjc1
 *  isFeeRequired is initialized to null
 *
 *  Revision 1.42  2011/01/29 00:24:23  mwtjc1
 *  getIsFeeRequired removed
 *
 *  Revision 1.41  2011/01/29 00:14:24  mwtjc1
 *  isFeeRequired is initialized to false
 *
 *  Revision 1.40  2011/01/28 18:52:36  mwuxb
 *  Added variable originalTypeTransactionCode.
 *
 *  Revision 1.39  2011/01/27 19:37:09  mwtjc1
 *  getIsFeeRequired is changed to public
 *
 *  Revision 1.38  2011/01/22 19:03:53  mwuxb
 *  Added actionMessages field.
 *
 *  Revision 1.37  2011/01/17 01:20:10  mwpxp2
 *  Builk cleanup
 *
 *  Revision 1.36  2011/01/05 17:03:43  mwhys
 *  Added state variable "feeReasonNeeded" whose value is set using hidden logic.
 *
 *  Revision 1.35  2010/12/30 03:15:26  mwpxr4
 *  Added inventory related fields for bridge call - BCTR.
 *
 *  Revision 1.34  2010/12/24 22:36:37  mwhxb3
 *  Removed isPasswordRequiredRecordReviewCond.
 *
 *  Revision 1.33  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.31.2.2  2010/12/23 03:13:54  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.31.2.1  2010/12/21 18:02:29  mwsyk1
 *  controlCashierSequenceNumber adder
 *
 *  Revision 1.32  2010/12/21 01:05:29  mwtjc1
 *  controlCashierSeqNumber added
 *
 *  Revision 1.31  2010/12/17 17:23:20  mwhxb3
 *  Removed reviewclass.
 *
 *  Revision 1.30  2010/12/16 18:35:02  mwuxb
 *  Added process date in equals & hashcode
 *
 *  Revision 1.29  2010/12/15 21:54:38  mwhxb3
 *  Added isPasswordRequiredRecordReviewCond and reviewClass.
 *
 *  Revision 1.28  2010/12/15 01:15:00  mwuxb
 *  Add process date.
 *
 *  Revision 1.27  2010/12/15 00:14:26  mwpxr4
 *  Reverted to previous version.
 *
 *  Revision 1.25  2010/12/13 02:57:00  mwpxr4
 *  Moved photorequired code from dlapp to app.
 *
 *  Revision 1.24  2010/12/07 22:08:35  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.23  2010/12/07 02:42:34  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.22  2010/11/04 23:52:41  mwuxb
 *  setIssuanceReferralMessages made public.
 *
 *  Revision 1.21  2010/11/02 21:46:57  mwuxb
 *  hasIssuanceReferralMessage made public.
 *
 *  Revision 1.20  2010/11/01 23:07:48  mwtjc1
 *  setCnaConditions made public
 *
 *  Revision 1.19  2010/09/13 04:40:28  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.18  2010/08/28 00:19:37  mwcsj3
 *  Added default values to Fee required and Original application indicators
 *
 *  Revision 1.17  2010/08/12 22:10:48  mwcsj3
 *  Made changes to setProcessHistoryList method, as part of bug fix.
 *
 *  Revision 1.16  2010/08/11 21:02:36  mwlft1
 *  Added Application Type Text
 *
 *  Revision 1.15  2010/08/11 18:30:27  mwvxm6
 *  Updated methods to fix getPreviousProcessHistory and getOriginalProcessHistory
 *
 *  Revision 1.14  2010/08/10 17:05:48  mwtjc1
 *  setProcessHistory is added to remove compilation errors
 *
 *  Revision 1.13  2010/08/10 00:51:03  mwpxp2
 *  Fixed inconsistent lazy/eager instation; added several fixmes and todos; recreated hash and equals
 *
 *  Revision 1.12  2010/08/05 18:44:19  mwhxa2
 *  Added Application Pending Indicator
 *
 *  Revision 1.11  2010/07/26 22:03:49  mwvxm6
 *  Added helper to add process history
 *
 *  Revision 1.10  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.9  2010/05/15 01:34:02  mwuxb
 *  Added attribute issuanceReferralMessages
 *
 *  Revision 1.8  2010/05/12 19:53:10  mwuxb
 *  Updated
 *
 *  Revision 1.7  2010/05/12 19:50:31  mwuxb
 *  Added attribute dataEntryReceiptTypeCode
 *
 *  Revision 1.6  2010/05/12 17:38:05  mwuxb
 *  Changed String to CodeSetElement for attribute applicationType in Application class.
 *
 *  Revision 1.5  2010/05/07 20:13:44  mwuxb
 *  Added attribute isAddressCorrectionOnly
 *
 *  Revision 1.4  2010/05/06 16:08:47  mwuxb
 *  Pulled up applicationTypeCode to Application from DlApplication.
 *
 *  Revision 1.3  2010/04/29 17:08:25  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.2  2010/04/24 00:27:14  mwrsk
 *  Made changes to ProcessHistory retrieval
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.22  2010/04/15 00:09:21  mwvxm6
 *  Moved dataEntryReceiptNumber to Application and changed type to String
 *
 *  Revision 1.21  2010/04/14 01:32:36  mwvxm6
 *  Move fee and invoice related attributes to Application class since it is now shared with multiple license Applications
 *
 *  Revision 1.20  2010/04/13 18:10:11  mwyxg1
 *  fix nullPointerException
 *
 *  Revision 1.19  2010/04/12 23:40:15  mwvxm6
 *  Updated CNA condition to common class
 *
 *  Revision 1.18  2010/04/12 18:04:29  mwuxb
 *  Updated
 *
 *  Revision 1.17  2010/04/09 23:07:00  mwuxb
 *  Added helper method for process history
 *
 *  Revision 1.16  2010/04/09 18:19:34  mwuxb
 *  Updated helper methods for process history
 *
 *  Revision 1.15  2010/04/07 17:58:54  mwuxb
 *  Renamed current process history to previous
 *
 *  Revision 1.14  2010/04/06 18:52:39  mwuxb
 *  Added helper methods for process history.
 *
 *  Revision 1.13  2010/03/16 20:17:22  mwjxk6
 *  update comment
 *
 *  Revision 1.12  2010/03/11 17:48:43  mwuxb
 *  Added helper method to add application document
 *
 *  Revision 1.11  2010/03/09 22:59:05  mwhxa2
 *  Added process history info
 *
 *  Revision 1.10  2010/03/04 02:03:10  mwrsk
 *  Reverting back to the previous version
 *
 *  Revision 1.8  2010/02/26 19:23:18  mwjxk6
 *  change managerPassword to authorizingPassword
 *
 *  Revision 1.7  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.6  2010/02/17 22:24:03  mwuxb
 *  Added systemDate attribute and updated comments
 *
 *  Revision 1.5  2010/02/01 17:27:58  mwhxa2
 *  Added Application Date Attribute
 *
 *  Revision 1.4  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/07 18:29:31  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.15  2009/10/15 22:25:11  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.14  2009/10/03 21:06:31  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.13  2009/09/25 00:17:37  mwhxa2
 *  Extends BaseBusinessObject
 *
 *  Revision 1.12  2009/09/02 15:43:43  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.11  2009/08/27 05:39:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2009/08/22 23:19:33  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.9  2009/08/10 17:18:20  mwrrv3
 *  Moved password field from DlApplication to Application.
 *
 *  Revision 1.8  2009/08/08 20:52:27  mwrrv3
 *  Changed data type String to CodeSetElement.
 *
 *  Revision 1.7  2009/08/05 17:45:37  mwskd2
 *  Added application type for application.
 *
 *  Revision 1.6  2009/08/04 17:53:48  mwyxg1
 *  add constructor
 *
 *  Revision 1.5  2009/07/30 18:50:07  mwrrv3
 *  Added documents attribute.
 *
 *  Revision 1.4  2009/07/30 17:22:47  mwrrv3
 *  Changed extends Document to BusinessObject.
 *
 *  Revision 1.3  2009/07/28 01:57:43  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:35  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
