/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;

import java.util.Date;

/**
 * Description: This class captures information pertaining to the payments for adding court restrictions
 * when the customer submits a court referral form (DL 103) 
 * File: AddCourtRestrictionPayment.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class AddCourtRestrictionApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6824591868577656884L;
	/** This represents the Consent Date from the DL 103 */
	private Date consentDate;
	/** This represents the Enrollment Date from the DL 103 */
	private Date enrollmentDate;
	/** This represents the Number Of Jail Days served */
	private Integer numberOfJailDays;

	/**
	 * Instantiates a new application.
	 */
	public AddCourtRestrictionApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the consentDate
	 */
	public Date getConsentDate() {
		return consentDate;
	}

	/**
	 * @return the enrollmentDate
	 */
	public Date getEnrollmentDate() {
		return enrollmentDate;
	}

	/**
	 * @return the numberOfJailDays
	 */
	public Integer getNumberOfJailDays() {
		return numberOfJailDays;
	}

	/**
	 * @param consentDate the consentDate to set
	 */
	public void setConsentDate(Date consentDate) {
		this.consentDate = consentDate;
	}

	/**
	 * @param enrollmentDate the enrollmentDate to set
	 */
	public void setEnrollmentDate(Date enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	/**
	 * @param numberOfJailDays the numberOfJailDays to set
	 */
	public void setNumberOfJailDays(Integer numberOfJailDays) {
		this.numberOfJailDays = numberOfJailDays;
	}
}
