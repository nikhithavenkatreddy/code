/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

/**
 * Description: CreditPayment encapsulates the attributes of a credit card.
 * File: CreditPayment.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Aug 3, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/07 18:46:43 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CreditPayment extends CardPayment {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1619060784101864003L;
	/** Holds the credit card number. */
	private String creditCardNumber;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CreditPayment other = (CreditPayment) obj;
		if (creditCardNumber == null) {
			if (other.creditCardNumber != null) {
				return false;
			}
		}
		else if (!creditCardNumber.equals(other.creditCardNumber)) {
			return false;
		}
		if (expiryDate == null) {
			if (other.expiryDate != null) {
				return false;
			}
		}
		else if (!expiryDate.equals(other.expiryDate)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the credit card number.
	 * 
	 * @return the creditCardNumber
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((creditCardNumber == null) ? 0 : creditCardNumber.hashCode());
		result = prime * result
				+ ((expiryDate == null) ? 0 : expiryDate.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.Payment#isCredit()
	 */
	@Override
	public boolean isCredit() {
		return true;
	}

	/**
	 * Sets the credit card number.
	 * 
	 * @param creditCardNumber the creditCardNumber to set
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CreditPayment.java,v $
 *  Revision 1.2  2010/07/07 18:46:43  mwpxp2
 *  Added is~ redefinition from super
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/03/03 16:11:23  mwrsk
 *  cleanup imports
 *
 *  Revision 1.4  2010/02/16 22:45:07  mwvxm6
 *  Added an abstract CardPayment class with the common expiry date attribute
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/06 00:14:19  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/13 22:39:29  mwvxm6
 *  Added PaymentValidator so that the validate method get code coverage for this method.
 *  Added a basic Payment validation to check for amount NOT= 0.
 *  Comment out this validation if a uses case requires 0 or null amounts
 *
 *  Revision 1.7  2009/10/03 21:06:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/25 00:02:00  mwhxa2
 *  Payment now extends base businessObject
 *
 *  Revision 1.5  2009/08/27 05:39:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/22 23:21:46  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.3  2009/08/03 21:49:16  mwrrv3
 *  Code formatted and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:37  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:17  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 4:40:02 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 4:40:02 PM  MWCSJ3
 *  $Initial
 *  $
 */
