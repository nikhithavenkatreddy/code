package gov.ca.dmv.ease.bo.financial.impl;

import java.util.Date;

/**
 * Description: I represent the abstract Card Payment
 * 
 * File: CardPayment.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Mar 3, 2010 
 * @author MWRSK  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/01/22 02:50:13 $
 * Last Changed By: $Author: mwyxg1 $
 */
public abstract class CardPayment extends Payment {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	/** The authorization number. The three digit authorization code on the back side of credit/debit card. */
	protected Integer authorizationNumber;
	/** Holds the credit card expiration date. */
	protected Date expiryDate;

	/**
	 * Gets the authorization number.
	 * 
	 * @return the authorizationNumber
	 */
	public Integer getAuthorizationNumber() {
		return authorizationNumber;
	}

	/**
	 * Gets the expiry date.
	 * 
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * Sets the authorization number.
	 * 
	 * @param authorizationNumber the authorizationNumber to set
	 */
	public void setAuthorizationNumber(Integer authorizationNumber) {
		this.authorizationNumber = authorizationNumber;
	}

	/**
	 * Sets the expiry date.
	 * 
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CardPayment.java,v $
 *  Revision 1.5  2011/01/22 02:50:13  mwyxg1
 *  remove constructor
 *
 *  Revision 1.4  2011/01/22 02:29:18  mwyxg1
 *  add date
 *
 *  Revision 1.3  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/04/29 23:13:45  mwuxb
 *  Added authorization number
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/03 16:14:47  mwrsk
 *  Add comments & cleanup
 *
*/
