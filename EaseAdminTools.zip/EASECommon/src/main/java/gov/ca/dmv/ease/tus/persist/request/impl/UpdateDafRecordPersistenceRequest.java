/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService;

/**
 * Description: I represent the request to update the blob object (daf record).
 * File: AssignDafNumberRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 17, 2010
 * 
 * @author MWTJC1
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/01/14 17:44:20 $
 * Last Changed By: $Author: mwtjc1 $
 */
public class UpdateDafRecordPersistenceRequest extends
		PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3506552603513262650L;
	/** The allocated daf number. */
	private int allocatedDafNumber;
	/** The application. */
	private Application application;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public PersistenceServiceResponse execute() {
		return ((ITransactionPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Instantiates a new issue local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param allocatedDafNumber the allocated daf number
	 * @param application the application
	 */
	public UpdateDafRecordPersistenceRequest(IUserContext userContext,
			Application application, int allocatedDafNumber) {
		super(userContext);
		this.application = application;
		this.allocatedDafNumber = allocatedDafNumber;
	}

	/**
	 * Gets the application.
	 * 
	 * @return the application
	 */
	public Application getApplication() {
		return application;
	}

	/**
	 * Gets the allocated daf number.
	 * 
	 * @return the allocated daf number
	 */
	public int getAllocatedDafNumber() {
		return allocatedDafNumber;
	}
}
/**
 *  Modification History:
 *
 *  $Log: UpdateDafRecordPersistenceRequest.java,v $
 *  Revision 1.3  2011/01/14 17:44:20  mwtjc1
 *  application added
 *
 *  Revision 1.2  2011/01/14 17:42:37  mwtjc1
 *  allocatedDafNumber added
 *
 *  Revision 1.1  2011/01/14 17:37:06  mwtjc1
 *  first commit
 *
 */
