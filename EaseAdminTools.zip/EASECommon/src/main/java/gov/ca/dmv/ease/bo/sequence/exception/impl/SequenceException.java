/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessObjectException;

// TODO: Auto-generated Javadoc
/**
 * Description: I am superclass for exceptions related to sequences
 * File: SequenceException.java
 * Module:  gov.ca.dmv.ease.bo.sequence.exception.impl
 * Created: Sep 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/30 17:44:52 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SequenceException extends EaseBusinessObjectException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7674173201805840018L;

	/**
	 * Instantiates a new sequence exception.
	 */
	public SequenceException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public SequenceException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public SequenceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public SequenceException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequenceException.java,v $
 *  Revision 1.1  2010/09/30 17:44:52  mwpxp2
 *  Initial
 *
 */
