/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.dl.record.impl.AkaInformation;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: An object to hold information of the applicants past licenses
 * especially from out of California. 
 * File: OutOfStateLicense.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.21 $
 * Last Changed: $Date: 2013/05/29 16:49:46 $
 * Last Changed By: $Author: mwskh1 $
 */
public class OutOfStateLicense extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4128055048979628507L;
	/** The birth date. */
	private Date birthDate;
	/** This represents the commercial License Class of the license. */
	private String commercialLicenseClass;
	/** This represents the commercial License Status of the license. */
	private String commercialLicenseStatus;
	/** This represents the existing endorsements of the license. */
	private List <CodeSetElement> existingEndorsements;
	/** This represents the gender code on the out of state record. */
	private CodeSetElement genderCode;
	/** The isCommercial license . */
	private Boolean isCommercial;
	/** This represents the issued country name. */
	private String issuedByCountry;
	/** This represents the issued state. */
	private CodeSetElement issuedByState;
	/** The license location code. */
	private CodeSetElement licenseLocation;
	/** This represents the license number on the out of state record. */
	private String licenseNumber;
	/** The current name. */
	private PersonName name;
	/** This represents the non commercial License Class of the license. */
	private String noncommercialLicneseClass;
	/** This represents the non commercial License Status of the license. */
	private String noncommercialLicneseStatus;
	/** The Person Names. */
	private List <PersonName> personNames;
	/** This represents the restrictions of the license. */
	private List <DrivingRestriction> restrictions;
	/** This represents the ssn number on the out of state record. */
	private String ssn;
	/** The valueChange for Informational Message. */
	private String valueChange;
	/** The expanded AKA Information of the person. (CDLIS 5.2) */
	private List <AkaInformation> expandedAkaInformationList;
	/** The Expanded Name of the Person. (CDLIS 5.2) */
	private PersonName expandedCurrentName;

	/**
	 * Gets the value change.
	 *
	 * @return the valueChange
	 */
	public String getValueChange() {
		return valueChange;
	}

	/**
	 * Sets the value change.
	 *
	 * @param valueChange the new value change
	 */
	public void setValueChange(String valueChange) {
		this.valueChange = valueChange;
	}

	/**
	 * Default Constructor.
	 */
	public OutOfStateLicense() {
		//issuedBy = new CodeSetElement();
	}

	/**
	 * Instantiates a new out of state license.
	 *
	 * @param outOfStateLicense the out of state license
	 */
	public OutOfStateLicense(OutOfStateLicense outOfStateLicense) {
		super();
		copy(outOfStateLicense);
	}

	/**
	 * Copy.
	 *
	 * @param objectToCopy the object to copy
	 */
	protected void copy(OutOfStateLicense objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null outOfStateLicense argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		if (isNotNull(objectToCopy.getBirthDate())) {
			setBirthDate(new Date(objectToCopy.getBirthDate().getTime()));
		}
		else {
			setBirthDate(null);
		}
		setCommercialLicenseClass(objectToCopy.getCommercialLicenseClass());
		setCommercialLicenseStatus(objectToCopy.getCommercialLicenseStatus());
		if (isNotNull(objectToCopy.getGenderCode())) {
			setGenderCode(new CodeSetElement(objectToCopy.getGenderCode()));
		}
		else {
			setGenderCode(null);
		}
		if (isNotNull(objectToCopy.isCommercial())) {
			setCommercial(objectToCopy.isCommercial());
		}
		else {
			setCommercial(null);
		}
		setIssuedByCountry(objectToCopy.getIssuedByCountry());
		if (isNotNull(objectToCopy.getIssuedByState())) {
			setIssuedByState(new CodeSetElement(objectToCopy.getIssuedByState()));
		}
		else {
			setIssuedByState(null);
		}
		if (isNotNull(objectToCopy.getLicenseLocation())) {
			setLicenseLocation(new CodeSetElement(objectToCopy
					.getLicenseLocation()));
		}
		else {
			setLicenseLocation(null);
		}
		setLicenseNumber(objectToCopy.getLicenseNumber());
		if (isNotNull(objectToCopy.getName())) {
			setName(new PersonName(objectToCopy.getName()));
		}
		else {
			setName(null);
		}
		setNoncommercialLicneseClass(objectToCopy
				.getNoncommercialLicneseClass());
		setNoncommercialLicneseStatus(objectToCopy
				.getNoncommercialLicneseStatus());
		copyPersonNames(objectToCopy.getPersonNames());
		copyDrivingRestrictions(objectToCopy.getRestrictions());
		copyEndorsements(objectToCopy.getExistingEndorsements());
		setSsn(objectToCopy.getSsn());
		setValueChange(objectToCopy.getValueChange());
		copyExpandedAkaInformation(objectToCopy.getExpandedAkaInformationList());
		//Copy expandedCurrentName
		if (isNotNull(objectToCopy.getExpandedCurrentName())) {
			setExpandedCurrentName(new PersonName(objectToCopy
					.getExpandedCurrentName()));
		}
		else {
			setExpandedCurrentName(null);
		}
	}

	/**
	 * Copy expanded aka information. (CDLIS 5.2)
	 *
	 * @param akaInformation the aka information
	 */
	protected void copyExpandedAkaInformation(
			List <AkaInformation> expandedAkaInformationList) {
		if (isNotNull(expandedAkaInformationList)) {
			List <AkaInformation> expandedAkaInformationCopy = new ArrayList <AkaInformation>();
			for (AkaInformation expandedAkaInformationToCopy : expandedAkaInformationList) {
				if (isNotNull(expandedAkaInformationToCopy)) {
					expandedAkaInformationCopy.add(new AkaInformation(
							expandedAkaInformationToCopy));
				}
			}
			setExpandedAkaInformationList(expandedAkaInformationCopy);
		}
		else {
			setExpandedAkaInformationList(null);
		}
	}

	/**
	 * Copy person names.
	 *
	 * @param personNamesToCopy the person names to copy
	 */
	private void copyPersonNames(List <PersonName> personNamesToCopy) {
		if (isNotNull(personNamesToCopy)) {
			List <PersonName> personNames = new ArrayList <PersonName>();
			for (PersonName personNameToCopy : personNamesToCopy) {
				if (isNotNull(personNameToCopy)) {
					personNames.add(new PersonName(personNameToCopy));
				}
			}
			setPersonNames(personNames);
		}
		else {
			setPersonNames(null);
		}
	}

	/**
	 * Copy driving restrictions.
	 *
	 * @param drivingRestrictionsToCopy the driving restrictions to copy
	 */
	private void copyDrivingRestrictions(
			List <DrivingRestriction> drivingRestrictionsToCopy) {
		if (isNotNull(drivingRestrictionsToCopy)) {
			List <DrivingRestriction> drivingRestrictions = new ArrayList <DrivingRestriction>();
			for (DrivingRestriction drivingRestrictionToCopy : drivingRestrictionsToCopy) {
				if (isNotNull(drivingRestrictionToCopy)) {
					drivingRestrictions.add(new DrivingRestriction(
							drivingRestrictionToCopy));
				}
			}
			setRestrictions(drivingRestrictions);
		}
		else {
			setRestrictions(null);
		}
	}

	/**
	 * Copy endorsements.
	 *
	 * @param endorsementsToCopy the endorsements to copy
	 */
	private void copyEndorsements(List <CodeSetElement> endorsementsToCopy) {
		if (isNotNull(endorsementsToCopy)) {
			List <CodeSetElement> personNames = new ArrayList <CodeSetElement>();
			for (CodeSetElement endorsementToCopy : endorsementsToCopy) {
				if (isNotNull(endorsementToCopy)) {
					personNames.add(new CodeSetElement(endorsementToCopy));
				}
			}
			setExistingEndorsements(endorsementsToCopy);
		}
		else {
			setExistingEndorsements(null);
		}
	}

	/**
	 * Gets the Birth Date.
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Gets the commercial license class.
	 *
	 * @return the commercialLicenseClass
	 */
	public String getCommercialLicenseClass() {
		return commercialLicenseClass;
	}

	/**
	 * Gets the commercial license status.
	 *
	 * @return the commercialLicenseStatus
	 */
	public String getCommercialLicenseStatus() {
		return commercialLicenseStatus;
	}

	/**
	 * Gets the existing endorsements.
	 *
	 * @return the existingEndorsements
	 */
	public List <CodeSetElement> getExistingEndorsements() {
		return existingEndorsements;
	}

	/**
	 * Gets the Gender Code.
	 * 
	 * @return the genderCode
	 */
	public CodeSetElement getGenderCode() {
		return genderCode;
	}

	/**
	 * Gets the Issued By Country.
	 * 
	 * @return the issuedByCountry
	 */
	public String getIssuedByCountry() {
		return issuedByCountry;
	}

	/**
	 * Gets the Issued By State.
	 * 
	 * @return the issuedByState
	 */
	public CodeSetElement getIssuedByState() {
		return issuedByState;
	}

	/**
	 * Gets the License Location.
	 * 
	 * @return the licenseLocation
	 */
	public CodeSetElement getLicenseLocation() {
		return licenseLocation;
	}

	/**
	 * Gets the License Number.
	 * 
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/**
	 * Gets the Current Name.
	 * 
	 * @return the currentName
	 */
	public PersonName getName() {
		return name;
	}

	/**
	 * Gets the noncommercial licnese class.
	 *
	 * @return the noncommercialLicneseClass
	 */
	public String getNoncommercialLicneseClass() {
		return noncommercialLicneseClass;
	}

	/**
	 * Gets the noncommercial licnese status.
	 *
	 * @return the noncommercialLicneseStatus
	 */
	public String getNoncommercialLicneseStatus() {
		return noncommercialLicneseStatus;
	}

	/**
	 * Gets the Person Names.
	 * 
	 * @return the personNames
	 */
	public List <PersonName> getPersonNames() {
		return personNames;
	}

	/**
	 * Gets the restrictions.
	 *
	 * @return the restrictions
	 */
	public List <DrivingRestriction> getRestrictions() {
		return restrictions;
	}

	/**
	 * Gets the SSN.
	 * 
	 * @return the ssn
	 */
	public String getSsn() {
		return ssn;
	}

	/**
	 * Checks if it is a Commercial.
	 * 
	 * @return the boolean
	 */
	public Boolean isCommercial() {
		return isCommercial;
	}

	/**
	 * Sets the Birth Date.
	 * 
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Sets the isCommercial.
	 *
	 * @param commercial the new commercial
	 */
	public void setCommercial(Boolean commercial) {
		this.isCommercial = commercial;
	}

	/**
	 * Sets the commercial license class.
	 *
	 * @param commercialLicenseClass the commercialLicenseClass to set
	 */
	public void setCommercialLicenseClass(String commercialLicenseClass) {
		this.commercialLicenseClass = commercialLicenseClass;
	}

	/**
	 * Sets the commercial license status.
	 *
	 * @param commercialLicenseStatus the commercialLicenseStatus to set
	 */
	public void setCommercialLicenseStatus(String commercialLicenseStatus) {
		this.commercialLicenseStatus = commercialLicenseStatus;
	}

	/**
	 * Sets the existing endorsements.
	 *
	 * @param existingEndorsements the existingEndorsements to set
	 */
	public void setExistingEndorsements(
			List <CodeSetElement> existingEndorsements) {
		this.existingEndorsements = existingEndorsements;
	}

	/**
	 * Sets the Gender Code.
	 * 
	 * @param genderCode the genderCode to set
	 */
	public void setGenderCode(CodeSetElement genderCode) {
		this.genderCode = genderCode;
	}

	/**
	 * Sets the Issued By Country.
	 * 
	 * @param issuedByCountry the issuedByCountry to set
	 */
	public void setIssuedByCountry(String issuedByCountry) {
		this.issuedByCountry = issuedByCountry;
	}

	/**
	 * Sets the Issued By State.
	 * 
	 * @param issuedByState the issuedByState to set
	 */
	public void setIssuedByState(CodeSetElement issuedByState) {
		this.issuedByState = issuedByState;
	}

	/**
	 * Sets the License Location.
	 * 
	 * @param licenseLocation the licenseLocation to set
	 */
	public void setLicenseLocation(CodeSetElement licenseLocation) {
		this.licenseLocation = licenseLocation;
	}

	/**
	 * Sets the License Number.
	 * 
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	/**
	 * Sets the Current Name.
	 * 
	 * @param currentName the currentName to set
	 */
	public void setName(PersonName currentName) {
		this.name = currentName;
	}

	/**
	 * Sets the noncommercial licnese class.
	 *
	 * @param noncommercialLicneseClass the noncommercialLicneseClass to set
	 */
	public void setNoncommercialLicneseClass(String noncommercialLicneseClass) {
		this.noncommercialLicneseClass = noncommercialLicneseClass;
	}

	/**
	 * Sets the noncommercial licnese status.
	 *
	 * @param noncommercialLicneseStatus the noncommercialLicneseStatus to set
	 */
	public void setNoncommercialLicneseStatus(String noncommercialLicneseStatus) {
		this.noncommercialLicneseStatus = noncommercialLicneseStatus;
	}

	/**
	 * Sets the Person Names.
	 * 
	 * @param personNames the personNames to set
	 */
	public void setPersonNames(List <PersonName> personNames) {
		this.personNames = personNames;
	}

	/**
	 * Sets the restrictions.
	 *
	 * @param restrictions the restrictions to set
	 */
	public void setRestrictions(List <DrivingRestriction> restrictions) {
		this.restrictions = restrictions;
	}

	/**
	 * Sets the SSN.
	 * 
	 * @param ssn the ssn to set
	 */
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	/**
	 * Gets the expanded AKA Names. (CDLIS 5.2)
	 * 
	 * @return the akaNames
	 */
	public List <AkaInformation> getExpandedAkaInformationList() {
		return expandedAkaInformationList;
	}

	/**
	 * Sets the expanded AKA Names. (CDLIS 5.2)
	 *
	 * @param akaInformation the new aka information
	 */
	public void setExpandedAkaInformationList(
			List <AkaInformation> expandedAkaInformation) {
		this.expandedAkaInformationList = expandedAkaInformation;
	}

	/**
	 * Sets the expand current name. (CDLIS 5.2)
	 * 
	 * @param currentName the new current name
	 */
	public void setExpandedCurrentName(PersonName expandedCurrentName) {
		this.expandedCurrentName = expandedCurrentName;
	}

	/**
	 * Gets the expanded current name.(CDLIS 5.2)
	 * 
	 * @return the current name
	 */
	public PersonName getExpandedCurrentName() {
		return expandedCurrentName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("name", name, anIndent, aBuilder);
		outputKeyValue("ssn", ssn, anIndent, aBuilder);
		outputKeyValue("birthDate", birthDate, anIndent, aBuilder);
		outputKeyValue("commercialLicenseClass", commercialLicenseClass,
				anIndent, aBuilder);
		outputKeyValue("commercialLicenseStatus", commercialLicenseStatus,
				anIndent, aBuilder);
		outputKeyValue("existingEndorsements", existingEndorsements, anIndent,
				aBuilder);
		outputKeyValue("genderCode", genderCode, anIndent, aBuilder);
		outputKeyValue("isCommercial", isCommercial, anIndent, aBuilder);
		outputKeyValue("issuedByCountry", issuedByCountry, anIndent, aBuilder);
		outputKeyValue("issuedByState", issuedByState, anIndent, aBuilder);
		outputKeyValue("licenseLocation", licenseLocation, anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("noncommercialLicneseClass", noncommercialLicneseClass,
				anIndent, aBuilder);
		outputKeyValue("noncommercialLicneseStatus",
				noncommercialLicneseStatus, anIndent, aBuilder);
		outputKeyValue("personNames", personNames, anIndent, aBuilder);
		outputKeyValue("restrictions", restrictions, anIndent, aBuilder);
		outputKeyValue("ExpandedName",
				(expandedCurrentName == null ? expandedCurrentName
						: expandedCurrentName.getFullNameWithSuffix()),
				anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime
				* result
				+ ((commercialLicenseClass == null) ? 0
						: commercialLicenseClass.hashCode());
		result = prime
				* result
				+ ((commercialLicenseStatus == null) ? 0
						: commercialLicenseStatus.hashCode());
		result = prime
				* result
				+ ((existingEndorsements == null) ? 0 : existingEndorsements
						.hashCode());
		result = prime * result
				+ ((genderCode == null) ? 0 : genderCode.hashCode());
		result = prime * result
				+ ((isCommercial == null) ? 0 : isCommercial.hashCode());
		result = prime * result
				+ ((issuedByCountry == null) ? 0 : issuedByCountry.hashCode());
		result = prime * result
				+ ((issuedByState == null) ? 0 : issuedByState.hashCode());
		result = prime * result
				+ ((licenseLocation == null) ? 0 : licenseLocation.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime
				* result
				+ ((noncommercialLicneseClass == null) ? 0
						: noncommercialLicneseClass.hashCode());
		result = prime
				* result
				+ ((noncommercialLicneseStatus == null) ? 0
						: noncommercialLicneseStatus.hashCode());
		result = prime * result
				+ ((personNames == null) ? 0 : personNames.hashCode());
		result = prime * result
				+ ((restrictions == null) ? 0 : restrictions.hashCode());
		result = prime * result + ((ssn == null) ? 0 : ssn.hashCode());
		result = prime * result
				+ ((valueChange == null) ? 0 : valueChange.hashCode());
		result = prime
				* result
				+ ((expandedAkaInformationList == null) ? 0
						: expandedAkaInformationList.hashCode());
		result = prime
				* result
				+ ((expandedCurrentName == null) ? 0 : expandedCurrentName
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		OutOfStateLicense other = (OutOfStateLicense) obj;
		if (birthDate == null) {
			if (other.birthDate != null)
				return false;
		}
		else if (!birthDate.equals(other.birthDate))
			return false;
		if (commercialLicenseClass == null) {
			if (other.commercialLicenseClass != null)
				return false;
		}
		else if (!commercialLicenseClass.equals(other.commercialLicenseClass))
			return false;
		if (commercialLicenseStatus == null) {
			if (other.commercialLicenseStatus != null)
				return false;
		}
		else if (!commercialLicenseStatus.equals(other.commercialLicenseStatus))
			return false;
		if (existingEndorsements == null) {
			if (other.existingEndorsements != null)
				return false;
		}
		else if (!existingEndorsements.equals(other.existingEndorsements))
			return false;
		if (genderCode == null) {
			if (other.genderCode != null)
				return false;
		}
		else if (!genderCode.equals(other.genderCode))
			return false;
		if (isCommercial == null) {
			if (other.isCommercial != null)
				return false;
		}
		else if (!isCommercial.equals(other.isCommercial))
			return false;
		if (issuedByCountry == null) {
			if (other.issuedByCountry != null)
				return false;
		}
		else if (!issuedByCountry.equals(other.issuedByCountry))
			return false;
		if (issuedByState == null) {
			if (other.issuedByState != null)
				return false;
		}
		else if (!issuedByState.equals(other.issuedByState))
			return false;
		if (licenseLocation == null) {
			if (other.licenseLocation != null)
				return false;
		}
		else if (!licenseLocation.equals(other.licenseLocation))
			return false;
		if (licenseNumber == null) {
			if (other.licenseNumber != null)
				return false;
		}
		else if (!licenseNumber.equals(other.licenseNumber))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		if (noncommercialLicneseClass == null) {
			if (other.noncommercialLicneseClass != null)
				return false;
		}
		else if (!noncommercialLicneseClass
				.equals(other.noncommercialLicneseClass))
			return false;
		if (noncommercialLicneseStatus == null) {
			if (other.noncommercialLicneseStatus != null)
				return false;
		}
		else if (!noncommercialLicneseStatus
				.equals(other.noncommercialLicneseStatus))
			return false;
		if (personNames == null) {
			if (other.personNames != null)
				return false;
		}
		else if (!personNames.equals(other.personNames))
			return false;
		if (restrictions == null) {
			if (other.restrictions != null)
				return false;
		}
		else if (!restrictions.equals(other.restrictions))
			return false;
		if (ssn == null) {
			if (other.ssn != null)
				return false;
		}
		else if (!ssn.equals(other.ssn))
			return false;
		if (valueChange == null) {
			if (other.valueChange != null)
				return false;
		}
		else if (!valueChange.equals(other.valueChange))
			return false;
		if (expandedAkaInformationList == null) {
			if (other.expandedAkaInformationList != null) {
				return false;
			}
		}
		else if (!expandedAkaInformationList
				.equals(other.expandedAkaInformationList)) {
			return false;
		}
		if (expandedCurrentName == null) {
			if (other.expandedCurrentName != null) {
				return false;
			}
		}
		else if (!expandedCurrentName.equals(other.expandedCurrentName)) {
			return false;
		}
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OutOfStateLicense.java,v $
 *  Revision 1.21  2013/05/29 16:49:46  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *  Revision 1.20.24.1  2013/05/07 16:20:18  mwskh1
 *  CDLIS 5.2 - new state of record converter for CDLIS 5.2
 *
 *  Revision 1.20  2011/04/07 04:04:52  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.19.14.3  2011/04/05 18:18:21  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.19.14.2  2011/04/05 01:13:58  mwhys
 *  (1) Regenerated hashCode() and equals() methods.
 *  (2) Modified copy method to include null checks and added explicit else blocks.
 *
 *  Revision 1.19.14.1  2011/04/03 21:05:32  mwrrv3
 *  Copy Functionality Implemented -- Amar Bade
 *
 *  Revision 1.19  2010/12/16 17:24:52  mwnrk
 *  Fix for Informational Message.
 *
 *  Revision 1.18  2010/12/07 22:10:42  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.17  2010/12/07 18:20:43  mwhys
 *  Removed null check in the constructor, as it is incorrect to do so.
 *
 *  Revision 1.16  2010/12/07 03:57:06  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.15  2010/12/06 22:46:38  mwhys
 *  Added null check.
 *
 *  Revision 1.14  2010/12/06 21:38:22  mwhys
 *  Updated constructor.
 *
 *  Revision 1.13  2010/12/06 02:10:26  mwhys
 *  Added a constructor.
 *
 *  Revision 1.12  2010/09/13 18:38:27  mwjxa11
 *  Updated by adding existing Endorsements object and its getter/setter methods
 *
 *  Revision 1.11  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.10  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.4.2.2  2010/06/20 18:07:13  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.9  2010/06/11 00:27:45  mwvxm6
 *  Added status and restriction attributes methods
 *
 *  Revision 1.8  2010/06/11 00:23:02  mwvxm6
 *  Added status and restriction attributes
 *
 *  Revision 1.7  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/06/03 22:02:36  mwrrv3
 *  removed the boolean variable
 *
 *  Revision 1.5  2010/06/01 21:06:23  mwsyk1
 *  temporary added variable for OutofStateLicenseCanDelete
 *
 *  Revision 1.4  2010/05/27 14:37:54  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.3  2010/05/22 19:39:28  mwrsk
 *  Removed isOutOfStateLicenseCanDelete
 *
 *  Revision 1.2  2010/05/21 20:30:48  mwskd2
 *  OutofStateLicense checkbox logic is implemented
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.10  2010/03/03 15:44:31  mwrsk
 *  Changed commercial to isCommercial
 *
 *  Revision 1.9  2010/03/03 02:42:55  mwrsk
 *  Added isCommercial
 *
 *  Revision 1.8  2010/03/03 02:05:37  mwvxm6
 *  Updated attribute to name from currentName
 *
 *  Revision 1.7  2010/03/02 22:40:58  mwuxb
 *  Updated attribute name from ssnCode to ssn
 *
 *  Revision 1.6  2010/01/28 22:21:40  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.5  2010/01/25 21:59:31  mwuxb
 *  Additional variables for converters
 *
 *  Revision 1.4  2010/01/21 19:49:21  mwhxa2
 *  Modified - Now consists of List of Out of State Licenses
 *
 *  Revision 1.3  2010/01/21 19:48:16  mwhxa2
 *  Modified OutofStateLicense, it no longer extends DriverLicense
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.13  2009/10/07 16:58:29  mwpxr4
 *  Cleared unwanted comment.
 *
 *  Revision 1.12  2009/09/13 20:45:38  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.11.2.1  2009/09/12 19:08:52  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.11  2009/09/01 21:25:18  mwrrv3
 *  Added generated Serializable UID.
 *
 *  Revision 1.10  2009/08/27 05:39:52  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2009/08/26 17:44:06  mwsyk1
 *  moved previous application date
 *
 *  Revision 1.8  2009/08/22 23:21:48  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.7  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.6  2009/07/30 01:11:02  mwrrv3
 *  Removed isSuspended attribute.
 *
 *  Revision 1.5  2009/07/29 17:24:02  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.4  2009/07/27 21:41:37  mwcsj3
 *  Added class header
 *
 *  Revision 1.3  2009/07/21 18:33:58  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.2  2009/07/14 23:44:31  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:41:32  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
