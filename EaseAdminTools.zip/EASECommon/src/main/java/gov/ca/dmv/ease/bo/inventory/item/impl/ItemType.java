/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.impl.SequencePatternFactory;

/**
 * Description: I am default implementation of IItemType
 * File: ItemType.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/12/09 16:35:11 $
 * Last Changed By: $Author: mwkfh $
 */
public class ItemType implements IItemType {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1119307508170354664L;

	/**
	 * For code.
	 * 
	 * @param aCode the a code
	 * 
	 * @return the i item type
	 */
	public static IItemType forCode(String aCode) {
		//TODO - replace by retrieval of a predefined object
		ISequencePattern seqPattern = SequencePatternFactory.getInstance()
				.getSequencePatternForCode(aCode);
		return new ItemType(aCode, seqPattern.getDescription());
	}

	/** The code. */
	private String code;
	/** The description. */
	private String description;

	/**
	 * Instantiates a new item type.
	 */
	protected ItemType() {
		super();
	}

	/**
	 * Instantiates a new item type.
	 * 
	 * @param aCode the a code
	 */
	public ItemType(String aCode) {
		super();
		setCode(aCode);
	}

	/**
	 * Instantiates a new item type.
	 * 
	 * @param aCode the a code
	 * @param aDesc the a desc
	 */
	public ItemType(String aCode, String aDesc) {
		super();
		setCode(aCode);
		setDescription(aDesc);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ItemType other = (ItemType) obj;
		if (code == null) {
			if (other.code != null) {
				return false;
			}
		}
		else if (!code.equals(other.code)) {
			return false;
		}
		if (description == null) {
			if (other.description != null) {
				return false;
			}
		}
		else if (!description.equals(other.description)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemType#getCode()
	 */
	public String getCode() {
		return code;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemType#getDescription()
	 */
	public String getDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		return result;
	}

	/**
	 * Sets the code.
	 * 
	 * @param aCode the a code
	 */
	protected void setCode(String aCode) {
		code = aCode;
	}

	/**
	 * Sets the description.
	 * 
	 * @param aDesc the a desc
	 */
	protected void setDescription(String aDesc) {
		description = aDesc;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" code: ").append(code);
		aBuilder.append(" desc: ").append(description);
		aBuilder.append(" ]");
		return aBuilder.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: ItemType.java,v $
 *  Revision 1.5  2010/12/09 16:35:11  mwkfh
 *  added description to forCode
 *
 *  Revision 1.4  2010/10/05 22:27:27  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.3  2010/09/02 18:16:51  mwpxp2
 *  Added static utility forCode/1
 *
 *  Revision 1.2  2010/08/31 03:50:52  mwpxp2
 *  Added equals/1, hashCode/0
 *
 *  Revision 1.1  2010/08/30 21:46:33  mwpxp2
 *  Initial, not unit tested
 *
 */
