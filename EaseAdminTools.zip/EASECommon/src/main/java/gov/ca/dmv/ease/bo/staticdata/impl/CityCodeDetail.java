/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.staticdata.impl;

import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: Class representing City code detail each Office enters for lookup or keying aid
 * File: CityCodeSetElement.java
 * Module:  gov.ca.dmv.ease.bo.staticdata.impl
 * Created: Aug 20, 2009
 * 
 * @author mwvxm6
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/12/16 23:08:00 $
 * Last Changed By: $Author: mwkfh $
 */
public class CityCodeDetail extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3575232501451850997L;
	/** The city code. */
	private String cityCode;
	/** The city name. */
	private String cityName;
	/** The county code. */
	private String countyCode;
	/** The office. */
	private Office office;
	/** The office sys id. */
	private Long officeSysId;
	/** The zip code. */
	private String zipCode;

	/**
	 * Constructor.
	 */
	public CityCodeDetail() {
	}

	/**
	 * Constructor.
	 * 
	 * @param code the code
	 * @param name the name
	 * @param countyCode the county code
	 * @param zipCode the zip code
	 */
	public CityCodeDetail(String code, String name, String countyCode,
			String zipCode) {
		this.setCityCode(code);
		this.setCityName(name);
		this.setCountyCode(countyCode);
		this.setZipCode(zipCode);
	}

	/**
	 * Gets the City Code.
	 * 
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * Gets the City Name.
	 * 
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * Gets the County Code.
	 * 
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * Gets the office.
	 * 
	 * @return the office
	 */
	public Office getOffice() {
		return office;
	}

	/**
	 * Gets the office sys id.
	 * 
	 * @return the office sys id
	 */
	public Long getOfficeSysId() {
		return officeSysId;
	}

	/**
	 * Gets the Zip Code.
	 * 
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * Sets the City Code.
	 * 
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	/**
	 * Sets the City Name.
	 * 
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * Sets the County Code.
	 * 
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * Sets the office.
	 * 
	 * @param office the new office
	 */
	public void setOffice(Office office) {
		this.office = office;
		if (office != null) {
			officeSysId = office.getId();
		}
	}

	/**
	 * Sets the Zip Code.
	 * 
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CityCodeDetail.java,v $
 *  Revision 1.4  2010/12/16 23:08:00  mwkfh
 *  added officeSysId
 *
 *  Revision 1.3  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/05/19 22:43:35  mwrsk
 *  Added office - requested by bridge code
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.2  2010/01/28 22:36:48  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/07 01:19:20  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.2  2009/10/03 21:06:31  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.1  2009/09/04 01:41:17  mwvxm6
 *  Added CityCodeDetail list to the Office and a helper method to get CityCodeDetail for the specified city code
 *
 */
