/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.admin.impl.Employee;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.util.Date;

/** 
 * Voucher business object represents the information related to automated receipt.
 * File: Voucher.java
 * Module: gov.ca.dmv.ease.bo.financial.impl
 * Created: May 28, 2009
 * @author MWRRV3
 * @version $Revision: 1.16 $ 
 * Last Changed: $Date: 2010/12/23 07:25:45 $ Last
 * Changed By: $Author: mwrrv3 $ 
 */
public class Voucher extends Payment {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1200394439633557325L;

	/**
	 * Returns the sequence number as a string with zero fills.
	 * @param inputString
	 * @param expectedLength
	 * @return
	 */
	public static String filler(String inputString, int expectedLength) {
		StringBuilder stringBuilder = null;
		if (inputString != null) {
			if (inputString.length() > expectedLength) {
				inputString = inputString.substring(0, expectedLength);
			}
		}
		else if (inputString == null) {
			inputString = "";
		}
		int paddingNeeded = expectedLength - inputString.length();
		if (paddingNeeded <= 0) {
			return inputString;
		}
		char padding[] = new char[paddingNeeded];
		java.util.Arrays.fill(padding, '0');
		stringBuilder = new StringBuilder(expectedLength);
		stringBuilder.append(padding);
		stringBuilder.append(inputString);
		String returnString = stringBuilder.toString();
		return returnString;
	}

	/** This represents the comments for the voucher,. */
	private String comment;
	/** The employee. */
	private Employee employee;
	/** This represents the last 3 digits of VIN. */
	private String last3Vin;
	/** This represents the&nbsp;License number. */
	private String licenseNumber;
	/** This represents the customer or bundle ID. */
	private String nameOrBundleId;
	/** This represents the Office Id. */
	private Office office;
	/** The receipt phase number. Holds 1 for Phase I and 2 for Phase II payment transactions. */
	private String receiptPhaseNumber;
	/** This represents the sequence number on a receipt. */
	private Integer sequenceNumber;
	/** This represents the status code of a Voucher. C - Credit, I - Ignore */
	private CodeSetElement statusCode;
	/** Id is combination of office id, work date, employee id and sequence number(e.g 120 111208 20 300). */
	private String voucherId;
	/** This represents the work date on the receipt. */
	private Date workDate;

	public Voucher() {
		//employee = new Employee();
		//office = new Office();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Voucher other = (Voucher) obj;
		if (comment == null) {
			if (other.comment != null) {
				return false;
			}
		}
		else if (!comment.equals(other.comment)) {
			return false;
		}
		if (employee == null) {
			if (other.employee != null) {
				return false;
			}
		}
		else if (!employee.equals(other.employee)) {
			return false;
		}
		if (last3Vin == null) {
			if (other.last3Vin != null) {
				return false;
			}
		}
		else if (!last3Vin.equals(other.last3Vin)) {
			return false;
		}
		if (licenseNumber == null) {
			if (other.licenseNumber != null) {
				return false;
			}
		}
		else if (!licenseNumber.equals(other.licenseNumber)) {
			return false;
		}
		if (nameOrBundleId == null) {
			if (other.nameOrBundleId != null) {
				return false;
			}
		}
		else if (!nameOrBundleId.equals(other.nameOrBundleId)) {
			return false;
		}
		if (office == null) {
			if (other.office != null) {
				return false;
			}
		}
		else if (!office.equals(other.office)) {
			return false;
		}
		if (sequenceNumber == null) {
			if (other.sequenceNumber != null) {
				return false;
			}
		}
		else if (!sequenceNumber.equals(other.sequenceNumber)) {
			return false;
		}
		if (statusCode == null) {
			if (other.statusCode != null) {
				return false;
			}
		}
		else if (!statusCode.equals(other.statusCode)) {
			return false;
		}
		if (voucherId == null) {
			if (other.voucherId != null) {
				return false;
			}
		}
		else if (!voucherId.equals(other.voucherId)) {
			return false;
		}
		if (workDate == null) {
			if (other.workDate != null) {
				return false;
			}
		}
		else if (!workDate.equals(other.workDate)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the comment.
	 * 
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * Gets the last3 vin.
	 * 
	 * @return the last3Vin
	 */
	public String getLast3Vin() {
		return last3Vin;
	}

	/**
	 * Gets the license number.
	 * 
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/**
	 * Gets the name or bundle id.
	 * 
	 * @return the nameOrBundleId
	 */
	public String getNameOrBundleId() {
		return nameOrBundleId;
	}

	/**
	 * Gets the office.
	 * 
	 * @return the office
	 */
	public Office getOffice() {
		return office;
	}

	/**
	 * Gets the receipt phase number.
	 * 
	 * @return the receiptPhaseNumber
	 */
	public String getReceiptPhaseNumber() {
		return receiptPhaseNumber;
	}

	/**
	 * Gets the sequence number.
	 * 
	 * @return the sequenceNumber
	 */
	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * Returns the sequence number as a string with zero fills.
	 * @return
	 */
	public String getSequenceNumberAsString() {
		String sequenceNumberAsString = "";
		if (sequenceNumber != null) {
			return filler(sequenceNumber.toString(), 4);
		}
		return sequenceNumberAsString;
	}

	/**
	 * Gets the status code.
	 * 
	 * @return the status
	 */
	public CodeSetElement getStatusCode() {
		return statusCode;
	}

	public String getStatusCodeString() {
		if (statusCode == null) {
			return " ";
		}
		else {
			return statusCode.getCode();
		}
	}

	/**
	 * Gets the voucher id.
	 * 
	 * @return the voucherId
	 */
	public String getVoucherId() {
		return voucherId;
	}

	/**
	 * Gets the work date.
	 * 
	 * @return the workDate
	 */
	public Date getWorkDate() {
		return workDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((comment == null) ? 0 : comment.hashCode());
		result = prime * result
				+ ((employee == null) ? 0 : employee.hashCode());
		result = prime * result
				+ ((last3Vin == null) ? 0 : last3Vin.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime * result
				+ ((nameOrBundleId == null) ? 0 : nameOrBundleId.hashCode());
		result = prime * result + ((office == null) ? 0 : office.hashCode());
		result = prime * result
				+ ((sequenceNumber == null) ? 0 : sequenceNumber.hashCode());
		result = prime * result
				+ ((statusCode == null) ? 0 : statusCode.hashCode());
		result = prime * result
				+ ((voucherId == null) ? 0 : voucherId.hashCode());
		result = prime * result
				+ ((workDate == null) ? 0 : workDate.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.Payment#isVoucher()
	 */
	@Override
	public boolean isVoucher() {
		return true;
	}

	/**
	 * Sets the comment.
	 * 
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * Sets the employee.
	 * 
	 * @param employee the employee to set
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * Sets the last3 vin.
	 * 
	 * @param last3Vin the last3Vin to set
	 */
	public void setLast3Vin(String last3Vin) {
		this.last3Vin = last3Vin;
	}

	/**
	 * Sets the license number.
	 * 
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	/**
	 * Sets the name or bundle id.
	 * 
	 * @param nameOrBundleId the name or bundle id
	 */
	public void setNameOrBundleId(String nameOrBundleId) {
		this.nameOrBundleId = nameOrBundleId;
	}

	/**
	 * Sets the office.
	 * 
	 * @param office the office to set
	 */
	public void setOffice(Office office) {
		this.office = office;
	}

	/**
	 * Sets the receipt phase number.
	 * 
	 * @param receiptPhaseNumber the receiptPhaseNumber to set
	 */
	public void setReceiptPhaseNumber(String receiptPhaseNumber) {
		this.receiptPhaseNumber = receiptPhaseNumber;
	}

	/**
	 * Sets the sequence number.
	 * 
	 * @param sequenceNumber the sequenceNumber to set
	 */
	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * 
	 * @param sequenceNumberAsString
	 */
	public void setSequenceNumberAsString(String sequenceNumberAsString) {
		if (sequenceNumberAsString != null && isNumeric(sequenceNumberAsString)) {
			setSequenceNumber(Integer.parseInt(sequenceNumberAsString));
		} else {
			setSequenceNumber(null);
		}
	}

	/**
	 * Sets the status code.
	 * 
	 * @param status the status code to set
	 */
	public void setStatusCode(CodeSetElement statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Sets the voucher id.
	 * 
	 * @param voucherId the voucherId to set
	 */
	public void setVoucherId(String voucherId) {
		this.voucherId = voucherId;
	}

	/**
	 * Sets the work date.
	 * 
	 * @param workDate the workDate to set
	 */
	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}
	
	/**
	 * Check for numeric sequence number.
	 * @param str
	 * @return
	 */
	private static boolean isNumeric(String str) {
		try {
			int seqNumber = Integer.parseInt(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}  
	
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("comment", comment, anIndent, aBuilder);
		outputKeyValue("employee", employee, anIndent, aBuilder);
		outputKeyValue("last3Vin", last3Vin, anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("nameOrBundleId", nameOrBundleId, anIndent, aBuilder);
		outputKeyValue("office", office, anIndent, aBuilder);
		outputKeyValue("receiptPhaseNumber", receiptPhaseNumber, anIndent,
				aBuilder);
		outputKeyValue("sequenceNumber", sequenceNumber, anIndent, aBuilder);
		outputKeyValue("statusCode", statusCode, anIndent, aBuilder);
		outputKeyValue("voucherId", voucherId, anIndent, aBuilder);
		outputKeyValue("workDate", workDate, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $$Log: Voucher.java,v $
 *  $Revision 1.16  2010/12/23 07:25:45  mwrrv3
 *  $Updated setSequenceNumberAsString method to set null value for sequence number.
 *  $
 *  $Revision 1.15  2010/12/23 06:18:21  mwkkc
 *  $Merged Production code from Branch
 *  $
 *  $Revision 1.12.8.3  2010/12/23 03:13:54  mwkkc
 *  $Rebase from head - Common
 *  $
 *  $Revision 1.14  2010/12/22 23:17:19  mwrrv2
 *  $updated.
 *  $
 *  $Revision 1.12.8.2  2010/12/22 22:25:10  mwsyk1
 *  $Updated the setter method for voucher sequence number.
 *  $
 *  $Revision 1.12.8.1  2010/12/22 18:54:35  mwhys
 *  $Added isNumeric method.
 *  $
 *  $Revision 1.13  2010/12/22 18:53:53  mwrrv3
 *  $Added isNumeric.
 *  $
 *  $Revision 1.12  2010/12/07 22:08:32  mwpxp2
 *  $Implemented ITreePrintable
 *  $
 *  $Revision 1.11  2010/12/07 03:03:12  mwpxp2
 *  $Added toStringOn/1; sorted
 *  $
 *  $Revision 1.10  2010/12/04 01:05:39  mwpxp2
 *  $Added getStatusCodeString
 *  $
 *  $Revision 1.9  2010/11/15 23:51:22  mwgxk2
 *  $Sequence Number Fix.
 *  $
 *  $Revision 1.8  2010/11/11 02:25:52  mwnrk
 *  $Fix for sequence number as a string with zero fills
 *  $
 *  $Revision 1.7  2010/07/07 18:46:43  mwpxp2
 *  $Added is~ redefinition from super
 *  $
 *  $Revision 1.6  2010/05/10 20:59:31  mwuxb
 *  $changed type from Integer to String for variable - last3Vin
 *  $
 *  $Revision 1.5  2010/05/10 17:08:14  mwuxb
 *  $Changed String to CodeSetElement for attribute statusCode in Voucher
 *  $
 *  $Revision 1.4  2010/05/10 01:12:20  mwsxd10
 *  $StatusCode is changed from CodeSetElement to String.
 *  $
 *  $Revision 1.3  2010/05/06 14:55:48  mwuxb
 *  $Updated
 *  $
 *  $Revision 1.2  2010/05/06 14:37:12  mwuxb
 *  $Added attribute receiptPhaseNumber
 *  $
 *  $Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  $Initial commit of bo packages move to Common
 *  $
 *  $Revision 1.5  2010/03/04 02:20:45  mwuxb
 *  $Update status to statusCode
 *  $
 *  $Revision 1.4  2010/01/28 19:53:51  mwhxa2
 *  $Updated Java Docs
 *  $
 *  $Revision 1.3  2010/01/06 00:14:19  mwvxm6
 *  $BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *  $
 *  $Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  $BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *  $
 *  $Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  $Intial commit
 *  $
 *  $Revision 1.10  2009/10/13 22:39:29  mwvxm6
 *  $Added PaymentValidator so that the validate method get code coverage for this method.
 *  $Added a basic Payment validation to check for amount NOT= 0.
 *  $Comment out this validation if a uses case requires 0 or null amounts
 *  $
 *  $Revision 1.9  2009/10/03 21:06:33  mwpxp2
 *  $Adjusted imports for fw refactorings; bulk cleanup
 *  $
 *  $Revision 1.8  2009/09/24 23:03:11  mwhxa2
 *  $Removed unused imports
 *  $
 *  $Revision 1.7  2009/09/24 23:02:53  mwhxa2
 *  $Added getValidator()
 *  $
 *  $Revision 1.6  2009/08/27 05:39:42  mwpxp2
 *  $Bulk cleanup
 *  $
 *  $Revision 1.5  2009/08/22 23:21:46  mwrrv3
 *  $Implemented equals and hashCode methods.
 *  $$
 */
