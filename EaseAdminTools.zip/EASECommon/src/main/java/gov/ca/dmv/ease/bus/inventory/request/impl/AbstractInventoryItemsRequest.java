/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am abstract superclass for handling inventory requests
 * that operate on inventory items
 * 
 * File: AbstractInventoryItemsRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/10/07 17:15:48 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class AbstractInventoryItemsRequest extends
		AbstractInventoryRequest implements IInventoryItemsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2597882160084190668L;

	/**
	 * Instantiates a new abstract inventory items request.
	 */
	protected AbstractInventoryItemsRequest() {
		super();
	}

	/**
	 * Instantiates a new abstract inventory items request.
	 * 
	 * @param context the context
	 */
	protected AbstractInventoryItemsRequest(IUserContext context) {
		super(context);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.IInventoryRequest#execute()
	 */
	public abstract IInventoryServiceResponse execute();
}
/**
 *  Modification History:
 *
 *  $Log: AbstractInventoryItemsRequest.java,v $
 *  Revision 1.2  2010/10/07 17:15:48  mwkfh
 *  split getItem and getItemList into separate interfaces from IInventoryRequest
 *
 *  Revision 1.1  2010/09/20 23:22:14  mwpxp2
 *  Initial
 *
 */
