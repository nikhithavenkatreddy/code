/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.app.constants.DlIdDrivingSchoolInstructorTable;
import gov.ca.dmv.ease.app.constants.PrintClassCode;
import gov.ca.dmv.ease.app.constants.PrintRequestTypes;
import gov.ca.dmv.ease.app.constants.SalesPersonTable;
import gov.ca.dmv.ease.bo.document.IPrintDocumentHistory;
import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.List;

/**
 * Description: //TODO - provide description!
 * File: PrintDocumentHistory.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 4, 2011 
 * @author MWXXW  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/04/13 18:11:44 $
 * Last Changed By: $Author: mwxxw $
 */
public class PrintDocumentHistory extends BusinessObject implements IPrintDocumentHistory {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1728364620331286199L;
	/** The print request types. */
	private List<PrintRequestTypes> printRequestTypes;	
	/** Print class code for BCTR command. */
	private String printClassCode;	
	/** If it is from sales person TTC */
	private boolean fromSalesPerson;	
	
	/**
	 * @param printRequestTypes
	 * @param fromSalesPerson
	 */
	public PrintDocumentHistory(List <PrintRequestTypes> printRequestTypes,
			boolean fromSalesPerson) {
		super();
		this.printRequestTypes = printRequestTypes;
		this.fromSalesPerson = fromSalesPerson;
	}
	
	public String calculatePrintClassCode() {
		// calculate print class code.
		this.printClassCode = "  ";
		
		if (printRequestTypes != null && printRequestTypes.size() == 1) {
			this.printClassCode = calcClassCodeForSinglePrintDoc();			
		}
		else if (printRequestTypes != null && printRequestTypes.size() > 1) {
			this.printClassCode = calcClassCodeForMultiPrintDocs(this.isFromSalesPerson());			
		}
		
		return this.printClassCode;
	}
	/**
	 * Calculate Print Class Code For Single Print Document
	 * @return
	 */
	private String calcClassCodeForSinglePrintDoc() {
		PrintRequestTypes printRequestType = null;
		String retPrintClassCode = "  ";
		
		printRequestType = (PrintRequestTypes)this.printRequestTypes.get(0);
		if (PrintClassCode.getClassCodeByPrintRequestType(printRequestType) != null) {
			if (PrintClassCode.getClassCodeByPrintRequestType(printRequestType) != null) {
				retPrintClassCode = PrintClassCode.getClassCodeByPrintRequestType(printRequestType).getClassCode();
			}
		}
		return retPrintClassCode;
	}
	/**
	 * @param printRequestTypes2
	 * @param isFromSalesPerson
	 * @return
	 */
	private String calcClassCodeForMultiPrintDocs(boolean isFromSalesPerson) {
		PrintClassCode tempClassCode = null;
		PrintClassCode finalClassCode = null;
		int priorityId = -1;
		int tempPriorityId = 100;
		String retPrintClassCode = "  ";
		
		for (PrintRequestTypes item : printRequestTypes) {
			tempClassCode = PrintClassCode.getClassCodeByPrintRequestType(item);
			
			if (isFromSalesPerson) {
				if (tempClassCode != null) {
					priorityId = SalesPersonTable.getPriorityIdByPrintClassCode(tempClassCode.getClassCode());
				}
			}
			else {
				if (tempClassCode != null) {
					priorityId = DlIdDrivingSchoolInstructorTable.getPriorityIdByPrintClassCode(tempClassCode.getClassCode());
				}
			}
			
			if (priorityId != -1) {
				if (priorityId < tempPriorityId) {
					tempPriorityId = priorityId;
					finalClassCode = tempClassCode;
				}
			}
		}
		
		if (finalClassCode != null) {
			retPrintClassCode = finalClassCode.getClassCode();
		} 
		else {
			retPrintClassCode = calcClassCodeForSinglePrintDoc();
		}
		
		return retPrintClassCode;
	}
	/**
	 * Getter for printRequestTypes
	 * @return
	 */
	public List<PrintRequestTypes> getPrintRequestTypes() {
		return printRequestTypes;
	}

	/**
	 * Setter for printRequestTypes
	 * @param printRequestTypes
	 */
	private void setPrintRequestTypes(List<PrintRequestTypes> printRequestTypes) {
		this.printRequestTypes = printRequestTypes;
	}

	/**
	 * Getter for printClassCode.
	 * @return
	 */
	public String getPrintClassCode() {
		return printClassCode;
	}

	/**
	 * Setter for printClassCode.
	 * @param printClassCode
	 */
	private void setPrintClassCode(String printClassCode) {
		this.printClassCode = printClassCode;
	}
	
	/**
	 * If it is From Sales Person.
	 * @return
	 */
	public boolean isFromSalesPerson() {
		return fromSalesPerson;
	}
	
	/**
	 * Setter for From Sales Person.
	 * @param fromSalesPerson
	 */
	private void setFromSalesPerson(boolean fromSalesPerson) {
		this.fromSalesPerson = fromSalesPerson;
	}	
}


/**
 *  Modification History:
 *
 *  $Log: PrintDocumentHistory.java,v $
 *  Revision 1.7  2011/04/13 18:11:44  mwxxw
 *  Fix defect 5743.
 *
 *  Revision 1.6  2011/04/08 00:57:57  mwxxw
 *  Use IPrintDocumentHistory instead of PrintDocumentHistory
 *
 *  Revision 1.5  2011/04/06 22:19:07  mwxxw
 *  Add more printClassCode mapping according requirement.
 *
 *  Revision 1.4  2011/04/06 02:18:49  mwxxw
 *  Make it extends BaseBusinessObject.
 *
 *  Revision 1.3  2011/04/06 01:36:21  mwxxw
 *  Change the signature for calculatePrintClassCode() function.
 *
 *  Revision 1.2  2011/04/06 01:17:30  mwxxw
 *  Add new field: boolean fromSalesPerson.
 *
 *  Revision 1.1  2011/04/06 00:32:17  mwxxw
 *  New files add for calculation printClassCode for printed docs.
 *
 */
