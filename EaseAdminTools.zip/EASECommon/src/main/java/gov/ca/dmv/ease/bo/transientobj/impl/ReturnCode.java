/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.impl;

import java.io.Serializable;

/**
 * Description: I am Return Code
 * File: ReturnCode.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.impl
 * Created: May 6, 2009
 * @author MWCSJ3
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/07/22 17:50:33 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ReturnCode implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2960978046499371578L;
	/** The code. */
	private String code;
	/** The message. */
	private String message;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ReturnCode other = (ReturnCode) obj;
		if (code == null) {
			if (other.code != null) {
				return false;
			}
		}
		else if (!code.equals(other.code)) {
			return false;
		}
		if (message == null) {
			if (other.message != null) {
				return false;
			}
		}
		else if (!message.equals(other.message)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Gets the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		return result;
	}

	/**
	 * Sets the code.
	 * 
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Sets the message.
	 * 
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ReturnCode.java,v $
 *  Revision 1.4  2010/07/22 17:50:33  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/06/21 23:01:04  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.8.2  2010/06/20 18:07:15  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/02 20:57:01  mwvxm6
 *  Updated equals method
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/03/15 23:00:12  mwhxa2
 *  Implements serializable
 *
 *  Revision 1.2  2010/01/28 22:41:12  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/07/14 23:44:33  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:55:40  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:25  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
