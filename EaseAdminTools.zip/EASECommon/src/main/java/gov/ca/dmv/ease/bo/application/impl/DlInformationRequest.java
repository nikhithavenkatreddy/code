/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.subject.impl.Person;

/**
 * Description: This class is for the TTC DIR which receipts the sale of driver or vehicle information.
 * It also allows no fee requests to be processed.
 * File: DlInformationRequest.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class DlInformationRequest extends Application {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8629184176260381766L;
	/** The info code. */
	private CodeSetElement infoCode;
	
	/** The inquiry type code. */
	private CodeSetElement inquiryTypeCode;
	
	/** The is fee information requested indicator. */
	private Boolean isFeeInformationRequestedIndicator;

	/**
	 * Instantiates a new dl information request.
	 *
	 * @param anApplicant the an applicant
	 */
	public DlInformationRequest(Person anApplicant) {
		super();
		setApplicant(anApplicant);
	}

	/**
	 * @return the infoCode
	 */
	public CodeSetElement getInfoCode() {
		return infoCode;
	}

	/**
	 * @return the inquiryTypeCode
	 */
	public CodeSetElement getInquiryTypeCode() {
		return inquiryTypeCode;
	}

	/**
	 * @return the isFeeInformationRequestedIndicator
	 */
	public Boolean isFeeInformationRequestedIndicator() {
		return isFeeInformationRequestedIndicator;
	}

	/**
	 * @param isFeeInformationRequestedIndicator the isFeeInformationRequestedIndicator to set
	 */
	public void setFeeInformationRequestedIndicator(
			Boolean isFeeInformationRequestedIndicator) {
		this.isFeeInformationRequestedIndicator = isFeeInformationRequestedIndicator;
	}

	/**
	 * @param infoCode the infoCode to set
	 */
	public void setInfoCode(CodeSetElement infoCode) {
		this.infoCode = infoCode;
	}

	/**
	 * @param inquiryTypeCode the inquiryTypeCode to set
	 */
	public void setInquiryTypeCode(CodeSetElement inquiryTypeCode) {
		this.inquiryTypeCode = inquiryTypeCode;
	}
}
/**
 *  Modification History:
 *
 *  $Log: DlInformationRequest.java,v $
 *  Revision 1.9  2012/03/14 01:57:56  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.8  2011/10/19 17:09:49  mwpxp2
 *  Added missing footer; added constructor/1 for unit tests
 *
 */