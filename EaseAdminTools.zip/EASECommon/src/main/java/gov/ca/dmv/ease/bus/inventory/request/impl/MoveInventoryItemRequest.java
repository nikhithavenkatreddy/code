/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I represent a request to move potentially multiple inventory items to a single target location.
 * Each item knows its location of origin.
 * 
 * File: MoveInventoryItemRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/07/06 17:11:03 $
 * Last Changed By: $Author: mwkfh $
 */
public class MoveInventoryItemRequest extends AbstractMultipleSequenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1222107372144081273L;
	/** The location. */
	private IItemLocation location;

	/**
	 * The Constructor.
	 * 
	 * @param context
	 * @param aSequence
	 */
	public MoveInventoryItemRequest(IUserContext context,
			IItemLocation targetLocation, IContiguousItemSequence aSequence) {
		super(context, aSequence);
		setLocation(targetLocation);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}

	/**
	 * Gets the location.
	 * 
	 * @return the location
	 */
	public IItemLocation getLocation() {
		return location;
	}

	/**
	 * Sets the location.
	 * 
	 * @param location the location to set
	 */
	protected void setLocation(IItemLocation aLocation) {
		location = aLocation;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MoveInventoryItemRequest.java,v $
 *  Revision 1.3  2011/07/06 17:11:03  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.2  2010/09/20 23:19:31  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.2  2010/09/14 19:53:20  mwpxp2
 *  Added constructors from super
 *
 *  Revision 1.1  2010/09/14 18:59:37  mwpxp2
 *  Initial
 *
 */
