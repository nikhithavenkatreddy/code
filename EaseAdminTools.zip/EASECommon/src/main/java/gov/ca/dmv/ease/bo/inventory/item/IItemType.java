/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

import java.io.Serializable;

/**
 * Description: I am interface for inventory item:
 *  - I have a code, e.g. "400"
 *  - I have a description, e.g.  "DL/ID NUMBER"
 *  There should be a single instance of the implementation for a given unique code in the app scope.
 *  
 * File: IItemType.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/09/02 19:02:04 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IItemType extends Serializable {
	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	String getCode();

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	String getDescription();
}
/**
 *  Modification History:
 *
 *  $Log: IItemType.java,v $
 *  Revision 1.4  2010/09/02 19:02:04  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/08/31 23:30:55  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2010/08/30 22:35:08  mwpxp2
 *  Changed super to Object from bo
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
