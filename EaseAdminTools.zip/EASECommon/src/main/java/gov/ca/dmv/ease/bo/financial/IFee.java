package gov.ca.dmv.ease.bo.financial;

import java.math.BigDecimal;

public interface IFee {
	/**
	 * Gets the amount.
	 * 
	 * @return the amount
	 */
	public abstract BigDecimal getAmount();

	/**
	 * Gets the fee type.
	 * 
	 * @return the feeType
	 */
	public abstract String getFeeType();

	/**
	 * @return the rateCode
	 */
	public abstract String getRateCode();
}
/**
 *  Modification History:
 *
 *  $Log: IFee.java,v $
 *  Revision 1.1  2011/10/21 22:24:41  mwpxp2
 *  Initial - extracted out from the WS4 payment implementation
 *
 */
