package gov.ca.dmv.ease.bo.admin;

import java.util.Date;

/**
 * Description: I am interface for employee workdate control implementations
 * File: IEmployeeWorkdateControl.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/10/21 23:25:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEmployeeWorkdateControl {
	/**
	 * Gets the authorized work date.
	 * 
	 * @return the authorizedWorkDate
	 */
	Date getAuthorizedWorkDate();

	/**
	 * Gets the current admin sequence number.
	 * 
	 * @return the currentAdminSequenceNumber
	 */
	Integer getCurrentAdminSequenceNumber();

	/**
	 * Gets the current dl mt sequence number.
	 * 
	 * @return the currentDlMtSequenceNumber
	 */
	Integer getCurrentDlMtSequenceNumber();

	/**
	 * Gets the current dl sequence number.
	 * 
	 * @return the currentDlSequenceNumber
	 */
	Integer getCurrentDlSequenceNumber();

	/**
	 * Gets the current vr mt sequence number.
	 * 
	 * @return the currentVrMtSequenceNumber
	 */
	Integer getCurrentVrMtSequenceNumber();

	/**
	 * Gets the current vr sequence number.
	 * 
	 * @return the currentVrSequenceNumber
	 */
	Integer getCurrentVrSequenceNumber();

	/**
	 * Gets the employee.
	 * 
	 * @return the employeeManager
	 */
	IEmployee getEmployee();

	/**
	 * Gets the office workdate.
	 * 
	 * @return the office
	 */
	IOfficeWorkdate getOfficeWorkdate();

	/**
	 * Gets the status.
	 * 
	 * @return the status
	 */
	String getStatus();
}
/**
 *  Modification History:
 *
 *  $Log: IEmployeeWorkdateControl.java,v $
 *  Revision 1.2  2011/10/21 23:25:06  mwpxp2
 *  Changed referenced types to interfaces where possible
 *
 *  Revision 1.1  2011/10/21 23:21:51  mwpxp2
 *  Extracted from existing implementation
 *
 */
