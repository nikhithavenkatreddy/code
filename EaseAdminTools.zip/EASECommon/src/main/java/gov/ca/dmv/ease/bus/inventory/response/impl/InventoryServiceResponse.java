/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response.impl;

import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

/**
 * Description: I am generic response for Inventory Service requests
 * File: InventoryServiceResponse.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.response.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/10/13 02:11:43 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryServiceResponse extends AbstractResponse implements
		IInventoryServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6527717530874552150L;
	/** The affected item count. */
	private int affectedItemCount = 0;

	/**
	 * Instantiates a new inventory service response.
	 */
	protected InventoryServiceResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public InventoryServiceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public InventoryServiceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new inventory service response.
	 * 
	 * @param anItemCount the an item count
	 * @param collector the collector
	 */
	public InventoryServiceResponse(int anItemCount, IErrorCollector collector) {
		super(collector);
		setAffectedItemCount(anItemCount);
	}

	/**
	 * Instantiates a new inventory service response.
	 * 
	 * @param itemCount the item count
	 */
	public InventoryServiceResponse(int anItemCount) {
		super();
		setAffectedItemCount(anItemCount);
	}

	/**
	 * Gets the affected item count.
	 * 
	 * @return the affected item count
	 */
	public int getAffectedItemCount() {
		return affectedItemCount;
	}

	/**
	 * Sets the affected item count.
	 * 
	 * @param affectedItemCount the new affected item count
	 */
	protected void setAffectedItemCount(int affectedItemCount) {
		this.affectedItemCount = affectedItemCount;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractResponse#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(64);
		aBuilder.append(getClass().getName()).append("[");
		aBuilder.append("responseCode =").append(responseCode);
		aBuilder.append("; affectedItemCount =").append(affectedItemCount);
		aBuilder.append("; errorCollector =").append(getErrorCollector());
		aBuilder.append("; validationMessageObject =").append(
				getValidationMessageObject());
		aBuilder.append("]");
		return aBuilder.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryServiceResponse.java,v $
 *  Revision 1.4  2010/10/13 02:11:43  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.3  2010/10/13 01:55:35  mwpxp2
 *  Added contructor/2 with item count and error collector
 *
 *  Revision 1.2  2010/09/20 22:08:59  mwpxp2
 *  Implemented IInventoryServiceResponse - satisfied todo
 *
 *  Revision 1.1  2010/09/20 20:29:13  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.5  2010/09/15 23:47:27  mwpxp2
 *  Made default constructor non-public
 *
 *  Revision 1.4  2010/09/15 01:15:08  mwpxp2
 *  Added todo
 *
 *  Revision 1.3  2010/09/02 20:44:55  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.2  2010/09/01 00:36:19  mwpxp2
 *  Cleanup
 *
 *  Revision 1.1  2010/08/31 23:59:29  mwpxp2
 *  Initial
 *
 */
