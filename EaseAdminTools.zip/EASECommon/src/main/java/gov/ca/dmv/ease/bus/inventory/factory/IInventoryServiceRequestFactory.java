/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.factory;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryStateRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am interface for creating instances of requests for Inventory Service
 * File: IInventoryServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.15 $
 * Last Changed: $Date: 2011/11/04 16:39:19 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryServiceRequestFactory {
	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param items the items
	 * @param context the context
	 * 
	 * @return the adds the inventory item request
	 */
	IInventoryItemsRequest createAddItemsRequest(IUserContext context,
			IInventoryItem... items);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param aListOfItems the a list of items
	 * @param context the context
	 * 
	 * @return the adds the inventory item request
	 */
	IInventoryItemsRequest createAddItemsRequest(IUserContext context,
			List <IInventoryItem> aListOfItems);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param aSequence the sequence
	 * 
	 * @return the seed inventory from dmva request
	 */
	IInventoryItemsRequest createAddInventoryRequest(IUserContext context,
			IContiguousItemSequence aSequence);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param aListOfItems the a list of items
	 * 
	 * @return the Add Station Inventory Assignment Request
	 */
	IInventoryItemsRequest createAddStationInventoryAssignmentRequest(
			IUserContext context, List <IInventoryItem> aListOfItems);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param aSequence the item aSequence
	 * 
	 * @return the adds the inventory items request
	 */
	IInventoryItemsRequest createDeleteInventoryRequest(IUserContext context,
			IContiguousItemSequence aSequence);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param aListOfItemThresholds the a list of item thresholds
	 * @param context the context
	 * 
	 * @return the adds the get current item count request
	 */
	IInventoryStateRequest createGetCurrentItemCountRequest(
			IUserContext context, List <IItemThreshold> aListOfItems);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param itemTypeCode the item type code
	 * @param officeId the office id
	 * 
	 * @return the adds the inventory item request
	 */
	IInventoryItemRequest createGetLowestSequenceRequest(IUserContext context,
			String anItemTypeCode, String officeId);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param itemTypeCode the item type code
	 * @param forLocation the target location
	 * @param context the context
	 * 
	 * @return the adds the issue inventory item request
	 */
	IInventoryItemRequest createIssueInventoryItemRequest(IUserContext context,
			IItemLocation forLocation, String anItemTypeCode);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param forLocation the target location
	 * @param itemTypeCode the item type code
	 * @param quantity the quantity
	 * 
	 * @return the adds the issue inventory item request
	 */
	IInventoryItemRequest createIssueMultipleInventoryItemsRequest(
			IUserContext context, IItemLocation forLocation,
			String anItemTypeCode, int quantity);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param itemSequenceList the item sequence list
	 * 
	 * @return the issue inventory item request
	 */
	IInventoryItemsRequest createManuallyIssueMultipleInventoryItemsSequenceRequest(
			IUserContext context,
			List <IContiguousItemSequence> itemSequenceList);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param targetLocation
	 * @param aSequence the item aSequence
	 * 
	 * @return the adds the inventory items request
	 */
	IInventoryItemsRequest createMoveItemsRequest(IUserContext context,
			IItemLocation targetLocation, IContiguousItemSequence aSequence);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param aListOfItems the a list of items
	 * 
	 * @return the Remove Station Inventory Assignment Request
	 */
	IInventoryItemsRequest createRemoveStationInventoryAssignmentRequest(
			IUserContext context, List <IInventoryItem> aListOfItems);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param context the context
	 * @param itemsToIssue the item list
	 * 
	 * @return the issue inventory item request
	 */
	IInventoryItemsRequest createRestoreInventoryItemsAvailabilityRequest(
			IUserContext context, List <IContiguousItemSequence> itemsToIssue);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param sequences the sequences
	 * @param context the context
	 * 
	 * @return the seed inventory from dmva request
	 */
	IInventoryItemsRequest createSeedInventoryRequest(IUserContext context,
			IContiguousItemSequence... sequences);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param aListOfSequences the a list of sequences
	 * @param context the context
	 * 
	 * @return the seed inventory from dmva request
	 */
	IInventoryItemsRequest createSeedInventoryRequest(IUserContext context,
			List <IContiguousItemSequence> aListOfSequences);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param sequences the sequences
	 * @param context the context
	 * 
	 * @return the seed inventory from dmva request
	 */
	IInventoryItemsRequest createSeedInventoryRequest(IUserContext context,
			String officeId, IContiguousItemSequence... sequences);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param aListOfSequences the a list of sequences
	 * @param officeId the office id to purge
	 * @param processorId the processor id to purge
	 * @param context the context
	 * 
	 * @return the seed inventory from dmva request
	 */
	IInventoryItemsRequest createSeedInventoryRequest(IUserContext context,
			String officeId, String processorId,
			List <IContiguousItemSequence> aListOfSequences);

	/**
	 * Creates a new IInventoryServiceRequest object.
	 * 
	 * @param aListOfItemThresholds the a list of item thresholds
	 * @param officeId the office id to purge
	 * @param context the context
	 * 
	 * @return the adds the set current item count request
	 */
	IInventoryStateRequest createSetItemCountThresholdRequest(
			IUserContext context, List <IItemThreshold> aListOfItems);
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryServiceRequestFactory.java,v $
 *  Revision 1.15  2011/11/04 16:39:19  mwkfh
 *  added GetLowestSequence
 *
 *  Revision 1.14  2011/09/23 00:20:29  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.13  2011/07/13 17:31:06  mwkfh
 *  added RemoveStationInventoryAssignmentRequest
 *
 *  Revision 1.12  2011/07/12 00:11:17  mwkfh
 *  added AddStationInventoryAssignmentRequest
 *
 *  Revision 1.11  2011/07/07 22:32:40  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.10  2011/07/06 17:10:49  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.9  2011/06/09 18:32:22  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.8  2011/06/08 18:55:33  mwkfh
 *  added AddInventoryRequest
 *
 *  Revision 1.7  2011/01/10 21:48:06  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.6  2010/12/08 19:03:12  mwkfh
 *  added RestoreInventoryItemsAvailabilityRequest
 *
 *  Revision 1.5  2010/12/07 00:18:38  mwkfh
 *  added createManuallyIssueMultipleInventoryItemsRequests
 *
 *  Revision 1.4  2010/12/05 00:06:16  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 *  Revision 1.3  2010/10/07 17:55:16  mwkfh
 *  fixed return type for createIssueInventoryItemRequest
 *
 *  Revision 1.2  2010/10/05 17:40:32  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.1  2010/09/20 20:29:14  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.5  2010/09/15 00:16:09  mwpxp2
 *  Removed deps on implementation types - created requests are returned as IInventoryRequest
 *
 *  Revision 1.4  2010/09/14 20:01:15  mwpxp2
 *  Refactored to use four types of requests: add, remove, move, seed
 *
 *  Revision 1.3  2010/09/02 20:44:55  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.2  2010/09/01 00:35:04  mwpxp2
 *  Initial
 *
 *  Revision 1.1  2010/09/01 00:18:04  mwpxp2
 *  Initial
 *
 */
