/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_FIRST_MIDDLE_LAST;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_LAST_FIRST;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX_WITH_COMMA;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_LAST_MIDDLE_FIRST;
import static gov.ca.dmv.ease.app.constants.IPersonNameFormatConstants.NAME_FORMAT_MIDDLE_LAST_FIRST;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: PersonName is the subclass of Name. PersonName class
 * encapsulates the first name, last name, middle name, prefix and suffix, which
 * are specific to a person.
 * File: PersonName.java
 * Module:gov.ca.dmv.ease.bo.subject.impl
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.35 $
 * Last Changed: $Date: 2013/03/05 23:45:13 $
 * Last Changed By: $Author: mwhys $
 */
public class PersonName extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -143289030349144151L;
	/** The constant empty space. */
	private static final String EMPTY_SPACE = " ";
	/** The Constant BLANK. */
	private static final String BLANK = "";
	/** The first name of a person. */
	private String firstName;
	/** Holds the flag for primary name. */
	private Boolean isPrimary = true;
	/** The is processed. */
	private boolean isProcessed;
	/** The last name of a person. */
	private String lastName;
	/** The middle name of a person. */
	private String middleName;
	/** Holds the prefix of a person. */
	private String prefix;
	/** Holds the suffix of the person. */
	private String suffix;

	/**
	 * Default constructor.
	 */
	public PersonName() {
	}

	/**
	 * Instantiates a new person name.
	 *
	 * @param personName the person name
	 */
	public PersonName(PersonName personName) {
		super();
		copy(personName);
	}

	/**
	 * Instantiates a new person name.
	 *
	 * @param firstName the first name
	 * @param middleName the middle name
	 * @param lastName the last name
	 * @param suffix the suffix
	 */
	public PersonName(String firstName, String middleName, String lastName,
			String suffix) {
		super();
		setFirstName(firstName);
		setMiddleName(middleName);
		setLastName(lastName);
		setSuffix(suffix);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonName other = (PersonName) obj;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		}
		else if (!firstName.equals(other.firstName))
			return false;
		if (isPrimary == null) {
			if (other.isPrimary != null)
				return false;
		}
		else if (!isPrimary.equals(other.isPrimary))
			return false;
		if (isProcessed != other.isProcessed)
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		}
		else if (!lastName.equals(other.lastName))
			return false;
		if (middleName == null) {
			if (other.middleName != null)
				return false;
		}
		else if (!middleName.equals(other.middleName))
			return false;
		if (prefix == null) {
			if (other.prefix != null)
				return false;
		}
		else if (!prefix.equals(other.prefix))
			return false;
		if (suffix == null) {
			if (other.suffix != null)
				return false;
		}
		else if (!suffix.equals(other.suffix))
			return false;
		return true;
	}

	/**
	 * Gets the first name.
	 * 
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Get the full name (First, Middle, Last) of a person.
	 * 
	 * @return the full name
	 */
	public String getFullName() {
		return getFullName(NAME_FORMAT_FIRST_MIDDLE_LAST);
	}

	/**
	 * Get the full name (First, Middle,Suffix Last) of a person.
	 * 
	 * @return the full name
	 */
	public String getFullNameWithSuffix() {
		return getFullName(NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST);
	}

	/**
	 * Get the full name (First, Middle, Last, Suffix) of a person.
	 * 
	 * @return the full name
	 */
	public String getNameWithSuffix() {
		return getFullName(NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX);
	}

	/**
	 * Sets the name of the person.
	 *
	 * @param aName the new name with suffix
	 */
	public void setNameWithSuffix(String aName) {
		this.setName(aName);
	}

	/**
	 * This method returns the full name in specified format.
	 * 
	 * @param nameFormat Format of the name
	 * @return Full Name
	 */
	public String getFullName(int nameFormat) {
		StringBuilder fullNameSb = new StringBuilder(40);
		if (nameFormat == NAME_FORMAT_LAST_MIDDLE_FIRST) {
			if (getLastName() != null) {
				fullNameSb.append(getLastName().trim()).append(EMPTY_SPACE);
			}
			if (getMiddleName() != null) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (getFirstName() != null) {
				fullNameSb.append(getFirstName().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_LAST_FIRST) {
			if (getLastName() != null) {
				fullNameSb.append(getLastName().trim()).append(EMPTY_SPACE);
			}
			if (getFirstName() != null) {
				fullNameSb.append(getFirstName().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_MIDDLE_LAST_FIRST) {
			if (getMiddleName() != null) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (getLastName() != null) {
				fullNameSb.append(getLastName().trim()).append(EMPTY_SPACE);
			}
			if (getFirstName() != null) {
				fullNameSb.append(getFirstName().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX) {
			if (!isNullOrBlank(getLastName())) {
				fullNameSb.append(getLastName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getFirstName())) {
				fullNameSb.append(getFirstName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getMiddleName())) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getSuffix())) {
				fullNameSb.append(getSuffix().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX_WITH_COMMA) {
			if (!isNullOrBlank(getLastName())) {
				fullNameSb.append(getLastName().trim());
			}
			if (!isNullOrBlank(getFirstName())) {
				fullNameSb.append(EMPTY_SPACE).append(getFirstName().trim());
			}
			if (!isNullOrBlank(getMiddleName())) {
				fullNameSb.append(EMPTY_SPACE).append(getMiddleName().trim());
			}
			if (!isNullOrBlank(getSuffix())) {
				fullNameSb.append(",").append(getSuffix().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX) {
			if (!isNullOrBlank(getFirstName())) {
				fullNameSb.append(getFirstName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getMiddleName())) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getLastName())) {
				fullNameSb.append(getLastName().trim());
			}
			if (!isNullOrBlank(getSuffix())) {
				fullNameSb.append(",").append(getSuffix().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX) {
			if (!isNullOrBlank(getFirstName())) {
				fullNameSb.append(getFirstName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getMiddleName())) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getLastName())) {
				fullNameSb.append(getLastName().trim());
			}
			if (!isNullOrBlank(getSuffix())) {
				fullNameSb.append(",").append(getSuffix().trim());
			}
		}
		else if (nameFormat == NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST) {
			if (!isNullOrBlank(getFirstName())) {
				fullNameSb.append(getFirstName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getMiddleName())) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getSuffix())) {
				fullNameSb.append(getSuffix().trim()).append(EMPTY_SPACE);
			}
			if (!isNullOrBlank(getLastName())) {
				fullNameSb.append(getLastName().trim());
			}
		}
		else {
			if (getFirstName() != null) {
				fullNameSb.append(getFirstName().trim()).append(EMPTY_SPACE);
			}
			if (getMiddleName() != null) {
				fullNameSb.append(getMiddleName().trim()).append(EMPTY_SPACE);
			}
			if (getLastName() != null) {
				if (getFirstName() != null) {
					fullNameSb.append(getLastName().trim());
				}
				else {
					fullNameSb.append(getLastName().trim());
				}
			}
		}
		return (fullNameSb.length() == 0 ? null : fullNameSb.toString());
	}

	/**
	 * Gets the is primary.
	 * 
	 * @return the isPrimary
	 */
	public Boolean getIsPrimary() {
		return isPrimary;
	}

	/**
	 * Gets the last name.
	 * 
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Gets the middle name.
	 * 
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return getFullName();
	}

	/**
	 * Gets the prefix.
	 * 
	 * @return the prefix
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * Gets the suffix.
	 * 
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result
				+ ((isPrimary == null) ? 0 : isPrimary.hashCode());
		result = prime * result + (isProcessed ? 1231 : 1237);
		result = prime * result
				+ ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result
				+ ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result + ((prefix == null) ? 0 : prefix.hashCode());
		result = prime * result + ((suffix == null) ? 0 : suffix.hashCode());
		return result;
	}

	/**
	 * Checks if is processed.
	 * 
	 * @return the isProcessed
	 */
	public Boolean isProcessed() {
		return isProcessed;
	}

	/**
	 * Parses the and remove suffix in.
	 * 
	 * @param aName
	 *            the a name
	 * 
	 * @return the string
	 */
	private String parseAndRemoveSuffixIn(String aName) {
		String trimmedName = aName.trim();
		// Parsing and removing suffix
		int commaPos = trimmedName.indexOf(",");
		if (commaPos >= 0) {
			setSuffix(trimmedName.substring(commaPos + 1).trim());
			return trimmedName.substring(0, commaPos).trim();
		}
		else {
			return trimmedName.trim();
		}
	}

	/**
	 * Parses the and set names from.
	 * 
	 * @param aName
	 *            the a name
	 */
	private void parseAndSetNamesFrom(String aName) {
		if (aName == null) {
			return;
		}
		// Parsing and removing suffix
		String adjustedName = parseAndRemoveSuffixIn(aName);
		// Parsing Name
		String personName[] = adjustedName.split(EMPTY_SPACE);
		int partsNo = personName.length;
		if (partsNo > 3) {
			setFirstName(personName[0]);
			setMiddleName(personName[1]);
			StringBuilder lastNameBuilder = new StringBuilder();
			// add all remaining names to the last name, this may include the
			// suffix if the user left out the comma, if so they will get a
			// warnign.
			for (int i = 2; i < personName.length; i++) {
				// lastNameBuilder.append(i == 2 ? personName[i] : " " +
				// personName[i]);
				if (i != 2) {
					lastNameBuilder.append(" ");
				}
				lastNameBuilder.append(personName[i]);
			}
			setLastName(lastNameBuilder.toString());
		}
		if (partsNo == 3) {
			setFirstName(personName[0]);
			setMiddleName(personName[1]);
			setLastName(personName[2]);
		}
		else if (partsNo == 2) {
			setFirstName(personName[0]);
			setLastName(personName[1]);
			setMiddleName(null);
		}
		else if (partsNo == 1) {
			setLastName(personName[0]);
			setFirstName(null);
			setMiddleName(null);
		}
	}

	/**
	 * Sets the first name.
	 * 
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Sets the is primary.
	 * 
	 * @param isPrimary
	 *            the isPrimary to set
	 */
	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	/**
	 * Sets the last name.
	 * 
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Sets the middle name.
	 * 
	 * @param middleName
	 *            the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * Gets the Person Name in the 3 position format.
	 *
	 * @return the 3 POS name
	 */
	public String getThreePosName() {
		String lastName = getLastName();
		String firstName = getFirstName();
		//If the last name is more than 3 characters, trim it and return it
		if (!isNullOrBlank(lastName) && lastName.length() > 3) {
			return lastName.substring(0, 3);
		}
		//Else if it is 3 or 2 characters, return it as is
		else if (!isNullOrBlank(lastName) && lastName.length() >= 2) {
			return lastName;
		}
		//Else if it is only 1 character and there is first name, 
		//return last_name + SPACE + 1st character of first name
		else if (!isNullOrBlank(lastName) && lastName.length() == 1
				&& !isNullOrBlank(firstName)) {
			return lastName + EMPTY_SPACE + firstName.substring(0, 1);
		}
		//Else if it is only 1 character and no first name.
		//return as is.
		else if (!isNullOrBlank(lastName) && lastName.length() == 1
				&& isNullOrBlank(firstName)) {
			return lastName;
		}
		return BLANK;
	}

	/**
	 * Sets the name of the person.
	 * 
	 * @param aName
	 *            the a name
	 */
	public void setName(String aName) {
		if (aName == null) {
			setFirstName(null);
			setMiddleName(null);
			setLastName(null);
			setPrefix(null);
		}
		else {
			parseAndSetNamesFrom(aName);
		}
	}

	/**
	 * Sets the prefix.
	 * 
	 * @param prefix
	 *            the new prefix
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	/**
	 * Sets the processed.
	 * 
	 * @param isProcessed
	 *            the isProcessed to set
	 */
	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	/**
	 * Sets the suffix.
	 * 
	 * @param suffix
	 *            the new suffix
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("prefix", prefix, anIndent, aBuilder);
		outputKeyValue("firstName", firstName, anIndent, aBuilder);
		outputKeyValue("middleName", middleName, anIndent, aBuilder);
		outputKeyValue("lastName", lastName, anIndent, aBuilder);
		outputKeyValue("suffix", suffix, anIndent, aBuilder);
		outputKeyValue("isPrimary", isPrimary, anIndent, aBuilder);
		outputKeyValue("isProcessed", isProcessed, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/**
	 * This method is to copy PersonName.
	 *
	 * @param objectToCopy the object to copy
	 */
	protected void copy(PersonName objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null personName argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		setFirstName(objectToCopy.getFirstName());
		setIsPrimary(objectToCopy.getIsPrimary());
		setProcessed(objectToCopy.isProcessed());
		setLastName(objectToCopy.getLastName());
		setMiddleName(objectToCopy.getMiddleName());
		setPrefix(objectToCopy.getPrefix());
		setSuffix(objectToCopy.getSuffix());
	}

	/**
	 * Gets the compressed name without special characters.
	 * Refer: COMMON_CompressName.doc (ELB tcode folder)
	 *
	 * @return the compressed name without special characters
	 */
	public PersonName getCompressedNameWithoutSpecialCharacters(
			int lengthRequired) {
		//1. Remove all slashes, quotes and hyphens from the name
		String firstName = removeSpecialCharacters(getFirstName());
		String middleName = removeSpecialCharacters(getMiddleName());
		String lastName = removeSpecialCharacters(getLastName());
		String suffix = getSuffix();
		PersonName nameWithoutSpecialCharacters = new PersonName(firstName,
				middleName, lastName, suffix);
		//2. If the total number of characters of all names (allowing for spaces and ,Suffix) is smaller than 35 characters,
		//   then send as-is.
		if (nameWithoutSpecialCharacters.getFullNameWithSuffix().length() <= lengthRequired) {
			return nameWithoutSpecialCharacters;
		}
		//Else, recursively replace last middle name with the initial
		else {
			int numberOfCharactersToCompress = nameWithoutSpecialCharacters
					.getFullNameWithSuffix().length()
					- lengthRequired;
			String newFirstName = firstName;
			String newMiddleName = ""; //The default value should be BLANK, since we concatenate later.
			String newSuffix = suffix;
			String newLastName = lastName;
			int numberOfCharactersCompressed = 0;
			if (!isNullOrBlank(middleName)) {
				String[] middleNames = middleName.split(EMPTY_SPACE);
				int numberOfTokens = middleNames.length;
				for (int i = numberOfTokens - 1; i >= 0; i--) {
					String currentToken = middleNames[i];
					if (numberOfCharactersCompressed <= numberOfCharactersToCompress) {
						middleNames[i] = currentToken.substring(0, 1);//get the initial
					}
					numberOfCharactersCompressed += currentToken.length() - 1;
				}
				for (int i = 0; i < numberOfTokens; i++) {
					newMiddleName = newMiddleName.concat(middleNames[i]);
					newMiddleName = newMiddleName.concat(EMPTY_SPACE);
				}
				newMiddleName = newMiddleName.trim(); //Remove the trailing space
			}
			//3. If there are no Middle Names or all Middle Names have been replaced with Initials 
			//   and the name is still greater than lengthRequired, then
			//   Replace First Name with Initial
			if (!isNullOrBlank(firstName)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newFirstName = firstName.substring(0, 1);
				numberOfCharactersCompressed += firstName.length() - 1;
			}
			//4. If name is still longer than lengthRequired characters the Suffix is eliminated
			if (!isNullOrBlank(suffix)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newSuffix = null;
				numberOfCharactersCompressed += suffix.length();
			}
			//5. If name is still longer than lengthRequired characters then the Last Name is shortened if required 
			if (!isNullOrBlank(lastName)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newLastName = lastName.substring(0, lastName.length()
						- numberOfCharactersToCompress
						+ numberOfCharactersCompressed);
			}
			nameWithoutSpecialCharacters = new PersonName(newFirstName,
					newMiddleName, newLastName, newSuffix);
			return nameWithoutSpecialCharacters;
		}
	}

	/**
	 * Gets the compressed name without special characters.
	 * Refer: COMMON_CompressName.doc (ELB tcode folder)
	 *
	 * @return the compressed name with special characters
	 */
	public PersonName getCompressedNameWithSpecialCharacters(int lengthRequired) {
		//1. Remove all slashes, quotes and hyphens from the name
		String firstName = getFirstName();
		String middleName = getMiddleName();
		String lastName = getLastName();
		String suffix = getSuffix();
		PersonName nameWithSpecialCharacters = new PersonName(firstName,
				middleName, lastName, suffix);
		//2. If the total number of characters of all names (allowing for spaces and ,Suffix) is smaller than 35 characters,
		//   then send as-is.
		if (nameWithSpecialCharacters.getFullNameWithSuffix().length() <= lengthRequired) {
			return nameWithSpecialCharacters;
		}
		//Else, recursively replace last middle name with the initial
		else {
			int numberOfCharactersToCompress = nameWithSpecialCharacters
					.getFullNameWithSuffix().length()
					- lengthRequired;
			String newFirstName = firstName;
			String newMiddleName = ""; //The default value should be BLANK, since we concatenate later.
			String newSuffix = suffix;
			String newLastName = lastName;
			int numberOfCharactersCompressed = 0;
			if (!isNullOrBlank(middleName)) {
				String[] middleNames = middleName.split(EMPTY_SPACE);
				int numberOfTokens = middleNames.length;
				for (int i = numberOfTokens - 1; i >= 0; i--) {
					String currentToken = middleNames[i];
					if (numberOfCharactersCompressed <= numberOfCharactersToCompress) {
						middleNames[i] = currentToken.substring(0, 1);//get the initial
					}
					numberOfCharactersCompressed += currentToken.length() - 1;
				}
				for (int i = 0; i < numberOfTokens; i++) {
					newMiddleName = newMiddleName.concat(middleNames[i]);
					newMiddleName = newMiddleName.concat(EMPTY_SPACE);
				}
				newMiddleName = newMiddleName.trim(); //Remove the trailing space
			}
			//3. If there are no Middle Names or all Middle Names have been replaced with Initials 
			//   and the name is still greater than lengthRequired, then
			//   Replace First Name with Initial
			if (!isNullOrBlank(firstName)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newFirstName = firstName.substring(0, 1);
				numberOfCharactersCompressed += firstName.length() - 1;
			}
			//4. If name is still longer than lengthRequired characters the Suffix is eliminated
			if (!isNullOrBlank(suffix)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newSuffix = null;
				numberOfCharactersCompressed += suffix.length();
			}
			//5. If name is still longer than lengthRequired characters then the Last Name is shortened if required 
			if (!isNullOrBlank(lastName)
					&& numberOfCharactersCompressed <= numberOfCharactersToCompress) {
				newLastName = lastName.substring(0, lastName.length()
						- numberOfCharactersToCompress
						+ numberOfCharactersCompressed);
			}
			nameWithSpecialCharacters = new PersonName(newFirstName,
					newMiddleName, newLastName, newSuffix);
			return nameWithSpecialCharacters;
		}
	}

	/**
	 * Removes the special characters.
	 *
	 * @param name the name
	 * @return the string
	 */
	private String removeSpecialCharacters(String name) {
		if (!isNullOrBlank(name)) {
			String[] chars = new String[] { "/", "'", "-" };
			for (int i = 0; i < chars.length; i++) {
				if (name.contains(chars[i])) {
					name = name.replace(chars[i], "");
				}
			}
			return name;
		}
		else {
			return null;
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: PersonName.java,v $
 * Revision 1.35  2013/03/05 23:45:13  mwhys
 * Added a new format for getFullName(). (Defect 8670)
 *
 * Revision 1.34  2012/01/30 21:47:31  mwpxr5
 * Fixed the defect # 4707 getCompressedNameWithSpecialCharacters method added.
 *
 * Revision 1.33  2011/12/03 01:13:34  mwhys
 * Updated getFullName() for proper space format.
 *
 * Revision 1.32  2011/11/28 19:55:24  mwhys
 * Moved static final variables to interface which are referenced in public methods. (Defect 1046)
 *
 * Revision 1.31  2011/04/28 17:11:38  mwhys
 * Updated.
 *
 * Revision 1.30  2011/04/27 23:43:10  mwhys
 * Added a method getCompressedNameWithoutSpecialCharacters() to compress the name as per
 * the rules specified in COMMON_CompressName.doc.
 * (Fix for defect 649)
 *
 * Revision 1.29  2011/04/21 23:39:50  mwhys
 * Updated getThreePosName() to return a value when the last name is only
 * 1 character and there is no first name.
 *
 * Revision 1.28  2011/04/07 04:04:54  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.27.2.5  2011/04/05 18:09:44  mwhys
 * Updated.
 *
 * Revision 1.27.2.4  2011/04/05 18:07:53  mwhys
 * Moved the code that throws exception from copy-constructor to copy-method.
 *
 * Revision 1.27.2.3  2011/04/02 20:00:23  mwhys
 * Made copy method protected.
 *
 * Revision 1.27.2.2  2011/04/02 19:18:12  mwhys
 * Updated.
 *
 * Revision 1.27.2.1  2011/04/02 18:57:56  mwhys
 * (1) Regenerated hashCode() and equals() methods.
 * (2) Updated copy method.
 *
 * Revision 1.27  2011/03/03 19:12:51  mwhys
 * Fixed defect 5279. Added a method that returns the person name in the 3 position format.
 *
 * Revision 1.26  2011/02/18 00:40:05  mwrrv3
 * Defect fix 5025 -- Added the new getter setter for the name format FIRST MIDDLE LAST SUFFIX -- Amar Bade
 *
 * Revision 1.25  2011/02/02 17:48:31  mwpxr4
 * Updated code to have trim() for all the name fields, this could fix DLP name dropping issue.
 *
 * Revision 1.24  2010/12/17 19:10:29  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST added
 *
 * Revision 1.23  2010/12/14 17:37:29  mwrxn3
 * Updated
 *
 * Revision 1.22  2010/12/13 19:24:48  mwrxn3
 * Removed getMyCopy method and updated with copy constructor
 *
 * Revision 1.21  2010/12/12 22:30:10  mwrxn3
 * Added getMyCopy method
 *
 * Revision 1.20  2010/12/10 22:02:31  mwtjc1
 * logic of parseAndRemoveSuffixIn is improved my adding .trim()
 *
 * Revision 1.19  2010/12/07 22:14:57  mwpxp2
 * Implemented ITreePrintable; added exception in the copy constructor
 *
 * Revision 1.18  2010/12/07 18:20:55  mwhys
 * Removed null check in the constructor, as it is incorrect to do so.
 *
 * Revision 1.17  2010/12/07 04:16:06  mwpxp2
 * Modified toStringOn/1
 *
 * Revision 1.16  2010/12/07 03:57:52  mwpxp2
 * Added toStringOn/1
 *
 * Revision 1.15  2010/12/07 01:51:25  mwpxp2
 * Added toString/0
 *
 * Revision 1.14  2010/12/07 01:24:13  mwrrv2
 * Updated D676 and D677 rules.
 *
 * Revision 1.13  2010/12/07 00:50:03  mwhys
 * Added null check.
 *
 * Revision 1.12  2010/12/06 02:08:15  mwhys
 * Added constructors.
 *
 * Revision 1.11  2010/12/04 22:05:28  mwrrv3
 * Added setPrefix(null) to the setName method.
 *
 * Revision 1.10  2010/12/02 00:15:47  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.9  2010/09/01 17:31:22  mwcyl
 * names that are not entered in the ui should be cleared out
 *
 * Revision 1.8  2010/08/16 23:00:13  mwskh1
 * Added code to handle last name only field (out of state) defect 2122
 * Revision 1.7 2010/08/16 20:52:56 mwpxp2 Fixed null
 * equality test in setName
 * 
 * Revision 1.6 2010/08/16 20:48:08 mwpxp2 Fixed aliasing in setName/1 and
 * refactored it; cleaned up, added jmissing avadoc
 * 
 * Revision 1.5 2010/08/16 18:41:07 mwcyl handle last names that have spaces
 * (i.e. Garcia y Lorca)
 * 
 * Revision 1.4 2010/07/22 17:50:30 mwpxp2 Bulk cleanup and format
 * 
 * Revision 1.3 2010/06/21 23:01:01 mwcsj3 Merged
 * SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 * 
 * Revision 1.1.8.2 2010/06/20 18:07:11 mwakg Rebased to June 20, 2010
 * 
 * Revision 1.2 2010/06/02 20:41:58 mwrsk Remove clone()
 * 
 * Revision 1.1 2010/04/15 18:31:14 mwvxm6 Initial commit of bo packages move to
 * Common
 * 
 * Revision 1.8 2010/04/08 01:18:55 mwsxd10 Swapping flag added.
 * 
 * Revision 1.7 2010/04/07 21:48:14 mwskd2 added clone method
 * 
 * Revision 1.6 2010/04/07 01:34:50 mwsxd10 PernName needs a boolean for
 * checking primary of multiple aka names.
 * 
 * Revision 1.5 2010/04/06 17:48:56 mwhxa2 Added formatter for
 * NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX type
 * 
 * Revision 1.4 2010/01/28 22:48:46 mwhxa2 Updated Java Docs
 * 
 * Revision 1.3 2010/01/12 02:47:11 mwvxm6 BO Refactoring. List Variabe
 * renaming. Attribute type changes from prmitive to Objects. Spring DI to
 * replace news in constructors. Dummy Helper class methods in place of BO
 * logic.
 * 
 * Revision 1.2 2010/01/07 18:29:31 mwhxa2 Domain Model changes - Draft 1
 * 
 * Revision 1.1 2009/11/23 16:25:13 mwrsk Intial commit
 * 
 * Revision 1.21 2009/10/15 22:14:19 mwcsj3 Fixed to do's
 * 
 * Revision 1.20 2009/10/12 20:04:53 mwtjc1 local variable fullNameSB of
 * getFullName method is changed to fullNameSb to resolve PMD reported issue.
 * [SEVERITY 2] Local Variable name 'fullNameSB' should be in camel casing.
 * 
 * Revision 1.19 2009/09/10 21:51:16 mwcsj3 Fixed NULL pointer exception in
 * setName method
 * 
 * Revision 1.18 2009/09/10 18:45:33 mwcsj3 Added empty space to getFullName(int
 * nameFormat) method
 * 
 * Revision 1.17 2009/09/10 04:35:58 mwsmg6 LicenseClass
 * 
 * Revision 1.16 2009/08/27 05:39:48 mwpxp2 Bulk cleanup
 * 
 * Revision 1.15 2009/08/22 23:21:47 mwrrv3 Implemented equals and hashCode
 * methods.
 * 
 * Revision 1.14 2009/08/19 18:40:32 mwakg Fixed space issue in FullName
 * 
 * Revision 1.13 2009/08/18 18:41:39 mwakg Overriden getName method
 * 
 * Revision 1.12 2009/08/18 16:05:11 mwakg Overloaded getFullName method
 * 
 * Revision 1.11 2009/08/18 01:44:02 mwakg Overloaded getFullName method
 * 
 * Revision 1.10 2009/08/12 22:08:43 mwakg Fixed setName
 * 
 * Revision 1.9 2009/08/11 23:09:12 mwakg Added new date pattern
 * 
 * Revision 1.8 2009/08/11 20:24:59 mwrrv3 Updated the helper methods
 * implementation.
 * 
 * Revision 1.7 2009/08/11 00:10:26 mwrrv3 Updated the setName method.
 * 
 * Revision 1.6 2009/08/10 23:36:45 mwakg Overridden setName method in perosn
 * 
 * Revision 1.5 2009/08/05 23:04:54 mwrrv3 Code formatted and remove
 * annotations.
 * 
 * Revision 1.4 2009/07/26 22:58:26 mwrrv3 Code formated and added comments.
 * Revision 1.3 2009/07/22 18:38:00 mwbxp5 Cleaned the Person Object. Removed
 * ref to DlApplication, Documents, CdlisPdps history Revision 1.2 2009/07/14
 * 23:44:26 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.1 2009-07-12 00:55:16 ppalacz Moved to .impl package; added file
 * decorations, todos
 * 
 * Revision 1.1 2009-07-10 07:09:24 ppalacz Synch
 * 
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial ITM commit $ $Revision
 * 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial $
 */
