/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.cc.impl;

import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.bo.admin.impl.Employee;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.bo.tx.impl.Transaction;

import java.util.Date;

/**
 * Description: This represents the inventory item details.
 *  //TODO - the references to ttc and transaction object are problematic
 *  //TODO - this object reflects CC's perspective of the item, which is not to be handled by EASE until CC is moved over from DMVA
 *  //TODO - it seems to mix two things: being issued and used in a transaction and management of inventory by CC: 
 *  //they are separate functions, arguably requiring separate objets
 * File: InventoryItem.java
 * Module: gov.ca.dmv.ease.bo.cc.impl 
 * Created: May 4, 2009
 * @author MWRRV3
 * @version $Revision: 1.6 $ 
 * Last Changed: $Date: 2010/09/15 18:06:20 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryItem extends BaseBusinessObject implements
		IInventoryItemRetrievable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3057128171087423656L;
	/** The Employee. */
	private Employee employee;
	/** The inventory type code. */
	private CodeSetElement inventoryTypeCode;
	/** The issued. */
	private Boolean issued;
	/** The issued date. */
	private Date issuedDate;
	/** The item code. */
	private String itemCode;
	/** The item description. */
	private String itemDescription;
	/** The office. */
	private Office office;
	/** The problem code. 
	 * D - Damaged
	 * M - Missing
	 * V - Voided
	 * R - Refused */
	private CodeSetElement problemCode;
	/** The seq number. */
	private String seqNumber;
	/** The serial number. */
	private String serialNumber;
	/** The transaction that this inventory item is assigned to*/
	private Transaction transaction;
	/** The Transaction Type Code. */
	private String typeTransactionCode;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		InventoryItem other = (InventoryItem) obj;
		if (inventoryTypeCode == null) {
			if (other.inventoryTypeCode != null) {
				return false;
			}
		}
		else if (!inventoryTypeCode.equals(other.inventoryTypeCode)) {
			return false;
		}
		if (issued == null) {
			if (other.issued != null) {
				return false;
			}
		}
		else if (!issued.equals(other.issued)) {
			return false;
		}
		if (itemCode == null) {
			if (other.itemCode != null) {
				return false;
			}
		}
		else if (!itemCode.equals(other.itemCode)) {
			return false;
		}
		if (itemDescription == null) {
			if (other.itemDescription != null) {
				return false;
			}
		}
		else if (!itemDescription.equals(other.itemDescription)) {
			return false;
		}
		if (problemCode == null) {
			if (other.problemCode != null) {
				return false;
			}
		}
		else if (!problemCode.equals(other.problemCode)) {
			return false;
		}
		if (seqNumber == null) {
			if (other.seqNumber != null) {
				return false;
			}
		}
		else if (!seqNumber.equals(other.seqNumber)) {
			return false;
		}
		if (transaction == null) {
			if (other.transaction != null) {
				return false;
			}
		}
		else if (!transaction.equals(other.transaction)) {
			return false;
		}
		if (office == null) {
			if (other.office != null) {
				return false;
			}
		}
		else if (!office.equals(other.office)) {
			return false;
		}
		if (employee == null) {
			if (other.employee != null) {
				return false;
			}
		}
		else if (!employee.equals(other.employee)) {
			return false;
		}
		if (typeTransactionCode == null) {
			if (other.typeTransactionCode != null) {
				return false;
			}
		}
		else if (!typeTransactionCode.equals(other.typeTransactionCode)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * Gets the inventory type code.
	 * 
	 * @return the inventoryTypeCode
	 */
	public CodeSetElement getInventoryTypeCode() {
		return inventoryTypeCode;
	}

	/**
	 * Gets the issued.
	 * 
	 * @return the issued
	 */
	public Boolean getIssued() {
		return issued;
	}

	/**
	 * Gets the issued date.
	 * 
	 * @return the issued date
	 */
	public Date getIssuedDate() {
		return issuedDate;
	}

	/**
	 * Gets the item code.
	 * 
	 * @return the itemCode
	 */
	public String getItemCode() {
		return itemCode;
	}

	/**
	 * Gets the item description.
	 * 
	 * @return the item description
	 */
	public String getItemDescription() {
		return itemDescription;
	}

	/**
	 * Gets the office.
	 * 
	 * @return the office
	 */
	public Office getOffice() {
		return office;
	}

	/**
	 * Gets the problem code.
	 * 
	 * @return the problem code
	 */
	public CodeSetElement getProblemCode() {
		return problemCode;
	}

	/**
	 * Gets the seq number.
	 * 
	 * @return the seq number
	 */
	public String getSeqNumber() {
		return seqNumber;
	}

	/**
	 * Gets the serial number.
	 * 
	 * @return the serial number
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 */
	public Transaction getTransaction() {
		return transaction;
	}

	/**
	 * Gets the typeTransactionCode.
	 * 
	 * @return the typeTransactionCode
	 */
	public String getTypeTransactionCode() {
		return typeTransactionCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((inventoryTypeCode == null) ? 0 : inventoryTypeCode
						.hashCode());
		result = prime * result + ((issued == null) ? 0 : issued.hashCode());
		result = prime * result
				+ ((itemCode == null) ? 0 : itemCode.hashCode());
		result = prime * result
				+ ((itemDescription == null) ? 0 : itemDescription.hashCode());
		result = prime * result
				+ ((problemCode == null) ? 0 : problemCode.hashCode());
		result = prime * result
				+ ((seqNumber == null) ? 0 : seqNumber.hashCode());
		result = prime * result
				+ ((transaction == null) ? 0 : transaction.hashCode());
		return result;
	}

	/**
	 * Sets the employee.
	 * 
	 * @param employee the employee to set
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * Sets the inventory type code.
	 * 
	 * @param inventoryTypeCode
	 *            the inventoryTypeCode to set
	 */
	public void setInventoryTypeCode(CodeSetElement inventoryTypeCode) {
		this.inventoryTypeCode = inventoryTypeCode;
	}

	/**
	 * Sets the issued.
	 * 
	 * @param issued
	 *            the issued to set
	 */
	public void setIssued(Boolean issued) {
		this.issued = issued;
	}

	/**
	 * Sets the issued date.
	 * 
	 * @param issuedDate
	 *            the new issued date
	 */
	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	/**
	 * Sets the item code.
	 * 
	 * @param itemCode
	 *            the itemCode to set
	 */
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * Sets the item description.
	 * 
	 * @param itemDescription
	 *            the new item description
	 */
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	/**
	 * Sets the office.
	 * 
	 * @param office the office to set
	 */
	public void setOffice(Office office) {
		this.office = office;
	}

	/**
	 * Sets the problem code.
	 * 
	 * @param problemCode
	 *            the new problem code
	 */
	public void setProblemCode(CodeSetElement problemCode) {
		this.problemCode = problemCode;
	}

	/**
	 * Sets the seq number.
	 * 
	 * @param seqNumber
	 *            the new seq number
	 */
	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	/**
	 * Sets the serial number.
	 * 
	 * @param serialNumber
	 *            the new serial number
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Sets the transaction.
	 * 
	 * @param transaction
	 *            the transaction to set
	 */
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	/**
	 * Sets the typeTransactionCode.
	 * 
	 * @param typeTransactionCode the typeTransactionCode to set
	 */
	public void setTypeTransactionCode(String typeTransactionCode) {
		this.typeTransactionCode = typeTransactionCode;
	}
}
/**
 * Modification History:
 * 
 * $Log: InventoryItem.java,v $
 * Revision 1.6  2010/09/15 18:06:20  mwpxp2
 * Cleaned up imports; added todos
 *
 * Revision 1.5  2010/09/13 04:40:28  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.4  2010/07/22 17:50:33  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.3  2010/05/27 22:01:58  mwvxm6
 * Added comments
 *
 * Revision 1.2  2010/05/27 14:37:55  mwrsk
 * Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 * Revision 1.1  2010/04/15 18:31:15  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.3  2010/02/23 22:52:19  mwvxm6
 * Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 * Revision 1.2  2010/01/28 19:49:20  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.1  2009/11/23 16:25:21  mwrsk
 * Intial commit
 *
 * Revision 1.23  2009/10/15 22:30:54  mwcsj3
 * Fixed to do's
 *
 * Revision 1.22  2009/10/15 22:15:28  mwvxm6
 * Updated annotation as per the modified DB2 schema which now has a join table for Inventory and Transaction
 *
 * Revision 1.21  2009/10/07 01:17:26  mwvxm6
 * DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 * Revision 1.20  2009/10/03 21:06:35  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.19  2009/09/25 23:03:00  mwhxa2
 * Now Extends BaseBusinessObject
 *
 * Revision 1.18  2009/09/13 20:45:40  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.17.2.1  2009/09/12 19:08:53  mwakg
 * Removed CodeSetElement sub classes
 *
 * Revision 1.17  2009/09/03 16:16:42  mwrsk
 * Added @Transient annotations for the newly added instance variables
 *
 * Revision 1.16  2009/08/28 01:24:52  mwvxm6
 * Updated Annotations per revised DDL
 *
 * Revision 1.15  2009/08/27 05:40:00  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.14  2009/08/27 02:22:39  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.13  2009/08/24 23:32:53  mwvxm6
 * Added annotation to Office attribute
 *
 * Revision 1.12  2009/08/24 18:27:11  mwhxa2
 * Adding TypeTransactionCode Attribute.
 *
 * Revision 1.11  2009/08/24 18:05:58  mwhxa2
 * Adding office and Employee Attributes.
 *
 * Revision 1.10  2009/08/22 23:19:34  mwrrv3
 * Implemented equals and hashCode methods.
 *
 * Revision 1.9  2009/08/20 02:42:51  mwrrv3
 * Updated the annotations.
 *
 * Revision 1.8  2009/08/19 18:41:33  mwrrv3
 * Updated the annotations (table name and column names).
 *
 * Revision 1.7  2009/08/06 02:15:26  mwrrv2
 * Updated annotations
 *
 * Revision 1.6  2009/08/06 02:13:33  mwrrv2
 * Added issuedDate variable.
 * Revision 1.5 2009/08/06 01:43:22 mwrrv2 updated
 * the table annotations
 * 
 * Revision 1.4 2009/08/05 01:31:38 mwyxg1 added hashcode and equals
 * 
 * Revision 1.3 2009/07/14 23:44:27 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.2 2009-07-12 15:51:42 ppalacz Removed shadowing of id from super
 * 
 * Revision 1.1 2009-07-12 00:58:24 ppalacz moved to .cc.impl
 * 
 * Revision 1.1 2009-07-10 07:09:26 ppalacz Synch
 * 
 * $Revision 1.1 May 4, 2009 10:53:21 AM MWCSJ3 $Initial ITM commit $ $Revision
 * 1.1 May 4, 2009 10:53:21 AM MWCSJ3 $Initial $
 */
