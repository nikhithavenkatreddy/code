/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.testresult.DriveAndLawTestResultType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;

import java.util.Date;

/**
 * Description: This class holds drive test results.
 * File: DriveAndLawTestResult.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult.impl
 * Created: Jan 6, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.13 $
 * Last Changed: $Date: 2012/08/15 16:23:23 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DriveAndLawTestResult extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6448397591023061181L;
	/** Holds Drive and Law Test Result Type. */
	private DriveAndLawTestResultType driveAndLawTestResultType;
	/** Holds Drive Test Failure Date. */
	private Date driveTestFailureDate;
	/** Holds License Class Code. */
	private CodeSetElement licenseClassCode;
	/** Holds Technician ID. */
	private String technicianId;
	/** Holds Law/Drive/Word And Phrase/Signs Test Result Code. */
	private CodeSetElement testResultCode;

	/**
	 * Private Constructor
	 */
	private DriveAndLawTestResult() {
		// Empty Constructor
	}

	/**
	 * Overloaded Constructor
	 */
	public DriveAndLawTestResult(DriveAndLawTestResult dataToCopy) {
		super();
		copy(dataToCopy);
	}

	/**
	 * Copy the data from dataToCopy to this object.
	 * @param objectToCopy
	 */
	private void copy(DriveAndLawTestResult objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null DriveAndLawTestResult argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		//Set Drive And Law test result type
		setDriveAndLawTestResultType(objectToCopy
				.getDriveAndLawTestResultType());
		//Copy Drive Test Failure Date
		if (isNotNull(objectToCopy.getDriveTestFailureDate())) {
			setDriveTestFailureDate(new Date(objectToCopy
					.getDriveTestFailureDate().getTime()));
		}
		else {
			setDriveTestFailureDate(null);
		}
		//Copy License Class Code
		if (isNotNull(objectToCopy.getLicenseClassCode())) {
			setLicenseClassCode(new CodeSetElement(objectToCopy
					.getLicenseClassCode()));
		}
		else {
			setLicenseClassCode(null);
		}
		//Copy Technician Id (Tech id)
		setTechnicianId(objectToCopy.getTechnicianId());
		//Copy Test Result Code
		if (isNotNull(objectToCopy.getTestResultCode())) {
			setTestResultCode(new CodeSetElement(objectToCopy
					.getTestResultCode()));
		}
		else {
			setTestResultCode(null);
		}
	}

	/**
	 * @param driveAndLawTestResultType the driveAndLawTestResultType to set
	 */
	public void setDriveAndLawTestResultType(
			DriveAndLawTestResultType driveAndLawTestResultType) {
		this.driveAndLawTestResultType = driveAndLawTestResultType;
	}

	/**
	 * Overridden Constructor.
	 * 
	 * @param driveAndLawTestResultType Drive and Law Test Type
	 */
	public DriveAndLawTestResult(
			DriveAndLawTestResultType driveAndLawTestResultType) {
		this.driveAndLawTestResultType = driveAndLawTestResultType;
	}

	/**
	 * Gets the Drive And Law Test Result Type.
	 * 
	 * @return the driveAndLawTestResultType
	 */
	public DriveAndLawTestResultType getDriveAndLawTestResultType() {
		return driveAndLawTestResultType;
	}

	/**
	 * Gets the Drive Test Failure Date.
	 * 
	 * @return the driveTestFailureDate
	 */
	public Date getDriveTestFailureDate() {
		if (getTestResultCode() != null
				&& ArrayUtils.contains(getTestResultCode().getCode(), "F", "1",
						"2", "3", "4", "5", "6", "7", "8", "9", "0", "L")) {
			return driveTestFailureDate;
		}
		return null;
	}

	/**
	 * Gets the License Class Code.
	 * 
	 * @return the licenseClassCode
	 */
	public CodeSetElement getLicenseClassCode() {
		return licenseClassCode;
	}

	/**
	 * Gets the Technician Id.
	 * 
	 * @return the technicianId
	 */
	public String getTechnicianId() {
		return technicianId;
	}

	/**
	 * Gets Law/Drive/Word And Phrase/Signs Test Result COde.
	 * 
	 * @return the testResultCode
	 */
	public CodeSetElement getTestResultCode() {
		return testResultCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((driveAndLawTestResultType == null) ? 0
						: driveAndLawTestResultType.hashCode());
		result = prime
				* result
				+ ((driveTestFailureDate == null) ? 0 : driveTestFailureDate
						.hashCode());
		result = prime
				* result
				+ ((licenseClassCode == null) ? 0 : licenseClassCode.hashCode());
		result = prime * result
				+ ((technicianId == null) ? 0 : technicianId.hashCode());
		result = prime * result
				+ ((testResultCode == null) ? 0 : testResultCode.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DriveAndLawTestResult other = (DriveAndLawTestResult) obj;
		if (driveAndLawTestResultType == null) {
			if (other.driveAndLawTestResultType != null)
				return false;
		}
		else if (!driveAndLawTestResultType
				.equals(other.driveAndLawTestResultType))
			return false;
		if (driveTestFailureDate == null) {
			if (other.driveTestFailureDate != null)
				return false;
		}
		else if (!driveTestFailureDate.equals(other.driveTestFailureDate))
			return false;
		if (licenseClassCode == null) {
			if (other.licenseClassCode != null)
				return false;
		}
		else if (!licenseClassCode.equals(other.licenseClassCode))
			return false;
		if (technicianId == null) {
			if (other.technicianId != null)
				return false;
		}
		else if (!technicianId.equals(other.technicianId))
			return false;
		if (testResultCode == null) {
			if (other.testResultCode != null)
				return false;
		}
		else if (!testResultCode.equals(other.testResultCode))
			return false;
		return true;
	}

	/**
	 * Sets the Drive Test Failure Date.
	 * 
	 * @param driveTestFailureDate the driveTestFailureDate to set
	 */
	public void setDriveTestFailureDate(Date driveTestFailureDate) {
		this.driveTestFailureDate = driveTestFailureDate;
	}

	/**
	 * Sets the License Class.
	 * 
	 * @param licenseClass the licenseClassCOde to set
	 */
	public void setLicenseClassCode(CodeSetElement licenseClassCode) {
		this.licenseClassCode = licenseClassCode;
	}

	/**
	 * Sets the Technician Id.
	 * 
	 * @param technicianID the technicianId to set
	 */
	public void setTechnicianId(String technicianId) {
		this.technicianId = technicianId;
	}

	/**
	 * Sets Law/Drive/Word And Phrase/Signs Test Result Code.
	 * 
	 * @param testResult the testResultCode to set
	 */
	public void setTestResultCode(CodeSetElement testResultCode) {
		this.testResultCode = testResultCode;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DriveAndLawTestResult.java,v $
 *  Revision 1.13  2012/08/15 16:23:23  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.12  2011/06/10 23:13:33  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.11  2011/05/12 17:13:39  mwrka1
 *  rollack to 1.9 version
 *
 *  Revision 1.9  2011/04/21 21:02:32  mwrka1
 *  added constant "L" for failure date
 *
 *  Revision 1.8  2011/04/07 04:04:55  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.7.10.5  2011/04/05 21:11:08  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.7.10.4  2011/04/05 20:40:07  mwrrv3
 *  Added setter method for driveAndLawTestResultType attribute.
 *
 *  Revision 1.7.10.3  2011/04/05 18:53:41  mwrrv3
 *  Updated the copy method.
 *
 *  Revision 1.7.10.2  2011/04/04 18:59:58  mwrrv3
 *  Updated the overloaded constructor.
 *
 *  Revision 1.7.10.1  2011/04/04 00:31:34  mwrrv3
 *  Added copyConstructor functionality to this class.
 *
 *  Revision 1.7  2010/12/21 23:02:55  mwrka1
 *  hashcode and equals methods updated
 *
 *  Revision 1.6  2010/12/17 19:26:57  mwskh1
 *  modified getDriveTestFailureDate
 *
 *  Revision 1.5  2010/11/07 00:56:28  mwrrv3
 *  Updated the getDriveTestFailureDate method to check the result code.
 *
 *  Revision 1.4  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/06/21 23:01:03  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.8.2  2010/06/20 18:07:14  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/02 20:41:57  mwrsk
 *  Remove clone()
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/30 16:59:37  mwhxa2
 *  default constructor is made private, so the setting the drive n law test type is mandatory to be set
 *
 *  Revision 1.1  2010/03/18 17:22:05  mwhxa2
 *  Changed name to DriveAndLawTestResult
 *
 *  Revision 1.2  2010/01/29 15:12:01  mwrsk
 *  renamed testResult & LicenseClass to include "Code" suffix
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
 *  Revision 1.2  2010/01/07 23:32:45  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.1  2010/01/07 18:29:48  mwhxa2
 *  Domain Model changes - Draft 1
 *
*/
