/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseServiceLayerException;

/**
 * Description: I am abstract exception for Inventory related exceptions
 * File: InventoryException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/08/30 21:13:22 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryException extends EaseServiceLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2423978444375080500L;

	/**
	 * Instantiates a new inventory exception.
	 */
	public InventoryException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public InventoryException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public InventoryException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public InventoryException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryException.java,v $
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
