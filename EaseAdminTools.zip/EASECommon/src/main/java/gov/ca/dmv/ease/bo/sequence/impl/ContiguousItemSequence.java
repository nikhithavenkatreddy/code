/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.sequence.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.inventory.item.impl.ItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.impl.ItemType;
import gov.ca.dmv.ease.bo.inventory.item.impl.LocalInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.ISequencePatternFactory;
import gov.ca.dmv.ease.bo.sequence.exception.impl.NoSequenceAvailableException;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequenceException;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequenceParsingException;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequencePatternException;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am default implementation of IContiguousItemSequence
 * I am object to be instantiated from DMVA-originating Inventory seeding messages
 * 
 * File: ContiguousItemSequence.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.41 $
 * Last Changed: $Date: 2012/08/15 23:17:57 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class ContiguousItemSequence extends BusinessObject implements
		IContiguousItemSequence {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(ContiguousItemSequence.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1249845422653077894L;
	/** The Maximum number of possible items int. */
	private static final int MAX_ITEM_COUNT = 99999;
	/** The UNDEF_INT. */
	private static final int UNDEF_INT = -1;
	/** The is drawn from HQ. */
	private boolean isDrawnFromHq = false;
	/** The lower boundary. */
	private String lowerBoundary;
	/** The low point count. */
	private int lowPointCount = UNDEF_INT;
	/** The office id. */
	private String officeId;
	/** The org code. */
	private String orgCode;
	/** The pattern. */
	private ISequencePattern pattern;
	/** The sequence pattern. */
	//TODO - remove
	private ISequencePattern sequencePattern;
	/** The station id. */
	private String stationId;
	/** The type. */
	private IItemType type;
	/** The upper boundary. */
	private String upperBoundary;
	/** The item count. */
	private int sequenceCount = MAX_ITEM_COUNT;
	/** Required for mapping ITEM_CD field. */
	private String typeCode;
	/** Required for mapping ITEM_LOCATION_CD field. */
	private String itemLocationCode;

	/**
	 * Instantiates a new contiguous item sequence.
	 */
	protected ContiguousItemSequence() {
		super();
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aType the a type
	 * @param aSequenceCount the a sequence count
	 */
	public ContiguousItemSequence(IItemType aType, int aSequenceCount) {
		super();
		setType(aType);
		setSequenceCount(aSequenceCount);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aLowerBoundary the a lower boundary
	 * @param anUpperBoundary the an upper boundary
	 * @param aType the a type
	 * @param aPattern the a pattern
	 */
	public ContiguousItemSequence(String aLowerBoundary,
			String anUpperBoundary, IItemType aType, ISequencePattern aPattern) {
		super();
		setType(aType);
		setSequencePattern(aPattern);
		setLowerBoundary(aLowerBoundary);
		setUpperBoundary(anUpperBoundary);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aLowerBoundary the a lower boundary
	 * @param anUpperBoundary the an upper boundary
	 * @param aSequenceCount quantity
	 * @param aType the a type
	 * @param aPattern the a pattern
	 */
	public ContiguousItemSequence(String aLowerBoundary,
			String anUpperBoundary, int aSequenceCount, IItemType aType,
			ISequencePattern aPattern) {
		super();
		setType(aType);
		setSequenceCount(aSequenceCount);
		setSequencePattern(aPattern);
		setLowerBoundary(aLowerBoundary);
		setUpperBoundary(anUpperBoundary);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aLowerBoundary the a lower boundary
	 * @param anUpperBoundary the an upper boundary
	 * @param aSequenceCount quantity
	 * @param aType the a type
	 * @param aPattern the a pattern
	 * @param orgCode
	 */
	public ContiguousItemSequence(String aLowerBoundary,
			String anUpperBoundary, int aSequenceCount, IItemType aType,
			ISequencePattern aPattern, String orgCode) {
		super();
		setType(aType);
		setSequenceCount(aSequenceCount);
		setSequencePattern(aPattern);
		setLowerBoundary(aLowerBoundary);
		setUpperBoundary(anUpperBoundary);
		setOrgCode(orgCode);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aType
	 * @param aLocation
	 */
	public ContiguousItemSequence(IItemType aType, IItemLocation aLocation) {
		super();
		setType(aType);
		setOfficeId(aLocation.getOfficeId());
		setStationId(aLocation.getStationId());
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aType
	 * @param aStationId
	 * @deprecated
	 */
	public ContiguousItemSequence(IItemType aType, String aStationId) {
		super();
		setType(aType);
		setStationId(aStationId);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aTypeCode the a type code
	 * @param aLowerBoundarySequenceString the a lower boundary sequence string
	 * @param aUpperBoundarySequenceString the a upper boundary sequence string
	 */
	public ContiguousItemSequence(String aTypeCode,
			String aLowerBoundarySequenceString,
			String aUpperBoundarySequenceString) {
		super();
		setTypeFrom(aTypeCode);
		setLowerBoundary(aLowerBoundarySequenceString);
		setUpperBoundary(aUpperBoundarySequenceString);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aTypeCode the a type code
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param aLowerBoundarySequenceString the a lower boundary sequence string
	 * @param aUpperBoundarySequenceString the a upper boundary sequence string
	 * @param isDrawnFromHq the is drawn from hq
	 */
	public ContiguousItemSequence(String aTypeCode, String anOfficeId,
			String aStationId, String aLowerBoundarySequenceString,
			String aUpperBoundarySequenceString, boolean isDrawnFromHq) {
		super();
		setTypeFrom(aTypeCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setLowerBoundary(aLowerBoundarySequenceString);
		setUpperBoundary(aUpperBoundarySequenceString);
		setDrawnFromHq(isDrawnFromHq);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aTypeCode the a type code
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param aLowPointCount the a low point count
	 * @param aLowerBoundarySequenceString the a lower boundary sequence string
	 * @param aUpperBoundarySequenceString the a upper boundary sequence string
	 * @param isDrawnFromHq the is drawn from hq
	 */
	public ContiguousItemSequence(String aTypeCode, String anOfficeId,
			String aStationId, int aLowPointCount,
			String aLowerBoundarySequenceString,
			String aUpperBoundarySequenceString, boolean isDrawnFromHq) {
		super();
		setTypeFrom(aTypeCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setLowPointCount(aLowPointCount);
		setLowerBoundary(aLowerBoundarySequenceString);
		setUpperBoundary(aUpperBoundarySequenceString);
		setDrawnFromHq(isDrawnFromHq);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aTypeCode the a type code
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param aLowerBoundarySequenceString the a lower boundary sequence string
	 * @param aUpperBoundarySequenceString the a upper boundary sequence string
	 * @param anItemCount the item count
	 * @param isDrawnFromHq the is drawn from hq
	 */
	public ContiguousItemSequence(String aTypeCode, String anOfficeId,
			String aStationId, String aLowerBoundarySequenceString,
			String aUpperBoundarySequenceString, int aSequenceCount,
			boolean isDrawnFromHq) {
		super();
		setTypeFrom(aTypeCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setSequenceCount(aSequenceCount);
		setLowerBoundary(aLowerBoundarySequenceString);
		setUpperBoundary(aUpperBoundarySequenceString);
		setDrawnFromHq(isDrawnFromHq);
	}

	/**
	 * Instantiates a new contiguous item sequence.
	 * 
	 * @param aTypeCode the a type code
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param aLowerBoundarySequenceString the a lower boundary sequence string
	 * @param aUpperBoundarySequenceString the a upper boundary sequence string
	 * @param anItemCount the item count
	 * @param isDrawnFromHq the is drawn from hq
	 * @param orgcode
	 */
	public ContiguousItemSequence(String aTypeCode, String anOfficeId,
			String aStationId, String aLowerBoundarySequenceString,
			String aUpperBoundarySequenceString, int aSequenceCount,
			boolean isDrawnFromHq, String orgCode) {
		super();
		setTypeFrom(aTypeCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setSequenceCount(aSequenceCount);
		setLowerBoundary(aLowerBoundarySequenceString);
		setUpperBoundary(aUpperBoundarySequenceString);
		setDrawnFromHq(isDrawnFromHq);
		setOrgCode(orgCode);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#asItemList()
	 */
	public List <IInventoryItem> asItemList() {
		List <IInventoryItem> aList = new ArrayList <IInventoryItem>();
		IInventoryItem anItem;
		for (ISequence seqNo : getSequenceNoList()) {
			anItem = LocalInventoryItem.newInstanceFor(seqNo, getType(),
					getOfficeId(), getStationId());
			anItem.beAvailable(); //by default
			aList.add(anItem);
		}
		return aList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence#contains(gov.ca.dmv.ease.bo.inventory.item.IInventoryItem)
	 */
	public boolean contains(IInventoryItem aSequence) {
		List <ISequence> aList = getSequenceNoList();
		for (ISequence sequence : aList) {
			if (sequence.getSequenceNo().equals(
					aSequence.getSequenceNo().getValue())) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence#contains(gov.ca.dmv.ease.bo.sequence.ISequence)
	 */
	public boolean contains(ISequence aSequence) {
		List <ISequence> aList = getSequenceNoList();
		for (ISequence sequence : aList) {
			if (sequence.getSequenceNo().equals(aSequence.getSequenceNo())) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ContiguousItemSequence)) {
			return false;
		}
		ContiguousItemSequence other = (ContiguousItemSequence) obj;
		if (isDrawnFromHq != other.isDrawnFromHq) {
			return false;
		}
		if (lowPointCount != other.lowPointCount) {
			return false;
		}
		if (lowerBoundary == null) {
			if (other.lowerBoundary != null) {
				return false;
			}
		}
		else if (!lowerBoundary.equals(other.lowerBoundary)) {
			return false;
		}
		if (officeId == null) {
			if (other.officeId != null) {
				return false;
			}
		}
		else if (!officeId.equals(other.officeId)) {
			return false;
		}
		if (pattern == null) {
			if (other.pattern != null) {
				return false;
			}
		}
		else if (!pattern.equals(other.pattern)) {
			return false;
		}
		if (sequencePattern == null) {
			if (other.sequencePattern != null) {
				return false;
			}
		}
		else if (!sequencePattern.equals(other.sequencePattern)) {
			return false;
		}
		if (stationId == null) {
			if (other.stationId != null) {
				return false;
			}
		}
		else if (!stationId.equals(other.stationId)) {
			return false;
		}
		if (type == null) {
			if (other.type != null) {
				return false;
			}
		}
		else if (!type.equals(other.type)) {
			return false;
		}
		if (upperBoundary == null) {
			if (other.upperBoundary != null) {
				return false;
			}
		}
		else if (!upperBoundary.equals(other.upperBoundary)) {
			return false;
		}
		return true;
	}

	/**
	 * Generates the upper boundary if possible
	 */
	private void generateUpperBoundary() {
		if (EaseUtil.isNullOrBlank(upperBoundary) && (sequenceCount > 0)
				&& (sequenceCount < MAX_ITEM_COUNT)) {
			List <ISequence> seqList = getSequenceNoList();
			upperBoundary = seqList.get(seqList.size() - 1).getValue();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#size()
	 */
	public int getItemCount() {
		return getSequenceNoList().size();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getItemLocation()
	 */
	public IItemLocation getItemLocation() {
		return new ItemLocation(getOfficeId(), getStationId());
	}

	/**
	 * Returns the item location code
	 * 
	 * @return itemLocationCode
	 */
	public String getItemLocationCode() {
		return this.itemLocationCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getItemType()
	 */
	public IItemType getItemType() {
		return getType();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getLowerBoundary()
	 */
	public String getLowerBoundary() {
		return lowerBoundary;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getLowPointCount()
	 */
	public int getLowPointCount() {
		return lowPointCount;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getOfficeId()
	 */
	public String getOfficeId() {
		return officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getOrgCode()
	 */
	public String getOrgCode() {
		if (orgCode == null) {
			setOrgCode();
		}
		return orgCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getProcessorId()
	 */
	public String getProcessorId() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			return stationId.substring(0, 2);
		}
		else {
			return null;
		}
	}

	/**
	 * @return the pattern
	 */
	public ISequencePattern getPattern() {
		if (pattern == null) {
			setPattern(getPatternUsingFactory());
		}
		return pattern;
	}

	/**
	 * Gets the pattern using factory.
	 * 
	 * @return the pattern using factory
	 */
	protected ISequencePattern getPatternUsingFactory() {
		try {
			ISequencePatternFactory aFactory = SequencePatternFactory
					.getInstance();
			if ((getLowerBoundary() == null) || getLowerBoundary().length() < 2) {
				return aFactory.getSequencePatternForCode(getTypeCode());
			}
			else {
				return aFactory.getSequencePatternForCode(getTypeCode(),
						getLowerBoundary(), getUpperBoundary());
			}
		}
		catch (SequenceParsingException e) {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getSequenceCount()
	 */
	public int getSequenceCount() {
		if (!hasSequenceCount()) {
			sequenceCount = getItemCount();
		}
		return sequenceCount;
	}

	/**
	 * Gets the sequence no list.
	 * 
	 * @return the sequence no list
	 */
	public List <ISequence> getSequenceNoList() {
		LOGGER.debug("getSequenceNoList() - start");
		//create a list of all sequence no between lower and upper boundary
		//by starting with lower boundary, and obtaining next sequence until upper boundary is hit
		List <ISequence> aList = new ArrayList <ISequence>();
		String upperBoundarySequenceString = getUpperBoundary();
		if (upperBoundarySequenceString == null) {
			upperBoundarySequenceString = "        ";
		}
		String lowerBoundarySequenceString = getLowerBoundary();
		if (getPattern() != null) {
			lowerBoundarySequenceString = (new Sequence(getLowerBoundary(),
					getPattern())).getSequenceNo();
			if (!lowerBoundarySequenceString.equals(getLowerBoundary())) {
				setLowerBoundary(lowerBoundarySequenceString);
			}
			if (!EaseUtil.isNullOrBlank(upperBoundarySequenceString)) {
				upperBoundarySequenceString = (new Sequence(getUpperBoundary(),
						getPattern())).getSequenceNo();
				if (!upperBoundarySequenceString.equals(getUpperBoundary())) {
					setUpperBoundary(upperBoundarySequenceString);
				}
			}
		}
		int sequenceCount = this.sequenceCount;
		if ((lowerBoundarySequenceString.compareTo(upperBoundarySequenceString) > 0)
				&& (sequenceCount <= 0)) {
			throw new SequenceException("lower boundary \""
					+ lowerBoundarySequenceString
					+ "\" is greater than the upper one: \""
					+ upperBoundarySequenceString + "\" or sequence count "
					+ sequenceCount + " <= 0");
		}
		//IItemSequenceNo
		ISequence nextSequence = new Sequence(getLowerBoundary(), getPattern());
		aList.add(nextSequence);
		sequenceCount--;
		while (!nextSequence.isAfter(upperBoundarySequenceString)
				|| EaseUtil.isNullOrBlank(upperBoundarySequenceString)
				&& sequenceCount > 0) {
			try {
				//System.out.println("now: " + nextSequence);
				nextSequence = nextSequence.getNext();
				sequenceCount--;
				//System.out.println("next: " + nextSequence);
			}
			catch (NoSequenceAvailableException e) {
				if (EaseUtil.isNullOrBlank(upperBoundarySequenceString)) {
					setUpperBoundary(aList.get(aList.size() - 1).getValue());
				}
				LOGGER.info("getSequenceNoList()" + e.getMessage());
				LOGGER.debug("getSequenceNoList() - end");
				return aList;
			}
			LOGGER.debug("nextSequence: " + nextSequence);
			aList.add(nextSequence);
		}
		if (EaseUtil.isNullOrBlank(upperBoundarySequenceString)) {
			setUpperBoundary(aList.get(aList.size() - 1).getValue());
		}
		LOGGER.debug("getSequenceNoList() - end");
		return aList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getSequencePattern()
	 */
	public ISequencePattern getSequencePattern() {
		if (sequencePattern == null) {
			initSequencePattern();
		}
		return sequencePattern;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getStationId()
	 */
	public String getStationId() {
		return stationId;
	}

	/**
	 * @return the type
	 */
	protected IItemType getType() {
		if (type == null) {
			try {
				type = ItemType.forCode(typeCode);
			}
			catch (SequenceParsingException e) {
				LOGGER.debug(e.getMessage());
			}
		}
		return type;
	}

	/**
	 * Gets the type code.
	 * 
	 * @return the type code
	 */
	public String getTypeCode() {
		if (getType() != null) {
			return getType().getCode();
		}
		else {
			return this.typeCode;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getUpperBoundary()
	 */
	public String getUpperBoundary() {
		return upperBoundary;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (isDrawnFromHq ? 1231 : 1237);
		result = prime * result + lowPointCount;
		result = prime * result
				+ ((lowerBoundary == null) ? 0 : lowerBoundary.hashCode());
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());
		result = prime * result + ((pattern == null) ? 0 : pattern.hashCode());
		result = prime * result
				+ ((sequencePattern == null) ? 0 : sequencePattern.hashCode());
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result
				+ ((upperBoundary == null) ? 0 : upperBoundary.hashCode());
		return result;
	}

	/**
	 * Checks for low point defined.
	 * 
	 * @return true, if successful
	 */
	public boolean hasLowPointDefined() {
		return getLowPointCount() > UNDEF_INT;
	}

	/**
	 * Checks for sequence count set.
	 * 
	 * @return true, if successful
	 */
	public boolean hasSequenceCount() {
		return (sequenceCount > 0) && (sequenceCount < MAX_ITEM_COUNT);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#hasUpperBoundary()
	 */
	public boolean hasUpperBoundary() {
		if (EaseUtil.isNullOrBlank(upperBoundary)) {
			generateUpperBoundary();
		}
		return (!EaseUtil.isNullOrBlank(upperBoundary));
	}

	/**
	 * Inits the sequence pattern.
	 */
	private void initSequencePattern() {
		String anItemTypeCode = getTypeCode();
		ISequencePattern aPattern;
		if (getTypeCode() != null) {
			aPattern = SequencePatternFactory.getInstance()
					.getSequencePatternForCode(anItemTypeCode);
			setSequencePattern(aPattern);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#isDrawnFromHq()
	 */
	public boolean isDrawnFromHq() {
		return isDrawnFromHq;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#isForStation()
	 */
	public boolean isForStation() {
		return (getStationId() != null) && !getStationId().endsWith("#");
	}

	/**
	 * @param isDrawnFromHq the isDrawnFromHq to set
	 */
	protected void setDrawnFromHq(boolean isDrawnFromHq) {
		this.isDrawnFromHq = isDrawnFromHq;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#setItemLocation()
	 */
	public void setItemLocation(IItemLocation location) {
		this.setOfficeId(location.getOfficeId());
		this.setStationId(location.getStationId());
	}

	/**
	 * Sets the lower boundary.
	 * 
	 * @param lowerBoundary the new lower boundary
	 */
	public void setLowerBoundary(String lowerBoundary) {
		this.lowerBoundary = lowerBoundary;
		try {
			//correct boundary if needed
			ISequencePattern pattern = getPatternUsingFactory();
			if (!(EaseUtil.isNullOrBlank(lowerBoundary) || lowerBoundary.trim()
					.equals("*"))
					&& pattern != null) {
				this.lowerBoundary = Sequence.addTrimmedSpaces(lowerBoundary,
						pattern.getValue());
			}
		}
		catch (SequencePatternException e) {
			LOGGER.debug(e.getMessage());
		}
	}

	/**
	 * @param lowPointCount the lowPointCount to set
	 */
	protected void setLowPointCount(int lowPointCount) {
		this.lowPointCount = lowPointCount;
	}

	/**
	 * @param officeId the officeId to set
	 */
	protected void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Set the org code based on the station.
	 */
	protected void setOrgCode() {
		setOrgCode(null);
	}

	/**
	 * Set the org code based.
	 * 
	 * @param orgCode the org code
	 */
	protected void setOrgCode(String orgCode) {
		if (EaseUtil.isNotNull(orgCode)) {
			this.orgCode = orgCode;
		}
		else {
			if (isForStation()) {
				this.orgCode = ORG_CODE_WORKSTATION;
			}
			else {
				this.orgCode = ORG_CODE_OFFICE;
			}
		}
	}

	/**
	 * @param pattern the pattern to set
	 */
	protected void setPattern(ISequencePattern pattern) {
		this.pattern = pattern;
	}

	/**
	 * @param sequenceCount the sequenceCount to set
	 */
	protected void setSequenceCount(int sequenceCount) {
		this.sequenceCount = sequenceCount;
	}

	/**
	 * Sets the sequence pattern.
	 * 
	 * @param sequencePattern the new sequence pattern
	 */
	protected void setSequencePattern(ISequencePattern aPattern) {
		sequencePattern = aPattern;
	}

	/**
	 * @param stationId the stationId to set
	 */
	protected void setStationId(String anId) {
		if (anId != null) {
			stationId = anId;
		}
		else {
			stationId = "";
		}
		setItemLocationCode();
	}

	/**
	 * Sets the type.
	 * 
	 * @param type the new type
	 */
	protected void setType(IItemType aType) {
		type = aType;
		if (EaseUtil.isNotNull(aType)) {
			setTypeCode(aType.getCode());
		}
		else {
			setTypeCode(null);
		}
	}

	/**
	 * Sets the type from.
	 * 
	 * @param aCode the new type from
	 */
	private void setTypeFrom(String aCode) {
		try {
			setType(ItemType.forCode(aCode));
		}
		catch (SequenceParsingException e) {
			setType(null);
			this.typeCode = aCode;
		}
	}

	/**
	 * Sets the upper boundary.
	 * 
	 * @param upperBoundary the new upper boundary
	 */
	public void setUpperBoundary(String aSequence) {
		upperBoundary = aSequence;
		try {
			//correct boundary if needed
			ISequencePattern pattern = getPatternUsingFactory();
			if (!EaseUtil.isNullOrBlank(aSequence) && pattern != null) {
				upperBoundary = Sequence.addTrimmedSpaces(aSequence, pattern
						.getValue());
			}
		}
		catch (SequencePatternException e) {
			LOGGER.debug(e.getMessage());
		}
	}

	/**
	 * Sets the location code
	 * 
	 * @param itemLocationCode
	 */
	private void setItemLocationCode() {
		if (EaseUtil.isNullOrBlank(this.stationId)
				|| this.stationId.endsWith("#")) {
			this.itemLocationCode = "O";
		}
		else {
			this.itemLocationCode = "S";
		}
	}

	/**
	 * Sets the type code
	 * 
	 * @param typeCode
	 */
	public void setTypeCode(String typeCode) {
		if (EaseUtil.isNullOrBlank(typeCode)) {
			this.type = null;
		}
		else {
			this.type = ItemType.forCode(typeCode);
		}
		this.typeCode = typeCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(128);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" office: ").append(officeId);
		aBuilder.append(" station: ").append(stationId);
		aBuilder.append(" type: ").append(type);
		aBuilder.append(" <").append(lowerBoundary).append(" ,");
		aBuilder.append(upperBoundary).append(">");
		aBuilder.append(" isDrawnFromHq: ").append(isDrawnFromHq);
		aBuilder.append(" ]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validate()
	 */
	@Override
	public IErrorCollector validate() {
		IErrorCollector anErrorCollector = new ErrorCollector();
		validateUsing(anErrorCollector);
		return anErrorCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		if (getOfficeId() == null) {
			aCollector.register(new EaseValidationException(
					"officeId must not be null in " + this));
		}
		if (getLowerBoundary() == null) {
			aCollector.register(new EaseValidationException(
					"lowerBoundary must not be null in " + this));
		}
		if (getUpperBoundary() == null) {
			aCollector.register(new EaseValidationException(
					"upperBoundary must not be null in " + this));
		}
		if (getType() == null) {
			aCollector.register(new EaseValidationException(
					"type must not be null in " + this));
		}
		else {
			if (getTypeCode() == null) {
				aCollector.register(new EaseValidationException(
						"getTypeCode must not be null in " + this));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ContiguousItemSequence.java,v $
 *  Revision 1.41  2012/08/15 23:17:57  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.40  2012/08/14 20:46:14  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.39  2011/11/22 23:23:29  mwkfh
 *  updated setOrgCode
 *
 *  Revision 1.38  2011/11/22 23:03:58  mwkfh
 *  added orgCode property
 *
 *  Revision 1.37  2011/11/21 21:18:02  mwkfh
 *  added getOrgCode to fix defect 6961
 *
 *  Revision 1.36  2011/09/27 22:52:06  mwkfh
 *  updated getType()
 *
 *  Revision 1.35  2011/09/27 21:37:10  mwkfh
 *  updated type codes checks to allow invalid codes
 *
 *  Revision 1.34  2011/09/23 21:21:20  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.33  2011/09/22 22:27:05  mwkfh
 *  updated setItemLocationCode
 *
 *  Revision 1.32  2011/08/11 23:09:56  mwkfh
 *  updated hasSequenceCount()
 *
 *  Revision 1.31  2011/08/11 23:00:41  mwxxw
 *  Add check for sequenceCount == 0 in getSequenceCount() function.
 *
 *  Revision 1.30  2011/07/07 16:01:04  mwkfh
 *  added validateUsing
 *
 *  Revision 1.29  2011/07/06 17:10:45  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.28  2011/07/01 23:58:13  mwkfh
 *  overloaded contains, etc.
 *
 *  Revision 1.27  2011/06/29 20:44:14  mwkfh
 *  added item type + location constructor
 *
 *  Revision 1.26  2011/06/25 01:15:49  mwxxw
 *  Add more logic for typeCode.
 *
 *  Revision 1.25  2011/06/23 22:31:38  mwxxw
 *  Add more logic for new mapping fields.
 *
 *  Revision 1.24  2011/06/22 17:30:59  mwxxw
 *  Updated for hibernate mapping.
 *
 *  Revision 1.23  2011/06/22 02:38:40  mwxxw
 *  Add two new fields.
 *
 *  Revision 1.22  2011/03/23 23:51:41  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.21  2011/01/03 18:12:31  mwkfh
 *  updated set boundaries to correct with pattern if possible
 *
 *  Revision 1.20  2010/12/31 23:28:21  mwkfh
 *  added upper boundary fixes to getSequenceNoList
 *
 *  Revision 1.19  2010/12/31 01:41:44  mwkfh
 *  updated getSequenceCount
 *
 *  Revision 1.18  2010/12/30 03:21:00  mwpxr4
 *  *** empty log message ***
 *
 *  Revision 1.17  2010/12/28 21:29:13  mwkfh
 *  added hasSequenceCount
 *
 *  Revision 1.16  2010/12/23 06:18:21  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.14.4.1  2010/12/23 03:13:55  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.15  2010/12/18 19:40:49  mwtjc1
 *  ContiguousItemSequence(IItemType aType, int aSequenceCount) added
 *
 *  Revision 1.14  2010/12/15 23:20:34  mwkfh
 *  added constructor
 *
 *  Revision 1.13  2010/12/15 21:43:02  mwrrv2
 *  Updates to Local Inventory
 *
 *  Revision 1.12  2010/12/15 18:55:35  mwkfh
 *  added new constructor
 *
 *  Revision 1.11  2010/12/04 20:06:00  mwkfh
 *  updated getSequenceNoList to use sequence count if upper bound blank
 *
 *  Revision 1.10  2010/12/04 01:45:53  mwkfh
 *  added MaxItemCount
 *
 *  Revision 1.9  2010/10/14 23:26:01  mwkfh
 *  change lower and upperBoundary to String
 *
 *  Revision 1.8  2010/10/12 22:21:35  mwpxp2
 *  Fixed creation of an item with type instance passed in
 *
 *  Revision 1.7  2010/10/09 00:18:07  mwpxp2
 *  Modified getSequenceNoList() t intercept NoSequenceAvailableException
 *
 *  Revision 1.6  2010/10/08 18:39:18  mwpxp2
 *  Logging added
 *
 *  Revision 1.5  2010/10/08 18:33:54  mwpxp2
 *  Added boundary validation in getSequenceNoList
 *
 *  Revision 1.4  2010/10/08 01:53:56  mwpxp2
 *  Added getPattern/0
 *
 *  Revision 1.3  2010/10/05 22:29:43  mwpxp2
 *  Removed sequencedItems inst var; added toString/0
 *
 *  Revision 1.2  2010/10/05 20:40:24  mwpxp2
 *  Adjusted references to sequence types
 *
 *  Revision 1.1  2010/10/05 17:40:13  mwpxp2
 *  Moved to sequence package
 *
 *  Revision 1.14  2010/10/05 17:18:47  mwpxp2
 *  Removed ref to implementation in asItemList
 *
 *  Revision 1.13  2010/09/27 20:59:44  mwbxg3
 *  replaced getSequencePatternForCode with getItemSequencePatternForCode
 *
 *  Revision 1.12  2010/09/24 23:37:11  mwpxp2
 *  Fixed impl of getSequenceNoList
 *
 *  Revision 1.11  2010/09/24 20:56:09  mwpxp2
 *  Implemented getSequenceNoList, getPattern
 *
 *  Revision 1.10  2010/09/17 21:05:09  mwpxp2
 *  Sorted members; added comment to getSequenceNoList/0
 *
 *  Revision 1.9  2010/09/14 01:57:52  mwpxp2
 *  Adjusted for bo InventoryItem rename
 *
 *  Revision 1.8  2010/09/14 01:26:12  mwpxp2
 *  Added support for interface additions; added 7-arg utility constructor (using primitive types) for message handler.
 *
 *  Revision 1.7  2010/09/02 19:02:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/09/02 18:59:36  mwpxp2
 *  Added 3-arg constructor on strings and support to create corresponding objects
 *
 *  Revision 1.5  2010/09/02 18:43:54  mwpxp2
 *  Added to class comment
 *
 *  Revision 1.4  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.3  2010/09/02 17:27:26  mwpxp2
 *  Added hashCode, equals; removed obsolete behavior
 *
 *  Revision 1.2  2010/08/31 03:49:12  mwpxp2
 *  Added add/1, asItemList/0, getItemCount/0
 *
 *  Revision 1.1  2010/08/30 23:19:48  mwpxp2
 *  Initial, not unit tested
 *
 */
