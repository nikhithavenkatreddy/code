/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I am interface for a factory to access instances of ISequencePattern
 * File: ISequencePatternFactory.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 7, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2010/10/14 23:27:20 $
 * Last Changed By: $Author: mwkfh $
 */
public interface ISequencePatternFactory extends Serializable {
	/**
	 * Gets the known codes.
	 * 
	 * @return the known codes
	 */
	List <String> getKnownCodes();

	/**
	 * Gets the known sequence patterns.
	 * 
	 * @return the known sequence patterns
	 */
	List <ISequencePattern> getKnownSequencePatterns();

	/**
	 * Gets the sequence pattern for code.
	 * 
	 * @param aCode the a code
	 * 
	 * @return the sequence pattern for code
	 */
	ISequencePattern getSequencePatternForCode(String aCode);

	/**
	 * Gets the sequence pattern for code.
	 * 
	 * @param typeCode the type code
	 * @param lowerBoundary the lower boundary
	 * @param upperBoundary the upper boundary
	 * 
	 * @return the sequence pattern for code
	 */
	ISequencePattern getSequencePatternForCode(String typeCode,
			String lowerBoundary, String upperBoundary);

	/**
	 * Register.
	 * 
	 * @param aCode the a code
	 * @param sequencePattern the sequence pattern
	 */
	void register(String aCode, ISequencePattern sequencePattern);
}
/**
 *  Modification History:
 *
 *  $Log: ISequencePatternFactory.java,v $
 *  Revision 1.6  2010/10/14 23:27:20  mwkfh
 *  removed  deprecated constructors
 *
 *  Revision 1.5  2010/10/14 17:19:20  mwkfh
 *  updated constructors
 *
 *  Revision 1.4  2010/10/08 01:53:42  mwpxp2
 *  Added getSequencePatternForCode/3
 *
 *  Revision 1.3  2010/09/08 00:34:52  mwpxp2
 *  Added getKnownCodes/0
 *
 *  Revision 1.2  2010/09/07 22:57:49  mwpxp2
 *  Replaced register/1 with register/2
 *
 *  Revision 1.1  2010/09/07 20:23:19  mwpxp2
 *  Initial
 *
 */
