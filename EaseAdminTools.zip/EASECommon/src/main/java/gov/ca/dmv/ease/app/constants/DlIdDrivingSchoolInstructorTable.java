/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * Description: Enum for DL/ID Driving School Instructor Print Class Codes.
 * File: PrintClassCode.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Apr 4, 2011 
 * @author MWXXW  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/08/14 20:42:35 $
 * Last Changed By: $Author: mwrrv3 $
 */
public enum DlIdDrivingSchoolInstructorTable {
	CLASS_CODE_PRIORITY_1(1, "74"),
	CLASS_CODE_PRIORITY_2(2, "63"),
	CLASS_CODE_PRIORITY_3(3, "84"),
	CLASS_CODE_PRIORITY_4(4, "76"),
	CLASS_CODE_PRIORITY_5(5, "65"),
	CLASS_CODE_PRIORITY_6(6, "64"),
	CLASS_CODE_PRIORITY_7(7, "73"),
	CLASS_CODE_PRIORITY_8(8, "81"),
	CLASS_CODE_PRIORITY_9(9, "67"),
	CLASS_CODE_PRIORITY_10(10, "77"),
	CLASS_CODE_PRIORITY_11(11, "80"),
	CLASS_CODE_PRIORITY_12(12, "75"),
	CLASS_CODE_PRIORITY_13(13, "85"),
	CLASS_CODE_PRIORITY_14(14, "86");
	
	private final int priorityId;
	private final String printClassCode;
	private static final Map <String, Integer> PRINT_CLS_CODE_TO_PRIORITY_MAP;
	
	// Make the mapping
	static
	{
		PRINT_CLS_CODE_TO_PRIORITY_MAP = new HashMap <String, Integer>();
		for (DlIdDrivingSchoolInstructorTable item : DlIdDrivingSchoolInstructorTable.values() ) {
			PRINT_CLS_CODE_TO_PRIORITY_MAP.put(item.getPrintClassCode(), item
					.getPriorityId());
		}
	}
	
	/**
	 * Constructor
	 */
	private DlIdDrivingSchoolInstructorTable(int priorityId, String printClassCode) {
		this.priorityId = priorityId;
		this.printClassCode = printClassCode;
	}

	/**
	 * Getter for priority id.
	 * @return
	 */
	public int getPriorityId() {
		return priorityId;
	}

	/**
	 * Getter for printClassCode.
	 * @return
	 */
	public String getPrintClassCode() {
		return printClassCode;
	}

	public static int getPriorityIdByPrintClassCode(String printClassCode) {
		int priorityId = -1;
		if (PRINT_CLS_CODE_TO_PRIORITY_MAP.containsKey(printClassCode)) {
			priorityId = PRINT_CLS_CODE_TO_PRIORITY_MAP.get(printClassCode);
		}
		return priorityId;
	}
}


/**
 *  Modification History:
 *
 *  $Log: DlIdDrivingSchoolInstructorTable.java,v $
 *  Revision 1.3  2012/08/14 20:42:35  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.2  2011/04/06 22:19:07  mwxxw
 *  Add more printClassCode mapping according requirement.
 *
 *  Revision 1.1  2011/04/06 00:32:16  mwxxw
 *  New files add for calculation printClassCode for printed docs.
 *
 */
