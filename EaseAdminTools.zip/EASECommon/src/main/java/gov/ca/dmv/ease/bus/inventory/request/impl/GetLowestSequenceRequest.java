/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.impl.ItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryItemResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am request to retrieve the lowest sequence an 
 * inventory item for particular location, for item of a given type
 * File: GetLowestSequenceRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Nov 3, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/11/04 16:39:20 $
 * Last Changed By: $Author: mwkfh $
 */
public class GetLowestSequenceRequest extends AbstractInventoryRequest
		implements IInventoryItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3087041033859727040L;
	/** The item type code. */
	private String itemTypeCode;
	/** The office id. */
	private String officeId;

	/**
	 * Instantiates a new issue inventory item request.
	 */
	protected GetLowestSequenceRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected GetLowestSequenceRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Instantiates a new issue inventory item request.
	 * 
	 * @param context the context
	 * @param anItemTypeCode the an item type code
	 * @param officId the office id
	 */
	public GetLowestSequenceRequest(IUserContext context,
			String anItemTypeCode, String officId) {
		super(context);
		setItemTypeCode(anItemTypeCode);
		setOfficeId(officId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	public IInventoryItemResponse execute() {
		return getService().execute(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (itemTypeCode == null) {
			return 0;
		}
		else {
			return 1;
		}
	}

	/**
	 * @deprecated
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.IInventoryRequest#getItemList()
	 */
	public IInventoryItem getItem() {
		//TODO: add check to see if inventory should be issued by workstation
		//		if (getLocation().isAssignedToStation()) {
		return new StationLocalInventoryItem(getItemTypeCode(),
				new ItemLocation(getOfficeId(), null));
		//		}
		//		else {
		//return new OfficeLocalInventoryItem(getItemTypeCode(), new ItemLocation(getOfficeId(), null));
		//		}
	}

	/**
	 * Gets the item type code.
	 * 
	 * @return the itemTypeCode
	 */
	public String getItemTypeCode() {
		return itemTypeCode;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the item type code.
	 * 
	 * @param itemTypeCode the itemTypeCode to set
	 */
	protected void setItemTypeCode(String aCodeString) {
		itemTypeCode = aCodeString;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param location the office id
	 */
	protected void setOfficeId(String anOfficeId) {
		officeId = anOfficeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: GetLowestSequenceRequest.java,v $
 *  Revision 1.1  2011/11/04 16:39:20  mwkfh
 *  added GetLowestSequence
 *
 */
