/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.daf.request.impl;

import gov.ca.dmv.ease.bus.daf.response.impl.PurgeDafRecordResponseBus;
import gov.ca.dmv.ease.bus.daf.service.impl.PurgeDafRecordService;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * Description: PurgeDafRecordRequest Business object
 * File: PurgeDafRecordRequestBus.java
 * Module:  gov.ca.dmv.ease.bus.dl.request.impl
 * Created: Mar 4, 2010
 * 
 * @author MWYXG1
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/10/25 23:49:14 $
 * Last Changed By: $Author: mwhys $
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class PurgeDafRecordRequestBus extends AbstractRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1976601871480488261L;
	/** The daf number. */
	private Integer dafNumber;
	/** The dl number. */
	private String dlNumber;
	/** The is it hard delete. */
	private boolean isItHardDelete = false;
	
	/**
	 * Instantiates a new purge daf record request bus.
	 * 
	 * @param userContext the user context
	 * @param dafNumber the daf number
	 */
	public PurgeDafRecordRequestBus(IUserContext userContext, Integer dafNumber) {
		super(userContext);
		setDafNumber(dafNumber);
	}
	
	/**
	 * Instantiates a new purge daf record request bus.
	 * 
	 * @param userContext the user context
	 * @param dafNumber the daf number
	 * @param isItHardDelete the is it hard delete
	 */
	public PurgeDafRecordRequestBus(IUserContext userContext,
			Integer dafNumber, boolean isItHardDelete) {
		super(userContext);
		setDafNumber(dafNumber);
		setIsItHardDelete(isItHardDelete);
	}
	
	/**
	 * Instantiates a new purge daf record request bus.
	 * 
	 * @param userContext the user context
	 * @param dafNumber the daf number
	 */
	public PurgeDafRecordRequestBus(IUserContext userContext, String dlNumber) {
		super(userContext);
		setDlNumber(dlNumber);
	}
	
	/**
	 * Instantiates a new purge daf record request bus.
	 * 
	 * @param userContext the user context
	 * @param dafNumber the daf number
	 * @param isItHardDelete the is it hard delete
	 */
	public PurgeDafRecordRequestBus(IUserContext userContext, String dlNumber,
			boolean isItHardDelete) {
		super(userContext);
		setDlNumber(dlNumber);
		setIsItHardDelete(isItHardDelete);
	}
	
	/**
	 * Executes the request in the service.
	 * 
	 * @return PurgeDafRecordResponseBus
	 */
	public PurgeDafRecordResponseBus execute() {
		return PurgeDafRecordService.execute(this);
	}
	
	/**
	 * Gets the daf number.
	 * 
	 * @return dafNumber
	 */
	public Integer getDafNumber() {
		return dafNumber;
	}
	
	/**
	 * Gets the DL number
	 * 
	 * @return the dlNumber
	 */
	public String getDlNumber() {
		return dlNumber;
	}
	
	/**
	 * Returns true if daf number set.
	 * 
	 * @return true if daf number set
	 */
	public boolean hasDafNumber() {
		return EaseUtil.isNotNull(dafNumber);
	}
	
	/**
	 * Returns true if dl number set.
	 * 
	 * @return true if dl number set
	 */
	public boolean hasDlNumber() {
		return EaseUtil.isNotNull(dlNumber);
	}
	
	/**
	 * Checks if is it hard delete.
	 * 
	 * @return true, if is it hard delete
	 */
	public boolean isItHardDelete() {
		return isItHardDelete;
	}
	
	/**
	 * Sets the daf number.
	 * 
	 * @param dafNumber the daf number
	 */
	public void setDafNumber(Integer dafNumber) {
		this.dafNumber = dafNumber;
	}
	
	/**
	 * Sets the DL Number
	 * 
	 * @param dlNumber the dlNumber to set
	 */
	private void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	
	/**
	 * Sets the DL Number
	 * 
	 * @param dlNumber the dlNumber to set
	 */
	private void setIsItHardDelete(boolean isItHardDelete) {
		this.isItHardDelete = isItHardDelete;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: PurgeDafRecordRequestBus.java,v $
 *  Revision 1.2  2011/10/25 23:49:14  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.1  2011/02/18 01:01:08  mwkfh
 *  moved purgeDafService to common
 *
 *  Revision 1.4  2011/01/14 23:04:20  mwtjc1
 *  isItHardDelete added
 *
 *  Revision 1.3  2010/03/25 17:52:17  mwyxg1
 *  add daf maintenance business logic
 *
 */
