/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: This represents the Identification card and it extends License
 * and inherits the properties from License class. 
 * File: IdCard.java 
 * Module: gov.ca.dmv.ease.bo.license.impl 
 * Created: May 6, 2009
 * @author MWCSJ3
 * @version $Revision: 1.11 $ 
 * Last Changed: $Date: 2012/04/05 20:38:53 $
 * Last Changed By: $Author: mwhys $
 */
public class IdCard extends License {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8710409333923968119L;
	/** The Type Indicator for ID - R=REGULAR S=SENIOR NULL=NONE. */
	private CodeSetElement typeIndicatorCode;
	
	/**
	 * Default Constructor.
	 */
	public IdCard() {
	}
	
	/**
	 * Instantiates a new IdCard data - copy constructor.
	 *
	 * @param idCard the id card
	 */
	public IdCard(IdCard idCard) {
		super();
		copy(idCard);
	}
	
	/**
	 * Gets the id number.
	 * 
	 * @return the id number
	 */
	public String getIdNumber() {
		return this.getLicenseNumber();
	}
	
	/**
	 * Sets the Type Indicator Code.
	 *
	 * @return the typeIndicatorCode
	 */
	public CodeSetElement getTypeIndicatorCode() {
		return typeIndicatorCode;
	}
	
	/**
	 * Sets the id number.
	 * 
	 * @param idNumber
	 *            the new id number
	 */
	public void setIdNumber(String idNumber) {
		this.setLicenseNumber(idNumber);
	}
	
	/**
	 * Gets the Type Indicator Code.
	 *
	 * @param typeIndicatorCode the typeIndicatorCode to set
	 */
	public void setTypeIndicatorCode(CodeSetElement typeIndicatorCode) {
		this.typeIndicatorCode = typeIndicatorCode;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder
	 * , int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("typeIndicatorCode", typeIndicatorCode, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * This method is to copy IdCard.
	 * 
	 * @param objectToCopy
	 *            the object to copy
	 */
	protected void copy(IdCard objectToCopy) {
		/*
		 * Checking for the object value and if it null throw exception.
		 */
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null idCard argument expected in copy constructor in "
							+ this);
		}
		super.copy(objectToCopy);
		if (EaseUtil.isNotNull(objectToCopy.getTypeIndicatorCode())) {
			setTypeIndicatorCode(new CodeSetElement(objectToCopy
					.getTypeIndicatorCode()));
		}
		else {
			setTypeIndicatorCode(null);
		}
		setLimitedTermFeeDueYear(objectToCopy.getLimitedTermFeeDueYear());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((typeIndicatorCode == null) ? 0 : typeIndicatorCode
						.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		IdCard other = (IdCard) obj;
		if (typeIndicatorCode == null) {
			if (other.typeIndicatorCode != null)
				return false;
		}
		else if (!typeIndicatorCode.equals(other.typeIndicatorCode))
			return false;
		return true;
	}
}
/**
 * Modification History:
 * 
 * $Log: IdCard.java,v $
 * Revision 1.11  2012/04/05 20:38:53  mwhys
 * Moved limitedTermFeeDueYear to License class.
 * Regenerated equals(), hashCode(), and updated copy().
 *
 * Revision 1.10  2011/05/04 21:50:57  mwhys
 * Fixed defect 123(IT).
 * Added a field limitedTermFeeDueYear
 * (Update equals, hashcode, toString and copy methods)
 *
 * Revision 1.9  2011/04/07 04:04:52  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.8.14.6  2011/04/05 18:24:11  mwhys
 * Used isNotNull instead of !isNullOrBlank.
 *
 * Revision 1.8.14.5  2011/04/05 18:10:13  mwark
 * Moved validation to copy method from the constructor code.
 *
 * Revision 1.8.14.4  2011/04/04 20:54:37  mwark
 * Added null check in the constructor.
 * Revision 1.8.14.3 2011/04/04 02:11:51 mwark Removed the
 * duplicate hashCode and equals methods to fix the compilation errors.
 * 
 * Revision 1.8.14.2 2011/04/04 02:06:39 mwark Updated with the copy method.
 * 
 * Revision 1.8.14.1 2011/04/02 19:01:23 mwhys Generated hashCode() and equals()
 * methods.
 * 
 * Revision 1.8 2010/12/14 17:37:39 mwrxn3 Updated
 * 
 * Revision 1.7 2010/12/13 19:24:59 mwrxn3 Removed getMyCopy method and updated
 * with copy constructor
 * 
 * Revision 1.6 2010/12/12 22:29:55 mwrxn3 Added getMyCopy method
 * 
 * Revision 1.5 2010/12/07 22:08:54 mwpxp2 Implemented ITreePrintable
 * 
 * Revision 1.4 2010/12/07 03:56:08 mwpxp2 Added toStringOn/1
 * 
 * Revision 1.3 2010/06/21 23:01:02 mwcsj3 Merged
 * SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 * 
 * Revision 1.1.8.2 2010/06/20 18:07:13 mwakg Rebased to June 20, 2010
 * 
 * Revision 1.2 2010/06/07 16:54:00 mwpxp2 Bulk cleanup
 * 
 * Revision 1.1 2010/04/15 18:31:14 mwvxm6 Initial commit of bo packages move to
 * Common
 * 
 * Revision 1.4 2010/04/12 23:23:56 mwvxm6 For the id number use the
 * licenseNumber attribute from the License class
 * 
 * Revision 1.3 2010/03/17 02:41:51 mwuxb Added attribute typeIndicatorCode
 * 
 * Revision 1.2 2010/01/28 22:21:40 mwhxa2 Updated Java Docs
 * 
 * Revision 1.1 2010/01/06 00:01:55 mwvxm6 BO Refactoring. List Variabe
 * renaming. Attribute type changes from prmitive to Objects. Spring DI to
 * replace news in constructors. Dummy Helper class methods in place of BO
 * logic.
 * 
 * Revision 1.1 2009/11/23 16:25:16 mwrsk Intial commit
 * 
 * Revision 1.6 2009/08/27 05:39:49 mwpxp2 Bulk cleanup
 * 
 * Revision 1.5 2009/08/13 18:07:13 mwcsj3 Moved getExpirationYear() method to
 * super class
 * 
 * Revision 1.4 2009/08/13 17:58:41 mwcsj3 Added getExpirationYear() method
 * 
 * Revision 1.3 2009/07/30 23:02:45 mwrrv3 Extends License class.
 * 
 * Revision 1.2 2009/07/14 23:44:33 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.1 2009-07-12 07:55:40 ppalacz Moved to .impl package; added file
 * decorations, todos
 * 
 * Revision 1.1 2009-07-10 07:09:26 ppalacz Synch
 * 
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial ITM commit $ $Revision
 * 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial $
 */
