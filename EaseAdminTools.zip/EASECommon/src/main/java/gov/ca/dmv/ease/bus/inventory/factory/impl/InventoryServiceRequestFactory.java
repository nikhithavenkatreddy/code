/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bus.inventory.factory.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.factory.IInventoryServiceRequestFactory;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.DeleteInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetCurrentItemCountRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetLowestSequenceRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.ManuallyIssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.MoveInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RemoveStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RestoreInventoryItemsAvailabilityRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SeedInventoryFromDmvaRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SetItemCountThresholdRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory;

import java.util.List;

/**
 * Description:  I am default implementation of IInventoryServiceRequestFactory
 * I am singleton - either as POJO or as Spring bean
 * 
 * File: InventoryServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.factory.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.17 $
 * Last Changed: $Date: 2011/11/04 16:39:20 $
 * Last Changed By: $Author: mwkfh $
 */
public class InventoryServiceRequestFactory implements
		IInventoryServiceRequestFactory {
	/** The FACTORY. */
	private static IPersistenceServiceRequestFactory FACTORY;
	/** The SINGLETON. */
	private static IInventoryServiceRequestFactory SINGLETON;

	/**
	 * Gets the single instance of InventoryServiceRequestFactory.
	 * 
	 * @return single instance of InventoryServiceRequestFactory
	 */
	public static IInventoryServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	private static void initSingleton() {
		SINGLETON = new InventoryServiceRequestFactory();
	}

	/**
	 * Instantiates a new inventory service request factory.
	 */
	private InventoryServiceRequestFactory() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createAddItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IInventoryItem[])
	 */
	public AddInventoryItemRequest createAddItemsRequest(IUserContext context,
			IInventoryItem... items) {
		return new AddInventoryItemRequest(context, items);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createAddItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public AddInventoryItemRequest createAddItemsRequest(IUserContext context,
			List <IInventoryItem> listOfItems) {
		return new AddInventoryItemRequest(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createAddInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence[])
	 */
	public AddInventoryRequest createAddInventoryRequest(IUserContext context,
			IContiguousItemSequence sequence) {
		return new AddInventoryRequest(context, sequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createAddStationInventoryAssignmentRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public AddStationInventoryAssignmentRequest createAddStationInventoryAssignmentRequest(
			IUserContext context, List <IInventoryItem> listOfItems) {
		return new AddStationInventoryAssignmentRequest(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createDeleteInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence)
	 */
	public DeleteInventoryItemRequest createDeleteInventoryRequest(
			IUserContext context, IContiguousItemSequence aSequence) {
		return new DeleteInventoryItemRequest(context, aSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createGetCurrentItemCountRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public GetCurrentItemCountRequest createGetCurrentItemCountRequest(
			IUserContext context, List <IItemThreshold> listOfItems) {
		return new GetCurrentItemCountRequest(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createGetLowestSequenceRequest(gov.ca.dmv.ease.fw.process.IUserContext, ItemLocation, java.lang.String)
	 */
	public GetLowestSequenceRequest createGetLowestSequenceRequest(
			IUserContext context, String anItemTypeCode, String officeId) {
		return new GetLowestSequenceRequest(context, anItemTypeCode, officeId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createDeleteItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, ItemLocation, java.lang.String)
	 */
	public IssueInventoryItemRequest createIssueInventoryItemRequest(
			IUserContext context, IItemLocation forLocation,
			String anItemTypeCode) {
		return new IssueInventoryItemRequest(context, forLocation,
				anItemTypeCode);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createDeleteItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, anItemTypeCode, java.lang.String)
	 */
	public IssueMultipleInventoryItemsRequest createIssueMultipleInventoryItemsRequest(
			IUserContext context, IItemLocation forLocation,
			String anItemTypeCode, int quantity) {
		return new IssueMultipleInventoryItemsRequest(context, forLocation,
				anItemTypeCode, quantity);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createDeleteItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, anItemTypeCode, java.lang.String)
	 */
	public ManuallyIssueMultipleInventoryItemsRequest createManuallyIssueMultipleInventoryItemsSequenceRequest(
			IUserContext context,
			List <IContiguousItemSequence> itemSequenceList) {
		/*
		List <IInventoryItem> itemsToIssue = new ArrayList <IInventoryItem>();
		if (itemSequenceList != null) {
			for (IContiguousItemSequence itemSequence : itemSequenceList) {
				itemsToIssue.addAll(itemSequence.asItemList());
			}
		}
		*/
		return new ManuallyIssueMultipleInventoryItemsRequest(context,
				itemSequenceList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createMoveItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence)
	 */
	public MoveInventoryItemRequest createMoveItemsRequest(
			IUserContext context, IItemLocation targetLocation,
			IContiguousItemSequence aSequence) {
		return new MoveInventoryItemRequest(context, targetLocation, aSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createRemoveStationInventoryAssignmentRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public RemoveStationInventoryAssignmentRequest createRemoveStationInventoryAssignmentRequest(
			IUserContext context, List <IInventoryItem> listOfItems) {
		return new RemoveStationInventoryAssignmentRequest(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createDeleteItemsRequest(gov.ca.dmv.ease.fw.process.IUserContext, anItemTypeCode, java.lang.String)
	 */
	public RestoreInventoryItemsAvailabilityRequest createRestoreInventoryItemsAvailabilityRequest(
			IUserContext context, List <IContiguousItemSequence> itemsToIssue) {
		return new RestoreInventoryItemsAvailabilityRequest(context,
				itemsToIssue);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createSeedInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence[])
	 */
	public SeedInventoryFromDmvaRequest createSeedInventoryRequest(
			IUserContext context, IContiguousItemSequence... sequences) {
		return new SeedInventoryFromDmvaRequest(context, sequences);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createSeedInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public SeedInventoryFromDmvaRequest createSeedInventoryRequest(
			IUserContext context, List <IContiguousItemSequence> aSequenceList) {
		return new SeedInventoryFromDmvaRequest(context, aSequenceList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createSeedInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence[])
	 */
	public SeedInventoryFromDmvaRequest createSeedInventoryRequest(
			IUserContext context, String officeId,
			IContiguousItemSequence... sequences) {
		return new SeedInventoryFromDmvaRequest(context, officeId, sequences);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createSeedInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public SeedInventoryFromDmvaRequest createSeedInventoryRequest(
			IUserContext context, String officeId, String processorId,
			List <IContiguousItemSequence> aSequenceList) {
		return new SeedInventoryFromDmvaRequest(context, officeId, processorId,
				aSequenceList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IInventoryServiceRequestFactory#createSetItemCountThresholdRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.List)
	 */
	public SetItemCountThresholdRequest createSetItemCountThresholdRequest(
			IUserContext context, List <IItemThreshold> listOfItems) {
		return new SetItemCountThresholdRequest(context, listOfItems);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryServiceRequestFactory.java,v $
 *  Revision 1.17  2011/11/04 16:39:20  mwkfh
 *  added GetLowestSequence
 *
 *  Revision 1.16  2011/09/23 00:20:30  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.15  2011/07/13 17:31:07  mwkfh
 *  added RemoveStationInventoryAssignmentRequest
 *
 *  Revision 1.14  2011/07/12 00:11:17  mwkfh
 *  added AddStationInventoryAssignmentRequest
 *
 *  Revision 1.13  2011/07/07 22:32:43  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.12  2011/07/06 17:10:48  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.11  2011/06/09 18:32:20  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.10  2011/06/08 18:55:35  mwkfh
 *  added AddInventoryRequest
 *
 *  Revision 1.9  2011/01/10 21:48:06  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.8  2010/12/08 19:03:13  mwkfh
 *  added RestoreInventoryItemsAvailabilityRequest
 *
 *  Revision 1.7  2010/12/07 00:18:38  mwkfh
 *  added createManuallyIssueMultipleInventoryItemsRequests
 *
 *  Revision 1.6  2010/12/05 00:06:17  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 *  Revision 1.5  2010/10/15 20:58:01  mwkfh
 *  removed getPersistenceServiceRequestFactory which is never called
 *
 *  Revision 1.4  2010/10/07 15:36:02  mwkfh
 *  added Item count and Issue create methods
 *
 *  Revision 1.3  2010/10/05 17:40:43  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.2  2010/09/23 21:21:52  mwpxp2
 *  Implemented createSeedInventoryRequest* methods
 *
 *  Revision 1.1  2010/09/20 20:29:13  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.4  2010/09/14 20:01:35  mwpxp2
 *  Adjusted for interface mods
 *
 *  Revision 1.3  2010/09/02 20:44:54  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.2  2010/09/01 00:42:57  mwpxp2
 *  Removed  getInventoryServiceInstance/0
 *
 *  Revision 1.1  2010/09/01 00:34:50  mwpxp2
 *  Initial shell
 *
 */
