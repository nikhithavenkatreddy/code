/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.LegalPresenceDocument;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;

import java.io.Serializable;

/**
 * Description: LpvRecord captures the information for designateActionCode and legalPresenceDocument.
 * File: LpvRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Aug 22, 2009 
 * @author MWSYK1  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2011/11/30 19:53:26 $
 * Last Changed By: $Author: mwhys $
 */
public class LpvRecord implements ITreePrintable, Serializable {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4727052135242459807L;
	
	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}
	
	/** Designate Action Code. */
	private CodeSetElement designateActionCode;
	/** The execution status. */
	private String executionStatus;
	/** The Legal Presence Document. */
	private LegalPresenceDocument legalPresenceDocument;
	/** The Person Name. This captures information for the First, Last name returned from the mainframe. */
	private PersonName personName;
	/** The eligibility statement code. */
	private String eligibilityStatementCode;
	
	/**
	 * Gets the Designate Action.
	 * 
	 * @return the designateActionCode
	 */
	public CodeSetElement getDesignateActionCode() {
		return designateActionCode;
	}
	
	/**
	 * Gets the eligibility statement code.
	 *
	 * @return the eligibilityStatementCode
	 */
	public String getEligibilityStatementCode() {
		return eligibilityStatementCode;
	}
	
	/**
	 * Gets the execution status.
	 *
	 * @return the executionStatus
	 */
	public String getExecutionStatus() {
		return executionStatus;
	}
	
	/**
	 * Gets the legal Presence Document.
	 * 
	 * @return the legalPresenceDocument
	 */
	public LegalPresenceDocument getLegalPresenceDocument() {
		return legalPresenceDocument;
	}
	
	/**
	 * Gets the person name.
	 *
	 * @return the personName
	 */
	public PersonName getPersonName() {
		return personName;
	}
	
	/**
	 * Sets the Designate Action.
	 * 
	 * @param designateActionCode the designateActionCode to set
	 */
	public void setDesignateActionCode(CodeSetElement designateActionCode) {
		this.designateActionCode = designateActionCode;
	}
	
	/**
	 * Sets the eligibility statement code.
	 *
	 * @param eligibilityStatementCode the eligibilityStatementCode to set
	 */
	public void setEligibilityStatementCode(String eligibilityStatementCode) {
		this.eligibilityStatementCode = eligibilityStatementCode;
	}
	
	/**
	 * Sets the execution status.
	 *
	 * @param executionStatus the executionStatus to set
	 */
	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}
	
	/**
	 * Sets the legal Presence Document.
	 * 
	 * @param legalPresenceDocument the legalPresenceDocument to set
	 */
	public void setLegalPresenceDocument(
			LegalPresenceDocument legalPresenceDocument) {
		this.legalPresenceDocument = legalPresenceDocument;
	}
	
	/**
	 * Sets the person name.
	 *
	 * @param personName the personName to set
	 */
	public void setPersonName(PersonName personName) {
		this.personName = personName;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(512);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LpvRecord other = (LpvRecord) obj;
		if (designateActionCode == null) {
			if (other.designateActionCode != null)
				return false;
		}
		else if (!designateActionCode.equals(other.designateActionCode))
			return false;
		if (eligibilityStatementCode == null) {
			if (other.eligibilityStatementCode != null)
				return false;
		}
		else if (!eligibilityStatementCode
				.equals(other.eligibilityStatementCode))
			return false;
		if (executionStatus == null) {
			if (other.executionStatus != null)
				return false;
		}
		else if (!executionStatus.equals(other.executionStatus))
			return false;
		if (legalPresenceDocument == null) {
			if (other.legalPresenceDocument != null)
				return false;
		}
		else if (!legalPresenceDocument.equals(other.legalPresenceDocument))
			return false;
		if (personName == null) {
			if (other.personName != null)
				return false;
		}
		else if (!personName.equals(other.personName))
			return false;
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((designateActionCode == null) ? 0 : designateActionCode
						.hashCode());
		result = prime
				* result
				+ ((eligibilityStatementCode == null) ? 0
						: eligibilityStatementCode.hashCode());
		result = prime * result
				+ ((executionStatus == null) ? 0 : executionStatus.hashCode());
		result = prime
				* result
				+ ((legalPresenceDocument == null) ? 0 : legalPresenceDocument
						.hashCode());
		result = prime * result
				+ ((personName == null) ? 0 : personName.hashCode());
		return result;
	}
	
	/**
	 * To string on.
	 *
	 * @param aBuilder the a builder
	 * @param anIndent the an indent
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("designateActionCode", designateActionCode, anIndent,
				aBuilder);
		outputKeyValue("executionStatus", executionStatus, anIndent, aBuilder);
		outputKeyValue("legalPresenceDocument", legalPresenceDocument,
				anIndent, aBuilder);
		outputKeyValue("personName", personName, anIndent, aBuilder);
		outputKeyValue("eligibilityStatementCode", eligibilityStatementCode,
				anIndent, aBuilder);
	}
}
/**
 *  Modification History:
 *
 *  $Log: LpvRecord.java,v $
 *  Revision 1.8  2011/11/30 19:53:26  mwhys
 *  Added eligibilityStatementCode field. (Defect 986)
 *
 *  Revision 1.7  2010/12/07 22:08:54  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.6  2010/12/07 03:56:50  mwpxp2
 *  Added toStringOn/1, toString/0; sorted
 *
 *  Revision 1.5  2010/08/04 00:22:18  mwpxr4
 *  Added execution status to LpvRecord.
 *
 *  Revision 1.4  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.2.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 16:53:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/05/27 14:37:53  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.4  2010/03/25 17:18:55  mwuxb
 *  Added attribute person name.
 *
 *  Revision 1.3  2010/03/15 23:00:13  mwhxa2
 *  Implements serializable
 *
 *  Revision 1.2  2010/01/28 22:21:40  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/07 16:15:41  mwpxr4
 *  Added class description in JavaDocs.
 *
 *  Revision 1.4  2009/09/14 18:16:18  mwcsj3
 *  Changed DesignateCode to CodeSetElement
 *
 *  Revision 1.3  2009/09/08 17:59:33  mwsmg6
 *  removing CodeSetElement subclasses
 *
 *  Revision 1.2  2009/08/27 05:39:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/22 20:55:49  mwsyk1
 *  LPV record class
 *
 */
