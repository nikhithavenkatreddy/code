package gov.ca.dmv.ease.bo.financial;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Description: I am interface for payment implementatiaons
 * File: IPayment.java
 * Module:  gov.ca.dmv.ease.bo.financial
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/21 22:24:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPayment extends IPaymentType, Serializable {
	/**
	 * Gets the amount.
	 * 
	 * @return the amount
	 */
	BigDecimal getAmount();

	/**
	 * Gets the amount as string.
	 *
	 * @return the amount as string
	 */
	String getAmountAsString();

	/**
	 * Gets the date.
	 * 
	 * @return the date
	 */
	Date getDate();
}
/**
 *  Modification History:
 *
 *  $Log: IPayment.java,v $
 *  Revision 1.1  2011/10/21 22:24:27  mwpxp2
 *  Initial - extracted out from the WS4 payment implementation
 *
 */
