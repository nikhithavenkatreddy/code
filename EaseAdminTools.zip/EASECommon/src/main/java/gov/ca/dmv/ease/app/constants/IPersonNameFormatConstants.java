/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: I define the constants for person name format.
 * File: $ IPersonNameFormatConstants.java $
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Nov 28, 2011
 * @author MWHYS  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/03/05 23:43:14 $
 * Last Changed By: $ MWHYS $
 */
public interface IPersonNameFormatConstants {
	/** The NAME_FORMAT_FIRST_MIDDLE_LAST. */
	int NAME_FORMAT_FIRST_MIDDLE_LAST = 1;
	/** The NAME_FORMAT_LAST_MIDDLE_FIRST. */
	int NAME_FORMAT_LAST_MIDDLE_FIRST = 2;
	/** The NAME_FORMAT_MIDDLE_LAST_FIRST. */
	int NAME_FORMAT_MIDDLE_LAST_FIRST = 3;
	/** The NAME_FORMAT_LAST_FIRST. */
	int NAME_FORMAT_LAST_FIRST = 4;
	/** The NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX. */
	int NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX = 5;
	/** The NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX. */
	int NAME_FORMAT_FIRST_MIDDLE_LAST_SUFFIX = 6;
	/** The NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST. */
	int NAME_FORMAT_FIRST_MIDDLE_SUFFIX_LAST = 7;
	/** The NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX_WITH_COMMA. */
	int NAME_FORMAT_LAST_FIRST_MIDDLE_SUFFIX_WITH_COMMA = 8;
}
/**
 *  Modification History:
 * 
 *  $Log: IPersonNameFormatConstants.java,v $
 *  Revision 1.2  2013/03/05 23:43:14  mwhys
 *  Added a new format. (Defect 8670)
 *
 *  Revision 1.1  2011/11/28 19:55:36  mwhys
 *  Initial
 *
 */
