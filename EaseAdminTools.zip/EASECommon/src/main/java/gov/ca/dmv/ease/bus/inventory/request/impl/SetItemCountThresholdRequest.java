/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request to set threshold(s) for inventory item(s)
 * 
 * File: SetItemCountThresholdRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/20 23:19:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SetItemCountThresholdRequest extends AbstractInventoryStateRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 869215658286324087L;

	/**
	 * Instantiates a new sets the item count threshold request.
	 */
	protected SetItemCountThresholdRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	public SetItemCountThresholdRequest(IUserContext context,
			List <IItemThreshold> aThresholdList) {
		super(context);
		setThresholdsFrom(aThresholdList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryStatusRequestResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SetItemCountThresholdRequest.java,v $
 *  Revision 1.2  2010/09/20 23:19:31  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.2  2010/09/20 18:36:27  mwpxp2
 *  Added threshold list
 *
 *  Revision 1.1  2010/09/20 18:30:19  mwpxp2
 *  Initial
 *
 */
