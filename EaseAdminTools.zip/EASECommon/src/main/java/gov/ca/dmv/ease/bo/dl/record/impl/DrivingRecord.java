/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.dl.record.impl;

import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_ELG;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_EXP;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_LIC;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_VAL;
import static gov.ca.dmv.ease.fw.util.impl.ArrayUtils.contains;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: This class holds the driving record of a person
 * File: DrivingRecord.java
 * Module:  gov.cd.dmv.ease.bo.dl.record.impl
 * Created: 2009 
 * @author NN  
 * @version $Revision: 1.34 $
 * Last Changed: $Date: 2013/10/03 15:14:57 $
 * Last Changed By: $Author: mwskh1 $
 */
public class DrivingRecord extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6329967687795083459L;
	/** The Constant STATE_OF_ORIGIN_XX. */
	private static final String STATE_OF_ORIGIN_XX = "XX";
	/** The Constant TYPE_INDICATOR_NDR. */
	private static final String TYPE_INDICATOR_NDR = "N";
	/** The Constant TYPE_INDICATOR_PDPS. */
	private static final String TYPE_INDICATOR_PDPS = "P";
	/** The Constant DESIGNATE_QUESTIONABLE. */
	private static final String DESIGNATE_QUESTIONABLE = "Q";
	/** The Constant DESIGNATE_SAME. */
	private static final String DESIGNATE_SAME = "S";
	/** The Constant VALID_DRIVING_RECORD_STATUS_DESC. 
	 * ELIGIBLE, LICENSED, VALID, EXPIRED*/
	private static final Object[] VALID_DRIVING_RECORD_STATUS_DESC = {
			OUTPUT_COMM_STATUS_DESC_ELG, OUTPUT_COMM_STATUS_DESC_LIC,
			OUTPUT_COMM_STATUS_DESC_VAL, OUTPUT_COMM_STATUS_DESC_EXP };
	/** The AKA Information of the person. */
	private List <AkaInformation> akaInformation;
	/** The expanded AKA Information of the person. */
	private List <AkaInformation> expandedAkaInformationList;
	/** The DL withdrawal pending indicator. */
	private String akaSocialSecurityNumber;
	/** The aka first dl number state. */
	private String akaFirstDlNumberState;
	/** The aka first dl number. */
	private String akaFirstDlNumber;
	/** The Application Id. */
	private int applicationId;
	/** The city. */
	private String city;
	/** The commercial License status codes. Set in SendCdlisAndPdpsConverter. */
	private CodeSetElement commercialLicenseStatusCode;
	/** The Birth Date of the Person. */
	private Date currentBirthDate;
	/** The Name of the Person. */
	private PersonName currentName;
	/** The Expanded Name of the Person. (CDLIS 5.2) */
	private PersonName expandedCurrentName;
	/** The State of the DL number. */
	private CodeSetElement currentPrimaryDlNumberState;
	/** The Social Security number of the person. */
	private String currentPrimarySsn;
	/** The Designate Action. */
	private String designateAction;
	/** The DL withdrawal pending indicator. */
	private String dlWithdrawalPendingIndicator;
	/** The driver license class codes of the person. */
	private List <CodeSetElement> driverLicenseClassCodes;
	/** The Endorsements of the matched record. */
	private List <CodeSetElement> endorsements;
	/** The Expiration Date of the Matched Record. */
	private Date expirationDate;
	/** The eye color code. */
	private CodeSetElement eyeColorCode;
	/** The gender code of the person. */
	private CodeSetElement genderCode;
	/** The License Number of the person. */
	private CodeSetElement hairColorCode;
	/** The height in feet of the person. */
	private Integer heightInFeet;
	/** The height in inches of the person. */
	private Integer heightInInch;
	/** The Cleared By Issuance Indicator. */
	@Deprecated
	/** Not Sure how this attribute is being used. Need more clarity.  */
	private Boolean isClearedByIssuanceIndicator;
	/** The Remove Restriction Indicator. */
	@Deprecated
	/** Not Sure how this attribute is being used. Need more clarity.  */
	private Boolean isRemoveRestrictionIndicator;
	/** The License Number of the person. */
	private String licenseNumber;
	/** The match sequence number of CDLIS and PDPS. */
	private int matchSequenceNumberId;
	/** The non commercial License status codes. Non-Commercial/Motorcycle*/
	private CodeSetElement nonCommercialLicenseStatusCode;
	/** The Password. */
	private String password;
	/** The record type. XX means CDLIS otherwise PDPS */
	private String recordTypeOrStateOfOrigin;
	/** The Restrictions places on the Customer's License as reported by CDLIS. */
	private List <CodeSetElement> restrictions;
	/** The weight of the person. */
	private Integer weight;
	/** The record index. */
	private int recordIndex;
	/** CDLIS 5.2  A temporary flag to be used for CDLIS 5.2 testing.  Gap code is an origin code */
	private boolean isAcGapCodeEnabled = false;
	/** 
	 * The cdlis/pdps response code. This holds the status of cdlis/pdps inquiry for CDU Tcode. 
	 * This response code will be use to display cdlis inquiry's status on the cdlis/pdps response screen.
	 *  
	 *  C = CDL - CNA, 
	 *  L = CDL RESPONSE LENGTH ERROR, 
	 *  M = CDL RECORD TOO LONG,
	 *  P = PARTIAL CDL RESPONSE RECEIVED, 
	 *  T = NO CDL RESPONSE RECEIVED, 
	 *  E = CDLIS RETURNED ERROR, 
	 *  U = CDLIS - CNA,
	 *  G = GOOD RESPONSE
	 *  N = NO ADDITIONAL HITS,
	 *  W = CDL WITHDRAWAL PENDING,
	 *  D = CDL DISCREPANCY, 
	 *  I = CDL INCOMPLETE.
	 *  
	 * */
	private CodeSetElement cdlisPdpsResponseCode;
	/** The cdu or ndr response code. 
	 *  Corresponds to MSRCRCDE or MSRNRCDE */
	private CodeSetElement cduOrNdrResponseCode;
	/** The display response text1. Can be used for both CDLIS and PDPS records. 
	 *  Corresponding EDL variables: VFSMSG1C/VFSNR2CS */
	private String displayResponseText1;
	/** The display response text2. Can be used for both CDLIS and PDPS records.
	 *  Corresponding EDL variables: VFSMSG2C/VFSNR2NS */
	private String displayResponseText2;
	/** The match limit indicator. */
	private String matchLimitIndicator;
	/** The cdl designate field. The value of this field is set in CDS converter. 
	 * Corresponding EDL variable: VDICDSN1 */
	private String cdlDesignateField;
	/** The is cdlis record tried. */
	private boolean isCdlisRecordTried = false;
	/** The commercial license status. Used in CdlisStateOfRecordConverter. */
	private String commercialLicenseStatus;
	/** The non commercial license status. */
	private String nonCommercialLicenseStatus;
	/** The pdps non pdpd state indicator. 
	 *  Corresponding EDL variable: VFSPNPS */
	private String pdpsNonPdpdStateIndicator;
	/** The cdl ndr hit record status. */
	private CodeSetElement cdlNdrHitRecordStatus = new CodeSetElement();
	/** The is approval password required and entered. */
	private boolean isApprovalPasswordRequiredAndEntered = false;
	/** Used for match logic for CDLIS Records */
	private int matchCount = 0;

	/**
	 * Instantiates a new driving record.
	 */
	public DrivingRecord() {
	}

	/**
	 * Instantiates a new driving record.
	 *
	 * @param dataToCopy the data to copy
	 */
	public DrivingRecord(DrivingRecord dataToCopy) {
		super();
		copy(dataToCopy);
	}

	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	private void copy(DrivingRecord dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null person argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		copyAkaInformation(dataToCopy.getAkaInformation());
		copyExpandedAkaInformation(dataToCopy.getExpandedAkaInformationList());
		setAkaSocialSecurityNumber(dataToCopy.getAkaSocialSecurityNumber());
		setAkaFirstDlNumberState(dataToCopy.getAkaFirstDlNumberState());
		setAkaFirstDlNumber(dataToCopy.getAkaFirstDlNumber());
		setApplicationId(dataToCopy.getApplicationId());
		setCity(dataToCopy.getCity());
		//Copy CommercialLicenseStatusCode
		if (isNotNull(dataToCopy.getCommercialLicenseStatusCode())) {
			setCommercialLicenseStatusCode(new CodeSetElement(dataToCopy
					.getCommercialLicenseStatusCode()));
		}
		else {
			setCommercialLicenseStatusCode(null);
		}
		//Copy currentBirthDate
		if (isNotNull(dataToCopy.getCurrentBirthDate())) {
			setCurrentBirthDate(new Date(dataToCopy.getCurrentBirthDate()
					.getTime()));
		}
		else {
			setCurrentBirthDate(null);
		}
		//Copy currentName
		if (isNotNull(dataToCopy.getCurrentName())) {
			setCurrentName(new PersonName(dataToCopy.getCurrentName()));
		}
		else {
			setCurrentName(null);
		}
		//Copy expandedCurrentName
		if (isNotNull(dataToCopy.getExpandedCurrentName())) {
			setExpandedCurrentName(new PersonName(dataToCopy
					.getExpandedCurrentName()));
		}
		else {
			setExpandedCurrentName(null);
		}
		//Copy currentPrimaryDlNumberState
		if (isNotNull(dataToCopy.getCurrentPrimaryDlNumberState())) {
			setCurrentPrimaryDlNumberState(new CodeSetElement(dataToCopy
					.getCurrentPrimaryDlNumberState()));
		}
		else {
			setCurrentPrimaryDlNumberState(null);
		}
		setCurrentPrimarySsn(dataToCopy.getCurrentPrimarySsn());
		setDesignateAction(dataToCopy.getDesignateAction());
		setDlWithdrawalPendingIndicator(dataToCopy
				.getDlWithdrawalPendingIndicator());
		copyDriverLicenseClassCodes(dataToCopy.getDriverLicenseClassCodes());
		copyEndorsements(dataToCopy.getEndorsements());
		//Copy expirationDate
		if (isNotNull(dataToCopy.getExpirationDate())) {
			setExpirationDate(new Date(dataToCopy.getExpirationDate().getTime()));
		}
		else {
			setExpirationDate(null);
		}
		//Copy eyeColorCode
		if (isNotNull(dataToCopy.getEyeColorCode())) {
			setEyeColorCode(new CodeSetElement(dataToCopy.getEyeColorCode()));
		}
		else {
			setEyeColorCode(null);
		}
		//Copy genderCode
		if (isNotNull(dataToCopy.getGenderCode())) {
			setGenderCode(new CodeSetElement(dataToCopy.getGenderCode()));
		}
		else {
			setGenderCode(null);
		}
		//Copy hairColorCode
		if (isNotNull(dataToCopy.getHairColorCode())) {
			setHairColorCode(new CodeSetElement(dataToCopy.getHairColorCode()));
		}
		else {
			setHairColorCode(null);
		}
		//Copy heightInFeet
		if (isNotNull(dataToCopy.getHeightInFeet())) {
			setHeightInFeet(new Integer(dataToCopy.getHeightInFeet()));
		}
		else {
			setHeightInFeet(null);
		}
		//Copy heightInInch
		if (isNotNull(dataToCopy.getHeightInInch())) {
			setHeightInInch(new Integer(dataToCopy.getHeightInInch()));
		}
		else {
			setHeightInInch(null);
		}
		//Copy isClearedByIssuanceIndicator
		if (isNotNull(dataToCopy.isClearedByIssuanceIndicator())) {
			setClearedByIssuanceIndicator(new Boolean(dataToCopy
					.isClearedByIssuanceIndicator()));
		}
		else {
			setClearedByIssuanceIndicator(null);
		}
		//Copy isRemoveRestrictionIndicator
		if (isNotNull(dataToCopy.isRemoveRestrictionIndicator())) {
			setRemoveRestrictionIndicator(new Boolean(dataToCopy
					.isRemoveRestrictionIndicator()));
		}
		else {
			setRemoveRestrictionIndicator(null);
		}
		setLicenseNumber(dataToCopy.getLicenseNumber());
		setMatchSequenceNumberId(dataToCopy.getMatchSequenceNumberId());
		//Copy nonCommercialLicenseStatusCode
		if (isNotNull(dataToCopy.getNonCommercialLicenseStatusCode())) {
			setNonCommercialLicenseStatusCode(new CodeSetElement(dataToCopy
					.getNonCommercialLicenseStatusCode()));
		}
		else {
			setNonCommercialLicenseStatusCode(null);
		}
		setPassword(dataToCopy.getPassword());
		setRecordTypeOrStateOfOrigin(dataToCopy.getRecordTypeOrStateOfOrigin());
		copyRestrictions(dataToCopy.getRestrictions());
		//Copy weight
		if (isNotNull(dataToCopy.getWeight())) {
			setWeight(new Integer(dataToCopy.getWeight()));
		}
		else {
			setWeight(null);
		}
		setRecordIndex(dataToCopy.getRecordIndex());
		//Copy cdlisPdpsResponseCode
		if (isNotNull(dataToCopy.getCdlisPdpsResponseCode())) {
			setCdlisPdpsResponseCode(new CodeSetElement(dataToCopy
					.getCdlisPdpsResponseCode()));
		}
		else {
			setCdlisPdpsResponseCode(null);
		}
		//Copy cduOrNdrResponseCode
		if (isNotNull(dataToCopy.getCduOrNdrResponseCode())) {
			setCduOrNdrResponseCode(new CodeSetElement(dataToCopy
					.getCduOrNdrResponseCode()));
		}
		else {
			setCduOrNdrResponseCode(null);
		}
		setDisplayResponseText1(dataToCopy.getDisplayResponseText1());
		setDisplayResponseText2(dataToCopy.getDisplayResponseText2());
		setMatchLimitIndicator(dataToCopy.getMatchLimitIndicator());
		setCdlDesignateField(dataToCopy.getCdlDesignateField());
		setCdlisRecordTried(dataToCopy.isCdlisRecordTried());
		setCommercialLicenseStatus(dataToCopy.getCommercialLicenseStatus());
		setNonCommercialLicenseStatus(dataToCopy
				.getNonCommercialLicenseStatus());
		//Copy cdlNdrHitRecordStatus
		if (isNotNull(dataToCopy.getCdlNdrHitRecordStatus())) {
			setCdlNdrHitRecordStatus(new CodeSetElement(dataToCopy
					.getCdlNdrHitRecordStatus()));
		}
		else {
			setCduOrNdrResponseCode(null);
		}
		//Copy isApprovalPasswordRequiredAndEntered
		setApprovalPasswordRequiredAndEntered(dataToCopy
				.isApprovalPasswordRequiredAndEntered());
	}

	/**
	 * Copy aka information.
	 *
	 * @param akaInformation the aka information
	 */
	protected void copyAkaInformation(List <AkaInformation> akaInformationList) {
		if (isNotNull(akaInformationList)) {
			List <AkaInformation> akaInformationCopy = new ArrayList <AkaInformation>();
			for (AkaInformation akaInformationToCopy : akaInformationList) {
				if (isNotNull(akaInformationToCopy)) {
					akaInformationCopy.add(new AkaInformation(
							akaInformationToCopy));
				}
			}
			setAkaInformation(akaInformationCopy);
		}
		else {
			setAkaInformation(null);
		}
	}

	/**
	 * Copy expanded aka information. (CDLIS 5.2)
	 *
	 * @param akaInformation the aka information
	 */
	protected void copyExpandedAkaInformation(
			List <AkaInformation> expandedAkaInformationList) {
		if (isNotNull(expandedAkaInformationList)) {
			List <AkaInformation> expandedAkaInformationCopy = new ArrayList <AkaInformation>();
			for (AkaInformation expandedAkaInformationToCopy : expandedAkaInformationList) {
				if (isNotNull(expandedAkaInformationToCopy)) {
					expandedAkaInformationCopy.add(new AkaInformation(
							expandedAkaInformationToCopy));
				}
			}
			setExpandedAkaInformationList(expandedAkaInformationCopy);
		}
		else {
			setExpandedAkaInformationList(null);
		}
	}

	/**
	 * Copy driver license class codes.
	 *
	 * @param driverLicenseClassCodes the driver license class codes
	 */
	protected void copyDriverLicenseClassCodes(
			List <CodeSetElement> driverLicenseClassCodes) {
		if (isNotNull(driverLicenseClassCodes)) {
			List <CodeSetElement> driverLicenseClassCodesCopy = new ArrayList <CodeSetElement>();
			for (CodeSetElement driverLicenseClassCodeToCopy : driverLicenseClassCodes) {
				if (isNotNull(driverLicenseClassCodeToCopy)) {
					driverLicenseClassCodesCopy.add(new CodeSetElement(
							driverLicenseClassCodeToCopy));
				}
			}
			setDriverLicenseClassCodes(driverLicenseClassCodesCopy);
		}
		else {
			setDriverLicenseClassCodes(null);
		}
	}

	/**
	 * Copy endorsements.
	 *
	 * @param endorsements the endorsements
	 */
	protected void copyEndorsements(List <CodeSetElement> endorsements) {
		if (isNotNull(endorsements)) {
			List <CodeSetElement> endorsementsCopy = new ArrayList <CodeSetElement>();
			for (CodeSetElement endorsementToCopy : endorsements) {
				if (isNotNull(endorsementToCopy)) {
					endorsementsCopy.add(new CodeSetElement(endorsementToCopy));
				}
			}
			setEndorsements(endorsementsCopy);
		}
		else {
			setEndorsements(null);
		}
	}

	/**
	 * Copy restrictions.
	 *
	 * @param restrictions the restrictions
	 */
	protected void copyRestrictions(List <CodeSetElement> restrictions) {
		if (isNotNull(restrictions)) {
			List <CodeSetElement> restrictionsCopy = new ArrayList <CodeSetElement>();
			for (CodeSetElement restrictionToCopy : restrictions) {
				if (isNotNull(restrictionToCopy)) {
					restrictionsCopy.add(new CodeSetElement(restrictionToCopy));
				}
			}
			setRestrictions(restrictionsCopy);
		}
		else {
			setRestrictions(null);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((akaFirstDlNumber == null) ? 0 : akaFirstDlNumber.hashCode());
		result = prime
				* result
				+ ((akaFirstDlNumberState == null) ? 0 : akaFirstDlNumberState
						.hashCode());
		result = prime * result
				+ ((akaInformation == null) ? 0 : akaInformation.hashCode());
		result = prime
				* result
				+ ((expandedAkaInformationList == null) ? 0
						: expandedAkaInformationList.hashCode());
		result = prime
				* result
				+ ((akaSocialSecurityNumber == null) ? 0
						: akaSocialSecurityNumber.hashCode());
		result = prime * result + applicationId;
		result = prime
				* result
				+ ((cdlDesignateField == null) ? 0 : cdlDesignateField
						.hashCode());
		result = prime
				* result
				+ ((cdlNdrHitRecordStatus == null) ? 0 : cdlNdrHitRecordStatus
						.hashCode());
		result = prime
				* result
				+ ((cdlisPdpsResponseCode == null) ? 0 : cdlisPdpsResponseCode
						.hashCode());
		result = prime
				* result
				+ ((cduOrNdrResponseCode == null) ? 0 : cduOrNdrResponseCode
						.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime
				* result
				+ ((commercialLicenseStatus == null) ? 0
						: commercialLicenseStatus.hashCode());
		result = prime
				* result
				+ ((commercialLicenseStatusCode == null) ? 0
						: commercialLicenseStatusCode.hashCode());
		result = prime
				* result
				+ ((currentBirthDate == null) ? 0 : currentBirthDate.hashCode());
		result = prime * result
				+ ((currentName == null) ? 0 : currentName.hashCode());
		result = prime
				* result
				+ ((expandedCurrentName == null) ? 0 : expandedCurrentName
						.hashCode());
		result = prime
				* result
				+ ((currentPrimaryDlNumberState == null) ? 0
						: currentPrimaryDlNumberState.hashCode());
		result = prime
				* result
				+ ((currentPrimarySsn == null) ? 0 : currentPrimarySsn
						.hashCode());
		result = prime * result
				+ ((designateAction == null) ? 0 : designateAction.hashCode());
		result = prime
				* result
				+ ((displayResponseText1 == null) ? 0 : displayResponseText1
						.hashCode());
		result = prime
				* result
				+ ((displayResponseText2 == null) ? 0 : displayResponseText2
						.hashCode());
		result = prime
				* result
				+ ((dlWithdrawalPendingIndicator == null) ? 0
						: dlWithdrawalPendingIndicator.hashCode());
		result = prime
				* result
				+ ((driverLicenseClassCodes == null) ? 0
						: driverLicenseClassCodes.hashCode());
		result = prime * result
				+ ((endorsements == null) ? 0 : endorsements.hashCode());
		result = prime * result
				+ ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime * result
				+ ((eyeColorCode == null) ? 0 : eyeColorCode.hashCode());
		result = prime * result
				+ ((genderCode == null) ? 0 : genderCode.hashCode());
		result = prime * result
				+ ((hairColorCode == null) ? 0 : hairColorCode.hashCode());
		result = prime * result
				+ ((heightInFeet == null) ? 0 : heightInFeet.hashCode());
		result = prime * result
				+ ((heightInInch == null) ? 0 : heightInInch.hashCode());
		result = prime * result
				+ (isApprovalPasswordRequiredAndEntered ? 1231 : 1237);
		result = prime * result + (isCdlisRecordTried ? 1231 : 1237);
		result = prime
				* result
				+ ((isClearedByIssuanceIndicator == null) ? 0
						: isClearedByIssuanceIndicator.hashCode());
		result = prime
				* result
				+ ((isRemoveRestrictionIndicator == null) ? 0
						: isRemoveRestrictionIndicator.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime
				* result
				+ ((matchLimitIndicator == null) ? 0 : matchLimitIndicator
						.hashCode());
		result = prime * result + matchSequenceNumberId;
		result = prime
				* result
				+ ((nonCommercialLicenseStatus == null) ? 0
						: nonCommercialLicenseStatus.hashCode());
		result = prime
				* result
				+ ((nonCommercialLicenseStatusCode == null) ? 0
						: nonCommercialLicenseStatusCode.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime
				* result
				+ ((pdpsNonPdpdStateIndicator == null) ? 0
						: pdpsNonPdpdStateIndicator.hashCode());
		result = prime * result + recordIndex;
		result = prime
				* result
				+ ((recordTypeOrStateOfOrigin == null) ? 0
						: recordTypeOrStateOfOrigin.hashCode());
		result = prime * result
				+ ((restrictions == null) ? 0 : restrictions.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DrivingRecord other = (DrivingRecord) obj;
		if (akaFirstDlNumber == null) {
			if (other.akaFirstDlNumber != null) {
				return false;
			}
		}
		else if (!akaFirstDlNumber.equals(other.akaFirstDlNumber)) {
			return false;
		}
		if (akaFirstDlNumberState == null) {
			if (other.akaFirstDlNumberState != null) {
				return false;
			}
		}
		else if (!akaFirstDlNumberState.equals(other.akaFirstDlNumberState)) {
			return false;
		}
		if (akaInformation == null) {
			if (other.akaInformation != null) {
				return false;
			}
		}
		else if (!akaInformation.equals(other.akaInformation)) {
			return false;
		}
		if (expandedAkaInformationList == null) {
			if (other.expandedAkaInformationList != null) {
				return false;
			}
		}
		else if (!expandedAkaInformationList
				.equals(other.expandedAkaInformationList)) {
			return false;
		}
		if (akaSocialSecurityNumber == null) {
			if (other.akaSocialSecurityNumber != null) {
				return false;
			}
		}
		else if (!akaSocialSecurityNumber.equals(other.akaSocialSecurityNumber)) {
			return false;
		}
		if (applicationId != other.applicationId) {
			return false;
		}
		if (cdlDesignateField == null) {
			if (other.cdlDesignateField != null) {
				return false;
			}
		}
		else if (!cdlDesignateField.equals(other.cdlDesignateField)) {
			return false;
		}
		if (cdlNdrHitRecordStatus == null) {
			if (other.cdlNdrHitRecordStatus != null) {
				return false;
			}
		}
		else if (!cdlNdrHitRecordStatus.equals(other.cdlNdrHitRecordStatus)) {
			return false;
		}
		if (cdlisPdpsResponseCode == null) {
			if (other.cdlisPdpsResponseCode != null) {
				return false;
			}
		}
		else if (!cdlisPdpsResponseCode.equals(other.cdlisPdpsResponseCode)) {
			return false;
		}
		if (cduOrNdrResponseCode == null) {
			if (other.cduOrNdrResponseCode != null) {
				return false;
			}
		}
		else if (!cduOrNdrResponseCode.equals(other.cduOrNdrResponseCode)) {
			return false;
		}
		if (city == null) {
			if (other.city != null) {
				return false;
			}
		}
		else if (!city.equals(other.city)) {
			return false;
		}
		if (commercialLicenseStatus == null) {
			if (other.commercialLicenseStatus != null) {
				return false;
			}
		}
		else if (!commercialLicenseStatus.equals(other.commercialLicenseStatus)) {
			return false;
		}
		if (commercialLicenseStatusCode == null) {
			if (other.commercialLicenseStatusCode != null) {
				return false;
			}
		}
		else if (!commercialLicenseStatusCode
				.equals(other.commercialLicenseStatusCode)) {
			return false;
		}
		if (currentBirthDate == null) {
			if (other.currentBirthDate != null) {
				return false;
			}
		}
		else if (!currentBirthDate.equals(other.currentBirthDate)) {
			return false;
		}
		if (currentName == null) {
			if (other.currentName != null) {
				return false;
			}
		}
		else if (!currentName.equals(other.currentName)) {
			return false;
		}
		if (currentPrimaryDlNumberState == null) {
			if (other.currentPrimaryDlNumberState != null) {
				return false;
			}
		}
		else if (!currentPrimaryDlNumberState
				.equals(other.currentPrimaryDlNumberState)) {
			return false;
		}
		if (currentPrimarySsn == null) {
			if (other.currentPrimarySsn != null) {
				return false;
			}
		}
		else if (!currentPrimarySsn.equals(other.currentPrimarySsn)) {
			return false;
		}
		if (designateAction == null) {
			if (other.designateAction != null) {
				return false;
			}
		}
		else if (!designateAction.equals(other.designateAction)) {
			return false;
		}
		if (displayResponseText1 == null) {
			if (other.displayResponseText1 != null) {
				return false;
			}
		}
		else if (!displayResponseText1.equals(other.displayResponseText1)) {
			return false;
		}
		if (displayResponseText2 == null) {
			if (other.displayResponseText2 != null) {
				return false;
			}
		}
		else if (!displayResponseText2.equals(other.displayResponseText2)) {
			return false;
		}
		if (dlWithdrawalPendingIndicator == null) {
			if (other.dlWithdrawalPendingIndicator != null) {
				return false;
			}
		}
		else if (!dlWithdrawalPendingIndicator
				.equals(other.dlWithdrawalPendingIndicator)) {
			return false;
		}
		if (driverLicenseClassCodes == null) {
			if (other.driverLicenseClassCodes != null) {
				return false;
			}
		}
		else if (!driverLicenseClassCodes.equals(other.driverLicenseClassCodes)) {
			return false;
		}
		if (endorsements == null) {
			if (other.endorsements != null) {
				return false;
			}
		}
		else if (!endorsements.equals(other.endorsements)) {
			return false;
		}
		if (expirationDate == null) {
			if (other.expirationDate != null) {
				return false;
			}
		}
		else if (!expirationDate.equals(other.expirationDate)) {
			return false;
		}
		if (eyeColorCode == null) {
			if (other.eyeColorCode != null) {
				return false;
			}
		}
		else if (!eyeColorCode.equals(other.eyeColorCode)) {
			return false;
		}
		if (genderCode == null) {
			if (other.genderCode != null) {
				return false;
			}
		}
		else if (!genderCode.equals(other.genderCode)) {
			return false;
		}
		if (hairColorCode == null) {
			if (other.hairColorCode != null) {
				return false;
			}
		}
		else if (!hairColorCode.equals(other.hairColorCode)) {
			return false;
		}
		if (heightInFeet == null) {
			if (other.heightInFeet != null) {
				return false;
			}
		}
		else if (!heightInFeet.equals(other.heightInFeet)) {
			return false;
		}
		if (heightInInch == null) {
			if (other.heightInInch != null) {
				return false;
			}
		}
		else if (!heightInInch.equals(other.heightInInch)) {
			return false;
		}
		if (isApprovalPasswordRequiredAndEntered != other.isApprovalPasswordRequiredAndEntered) {
			return false;
		}
		if (isCdlisRecordTried != other.isCdlisRecordTried) {
			return false;
		}
		if (isClearedByIssuanceIndicator == null) {
			if (other.isClearedByIssuanceIndicator != null) {
				return false;
			}
		}
		else if (!isClearedByIssuanceIndicator
				.equals(other.isClearedByIssuanceIndicator)) {
			return false;
		}
		if (isRemoveRestrictionIndicator == null) {
			if (other.isRemoveRestrictionIndicator != null) {
				return false;
			}
		}
		else if (!isRemoveRestrictionIndicator
				.equals(other.isRemoveRestrictionIndicator)) {
			return false;
		}
		if (licenseNumber == null) {
			if (other.licenseNumber != null) {
				return false;
			}
		}
		else if (!licenseNumber.equals(other.licenseNumber)) {
			return false;
		}
		if (matchLimitIndicator == null) {
			if (other.matchLimitIndicator != null) {
				return false;
			}
		}
		else if (!matchLimitIndicator.equals(other.matchLimitIndicator)) {
			return false;
		}
		if (matchSequenceNumberId != other.matchSequenceNumberId) {
			return false;
		}
		if (nonCommercialLicenseStatus == null) {
			if (other.nonCommercialLicenseStatus != null) {
				return false;
			}
		}
		else if (!nonCommercialLicenseStatus
				.equals(other.nonCommercialLicenseStatus)) {
			return false;
		}
		if (nonCommercialLicenseStatusCode == null) {
			if (other.nonCommercialLicenseStatusCode != null) {
				return false;
			}
		}
		else if (!nonCommercialLicenseStatusCode
				.equals(other.nonCommercialLicenseStatusCode)) {
			return false;
		}
		if (password == null) {
			if (other.password != null) {
				return false;
			}
		}
		else if (!password.equals(other.password)) {
			return false;
		}
		if (pdpsNonPdpdStateIndicator == null) {
			if (other.pdpsNonPdpdStateIndicator != null) {
				return false;
			}
		}
		else if (!pdpsNonPdpdStateIndicator
				.equals(other.pdpsNonPdpdStateIndicator)) {
			return false;
		}
		if (recordIndex != other.recordIndex) {
			return false;
		}
		if (recordTypeOrStateOfOrigin == null) {
			if (other.recordTypeOrStateOfOrigin != null) {
				return false;
			}
		}
		else if (!recordTypeOrStateOfOrigin
				.equals(other.recordTypeOrStateOfOrigin)) {
			return false;
		}
		if (restrictions == null) {
			if (other.restrictions != null) {
				return false;
			}
		}
		else if (!restrictions.equals(other.restrictions)) {
			return false;
		}
		if (weight == null) {
			if (other.weight != null) {
				return false;
			}
		}
		else if (!weight.equals(other.weight)) {
			return false;
		}
		return true;
	}

	/**
	 * Checks if is approval password required and entered.
	 *
	 * @return the isApprovalPasswordRequiredAndEntered
	 */
	public boolean isApprovalPasswordRequiredAndEntered() {
		return isApprovalPasswordRequiredAndEntered;
	}

	/**
	 * Checks if is approval password required.
	 *
	 * @return true, if is approval password required
	 */
	public boolean isApprovalPasswordRequired() {
		//Approval authority credentials are required when a record is marked SAME and 
		//it is _not_ "Valid", "Expired", "Licensed", "Eligible"
		if (DESIGNATE_SAME.equalsIgnoreCase(getDesignateAction())) {
			String commercialStatusDesc = getCommercialLicenseStatusCode() != null ? getCommercialLicenseStatusCode()
					.getDescription()
					: null;
			String nonCommercialStatusDesc = getNonCommercialLicenseStatusCode() != null ? getNonCommercialLicenseStatusCode()
					.getDescription()
					: null;
			return (!isNullOrBlank(commercialStatusDesc) && !contains(
					commercialStatusDesc, VALID_DRIVING_RECORD_STATUS_DESC))
					|| (!isNullOrBlank(nonCommercialStatusDesc) && !contains(
							nonCommercialStatusDesc,
							VALID_DRIVING_RECORD_STATUS_DESC));
		}
		return false;
	}

	/**
	 * Checks if the CDLIS record is identical to another CDLIS record.
	 *
	 * @param drivingRecord the driving record
	 * @return true, if is identical to
	 */
	public boolean isIdenticalTo(DrivingRecord drivingRecord) {
		boolean isIdentical = false;
		//TODO: Check with Larry what is the criteria to determine if two CDLIS records are identical.
		isIdentical = this.equals(drivingRecord);
		return isIdentical;
	}

	/**
	 * Gets the AKA Names.
	 * 
	 * @return the akaNames
	 */
	public List <AkaInformation> getAkaInformation() {
		return akaInformation;
	}

	/**
	 * Gets the expanded AKA Names. (CDLIS 5.2)
	 * 
	 * @return the akaNames
	 */
	public List <AkaInformation> getExpandedAkaInformationList() {
		return expandedAkaInformationList;
	}

	/**
	 * Gets the aka social security number.
	 * 
	 * @return the aka social security number
	 */
	public String getAkaSocialSecurityNumber() {
		return akaSocialSecurityNumber;
	}

	/**
	 * Gets the Application Id.
	 * 
	 * @return the applicationId
	 */
	public int getApplicationId() {
		return applicationId;
	}

	/**
	 * Gets the cdlis/pdps response code.
	 * 
	 * @return the cdlis/pdps response code
	 */
	public CodeSetElement getCdlisPdpsResponseCode() {
		return cdlisPdpsResponseCode;
	}

	/**
	 * Gets the city.
	 * 
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Gets the Commercial Status code set in SendCdlisAndPdpsConverter (CDU TCODE).
	 * 
	 * @return the commercialStatus
	 */
	public CodeSetElement getCommercialLicenseStatusCode() {
		if (commercialLicenseStatusCode == null) {
			commercialLicenseStatusCode = new CodeSetElement("", "", "");
		}
		return commercialLicenseStatusCode;
	}

	/**
	 * Gets the current birth date.
	 * 
	 * @return the current birth date
	 */
	public Date getCurrentBirthDate() {
		return currentBirthDate;
	}

	/**
	 * Gets the current name.
	 * 
	 * @return the current name
	 */
	public PersonName getCurrentName() {
		return currentName;
	}

	/**
	 * Gets the current primary dl number state.
	 * 
	 * @return the current primary dl number state
	 */
	public CodeSetElement getCurrentPrimaryDlNumberState() {
		return currentPrimaryDlNumberState;
	}

	/**
	 * Gets the current primary ssn.
	 * 
	 * @return the current primary ssn
	 */
	public String getCurrentPrimarySsn() {
		return currentPrimarySsn;
	}

	/**
	 * Gets the Designate Action.
	 * 
	 * @return the designateAction
	 */
	public String getDesignateAction() {
		return designateAction;
	}

	/**
	 * Gets the dl withdrawal pending indicator.
	 * 
	 * @return the dl withdrawal pending indicator
	 */
	public String getDlWithdrawalPendingIndicator() {
		return dlWithdrawalPendingIndicator;
	}

	/**
	 * Gets the driver license class codes.
	 * 
	 * @return the driver license class codes
	 */
	public List <CodeSetElement> getDriverLicenseClassCodes() {
		return driverLicenseClassCodes;
	}

	/**
	 * Gets the Endorsements.
	 * 
	 * @return the endorsements
	 */
	public List <CodeSetElement> getEndorsements() {
		return endorsements;
	}

	/**
	 * Gets the License Expiration Date.
	 * 
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Gets the Eye Color.
	 * 
	 * @return the eyeColorCode
	 */
	public CodeSetElement getEyeColorCode() {
		return eyeColorCode;
	}

	/**
	 * Gets the Gender of Person.
	 * 
	 * @return the genderCode
	 */
	public CodeSetElement getGenderCode() {
		return genderCode;
	}

	/**
	 * Gets the hair color code.
	 *
	 * @return the hairColorCode
	 */
	public CodeSetElement getHairColorCode() {
		return hairColorCode;
	}

	/**
	 * Gets the Height.
	 * 
	 * @return the heightInFeet
	 */
	public Integer getHeightInFeet() {
		return heightInFeet;
	}

	/**
	 * Gets the Height.
	 * 
	 * @return the heightInInch
	 */
	public Integer getHeightInInch() {
		return heightInInch;
	}

	/**
	 * Gets the License Number.
	 * 
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/**
	 * Simple getter for matchSequenceNumberId.
	 * @return matchSequenceNumberId
	 */
	public int getMatchSequenceNumberId() {
		return matchSequenceNumberId;
	}

	/**
	 * Gets the non commercial license status code.
	 *
	 * @return the nonCommercialLicenseStatusCode
	 */
	public CodeSetElement getNonCommercialLicenseStatusCode() {
		if (nonCommercialLicenseStatusCode == null) {
			nonCommercialLicenseStatusCode = new CodeSetElement("", "", "");
		}
		return nonCommercialLicenseStatusCode;
	}

	/**
	 * Gets the Password.
	 * 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Gets the pdps non pdpd state indicator.
	 * Values "P" or "N".
	 * (Corresponding EDL variable: VFSPNPS) 
	 *
	 * @return the pdpsNonPdpdStateIndicator
	 */
	public String getPdpsNonPdpdStateIndicator() {
		String pdpsNonPdpdStateIndicator = TYPE_INDICATOR_NDR;
		//If MUITYPE is "HC" and
		//MUIORGIN_StateOfOrigin is not (XX or ZZ)
		//return "P".
		//Note: For a PDPS record, 
		//the state of origin of a data segment will always be ZZ and
		//that of HC segment will never be ZZ, but will be a "state".
		//The driving record object for PDPS record will not capture the state of origin of the HC segment.
		//So the logic boils down to "P" for PDPS records (state of origin != XX).
		if (!ArrayUtils.contains(getRecordTypeOrStateOfOrigin(),
				STATE_OF_ORIGIN_XX)) {
			pdpsNonPdpdStateIndicator = TYPE_INDICATOR_PDPS;
		}
		return pdpsNonPdpdStateIndicator;
	}

	/**
	 * Gets the record type or state of origin.
	 * 
	 * @return the record type or state of origin
	 */
	public String getRecordTypeOrStateOfOrigin() {
		return recordTypeOrStateOfOrigin;
	}

	/**
	 * Gets the Restrictions.
	 * 
	 * @return the restrictions
	 */
	public List <CodeSetElement> getRestrictions() {
		return restrictions;
	}

	/**
	 * Gets the Weight.
	 * 
	 * @return the weight
	 */
	public Integer getWeight() {
		return weight;
	}

	/**
	 * Gets the Cleared by Issuance Indicator.
	 * 
	 * @return the isClearedByIssuanceIndicator
	 * @deprecated
	 */
	@Deprecated
	public Boolean isClearedByIssuanceIndicator() {
		return isClearedByIssuanceIndicator;
	}

	/**
	 * Gets the Remove Restriction Indicator.
	 * 
	 * @return the isRemoveRestrictionIndicator
	 * @deprecated
	 */
	@Deprecated
	public Boolean isRemoveRestrictionIndicator() {
		return isRemoveRestrictionIndicator;
	}

	/**
	 * Sets the AKA Names.
	 *
	 * @param akaInformation the new aka information
	 */
	public void setAkaInformation(List <AkaInformation> akaInformation) {
		this.akaInformation = akaInformation;
	}

	/**
	 * Sets the expanded AKA Names. (CDLIS 5.2)
	 *
	 * @param akaInformation the new aka information
	 */
	public void setExpandedAkaInformationList(
			List <AkaInformation> expandedAkaInformation) {
		this.expandedAkaInformationList = expandedAkaInformation;
	}

	/**
	 * Sets the aka social security number.
	 * 
	 * @param akaSocialSecurityNumber the new aka social security number
	 */
	public void setAkaSocialSecurityNumber(String akaSocialSecurityNumber) {
		this.akaSocialSecurityNumber = akaSocialSecurityNumber;
	}

	/**
	 * Sets the Application Id.
	 * 
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * Sets the cdlis/pdps response code.
	 * 
	 * @param cdlisPdpsResponseCode the new cdlis/pdps response code
	 */
	public void setCdlisPdpsResponseCode(CodeSetElement cdlisPdpsResponseCode) {
		this.cdlisPdpsResponseCode = cdlisPdpsResponseCode;
	}

	/**
	 * Sets the city.
	 * 
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Sets the Cleared by Issuance Indicator.
	 * 
	 * @param isClearedByIssuanceIndicator the isClearedByIssuanceIndicator to set
	 * @deprecated
	 */
	@Deprecated
	public void setClearedByIssuanceIndicator(
			Boolean isClearedByIssuanceIndicator) {
		this.isClearedByIssuanceIndicator = isClearedByIssuanceIndicator;
	}

	/**
	 * Sets the Commercial Status in the SendCdlisAndPdpsConverter (CDU TCODE).
	 * 
	 * @param commercialStatus the commercialStatus to set
	 */
	public void setCommercialLicenseStatusCode(CodeSetElement commercialStatus) {
		this.commercialLicenseStatusCode = commercialStatus;
	}

	/**
	 * Sets the current birth date.
	 * 
	 * @param currentBirthDate the new current birth date
	 */
	public void setCurrentBirthDate(Date currentBirthDate) {
		this.currentBirthDate = currentBirthDate;
	}

	/**
	 * Sets the current name.
	 * 
	 * @param currentName the new current name
	 */
	public void setCurrentName(PersonName currentName) {
		this.currentName = currentName;
	}

	/**
	 * Sets the expand current name. (CDLIS 5.2)
	 * 
	 * @param currentName the new current name
	 */
	public void setExpandedCurrentName(PersonName expandedCurrentName) {
		this.expandedCurrentName = expandedCurrentName;
	}

	/**
	 * Gets the expanded current name.(CDLIS 5.2)
	 * 
	 * @return the current name
	 */
	public PersonName getExpandedCurrentName() {
		return expandedCurrentName;
	}

	/**
	 * Sets the current primary dl number state.
	 * 
	 * @param currentPrimaryDlNumberState the new current primary dl number state
	 */
	public void setCurrentPrimaryDlNumberState(
			CodeSetElement currentPrimaryDlNumberState) {
		this.currentPrimaryDlNumberState = currentPrimaryDlNumberState;
	}

	/**
	 * Sets the current primary ssn.
	 * 
	 * @param currentPrimarySsn the new current primary ssn
	 */
	public void setCurrentPrimarySsn(String currentPrimarySsn) {
		this.currentPrimarySsn = currentPrimarySsn;
	}

	/**
	 * Sets the Designate Action.
	 * 
	 * @param designateAction the designateAction to set
	 */
	public void setDesignateAction(String designateAction) {
		this.designateAction = designateAction;
	}

	/**
	 * Sets the dl withdrawal pending indicator.
	 * 
	 * @param dlWithdrawalPendingIndicator the new dl withdrawal pending indicator
	 */
	public void setDlWithdrawalPendingIndicator(
			String dlWithdrawalPendingIndicator) {
		this.dlWithdrawalPendingIndicator = dlWithdrawalPendingIndicator;
	}

	/**
	 * Sets the driver license class codes.
	 * 
	 * @param driverLicenseClassCodes the new driver license class codes
	 */
	public void setDriverLicenseClassCodes(
			List <CodeSetElement> driverLicenseClassCodes) {
		this.driverLicenseClassCodes = driverLicenseClassCodes;
	}

	/**
	 * Sets the Endorsements.
	 * 
	 * @param endorsements the endorsements to set
	 */
	public void setEndorsements(List <CodeSetElement> endorsements) {
		this.endorsements = endorsements;
	}

	/**
	 * Sets the License Expiration Date.
	 * 
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * Sets the Eye Color.
	 * 
	 * @param eyeColorCode the eyeColorCode to set
	 */
	public void setEyeColorCode(CodeSetElement eyeColorCode) {
		this.eyeColorCode = eyeColorCode;
	}

	/**
	 * Sets the Gender of Person.
	 * 
	 * @param genderCode the genderCode to set
	 */
	public void setGenderCode(CodeSetElement genderCode) {
		this.genderCode = genderCode;
	}

	/**
	 * Sets the hair color code.
	 *
	 * @param hairColorCode the hairColorCode to set
	 */
	public void setHairColorCode(CodeSetElement hairColorCode) {
		this.hairColorCode = hairColorCode;
	}

	/**
	 * Sets the Height.
	 * 
	 * @param heightInFeet the heightInFeet to set
	 */
	public void setHeightInFeet(Integer heightInFeet) {
		this.heightInFeet = heightInFeet;
	}

	/**
	 * Sets the Height.
	 * 
	 * @param heightInInch the heightInInch to set
	 */
	public void setHeightInInch(Integer heightInInch) {
		this.heightInInch = heightInInch;
	}

	/**
	 * Sets the License Number.
	 * 
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	/**
	 * Simple setter for matchSequenceNumberId.
	 *
	 * @param matchSequenceNumberId the new match sequence number id
	 */
	public void setMatchSequenceNumberId(int matchSequenceNumberId) {
		this.matchSequenceNumberId = matchSequenceNumberId;
	}

	/**
	 * Sets the non commercial license status code.
	 *
	 * @param nonCommercialLicenseStatusCode the nonCommercialLicenseStatusCode to set
	 */
	public void setNonCommercialLicenseStatusCode(
			CodeSetElement nonCommercialLicenseStatusCode) {
		this.nonCommercialLicenseStatusCode = nonCommercialLicenseStatusCode;
	}

	/**
	 * Sets the Password.
	 * 
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Sets the pdps non pdpd state indicator.
	 *
	 * @param pdpsNonPdpdStateIndicator the pdpsNonPdpdStateIndicator to set
	 */
	public void setPdpsNonPdpdStateIndicator(String pdpsNonPdpdStateIndicator) {
		this.pdpsNonPdpdStateIndicator = pdpsNonPdpdStateIndicator;
	}

	/**
	 * Sets the record type or state of origin.
	 * 
	 * @param recordType the new record type or state of origin
	 */
	public void setRecordTypeOrStateOfOrigin(String recordType) {
		this.recordTypeOrStateOfOrigin = recordType;
	}

	/**
	 * Sets the Remove Restriction Indicator.
	 * 
	 * @param isRemoveRestrictionIndicator the isRemoveRestrictionIndicator to set
	 * @deprecated
	 */
	@Deprecated
	public void setRemoveRestrictionIndicator(
			Boolean isRemoveRestrictionIndicator) {
		this.isRemoveRestrictionIndicator = isRemoveRestrictionIndicator;
	}

	/**
	 * Sets the Restrictions.
	 * 
	 * @param restrictions the restrictions to set
	 */
	public void setRestrictions(List <CodeSetElement> restrictions) {
		this.restrictions = restrictions;
	}

	/**
	 * Sets the Weight.
	 * 
	 * @param weight the weight to set
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	/**
	 * Gets the match sequence number id as string.
	 *
	 * @return the match sequence number id as string
	 */
	public String getMatchSequenceNumberIdAsString() {
		try {
			if (matchSequenceNumberId == 0) {
				return "";
			}
			else {
				return (new Integer(matchSequenceNumberId)).toString();
			}
		}
		catch (Exception e) {
			return "";
		}
	}

	/**
	 * Gets the record index.
	 *
	 * @return the record index
	 */
	public int getRecordIndex() {
		return recordIndex;
	}

	/**
	 * Sets the record index.
	 *
	 * @param recordIndex the new record index
	 */
	public void setRecordIndex(int recordIndex) {
		this.recordIndex = recordIndex;
	}

	/**
	 * Checks if is disable.
	 *
	 * @return true, if is disable
	 */
	public boolean isDisable() {
		// Defect # 3634
		if (matchSequenceNumberId == 0) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Sets the display response text1.
	 *
	 * @param displayResponseText1 the displayResponseText1 to set
	 */
	public void setDisplayResponseText1(String displayResponseText1) {
		this.displayResponseText1 = displayResponseText1;
	}

	/**
	 * Gets the display response text1.
	 *
	 * @return the displayResponseText1
	 */
	public String getDisplayResponseText1() {
		return displayResponseText1;
	}

	/**
	 * Sets the display response text2.
	 *
	 * @param displayResponseText2 the displayResponseText2 to set
	 */
	public void setDisplayResponseText2(String displayResponseText2) {
		this.displayResponseText2 = displayResponseText2;
	}

	/**
	 * Gets the display response text2.
	 *
	 * @return the displayResponseText2
	 */
	public String getDisplayResponseText2() {
		return displayResponseText2;
	}

	/**
	 * Sets the cdu or ndr response code.
	 *
	 * @param cduOrNdrResponseCode the cduOrNdrResponseCode to set
	 */
	public void setCduOrNdrResponseCode(CodeSetElement cduOrNdrResponseCode) {
		this.cduOrNdrResponseCode = cduOrNdrResponseCode;
	}

	/**
	 * Gets the cdu or ndr response code.
	 *
	 * @return the cduOrNdrResponseCode
	 */
	public CodeSetElement getCduOrNdrResponseCode() {
		return cduOrNdrResponseCode;
	}

	/**
	 * Sets the match limit indicator.
	 *
	 * @param matchLimitIndicator the matchLimitIndicator to set
	 */
	public void setMatchLimitIndicator(String matchLimitIndicator) {
		this.matchLimitIndicator = matchLimitIndicator;
	}

	/**
	 * Gets the match limit indicator.
	 *
	 * @return the matchLimitIndicator
	 */
	public String getMatchLimitIndicator() {
		return matchLimitIndicator;
	}

	/**
	 * Sets the cdl designate field.
	 *
	 * @param cdlDesignateField the cdlDesignateField to set
	 */
	public void setCdlDesignateField(String cdlDesignateField) {
		this.cdlDesignateField = cdlDesignateField;
	}

	/**
	 * Gets the cdl designate field.
	 *
	 * @return the cdlDesignateField
	 */
	public String getCdlDesignateField() {
		return cdlDesignateField;
	}

	/**
	 * Gets the cdl ndr hit record status.
	 *
	 * @return the cdlNdrHitRecordStatus
	 */
	public CodeSetElement getCdlNdrHitRecordStatus() {
		return cdlNdrHitRecordStatus;
	}

	/**
	 * Sets the aka first dl number state.
	 *
	 * @param akaFirstDlNumberState the akaFirstDlNumberState to set
	 */
	public void setAkaFirstDlNumberState(String akaFirstDlNumberState) {
		this.akaFirstDlNumberState = akaFirstDlNumberState;
	}

	/**
	 * Gets the aka first dl number state.
	 *
	 * @return the akaFirstDlNumberState
	 */
	public String getAkaFirstDlNumberState() {
		return akaFirstDlNumberState;
	}

	/**
	 * Sets the aka first dl number.
	 *
	 * @param akaFirstDlNumber the akaFirstDlNumber to set
	 */
	public void setAkaFirstDlNumber(String akaFirstDlNumber) {
		this.akaFirstDlNumber = akaFirstDlNumber;
	}

	/**
	 * Sets the approval password required and entered.
	 *
	 * @param isApprovalPasswordRequiredAndEntered the isApprovalPasswordRequiredAndEntered to set
	 */
	public void setApprovalPasswordRequiredAndEntered(
			boolean isApprovalPasswordRequiredAndEntered) {
		this.isApprovalPasswordRequiredAndEntered = isApprovalPasswordRequiredAndEntered;
	}

	/**
	 * Gets the aka first dl number.
	 *
	 * @return the akaFirstDlNumber
	 */
	public String getAkaFirstDlNumber() {
		return akaFirstDlNumber;
	}

	/**
	 * Sets the cdlis record tried.
	 *
	 * @param isCdlisRecordTried the isCdlisRecordTried to set
	 */
	public void setCdlisRecordTried(boolean isCdlisRecordTried) {
		this.isCdlisRecordTried = isCdlisRecordTried;
	}

	/**
	 * Sets the cdl ndr hit record status.
	 *
	 * @param cdlNdrHitRecordStatus the cdlNdrHitRecordStatus to set
	 */
	public void setCdlNdrHitRecordStatus(CodeSetElement cdlNdrHitRecordStatus) {
		this.cdlNdrHitRecordStatus = cdlNdrHitRecordStatus;
	}

	/**
	 * Checks if is cdlis record tried.
	 *
	 * @return the isCdlisRecordTried
	 */
	public boolean isCdlisRecordTried() {
		return isCdlisRecordTried;
	}

	/**
	 * Sets the commercial license status.
	 *
	 * @param commercialLicenseStatus the commercialLicenseStatus to set
	 */
	public void setCommercialLicenseStatus(String commercialLicenseStatus) {
		this.commercialLicenseStatus = commercialLicenseStatus;
	}

	/**
	 * Gets the commercial license status.
	 *
	 * @return the commercialLicenseStatus
	 */
	public String getCommercialLicenseStatus() {
		return commercialLicenseStatus;
	}

	/**
	 * Sets the non commercial license status.
	 *
	 * @param nonCommercialLicenseStatus the nonCommercialLicenseStatus to set
	 */
	public void setNonCommercialLicenseStatus(String nonCommercialLicenseStatus) {
		this.nonCommercialLicenseStatus = nonCommercialLicenseStatus;
	}

	/**
	 * Gets the non commercial license status.
	 *
	 * @return the nonCommercialLicenseStatus
	 */
	public String getNonCommercialLicenseStatus() {
		return nonCommercialLicenseStatus;
	}

	/**
	 * Checks if is designate questionable.
	 *
	 * @return true, if is designate questionable
	 */
	public boolean isDesignateQuestionable() {
		return DESIGNATE_QUESTIONABLE.equalsIgnoreCase(getDesignateAction());
	}

	/**
	 * Checks if is designate same.
	 *
	 * @return true, if is designate same
	 */
	public boolean isDesignateSame() {
		return DESIGNATE_SAME.equalsIgnoreCase(getDesignateAction());
	}

	/**
	 * Sets the match count - used for CDLIS
	 *
	 * @param matchCount the match count to set
	 */
	public void setMatchCount(int matchCount) {
		this.matchCount = matchCount;
	}

	/**
	 * Gets the match count - used for CDLIS
	 *
	 * @return the matchCount
	 */
	public int getMatchCount() {
		return matchCount;
	}

	/**
	 * CDLIS 5.2 Sets the isAC_GapCodeEnabled flag
	 *
	 * @param isAC_GapCodeEnabled the isAC_GapCodeEnabled to set
	 */
	public void setAcGapCodeEnabled(boolean isAcGapCodeEnabled) {
		this.isAcGapCodeEnabled = isAcGapCodeEnabled;
	}

	/**
	 * CDLIS 5.2 Checks if is AC Gap code in use.
	 *
	 * @return true, if AC Gap code in use
	 */
	public boolean isAcGapCodeEnabled() {
		return isAcGapCodeEnabled;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("MatchSequenceNumberId", matchSequenceNumberId,
				anIndent, aBuilder);
		outputKeyValue("Type of record", (applicationId == 12 ? "PDPS"
				: "CDLIS"), anIndent, aBuilder);
		outputKeyValue("Name", (currentName == null ? currentName : currentName
				.getFullNameWithSuffix()), anIndent, aBuilder);
		outputKeyValue("ExpandedName",
				(expandedCurrentName == null ? expandedCurrentName
						: expandedCurrentName.getFullNameWithSuffix()),
				anIndent, aBuilder);
		outputKeyValue(
				"State",
				(currentPrimaryDlNumberState == null ? currentPrimaryDlNumberState
						: currentPrimaryDlNumberState.getCode()), anIndent,
				aBuilder);
		outputKeyValue("LicenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue(
				"CommercialLicenseStatus",
				(commercialLicenseStatusCode == null ? commercialLicenseStatusCode
						: commercialLicenseStatusCode.getDescription()),
				anIndent, aBuilder);
		outputKeyValue(
				"NonCommercialLicenseStatus",
				(nonCommercialLicenseStatusCode == null ? nonCommercialLicenseStatusCode
						: nonCommercialLicenseStatusCode.getDescription()),
				anIndent, aBuilder);
		outputKeyValue("DesignateAction", designateAction, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DrivingRecord.java,v $
 *  Revision 1.34  2013/10/03 15:14:57  mwskh1
 *  CDLIS 5.2 - Code review changes
 *
 *  Revision 1.33  2013/10/03 15:11:39  mwskh1
 *  CDLIS 5.2 - Code review changes
 *
 *  Revision 1.32  2013/10/01 20:56:30  mwskh1
 *  CDLIS 5.2 - added flag to check if AC gap code in use
 *
 *  Revision 1.31  2013/07/01 18:42:59  mwskh1
 *  CDLIS 5.2 - added setMatchCount for expanded name match
 *
 *  Revision 1.30  2013/05/29 16:49:46  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *  Revision 1.29.2.3  2013/03/11 22:00:05  mwskh1
 *  fixed copyExpandedAkaInformation
 *
 *  Revision 1.29.2.2  2013/03/11 21:45:57  mwskh1
 *  fixed expanded name copy.
 *
 *  Revision 1.29.2.1  2013/03/06 16:15:06  mwskh1
 *  CDLIS 5.2 - added expanded name and aka names
 *
 *  Revision 1.29  2013/02/21 02:45:46  mwhys
 *  Added a field isApprovalPasswordRequiredAndEntered and isApprovalPasswordRequired() method. (Defect 8586)
 *
 *  Revision 1.28  2012/12/17 22:40:21  mwhys
 *  Added toStringOn().
 *
 *  Revision 1.27  2012/02/09 01:40:58  mwhys
 *  Added a field cdlNdrHitRecordStatus. (Defect 7201)
 *
 *  Revision 1.26  2011/07/23 19:36:20  mwhys
 *  Added methods to check for designate field.
 *
 *  Revision 1.25  2011/06/10 23:13:34  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.24  2011/06/10 19:07:07  mwhys
 *  Fixed defect 6236. Added a field pdpsNonPdpdStateIndicator and logic to the getter method.
 *
 *  Revision 1.23  2011/05/13 22:24:34  mwhys
 *  Fixed defect TRN 698. Added copy constructor.
 *
 *  Revision 1.22  2011/03/21 22:07:30  mwhys
 *  Added copy constructor.
 *
 *  Revision 1.21  2011/03/18 04:09:49  mwhys
 *  Temporarily added 2 fields.
 *
 *  Revision 1.20  2011/03/18 04:04:33  mwhys
 *  Added isCdlisRecordTried field;
 *
 *  Revision 1.19  2011/03/12 21:52:54  mwhys
 *  Added 3 new fields.
 *
 *  Revision 1.18  2011/03/04 01:28:27  mwhys
 *  Added a field matchLimitIndicator, which will be used in the hidden logic to set the IARC.
 *
 *  Revision 1.17  2011/01/29 19:59:04  mwhys
 *  Added a field for cduOrNdrResponseCode.
 *
 *  Revision 1.16  2011/01/26 19:02:02  mwrrv3
 *  Added 2 new attributes for response codes for CDSLI and PDPS records.
 *
 *  Revision 1.15  2011/01/24 23:58:56  mwhys
 *  Updated javadoc for 2 fields.
 *
 *  Revision 1.14  2011/01/18 22:30:03  mwrrv3
 *  Added a method to validate the Designate Field in Cdlispdpsinquiry response page -- Amar Bade
 *
 *  Revision 1.13  2011/01/15 19:36:25  mwgxk2
 *  RecordIndex attribute added.
 *
 *  Revision 1.12  2011/01/08 01:28:21  mwrrv3
 *  Added new method getMatchSequenceNumberIdAsString.
 *
 *  Revision 1.11  2010/12/13 00:13:59  mwhys
 *  Added isIdenticalTo() method.
 *
 *  Revision 1.10  2010/11/22 23:36:53  mwpxr4
 *  Added license status string to cdlis(driving)record
 *
 *  Revision 1.9  2010/11/11 22:45:39  mwhys
 *  Updated equals and hashCode methods.
 *
 *  Revision 1.8  2010/11/11 19:25:39  mwkfh
 *  added cdlisPdpsResponseCode
 *
 *  Revision 1.7  2010/10/08 20:52:16  mwrrv3
 *  Changed the data type to String for designateAction.
 *
 *  Revision 1.6  2010/07/22 17:34:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/05/27 14:37:54  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.4  2010/05/16 20:56:20  mwuxb
 *  Removed attribute statusMessages
 *
 *  Revision 1.3  2010/04/19 16:35:15  mwvkm
 *  Added Java Docs
 *
 *  Revision 1.2  2010/04/15 23:41:05  mwvkm
 *  Renamed the field recordType to recordTypeOrStateOfOrigin to be more meaningful with the description and usage.
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.19  2010/04/10 22:49:54  mwsxd10
 *  HairColorcode added.
 *
 *  Revision 1.18  2010/04/07 17:12:47  mwvkm
 *  Removed all the deprecated methods except the clearance indicator and removal indicator.
 *
 *  Revision 1.17  2010/03/28 21:40:02  mwsxd10
 *  City property added.
 *
 *  Revision 1.16  2010/03/25 23:25:23  mwuxb
 *  Added attribute statusMessages
 *
 *  Revision 1.15  2010/03/25 19:11:03  mwvkm
 *  Modified the code for CDU as per the match logic document that the development had received.
 *
 *  Revision 1.14  2010/03/18 01:41:25  mwvxm6
 *  Replaced PerconName with  AkaInformation class which is a container for AKA response fields
 *
 *  Revision 1.13  2010/03/17 21:25:32  mwvxm6
 *  Updated type of stateOfOrigin to CodeSetElement
 *
 *  Revision 1.12  2010/03/09 18:25:59  mwvxm6
 *  Removed String akaName; Use List <PersonName> akaNames;
 *  Replaced with new names:
 *  licenseClasses -> commercialLicenseClassCodes
 *  String commercialStatus -> commercialLicenseStatusCode
 *
 *  Revision 1.11  2010/03/03 01:56:20  mwvxm6
 *  Updated the setter for genderCode
 *
 *  Revision 1.10  2010/03/02 22:28:40  mwuxb
 *  Updated attribute name from sexCode to genderCode
 *
 *  Revision 1.9  2010/02/23 00:57:03  mwuxb
 *  removed cdlisPdpsInquiryStatus attribute
 *
 *  Revision 1.8  2010/02/04 17:03:06  mwrsk
 *  Optimize imports
 *
 *  Revision 1.7  2010/02/04 01:03:45  mwrsk
 *  Delete CdlisPdpsRecord.java and use CdlisRecord.java & PdpsRecord.java
 *
 *  Revision 1.6  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.5  2010/01/28 17:47:24  mwhxa2
 *  Added weight
 *
 *  Revision 1.4  2010/01/27 17:15:32  mwhxa2
 *  Added issuedByState
 *
 *  Revision 1.3  2010/01/27 01:44:20  mwhxa2
 *  Added licenseClasses
 *
 *  Revision 1.2  2010/01/22 00:47:59  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.1  2009/11/23 16:25:15  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/12 23:42:20  mwtjc1
 *  CdlisPdpsRecord had all the properties and methods of DrivingRecord. To resolve CPD issue, common properties and methods are removed from CdlisPdpsRecord and now CdlisPdpsRecord extends DrivingRecord.
 *
 *  Revision 1.3  2009/08/27 05:39:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/06 23:51:39  mwcsj3
 *  Added attributes
 *
 *  Revision 1.1  2009/07/29 17:53:29  mwbxp5
 *  Corrected the package name from gov.cd.dmv.ease.bo.dl.record.impl to gov.ca.dmv.ease.bo.dl.record.impl
 *
 *  Revision 1.2  2009/07/14 23:44:29  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 15:43:44  ppalacz
 *  Moved into gov.cd.dmv.ease.bo.dl.record.impl
 *
 *  Revision 1.1  2009-07-12 08:12:00  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 */
