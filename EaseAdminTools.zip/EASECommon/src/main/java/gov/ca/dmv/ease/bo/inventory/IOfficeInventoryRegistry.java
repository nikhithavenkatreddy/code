/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory;

import gov.ca.dmv.ease.bo.IBusinessObject;

import java.util.List;

/**
 * Description: I am interface for an object registering all inventories (office and station) for a given office.
 * File: IOfficeInventoryRegistry.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Sep 1, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/01 20:42:48 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeInventoryRegistry extends IBusinessObject {
	/**
	 * Adds the.
	 * 
	 * @param anOfficeInventory the an office inventory
	 */
	void add(IOfficeInventory anOfficeInventory);

	/**
	 * Adds the.
	 * 
	 * @param aStationInventory the a station inventory
	 */
	void add(IStationInventory aStationInventory);

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();

	/**
	 * Gets the office inventories.
	 * 
	 * @return the office inventories
	 */
	List <IOfficeInventory> getOfficeInventories();

	/**
	 * Gets the station inventories.
	 * 
	 * @return the station inventories
	 */
	List <IStationInventory> getStationInventories();
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeInventoryRegistry.java,v $
 *  Revision 1.2  2010/09/01 20:42:48  mwpxp2
 *  Extended from IBusinessObject
 *
 *  Revision 1.1  2010/09/01 20:40:57  mwpxp2
 *  Initial
 *
 */
