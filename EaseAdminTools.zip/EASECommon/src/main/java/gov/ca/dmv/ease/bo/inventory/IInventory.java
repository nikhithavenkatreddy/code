/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;

import java.util.List;

/**
 * Description: I am interface for manipulating a collection of inventory items of various types
 * 
 * File: IInventory.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2010/10/14 05:38:11 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IInventory extends IBusinessObject {
	/**
	 * Adds the.
	 * 
	 * @param aSingleTypeInventory the a single type inventory
	 */
	int add(ISingleTypeInventory aSingleTypeInventory);

	/**
	 * Adds the all.
	 * 
	 * @param aList the a list
	 * 
	 * @return the int
	 */
	int addAll(List <ISingleTypeInventory> aList);

	/**
	 * Gets the item types present.
	 * 
	 * @return the item types present
	 */
	List <IItemType> getItemTypesPresent();

	/**
	 * Gets the registry id.
	 * 
	 * @return the registry id
	 */
	Long getRegistryId();

	/**
	 * Checks if is strictly local.
	 * 
	 * @return true, if is strictly local
	 */
	boolean isStrictlyLocal();

	/**
	 * Use next item of type.
	 * 
	 * @param aType the a type
	 * 
	 * @return the i item
	 */
	IInventoryItem issueNextItemOfType(IItemType aType);

	/**
	 * Sets the registry id.
	 * 
	 * @param anId the new registry id
	 */
	void setRegistryId(Long anId);
}
/**
 *  Modification History:
 *
 *  $Log: IInventory.java,v $
 *  Revision 1.9  2010/10/14 05:38:11  mwpxp2
 *  Removed returnItem/0
 *
 *  Revision 1.8  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.7  2010/09/01 21:19:29  mwpxp2
 *  Added support for parent registry id
 *
 *  Revision 1.6  2010/09/01 20:41:43  mwpxp2
 *  Extended from IBusinessObject
 *
 *  Revision 1.5  2010/08/31 03:45:33  mwpxp2
 *  Added add/1 and addAll/1 methods
 *
 *  Revision 1.4  2010/08/31 01:10:54  mwpxp2
 *  Extended Serializable
 *
 *  Revision 1.3  2010/08/30 23:24:59  mwpxp2
 *  Added isStrictlyLocal/0
 *
 *  Revision 1.2  2010/08/30 23:20:24  mwpxp2
 *  Renamed use~ to issue~
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
