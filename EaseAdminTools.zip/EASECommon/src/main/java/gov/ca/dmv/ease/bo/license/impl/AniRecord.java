/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.subject.impl.PersonName;

import java.util.Date;

/**
 * Description: This represents the ANI result record to encapsulate the Person
 * and action code.
 * File: AniRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Aug 6, 2009
 * 
 * @author MWRRV3
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2010/12/07 22:08:55 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AniRecord extends AbstractDlRecord {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7209103980933092604L;
	/** The First 3 Chars of the address. */
	private String addressFirst3Chars;
	/** The person date of birth. */
	private Date birthDate;
	/** The city name. */
	private String cityName;
	/** The license Number. */
	private String driverLicenseNumber;
	/** The eli record. */
	private EliRecord eliRecord;
	/** The person name. */
	private PersonName personName;
	/** The record index */
	private int recordIndex;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AniRecord other = (AniRecord) obj;
		if (addressFirst3Chars == null) {
			if (other.addressFirst3Chars != null) {
				return false;
			}
		}
		else if (!addressFirst3Chars.equals(other.addressFirst3Chars)) {
			return false;
		}
		if (birthDate == null) {
			if (other.birthDate != null) {
				return false;
			}
		}
		else if (!birthDate.equals(other.birthDate)) {
			return false;
		}
		if (cityName == null) {
			if (other.cityName != null) {
				return false;
			}
		}
		else if (!cityName.equals(other.cityName)) {
			return false;
		}
		if (driverLicenseNumber == null) {
			if (other.driverLicenseNumber != null) {
				return false;
			}
		}
		else if (!driverLicenseNumber.equals(other.driverLicenseNumber)) {
			return false;
		}
		if (personName == null) {
			if (other.personName != null) {
				return false;
			}
		}
		else if (!personName.equals(other.personName)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the addressFirst3Chars
	 */
	public String getAddressFirst3Chars() {
		return addressFirst3Chars;
	}

	/**
	 * Gets the birth date.
	 * 
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Gets the city name.
	 * 
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * Gets the driver license number.
	 * 
	 * @return the driverLicenseNumber
	 */
	public String getDriverLicenseNumber() {
		return driverLicenseNumber;
	}

	/**
	 * Gets the eli record.
	 * 
	 * @return the eli record
	 */
	public EliRecord getEliRecord() {
		return eliRecord;
	}

	/**
	 * Gets the person name.
	 * 
	 * @return the personName
	 */
	public PersonName getPersonName() {
		return personName;
	}

	/**
	 * @return the recordIndex
	 */
	public int getRecordIndex() {
		return recordIndex;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((addressFirst3Chars == null) ? 0 : addressFirst3Chars
						.hashCode());
		result = prime * result
				+ ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime * result
				+ ((cityName == null) ? 0 : cityName.hashCode());
		result = prime
				* result
				+ ((driverLicenseNumber == null) ? 0 : driverLicenseNumber
						.hashCode());
		result = prime * result
				+ ((personName == null) ? 0 : personName.hashCode());
		return result;
	}

	/**
	 * @param addressFirst3Chars the addressFirst3Chars to set
	 */
	public void setAddressFirst3Chars(String addressFirst3Chars) {
		this.addressFirst3Chars = addressFirst3Chars;
	}

	/**
	 * Sets the birth date.
	 * 
	 * @param birthDate the birth date to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Sets the city name.
	 * 
	 * @param cityName the city name to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * Sets the driver license number.
	 * 
	 * @param driverLicenseNumber the driver license number to set
	 */
	public void setDriverLicenseNumber(String driverLicenseNumber) {
		this.driverLicenseNumber = driverLicenseNumber;
	}

	/**
	 * Sets the eli record.
	 * 
	 * @param eliRecord the new eli record
	 */
	public void setEliRecord(EliRecord eliRecord) {
		this.eliRecord = eliRecord;
	}

	/**
	 * Sets the person name.
	 * 
	 * @param personName the person name to set
	 */
	public void setPersonName(PersonName personName) {
		this.personName = personName;
	}

	/**
	 * @param recordIndex the recordIndex to set
	 */
	public void setRecordIndex(int recordIndex) {
		this.recordIndex = recordIndex;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("addressFirst3Chars", addressFirst3Chars, anIndent,
				aBuilder);
		outputKeyValue("birthDate", birthDate, anIndent, aBuilder);
		outputKeyValue("cityName", cityName, anIndent, aBuilder);
		outputKeyValue("driverLicenseNumber", driverLicenseNumber, anIndent,
				aBuilder);
		outputKeyValue("eliRecord", eliRecord, anIndent, aBuilder);
		outputKeyValue("personName", personName, anIndent, aBuilder);
		outputKeyValue("recordIndex", recordIndex, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AniRecord.java,v $
 *  Revision 1.10  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.9  2010/12/07 03:54:58  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.8  2010/11/08 18:52:04  mwrrv3
 *  Added "recordIndex" variable -- Amar
 *
 *  Revision 1.7  2010/11/04 22:16:00  mwtjc1
 *  eliRecord added
 *
 *  Revision 1.6  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.4.2.2  2010/06/20 18:07:13  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.5  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/27 14:37:54  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.3  2010/04/29 17:08:25  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.2  2010/04/21 00:54:57  mwuxb
 *  Added AbstractDlRecord
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.11  2010/03/19 01:38:26  mwrsk
 *  cleanup imports and add comments
 *
 *  Revision 1.10  2010/03/19 01:19:49  mwvxm6
 *  Updated AniRecord to use only required attributes instead of Person
 *
 *  Revision 1.9  2010/03/19 01:14:19  mwvxm6
 *  Updated AniRecord to use only required attributes instead of Person
 *
 *  Revision 1.8  2010/03/18 22:18:45  mwhxb3
 *  Removed InquiredPerson.
 *
 *  Revision 1.7  2010/03/18 21:58:48  mwvxm6
 *  Remove license number and added city name
 *
 *  Revision 1.6  2010/03/15 17:06:00  mwhxa2
 *  Added Serialization
 *
 *  Revision 1.5  2010/03/10 00:49:36  mwuxb
 *  Added attribute License Number
 *
 *  Revision 1.4  2010/03/03 16:07:53  mwrsk
 *  cleanup imports
 *
 *  Revision 1.3  2010/02/09 20:37:59  mwrsk
 *  Pull up person to DLRecord
 *
 *  Revision 1.2  2010/01/28 22:21:40  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/08/27 05:39:52  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/12 00:36:14  mwrrv3
 *  Refactored the code.
 *
 *  Revision 1.1  2009/08/06 19:08:09  mwrrv3
 *  New class for ANI results.
 *
*/
