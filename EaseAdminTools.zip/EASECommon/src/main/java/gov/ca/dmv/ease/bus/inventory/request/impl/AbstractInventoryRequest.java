/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bus.inventory.service.ILocalInventoryService;
import gov.ca.dmv.ease.bus.inventory.service.impl.LocalInventoryService;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: I am abstract superclass for dl inventory service requests
 * My concrete subclasses are effectively Commands - they can be execute()d with no need to specify target service.
 * 
 * File: AbstractInventoryRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/10/25 23:49:14 $
 * Last Changed By: $Author: mwhys $
 */
public abstract class AbstractInventoryRequest extends AbstractRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4708902047707897523L;
	
	/**
	 * Instantiates a new abstract inventory request.
	 */
	public AbstractInventoryRequest() {
		super();
	}
	
	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	public AbstractInventoryRequest(IUserContext context) {
		super(context);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.IInventoryRequest#getItemCount()
	 */
	public abstract int getItemCount();
	
	/**
	 * Gets the service.
	 * 
	 * @return the service
	 */
	protected ILocalInventoryService getService() {
		return LocalInventoryService.getInstance();
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractInventoryRequest.java,v $
 *  Revision 1.3  2011/10/25 23:49:14  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.2  2010/09/20 23:18:39  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.8  2010/09/14 23:55:46  mwpxp2
 *  Extended IInventoryRequest
 *
 *  Revision 1.7  2010/09/14 18:59:10  mwpxp2
 *  Added getService/0
 *
 *  Revision 1.6  2010/09/13 04:42:10  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/09/02 20:44:54  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.4  2010/09/01 00:40:27  mwpxp2
 *  Implemented getInventoryServiceInstance/0
 *
 *  Revision 1.3  2010/09/01 00:35:48  mwpxp2
 *  Added abstract execute/0
 *
 *  Revision 1.2  2010/08/31 23:44:54  mwpxp2
 *  Made abstract
 *
 *  Revision 1.1  2010/08/31 23:26:26  mwpxp2
 *  Initial
 *
 */
