/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.app.constants.IGeneralTestConstants;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.dl.exams.impl.KnowledgeExam;
import gov.ca.dmv.ease.bo.license.InterimPermitType;
import gov.ca.dmv.ease.bo.license.testresult.DriveAndLawTestResultType;
import gov.ca.dmv.ease.bo.license.testresult.impl.CommercialTestResultGroup;
import gov.ca.dmv.ease.bo.license.testresult.impl.DriveAndLawTestResult;
import gov.ca.dmv.ease.bo.license.testresult.impl.DriveAndLawTestResultGroup;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * Description: This represents the driver license information.
 * File: DriverLicense.java
 * Module: gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 28, 2009
 * 
 * @author MWCSJ3
 * @version $Revision: 1.46.6.2 $
 * Last Changed: $Date: 2014/06/03 18:08:55 $
 * Last Changed By: $Author: mwgxd3 $
 */
public class DriverLicense extends License {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7739247173645720919L;
	/** The applied License Classes for a Driver License. */
	private List <CodeSetElement> appliedLicenseClasses;
	/** The previous pending applied license classes. */
	private List <CodeSetElement> previousPendingAppliedLicenseClasses;
	/** Background Record Check Expiration Date - Returned from the Back End. */
	private Date backgroundCheckExpirationDate;
	/** Background Record Check Indicator. Returned from the Back End. */
	private CodeSetElement backgroundCheckIndicator;
	/** The certificates. */
	private List <CodeSetElement> certificates;
	/** The Commercial Test Result Group - Test Screen 2 Results Information. */
	private CommercialTestResultGroup commercialTestResultGroup;
	/** The Drive and Law Test Result Group - Test Screen 1 Results Information. */
	private DriveAndLawTestResultGroup driveAndLawTestResultGroup;
	/** The Commercial Test Result Group - as present in DL database. */
	private CommercialTestResultGroup commercialTestResultGroupOnRecord;
	/** The Drive and Law Test Result Group - as present in DL database. */
	private DriveAndLawTestResultGroup driveAndLawTestResultGroupOnRecord;
	/** The existing attachments for a Driver License. */
	private List <CodeSetElement> existingAttachments;
	/** The existing Categories for a Driver License. */
	private List <CodeSetElement> existingCategories;
	/** The existing Endorsements for a Driver License. */
	private List <CodeSetElement> existingEndorsements;
	/** The existing interim permits. */
	private List <InterimPermit> existingInterimPermits;
	/** The existing License Classes for a Driver License. */
	/** Also called Class of record */
	private List <CodeSetElement> existingLicenseClasses;
	/** The previous existing License Classes for a Driver License. */
	/** Also called Previous Class of record */
	private List <CodeSetElement> previousExistingLicenseClasses;
	/** The DL/ID expiration date. */
	/** This is tied to previousExistingLicenseClasses. */
	private Date previousExistingExpirationDate;
	/** The existing minor guaranteer code. */
	private CodeSetElement existingMinorGuarantorCode;
	/** The existing restrictions for a Driver License. */
	private List <DrivingRestriction> existingRestrictions;
	/** The Foreign Language Code. */
	private CodeSetElement foreignLanguageCode;
	/** The Interim Issue Date. This holds the date on which application is complete and interim license is issued. */
	private Date interimIssueDate;
	/** The interim permits. */
	private List <InterimPermit> interimPermits;
	/** The Indicator for Oral Test. */
	private Boolean isOralTest;
	/** The Indicator for Regular Term. */
	private Boolean isRegularTerm;
	/** The Issuance Other date. */
	private Date issuanceOtherDate;
	/** License Extension Code. */
	private CodeSetElement licenseExtensionCode;
	/** The Limited Term Years for License. # LT OF YR. */
	private Integer limitedLicenseTermYears;
	/** The new attachments for a Driver License. */
	private List <CodeSetElement> newAttachments;
	/** The new Categories for a Driver License. */
	private List <CodeSetElement> newCategories;
	/** The new Endorsements for a Driver License. */
	private List <CodeSetElement> newEndorsements;
	/** The new restrictions for a Driver License. */
	private List <DrivingRestriction> newRestrictions;
	/** The pending app categories. */
	private List <CodeSetElement> pendingAppCategories;
	/** This represents the previous Application Date. */
	private Date perviousAppDate;
	/** The Renewal Term Years for License - Represents eligible number of years left to renew license. */
	private Integer renewalLicenseTermYears;
	/** The IID Indicator. */
	private String iidIndicator;
	/** The AB60 indicator. */
	private boolean isAppliedLpUnverified = false;
	/** The AB60 indicator for previous class. */
	private boolean isExistingLpUnverified;
	/** The AB60 indicator for pending class. */
	private boolean isPendingLpUnverified;
	
	/**
	 * Default Constructor.
	 */
	public DriverLicense() {
		//FIXME
		super();
	}
	
	/**
	 * Instantiates a new DriverLicense data - copy constructor.
	 * 
	 * @param dataToCopy the data to copy
	 */
	public DriverLicense(DriverLicense dataToCopy) {
		super();
		copy(dataToCopy);
	}
	
	/**
	 * Adds the applied license class.
	 * 
	 * @param appliedLienceClass the applied lience class
	 */
	public void addAppliedLicenseClass(CodeSetElement appliedLienceClass) {
		if (!EaseUtil.isNotNull(appliedLicenseClasses)) {
			appliedLicenseClasses = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(appliedLienceClass, appliedLicenseClasses);
	}
	
	/**
	 * Adds the previous pending applied license class.
	 * 
	 * @param previousPendingAppliedLicenseClass the previous pending applied license class
	 */
	public void addPreviousPendingAppliedLicenseClass(
			CodeSetElement previousPendingAppliedLicenseClass) {
		if (!EaseUtil.isNotNull(previousPendingAppliedLicenseClasses)) {
			previousPendingAppliedLicenseClasses = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(previousPendingAppliedLicenseClass,
				previousPendingAppliedLicenseClasses);
	}
	
	/**
	 * Adds the certificate.
	 * 
	 * @param aCode the a code
	 */
	public void addCertificate(CodeSetElement aCode) {
		if (!EaseUtil.isNotNull(certificates)) {
			certificates = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(aCode, certificates);
	}
	
	/**
	 * Adds the existing attachment.
	 * 
	 * @param aCode the a code
	 */
	public void addExistingAttachment(CodeSetElement aCode) {
		if (!EaseUtil.isNotNull(existingAttachments)) {
			existingAttachments = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(aCode, existingAttachments);
	}
	
	/**
	 * Adds the existing category.
	 * 
	 * @param existingCategory the existing category
	 */
	public void addExistingCategory(CodeSetElement existingCategory) {
		if (!EaseUtil.isNotNull(existingCategories)) {
			existingCategories = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(existingCategory, existingCategories);
	}
	
	/**
	 * Adds the existing endorsement.
	 * 
	 * @param aCode the a code
	 */
	public void addExistingEndorsement(CodeSetElement aCode) {
		if (!EaseUtil.isNotNull(existingEndorsements)) {
			existingEndorsements = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(aCode, existingEndorsements);
	}
	
	/**
	 * Adds the existing license class.
	 * 
	 * @param existingLicenseClass the existing license class
	 */
	public void addExistingLicenseClass(CodeSetElement existingLicenseClass) {
		if (!EaseUtil.isNotNull(existingLicenseClasses)) {
			existingLicenseClasses = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(existingLicenseClass,
				existingLicenseClasses);
	}
	
	/**
	 * Adds the existing restriction.
	 * 
	 * @param drivingRestriction the driving restriction
	 */
	public void addExistingRestriction(DrivingRestriction drivingRestriction) {
		if (!EaseUtil.isNotNull(existingRestrictions)) {
			existingRestrictions = new ArrayList <DrivingRestriction>();
		}
		addRestriction(drivingRestriction, existingRestrictions);
	}
	
	/**
	 * Adds the interim permit.
	 * 
	 * @param interimPermit the interim permit
	 */
	public void addInterimPermit(InterimPermit interimPermit) {
		if (!EaseUtil.isNotNull(interimPermits)) {
			interimPermits = new ArrayList <InterimPermit>();
		}
		interimPermits.add(interimPermit);
	}
	
	/**
	 * Adds the new attachment.
	 * 
	 * @param aCode the a code
	 */
	public void addNewAttachment(CodeSetElement aCode) {
		if (!EaseUtil.isNotNull(newAttachments)) {
			newAttachments = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(aCode, newAttachments);
	}
	
	/**
	 * Adds the new category.
	 * 
	 * @param newCategory the new category
	 */
	public void addNewCategory(CodeSetElement newCategory) {
		if (!EaseUtil.isNotNull(newCategories)) {
			newCategories = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(newCategory, newCategories);
	}
	
	/**
	 * Adds the new endorsement.
	 * 
	 * @param aCode the a code
	 */
	public void addNewEndorsement(CodeSetElement aCode) {
		if (!EaseUtil.isNotNull(newEndorsements)) {
			newEndorsements = new ArrayList <CodeSetElement>();
		}
		addNotExistingElementInList(aCode, newEndorsements);
	}
	
	/**
	 * Adds the new restriction.
	 * 
	 * @param drivingRestriction the driving restriction
	 */
	public void addNewRestriction(DrivingRestriction drivingRestriction) {
		if (!EaseUtil.isNotNull(this.newRestrictions)) {
			this.newRestrictions = new ArrayList <DrivingRestriction>();
		}
		addRestriction(drivingRestriction, newRestrictions);
	}
	
	/**
	 * Adds the not existing element in list.
	 * 
	 * @param aCode the a code
	 * @param codeSetElements the code set elements
	 */
	private void addNotExistingElementInList(CodeSetElement aCode,
			List <CodeSetElement> codeSetElements) {
		if (aCode != null && !StringUtils.isBlank(aCode.getCode())) {
			boolean aCodeAlreadyExists = false;
			for (CodeSetElement codeSetElement : codeSetElements) {
				if (codeSetElement.getCode().trim().equals(
						aCode.getCode().trim())) {
					aCodeAlreadyExists = true;
					break;
				}
			}
			if (!aCodeAlreadyExists) {
				codeSetElements.add(aCode);
			}
		}
	}
	
	/**
	 * Adds the restriction.
	 * 
	 * @param drivingRestriction the driving restriction
	 * @param drivingRestrictions the driving restrictions
	 */
	private void addRestriction(DrivingRestriction drivingRestriction,
			List <DrivingRestriction> drivingRestrictions) {
		CodeSetElement restrictionTypeCodeToBeAdded = drivingRestriction
				.getRestrictionTypeCode();
		if (restrictionTypeCodeToBeAdded != null
				&& !StringUtils.isBlank(restrictionTypeCodeToBeAdded.getCode())) {
			boolean restrictionTypeCodeAlreadyExists = false;
			if (!EaseUtil.isNotNull(drivingRestrictions)) {
				drivingRestrictions = new ArrayList <DrivingRestriction>();
			}
			for (DrivingRestriction existingRestriction : drivingRestrictions) {
				CodeSetElement restrictionTypeCode = existingRestriction
						.getRestrictionTypeCode();
				if (restrictionTypeCode.getCode().trim().equals(
						restrictionTypeCodeToBeAdded.getCode().trim())) {
					restrictionTypeCodeAlreadyExists = true;
					break;
				}
			}
			if (!restrictionTypeCodeAlreadyExists) {
				drivingRestrictions.add(drivingRestriction);
			}
		}
	}
	
	/**
	 * Gets the Applied License Classes.
	 * 
	 * @return the appliedLicenseClasses
	 */
	public List <CodeSetElement> getAppliedLicenseClasses() {
		if (appliedLicenseClasses == null) {
			setAppliedLicenseClasses(new ArrayList <CodeSetElement>());
		}
		return appliedLicenseClasses;
	}
	
	/**
	 * Gets the previous pending applied license classes.
	 * 
	 * @return the previous pending applied license classes
	 */
	public List <CodeSetElement> getPreviousPendingAppliedLicenseClasses() {
		if (previousPendingAppliedLicenseClasses == null) {
			setPreviousPendingAppliedLicenseClasses(new ArrayList <CodeSetElement>());
		}
		return previousPendingAppliedLicenseClasses;
	}
	
	/**
	 * Sets the previous pending applied license classes.
	 * 
	 * @param previousPendingAppliedLicenseClasses the new previous pending applied license classes
	 */
	public void setPreviousPendingAppliedLicenseClasses(
			List <CodeSetElement> previousPendingAppliedLicenseClasses) {
		this.previousPendingAppliedLicenseClasses = previousPendingAppliedLicenseClasses;
	}
	
	/**
	 * Gets the background check expiration date.
	 * 
	 * @return the backgroundCheckExpirationDate
	 */
	public Date getBackgroundCheckExpirationDate() {
		return backgroundCheckExpirationDate;
	}
	
	/**
	 * Gets the Background Check Indicator.
	 * 
	 * @return the backgroundCheckIndicator
	 */
	public CodeSetElement getBackgroundCheckIndicator() {
		return backgroundCheckIndicator;
	}
	
	/**
	 * Gets the Certificates.
	 * 
	 * @return the certificates
	 */
	public List <CodeSetElement> getCertificates() {
		return certificates;
	}
	
	/**
	 * Gets the Commercial Test Result Group.
	 * 
	 * @return the commercialTestResultGroup
	 */
	public CommercialTestResultGroup getCommercialTestResultGroup() {
		if (!EaseUtil.isNotNull(commercialTestResultGroup)) {
			commercialTestResultGroup = new CommercialTestResultGroup();
		}
		return commercialTestResultGroup;
	}
	
	/**
	 * Gets the commercial test result group on record.
	 *
	 * @return the commercialTestResultGroupOnRecord
	 */
	public CommercialTestResultGroup getCommercialTestResultGroupOnRecord() {
		return commercialTestResultGroupOnRecord;
	}
	
	/**
	 * Gets the Drive and Law Test Result Group.
	 * 
	 * @return the driveAndLawTestResultGroup
	 */
	public DriveAndLawTestResultGroup getDriveAndLawTestResultGroup() {
		if (!EaseUtil.isNotNull(driveAndLawTestResultGroup)) {
			driveAndLawTestResultGroup = new DriveAndLawTestResultGroup();
		}
		return driveAndLawTestResultGroup;
	}
	
	/**
	 * Gets the drive and law test result group on record.
	 *
	 * @return the driveAndLawTestResultGroupOnRecord
	 */
	public DriveAndLawTestResultGroup getDriveAndLawTestResultGroupOnRecord() {
		return driveAndLawTestResultGroupOnRecord;
	}
	
	/**
	 * Gets the Existing Attachments.
	 * 
	 * @return the existingAttachments
	 */
	public List <CodeSetElement> getExistingAttachments() {
		return existingAttachments;
	}
	
	/**
	 * Gets the Existing Categories.
	 * 
	 * @return the existingCategories
	 */
	public List <CodeSetElement> getExistingCategories() {
		return existingCategories;
	}
	
	/**
	 * Gets the Existing Endorsements.
	 * 
	 * @return the existingEndorsements
	 */
	public List <CodeSetElement> getExistingEndorsements() {
		return existingEndorsements;
	}
	
	/**
	 * Gets the existing interim permits.
	 * 
	 * @return the existingInterimPermits
	 */
	public List <InterimPermit> getExistingInterimPermits() {
		return existingInterimPermits;
	}
	
	/**
	 * This method returns Existing Interim Permits for the given Interim Permit Type.
	 * 
	 * @param interimPermitType the interim permit type
	 * 
	 * @return list of Required Interim Permits
	 * 
	 * @see InterimPermit
	 */
	public List <InterimPermit> getExistingInterimPermits(
			InterimPermitType interimPermitType) {
		List <InterimPermit> requiredInterimPermits = new ArrayList <InterimPermit>();
		//Check if Interim Permits exist
		if (!EaseUtil.isNullOrBlank(this.getExistingInterimPermits())) {
			//Iterate the Existing Interim Permits
			for (InterimPermit interimPermit : this.getExistingInterimPermits()) {
				//Check if Interim Permit type exists
				if (interimPermit.getPermitType().equals(interimPermitType)) {
					//Add to return list
					requiredInterimPermits.add(interimPermit);
				}
			}
		}
		return requiredInterimPermits;
	}
	
	/**
	 * Gets the Existing License Classes.
	 * 
	 * @return the existingLicenseClasses
	 */
	public List <CodeSetElement> getExistingLicenseClasses() {
		return existingLicenseClasses;
	}
	
	/**
	 * Gets the Existing Minor Guarantor Code.
	 * 
	 * @return the existingMinorGuarantorCode
	 */
	public CodeSetElement getExistingMinorGuarantorCode() {
		return existingMinorGuarantorCode;
	}
	
	/**
	 * Gets the Existing Restrictions.
	 * 
	 * @return the existingRestrictions
	 */
	public List <DrivingRestriction> getExistingRestrictions() {
		if (existingRestrictions == null) {
			existingRestrictions = new ArrayList <DrivingRestriction>();
		}
		return existingRestrictions;
	}
	
	/**
	 * Gets the Foreign Language Code.
	 * 
	 * @return the foreignLanguageCode
	 */
	public CodeSetElement getForeignLanguageCode() {
		return foreignLanguageCode;
	}
	
	/**
	 * Gets the Interim Issue Date.
	 * 
	 * @return the interimIssueDate
	 */
	public Date getInterimIssueDate() {
		return interimIssueDate;
	}
	
	/**
	 * Adds the New Endorsement.
	 * 
	 * @return the interim permits
	 */
	//	public void addNewEndorsement (CodeSetElement newEndorsement) {
	//		getNewEndorsements().add(newEndorsement);
	//	}
	/**
	 * Adds the New Attachment.
	 * 
	 * @param newAttachment the newAttachment to set
	 */
	//	public void addNewAttachment (CodeSetElement newAttachment) {
	//		getNewAttachments().add(newAttachment);
	//	}
	/**
	 * Adds the New Category.
	 * 
	 * @param newCategory the newCategory to set
	 */
	//	public void addNewCategory(CodeSetElement newCategory) {
	//		getNewCategories().add(newCategory);
	//	}
	/**
	 * Adds the New Restriction.
	 * 
	 * @return the interim permits
	 */
	//	public void addNewRestriction (DrivingRestriction newRestriction) {
	//		getNewRestrictions().add(newRestriction);
	//	}
	/**
	 * Gets the interim permits.
	 * 
	 * @return the interim permits
	 */
	public List <InterimPermit> getInterimPermits() {
		return interimPermits;
	}
	
	/**
	 * This method returns Interim Permits for the given Interim Permit Type.
	 * 
	 * @param interimPermitType the interim permit type
	 * 
	 * @return list of Required Interim Permits
	 * 
	 * @see InterimPermit
	 */
	public List <InterimPermit> getInterimPermits(
			InterimPermitType interimPermitType) {
		List <InterimPermit> requiredInterimPermits = new ArrayList <InterimPermit>();
		//Check if Interim Permits exist
		if (!EaseUtil.isNullOrBlank(this.getInterimPermits())) {
			//Iterate the Interim Permits
			for (InterimPermit interimPermit : this.getInterimPermits()) {
				//Check if Interim Permit type exists
				if (interimPermit.getPermitType().equals(interimPermitType)) {
					//Add to return list
					requiredInterimPermits.add(interimPermit);
				}
			}
		}
		return requiredInterimPermits;
	}
	
	/**
	 * Gets the Issuance Other Date.
	 * 
	 * @return the issuanceOtherDate
	 */
	public Date getIssuanceOtherDate() {
		return issuanceOtherDate;
	}
	
	/**
	 * Gets the License Extension Code.
	 * 
	 * @return the licenseExtensionCode
	 */
	public CodeSetElement getLicenseExtensionCode() {
		return licenseExtensionCode;
	}
	
	/**
	 * Gets the limited license term years.
	 * 
	 * @return the limitedLicenseTermYears
	 */
	public Integer getLimitedLicenseTermYears() {
		return limitedLicenseTermYears;
	}
	
	/**
	 * Gets the new Attachments to be added.
	 * 
	 * @return the addNewAttachments
	 */
	public List <CodeSetElement> getNewAttachments() {
		return newAttachments;
	}
	
	/**
	 * Gets the New Categories to be added.
	 * 
	 * @return the addNewCategories
	 */
	public List <CodeSetElement> getNewCategories() {
		return newCategories;
	}
	
	/**
	 * Gets the new instr permit or temp license class codes.
	 * 
	 * @param interimPermitType the interim permit type
	 * 
	 * @return the new instr permit or temp license class codes
	 */
	public List <CodeSetElement> getNewClassCodesForInterimPermitTypes(
			InterimPermitType interimPermitType) {
		List <CodeSetElement> requiredClasses = new ArrayList <CodeSetElement>();
		if (!EaseUtil.isNullOrBlank(this.getInterimPermits(interimPermitType))) {
			for (InterimPermit interimPermit : this.getInterimPermits()) {
				if (interimPermit.getPermitType().equals(interimPermitType)) {
					requiredClasses.add(interimPermit
							.getPermitLicenseClassCode());
				}
			}
		}
		return requiredClasses;
	}
	
	/**
	 * Gets the New Endorsements to be added.
	 * 
	 * @return the addNewEndorsements
	 */
	public List <CodeSetElement> getNewEndorsements() {
		return newEndorsements;
	}
	
	/**
	 * Gets the new instr permit or temp license issue date.
	 * 
	 * @param interimPermitType the interim permit type
	 * 
	 * @return the new instr permit or temp license issue date
	 */
	public Date getNewInstrPermitOrTempLicenseIssueDate(
			InterimPermitType interimPermitType) {
		if (!EaseUtil.isNullOrBlank(this.getInterimPermits(interimPermitType))) {
			return this.getInterimPermits(interimPermitType).get(0)
					.getPermitIssueDate();
		}
		return null;
	}
	
	/**
	 * Gets the New Restrictions to be added.
	 * 
	 * @return the addNewRestrictions
	 */
	public List <DrivingRestriction> getNewRestrictions() {
		return newRestrictions;
	}
	
	/**
	 * Gets the pending app categories.
	 * 
	 * @return the pending app categories
	 */
	public List <CodeSetElement> getPendingAppCategories() {
		return pendingAppCategories;
	}
	
	/**
	 * Gets the Previous Application Date.
	 * 
	 * @return the perviousAppDate
	 */
	public Date getPerviousAppDate() {
		return perviousAppDate;
	}
	
	/**
	 * Gets the renewal license term years.
	 * 
	 * @return the renewalLicenseTermYears
	 */
	public Integer getRenewalLicenseTermYears() {
		return renewalLicenseTermYears;
	}
	
	/**
	 * Returns the sign test history, which indicates either that the sign test has not yet
	 * been taken (0), has been passed (P), or has been failed x number of times.
	 * 
	 * @return
	 */
	public String getSignTestHistory() {
		DriveAndLawTestResultGroup driveAndLawTestResultGroup = getDriveAndLawTestResultGroup();
		List <DriveAndLawTestResult> signTestResults = driveAndLawTestResultGroup.getDriveAndLawTestResults(DriveAndLawTestResultType.SIGNS_TEST_RESULT);
		int totalFails = 0;
		for (DriveAndLawTestResult result : signTestResults) {
			if (IGeneralTestConstants.PASSED_AKTS_PASSED_SATISFACTORY.contains(result.getTestResultCode().getCode())) {
				return IGeneralTestConstants.PASSED;
			}
			int failValue = KnowledgeExam.getFailValue(result.getTestResultCode().getCode());
			totalFails += failValue;
		}
		return Integer.toString(totalFails);
	}
	
	/**
	 * Gets the Indicator for Oral Test.
	 * 
	 * @return the isOralTest
	 */
	public Boolean isOralTest() {
		return isOralTest;
	}
	
	/**
	 * Checks if is regular term.
	 * 
	 * @return the isRegularTerm
	 */
	public Boolean isRegularTerm() {
		return isRegularTerm;
	}
	
	/**
	 * Sets the Applied License Classes.
	 * 
	 * @param appliedLicenseClasses the appliedLicenseClasses to set
	 */
	public void setAppliedLicenseClasses(
			List <CodeSetElement> appliedLicenseClasses) {
		this.appliedLicenseClasses = appliedLicenseClasses;
	}
	
	/**
	 * Sets the background check expiration date.
	 * 
	 * @param backgroundCheckExpirationDate the backgroundCheckExpirationDate to set
	 */
	public void setBackgroundCheckExpirationDate(
			Date backgroundCheckExpirationDate) {
		this.backgroundCheckExpirationDate = backgroundCheckExpirationDate;
	}
	
	/**
	 * Sets the Background Check Indicator.
	 * 
	 * @param backgroundCheckIndicator the backgroundCheckIndicator to set
	 */
	public void setBackgroundCheckIndicator(
			CodeSetElement backgroundCheckIndicator) {
		this.backgroundCheckIndicator = backgroundCheckIndicator;
	}
	
	/**
	 * Sets the Certificates.
	 * 
	 * @param certificates the certificates to set
	 */
	public void setCertificates(List <CodeSetElement> certificates) {
		this.certificates = certificates;
	}
	
	/**
	 * Sets the Commercial Test Result Group.
	 * 
	 * @param commercialTestResultGroup the commercialTestResultGroup to set
	 */
	public void setCommercialTestResultGroup(
			CommercialTestResultGroup commercialTestResultGroup) {
		this.commercialTestResultGroup = commercialTestResultGroup;
	}
	
	/**
	 * Sets the commercial test result group on record.
	 *
	 * @param commercialTestResultGroupOnRecord the commercialTestResultGroupOnRecord to set
	 */
	public void setCommercialTestResultGroupOnRecord(
			CommercialTestResultGroup commercialTestResultGroupOnRecord) {
		this.commercialTestResultGroupOnRecord = commercialTestResultGroupOnRecord;
	}
	
	/**
	 * Sets the Drive and Law Test Result Group.
	 * 
	 * @param driveAndLawTestResultGroup the driveAndLawTestResultGroup to set
	 */
	public void setDriveAndLawTestResultGroup(
			DriveAndLawTestResultGroup driveAndLawTestResultGroup) {
		this.driveAndLawTestResultGroup = driveAndLawTestResultGroup;
	}
	
	/**
	 * Sets the drive and law test result group on record.
	 *
	 * @param driveAndLawTestResultGroupOnRecord the driveAndLawTestResultGroupOnRecord to set
	 */
	public void setDriveAndLawTestResultGroupOnRecord(
			DriveAndLawTestResultGroup driveAndLawTestResultGroupOnRecord) {
		this.driveAndLawTestResultGroupOnRecord = driveAndLawTestResultGroupOnRecord;
	}
	
	/**
	 * Sets the Existing Attachments.
	 * 
	 * @param existingAttachments the existingAttachments to set
	 */
	public void setExistingAttachments(List <CodeSetElement> existingAttachments) {
		this.existingAttachments = existingAttachments;
	}
	
	/**
	 * Sets the Existing Categories.
	 * 
	 * @param existingCategories the existingCategories to set
	 */
	public void setExistingCategories(List <CodeSetElement> existingCategories) {
		this.existingCategories = existingCategories;
	}
	
	/**
	 * Sets the Existing Endorsements.
	 * 
	 * @param existingEndorsements the existingEndorsements to set
	 */
	public void setExistingEndorsements(
			List <CodeSetElement> existingEndorsements) {
		this.existingEndorsements = existingEndorsements;
	}
	
	/**
	 * Sets the existing interim permits.
	 * 
	 * @param existingInterimPermits the existingInterimPermits to set
	 */
	public void setExistingInterimPermits(
			List <InterimPermit> existingInterimPermits) {
		this.existingInterimPermits = existingInterimPermits;
	}
	
	/**
	 * Sets the Existing License Classes.
	 * 
	 * @param existingLicenseClasses the existingLicenseClasses to set
	 */
	public void setExistingLicenseClasses(
			List <CodeSetElement> existingLicenseClasses) {
		this.existingLicenseClasses = existingLicenseClasses;
	}
	
	/**
	 * Sets the Existing Minor Guarantor Code.
	 * 
	 * @param existingMinorGuarantorCode the existingMinorGuarantorCode to set
	 */
	public void setExistingMinorGuarantorCode(
			CodeSetElement existingMinorGuarantorCode) {
		this.existingMinorGuarantorCode = existingMinorGuarantorCode;
	}
	
	/**
	 * Sets the Existing Restrictions.
	 * 
	 * @param existingRestrictions the existingRestrictions to set
	 */
	public void setExistingRestrictions(
			List <DrivingRestriction> existingRestrictions) {
		this.existingRestrictions = existingRestrictions;
	}
	
	/**
	 * Sets the Foreign Language Code.
	 * 
	 * @param foreignLanguage the new foreign language code
	 */
	public void setForeignLanguageCode(CodeSetElement foreignLanguage) {
		this.foreignLanguageCode = foreignLanguage;
	}
	
	/**
	 * Sets the Interim Issue Date.
	 * 
	 * @param interimIssueDate the interimIssueDate to set
	 */
	public void setInterimIssueDate(Date interimIssueDate) {
		this.interimIssueDate = interimIssueDate;
	}
	
	/**
	 * Sets the interim permits.
	 * 
	 * @param interimPermits the interimPermits to set
	 */
	public void setInterimPermits(List <InterimPermit> interimPermits) {
		this.interimPermits = interimPermits;
	}
	
	/**
	 * Sets the Indicator for Oral Test.
	 * 
	 * @param isOralTest the isOralTest to set
	 */
	public void setIsOralTest(Boolean isOralTest) {
		this.isOralTest = isOralTest;
	}
	
	/**
	 * Sets the Issuance Other Date.
	 * 
	 * @param issuanceOtherDate the issuanceOtherDate to set
	 */
	public void setIssuanceOtherDate(Date issuanceOtherDate) {
		this.issuanceOtherDate = issuanceOtherDate;
	}
	
	/**
	 * Sets the License Extension Code.
	 * 
	 * @param licenseExtensionCode the licenseExtensionCode to set
	 */
	public void setLicenseExtensionCode(CodeSetElement licenseExtensionCode) {
		this.licenseExtensionCode = licenseExtensionCode;
	}
	
	/**
	 * Sets the limited license term years.
	 * 
	 * @param limitedLicenseTermYears the limitedLicenseTermYears to set
	 */
	public void setLimitedLicenseTermYears(Integer limitedLicenseTermYears) {
		this.limitedLicenseTermYears = limitedLicenseTermYears;
	}
	
	/**
	 * Sets the new Attachments to be added.
	 * 
	 * @param addNewAttachments the addNewAttachments to set
	 */
	public void setNewAttachments(List <CodeSetElement> addNewAttachments) {
		this.newAttachments = addNewAttachments;
	}
	
	/**
	 * Sets the New Categories to be added.
	 * 
	 * @param addNewCategories the addNewCategories to set
	 */
	public void setNewCategories(List <CodeSetElement> addNewCategories) {
		if (!EaseUtil.isNotNull(newCategories)) {
			newCategories = new ArrayList <CodeSetElement>();
		}
		this.newCategories = addNewCategories;
	}
	
	/**
	 * Sets the New Endorsements to be added.
	 * 
	 * @param addNewEndorsements the addNewEndorsements to set
	 */
	public void setNewEndorsements(List <CodeSetElement> addNewEndorsements) {
		this.newEndorsements = addNewEndorsements;
	}
	
	/**
	 * Sets the New Restrictions to be added.
	 * 
	 * @param addNewRestrictions the addNewRestrictions to set
	 */
	public void setNewRestrictions(List <DrivingRestriction> addNewRestrictions) {
		this.newRestrictions = addNewRestrictions;
	}
	
	/**
	 * Sets the pending app categories.
	 * 
	 * @param pendingAppCategories the new pending app categories
	 */
	public void setPendingAppCategories(
			List <CodeSetElement> pendingAppCategories) {
		this.pendingAppCategories = pendingAppCategories;
	}
	
	/**
	 * Sets the Previous Application Date.
	 * 
	 * @param perviousAppDate the perviousAppDate to set
	 */
	public void setPerviousAppDate(Date perviousAppDate) {
		this.perviousAppDate = perviousAppDate;
	}
	
	/**
	 * Sets the regular term.
	 * 
	 * @param isRegularTerm the isRegularTerm to set
	 */
	public void setRegularTerm(Boolean isRegularTerm) {
		this.isRegularTerm = isRegularTerm;
	}
	
	/**
	 * Sets the renewal license term years.
	 * 
	 * @param renewalLicenseTermYears the renewalLicenseTermYears to set
	 */
	public void setRenewalLicenseTermYears(Integer renewalLicenseTermYears) {
		this.renewalLicenseTermYears = renewalLicenseTermYears;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.license.impl.License#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("appliedLicenseClasses", appliedLicenseClasses,
				anIndent, aBuilder);
		outputKeyValue("backgroundCheckExpirationDate",
				backgroundCheckExpirationDate, anIndent, aBuilder);
		outputKeyValue("backgroundCheckIndicator", backgroundCheckIndicator,
				anIndent, aBuilder);
		outputKeyValue("certificates", certificates, anIndent, aBuilder);
		outputKeyValue("commercialTestResultGroup", commercialTestResultGroup,
				anIndent, aBuilder);
		outputKeyValue("driveAndLawTestResultGroup",
				driveAndLawTestResultGroup, anIndent, aBuilder);
		outputKeyValue("existingAttachments", existingAttachments, anIndent,
				aBuilder);
		outputKeyValue("existingCategories", existingCategories, anIndent,
				aBuilder);
		outputKeyValue("existingEndorsements", existingEndorsements, anIndent,
				aBuilder);
		outputKeyValue("existingInterimPermits", existingInterimPermits,
				anIndent, aBuilder);
		outputKeyValue("existingLicenseClasses", existingLicenseClasses,
				anIndent, aBuilder);
		outputKeyValue("existingMinorGuarantorCode",
				existingMinorGuarantorCode, anIndent, aBuilder);
		outputKeyValue("existingRestrictions", existingRestrictions, anIndent,
				aBuilder);
		outputKeyValue("foreignLanguageCode", foreignLanguageCode, anIndent,
				aBuilder);
		outputKeyValue("iidIndicator", iidIndicator, anIndent, aBuilder);
		outputKeyValue("interimIssueDate", interimIssueDate, anIndent, aBuilder);
		outputKeyValue("interimPermits", interimPermits, anIndent, aBuilder);
		outputKeyValue("isOralTest", isOralTest, anIndent, aBuilder);
		outputKeyValue("isRegularTerm", isRegularTerm, anIndent, aBuilder);
		outputKeyValue("issuanceOtherDate", issuanceOtherDate, anIndent,
				aBuilder);
		outputKeyValue("licenseExtensionCode", licenseExtensionCode, anIndent,
				aBuilder);
		outputKeyValue("limitedLicenseTermYears", limitedLicenseTermYears,
				anIndent, aBuilder);
		outputKeyValue("newAttachments", newAttachments, anIndent, aBuilder);
		outputKeyValue("newCategories", newCategories, anIndent, aBuilder);
		outputKeyValue("newEndorsements", newEndorsements, anIndent, aBuilder);
		outputKeyValue("newRestrictions", newRestrictions, anIndent, aBuilder);
		outputKeyValue("pendingAppCategories", pendingAppCategories, anIndent,
				aBuilder);
		outputKeyValue("perviousAppDate", perviousAppDate, anIndent, aBuilder);
		outputKeyValue("renewalLicenseTermYears", renewalLicenseTermYears,
				anIndent, aBuilder);
		outputKeyValue("isAppliedLpUnverified", isAppliedLpUnverified, anIndent, aBuilder);
		outputKeyValue("isExistingLpUnverified", isExistingLpUnverified, anIndent, aBuilder);
		outputKeyValue("isPendingLpUnverified", isPendingLpUnverified, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * This method is to copy DriverLicense.
	 * 
	 * @param objectToCopy the data to copy
	 */
	private void copy(DriverLicense objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy method for " + this);
		}
		super.copy(objectToCopy);
		setAppliedLicenseClasses(CodeSetElement
				.copyCodeSetElementList(objectToCopy.getAppliedLicenseClasses()));
		setPreviousPendingAppliedLicenseClasses(CodeSetElement
				.copyCodeSetElementList(objectToCopy
						.getPreviousPendingAppliedLicenseClasses()));
		if (EaseUtil.isNotNull(objectToCopy.getBackgroundCheckExpirationDate())) {
			setBackgroundCheckExpirationDate(new Date(objectToCopy
					.getBackgroundCheckExpirationDate().getTime()));
		}
		else {
			setBackgroundCheckExpirationDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getBackgroundCheckIndicator())) {
			setBackgroundCheckIndicator(objectToCopy
					.getBackgroundCheckIndicator().copy());
		}
		else {
			setBackgroundCheckIndicator(null);
		}
		setCertificates(CodeSetElement.copyCodeSetElementList(objectToCopy
				.getCertificates()));
		//CommercialTestResultGroup
		if (EaseUtil.isNotNull(objectToCopy.getCommercialTestResultGroup())) {
			setCommercialTestResultGroup(new CommercialTestResultGroup(
					objectToCopy.getCommercialTestResultGroup()));
		}
		else {
			setCommercialTestResultGroup(null);
		}
		//CommercialTestResultGroupOnRecord
		if (EaseUtil.isNotNull(objectToCopy
				.getCommercialTestResultGroupOnRecord())) {
			setCommercialTestResultGroupOnRecord(new CommercialTestResultGroup(
					objectToCopy.getCommercialTestResultGroupOnRecord()));
		}
		else {
			setCommercialTestResultGroupOnRecord(null);
		}
		//DriveAndLawTestResultGroup
		if (EaseUtil.isNotNull(objectToCopy.getDriveAndLawTestResultGroup())) {
			setDriveAndLawTestResultGroup(new DriveAndLawTestResultGroup(
					objectToCopy.getDriveAndLawTestResultGroup()));
		}
		else {
			setDriveAndLawTestResultGroup(null);
		}
		//DriveAndLawTestResultGroupOnRecord
		if (EaseUtil.isNotNull(objectToCopy
				.getDriveAndLawTestResultGroupOnRecord())) {
			setDriveAndLawTestResultGroupOnRecord(new DriveAndLawTestResultGroup(
					objectToCopy.getDriveAndLawTestResultGroupOnRecord()));
		}
		else {
			setDriveAndLawTestResultGroupOnRecord(null);
		}
		setExistingAttachments(CodeSetElement
				.copyCodeSetElementList(objectToCopy.getExistingAttachments()));
		setExistingCategories(CodeSetElement
				.copyCodeSetElementList(objectToCopy.getExistingCategories()));
		setExistingEndorsements(CodeSetElement
				.copyCodeSetElementList(objectToCopy.getExistingEndorsements()));
		List <InterimPermit> origExistingInterimPermits = objectToCopy
				.getExistingInterimPermits();
		if (EaseUtil.isNotNull(origExistingInterimPermits)) {
			List <InterimPermit> copyExistingInterimPermits = new ArrayList <InterimPermit>();
			for (InterimPermit origExistingInterimPermit : origExistingInterimPermits) {
				if (EaseUtil.isNotNull(origExistingInterimPermit)) {
					copyExistingInterimPermits.add(new InterimPermit(
							origExistingInterimPermit));
				}
				else {
					copyExistingInterimPermits.add(null);
				}
			}
			setExistingInterimPermits(copyExistingInterimPermits);
		}
		else {
			setExistingInterimPermits(null);
		}
		setExistingLicenseClasses(CodeSetElement
				.copyCodeSetElementList(objectToCopy
						.getExistingLicenseClasses()));
		setPreviousExistingLicenseClasses(CodeSetElement
				.copyCodeSetElementList(objectToCopy
						.getPreviousExistingLicenseClasses()));
		if (EaseUtil
				.isNotNull(objectToCopy.getPreviousExistingExpirationDate())) {
			setPreviousExistingExpirationDate(new Date(objectToCopy
					.getPreviousExistingExpirationDate().getTime()));
		}
		else {
			setPreviousExistingExpirationDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getExistingMinorGuarantorCode())) {
			setExistingMinorGuarantorCode(objectToCopy
					.getExistingMinorGuarantorCode().copy());
		}
		else {
			setExistingMinorGuarantorCode(null);
		}
		List <DrivingRestriction> origExistingRestrictions = objectToCopy
				.getExistingRestrictions();
		if (EaseUtil.isNotNull(origExistingRestrictions)) {
			List <DrivingRestriction> copyExistingRestrictions = new ArrayList <DrivingRestriction>();
			for (DrivingRestriction origExistingRestriction : origExistingRestrictions) {
				if (EaseUtil.isNotNull(origExistingRestrictions)) {
					copyExistingRestrictions.add(new DrivingRestriction(
							origExistingRestriction));
				}
				else {
					copyExistingRestrictions.add(null);
				}
			}
			setExistingRestrictions(copyExistingRestrictions);
		}
		else {
			setExistingRestrictions(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getForeignLanguageCode())) {
			setForeignLanguageCode(objectToCopy.getForeignLanguageCode().copy());
		}
		else {
			setForeignLanguageCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getInterimIssueDate())) {
			setInterimIssueDate(new Date(objectToCopy.getInterimIssueDate()
					.getTime()));
		}
		else {
			setInterimIssueDate(null);
		}
		List <InterimPermit> origInterimPermits = objectToCopy
				.getInterimPermits();
		if (EaseUtil.isNotNull(origInterimPermits)) {
			List <InterimPermit> copyInterimPermits = new ArrayList <InterimPermit>();
			for (InterimPermit origInterimPermit : origInterimPermits) {
				if (EaseUtil.isNotNull(origInterimPermit)) {
					copyInterimPermits
							.add(new InterimPermit(origInterimPermit));
				}
				else {
					copyInterimPermits.add(null);
				}
			}
			setInterimPermits(copyInterimPermits);
		}
		else {
			setInterimPermits(null);
		}
		setIsOralTest(objectToCopy.isOralTest());
		setRegularTerm(objectToCopy.isRegularTerm());
		if (EaseUtil.isNotNull(objectToCopy.getIssuanceOtherDate())) {
			setIssuanceOtherDate(new Date(objectToCopy.getIssuanceOtherDate()
					.getTime()));
		}
		else {
			setIssuanceOtherDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getLicenseExtensionCode())) {
			setLicenseExtensionCode(objectToCopy.getLicenseExtensionCode()
					.copy());
		}
		else {
			setLicenseExtensionCode(null);
		}
		setLimitedLicenseTermYears(objectToCopy.getLimitedLicenseTermYears());
		setLimitedTermFeeDueYear(objectToCopy.getLimitedTermFeeDueYear());
		setNewAttachments(CodeSetElement.copyCodeSetElementList(objectToCopy
				.getNewAttachments()));
		setNewCategories(CodeSetElement.copyCodeSetElementList(objectToCopy
				.getNewCategories()));
		setNewEndorsements(CodeSetElement.copyCodeSetElementList(objectToCopy
				.getNewEndorsements()));
		List <DrivingRestriction> origNewRestrictions = objectToCopy
				.getNewRestrictions();
		if (EaseUtil.isNotNull(origNewRestrictions)) {
			List <DrivingRestriction> copyNewRestrictions = new ArrayList <DrivingRestriction>();
			for (DrivingRestriction origNewRestriction : origNewRestrictions) {
				if (EaseUtil.isNotNull(origNewRestrictions)) {
					copyNewRestrictions.add(new DrivingRestriction(
							origNewRestriction));
				}
				else {
					copyNewRestrictions.add(null);
				}
			}
			setNewRestrictions(copyNewRestrictions);
		}
		else {
			setNewRestrictions(null);
		}
		setPendingAppCategories(CodeSetElement
				.copyCodeSetElementList(objectToCopy.getPendingAppCategories()));
		if (EaseUtil.isNotNull(objectToCopy.getPerviousAppDate())) {
			setPerviousAppDate(new Date(objectToCopy.getPerviousAppDate()
					.getTime()));
		}
		else {
			setPerviousAppDate(null);
		}
		setRenewalLicenseTermYears(objectToCopy.getRenewalLicenseTermYears());
		setIidIndicator(objectToCopy.getIidIndicator());
		setAppliedLpUnverified(objectToCopy.isAppliedLpUnverified());
		
		setExistingLpUnverified(objectToCopy
					.isExistingLpUnverified());
		setPendingLpUnverified(objectToCopy
				.isPendingLpUnverified());
			
	}
	
	/**
	 * Adds the driving restriction.
	 * 
	 * @param drivingRestriction the driving restriction
	 */
	private void addDrivingRestriction(DrivingRestriction drivingRestriction) {
		this.newRestrictions = new ArrayList <DrivingRestriction>();
		this.newRestrictions.add(new DrivingRestriction(drivingRestriction));
	}
	
	/**
	 * Sets the previous existing license classes.
	 *
	 * @param previousExistingLicenseClasses the new previous existing license classes
	 */
	public void setPreviousExistingLicenseClasses(
			List <CodeSetElement> previousExistingLicenseClasses) {
		this.previousExistingLicenseClasses = previousExistingLicenseClasses;
	}
	
	/**
	 * Gets the previous existing license classes.
	 *
	 * @return the previous existing license classes
	 */
	public List <CodeSetElement> getPreviousExistingLicenseClasses() {
		return previousExistingLicenseClasses;
	}
	
	/**
	 * Sets the previous existing expiration date.
	 *
	 * @param previousExistingExpirationDate the new previous existing expiration date
	 */
	public void setPreviousExistingExpirationDate(
			Date previousExistingExpirationDate) {
		this.previousExistingExpirationDate = previousExistingExpirationDate;
	}
	
	/**
	 * Gets the previous existing expiration date.
	 *
	 * @return the previous existing expiration date
	 */
	public Date getPreviousExistingExpirationDate() {
		return previousExistingExpirationDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((appliedLicenseClasses == null) ? 0 : appliedLicenseClasses
						.hashCode());
		result = prime
				* result
				+ ((backgroundCheckExpirationDate == null) ? 0
						: backgroundCheckExpirationDate.hashCode());
		result = prime
				* result
				+ ((backgroundCheckIndicator == null) ? 0
						: backgroundCheckIndicator.hashCode());
		result = prime * result
				+ ((certificates == null) ? 0 : certificates.hashCode());
		result = prime
				* result
				+ ((commercialTestResultGroup == null) ? 0
						: commercialTestResultGroup.hashCode());
		result = prime
				* result
				+ ((commercialTestResultGroupOnRecord == null) ? 0
						: commercialTestResultGroupOnRecord.hashCode());
		result = prime
				* result
				+ ((driveAndLawTestResultGroup == null) ? 0
						: driveAndLawTestResultGroup.hashCode());
		result = prime
				* result
				+ ((driveAndLawTestResultGroupOnRecord == null) ? 0
						: driveAndLawTestResultGroupOnRecord.hashCode());
		result = prime
				* result
				+ ((existingAttachments == null) ? 0 : existingAttachments
						.hashCode());
		result = prime
				* result
				+ ((existingCategories == null) ? 0 : existingCategories
						.hashCode());
		result = prime
				* result
				+ ((existingEndorsements == null) ? 0 : existingEndorsements
						.hashCode());
		result = prime
				* result
				+ ((existingInterimPermits == null) ? 0
						: existingInterimPermits.hashCode());
		result = prime
				* result
				+ ((existingLicenseClasses == null) ? 0
						: existingLicenseClasses.hashCode());
		result = prime
				* result
				+ ((existingMinorGuarantorCode == null) ? 0
						: existingMinorGuarantorCode.hashCode());
		result = prime
				* result
				+ ((existingRestrictions == null) ? 0 : existingRestrictions
						.hashCode());
		result = prime
				* result
				+ ((foreignLanguageCode == null) ? 0 : foreignLanguageCode
						.hashCode());
		result = prime * result
				+ ((iidIndicator == null) ? 0 : iidIndicator.hashCode());
		result = prime
				* result
				+ ((interimIssueDate == null) ? 0 : interimIssueDate.hashCode());
		result = prime * result
				+ ((interimPermits == null) ? 0 : interimPermits.hashCode());
		result = prime * result
				+ (isAppliedLpUnverified ? 1231 : 1237);
		result = prime * result
				+ (isExistingLpUnverified ? 1231 : 1237);
		result = prime * result
				+ (isPendingLpUnverified ? 1231 : 1237);
		result = prime * result
				+ ((isOralTest == null) ? 0 : isOralTest.hashCode());
		result = prime * result
				+ ((isRegularTerm == null) ? 0 : isRegularTerm.hashCode());
		result = prime
				* result
				+ ((issuanceOtherDate == null) ? 0 : issuanceOtherDate
						.hashCode());
		result = prime
				* result
				+ ((licenseExtensionCode == null) ? 0 : licenseExtensionCode
						.hashCode());
		result = prime
				* result
				+ ((limitedLicenseTermYears == null) ? 0
						: limitedLicenseTermYears.hashCode());
		result = prime * result
				+ ((newAttachments == null) ? 0 : newAttachments.hashCode());
		result = prime * result
				+ ((newCategories == null) ? 0 : newCategories.hashCode());
		result = prime * result
				+ ((newEndorsements == null) ? 0 : newEndorsements.hashCode());
		result = prime * result
				+ ((newRestrictions == null) ? 0 : newRestrictions.hashCode());
		result = prime
				* result
				+ ((pendingAppCategories == null) ? 0 : pendingAppCategories
						.hashCode());
		result = prime * result
				+ ((perviousAppDate == null) ? 0 : perviousAppDate.hashCode());
		result = prime
				* result
				+ ((previousExistingExpirationDate == null) ? 0
						: previousExistingExpirationDate.hashCode());
		result = prime
				* result
				+ ((previousExistingLicenseClasses == null) ? 0
						: previousExistingLicenseClasses.hashCode());
		result = prime
				* result
				+ ((previousPendingAppliedLicenseClasses == null) ? 0
						: previousPendingAppliedLicenseClasses.hashCode());
		result = prime
				* result
				+ ((renewalLicenseTermYears == null) ? 0
						: renewalLicenseTermYears.hashCode());
		return result;
	}
	


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DriverLicense other = (DriverLicense) obj;
		if (appliedLicenseClasses == null) {
			if (other.appliedLicenseClasses != null) {
				return false;
			}
		}
		else if (!appliedLicenseClasses.equals(other.appliedLicenseClasses)) {
			return false;
		}
		if (backgroundCheckExpirationDate == null) {
			if (other.backgroundCheckExpirationDate != null) {
				return false;
			}
		}
		else if (!backgroundCheckExpirationDate
				.equals(other.backgroundCheckExpirationDate)) {
			return false;
		}
		if (backgroundCheckIndicator == null) {
			if (other.backgroundCheckIndicator != null) {
				return false;
			}
		}
		else if (!backgroundCheckIndicator
				.equals(other.backgroundCheckIndicator)) {
			return false;
		}
		if (certificates == null) {
			if (other.certificates != null) {
				return false;
			}
		}
		else if (!certificates.equals(other.certificates)) {
			return false;
		}
		if (commercialTestResultGroup == null) {
			if (other.commercialTestResultGroup != null) {
				return false;
			}
		}
		else if (!commercialTestResultGroup
				.equals(other.commercialTestResultGroup)) {
			return false;
		}
		if (commercialTestResultGroupOnRecord == null) {
			if (other.commercialTestResultGroupOnRecord != null) {
				return false;
			}
		}
		else if (!commercialTestResultGroupOnRecord
				.equals(other.commercialTestResultGroupOnRecord)) {
			return false;
		}
		if (driveAndLawTestResultGroup == null) {
			if (other.driveAndLawTestResultGroup != null) {
				return false;
			}
		}
		else if (!driveAndLawTestResultGroup
				.equals(other.driveAndLawTestResultGroup)) {
			return false;
		}
		if (driveAndLawTestResultGroupOnRecord == null) {
			if (other.driveAndLawTestResultGroupOnRecord != null) {
				return false;
			}
		}
		else if (!driveAndLawTestResultGroupOnRecord
				.equals(other.driveAndLawTestResultGroupOnRecord)) {
			return false;
		}
		if (existingAttachments == null) {
			if (other.existingAttachments != null) {
				return false;
			}
		}
		else if (!existingAttachments.equals(other.existingAttachments)) {
			return false;
		}
		if (existingCategories == null) {
			if (other.existingCategories != null) {
				return false;
			}
		}
		else if (!existingCategories.equals(other.existingCategories)) {
			return false;
		}
		if (existingEndorsements == null) {
			if (other.existingEndorsements != null) {
				return false;
			}
		}
		else if (!existingEndorsements.equals(other.existingEndorsements)) {
			return false;
		}
		if (existingInterimPermits == null) {
			if (other.existingInterimPermits != null) {
				return false;
			}
		}
		else if (!existingInterimPermits.equals(other.existingInterimPermits)) {
			return false;
		}
		if (existingLicenseClasses == null) {
			if (other.existingLicenseClasses != null) {
				return false;
			}
		}
		else if (!existingLicenseClasses.equals(other.existingLicenseClasses)) {
			return false;
		}
		if (existingMinorGuarantorCode == null) {
			if (other.existingMinorGuarantorCode != null) {
				return false;
			}
		}
		else if (!existingMinorGuarantorCode
				.equals(other.existingMinorGuarantorCode)) {
			return false;
		}
		if (existingRestrictions == null) {
			if (other.existingRestrictions != null) {
				return false;
			}
		}
		else if (!existingRestrictions.equals(other.existingRestrictions)) {
			return false;
		}
		if (foreignLanguageCode == null) {
			if (other.foreignLanguageCode != null) {
				return false;
			}
		}
		else if (!foreignLanguageCode.equals(other.foreignLanguageCode)) {
			return false;
		}
		if (iidIndicator == null) {
			if (other.iidIndicator != null) {
				return false;
			}
		}
		else if (!iidIndicator.equals(other.iidIndicator)) {
			return false;
		}
		if (interimIssueDate == null) {
			if (other.interimIssueDate != null) {
				return false;
			}
		}
		else if (!interimIssueDate.equals(other.interimIssueDate)) {
			return false;
		}
		if (interimPermits == null) {
			if (other.interimPermits != null) {
				return false;
			}
		}
		else if (!interimPermits.equals(other.interimPermits)) {
			return false;
		}

		if (isAppliedLpUnverified != other.isAppliedLpUnverified) {
			return false;
		}
		
		if (isExistingLpUnverified != other.isExistingLpUnverified) {
			return false;
		}
		
		if (isPendingLpUnverified != other.isPendingLpUnverified) {
			return false;
		}
		
		if (isOralTest == null) {
			if (other.isOralTest != null) {
				return false;
			}
		}
		else if (!isOralTest.equals(other.isOralTest)) {
			return false;
		}
		if (isRegularTerm == null) {
			if (other.isRegularTerm != null) {
				return false;
			}
		}
		else if (!isRegularTerm.equals(other.isRegularTerm)) {
			return false;
		}
		if (issuanceOtherDate == null) {
			if (other.issuanceOtherDate != null) {
				return false;
			}
		}
		else if (!issuanceOtherDate.equals(other.issuanceOtherDate)) {
			return false;
		}
		if (licenseExtensionCode == null) {
			if (other.licenseExtensionCode != null) {
				return false;
			}
		}
		else if (!licenseExtensionCode.equals(other.licenseExtensionCode)) {
			return false;
		}
		if (limitedLicenseTermYears == null) {
			if (other.limitedLicenseTermYears != null) {
				return false;
			}
		}
		else if (!limitedLicenseTermYears.equals(other.limitedLicenseTermYears)) {
			return false;
		}
		if (newAttachments == null) {
			if (other.newAttachments != null) {
				return false;
			}
		}
		else if (!newAttachments.equals(other.newAttachments)) {
			return false;
		}
		if (newCategories == null) {
			if (other.newCategories != null) {
				return false;
			}
		}
		else if (!newCategories.equals(other.newCategories)) {
			return false;
		}
		if (newEndorsements == null) {
			if (other.newEndorsements != null) {
				return false;
			}
		}
		else if (!newEndorsements.equals(other.newEndorsements)) {
			return false;
		}
		if (newRestrictions == null) {
			if (other.newRestrictions != null) {
				return false;
			}
		}
		else if (!newRestrictions.equals(other.newRestrictions)) {
			return false;
		}
		if (pendingAppCategories == null) {
			if (other.pendingAppCategories != null) {
				return false;
			}
		}
		else if (!pendingAppCategories.equals(other.pendingAppCategories)) {
			return false;
		}
		if (perviousAppDate == null) {
			if (other.perviousAppDate != null) {
				return false;
			}
		}
		else if (!perviousAppDate.equals(other.perviousAppDate)) {
			return false;
		}
		if (previousExistingExpirationDate == null) {
			if (other.previousExistingExpirationDate != null) {
				return false;
			}
		}
		else if (!previousExistingExpirationDate
				.equals(other.previousExistingExpirationDate)) {
			return false;
		}
		if (previousExistingLicenseClasses == null) {
			if (other.previousExistingLicenseClasses != null) {
				return false;
			}
		}
		else if (!previousExistingLicenseClasses
				.equals(other.previousExistingLicenseClasses)) {
			return false;
		}
		if (previousPendingAppliedLicenseClasses == null) {
			if (other.previousPendingAppliedLicenseClasses != null) {
				return false;
			}
		}
		else if (!previousPendingAppliedLicenseClasses
				.equals(other.previousPendingAppliedLicenseClasses)) {
			return false;
		}
		if (renewalLicenseTermYears == null) {
			if (other.renewalLicenseTermYears != null) {
				return false;
			}
		}
		else if (!renewalLicenseTermYears.equals(other.renewalLicenseTermYears)) {
			return false;
		}
		return true;
	}

	/**
	 * @param iidIndicator the iidIndicator to set
	 */
	public void setIidIndicator(String iidIndicator) {
		this.iidIndicator = iidIndicator;
	}

	/**
	 * @return the iidIndicator
	 */
	public String getIidIndicator() {
		return iidIndicator;
	}

	/**
	 * Return isAppliedLpUnverified
	 * 
	 * @return isAppliedLpUnverified
	 */
	public boolean isAppliedLpUnverified() {
		return isAppliedLpUnverified;
	}

	/**
	 * Set isAppliedLpUnverified
	 * 
	 * @param isAppliedLpUnverified
	 */
	public void setAppliedLpUnverified(boolean isAppliedLpUnverified) {
		this.isAppliedLpUnverified = isAppliedLpUnverified;
	}


	/**
	 * Return isExistingLpUnverified
	 * 
	 * @return isExistingLpUnverified
	 */
	public boolean isExistingLpUnverified() {
		return isExistingLpUnverified;
	}

	/**
	 * Sets isExistingLpUnverified
	 * 
	 * @param isExistingLpUnverified
	 */
	public void setExistingLpUnverified(boolean isExistingLpUnverified) {
		this.isExistingLpUnverified = isExistingLpUnverified;
	}

	/**
	 * Returns isPendingLpUnverified
	 * 
	 * @return isPendingLpUnverified
	 */
	public boolean isPendingLpUnverified() {
		return isPendingLpUnverified;
	}

	/**
	 * Sets isPendingLpUnverified
	 * 
	 * @param isPendingLpUnverified
	 */
	public void setPendingLpUnverified(boolean isPendingLpUnverified) {
		this.isPendingLpUnverified = isPendingLpUnverified;
	}
}
/**
 * Modification History:
 * 
 * $Log: DriverLicense.java,v $
 * Revision 1.46.6.2  2014/06/03 18:08:55  mwgxd3
 * AB60 -  some cleanup and added code formatter
 *
 * Revision 1.46.6.1  2014/06/03 17:50:03  mwgxd3
 * AB60 -  add AB60 indicators to DriverLicense
 *
 * Revision 1.46  2012/11/01 21:54:10  mwgxd3
 * AB91 - add iidIndicator
 *
 * Revision 1.45  2012/04/17 22:26:48  mwsec2
 * AKTS branch code merged to Head
 *
 * Revision 1.42.10.4  2012/04/10 18:16:25  mwgxd3
 * AKTS: update getSignTestHistory() to test all possible PASSED values.
 *
 * Revision 1.42.10.3  2012/04/09 21:12:48  mwsec2
 * re-based branch with changes from Head
 *
 * Revision 1.44  2012/04/05 20:38:46  mwhys
 * Moved limitedTermFeeDueYear to License class.
 * Regenerated equals(), hashCode(), and updated copy().
 *
 * Revision 1.43  2012/03/15 23:21:19  mwpxr5
 * populateRestrictionsOfRecord() added. (Defect 7236) Committing on behalf of Hari (mwhys)
 *
 * Revision 1.42  2011/05/21 02:07:15  mwhys
 * Added 2 new fields commercialTestResultGroupOnRecord,
 * driveAndLawTestResultGroupOnRecord.
 * Regenerated equals, hashCode, and updated copy methods.
 *
 * Revision 1.41  2011/05/04 21:48:29  mwhys
 * Added a field limitedTermFeeDueYear
 * (Update equals, hashcode, toString and copy methods)
 *
 * Revision 1.40  2011/04/07 04:04:52  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.39.2.8  2011/04/05 22:24:55  mwkfh
 * updated copy method
 *
 * Revision 1.39.2.7  2011/04/05 20:16:01  mwhys
 * setExistingCategories() was setting an empty list when the argument is a null. This is incorrect.
 *
 * Revision 1.39.2.6  2011/04/05 18:11:18  mwhys
 * Moved the code that throws exception from copy-constructor to copy-method.
 *
 * Revision 1.39.2.5  2011/04/05 00:11:45  mwkfh
 * updated copy method
 *
 * Revision 1.39.2.4  2011/04/04 23:34:35  mwkfh
 * updated copy method
 *
 * Revision 1.39.2.3  2011/04/04 23:08:41  mwkfh
 * updated copy
 *
 * Revision 1.39.2.2  2011/04/04 22:42:31  mwkfh
 * updated copy
 *
 * Revision 1.39.2.1  2011/04/04 21:05:43  mwkfh
 * updated copy and constructors
 *
 * Revision 1.39  2011/03/30 20:03:24  mwtjc1
 * using copyCodeSetElementList of CodeSetElement
 *
 * Revision 1.38  2011/03/29 22:45:43  mwtjc1
 * copy method of CodeSetElement is used
 *
 * Revision 1.37  2011/03/25 21:13:35  mwtjc1
 * copy method enhanced
 *
 * Revision 1.36  2011/02/01 01:43:07  mwjxa11
 * added null checks to avoid npr exceptions
 *
 * Revision 1.35  2011/01/31 21:09:31  mwskh1
 * added 	 previousExistingLicenseClasses and previousExistingExpirationDate
 *
 * Revision 1.34  2011/01/27 21:28:15  mwtjc1
 * previousNonCommCategories removed
 *
 * Revision 1.33  2011/01/27 21:24:15  mwtjc1
 * previousNonCommCategories added
 *
 * Revision 1.32  2011/01/27 20:50:30  mwtjc1
 * previousPendingAppliedLicenseClasses added
 *
 * Revision 1.31  2011/01/25 18:34:29  mwuxb
 * Added changes to prevent null pointers.
 *
 * Revision 1.30  2011/01/16 03:05:15  mwrka1
 * Updated cloning
 *
 * Revision 1.29  2011/01/12 19:48:46  mwrka1
 * null fix
 *
 * Revision 1.28  2011/01/12 18:38:57  mwrka1
 * deep cloning
 *
 * Revision 1.27  2010/12/30 18:16:17  mwuxb
 * Pulled up suspenseDueDate to License level, it is applicable to DL or ID.
 *
 * Revision 1.26  2010/12/18 00:36:18  mwrxn3
 * Updated
 *
 * Revision 1.25  2010/12/13 19:23:53  mwrxn3
 * Removed getMyCopy method and updated with copy constructor
 *
 * Revision 1.24  2010/12/12 22:30:40  mwrxn3
 * Added getMyCopy method
 *
 * Revision 1.23  2010/12/07 22:08:54  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.22  2010/12/07 03:55:14  mwpxp2
 * Removed  toString/0
 *
 * Revision 1.21  2010/12/07 02:05:22  mwpxp2
 * Added toStringOn/1, toString/0
 *
 * Revision 1.20  2010/12/02 00:15:47  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.19  2010/12/01 00:13:35  mwhys
 * Added pendingAppCategories.
 *
 * Revision 1.18  2010/11/07 22:52:26  mwrrv3
 * Modified getter methods for test result groups.
 *
 * Revision 1.17  2010/07/23 16:28:14  mwpxp2
 * Added lazy init to getAppliedLicenseClasses
 *
 * Revision 1.16  2010/07/22 17:50:32  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.15  2010/06/21 23:01:02  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.4.2.2  2010/06/20 18:07:12  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.14  2010/06/20 02:37:31  mwuxb
 * Added null check in helper methods
 *
 * Revision 1.13  2010/06/18 20:45:33  mwuxb
 * Updated addRestriction - added null check
 *
 * Revision 1.12  2010/06/17 18:09:53  mwuxb
 * List initializations to avoid null exceptions
 *
 * Revision 1.11  2010/06/17 00:51:24  mwpxr4
 * Corrected method.
 *
 * Revision 1.10  2010/06/16 21:06:42  mwpxr4
 * Methods made generic.
 *
 * Revision 1.9  2010/06/16 17:18:20  mwvxm6
 * Updated method getNewClassCodesForInterimPermitTypes
 *
 * Revision 1.8  2010/06/07 16:53:59  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.7  2010/06/05 22:14:39  mwuxb
 * update helper method of driver restrictions
 *
 * Revision 1.6  2010/06/02 20:41:58  mwrsk
 * Remove clone()
 *
 * Revision 1.5  2010/05/31 15:04:57  mwrsk
 * Clone return this mwlft1
 *
 * Revision 1.4  2010/05/28 16:12:50  mwuxb
 * Changed variable name foreignLanguage to foreignLanguageCode
 *
 * Revision 1.3  2010/05/27 14:37:54  mwrsk
 * Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 * Revision 1.2  2010/05/21 17:37:54  mwuxb
 * Updated
 *
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.43  2010/04/12 16:54:44  mwvxm6
 * Moved attribute licenseLocation from DriverLicense to License class
 *
 * Revision 1.42  2010/04/08 02:05:34  mwuxb
 * Added helper methods
 *
 * Revision 1.41  2010/04/08 01:39:13  mwuxb
 * added helper method to get issue date
 *
 * Revision 1.40  2010/04/06 01:19:41  mwrsk
 * Remove deprecated methods
 *
 * Revision 1.39  2010/04/05 18:48:09  mwpxr4
 * Moved new Minor Guarantor code from DriverLicense to License
 *
 * Revision 1.38  2010/04/02 20:17:13  mwtjc1
 * add* methods are added
 *
 * Revision 1.37  2010/04/02 20:14:02  mwtjc1
 * updated
 *
 * Revision 1.36  2010/04/02 19:52:25  mwtjc1
 * add* methods are added
 *
 * Revision 1.35  2010/04/02 19:47:56  mwtjc1
 * updated
 *
 * Revision 1.34  2010/04/02 19:41:34  mwtjc1
 * add* methods are added
 *
 * Revision 1.33  2010/04/01 23:10:44  mwuxb
 * Added attribute suspenseDueDate
 *
 * Revision 1.32  2010/03/31 23:56:04  mwuxb
 * Added attribute isRegularTerm
 *
 * Revision 1.31  2010/03/31 22:30:09  mwuxb
 * Added method getExistingInterimPermits by interim permit types
 *
 * Revision 1.30  2010/03/31 22:25:56  mwuxb
 * Added method getInterimPermits by interim permit types
 *
 * Revision 1.29  2010/03/18 18:39:30  mwuxb
 * Added attribute newMinorGuarantorCode
 *
 * Revision 1.28  2010/03/18 18:34:36  mwuxb
 * Changed minor guarantor code to existing minor guarantor code
 *
 * Revision 1.27  2010/03/18 16:21:18  mwvxm6
 * Added setter
 *
 * Revision 1.26  2010/03/15 22:22:14  mwvxm6
 * Added existing interim permits attributes
 *
 * Revision 1.25  2010/03/10 21:14:14  mwuxb
 * Updates - limitedLicenseTermYears as Integer and added renewalLicenseTermYears
 *
 * Revision 1.24  2010/03/09 03:15:13  mwuxb
 * Added attribute Returned from the Back End.
 *
 * Revision 1.23  2010/03/03 02:04:23  mwvxm6
 * Added helper methods to add new endorsements, attachments, categories and restrictions
 *
 * Revision 1.22  2010/02/26 22:41:29  mwvxm6
 * Updated attribute name to newAttachments, newCategories, newRestrictions
 *
 * Revision 1.21  2010/02/26 20:48:12  mwvxm6
 * Updated attribute name addNewEndorsements to newEndorsements
 *
 * Revision 1.20  2010/02/25 02:19:51  mwrsk
 * code cleanup
 *
 * Revision 1.19  2010/02/25 02:18:41  mwrsk
 * Remove unwanted attributes
 *
 * Revision 1.18  2010/02/24 22:50:05  mwuxb
 * Added attribute licenseExtensionCode
 *
 * Revision 1.17  2010/02/23 01:04:15  mwuxb
 * Moved attribute isCdlisPdpsInquiryMade from this class to DlApplication class
 *
 * Revision 1.16  2010/02/23 00:55:44  mwuxb
 * Added attribute isCdlisPdpsInquiryMade
 *
 * Revision 1.15  2010/02/19 03:10:35  mwrsk
 * Added InterimPermit changes
 *
 * Revision 1.14  2010/02/17 18:24:17  mwuxb
 * Added backgroundCheckIndicator attribute
 *
 * Revision 1.13  2010/02/12 00:34:58  mwhxa2
 * Restrictions are of type DrivingRestriction
 *
 * Revision 1.12  2010/02/04 18:16:30  mwrsk
 * Code cleanup
 *
 * Revision 1.11  2010/02/04 18:15:41  mwrsk
 * Update with removal of person from drivers license changes
 *
 * Revision 1.10  2010/01/28 22:44:46  mwrsk
 * Updated import statements
 *
 * Revision 1.9  2010/01/28 22:21:40  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.8  2010/01/26 18:48:29  mwhxa2
 * Changed List<String> to List<CodeSetElement>
 *
 * Revision 1.7  2010/01/12 23:20:44  mwhxa2
 * Endorsement is of type CodeSetElement
 *
 * Revision 1.6  2010/01/12 22:07:20  mwhxa2
 * Added limitedLicenseTermYears
 *
 * Revision 1.5  2010/01/07 22:45:27  mwhxa2
 * Domain Model changes - Draft 1
 *
 * Revision 1.4  2010/01/07 22:39:53  mwhxa2
 * Domain Model changes - Draft 1
 *
 * Revision 1.3  2010/01/07 18:29:31  mwhxa2
 * Domain Model changes - Draft 1
 *
 * Revision 1.2  2010/01/04 18:29:08  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.1  2009/11/23 16:25:12  mwrsk
 * Intial commit
 *
 * Revision 1.25  2009/09/15 04:41:23  mwsmg6
 * refactoring LicenseClass in DlApplication
 *
 * Revision 1.24  2009/09/13 20:45:38  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.23.2.1  2009/09/12 19:08:51  mwakg
 * Removed CodeSetElement sub classes
 *
 * Revision 1.23  2009/09/10 04:35:58  mwsmg6
 * LicenseClass
 *
 * Revision 1.22  2009/09/08 23:28:20  mwsmg6
 * removing CodeSetElement subclasses
 *
 * Revision 1.21  2009/09/02 15:55:31  mwsmg6
 * removal of CodeSetElements from the business tier
 *
 * Revision 1.20  2009/09/02 15:43:44  mwsmg6
 * removal of CodeSetElements from the business tier
 *
 * Revision 1.19  2009/08/27 05:39:51  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.18  2009/08/26 17:43:02  mwsyk1
 * Added IssuanceOtherDate variable
 *
 * Revision 1.17  2009/08/22 23:21:48  mwrrv3
 * Implemented equals and hashCode methods.
 *
 * Revision 1.16  2009/08/17 18:10:05  mwakg
 * made clone method public
 *
 * Revision 1.15  2009/08/17 18:02:51  mwakg
 * Added clone method for DriverLicense
 *
 * Revision 1.14  2009/08/13 18:07:13  mwcsj3
 * Moved getExpirationYear() method to super class
 *
 * Revision 1.13  2009/08/10 16:09:33  mwakg
 * fixed binding issues for SearchPersonByNumber
 *
 * Revision 1.12  2009/08/08 20:52:27  mwrrv3
 * Changed data type String to CodeSetElement.
 *
 * Revision 1.11  2009/08/05 19:12:04  mwrrv3
 * Created empty objects and assigned to the list in the constructor.
 *
 * Revision 1.10  2009/08/05 05:14:40  mwrrv3
 * Refactored Set to List.
 *
 * Revision 1.9  2009/08/03 20:45:37  mwrrv3
 * Added interimIssueDate and interimExpirationDate attributes.
 *
 * Revision 1.8  2009/08/03 20:41:35  mwrrv3
 * Added default constructor and created new objects in side default constructor and added comments.
 *
 * Revision 1.7  2009/07/30 01:42:44  mwrrv3
 * Changed set to list.
 *
 * Revision 1.6  2009/07/27 21:41:37  mwcsj3
 * Added class header
 *
 * Revision 1.5  2009/07/22 00:44:30  mwrrv3
 * Added comments.
 *
 * Revision 1.4  2009/07/21 18:33:58  mwrrv3
 * Modified the business objects.
 *
 * Revision 1.3  2009/07/14 23:44:30  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.2  2009-07-12 15:29:00  ppalacz
 * Bulk format
 *
 * Revision 1.1  2009-07-12 07:41:32  ppalacz
 * Moved to .impl package; added file decorations, todos
 *
 * Revision 1.1  2009-07-10 07:09:24  ppalacz
 * Synch
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3
 * $Initial ITM commit $ $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial $
 */
