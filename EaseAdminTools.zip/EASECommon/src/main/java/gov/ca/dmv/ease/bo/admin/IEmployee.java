package gov.ca.dmv.ease.bo.admin;

import gov.ca.dmv.ease.bo.tx.impl.Transaction;

import java.util.List;

/**
 * Description: I am interface for employee implementations
 * File: IEmployee.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/10/21 23:25:04 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEmployee {
	/**
	 * Gets the employee principal.
	 * 
	 * @return the employeePrincipal
	 */
	IEmployeePrincipal getEmployeePrincipal();

	/**
	 * Gets the employee tech id.
	 * 
	 * @return the employeeTechId
	 */
	String getEmployeeTechId();

	/**
	 * Gets the employee work date control.
	 * 
	 * @return the employeeWorkdateControl
	 */
	IEmployeeWorkdateControl getEmployeeWorkdateControl();

	/**
	 * @return the employeeWorkdateControlList
	 */
	List <IEmployeeWorkdateControl> getEmployeeWorkdateControls();

	/**
	 * Gets the next DL sequence number.
	 * 
	 * @return the next DL sequence number
	 */
	Integer getNextDlSequenceNumber();

	/**
	 * Gets the next VR sequence number.
	 * 
	 * @return the next VR sequence number
	 */
	Integer getNextVrSequenceNumber();

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 */
	List <Transaction> getTransactions();
}
/**
 *  Modification History:
 *
 *  $Log: IEmployee.java,v $
 *  Revision 1.2  2011/10/21 23:25:04  mwpxp2
 *  Changed referenced types to interfaces where possible
 *
 *  Revision 1.1  2011/10/21 23:21:51  mwpxp2
 *  Extracted from existing implementation
 *
 */
