/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am abstract superclass for requests operating on multiple inventory sequences
 * File: AbstractMultipleSequenceRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Jul 5, 2011 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/07/07 22:32:42 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class AbstractMultipleSequenceRequest extends
		AbstractInventoryItemsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6987043990269076333L;
	/** The ContiguousItemSequence */
	private List <IContiguousItemSequence> contiguousItemSequenceList;

	/**
	 * Instantiates a new abstract multi item request.
	 * 
	 * @param context the context
	 * @param aListOfItems the a list of items
	 */
	public AbstractMultipleSequenceRequest(IUserContext context,
			IContiguousItemSequence aSequence) {
		super(context);
		setContiguousItemSequence(aSequence);
	}

	/**
	 * Instantiates a new abstract multi item request.
	 * 
	 * @param context the context
	 * @param aListOfItems the a list of items
	 */
	public AbstractMultipleSequenceRequest(IUserContext context,
			List <IContiguousItemSequence> aSequenceList) {
		super(context);
		setContiguousItemSequenceList(aSequenceList);
	}

	/**
	 * @return the contiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		if (EaseUtil.isNullOrBlank(contiguousItemSequenceList)) {
			return null;
		}
		else {
			return getContiguousItemSequenceList().get(0);
		}
	}

	/**
	 * @return the contiguousItemSequenceList
	 */
	public List <IContiguousItemSequence> getContiguousItemSequenceList() {
		if (contiguousItemSequenceList == null) {
			setContiguousItemSequenceList(new ArrayList <IContiguousItemSequence>());
		}
		return contiguousItemSequenceList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		return getItemList().size();
	}

	/**
	 * @return the itemList
	 */
	public List <IInventoryItem> getItemList() {
		List <IInventoryItem> itemList = new ArrayList <IInventoryItem>();
		if (!EaseUtil.isNullOrBlank(contiguousItemSequenceList)) {
			for (IContiguousItemSequence itemSeq : contiguousItemSequenceList) {
				itemList.addAll(itemSeq.asItemList());
			}
		}
		return itemList;
	}

	/**
	 * @param contiguousItemSequence the contiguousItemSequence to set
	 */
	public void setContiguousItemSequence(
			IContiguousItemSequence contiguousItemSequence) {
		if (EaseUtil.isNullOrBlank(contiguousItemSequenceList)) {
			getContiguousItemSequenceList().add(contiguousItemSequence);
		}
		else {
			getContiguousItemSequenceList().set(0, contiguousItemSequence);
		}
	}

	/**
	 * @param contiguousItemSequence the contiguousItemSequence to set
	 */
	public void setContiguousItemSequenceList(
			List <IContiguousItemSequence> contiguousItemSequenceList) {
		this.contiguousItemSequenceList = contiguousItemSequenceList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractMultipleSequenceRequest.java,v $
 *  Revision 1.2  2011/07/07 22:32:42  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.1  2011/07/06 17:10:46  mwkfh
 *  updated for local inventory redesign
 *
 */
