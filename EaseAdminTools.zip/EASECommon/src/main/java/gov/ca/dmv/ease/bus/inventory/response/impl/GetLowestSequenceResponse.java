/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryItemResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am response carrying an inventory item
 * File: GetLowestSequenceResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response.impl
 * Created: Nov 3, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/11/04 16:39:19 $
 * Last Changed By: $Author: mwkfh $
 */
public class GetLowestSequenceResponse extends InventoryServiceResponse
		implements IInventoryItemResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 870420888116454356L;
	/** The issued item. */
	private IInventoryItem issuedItem;

	/**
	 * Instantiates a new inventory item response.
	 */
	protected GetLowestSequenceResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public GetLowestSequenceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public GetLowestSequenceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new inventory item response.
	 * 
	 * @param anItem the an item
	 */
	public GetLowestSequenceResponse(IInventoryItem anItem) {
		super();
		setItem(anItem);
	}

	/**
	 * Gets the issued item.
	 * 
	 * @return the issuedItem
	 */
	public IInventoryItem getItem() {
		return issuedItem;
	}

	/**
	 * Sets the issued item.
	 * 
	 * @param anItem the an item
	 */
	protected void setItem(IInventoryItem anItem) {
		issuedItem = anItem;
		if (issuedItem == null) {
			setAffectedItemCount(0);
		}
		else {
			setAffectedItemCount(1);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: GetLowestSequenceResponse.java,v $
 *  Revision 1.1  2011/11/04 16:39:19  mwkfh
 *  added GetLowestSequence
 *
 */
