/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.document.impl.Document;

import java.util.Date;
import java.util.List;

/**
 * Description: This class captures information to update a Medical Examination Report (DL51) 
 * or Health Questionnaire (DL 546) on the driver record
 * File: MedicalReportUpdate.java
 * Module:  gov.ca.dmv.ease.bo.misc
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2013/05/29 16:49:46 $
 * Last Changed By: $Author: mwskh1 $
 */
public class MedicalReportUpdateApplication extends Application {
	private static final long serialVersionUID = -811007569006952640L;
	/** This represents the attachmentCode (51 - Medical Report...) */
	private CodeSetElement attachmentCode;
	/** The List of all non supporting documents - documents to be printed during transaction*/
	// can extend Application ?
	private List <Document> documents;
	/** This represents the medical Exam Expiration Date. */
	private Date medicalExamExpirationDate;
	/** Indicates that a review of medical documents is required. */
	private Boolean medicalHqReviewRequiredIndicator;

	/**
	 * Instantiates a new application.
	 */
	public MedicalReportUpdateApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the attachmentCode
	 */
	public CodeSetElement getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * @return the documents
	 */
	@Override
	public List <Document> getDocuments() {
		return documents;
	}

	/**
	 * @return the medicalExamExpirationDate
	 */
	public Date getMedicalExamExpirationDate() {
		return medicalExamExpirationDate;
	}

	/**
	 * returns whether a medical document review is required at HQ
	 * 
	 * @return
	 */
	public Boolean getMedicalHqReviewRequiredIndicator() {
		return medicalHqReviewRequiredIndicator;
	}

	/**
	 * @param attachmentCode the attachmentCode to set
	 */
	public void setAttachmentCode(CodeSetElement attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * @param documents the documents to set
	 */
	@Override
	public void setDocuments(List <Document> documents) {
		this.documents = documents;
	}

	/**
	 * @param medicalExamExpirationDate the medicalExamExpirationDate to set
	 */
	public void setMedicalExamExpirationDate(Date medicalExamExpirationDate) {
		this.medicalExamExpirationDate = medicalExamExpirationDate;
	}

	/**
	 * Sets whether an HQ review of medical documents is required
	 * 
	 * @param medicalHqReviewRequired
	 */
	public void setMedicalHqReviewRequiredIndicator(
			Boolean medicalHqReviewRequiredIndicator) {
		this.medicalHqReviewRequiredIndicator = medicalHqReviewRequiredIndicator;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: MedicalReportUpdateApplication.java,v $
 *  Revision 1.9  2013/05/29 16:49:46  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *  Revision 1.8.12.3  2013/05/13 14:54:46  mwskh1
 *  CDLIS 5.2 - added history log
 *
 *
 */
