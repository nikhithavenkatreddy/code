/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.subject.impl.InsuranceCompany;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: //TODO - provide description!
 * File: InsurancePolicy.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/09/04 18:12:34 $
 * Last Changed By: $Author: mwhys $
 */
public class InsurancePolicy implements Serializable {

	private static final long serialVersionUID = 2344103133668221545L;
	/** The policy effective date. */
	private Date effectiveDate;
	/** The Mailing Address on the Insurance Certificate. */
	private Address insuranceCertificateMailingAddress;
	/** The Residence Address on the Insurance Certificate. */
	private Address insuranceCertificateResidenceAddress;
	/** The Insurance Company */
	private InsuranceCompany insuranceCompany;
	/** The Policy Number or Insurance Certificate  */
	private String policyNumber;
	/** The date the Insurance Certificate is received. */
	private Date receiptDate;
	/** The SR 22/SR 1P insurance certificate as FR proof */
	private CodeSetElement typeCertificateCode;
	/** U - Owners, T - Operators */
	private CodeSetElement typeOfCoverageCode;

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @return the insuranceCertificateMailingAddress
	 */
	public Address getInsuranceCertificateMailingAddress() {
		return insuranceCertificateMailingAddress;
	}

	/**
	 * @return the insuranceCertificateResidenceAddress
	 */
	public Address getInsuranceCertificateResidenceAddress() {
		return insuranceCertificateResidenceAddress;
	}

	/**
	 * @return the insuranceCompany
	 */
	public InsuranceCompany getInsuranceCompany() {
		return insuranceCompany;
	}

	/**
	 * @return the policyNumber
	 */
	public String getPolicyNumber() {
		return policyNumber;
	}

	/**
	 * @return the receiptDate
	 */
	public Date getReceiptDate() {
		return receiptDate;
	}

	/**
	 * @return the typeCertificateCode
	 */
	public CodeSetElement getTypeCertificateCode() {
		return typeCertificateCode;
	}

	/**
	 * @return the typeOfCoverageCode
	 */
	public CodeSetElement getTypeOfCoverageCode() {
		return typeOfCoverageCode;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @param insuranceCertificateMailingAddress the insuranceCertificateMailingAddress to set
	 */
	public void setInsuranceCertificateMailingAddress(
			Address insuranceCertificateMailingAddress) {
		this.insuranceCertificateMailingAddress = insuranceCertificateMailingAddress;
	}

	/**
	 * @param insuranceCertificateResidenceAddress the insuranceCertificateResidenceAddress to set
	 */
	public void setInsuranceCertificateResidenceAddress(
			Address insuranceCertificateResidenceAddress) {
		this.insuranceCertificateResidenceAddress = insuranceCertificateResidenceAddress;
	}

	/**
	 * @param insuranceCompany the insuranceCompany to set
	 */
	public void setInsuranceCompany(InsuranceCompany insuranceCompany) {
		this.insuranceCompany = insuranceCompany;
	}

	/**
	 * @param policyNumber the policyNumber to set
	 */
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	/**
	 * @param receiptDate the receiptDate to set
	 */
	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	/**
	 * @param typeCertificateCode the typeCertificateCode to set
	 */
	public void setTypeCertificateCode(CodeSetElement typeCertificateCode) {
		this.typeCertificateCode = typeCertificateCode;
	}

	/**
	 * @param typeOfCoverageCode the typeOfCoverageCode to set
	 */
	public void setTypeOfCoverageCode(CodeSetElement typeOfCoverageCode) {
		this.typeOfCoverageCode = typeOfCoverageCode;
	}
}
