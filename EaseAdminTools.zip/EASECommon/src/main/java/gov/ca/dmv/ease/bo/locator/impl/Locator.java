/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009 
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/** 
 * Description: Locator is the super class capturing the common attributes of 
 * physical or virtual locations. 
 * File: Locator.java
 * Module:  gov.ca.dmv.ease.bo.locator
 * Created: Apr 28, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/04/07 04:04:54 $
 * Last Changed By: $Author: mwhys $
 */
public abstract class Locator extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6139050214468268678L;
	/** The effective date. */
	private Date effectiveDate;
	/** The end date. */
	private Date endDate;
	
	/**
	 * Instantiates a new Locator object.
	 * 
	 * @param object to copy 
	 */
	public Locator() {
		super();
	}
	
	/**
	 * Instantiates a new Locator object.
	 * 
	 * @param object to copy 
	 */
	public Locator(Locator locator) {
		super();
		copy(locator);
	}
	
	/**
	 * Method to copy the Locator object.
	 * 
	 * @param objectToCopy
	 */
	protected void copy(Locator objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null locator argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		if (EaseUtil.isNotNull(objectToCopy.getEffectiveDate())) {
			setEffectiveDate(new Date(objectToCopy.getEffectiveDate().getTime()));
		}
		else {
			setEffectiveDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getEndDate())) {
			setEndDate(new Date(objectToCopy.getEndDate().getTime()));
		}
		else {
			setEndDate(null);
		}
	}
	
	/**
	 * Gets the effective date.
	 * 
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	
	/**
	 * Gets the end date.
	 * 
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	
	/**
	 * Sets the effective date.
	 * 
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	/**
	 * Sets the end date.
	 * 
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Locator other = (Locator) obj;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		}
		else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		}
		else if (!endDate.equals(other.endDate))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Locator.java,v $
 *  Revision 1.3  2011/04/07 04:04:54  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.2.32.7  2011/04/05 18:09:28  mwhys
 *  Updated.
 *
 *  Revision 1.2.32.6  2011/04/05 18:08:13  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.2.32.5  2011/04/05 17:38:50  mwhys
 *  Updated copy constructor and method.
 *
 *  Revision 1.2.32.4  2011/04/04 19:00:51  mwkfh
 *  added null check to copy
 *
 *  Revision 1.2.32.3  2011/04/04 18:33:00  mwkfh
 *  added super.copy to copy
 *
 *  Revision 1.2.32.2  2011/04/04 16:57:11  mwkfh
 *  added copy and copy constructor
 *
 *  Revision 1.2.32.1  2011/04/04 00:55:38  mwrrv3
 *  Regenerated equals() and hashCode() methods.
 *
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.6  2010/03/19 01:41:09  mwrsk
 *  cleanup imports
 *
 *  Revision 1.5  2010/03/03 21:30:03  mwrsk
 *  Added serviceVerificationCode
 *
 *  Revision 1.4  2010/02/16 20:17:31  mwuxb
 *  Changed Boolean valid to CodeSetElement addressValidityCode
 *
 *  Revision 1.3  2010/02/11 23:49:19  mwrsk
 *  Removed person reference
 *
 *  Revision 1.2  2010/01/28 22:36:48  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:21  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/08/27 05:39:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2009/08/22 23:22:09  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.4  2009/08/13 00:04:18  mwrrv3
 *  Added comments.
 *
 *  Revision 1.3  2009/08/03 23:46:25  mwrrv3
 *  Code formatted and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:39  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:44:15  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
