/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence;

import java.io.Serializable;

/**
 * Description: I am interface for manipulating Sequence Patterns
 * File: ISequencePattern.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 3, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/09/08 01:56:22 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequencePattern extends Serializable {
	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	String getDescription();

	/**
	 * Gets the lower sequence boundary.
	 * 
	 * @return the lower sequence boundary
	 */
	String getLowerSequenceBoundary();

	/**
	 * Gets the size.
	 * 
	 * @return the size
	 */
	int getSize();

	/**
	 * Gets the upper sequence boundary.
	 * 
	 * @return the upper sequence boundary
	 */
	String getUpperSequenceBoundary();

	/**
	 * As string.
	 * 
	 * @return the string
	 */
	String getValue();
}
/**
 *  Modification History:
 *
 *  $Log: ISequencePattern.java,v $
 *  Revision 1.3  2010/09/08 01:56:22  mwpxp2
 *  Formatting
 *
 *  Revision 1.2  2010/09/07 22:57:27  mwpxp2
 *  Added 3 accessors
 *
 *  Revision 1.1  2010/09/04 05:53:51  mwpxp2
 *  Initial, in progress
 *
 */
