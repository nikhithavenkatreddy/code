/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl;

/**
 * Description: The purpose of this class is to encapsulate the header information of CDLIS/PDPS.
 * File: CdlisPdpsHeaderInfo.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl
 * Created: Mar 23, 2010 
 * @author MWVKM  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:28 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CdlisPdpsHeaderInfo {
	/* AKA DL number count */
	private int akaDlNumberCount;
	/* AKA SSN count */
	private int akaSsNumberCount;
	/* Application ID */
	private int applicationId;
	/* Error Indicator */
	private String errorIndicator;
	/* Match Count */
	private int matchCount;
	/* Match Indicator */
	private String matchIndicator;
	/* Match limit indicator */
	private String matchLimitIndicator;
	/* Match sequence number ID */
	private int matchSequenceNumberId;
	/* Message Type */
	private String messageType;
	/* State of origin */
	private String stateOfOrigin;
	/* State of record code */
	private String stateOfRecordCode;

	/**
	 * Simple getter for akaDlNumberCount.
	 * 
	 * @return
	 */
	public int getAkaDlNumberCount() {
		return akaDlNumberCount;
	}

	/**
	 * Simple getter for akaSsNumberCount.
	 * 
	 * @return
	 */
	public int getAkaSsNumberCount() {
		return akaSsNumberCount;
	}

	/**
	 * Simple getter for applicationId.
	 * 
	 * @return
	 */
	public int getApplicationId() {
		return applicationId;
	}

	/**
	 * Simple getter for errorIndicator.
	 * @return
	 */
	public String getErrorIndicator() {
		return errorIndicator;
	}

	/**
	 * Simple getter for matchCount.
	 * 
	 * @return
	 */
	public int getMatchCount() {
		return matchCount;
	}

	/**
	 * Simple getter for matchIndicator.
	 * 
	 * @return
	 */
	public String getMatchIndicator() {
		return matchIndicator;
	}

	/**
	 * Simple getter for matchLimitIndicator.
	 * 
	 * @return
	 */
	public String getMatchLimitIndicator() {
		return matchLimitIndicator;
	}

	/**
	 * Simple getter for matchSequenceNumberId.
	 * @return
	 */
	public int getMatchSequenceNumberId() {
		return matchSequenceNumberId;
	}

	/**
	 * Simple getter for messageType.
	 * 
	 * @return
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * Simple getter for stateOfOrigin.
	 * 
	 * @return
	 */
	public String getStateOfOrigin() {
		return stateOfOrigin;
	}

	/**
	 * Simple getter for stateOfRecordCode.
	 * 
	 * @return
	 */
	public String getStateOfRecordCode() {
		return stateOfRecordCode;
	}

	/**
	 * Simple setter for akaDlNumberCount.
	 * 
	 * @param akaDlNumberCount
	 */
	public void setAkaDlNumberCount(int akaDlNumberCount) {
		this.akaDlNumberCount = akaDlNumberCount;
	}

	/**
	 * Simple setter for akaSsNumberCount.
	 * 
	 * @param akaSsNumberCount
	 */
	public void setAkaSsNumberCount(int akaSsNumberCount) {
		this.akaSsNumberCount = akaSsNumberCount;
	}

	/**
	 * Simple setter for applicationId.
	 * 
	 * @param applicationId
	 */
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * Simple setter for errorIndicator.
	 * @param errorIndicator
	 */
	public void setErrorIndicator(String errorIndicator) {
		this.errorIndicator = errorIndicator;
	}

	/**
	 * Simple setter for matchCount.
	 * 
	 * @param matchCount
	 */
	public void setMatchCount(int matchCount) {
		this.matchCount = matchCount;
	}

	/**
	 * Simple setter for matchIndicator.
	 * 
	 * @param matchIndicator
	 */
	public void setMatchIndicator(String matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	/**
	 * Simple setter for matchLimitIndicator.
	 * 
	 * @param matchLimitIndicator
	 */
	public void setMatchLimitIndicator(String matchLimitIndicator) {
		this.matchLimitIndicator = matchLimitIndicator;
	}

	/**
	 * Simple setter for matchSequenceNumberId.
	 * 
	 * @param matchSequenceNumberId
	 */
	public void setMatchSequenceNumberId(int matchSequenceNumberId) {
		this.matchSequenceNumberId = matchSequenceNumberId;
	}

	/**
	 * Simple setter for messageType.
	 * 
	 * @param messageType
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * Simple setter for stateOfOrigin.
	 * 
	 * @param stateOfOrigin
	 */
	public void setStateOfOrigin(String stateOfOrigin) {
		this.stateOfOrigin = stateOfOrigin;
	}

	/**
	 * Simple setter for stateOfRecordCode.
	 * 
	 * @param stateOfRecordCode
	 */
	public void setStateOfRecordCode(String stateOfRecordCode) {
		this.stateOfRecordCode = stateOfRecordCode;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CdlisPdpsHeaderInfo.java,v $
 *  Revision 1.2  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/03/25 19:11:03  mwvkm
 *  Modified the code for CDU as per the match logic document that the development had received.
 *
 */
