/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.conversion.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.impl.ContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.impl.Sequence;
import gov.ca.dmv.ease.bo.sequence.impl.SequencePatternFactory;
import gov.ca.dmv.ease.fw.exception.impl.EaseConversionException;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am a utility to convert inventory item sequences
 * File: ContiguousItemSequenceConverter.java
 * Module:  gov.ca.dmv.ease.bo.sequence.conversion.impl
 * Created: Dec 6, 2010 
 * @author MWKFH  
 * @version $Revision: 1.12 $
 * Last Changed: $Date: 2011/01/07 17:43:08 $
 * Last Changed By: $Author: mwkfh $
 */
public class ContiguousItemSequenceConverter {
	/** The SINGLETON. */
	private static ContiguousItemSequenceConverter SINGLETON;

	/**
	 * Gets the single instance of ContiguousItemSequenceConverter.
	 * 
	 * @return single instance of ContiguousItemSequenceConverter
	 */
	public static ContiguousItemSequenceConverter getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new ContiguousItemSequenceConverter();
	}

	/**
	 * Returns the next sequence in the list otherwise returns null
	 * 
	 * @param sequenceNo
	 * @param sequenceList
	 * 
	 * @return nextSequenceNo
	 */
	private String getNextSequenceNo(String sequenceNo,
			List <ISequence> sequenceList) {
		int index = 0;
		while (index < sequenceList.size() - 1) {
			if ((sequenceList.get(++index - 1).getSequenceNo()
					.equals(sequenceNo))
					|| (sequenceList.get(index - 1).getSequenceNo().trim()
							.equals(sequenceNo.trim()))) {
				return sequenceList.get(index).getSequenceNo();
			}
		}
		return null;
	}

	/**
	 * Returns the previous sequence in the list otherwise returns null
	 * 
	 * @param sequenceNo
	 * @param sequenceList
	 * 
	 * @return nextSequenceNo
	 */
	private String getPreviousSequenceNo(String sequenceNo,
			List <ISequence> sequenceList) {
		int index = -1;
		while (++index < sequenceList.size() - 1) {
			if ((sequenceList.get(index + 1).getSequenceNo().equals(sequenceNo))
					|| (sequenceList.get(index + 1).getSequenceNo().trim()
							.equals(sequenceNo.trim()))) {
				return sequenceList.get(index).getSequenceNo();
			}
		}
		return null;
	}

	/**
	 * Sorts and merges a list of ContiguousitemSequence
	 * 
	 * @param listToMerge
	 * 
	 * @return sorted and merged contiguous sequence list
	 */
	public List <IContiguousItemSequence> mergeSortSequencesIn(
			List <IContiguousItemSequence> listToMerge) {
		if (listToMerge == null || listToMerge.size() < 2) {
			return listToMerge;
		}
		else {
			List <IContiguousItemSequence> mergedList = new ArrayList <IContiguousItemSequence>();
			List <IContiguousItemSequence> sortedList = sortSequencesIn(listToMerge);
			mergedList.add(sortedList.get(0));
			IContiguousItemSequence lastMergedItem;
			ISequence nextSequence;
			for (IContiguousItemSequence sortedItem : sortedList) {
				lastMergedItem = mergedList.get(mergedList.size() - 1);
				nextSequence = (new Sequence(
						lastMergedItem.getUpperBoundary(),
						SequencePatternFactory
								.getInstance()
								.getSequencePatternForCode(
										lastMergedItem.getItemType().getCode(),
										lastMergedItem.getLowerBoundary(), null)))
						.nextSequence();
				if ((!sortedItem.getItemType().getCode().equals(
						lastMergedItem.getItemType().getCode()))
						|| (sortedItem.getLowerBoundary().compareTo(
								nextSequence.getValue()) > 0)) {
					mergedList.add(sortedItem);
				}
				else if (sortedItem.getUpperBoundary().compareTo(
						lastMergedItem.getUpperBoundary()) > 0) {
					//merge with last item
					mergedList.set(mergedList.size() - 1,
							new ContiguousItemSequence(lastMergedItem
									.getItemType().getCode(), lastMergedItem
									.getOfficeId(), lastMergedItem
									.getStationId(), lastMergedItem
									.getLowerBoundary(), sortedItem
									.getUpperBoundary(), lastMergedItem
									.getSequenceCount()
									+ sortedItem.getSequenceCount(),
									lastMergedItem.isDrawnFromHq()));
				}
			}
			return mergedList;
		}
	}

	/**
	 * Removes the items in the toRemove from the removeFrom and returns
	 * the resulting list of remaining items as ConyiguousItemSequence list.
	 * 
	 * @param removeFrom
	 * @param toRemove
	 * 
	 * @return contiguous sequence list
	 */
	public List <IContiguousItemSequence> removeItemSequenceFrom(
			IContiguousItemSequence removeFrom, IContiguousItemSequence toRemove) {
		List <IContiguousItemSequence> resultingItemSequenceList = new ArrayList <IContiguousItemSequence>();
		if (removeFrom != null
				&& toRemove != null
				&& removeFrom.getItemType().getCode().equals(
						toRemove.getItemType().getCode())
				&& toRemove.getItemCount() > 0) {
			if ((removeFrom.getLowerBoundary().compareTo(
					toRemove.getUpperBoundary()) > 0)
					|| (removeFrom.getUpperBoundary().compareTo(
							toRemove.getLowerBoundary()) < 0)) {
				//keep all
				resultingItemSequenceList.add(removeFrom);
			}
			else if ((removeFrom.getLowerBoundary().compareTo(
					toRemove.getLowerBoundary()) >= 0)
					&& (removeFrom.getUpperBoundary().compareTo(
							toRemove.getUpperBoundary()) <= 0)) {
				//remove all
			}
			else {
				//remove overlap
				List <ISequence> removeFromList = ((ContiguousItemSequence) removeFrom)
						.getSequenceNoList();
				if (removeFrom.getLowerBoundary().compareTo(
						toRemove.getLowerBoundary()) < 0) {
					if (removeFrom.getUpperBoundary().compareTo(
							toRemove.getUpperBoundary()) <= 0) {
						resultingItemSequenceList
								.add(new ContiguousItemSequence(removeFrom
										.getItemType().getCode(), removeFrom
										.getOfficeId(), removeFrom
										.getStationId(), removeFrom
										.getLowerBoundary(),
										getPreviousSequenceNo(toRemove
												.getLowerBoundary(),
												removeFromList), removeFrom
												.isDrawnFromHq()));
					}
					else {
						resultingItemSequenceList
								.add(new ContiguousItemSequence(removeFrom
										.getItemType().getCode(), removeFrom
										.getOfficeId(), removeFrom
										.getStationId(), removeFrom
										.getLowerBoundary(),
										getPreviousSequenceNo(toRemove
												.getLowerBoundary(),
												removeFromList), removeFrom
												.isDrawnFromHq()));
						resultingItemSequenceList
								.add(new ContiguousItemSequence(removeFrom
										.getItemType().getCode(), removeFrom
										.getOfficeId(), removeFrom
										.getStationId(), getNextSequenceNo(
										toRemove.getUpperBoundary(),
										removeFromList), removeFrom
										.getUpperBoundary(), removeFrom
										.isDrawnFromHq()));
					}
				}
				else {
					resultingItemSequenceList.add(new ContiguousItemSequence(
							removeFrom.getItemType().getCode(), removeFrom
									.getOfficeId(), removeFrom.getStationId(),
							getNextSequenceNo(toRemove.getUpperBoundary(),
									removeFromList), removeFrom
									.getUpperBoundary(), removeFrom
									.isDrawnFromHq()));
				}
			}
		}
		else if (removeFrom != null) {
			resultingItemSequenceList.add(removeFrom);
		}
		return resultingItemSequenceList;
	}

	/**
	 * Sorts list of ContiguousitemSequence
	 * 
	 * @param listToSort
	 * 
	 * @return sorted contiguous sequence list
	 */
	private List <IContiguousItemSequence> sortSequencesIn(
			List <IContiguousItemSequence> listToSort) {
		//Note: this list most likely short
		List <IContiguousItemSequence> resultingItemSequenceList = new ArrayList <IContiguousItemSequence>();
		int index;
		for (IContiguousItemSequence toSortItem : listToSort) {
			index = 0;
			for (IContiguousItemSequence sortedItem : resultingItemSequenceList) {
				if ((toSortItem.getItemType().getCode().compareTo(
						sortedItem.getItemType().getCode()) > 0)
						|| (toSortItem.getLowerBoundary().compareTo(
								sortedItem.getLowerBoundary()) > 0)) {
					index++;
				}
			}
			resultingItemSequenceList.add(index, toSortItem);
		}
		return resultingItemSequenceList;
	}

	/**
	 * Converts an inventory item list to an contiguous items sequence list.  It assumes
	 * all items in the list are from the same location and of the same type and are in 
	 * sequence order.
	 * 
	 * @param anItemList
	 * 
	 * @return contiguous sequence list
	 */
	public List <IContiguousItemSequence> toItemSequenceListFrom(
			List <IInventoryItem> anItemList) {
		List <IContiguousItemSequence> aContiguousItemSequenceList = new ArrayList <IContiguousItemSequence>();
		if (anItemList != null && !anItemList.isEmpty()) {
			int size = anItemList.size();
			String stationId = null;
			if (anItemList.get(0) instanceof StationLocalInventoryItem) {
				stationId = anItemList.get(0).getStationId();
			}
			ContiguousItemSequence aContiguousSequenceItem = new ContiguousItemSequence(
					anItemList.get(0).getType().getCode(), anItemList.get(0)
							.getOfficeId(), stationId, 0, anItemList.get(0)
							.getSequenceNo().getValue(), anItemList.get(
							size - 1).getSequenceNo().getValue(), false);
			List <ISequence> aSequenceItemList = aContiguousSequenceItem
					.getSequenceNoList();
			if (aSequenceItemList.size() == anItemList.size()) {
				//in order
				aContiguousSequenceItem = new ContiguousItemSequence(
						aContiguousSequenceItem.getItemType().getCode(),
						aContiguousSequenceItem.getOfficeId(), stationId,
						aContiguousSequenceItem.getLowerBoundary(),
						aContiguousSequenceItem.getUpperBoundary(), anItemList
								.size(), false);
				aContiguousItemSequenceList.add(aContiguousSequenceItem);
				return aContiguousItemSequenceList;
			}
			else if (aSequenceItemList.size() < anItemList.size()) {
				throw new EaseConversionException("INVALID SEQUENCE LIST");
			}
			//create contiguous sequence list by finding the breaks
			int sequenceCount;
			int indexSequenceList = 0;
			int indexItemList = 0;
			ISequence sequenceItem = aSequenceItemList.get(indexSequenceList);
			IInventoryItem inventoryItem = anItemList.get(indexItemList);
			String lowerBoundary;
			String upperBoundary;
			while (indexItemList < anItemList.size()) {
				sequenceCount = 0;
				lowerBoundary = inventoryItem.getSequenceNo().getValue();
				upperBoundary = lowerBoundary;
				while ((indexSequenceList < aSequenceItemList.size())
						&& (indexItemList < anItemList.size())
						&& sequenceItem.getSequenceNo().equals(
								inventoryItem.getSequenceNo().getValue())) {
					upperBoundary = inventoryItem.getSequenceNo().getValue();
					indexItemList++;
					indexSequenceList++;
					if ((indexSequenceList < aSequenceItemList.size())
							&& (indexItemList < anItemList.size())) {
						inventoryItem = anItemList.get(indexItemList);
						sequenceItem = aSequenceItemList.get(indexSequenceList);
					}
					sequenceCount++;
				}
				aContiguousItemSequenceList.add(new ContiguousItemSequence(
						inventoryItem.getType().getCode(), inventoryItem
								.getOfficeId(), stationId, lowerBoundary,
						upperBoundary, sequenceCount, false));
				while ((indexSequenceList < aSequenceItemList.size())
						&& !sequenceItem.getSequenceNo().equals(
								inventoryItem.getSequenceNo().getValue())) {
					sequenceItem = aSequenceItemList.get(++indexSequenceList);
				}
			}
		}
		return aContiguousItemSequenceList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ContiguousItemSequenceConverter.java,v $
 *  Revision 1.12  2011/01/07 17:43:08  mwkfh
 *  added exception for invalid list
 *
 *  Revision 1.11  2010/12/31 01:29:52  mwkfh
 *  fixed boundaries with count call before processing removeItemSequenceFrom
 *
 *  Revision 1.10  2010/12/31 01:12:42  mwkfh
 *  updated removeItemSequenceFrom
 *
 *  Revision 1.9  2010/12/30 19:35:22  mwkfh
 *  added type sorting to sortSequencesIn
 *
 *  Revision 1.8  2010/12/30 19:28:57  mwkfh
 *  added type code check to mergeSortSequencesIn
 *
 *  Revision 1.7  2010/12/30 19:19:36  mwkfh
 *  added mergeSortSequencesIn
 *
 *  Revision 1.6  2010/12/18 01:21:21  mwkfh
 *  added check for same item type in removeItemSequenceFrom
 *
 *  Revision 1.5  2010/12/16 18:44:20  mwrrv2
 *  Fixed removeItemSequenceFrom function-Kurt.
 *
 *  Revision 1.4  2010/12/16 01:19:59  mwkfh
 *  updated removeItemSequenceFrom to return from if to null
 *
 *  Revision 1.3  2010/12/15 23:21:37  mwkfh
 *  added removeItemSequenceFrom
 *
 *  Revision 1.2  2010/12/07 21:01:37  mwkfh
 *  updated toItemSequenceListFrom to work with split sequences
 *
 *  Revision 1.1  2010/12/07 19:30:48  mwkfh
 *  converts inventory item list to contiguous sequence list
 *
 */
