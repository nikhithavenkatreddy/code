/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.AuthorizeWorkDateResponse;
import gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService;

/**
 * Description: I represent the request to retrieve object from the persistent store
 * File: AssignDafNumberRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 17, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/20 22:35:56 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class AuthorizeWorkDateRequest extends PersistenceServiceRequest {
	private static final long serialVersionUID = 1759593206330372926L;
	private boolean isWorkDate;
	private boolean status;
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public AuthorizeWorkDateResponse execute() {
		return ((ITransactionPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Instantiates a new issue local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public AuthorizeWorkDateRequest(IUserContext userContext,
			boolean isWorkDate, boolean status) {
		super(userContext);
		setWorkDate(isWorkDate);
		setStatus(status);
	}

	/**
	 * @param isWorkDate the isWorkDate to set
	 */
	public void setWorkDate(boolean isWorkDate) {
		this.isWorkDate = isWorkDate;
	}

	/**
	 * @return the isWorkDate
	 */
	public boolean isWorkDate() {
		return isWorkDate;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * @return the status
	 */
	public boolean isStatus() {
		return status;
	}
	
}
/**
 *  Modification History:
 *
 *  $Log: AuthorizeWorkDateRequest.java,v $
 *  Revision 1.1  2011/10/20 22:35:56  mwrrv3
 *  Initial Commit - Performance Change
 *
 */
