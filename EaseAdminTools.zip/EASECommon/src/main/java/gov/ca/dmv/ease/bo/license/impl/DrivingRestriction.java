/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: This represents the driving restrictions on a driver license.
 * File: DrivingRestriction.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Jul 27, 2009
 * @author MWCSJ3
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2011/04/07 04:04:52 $
 * Last Changed By: $Author: mwhys $
 */
public class DrivingRestriction implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2951100952814177088L;
	
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}
	
	/** Holds driving license restriction effective date. */
	private Date effectiveDate;
	/** Holds driving license restriction expiration date. */
	private Date expirationDate;
	/** Holds driving license restriction type code. */
	private CodeSetElement restrictionTypeCode;
	
	/**
	 * Instantiates a new driving restriction.
	 */
	public DrivingRestriction() {
		//restrictionTypeCode = new ArrayList <RestrictionCode>();
	}
	
	/**
	 * Instantiates a new driving restriction.
	 *
	 * @param dataCopy the data copy
	 */
	public DrivingRestriction(DrivingRestriction objectToCopy) {
		super();
		copy(objectToCopy);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataCopy the data copy
	 */
	private void copy(DrivingRestriction objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy method for " + this);
		}
		if (EaseUtil.isNotNull(objectToCopy.getEffectiveDate())) {
			setEffectiveDate(new Date(objectToCopy.getEffectiveDate().getTime()));
		}
		else {
			setEffectiveDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getExpirationDate())) {
			setExpirationDate(new Date(objectToCopy.getExpirationDate()
					.getTime()));
		}
		else {
			setExpirationDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getRestrictionTypeCode())) {
			setRestrictionTypeCode(new CodeSetElement(objectToCopy
					.getRestrictionTypeCode()));
		}
		else {
			setRestrictionTypeCode(null);
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DrivingRestriction other = (DrivingRestriction) obj;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		}
		else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		}
		else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (restrictionTypeCode == null) {
			if (other.restrictionTypeCode != null)
				return false;
		}
		else if (!restrictionTypeCode.equals(other.restrictionTypeCode))
			return false;
		return true;
	}
	
	/**
	 * Gets the effective date.
	 * 
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	
	/**
	 * Gets the expiration date.
	 * 
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}
	
	/**
	 * Gets the restriction type code.
	 * 
	 * @return the restrictionTypeCode
	 */
	public CodeSetElement getRestrictionTypeCode() {
		return restrictionTypeCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result
				+ ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime
				* result
				+ ((restrictionTypeCode == null) ? 0 : restrictionTypeCode
						.hashCode());
		return result;
	}
	
	/**
	 * Sets the effective date.
	 * 
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	/**
	 * Sets the expiration date.
	 * 
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	/**
	 * Sets the restriction type code.
	 * 
	 * @param restrictionTypeCode the restrictionTypeCode to set
	 */
	public void setRestrictionTypeCode(CodeSetElement restrictionTypeCode) {
		this.restrictionTypeCode = restrictionTypeCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(64);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}
	
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("effectiveDate", effectiveDate, anIndent, aBuilder);
		outputKeyValue("expirationDate", expirationDate, anIndent, aBuilder);
		outputKeyValue("restrictionTypeCode", restrictionTypeCode, anIndent,
				aBuilder);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DrivingRestriction.java,v $
 *  Revision 1.10  2011/04/07 04:04:52  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.9.6.3  2011/04/05 18:12:36  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.9.6.2  2011/04/04 23:29:47  mwkfh
 *  updated copy method
 *
 *  Revision 1.9.6.1  2011/04/03 21:06:43  mwrrv3
 *  Copy Constructor Functionality Implemented -- Amar Bade
 *
 *  Revision 1.9  2011/01/16 03:05:32  mwrka1
 *  Updated cloning
 *
 *  Revision 1.8  2011/01/13 01:48:25  mwrka1
 *  Updated
 *
 *  Revision 1.7  2011/01/12 18:40:28  mwrka1
 *  deep cloning
 *
 *  Revision 1.6  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 03:55:29  mwpxp2
 *  Added toStringOn/1, toString/0; sorted
 *
 *  Revision 1.4  2010/06/21 23:01:02  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.2.2  2010/06/20 18:07:13  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/05/27 14:37:54  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.6  2010/03/15 20:27:43  mwhxa2
 *  Implements serializable
 *
 *  Revision 1.5  2010/03/03 16:08:13  mwrsk
 *  cleanup imports
 *
 *  Revision 1.4  2010/02/25 01:01:08  mwrsk
 *  DrivingRestriction changes
 *
 *  Revision 1.3  2010/01/13 01:20:32  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/09/01 21:25:18  mwrrv3
 *  Added generated Serializable UID.
 *
 *  Revision 1.8  2009/08/27 05:39:52  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2009/08/05 05:52:50  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.6  2009/08/04 17:05:47  mwrsk
 *  Remove Hibernate annotations
 *
 *  Revision 1.5  2009/07/27 21:41:37  mwcsj3
 *  Added class header
 *
 *  Revision 1.4  2009/07/21 18:33:58  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.3  2009/07/14 23:44:31  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:29:00  ppalacz
 *  Bulk format
 *
 *  Revision 1.1  2009-07-12 07:41:32  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 10:53:13 AM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 10:53:13 AM  MWCSJ3
 *  $Initial
 *  $
 */
