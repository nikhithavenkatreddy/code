/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service;

import gov.ca.dmv.ease.tus.persist.request.impl.AssignDafNumberRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.AuthorizeWorkDateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.AssignDafNumberResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.AuthorizeWorkDateResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;

// TODO: Auto-generated Javadoc
/**
 * Description: I am the interface to the transaction persistence service. 
 * File: ITransactionPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service
 * Created: Dec 17, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/10/20 22:35:20 $
 * Last Changed By: $Author: mwrrv3 $
 */
public interface ITransactionPersistenceService {
	/**
	 * Execute.
	 * 
	 * @param assignDafNumberRequest the assignDafNumberRequest persistence request
	 * 
	 * @return the persistence service response
	 */
	AssignDafNumberResponse execute(
			AssignDafNumberRequest assignDafNumberRequest);

	/**
	 * Execute.
	 * 
	 * @param request the request
	 * 
	 * @return the persistence service response
	 */
	PersistenceServiceResponse execute(UpdateDafRecordPersistenceRequest request);
	
	/**
	 * Execute.
	 *
	 * @param request the request
	 * @return the authorize work date response
	 */
	AuthorizeWorkDateResponse execute(AuthorizeWorkDateRequest request);
}
/**
 *  Modification History:
 *
 *  $Log: ITransactionPersistenceService.java,v $
 *  Revision 1.3  2011/10/20 22:35:20  mwrrv3
 *  Updated for performance improvement for authorize work date.
 *
 *  Revision 1.2  2011/01/14 17:37:45  mwtjc1
 *  execute(UpdateDafRecordPersistenceRequest request) added
 *
 *  Revision 1.1  2010/12/17 23:10:49  mwyxg1
 *  add new
 *
 */
