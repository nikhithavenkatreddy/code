/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I represent the request to retrieve object from the persistent store
 * 
 * File: IssueLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request
 * Created: Sept 17, 2010
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/10/06 22:32:39 $
 * Last Changed By: $Author: mwkfh $
 */
public class IssueLocalInventoryRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4951863278309626379L;
	/** The domain object. */
	private IInventoryItem inventoryItem;

	/**
	 * Instantiates a new issue local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public IssueLocalInventoryRequest(IUserContext userContext,
			IInventoryItem inventoryItem) {
		super(userContext);
		this.inventoryItem = inventoryItem;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public IssueLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * This method gets the business object based on which the search has to be done.
	 * 
	 * @return the businessObject BusinessObject to be searched on
	 */
	public IInventoryItem getInventoryItem() {
		return inventoryItem;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueLocalInventoryRequest.java,v $
 *  Revision 1.2  2010/10/06 22:32:39  mwkfh
 *  updated to use IInventoryItem
 *
 *  Revision 1.1  2010/09/20 18:25:44  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/20 16:49:51  mwkfh
 *  added issue local inv item
 *
 */
