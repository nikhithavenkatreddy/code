/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.factory.ITransactionPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.AssignDafNumberRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.AuthorizeWorkDateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.UpdateDafRecordPersistenceRequest;
import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;
import gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService;
import gov.ca.dmv.ease.tus.persist.service.impl.TransactionPersistenceService;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;

/**
 * Description: Implementation of the ITransactionPersistenceServiceRequestFactory request
 * interface 
 * File: TransactionPersistenceServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.factory.impl
 * Created: Dec 20, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2012/08/14 20:47:21 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class TransactionPersistenceServiceRequestFactory implements
		ITransactionPersistenceServiceRequestFactory {
	/** The local persistence service. */
	private transient TransactionPersistenceService transactionPersistenceService;
	/** The SINGLETON. */
	private static ITransactionPersistenceServiceRequestFactory SINGLETON;

	/**
	 * Gets the single instance of LocalPersistenceServiceRequestFactory.
	 * 
	 * @return single instance of LocalPersistenceServiceRequestFactory
	 */
	public static ITransactionPersistenceServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		try {
			if (!EaseUtil.isNotNull(EaseApplicationContext
					.getApplicationContext())) {
				SINGLETON = new TransactionPersistenceServiceRequestFactory();
			}
			else {
				SINGLETON = (TransactionPersistenceServiceRequestFactory) EaseApplicationContext
						.getApplicationContext().getBean(
								"transactionPersistenceServiceRequestFactory");
			}
		}
		catch (NoSuchBeanDefinitionException e) {
			SINGLETON = new TransactionPersistenceServiceRequestFactory();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.ITransactionPersistenceServiceRequestFactory#createAssignDafNumberRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.tx.ITransaction)
	 */
	public AssignDafNumberRequest createAssignDafNumberRequest(
			IUserContext userContext, Application application) {
		AssignDafNumberRequest request = new AssignDafNumberRequest(
				userContext, application);
		request
				.setPersistenceService((IPersistenceService) getTransactionPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.ITransactionPersistenceServiceRequestFactory#createUpdateDafRecordPersistenceRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.document.impl.Application, int)
	 */
	public UpdateDafRecordPersistenceRequest createUpdateDafRecordPersistenceRequest(
			IUserContext userContext, Application application,
			int allocatedDafNumber) {
		UpdateDafRecordPersistenceRequest request = new UpdateDafRecordPersistenceRequest(
				userContext, application, allocatedDafNumber);
		request
				.setPersistenceService((IPersistenceService) getTransactionPersistenceService());
		return request;
	}

	/**
	 * Gets the local persistence service.
	 * 
	 * @return the local persistence service
	 */
	private ITransactionPersistenceService getTransactionPersistenceService() {
		if (transactionPersistenceService == null) {
			setTransactionPersistenceService((TransactionPersistenceService) EaseApplicationContext
					.getApplicationContext().getBean(
							"transactionPersistenceService"));
		}
		return transactionPersistenceService;
	}

	/**
	 * Sets the transactionPersistenceService
	 *
	 * @param transactionPersistenceService the transactionPersistenceService to set
	 */
	public void setTransactionPersistenceService(
			TransactionPersistenceService transactionPersistenceService) {
		this.transactionPersistenceService = transactionPersistenceService;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.ITransactionPersistenceServiceRequestFactory#createWorkDateRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public AuthorizeWorkDateRequest createWorkDateRequest(
			IUserContext userContext, boolean isWorkDate, boolean status) {
		AuthorizeWorkDateRequest request = new AuthorizeWorkDateRequest(
				userContext, isWorkDate, status);
		request
				.setPersistenceService((IPersistenceService) getTransactionPersistenceService());
		return request;
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransactionPersistenceServiceRequestFactory.java,v $
 *  Revision 1.8  2012/08/14 20:47:21  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.7  2011/10/20 22:35:20  mwrrv3
 *  Updated for performance improvement for authorize work date.
 *
 *  Revision 1.6  2011/03/29 20:50:30  mwkfh
 *  updated initSingleton()
 *
 *  Revision 1.5  2011/01/14 18:28:26  mwtjc1
 *  createUpdateDafRecordPersistenceRequest added
 *
 *  Revision 1.4  2010/12/23 06:18:24  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.3.2.1  2010/12/23 03:13:57  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.3  2010/12/22 17:34:02  mwyxg1
 *  add application
 *
 *  Revision 1.2  2010/12/21 16:55:24  mwyxg1
 *  remove transaction
 *
 *  Revision 1.1  2010/12/20 18:11:50  mwyxg1
 *  add new
 *
 */
