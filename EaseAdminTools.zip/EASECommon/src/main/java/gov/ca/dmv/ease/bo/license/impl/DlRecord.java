/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.SocialSecurityDocument;
import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: This represents the common information for Driver License Number inquiry response.
 * File: DlRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 20, 2010
 * 
 * @author MWUXB
 * @version $Revision: 1.38 $
 * Last Changed: $Date: 2012/09/14 20:59:44 $
 * Last Changed By: $Author: mwhys $
 */
public class DlRecord extends AbstractDlRecord {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -485508570716220307L;
	/** The application held pending code. */
	private CodeSetElement applicationHeldPendingCode;
	/** The Application Pending Indicator. */
	private CodeSetElement applicationPendingIndicator;
	/** Segment E. */
	/** These fields are used to determine the Action Message to be displayed on the DL Inquiry Response screen. */
	/** The application sub record missing message. */
	private CodeSetElement applicationSubrecordMissingMessage;
	/** The Birth date Not Verified. */
	private CodeSetElement birthdateNotVerified;
	/** The Court Ordered License Delay. Action Message - COURT DELAY OF LIC. */
	protected CodeSetElement courtOrderedLicenseDelay;
	/** The Court Suspension. Action Message - COURT SUSPENSION. */
	protected CodeSetElement courtSuspension;
	/** Segment C. */
	/** These field are used to determine the Action Message to be displayed on the DL Inquiry Response screen. *
	/** The Deceased Code. Action Message - COUNSELOR VERIF REQ. */
	protected CodeSetElement deceasedCode;
	/** The Discretionary Suspension or Revocation. Action Message - DISCRET SUSP/REV. */
	protected CodeSetElement discretionarySuspensionOrRevocation;
	/** The Dis-honoured Checks. Action Message - DISHONORED CHECK. */
	protected CodeSetElement dishonoredChecks;
	/** The DL Application Date. */
	private Date dlApplicationDate;
	/** The DL renewal message code. */
	private CodeSetElement dlRenewalMessageCode;
	/** The double record code. */
	private CodeSetElement doubleRecordCode;
	/** If Birth date + 18 > Process Date and the indicator is false then display the message. */
	protected CodeSetElement eligibleForRestriction04;
	/* Do not copy following fields to DlApplication. Assumption - 
	 Following fields are not required in CDA and will not be part of object graph. */
	/** The error message. */
	@Deprecated
	private String errorMessage;
	/** The existing dl incomplete application reason code. */
	private CodeSetElement existingDlIncompleteApplicationReasonCode;
	/** The existing id incomplete application reason code. */
	private CodeSetElement existingIdIncompleteApplicationReasonCode;
	/** The Failure To Appear. Action Message - FAILURE TO APPEAR. */
	protected CodeSetElement failureToAppear;
	/** The Failure To Pay. Action Message - FAILURE TO PAY. */
	protected CodeSetElement failureToPay;
	/** The Finance Responsibility. Action Message - FR MANDATORY SUSP. */
	protected CodeSetElement financialResponsibility;
	/** The FR Penalty Fee Not Due. Action Message - If = 1 display NO FR FEE REQUIRED If = 2 display FR FEE ALREADY PAID. */
	protected CodeSetElement frPenaltyFeeNotDue;
	/** The fr proof not on file. */
	private CodeSetElement frProofNotOnFile;
	/** The hit counter. */
	private Integer hitCounter;
	/** The ID Application Date. */
	private Date idApplicationDate;
	/** The ID card returned unclaimed. */
	private CodeSetElement idCardReturnedUnclaimed;
	/** The ID Photo Retake. */
	private CodeSetElement idPhotoRetake;
	/** The ID renewal message code. */
	private CodeSetElement idRenewalMessageCode;
	/** The Ineligible to renew by mail. */
	private CodeSetElement ineligibleToRenewByMail;
	/** The Invalid Class Change. */
	private CodeSetElement invalidClassChange;
	/** The Absent Parent Indicator. */
	private Boolean isAbsentParent;
	/** The license location. */
	private CodeSetElement licenseLocationCode;
	/** The Mandatory Suspension or Revocation. Action Message - MANDATORY SUSP/REV. */
	protected CodeSetElement mandatorySuspensionOrRevocation;
	/** The Multiple Name and Birth Date Match. Action Message - MULT REC-SAME NAM/BD. */
	protected CodeSetElement multipleNameAndBirthDateMatch;
	/** The On Probation. Action Message - PROB-INELIG COMM’L. */
	protected CodeSetElement onProbation;
	/** The Other License. Action Message - OTHER LIC OUTSTNDING. */
	protected CodeSetElement otherLicense;
	/** The Pending Application Reason Code. Action Messages - MAN APP BD DISCREP - 3 PENDING APP FILE - 4 PENDING APP TO EDP - 1 PENDING MAIL RENEWAL - 5. */
	protected CodeSetElement pendingApplicationReasonCode;
	/** The person. */
	private Person person;
	/** The Photo Retake Not Ok Indicator. */
	private CodeSetElement photoRetakeNotOkIndicator;
	/** The Physical or Mental Problem. Action Message - DSR APPROVAL REQ. */
	protected CodeSetElement physicalOrMentalProblem;
	/** The Physical or Mental Problem Code. Action Message - COMM’L-VISION REQ. */
	protected CodeSetElement physicalOrMentalProblemCode;
	/** The RECORD SECURITY FILE CODE R. */
	protected CodeSetElement recordSecurityFileCode;
	/** The Reinstatement In Progress. Action Message - REVIEW STATUS SET. */
	protected CodeSetElement reinstatementInProgress;
	/** The Re-issue Fee Due. Action Message - REISSUE FEE DUE. */
	protected CodeSetElement reissueFeeDue;
	/** The Restriction Removal Fee Due. Action Message - REM RESTR FEE DUE. */
	protected CodeSetElement restrictionRemovalFeeDue;
	/** The return code. */
	private CodeSetElement returnCode;
	/** The Route Code. Action Messages - CONTROLLED-CALL DLF - 3510 CONTROLLED-CALL RSIU - 3503. */
	protected CodeSetElement routeCode;
	/** The segments. */
	private List <CodeSetElement> segments = new ArrayList <CodeSetElement>();
	/** The Service Of Order Needed. */
	private CodeSetElement serviceOfOrderNeeded;
	/** The Suspense or Revoke on file indicator. */
	private CodeSetElement suspenseOrRevokeOnFileIndicator;
	/** The Type Application Error. */
	private CodeSetElement typeApplicationError;
	/** DLA Activity shall copy values from the following fields to the appropriate fields in the DlApplication class. */
	/** The User Verified Ssn Code. From Segment 0.
	 * Sample Codes: D - Verified by DMV; R - Verification Required; 
	 * X - Not Verified
	 */
	private CodeSetElement userVerifiedSsnCode;
	/** The class of record. */
	private String classOfRecord;
	
	/**
	 * Instantiates a new dl record.
	 */
	public DlRecord() {
		super();
	}
	
	/**
	 * Instantiates a new dl record.
	 *
	 * @param dlRecord the dl record
	 */
	public DlRecord(DlRecord dlRecord) {
		super();
		copy(dlRecord);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(DlRecord dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null dlRecord argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		//Copy applicationHeldPendingCode
		if (isNotNull(dataToCopy.getApplicationHeldPendingCode())) {
			setApplicationHeldPendingCode(new CodeSetElement(dataToCopy
					.getApplicationHeldPendingCode()));
		}
		else {
			setApplicationHeldPendingCode(null);
		}
		//Copy applicationPendingIndicator
		if (isNotNull(dataToCopy.getApplicationPendingIndicator())) {
			setApplicationPendingIndicator(new CodeSetElement(dataToCopy
					.getApplicationPendingIndicator()));
		}
		else {
			setApplicationPendingIndicator(null);
		}
		//Copy applicationSubrecordMissingMessage
		if (isNotNull(dataToCopy.getApplicationSubrecordMissingMessage())) {
			setApplicationSubrecordMissingMessage(new CodeSetElement(dataToCopy
					.getApplicationSubrecordMissingMessage()));
		}
		else {
			setApplicationSubrecordMissingMessage(null);
		}
		//Copy birthdateNotVerified
		if (isNotNull(dataToCopy.getBirthdateNotVerified())) {
			setBirthdateNotVerified(new CodeSetElement(dataToCopy
					.getBirthdateNotVerified()));
		}
		else {
			setBirthdateNotVerified(null);
		}
		//Copy courtOrderedLicenseDelay
		if (isNotNull(dataToCopy.getCourtOrderedLicenseDelay())) {
			setCourtOrderedLicenseDelay(new CodeSetElement(dataToCopy
					.getCourtOrderedLicenseDelay()));
		}
		else {
			setCourtOrderedLicenseDelay(null);
		}
		//Copy courtSuspension
		if (isNotNull(dataToCopy.getCourtSuspension())) {
			setCourtSuspension(new CodeSetElement(dataToCopy
					.getCourtSuspension()));
		}
		else {
			setCourtSuspension(null);
		}
		//Copy deceasedCode
		if (isNotNull(dataToCopy.getDeceasedCode())) {
			setDeceasedCode(new CodeSetElement(dataToCopy.getDeceasedCode()));
		}
		else {
			setDeceasedCode(null);
		}
		//Copy discretionarySuspensionOrRevocation
		if (isNotNull(dataToCopy.getDiscretionarySuspensionOrRevocation())) {
			setDiscretionarySuspensionOrRevocation(new CodeSetElement(
					dataToCopy.getDiscretionarySuspensionOrRevocation()));
		}
		else {
			setDiscretionarySuspensionOrRevocation(null);
		}
		//Copy dishonoredChecks
		if (isNotNull(dataToCopy.getDishonoredChecks())) {
			setDishonoredChecks(new CodeSetElement(dataToCopy
					.getDishonoredChecks()));
		}
		else {
			setDishonoredChecks(null);
		}
		//Copy dlApplicationDate
		if (isNotNull(dataToCopy.getDlApplicationDate())) {
			setDlApplicationDate(new Date(dataToCopy.getDlApplicationDate()
					.getTime()));
		}
		else {
			setDlApplicationDate(null);
		}
		//Copy dlRenewalMessageCode
		if (isNotNull(dataToCopy.getDlRenewalMessageCode())) {
			setDlRenewalMessageCode(new CodeSetElement(dataToCopy
					.getDlRenewalMessageCode()));
		}
		else {
			setDlRenewalMessageCode(null);
		}
		//Copy doubleRecordCode
		if (isNotNull(dataToCopy.getDoubleRecordCode())) {
			setDoubleRecordCode(new CodeSetElement(dataToCopy
					.getDoubleRecordCode()));
		}
		else {
			setDoubleRecordCode(null);
		}
		//Copy eligibleForRestriction04
		if (isNotNull(dataToCopy.getEligibleForRestriction04())) {
			setEligibleForRestriction04(new CodeSetElement(dataToCopy
					.getEligibleForRestriction04()));
		}
		else {
			setEligibleForRestriction04(null);
		}
		//Copy errorMessage
		if (isNotNull(dataToCopy.getErrorMessage())) {
			setErrorMessage(dataToCopy.getErrorMessage());
		}
		//Copy existingDlIncompleteApplicationReasonCode
		if (isNotNull(dataToCopy.getExistingDlIncompleteApplicationReasonCode())) {
			setExistingDlIncompleteApplicationReasonCode(new CodeSetElement(
					dataToCopy.getExistingDlIncompleteApplicationReasonCode()));
		}
		else {
			setExistingDlIncompleteApplicationReasonCode(null);
		}
		//Copy existingIdIncompleteApplicationReasonCode
		if (isNotNull(dataToCopy.getExistingIdIncompleteApplicationReasonCode())) {
			setExistingIdIncompleteApplicationReasonCode(new CodeSetElement(
					dataToCopy.getExistingIdIncompleteApplicationReasonCode()));
		}
		else {
			setExistingIdIncompleteApplicationReasonCode(null);
		}
		//Copy failureToAppear
		if (isNotNull(dataToCopy.getFailureToAppear())) {
			setFailureToAppear(new CodeSetElement(dataToCopy
					.getFailureToAppear()));
		}
		else {
			setFailureToAppear(null);
		}
		//Copy failureToPay
		if (isNotNull(dataToCopy.getFailureToPay())) {
			setFailureToPay(new CodeSetElement(dataToCopy.getFailureToPay()));
		}
		else {
			setFailureToPay(null);
		}
		//Copy financialResponsibility
		if (isNotNull(dataToCopy.getFinancialResponsibility())) {
			setFinancialResponsibility(new CodeSetElement(dataToCopy
					.getFinancialResponsibility()));
		}
		else {
			setFinancialResponsibility(null);
		}
		//Copy frPenaltyFeeNotDue
		if (isNotNull(dataToCopy.getFrPenaltyFeeNotDue())) {
			setFrPenaltyFeeNotDue(new CodeSetElement(dataToCopy
					.getFrPenaltyFeeNotDue()));
		}
		else {
			setFrPenaltyFeeNotDue(null);
		}
		//Copy frProofNotOnFile
		if (isNotNull(dataToCopy.getFrProofNotOnFile())) {
			setFrProofNotOnFile(new CodeSetElement(dataToCopy
					.getFrProofNotOnFile()));
		}
		else {
			setFrProofNotOnFile(null);
		}
		//Copy hitCounter
		if (isNotNull(dataToCopy.getHitCounter())) {
			setHitCounter(new Integer(dataToCopy.getHitCounter()));
		}
		else {
			setHitCounter(null);
		}
		//Copy idApplicationDate
		if (isNotNull(dataToCopy.getIdApplicationDate())) {
			setIdApplicationDate(new Date(dataToCopy.getIdApplicationDate()
					.getTime()));
		}
		else {
			setIdApplicationDate(null);
		}
		//Copy idCardReturnedUnclaimed
		if (isNotNull(dataToCopy.getIdCardReturnedUnclaimed())) {
			setIdCardReturnedUnclaimed(new CodeSetElement(dataToCopy
					.getIdCardReturnedUnclaimed()));
		}
		else {
			setIdCardReturnedUnclaimed(null);
		}
		//Copy idPhotoRetake
		if (isNotNull(dataToCopy.getIdPhotoRetake())) {
			setIdPhotoRetake(new CodeSetElement(dataToCopy.getIdPhotoRetake()));
		}
		else {
			setIdPhotoRetake(null);
		}
		//Copy idRenewalMessageCode
		if (isNotNull(dataToCopy.getIdRenewalMessageCode())) {
			setIdRenewalMessageCode(new CodeSetElement(dataToCopy
					.getIdRenewalMessageCode()));
		}
		else {
			setIdRenewalMessageCode(null);
		}
		//Copy ineligibleToRenewByMail
		if (isNotNull(dataToCopy.getIneligibleToRenewByMail())) {
			setIneligibleToRenewByMail(new CodeSetElement(dataToCopy
					.getIneligibleToRenewByMail()));
		}
		else {
			setIneligibleToRenewByMail(null);
		}
		//Copy invalidClassChange
		if (isNotNull(dataToCopy.getInvalidClassChange())) {
			setInvalidClassChange(new CodeSetElement(dataToCopy
					.getInvalidClassChange()));
		}
		else {
			setInvalidClassChange(null);
		}
		//Copy isAbsentParent
		if (isNotNull(dataToCopy.isAbsentParent())) {
			setAbsentParentIndicator(new Boolean(dataToCopy.isAbsentParent()));
		}
		else {
			setAbsentParentIndicator(null);
		}
		//Copy licenseLocationCode
		if (isNotNull(dataToCopy.getLicenseLocationCode())) {
			setLicenseLocationCode(new CodeSetElement(dataToCopy
					.getLicenseLocationCode()));
		}
		else {
			setLicenseLocationCode(null);
		}
		//Copy mandatorySuspensionOrRevocation
		if (isNotNull(dataToCopy.getMandatorySuspensionOrRevocation())) {
			setMandatorySuspensionOrRevocation(new CodeSetElement(dataToCopy
					.getMandatorySuspensionOrRevocation()));
		}
		else {
			setMandatorySuspensionOrRevocation(null);
		}
		//Copy multipleNameAndBirthDateMatch
		if (isNotNull(dataToCopy.getMultipleNameAndBirthDateMatch())) {
			setMultipleNameAndBirthDateMatch(new CodeSetElement(dataToCopy
					.getMultipleNameAndBirthDateMatch()));
		}
		else {
			setMultipleNameAndBirthDateMatch(null);
		}
		//Copy onProbation
		if (isNotNull(dataToCopy.getOnProbation())) {
			setOnProbation(new CodeSetElement(dataToCopy.getOnProbation()));
		}
		else {
			setOnProbation(null);
		}
		//Copy otherLicense
		if (isNotNull(dataToCopy.getOtherLicense())) {
			setOtherLicense(new CodeSetElement(dataToCopy.getOtherLicense()));
		}
		else {
			setOtherLicense(null);
		}
		//Copy pendingApplicationReasonCode
		if (isNotNull(dataToCopy.getPendingApplicationReasonCode())) {
			setPendingApplicationReasonCode(new CodeSetElement(dataToCopy
					.getPendingApplicationReasonCode()));
		}
		else {
			setPendingApplicationReasonCode(null);
		}
		//Copy person
		if (isNotNull(dataToCopy.getPerson())) {
			setPerson(new Person(dataToCopy.getPerson()));
		}
		else {
			setPerson(null);
		}
		//Copy photoRetakeNotOkIndicator
		if (isNotNull(dataToCopy.getPhotoRetakeNotOkIndicator())) {
			setPhotoRetakeNotOkIndicator(new CodeSetElement(dataToCopy
					.getPhotoRetakeNotOkIndicator()));
		}
		else {
			setPhotoRetakeNotOkIndicator(null);
		}
		//Copy physicalOrMentalProblem
		if (isNotNull(dataToCopy.getPhysicalOrMentalProblem())) {
			setPhysicalOrMentalProblem(new CodeSetElement(dataToCopy
					.getPhysicalOrMentalProblem()));
		}
		else {
			setPhysicalOrMentalProblem(null);
		}
		//Copy physicalOrMentalProblemCode
		if (isNotNull(dataToCopy.getPhysicalOrMentalProblemCode())) {
			setPhysicalOrMentalProblemCode(new CodeSetElement(dataToCopy
					.getPhysicalOrMentalProblemCode()));
		}
		else {
			setPhysicalOrMentalProblemCode(null);
		}
		//Copy recordSecurityFileCode
		if (isNotNull(dataToCopy.getRecordSecurityFileCode())) {
			setRecordSecurityFileCode(new CodeSetElement(dataToCopy
					.getRecordSecurityFileCode()));
		}
		else {
			setRecordSecurityFileCode(null);
		}
		//Copy reinstatementInProgress
		if (isNotNull(dataToCopy.getReinstatementInProgress())) {
			setReinstatementInProgress(new CodeSetElement(dataToCopy
					.getReinstatementInProgress()));
		}
		else {
			setReinstatementInProgress(null);
		}
		//Copy reissueFeeDue
		if (isNotNull(dataToCopy.getReissueFeeDue())) {
			setReissueFeeDue(new CodeSetElement(dataToCopy.getReissueFeeDue()));
		}
		else {
			setReissueFeeDue(null);
		}
		//Copy restrictionRemovalFeeDue
		if (isNotNull(dataToCopy.getRestrictionRemovalFeeDue())) {
			setRestrictionRemovalFeeDue(new CodeSetElement(dataToCopy
					.getRestrictionRemovalFeeDue()));
		}
		else {
			setRestrictionRemovalFeeDue(null);
		}
		//Copy returnCode
		if (isNotNull(dataToCopy.getReturnCode())) {
			setReturnCode(new CodeSetElement(dataToCopy.getReturnCode()));
		}
		else {
			setReturnCode(null);
		}
		//Copy routeCode
		if (isNotNull(dataToCopy.getRouteCode())) {
			setRouteCode(new CodeSetElement(dataToCopy.getRouteCode()));
		}
		else {
			setRouteCode(null);
		}
		//Copy segments
		if (isNotNull(dataToCopy.getSegments())) {
			getSegments().addAll(dataToCopy.getSegments());
		}
		//Copy serviceOfOrderNeeded
		if (isNotNull(dataToCopy.getServiceOfOrderNeeded())) {
			setServiceOfOrderNeeded(new CodeSetElement(dataToCopy
					.getServiceOfOrderNeeded()));
		}
		else {
			setServiceOfOrderNeeded(null);
		}
		//Copy suspenseOrRevokeOnFileIndicator
		if (isNotNull(dataToCopy.getSuspenseOrRevokeOnFileIndicator())) {
			setSuspenseOrRevokeOnFileIndicator(new CodeSetElement(dataToCopy
					.getSuspenseOrRevokeOnFileIndicator()));
		}
		else {
			setSuspenseOrRevokeOnFileIndicator(null);
		}
		//Copy typeApplicationError
		if (isNotNull(dataToCopy.getTypeApplicationError())) {
			setTypeApplicationError(new CodeSetElement(dataToCopy
					.getTypeApplicationError()));
		}
		else {
			setTypeApplicationError(null);
		}
		//Copy userVerifiedSsnCode
		if (isNotNull(dataToCopy.getUserVerifiedSsnCode())) {
			setUserVerifiedSsnCode(new CodeSetElement(dataToCopy
					.getUserVerifiedSsnCode()));
		}
		else {
			setUserVerifiedSsnCode(null);
		}
		//Copy classOfRecord
		if (isNotNull(dataToCopy.getClassOfRecord())) {
			setClassOfRecord(dataToCopy.getClassOfRecord());
		}
	}
	
	/**
	 * Adds the segment.
	 * 
	 * @param segment the segment
	 */
	public void addSegment(CodeSetElement segment) {
		segments.add(segment);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DlRecord other = (DlRecord) obj;
		if (isAbsentParent == null) {
			if (other.isAbsentParent != null) {
				return false;
			}
		}
		else if (!isAbsentParent.equals(other.isAbsentParent)) {
			return false;
		}
		if (applicationHeldPendingCode == null) {
			if (other.applicationHeldPendingCode != null) {
				return false;
			}
		}
		else if (!applicationHeldPendingCode
				.equals(other.applicationHeldPendingCode)) {
			return false;
		}
		if (applicationPendingIndicator == null) {
			if (other.applicationPendingIndicator != null) {
				return false;
			}
		}
		else if (!applicationPendingIndicator
				.equals(other.applicationPendingIndicator)) {
			return false;
		}
		if (applicationSubrecordMissingMessage == null) {
			if (other.applicationSubrecordMissingMessage != null) {
				return false;
			}
		}
		else if (!applicationSubrecordMissingMessage
				.equals(other.applicationSubrecordMissingMessage)) {
			return false;
		}
		if (birthdateNotVerified == null) {
			if (other.birthdateNotVerified != null) {
				return false;
			}
		}
		else if (!birthdateNotVerified.equals(other.birthdateNotVerified)) {
			return false;
		}
		if (courtOrderedLicenseDelay == null) {
			if (other.courtOrderedLicenseDelay != null) {
				return false;
			}
		}
		else if (!courtOrderedLicenseDelay
				.equals(other.courtOrderedLicenseDelay)) {
			return false;
		}
		if (courtSuspension == null) {
			if (other.courtSuspension != null) {
				return false;
			}
		}
		else if (!courtSuspension.equals(other.courtSuspension)) {
			return false;
		}
		if (deceasedCode == null) {
			if (other.deceasedCode != null) {
				return false;
			}
		}
		else if (!deceasedCode.equals(other.deceasedCode)) {
			return false;
		}
		if (discretionarySuspensionOrRevocation == null) {
			if (other.discretionarySuspensionOrRevocation != null) {
				return false;
			}
		}
		else if (!discretionarySuspensionOrRevocation
				.equals(other.discretionarySuspensionOrRevocation)) {
			return false;
		}
		if (dishonoredChecks == null) {
			if (other.dishonoredChecks != null) {
				return false;
			}
		}
		else if (!dishonoredChecks.equals(other.dishonoredChecks)) {
			return false;
		}
		if (dlApplicationDate == null) {
			if (other.dlApplicationDate != null) {
				return false;
			}
		}
		else if (!dlApplicationDate.equals(other.dlApplicationDate)) {
			return false;
		}
		if (dlRenewalMessageCode == null) {
			if (other.dlRenewalMessageCode != null) {
				return false;
			}
		}
		else if (!dlRenewalMessageCode.equals(other.dlRenewalMessageCode)) {
			return false;
		}
		if (doubleRecordCode == null) {
			if (other.doubleRecordCode != null) {
				return false;
			}
		}
		else if (!doubleRecordCode.equals(other.doubleRecordCode)) {
			return false;
		}
		if (eligibleForRestriction04 == null) {
			if (other.eligibleForRestriction04 != null) {
				return false;
			}
		}
		else if (!eligibleForRestriction04
				.equals(other.eligibleForRestriction04)) {
			return false;
		}
		if (errorMessage == null) {
			if (other.errorMessage != null) {
				return false;
			}
		}
		else if (!errorMessage.equals(other.errorMessage)) {
			return false;
		}
		if (existingDlIncompleteApplicationReasonCode == null) {
			if (other.existingDlIncompleteApplicationReasonCode != null) {
				return false;
			}
		}
		else if (!existingDlIncompleteApplicationReasonCode
				.equals(other.existingDlIncompleteApplicationReasonCode)) {
			return false;
		}
		if (existingIdIncompleteApplicationReasonCode == null) {
			if (other.existingIdIncompleteApplicationReasonCode != null) {
				return false;
			}
		}
		else if (!existingIdIncompleteApplicationReasonCode
				.equals(other.existingIdIncompleteApplicationReasonCode)) {
			return false;
		}
		if (failureToAppear == null) {
			if (other.failureToAppear != null) {
				return false;
			}
		}
		else if (!failureToAppear.equals(other.failureToAppear)) {
			return false;
		}
		if (failureToPay == null) {
			if (other.failureToPay != null) {
				return false;
			}
		}
		else if (!failureToPay.equals(other.failureToPay)) {
			return false;
		}
		if (financialResponsibility == null) {
			if (other.financialResponsibility != null) {
				return false;
			}
		}
		else if (!financialResponsibility.equals(other.financialResponsibility)) {
			return false;
		}
		if (frPenaltyFeeNotDue == null) {
			if (other.frPenaltyFeeNotDue != null) {
				return false;
			}
		}
		else if (!frPenaltyFeeNotDue.equals(other.frPenaltyFeeNotDue)) {
			return false;
		}
		if (frProofNotOnFile == null) {
			if (other.frProofNotOnFile != null) {
				return false;
			}
		}
		else if (!frProofNotOnFile.equals(other.frProofNotOnFile)) {
			return false;
		}
		if (idApplicationDate == null) {
			if (other.idApplicationDate != null) {
				return false;
			}
		}
		else if (!idApplicationDate.equals(other.idApplicationDate)) {
			return false;
		}
		if (idCardReturnedUnclaimed == null) {
			if (other.idCardReturnedUnclaimed != null) {
				return false;
			}
		}
		else if (!idCardReturnedUnclaimed.equals(other.idCardReturnedUnclaimed)) {
			return false;
		}
		if (idPhotoRetake == null) {
			if (other.idPhotoRetake != null) {
				return false;
			}
		}
		else if (!idPhotoRetake.equals(other.idPhotoRetake)) {
			return false;
		}
		if (idRenewalMessageCode == null) {
			if (other.idRenewalMessageCode != null) {
				return false;
			}
		}
		else if (!idRenewalMessageCode.equals(other.idRenewalMessageCode)) {
			return false;
		}
		if (ineligibleToRenewByMail == null) {
			if (other.ineligibleToRenewByMail != null) {
				return false;
			}
		}
		else if (!ineligibleToRenewByMail.equals(other.ineligibleToRenewByMail)) {
			return false;
		}
		if (invalidClassChange == null) {
			if (other.invalidClassChange != null) {
				return false;
			}
		}
		else if (!invalidClassChange.equals(other.invalidClassChange)) {
			return false;
		}
		if (licenseLocationCode == null) {
			if (other.licenseLocationCode != null) {
				return false;
			}
		}
		else if (!licenseLocationCode.equals(other.licenseLocationCode)) {
			return false;
		}
		if (mandatorySuspensionOrRevocation == null) {
			if (other.mandatorySuspensionOrRevocation != null) {
				return false;
			}
		}
		else if (!mandatorySuspensionOrRevocation
				.equals(other.mandatorySuspensionOrRevocation)) {
			return false;
		}
		if (multipleNameAndBirthDateMatch == null) {
			if (other.multipleNameAndBirthDateMatch != null) {
				return false;
			}
		}
		else if (!multipleNameAndBirthDateMatch
				.equals(other.multipleNameAndBirthDateMatch)) {
			return false;
		}
		if (onProbation == null) {
			if (other.onProbation != null) {
				return false;
			}
		}
		else if (!onProbation.equals(other.onProbation)) {
			return false;
		}
		if (otherLicense == null) {
			if (other.otherLicense != null) {
				return false;
			}
		}
		else if (!otherLicense.equals(other.otherLicense)) {
			return false;
		}
		if (pendingApplicationReasonCode == null) {
			if (other.pendingApplicationReasonCode != null) {
				return false;
			}
		}
		else if (!pendingApplicationReasonCode
				.equals(other.pendingApplicationReasonCode)) {
			return false;
		}
		if (person == null) {
			if (other.person != null) {
				return false;
			}
		}
		else if (!person.equals(other.person)) {
			return false;
		}
		if (photoRetakeNotOkIndicator == null) {
			if (other.photoRetakeNotOkIndicator != null) {
				return false;
			}
		}
		else if (!photoRetakeNotOkIndicator
				.equals(other.photoRetakeNotOkIndicator)) {
			return false;
		}
		if (physicalOrMentalProblem == null) {
			if (other.physicalOrMentalProblem != null) {
				return false;
			}
		}
		else if (!physicalOrMentalProblem.equals(other.physicalOrMentalProblem)) {
			return false;
		}
		if (physicalOrMentalProblemCode == null) {
			if (other.physicalOrMentalProblemCode != null) {
				return false;
			}
		}
		else if (!physicalOrMentalProblemCode
				.equals(other.physicalOrMentalProblemCode)) {
			return false;
		}
		if (reinstatementInProgress == null) {
			if (other.reinstatementInProgress != null) {
				return false;
			}
		}
		else if (!reinstatementInProgress.equals(other.reinstatementInProgress)) {
			return false;
		}
		if (reissueFeeDue == null) {
			if (other.reissueFeeDue != null) {
				return false;
			}
		}
		else if (!reissueFeeDue.equals(other.reissueFeeDue)) {
			return false;
		}
		if (restrictionRemovalFeeDue == null) {
			if (other.restrictionRemovalFeeDue != null) {
				return false;
			}
		}
		else if (!restrictionRemovalFeeDue
				.equals(other.restrictionRemovalFeeDue)) {
			return false;
		}
		if (returnCode == null) {
			if (other.returnCode != null) {
				return false;
			}
		}
		else if (!returnCode.equals(other.returnCode)) {
			return false;
		}
		if (routeCode == null) {
			if (other.routeCode != null) {
				return false;
			}
		}
		else if (!routeCode.equals(other.routeCode)) {
			return false;
		}
		if (segments == null) {
			if (other.segments != null) {
				return false;
			}
		}
		else if (!segments.equals(other.segments)) {
			return false;
		}
		if (serviceOfOrderNeeded == null) {
			if (other.serviceOfOrderNeeded != null) {
				return false;
			}
		}
		else if (!serviceOfOrderNeeded.equals(other.serviceOfOrderNeeded)) {
			return false;
		}
		if (suspenseOrRevokeOnFileIndicator == null) {
			if (other.suspenseOrRevokeOnFileIndicator != null) {
				return false;
			}
		}
		else if (!suspenseOrRevokeOnFileIndicator
				.equals(other.suspenseOrRevokeOnFileIndicator)) {
			return false;
		}
		if (typeApplicationError == null) {
			if (other.typeApplicationError != null) {
				return false;
			}
		}
		else if (!typeApplicationError.equals(other.typeApplicationError)) {
			return false;
		}
		if (userVerifiedSsnCode == null) {
			if (other.userVerifiedSsnCode != null) {
				return false;
			}
		}
		else if (!userVerifiedSsnCode.equals(other.userVerifiedSsnCode)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the application held pending code.
	 * 
	 * @return the applicationHeldPendingCode
	 */
	public CodeSetElement getApplicationHeldPendingCode() {
		return applicationHeldPendingCode;
	}
	
	/**
	 * Gets the application pending indicator.
	 * 
	 * @return the applicationPendingIndicator
	 */
	public CodeSetElement getApplicationPendingIndicator() {
		return applicationPendingIndicator;
	}
	
	/**
	 * Checks if is dl pended.
	 *
	 * @return true, if is dl pended
	 */
	public boolean isDlPended() {
		CodeSetElement applicationPendingIndicator = getApplicationPendingIndicator();
		if (!EaseUtil.isNullOrBlank(applicationPendingIndicator)) {
			if ("D".equalsIgnoreCase(applicationPendingIndicator.getCode())
					|| "B".equalsIgnoreCase(applicationPendingIndicator
							.getCode())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks if is id pended.
	 *
	 * @return true, if is id pended
	 */
	public boolean isIdPended() {
		CodeSetElement applicationPendingIndicator = getApplicationPendingIndicator();
		if (!EaseUtil.isNullOrBlank(applicationPendingIndicator)) {
			if ("I".equalsIgnoreCase(applicationPendingIndicator.getCode())
					|| "B".equalsIgnoreCase(applicationPendingIndicator
							.getCode())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks if is both dl and id pended.
	 *
	 * @return true, if is both dl and id pended
	 */
	public boolean isBothDlAndIdPended() {
		CodeSetElement applicationPendingIndicator = getApplicationPendingIndicator();
		if (!EaseUtil.isNullOrBlank(applicationPendingIndicator)) {
			if ("B".equalsIgnoreCase(applicationPendingIndicator.getCode())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gets the application subrecord missing message.
	 * 
	 * @return the application subrecord missing message
	 */
	public CodeSetElement getApplicationSubrecordMissingMessage() {
		return applicationSubrecordMissingMessage;
	}
	
	/**
	 * Gets the birthdate not verified.
	 * 
	 * @return the birthdateNotVerified
	 */
	public CodeSetElement getBirthdateNotVerified() {
		return birthdateNotVerified;
	}
	
	/**
	 * Gets the courtOrderedLicenseDelay.
	 * 
	 * @return the courtOrderedLicenseDelay
	 */
	public CodeSetElement getCourtOrderedLicenseDelay() {
		return courtOrderedLicenseDelay;
	}
	
	/**
	 * Gets the courtSuspension.
	 * 
	 * @return the courtSuspension
	 */
	public CodeSetElement getCourtSuspension() {
		return courtSuspension;
	}
	
	/**
	 * Gets the deceasedCode.
	 * 
	 * @return the deceasedCode
	 */
	public CodeSetElement getDeceasedCode() {
		return deceasedCode;
	}
	
	/**
	 * Gets the discretionarySuspensionOrRevocation.
	 * 
	 * @return the discretionarySuspensionOrRevocation
	 */
	public CodeSetElement getDiscretionarySuspensionOrRevocation() {
		return discretionarySuspensionOrRevocation;
	}
	
	/**
	 * Gets the dishonoredChecks.
	 * 
	 * @return the dishonoredChecks
	 */
	public CodeSetElement getDishonoredChecks() {
		return dishonoredChecks;
	}
	
	/**
	 * Gets the dl application date.
	 * 
	 * @return the dlApplicationDate
	 */
	public Date getDlApplicationDate() {
		return dlApplicationDate;
	}
	
	/**
	 * Gets the dl renewal message code.
	 * 
	 * @return the dlRenewalMessageCode
	 */
	public CodeSetElement getDlRenewalMessageCode() {
		return dlRenewalMessageCode;
	}
	
	/**
	 * Gets the double record code.
	 * 
	 * @return the doubleRecordCode
	 */
	public CodeSetElement getDoubleRecordCode() {
		return doubleRecordCode;
	}
	
	/**
	 * Gets the eligibleForRestriction04.
	 * 
	 * @return the eligibleForRestriction04
	 */
	public CodeSetElement getEligibleForRestriction04() {
		return eligibleForRestriction04;
	}
	
	/**
	 * Gets the error message.
	 * 
	 * @return the error message
	 */
	@Deprecated
	public String getErrorMessage() {
		return errorMessage;
	}
	
	/**
	 * Gets the existing dl incomplete application reason code.
	 * 
	 * @return the existingDlIncompleteApplicationReasonCode
	 */
	public CodeSetElement getExistingDlIncompleteApplicationReasonCode() {
		return existingDlIncompleteApplicationReasonCode;
	}
	
	/**
	 * Gets the existing id incomplete application reason code.
	 * 
	 * @return the existingIdIncompleteApplicationReasonCode
	 */
	public CodeSetElement getExistingIdIncompleteApplicationReasonCode() {
		return existingIdIncompleteApplicationReasonCode;
	}
	
	/**
	 * Gets the failureToAppear.
	 * 
	 * @return the failureToAppear
	 */
	public CodeSetElement getFailureToAppear() {
		return failureToAppear;
	}
	
	/**
	 * Gets the failureToPay.
	 * 
	 * @return the failureToPay
	 */
	public CodeSetElement getFailureToPay() {
		return failureToPay;
	}
	
	/**
	 * Gets the financialResponsibility.
	 * 
	 * @return the financialResponsibility
	 */
	public CodeSetElement getFinancialResponsibility() {
		return financialResponsibility;
	}
	
	/**
	 * Gets the frPenaltyFeeNotDue.
	 * 
	 * @return the frPenaltyFeeNotDue
	 */
	public CodeSetElement getFrPenaltyFeeNotDue() {
		return frPenaltyFeeNotDue;
	}
	
	/**
	 * Gets the fr proof not on file.
	 * 
	 * @return the fr proof not on file
	 */
	public CodeSetElement getFrProofNotOnFile() {
		return frProofNotOnFile;
	}
	
	/**
	 * Gets the hit counter.
	 *
	 * @return the hitCounter
	 */
	public Integer getHitCounter() {
		return hitCounter;
	}
	
	/**
	 * Gets the id application date.
	 * 
	 * @return the idApplicationDate
	 */
	public Date getIdApplicationDate() {
		return idApplicationDate;
	}
	
	/**
	 * Gets the id card returned unclaimed.
	 * 
	 * @return the idCardReturnedUnclaimed
	 */
	public CodeSetElement getIdCardReturnedUnclaimed() {
		return idCardReturnedUnclaimed;
	}
	
	/**
	 * Gets the id photo retake.
	 * 
	 * @return the idPhotoRetake
	 */
	public CodeSetElement getIdPhotoRetake() {
		return idPhotoRetake;
	}
	
	/**
	 * Gets the id renewal message code.
	 * 
	 * @return the idRenewalMessageCode
	 */
	public CodeSetElement getIdRenewalMessageCode() {
		return idRenewalMessageCode;
	}
	
	/**
	 * Gets the ineligible to renew by mail.
	 * 
	 * @return the ineligibleToRenewByMail
	 */
	public CodeSetElement getIneligibleToRenewByMail() {
		return ineligibleToRenewByMail;
	}
	
	/**
	 * Gets the invalid class change.
	 * 
	 * @return the invalidClassChange
	 */
	public CodeSetElement getInvalidClassChange() {
		return invalidClassChange;
	}
	
	/**
	 * Gets the license location code.
	 * 
	 * @return the licenseLocationCode
	 */
	public CodeSetElement getLicenseLocationCode() {
		return licenseLocationCode;
	}
	
	/**
	 * Gets the mandatorySuspensionOrRevocation.
	 * 
	 * @return the mandatorySuspensionOrRevocation
	 */
	public CodeSetElement getMandatorySuspensionOrRevocation() {
		return mandatorySuspensionOrRevocation;
	}
	
	/**
	 * Gets the multipleNameAndBirthDateMatch.
	 * 
	 * @return the multipleNameAndBirthDateMatch
	 */
	public CodeSetElement getMultipleNameAndBirthDateMatch() {
		return multipleNameAndBirthDateMatch;
	}
	
	/**
	 * Gets the onProbation.
	 * 
	 * @return the onProbation
	 */
	public CodeSetElement getOnProbation() {
		return onProbation;
	}
	
	/**
	 * Gets the otherLicense.
	 * 
	 * @return the otherLicense
	 */
	public CodeSetElement getOtherLicense() {
		return otherLicense;
	}
	
	/**
	 * Gets the pendingApplicationReasonCode.
	 * 
	 * @return the pendingApplicationReasonCode
	 */
	public CodeSetElement getPendingApplicationReasonCode() {
		return pendingApplicationReasonCode;
	}
	
	/**
	 * Gets the person.
	 * 
	 * @return the person
	 */
	public Person getPerson() {
		return person;
	}
	
	/**
	 * Gets the photo retake not ok indicator.
	 * 
	 * @return the photoRetakeNotOkIndicator
	 */
	public CodeSetElement getPhotoRetakeNotOkIndicator() {
		return photoRetakeNotOkIndicator;
	}
	
	/**
	 * Gets the physicalOrMentalProblem.
	 * 
	 * @return the physicalOrMentalProblem
	 */
	public CodeSetElement getPhysicalOrMentalProblem() {
		return physicalOrMentalProblem;
	}
	
	/**
	 * Gets the physicalOrMentalProblemCode.
	 * 
	 * @return the physicalOrMentalProblemCode
	 */
	public CodeSetElement getPhysicalOrMentalProblemCode() {
		return physicalOrMentalProblemCode;
	}
	
	/**
	 * Gets the recordSecurityFileCode.
	 *
	 * @return the recordSecurityFileCode
	 */
	public CodeSetElement getRecordSecurityFileCode() {
		return recordSecurityFileCode;
	}
	
	/**
	 * Gets the reinstatementInProgress.
	 * 
	 * @return the reinstatementInProgress
	 */
	public CodeSetElement getReinstatementInProgress() {
		return reinstatementInProgress;
	}
	
	/**
	 * Gets the reissueFeeDue.
	 * 
	 * @return the reissueFeeDue
	 */
	public CodeSetElement getReissueFeeDue() {
		return reissueFeeDue;
	}
	
	/**
	 * Gets the onProbation.
	 * 
	 * @return the onProbation
	 */
	public CodeSetElement getRestrictionRemovalFeeDue() {
		return restrictionRemovalFeeDue;
	}
	
	/**
	 * Gets the return code.
	 * 
	 * @return the return code
	 */
	public CodeSetElement getReturnCode() {
		return returnCode;
	}
	
	/**
	 * Gets the routeCode.
	 * 
	 * @return the routeCode
	 */
	public CodeSetElement getRouteCode() {
		return routeCode;
	}
	
	/**
	 * Gets the segments.
	 * 
	 * @return the segments
	 */
	public List <CodeSetElement> getSegments() {
		return segments;
	}
	
	/**
	 * Gets the service of order needed.
	 * 
	 * @return the serviceOfOrderNeeded
	 */
	public CodeSetElement getServiceOfOrderNeeded() {
		return serviceOfOrderNeeded;
	}
	
	/**
	 * Gets the Social Security Document.
	 * 
	 * @return the socialSecurityDocument
	 */
	public SocialSecurityDocument getSocialSecurityDocument() {
		return this.getPerson().getSocialSecurityDocument();
	}
	
	/**
	 * Gets the suspense or revoke on file indicator.
	 * 
	 * @return the suspenseOrRevokeOnFileIndicator
	 */
	public CodeSetElement getSuspenseOrRevokeOnFileIndicator() {
		return suspenseOrRevokeOnFileIndicator;
	}
	
	/**
	 * Gets the type application error.
	 * 
	 * @return the typeApplicationError
	 */
	public CodeSetElement getTypeApplicationError() {
		return typeApplicationError;
	}
	
	/**
	 * Gets the user verified ssn code.
	 * 
	 * @return the userVerifiedSsnCode
	 */
	public CodeSetElement getUserVerifiedSsnCode() {
		return userVerifiedSsnCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((isAbsentParent == null) ? 0 : isAbsentParent.hashCode());
		result = prime
				* result
				+ ((applicationHeldPendingCode == null) ? 0
						: applicationHeldPendingCode.hashCode());
		result = prime
				* result
				+ ((applicationPendingIndicator == null) ? 0
						: applicationPendingIndicator.hashCode());
		result = prime
				* result
				+ ((applicationSubrecordMissingMessage == null) ? 0
						: applicationSubrecordMissingMessage.hashCode());
		result = prime
				* result
				+ ((birthdateNotVerified == null) ? 0 : birthdateNotVerified
						.hashCode());
		result = prime
				* result
				+ ((courtOrderedLicenseDelay == null) ? 0
						: courtOrderedLicenseDelay.hashCode());
		result = prime * result
				+ ((courtSuspension == null) ? 0 : courtSuspension.hashCode());
		result = prime * result
				+ ((deceasedCode == null) ? 0 : deceasedCode.hashCode());
		result = prime
				* result
				+ ((discretionarySuspensionOrRevocation == null) ? 0
						: discretionarySuspensionOrRevocation.hashCode());
		result = prime
				* result
				+ ((dishonoredChecks == null) ? 0 : dishonoredChecks.hashCode());
		result = prime
				* result
				+ ((dlApplicationDate == null) ? 0 : dlApplicationDate
						.hashCode());
		result = prime
				* result
				+ ((dlRenewalMessageCode == null) ? 0 : dlRenewalMessageCode
						.hashCode());
		result = prime
				* result
				+ ((doubleRecordCode == null) ? 0 : doubleRecordCode.hashCode());
		result = prime
				* result
				+ ((eligibleForRestriction04 == null) ? 0
						: eligibleForRestriction04.hashCode());
		result = prime * result
				+ ((errorMessage == null) ? 0 : errorMessage.hashCode());
		result = prime
				* result
				+ ((existingDlIncompleteApplicationReasonCode == null) ? 0
						: existingDlIncompleteApplicationReasonCode.hashCode());
		result = prime
				* result
				+ ((existingIdIncompleteApplicationReasonCode == null) ? 0
						: existingIdIncompleteApplicationReasonCode.hashCode());
		result = prime * result
				+ ((failureToAppear == null) ? 0 : failureToAppear.hashCode());
		result = prime * result
				+ ((failureToPay == null) ? 0 : failureToPay.hashCode());
		result = prime
				* result
				+ ((financialResponsibility == null) ? 0
						: financialResponsibility.hashCode());
		result = prime
				* result
				+ ((frPenaltyFeeNotDue == null) ? 0 : frPenaltyFeeNotDue
						.hashCode());
		result = prime
				* result
				+ ((frProofNotOnFile == null) ? 0 : frProofNotOnFile.hashCode());
		result = prime
				* result
				+ ((idApplicationDate == null) ? 0 : idApplicationDate
						.hashCode());
		result = prime
				* result
				+ ((idCardReturnedUnclaimed == null) ? 0
						: idCardReturnedUnclaimed.hashCode());
		result = prime * result
				+ ((idPhotoRetake == null) ? 0 : idPhotoRetake.hashCode());
		result = prime
				* result
				+ ((idRenewalMessageCode == null) ? 0 : idRenewalMessageCode
						.hashCode());
		result = prime
				* result
				+ ((ineligibleToRenewByMail == null) ? 0
						: ineligibleToRenewByMail.hashCode());
		result = prime
				* result
				+ ((invalidClassChange == null) ? 0 : invalidClassChange
						.hashCode());
		result = prime
				* result
				+ ((licenseLocationCode == null) ? 0 : licenseLocationCode
						.hashCode());
		result = prime
				* result
				+ ((mandatorySuspensionOrRevocation == null) ? 0
						: mandatorySuspensionOrRevocation.hashCode());
		result = prime
				* result
				+ ((multipleNameAndBirthDateMatch == null) ? 0
						: multipleNameAndBirthDateMatch.hashCode());
		result = prime * result
				+ ((onProbation == null) ? 0 : onProbation.hashCode());
		result = prime * result
				+ ((otherLicense == null) ? 0 : otherLicense.hashCode());
		result = prime
				* result
				+ ((pendingApplicationReasonCode == null) ? 0
						: pendingApplicationReasonCode.hashCode());
		result = prime * result + ((person == null) ? 0 : person.hashCode());
		result = prime
				* result
				+ ((photoRetakeNotOkIndicator == null) ? 0
						: photoRetakeNotOkIndicator.hashCode());
		result = prime
				* result
				+ ((physicalOrMentalProblem == null) ? 0
						: physicalOrMentalProblem.hashCode());
		result = prime
				* result
				+ ((physicalOrMentalProblemCode == null) ? 0
						: physicalOrMentalProblemCode.hashCode());
		result = prime
				* result
				+ ((reinstatementInProgress == null) ? 0
						: reinstatementInProgress.hashCode());
		result = prime * result
				+ ((reissueFeeDue == null) ? 0 : reissueFeeDue.hashCode());
		result = prime
				* result
				+ ((restrictionRemovalFeeDue == null) ? 0
						: restrictionRemovalFeeDue.hashCode());
		result = prime * result
				+ ((returnCode == null) ? 0 : returnCode.hashCode());
		result = prime * result
				+ ((routeCode == null) ? 0 : routeCode.hashCode());
		result = prime * result
				+ ((segments == null) ? 0 : segments.hashCode());
		result = prime
				* result
				+ ((serviceOfOrderNeeded == null) ? 0 : serviceOfOrderNeeded
						.hashCode());
		result = prime
				* result
				+ ((suspenseOrRevokeOnFileIndicator == null) ? 0
						: suspenseOrRevokeOnFileIndicator.hashCode());
		result = prime
				* result
				+ ((typeApplicationError == null) ? 0 : typeApplicationError
						.hashCode());
		result = prime
				* result
				+ ((userVerifiedSsnCode == null) ? 0 : userVerifiedSsnCode
						.hashCode());
		return result;
	}
	
	/**
	 * Gets the absent parent indicator.
	 * 
	 * @return the absentParentIndicator
	 */
	public Boolean isAbsentParent() {
		return isAbsentParent;
	}
	
	/**
	 * Sets the absent parent indicator.
	 *
	 * @param isAbsentParent the new absent parent indicator
	 */
	public void setAbsentParentIndicator(Boolean isAbsentParent) {
		this.isAbsentParent = isAbsentParent;
	}
	
	/**
	 * Sets the application held pending code.
	 * 
	 * @param applicationHeldPendingCode the applicationHeldPendingCode to set
	 */
	public void setApplicationHeldPendingCode(
			CodeSetElement applicationHeldPendingCode) {
		this.applicationHeldPendingCode = applicationHeldPendingCode;
	}
	
	/**
	 * Sets the application pending indicator.
	 * 
	 * @param applicationPendingIndicator the applicationPendingIndicator to set
	 */
	public void setApplicationPendingIndicator(
			CodeSetElement applicationPendingIndicator) {
		this.applicationPendingIndicator = applicationPendingIndicator;
	}
	
	/**
	 * Sets the application subrecord missing message.
	 * 
	 * @param applicationSubrecordMissingMessage the new application subrecord missing message
	 */
	public void setApplicationSubrecordMissingMessage(
			CodeSetElement applicationSubrecordMissingMessage) {
		this.applicationSubrecordMissingMessage = applicationSubrecordMissingMessage;
	}
	
	/**
	 * Sets the birthdate not verified.
	 * 
	 * @param birthdateNotVerified the birthdateNotVerified to set
	 */
	public void setBirthdateNotVerified(CodeSetElement birthdateNotVerified) {
		this.birthdateNotVerified = birthdateNotVerified;
	}
	
	/**
	 * Sets the courtOrderedLicenseDelay.
	 * 
	 * @param courtOrderedLicenseDelay the courtOrderedLicenseDelay to set
	 */
	public void setCourtOrderedLicenseDelay(
			CodeSetElement courtOrderedLicenseDelay) {
		this.courtOrderedLicenseDelay = courtOrderedLicenseDelay;
	}
	
	/**
	 * Sets the courtSuspension.
	 * 
	 * @param courtSuspension the courtSuspension to set
	 */
	public void setCourtSuspension(CodeSetElement courtSuspension) {
		this.courtSuspension = courtSuspension;
	}
	
	/**
	 * Sets the deceasedCode.
	 * 
	 * @param deceasedCode the deceasedCode to set
	 */
	public void setDeceasedCode(CodeSetElement deceasedCode) {
		this.deceasedCode = deceasedCode;
	}
	
	/**
	 * Sets the discretionarySuspensionOrRevocation.
	 * 
	 * @param discSuspensionOrRevocation the disc suspension or revocation
	 */
	public void setDiscretionarySuspensionOrRevocation(
			CodeSetElement discSuspensionOrRevocation) {
		this.discretionarySuspensionOrRevocation = discSuspensionOrRevocation;
	}
	
	/**
	 * Sets the dishonoredChecks.
	 * 
	 * @param dishonoredChecks the dishonoredChecks to set
	 */
	public void setDishonoredChecks(CodeSetElement dishonoredChecks) {
		this.dishonoredChecks = dishonoredChecks;
	}
	
	/**
	 * Sets the dl application date.
	 * 
	 * @param dlApplicationDate the dlApplicationDate to set
	 */
	public void setDlApplicationDate(Date dlApplicationDate) {
		this.dlApplicationDate = dlApplicationDate;
	}
	
	/**
	 * Sets the dl renewal message code.
	 * 
	 * @param dlRenewalMessageCode the dlRenewalMessageCode to set
	 */
	public void setDlRenewalMessageCode(CodeSetElement dlRenewalMessageCode) {
		this.dlRenewalMessageCode = dlRenewalMessageCode;
	}
	
	/**
	 * Sets the double record code.
	 * 
	 * @param doubleRecordCode the doubleRecordCode to set
	 */
	public void setDoubleRecordCode(CodeSetElement doubleRecordCode) {
		this.doubleRecordCode = doubleRecordCode;
	}
	
	/**
	 * Sets the eligibleForRestriction04.
	 * 
	 * @param eligibleForRestriction04 the eligibleForRestriction04 to set
	 */
	public void setEligibleForRestriction04(
			CodeSetElement eligibleForRestriction04) {
		this.eligibleForRestriction04 = eligibleForRestriction04;
	}
	
	/**
	 * Sets the error message.
	 * 
	 * @param errorMessage the new error message
	 */
	@Deprecated
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	/**
	 * Sets the existing dl incomplete application reason code.
	 * 
	 * @param existingDlIncompleteApplicationReasonCode the existingDlIncompleteApplicationReasonCode to set
	 */
	public void setExistingDlIncompleteApplicationReasonCode(
			CodeSetElement existingDlIncompleteApplicationReasonCode) {
		this.existingDlIncompleteApplicationReasonCode = existingDlIncompleteApplicationReasonCode;
	}
	
	/**
	 * Sets the existing id incomplete application reason code.
	 * 
	 * @param existingIdIncompleteApplicationReasonCode the existingIdIncompleteApplicationReasonCode to set
	 */
	public void setExistingIdIncompleteApplicationReasonCode(
			CodeSetElement existingIdIncompleteApplicationReasonCode) {
		this.existingIdIncompleteApplicationReasonCode = existingIdIncompleteApplicationReasonCode;
	}
	
	/**
	 * Sets the failureToAppear.
	 * 
	 * @param failureToAppear the failureToAppear to set
	 */
	public void setFailureToAppear(CodeSetElement failureToAppear) {
		this.failureToAppear = failureToAppear;
	}
	
	/**
	 * Sets the failureToPay.
	 * 
	 * @param failureToPay the failureToPay to set
	 */
	public void setFailureToPay(CodeSetElement failureToPay) {
		this.failureToPay = failureToPay;
	}
	
	/**
	 * Sets the financialResponsibility.
	 * 
	 * @param financialResponsibility the financialResponsibility to set
	 */
	public void setFinancialResponsibility(
			CodeSetElement financialResponsibility) {
		this.financialResponsibility = financialResponsibility;
	}
	
	/**
	 * Sets the frPenaltyFeeNotDue.
	 * 
	 * @param frPenaltyFeeNotDue the frPenaltyFeeNotDue to set
	 */
	public void setFrPenaltyFeeNotDue(CodeSetElement frPenaltyFeeNotDue) {
		this.frPenaltyFeeNotDue = frPenaltyFeeNotDue;
	}
	
	/**
	 * Sets the fr proof not on file.
	 * 
	 * @param frProofNotOnFile the new fr proof not on file
	 */
	public void setFrProofNotOnFile(CodeSetElement frProofNotOnFile) {
		this.frProofNotOnFile = frProofNotOnFile;
	}
	
	/**
	 * Sets the hit counter.
	 *
	 * @param hitCounter the hitCounter to set
	 */
	public void setHitCounter(Integer hitCounter) {
		this.hitCounter = hitCounter;
	}
	
	/**
	 * Sets the id application date.
	 * 
	 * @param idApplicationDate the idApplicationDate to set
	 */
	public void setIdApplicationDate(Date idApplicationDate) {
		this.idApplicationDate = idApplicationDate;
	}
	
	/**
	 * Sets the id card returned unclaimed.
	 * 
	 * @param idCardReturnedUnclaimed the idCardReturnedUnclaimed to set
	 */
	public void setIdCardReturnedUnclaimed(
			CodeSetElement idCardReturnedUnclaimed) {
		this.idCardReturnedUnclaimed = idCardReturnedUnclaimed;
	}
	
	/**
	 * Sets the id photo retake.
	 * 
	 * @param idPhotoRetake the idPhotoRetake to set
	 */
	public void setIdPhotoRetake(CodeSetElement idPhotoRetake) {
		this.idPhotoRetake = idPhotoRetake;
	}
	
	/**
	 * Sets the id renewal message code.
	 * 
	 * @param idRenewalMessageCode the idRenewalMessageCode to set
	 */
	public void setIdRenewalMessageCode(CodeSetElement idRenewalMessageCode) {
		this.idRenewalMessageCode = idRenewalMessageCode;
	}
	
	/**
	 * Sets the ineligible to renew by mail.
	 * 
	 * @param ineligibleToRenewByMail the ineligibleToRenewByMail to set
	 */
	public void setIneligibleToRenewByMail(
			CodeSetElement ineligibleToRenewByMail) {
		this.ineligibleToRenewByMail = ineligibleToRenewByMail;
	}
	
	/**
	 * Sets the invalid class change.
	 * 
	 * @param invalidClassChange the invalidClassChange to set
	 */
	public void setInvalidClassChange(CodeSetElement invalidClassChange) {
		this.invalidClassChange = invalidClassChange;
	}
	
	/**
	 * Sets the license location code.
	 * 
	 * @param licenseLocationCode the licenseLocationCode to set
	 */
	public void setLicenseLocationCode(CodeSetElement licenseLocationCode) {
		this.licenseLocationCode = licenseLocationCode;
	}
	
	/**
	 * Sets the mandatorySuspensionOrRevocation.
	 * 
	 * @param mandatorySuspensionOrRevocation the mandatorySuspensionOrRevocation to set
	 */
	public void setMandatorySuspensionOrRevocation(
			CodeSetElement mandatorySuspensionOrRevocation) {
		this.mandatorySuspensionOrRevocation = mandatorySuspensionOrRevocation;
	}
	
	/**
	 * Sets the multipleNameAndBirthDateMatch.
	 * 
	 * @param multipleNameAndBirthDateMatch the multipleNameAndBirthDateMatch to set
	 */
	public void setMultipleNameAndBirthDateMatch(
			CodeSetElement multipleNameAndBirthDateMatch) {
		this.multipleNameAndBirthDateMatch = multipleNameAndBirthDateMatch;
	}
	
	/**
	 * Sets the onProbation.
	 * 
	 * @param onProbation the onProbation to set
	 */
	public void setOnProbation(CodeSetElement onProbation) {
		this.onProbation = onProbation;
	}
	
	/**
	 * Sets the otherLicense.
	 * 
	 * @param otherLicense the otherLicense to set
	 */
	public void setOtherLicense(CodeSetElement otherLicense) {
		this.otherLicense = otherLicense;
	}
	
	/**
	 * Sets the pendingApplicationReasonCode.
	 * 
	 * @param pendingApplicationReasonCode the pendingApplicationReasonCode to set
	 */
	public void setPendingApplicationReasonCode(
			CodeSetElement pendingApplicationReasonCode) {
		this.pendingApplicationReasonCode = pendingApplicationReasonCode;
	}
	
	/**
	 * Sets the person.
	 * 
	 * @param person the person to set
	 */
	public void setPerson(Person person) {
		this.person = person;
	}
	
	/**
	 * Sets the photo retake not ok indicator.
	 * 
	 * @param photoRetakeNotOkIndicator the photoRetakeNotOkIndicator to set
	 */
	public void setPhotoRetakeNotOkIndicator(
			CodeSetElement photoRetakeNotOkIndicator) {
		this.photoRetakeNotOkIndicator = photoRetakeNotOkIndicator;
	}
	
	/**
	 * Sets the physicalOrMentalProblem.
	 * 
	 * @param physicalOrMentalProblem the physicalOrMentalProblem to set
	 */
	public void setPhysicalOrMentalProblem(
			CodeSetElement physicalOrMentalProblem) {
		this.physicalOrMentalProblem = physicalOrMentalProblem;
	}
	
	/**
	 * Sets the physicalOrMentalProblemCode.
	 * 
	 * @param physicalOrMentalProblemCode the physicalOrMentalProblemCode to set
	 */
	public void setPhysicalOrMentalProblemCode(
			CodeSetElement physicalOrMentalProblemCode) {
		this.physicalOrMentalProblemCode = physicalOrMentalProblemCode;
	}
	
	/**
	 * Sets the recordSecurityFileCode.
	 *
	 * @param recordSecurityFileCode the recordSecurityFileCode to set
	 */
	public void setRecordSecurityFileCode(CodeSetElement recordSecurityFileCode) {
		this.recordSecurityFileCode = recordSecurityFileCode;
	}
	
	/**
	 * Sets the reinstatementInProgress.
	 * 
	 * @param reinstatementInProgress the reinstatementInProgress to set
	 */
	public void setReinstatementInProgress(
			CodeSetElement reinstatementInProgress) {
		this.reinstatementInProgress = reinstatementInProgress;
	}
	
	/**
	 * Sets the reissueFeeDue.
	 * 
	 * @param reissueFeeDue the reissueFeeDue to set
	 */
	public void setReissueFeeDue(CodeSetElement reissueFeeDue) {
		this.reissueFeeDue = reissueFeeDue;
	}
	
	/**
	 * Sets the restrictionRemovalFeeDue.
	 * 
	 * @param restrictionRemovalFeeDue the restrictionRemovalFeeDue to set
	 */
	public void setRestrictionRemovalFeeDue(
			CodeSetElement restrictionRemovalFeeDue) {
		this.restrictionRemovalFeeDue = restrictionRemovalFeeDue;
	}
	
	/**
	 * Sets the return code.
	 * 
	 * @param returnCode the new return code
	 */
	public void setReturnCode(CodeSetElement returnCode) {
		this.returnCode = returnCode;
	}
	
	/**
	 * Sets the routeCode.
	 * 
	 * @param routeCode the routeCode to set
	 */
	public void setRouteCode(CodeSetElement routeCode) {
		this.routeCode = routeCode;
	}
	
	/**
	 * Sets the service of order needed.
	 * 
	 * @param serviceOfOrderNeeded the serviceOfOrderNeeded to set
	 */
	public void setServiceOfOrderNeeded(CodeSetElement serviceOfOrderNeeded) {
		this.serviceOfOrderNeeded = serviceOfOrderNeeded;
	}
	
	/**
	 * Sets the Social Security Document.
	 * 
	 * @param socialSecurityDocument the socialSecurityDocument to set
	 */
	public void setSocialSecurityDocument(
			SocialSecurityDocument socialSecurityDocument) {
		this.getPerson().getDocuments().add(socialSecurityDocument);
	}
	
	/**
	 * Sets the suspense or revoke on file indicator.
	 * 
	 * @param suspenseOrRevokeOnFileIndicator the suspenseOrRevokeOnFileIndicator to set
	 */
	public void setSuspenseOrRevokeOnFileIndicator(
			CodeSetElement suspenseOrRevokeOnFileIndicator) {
		this.suspenseOrRevokeOnFileIndicator = suspenseOrRevokeOnFileIndicator;
	}
	
	/**
	 * Sets the type application error.
	 * 
	 * @param typeApplicationError the typeApplicationError to set
	 */
	public void setTypeApplicationError(CodeSetElement typeApplicationError) {
		this.typeApplicationError = typeApplicationError;
	}
	
	/**
	 * Sets the user verified ssn code.
	 * 
	 * @param userVerifiedSsnCode the userVerifiedSsnCode to set
	 */
	public void setUserVerifiedSsnCode(CodeSetElement userVerifiedSsnCode) {
		this.userVerifiedSsnCode = userVerifiedSsnCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.license.impl.AbstractDlRecord#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("applicationHeldPendingCode",
				applicationHeldPendingCode, anIndent, aBuilder);
		outputKeyValue("applicationPendingIndicator",
				applicationPendingIndicator, anIndent, aBuilder);
		outputKeyValue("applicationSubrecordMissingMessage",
				applicationSubrecordMissingMessage, anIndent, aBuilder);
		outputKeyValue("birthdateNotVerified", birthdateNotVerified, anIndent,
				aBuilder);
		outputKeyValue("courtOrderedLicenseDelay", courtOrderedLicenseDelay,
				anIndent, aBuilder);
		outputKeyValue("courtSuspension", courtSuspension, anIndent, aBuilder);
		outputKeyValue("deceasedCode", deceasedCode, anIndent, aBuilder);
		outputKeyValue("discretionarySuspensionOrRevocation",
				discretionarySuspensionOrRevocation, anIndent, aBuilder);
		outputKeyValue("dishonoredChecks", dishonoredChecks, anIndent, aBuilder);
		outputKeyValue("dlApplicationDate", dlApplicationDate, anIndent,
				aBuilder);
		outputKeyValue("dlRenewalMessageCode", dlRenewalMessageCode, anIndent,
				aBuilder);
		outputKeyValue("doubleRecordCode", doubleRecordCode, anIndent, aBuilder);
		outputKeyValue("eligibleForRestriction04", eligibleForRestriction04,
				anIndent, aBuilder);
		//outputKeyValue("errorMessage", errorMessage, anIndent, aBuilder); 
		outputKeyValue("existingDlIncompleteApplicationReasonCode",
				existingDlIncompleteApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("existingIdIncompleteApplicationReasonCode",
				existingIdIncompleteApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("failureToAppear", failureToAppear, anIndent, aBuilder);
		outputKeyValue("failureToPay", failureToPay, anIndent, aBuilder);
		outputKeyValue("financialResponsibility", financialResponsibility,
				anIndent, aBuilder);
		outputKeyValue("frPenaltyFeeNotDue", frPenaltyFeeNotDue, anIndent,
				aBuilder);
		outputKeyValue("frProofNotOnFile", frProofNotOnFile, anIndent, aBuilder);
		outputKeyValue("hitCounter", hitCounter, anIndent, aBuilder);
		outputKeyValue("idApplicationDate", idApplicationDate, anIndent,
				aBuilder);
		outputKeyValue("idCardReturnedUnclaimed", idCardReturnedUnclaimed,
				anIndent, aBuilder);
		outputKeyValue("idPhotoRetake", idPhotoRetake, anIndent, aBuilder);
		outputKeyValue("idRenewalMessageCode", idRenewalMessageCode, anIndent,
				aBuilder);
		outputKeyValue("ineligibleToRenewByMail", ineligibleToRenewByMail,
				anIndent, aBuilder);
		outputKeyValue("invalidClassChange", invalidClassChange, anIndent,
				aBuilder);
		outputKeyValue("isAbsentParent", isAbsentParent, anIndent, aBuilder);
		outputKeyValue("licenseLocationCode", licenseLocationCode, anIndent,
				aBuilder);
		outputKeyValue("mandatorySuspensionOrRevocation",
				mandatorySuspensionOrRevocation, anIndent, aBuilder);
		outputKeyValue("multipleNameAndBirthDateMatch",
				multipleNameAndBirthDateMatch, anIndent, aBuilder);
		outputKeyValue("onProbation", onProbation, anIndent, aBuilder);
		outputKeyValue("otherLicense", otherLicense, anIndent, aBuilder);
		outputKeyValue("pendingApplicationReasonCode",
				pendingApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("person", person, anIndent, aBuilder);
		outputKeyValue("photoRetakeNotOkIndicator", photoRetakeNotOkIndicator,
				anIndent, aBuilder);
		outputKeyValue("physicalOrMentalProblem", physicalOrMentalProblem,
				anIndent, aBuilder);
		outputKeyValue("physicalOrMentalProblemCode",
				physicalOrMentalProblemCode, anIndent, aBuilder);
		outputKeyValue("recordSecurityFileCode", recordSecurityFileCode,
				anIndent, aBuilder);
		outputKeyValue("reinstatementInProgress", reinstatementInProgress,
				anIndent, aBuilder);
		outputKeyValue("reissueFeeDue", reissueFeeDue, anIndent, aBuilder);
		outputKeyValue("restrictionRemovalFeeDue", restrictionRemovalFeeDue,
				anIndent, aBuilder);
		outputKeyValue("returnCode", returnCode, anIndent, aBuilder);
		outputKeyValue("routeCode", routeCode, anIndent, aBuilder);
		outputKeyValue("segments", segments, anIndent, aBuilder);
		outputKeyValue("serviceOfOrderNeeded", serviceOfOrderNeeded, anIndent,
				aBuilder);
		outputKeyValue("suspenseOrRevokeOnFileIndicator",
				suspenseOrRevokeOnFileIndicator, anIndent, aBuilder);
		outputKeyValue("typeApplicationError", typeApplicationError, anIndent,
				aBuilder);
		outputKeyValue("userVerifiedSsnCode", userVerifiedSsnCode, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * Get the classOfRecord.
	 *
	 * @return the classOfRecord
	 */
	public String getClassOfRecord() {
		return classOfRecord;
	}
	
	/**
	 * Set classOfRecord.
	 *
	 * @param classOfRecord the classOfRecord to set
	 */
	public void setClassOfRecord(String classOfRecord) {
		this.classOfRecord = classOfRecord;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DlRecord.java,v $
 *  Revision 1.38  2012/09/14 20:59:44  mwhys
 *  Added copy constructor. (Defect 6900 - AN fatal)
 *
 *  Revision 1.37  2011/03/18 18:22:26  mwtjc1
 *  isDlPended and isIdPended method modified
 *
 *  Revision 1.36  2011/03/18 18:20:20  mwtjc1
 *  isDlPended, isIdPended and isBothDlAndIdPended methods added
 *
 *  Revision 1.35  2011/01/30 09:04:06  mwhxb3
 *  Added new fields
 *
 *  Revision 1.34  2010/12/07 22:08:52  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.33  2010/12/07 03:54:58  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.32  2010/12/06 19:03:44  mwyxg1
 *  add recordSecurityFileCode
 *
 *  Revision 1.31  2010/09/15 18:47:43  mwuxb
 *  Removed licenseExtensionCode.
 *
 *  Revision 1.30  2010/08/24 01:27:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.29  2010/07/30 18:13:01  mwpxr4
 *  Corrected getter method.
 *
 *  Revision 1.28  2010/07/29 22:37:09  mwpxr4
 *  Updated datatype to Boolean from CodeSetElement.
 *
 *  Revision 1.27  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.23.2.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.26  2010/06/07 18:28:32  mwuxb
 *  Updated type of hitCounter from String to Integer.
 *
 *  Revision 1.25  2010/06/07 16:53:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.24  2010/06/03 16:49:18  mwuxb
 *  added variable hitCounter
 *
 *  Revision 1.23  2010/05/27 14:37:53  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.22  2010/05/20 22:37:02  mwtjc1
 *  returnCode is made CodeSetElement
 *
 *  Revision 1.21  2010/05/01 17:31:54  mwuxb
 *  Pushed down variables in segment E to EliRecord
 *
 *  Revision 1.20  2010/04/28 20:11:02  mwtjc1
 *  updated
 *
 *  Revision 1.19  2010/04/28 18:57:14  mwtjc1
 *  updated
 *
 *  Revision 1.18  2010/04/28 18:33:20  mwtjc1
 *  updated
 *
 *  Revision 1.17  2010/04/28 18:30:58  mwtjc1
 *  updated
 *
 *  Revision 1.16  2010/04/28 18:27:08  mwtjc1
 *  applicationSubrecordMissingMessage added
 *
 *  Revision 1.15  2010/04/28 18:25:51  mwtjc1
 *  updated
 *
 *  Revision 1.14  2010/04/24 20:40:09  mwuxb
 *  updates for segment C
 *
 *  Revision 1.13  2010/04/24 20:32:09  mwuxb
 *  updates for segment C
 *
 *  Revision 1.12  2010/04/24 20:24:48  mwuxb
 *  updates for segment C
 *
 *  Revision 1.11  2010/04/24 19:14:52  mwuxb
 *  updates for segment C
 *
 *  Revision 1.10  2010/04/24 00:10:47  mwtjc1
 *  updated
 *
 *  Revision 1.9  2010/04/23 22:29:57  mwtjc1
 *  updated
 *
 *  Revision 1.8  2010/04/23 22:29:14  mwtjc1
 *  updated
 *
 *  Revision 1.7  2010/04/23 22:25:41  mwtjc1
 *  updated
 *
 *  Revision 1.6  2010/04/22 16:00:40  mwtjc1
 *  errorMessage field is moved from EliRecord to DlmRecord
 *
 *  Revision 1.5  2010/04/21 01:13:23  mwuxb
 *  Updated
 *
 *  Revision 1.4  2010/04/21 01:12:11  mwuxb
 *  Moved segments to DlRecord
 *
 *  Revision 1.3  2010/04/21 01:05:45  mwuxb
 *  Moved person to DlRecord
 *
 *  Revision 1.2  2010/04/21 00:54:57  mwuxb
 *  Added AbstractDlRecord
 *
*/
