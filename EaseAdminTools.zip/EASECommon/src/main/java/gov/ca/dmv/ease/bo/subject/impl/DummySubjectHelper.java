/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.locator.AddressType;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.locator.impl.Locator;

import java.util.Iterator;
import java.util.List;

/**
 * Description: I am Subject Helper.
 * File: DummySubjectHelper.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: Jan 28, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/04/07 04:04:55 $
 * Last Changed By: $Author: mwhys $
 * @deprecated All the Helper methods are moved to Subject
 * @see Subject
 */
@Deprecated
public class DummySubjectHelper {
	/** The Mailing Address Type.*/
	public static final AddressType ADDRESS_TYPE_MAIL = AddressType.MAILING;
	/** The Residential Address Type.*/
	public static final AddressType ADDRESS_TYPE_RES = AddressType.RESIDENTIAL;
	
	/**
	 * Get the mailing address of a person.
	 * 
	 * @param person the person
	 * @return the mailing address
	 */
	public static Address getMailingAddress(Person person) {
		List <Locator> locators = person.getLocators();
		if (locators != null) {
			Iterator <Locator> locatorItr = locators.iterator();
			while (locatorItr.hasNext()) {
				Locator locator = locatorItr.next();
				if (locator instanceof Address) {
					Address address = (Address) locator;
					if (address != null) {
						AddressType addressType = address.getAddressType();
						if (addressType != null
								&& ADDRESS_TYPE_MAIL.equals(addressType)) {
							return address;
						}
					}
				}
			}
		}
		Address address = new Address(AddressType.MAILING);
		setMailingAddress(person, address);
		return address;
	}
	
	/**
	 * Get the residence address of a person.
	 * 
	 * @return the residence address
	 */
	public static Address getResidenceAddress(Person person) {
		List <Locator> locators = person.getLocators();
		if (locators != null) {
			Iterator <Locator> locatorItr = locators.iterator();
			while (locatorItr.hasNext()) {
				Locator locator = locatorItr.next();
				if (locator instanceof Address) {
					Address address = (Address) locator;
					if (address != null) {
						AddressType addressType = address.getAddressType();
						if (addressType != null
								&& DummySubjectHelper.ADDRESS_TYPE_RES
										.equals(addressType)) {
							return address;
						}
					}
				}
			}
		}
		Address address = new Address(AddressType.RESIDENTIAL);
		DummySubjectHelper.setResidenceAddress(person, address);
		return address;
	}
	
	/**
	 * Set the mailing address of a person to an existing list.
	 * 
	 * @return the mailing address
	 */
	public static void setMailingAddress(Person person, Address mailingAddress) {
		// If the mailing address is null then do nothing
		if (mailingAddress == null) {
			return;
		}
		List <Locator> locators = person.getLocators();
		if (locators != null && locators.size() > 0) {
			boolean exists = false;
			for (int index = 0; index < locators.size(); index++) {
				Address address = (Address) locators.get(index);
				if (address != null) {
					AddressType addressType = address.getAddressType();
					if (addressType != null
							&& DummySubjectHelper.ADDRESS_TYPE_MAIL
									.equals(addressType)) {
						locators.remove(index);
						locators.add(index, mailingAddress);
						exists = true;
						break;
					}
				} // if loop
			} // for loop
			if (!exists) {
				locators.add(mailingAddress);
			}
		}
		else {
			locators.add(mailingAddress);
		}
		//person.addAddress(mailingAddress);
	}
	
	/**
	 * Set the residence address of a person to an existing list.
	 * 
	 * @return the residence address
	 */
	public static void setResidenceAddress(Person person,
			Address residenceAddress) {
		// If the residence address is null then do nothing
		if (residenceAddress == null) {
			return;
		}
		List <Locator> locators = person.getLocators();
		if (locators != null && locators.size() > 0) {
			boolean exists = false;
			for (int index = 0; index < locators.size(); index++) {
				Address address = (Address) locators.get(index);
				if (address != null) {
					AddressType addressType = address.getAddressType();
					if (addressType != null
							&& DummySubjectHelper.ADDRESS_TYPE_RES
									.equals(addressType)) {
						locators.remove(index);
						locators.add(index, residenceAddress);
						exists = true;
						break;
					}
				}
			} // for loop
			if (!exists) {
				locators.add(residenceAddress);
			}
		}
		else {
			locators.add(residenceAddress);
		}
		//person.addAddress(residenceAddress);
	}
}
