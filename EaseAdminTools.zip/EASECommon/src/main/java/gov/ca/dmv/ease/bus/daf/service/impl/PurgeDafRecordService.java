/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.daf.service.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.tx.impl.Transaction;
import gov.ca.dmv.ease.bus.daf.request.impl.PurgeDafRecordRequestBus;
import gov.ca.dmv.ease.bus.daf.response.impl.PurgeDafRecordResponseBus;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SaveOrUpdateBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SaveOrUpdateBusinessObjectResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * Description: PurgeDafRecord business Service
 * File: PurgeDafRecordService.java
 * Module:  gov.ca.dmv.ease.bus.dl.service.impl
 * Created: Mar 4, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2012/08/20 21:14:26 $
 * Last Changed By: $Author: mwhys $
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class PurgeDafRecordService {
	/** Logger */
	private static final Log LOGGER = LogFactory
			.getLog(PurgeDafRecordService.class);
	
	/**
	 * Create PersistenceServiceRequestFactory bean from Application context.
	 * 
	 * @return
	 */
	private static PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return (PersistenceServiceRequestFactory) EaseApplicationContext
				.getApplicationContext().getBean(
						"persistenceServiceRequestFactory");
	}
	
	/** 
	 * Purges a DAF record.
	 * @param busRequest
	 * @return PurgeDafRecordResponseBus
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public static PurgeDafRecordResponseBus execute(
			PurgeDafRecordRequestBus busRequest) {
		PurgeDafRecordResponseBus busResponse = null;
		try {
			Transaction transaction = new Transaction();
			if (busRequest.hasDafNumber()) {
				transaction.setTransactionIdentifier(busRequest.getDafNumber());
			}
			else {
				transaction.setLicenseNumber(busRequest.getDlNumber());
			}
			transaction.setOfficeId(busRequest.getUserContext().getOfficeId());
			IPersistenceServiceRequest request = getPersistenceServiceRequestFactory()
					.createRetrieveBusinessObjectRequest(
							busRequest.getUserContext(), transaction);
			RetrieveBusinessObjectResponse perResponse = (RetrieveBusinessObjectResponse) request
					.execute();
			if (perResponse.hasErrors()) {
				busResponse = new PurgeDafRecordResponseBus(perResponse
						.getErrorCollector());
			}
			else if (perResponse.getResults() != null
					&& perResponse.getResults().size() > 0) {
				//Loop through all the DAF records with the same DL/ID number
				for (IBusinessObject businessObject : perResponse.getResults()) {
					Transaction objectToDelete = (Transaction) businessObject;
					if (!busRequest.isItHardDelete()) {
						//Soft delete of DAF record
						objectToDelete.setTransactionData(null);// soft delete
						objectToDelete.beInactive();
						SaveOrUpdateBusinessObjectRequest saveOrUpdateBusinessObjectRequest = (SaveOrUpdateBusinessObjectRequest) getPersistenceServiceRequestFactory()
								.createSaveOrUpdateBusinessObjectRequest(
										busRequest.getUserContext(),
										objectToDelete);
						SaveOrUpdateBusinessObjectResponse saveOrUpdateBusinessObjectResponse = saveOrUpdateBusinessObjectRequest
								.execute();
						if (saveOrUpdateBusinessObjectResponse.hasErrors()) {
							if (LOGGER.isInfoEnabled()) {
								LOGGER.info("Error on soft delete of DAF # '"
										+ objectToDelete
												.getTransactionIdentifier()
										+ "' with license # '"
										+ objectToDelete.getLicenseNumber()
										+ "'");
							}
							busResponse = new PurgeDafRecordResponseBus(
									saveOrUpdateBusinessObjectResponse
											.getErrorCollector());
						}
						else {
							if (LOGGER.isInfoEnabled()) {
								LOGGER.info("Successful soft delete of DAF # '"
										+ objectToDelete
												.getTransactionIdentifier()
										+ "' with license # '"
										+ objectToDelete.getLicenseNumber()
										+ "'");
							}
							busResponse = new PurgeDafRecordResponseBus();
						}
					}
					else {
						//Hard delete of DAF record
						DeleteBusinessObjectRequest deleteBusinessObjectRequest = (DeleteBusinessObjectRequest) getPersistenceServiceRequestFactory()
								.createDeleteBusinessObjectRequest(
										busRequest.getUserContext(),
										objectToDelete);
						DeleteBusinessObjectResponse deleteBusinessObjectResponse = deleteBusinessObjectRequest
								.execute();
						if (deleteBusinessObjectResponse.hasErrors()) {
							if (LOGGER.isInfoEnabled()) {
								LOGGER.info("Error on hard delete of DAF # '"
										+ objectToDelete
												.getTransactionIdentifier()
										+ "' with license # '"
										+ objectToDelete.getLicenseNumber()
										+ "'");
							}
							busResponse = new PurgeDafRecordResponseBus(
									deleteBusinessObjectResponse
											.getErrorCollector());
						}
						else {
							if (LOGGER.isInfoEnabled()) {
								LOGGER.info("Successful hard delete of DAF # '"
										+ objectToDelete
												.getTransactionIdentifier()
										+ "' with license # '"
										+ objectToDelete.getLicenseNumber()
										+ "'");
							}
							busResponse = new PurgeDafRecordResponseBus();
						}
					}
				}
			}
			else {
				throw new ApplicationException("No DAF record.");
			}
		}
		catch (Exception e) {
			IErrorCollector collector = new ErrorCollector();
			collector.register(e);
			busResponse = new PurgeDafRecordResponseBus(collector);
		}
		return busResponse;
	}
}
/**
 * Modification History:
 * 
 * $Log: PurgeDafRecordService.java,v $
 * Revision 1.5  2012/08/20 21:14:26  mwhys
 * Check DAF number before checking DL number.
 *
 * Revision 1.4  2012/08/16 00:19:57  mwhys
 * Set "status" to inacive for soft-purge. (Defect 7150)
 *
 * Revision 1.3  2012/01/20 22:59:20  mwhys
 * Updated to delete all the DAF records with matching DL/ID number.
 *
 * Revision 1.2  2011/03/08 19:22:01  mwkfh
 * added logging
 *
 * Revision 1.1  2011/02/18 01:01:07  mwkfh
 * moved purgeDafService to common
 *
 * Revision 1.11  2011/01/14 23:09:22  mwtjc1
 * logic of hard deleting the daf record added
 *
 * Revision 1.10  2011/01/05 22:38:09  mwtjc1
 *  hard delete of daf record is replaced by soft delete
 *
 * Revision 1.9  2010/09/13 04:41:51  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.8  2010/08/31 18:00:58  mwhys
 * Marked Service(s) as transient.
 *
 * Revision 1.7  2010/03/29 18:28:07  mwyxg1
 * update comments
 *
 * Revision 1.6  2010/03/26 23:09:40  mwyxg1
 * create new response on happy path
 *
 * Revision 1.5  2010/03/26 22:15:01  mwcsj3
 * Injecting Persistence factory using Spring
 *
 * Revision 1.4  2010/03/26 21:22:13  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.3  2010/03/25 21:37:25  mwyxg1
 * add new
 *
 */
