/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.financial.impl.CashPayment;
import gov.ca.dmv.ease.bo.financial.impl.CheckPayment;
import gov.ca.dmv.ease.bo.financial.impl.DebitPayment;
import gov.ca.dmv.ease.bo.financial.impl.Invoice;
import gov.ca.dmv.ease.bo.financial.impl.InvoiceItem;
import gov.ca.dmv.ease.bo.financial.impl.Payment;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Description: This class captures information pertaining to the payments for removing court restrictions.
 * File: RemoveCourtRestrictionApplication.java
 * Module:  gov.ca.dmv.ease.bo.misc
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class DriverInformationRequestApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4627821635271352846L;
	/** The dl info. */
	private CodeSetElement dlInfo;
	/** The ani info code. */
	private CodeSetElement aniInfoCode;
	/** For BCTR command use. */
	/** The print data length. */
	private Integer printDataLength;
	/** The print data line count. */
	private Integer printDataLineCount;
	/** The citation data ind. */
	private boolean citationDataInd = false;
	
	/**
	 * Gets the dl info.
	 *
	 * @return the dlInfo
	 */
	public CodeSetElement getDlInfo() {
		return dlInfo;
	}
	
	/**
	 * Sets the dl info.
	 *
	 * @param dlInfo the dlInfo to set
	 */
	public void setDlInfo(CodeSetElement dlInfo) {
		this.dlInfo = dlInfo;
	}
	
	/**
	 * Gets the ani info code.
	 *
	 * @return the aniInfoCode
	 */
	public CodeSetElement getAniInfoCode() {
		return aniInfoCode;
	}
	
	/**
	 * Sets the ani info code.
	 *
	 * @param aniInfoCode the aniInfoCode to set
	 */
	public void setAniInfoCode(CodeSetElement aniInfoCode) {
		this.aniInfoCode = aniInfoCode;
	}
	
	/**
	 * Instantiates a new application.
	 */
	public DriverInformationRequestApplication() {
		super();
		Invoice invoice = new Invoice();
		List <InvoiceItem> items = new ArrayList <InvoiceItem>();
		invoice.setInvoiceItems(items);
		List <Payment> payments = new ArrayList <Payment>();
		invoice.setPayments(payments);
		CashPayment cashPayment = new CashPayment();
		payments.add(cashPayment);
		CheckPayment checkPayment = new CheckPayment();
		payments.add(checkPayment);
		DebitPayment debitPayment = new DebitPayment();
		payments.add(debitPayment);
		setInvoice(invoice);
		setFeeRequired(true);
	}
	
	/**
	 * Gets the prints the data length.
	 *
	 * @return the prints the data length
	 */
	public Integer getPrintDataLength() {
		return printDataLength;
	}
	
	/**
	 * Sets the prints the data length.
	 *
	 * @param printDataLength the new prints the data length
	 */
	public void setPrintDataLength(Integer printDataLength) {
		this.printDataLength = printDataLength;
	}
	
	/**
	 * Gets the prints the data line count.
	 *
	 * @return the prints the data line count
	 */
	public Integer getPrintDataLineCount() {
		return printDataLineCount;
	}
	
	/**
	 * Sets the prints the data line count.
	 *
	 * @param printDataLineCount the new prints the data line count
	 */
	public void setPrintDataLineCount(Integer printDataLineCount) {
		this.printDataLineCount = printDataLineCount;
	}
	
	/**
	 * Gets the citation data ind.
	 *
	 * @return the citation data ind
	 */
	public boolean getCitationDataInd() {
		return citationDataInd;
	}
	
	/**
	 * Sets the citation data ind.
	 *
	 * @param citationDataInd the new citation data ind
	 */
	public void setCitationDataInd(boolean citationDataInd) {
		this.citationDataInd = citationDataInd;
	}
	
	/**
	 * Return a pre-calculated fee.
	 * 
	 * @return a pre-calculated fee.
	 */
	public BigDecimal getExistingFee() {
		return getInvoice().getInvoiceTotal();
	}
	
	/**
	 * Return true if ANI inquiry.
	 * 
	 * @return a boolean 
	 */
	public boolean hasAniInquiry() {
		if (getApplicant() == null) {
			return false;
		}
		else {
			PersonName personName = getApplicant().getCurrentName();
			if (personName == null) {
				return false;
			}
			else {
				String firstName = personName.getFirstName();
				if (EaseUtil.isNotBlank(firstName)) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}
}
