/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.factory.ILocalPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.AddLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueMultipleLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MoveLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveLowestSequenceRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SeedLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;
import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;
import gov.ca.dmv.ease.tus.persist.service.impl.LocalPersistenceService;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

/**
 * Description: Implementation of the IInventoryPersistenceServiceRequestFactory request
 * interface 
 * 
 * File: LocalPersistenceServiceRequestFactory.java
 * Module: gov.ca.dmv.ease.tus.print.request.factory.impl 
 * Created: Jul 26, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.22 $
 * Last Changed: $Date: 2011/11/03 23:42:06 $
 * Last Changed By: $Author: mwkfh $
 */
public class LocalPersistenceServiceRequestFactory implements
		ILocalPersistenceServiceRequestFactory {
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(LocalPersistenceServiceRequestFactory.class);
	/** The local persistence service. */
	private transient LocalPersistenceService localPersistenceService;
	/** The SINGLETON. */
	private static ILocalPersistenceServiceRequestFactory SINGLETON;

	/**
	 * Gets the single instance of LocalPersistenceServiceRequestFactory.
	 * 
	 * @return single instance of LocalPersistenceServiceRequestFactory
	 */
	public static ILocalPersistenceServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static synchronized void initSingleton() {
		if (SINGLETON == null) {
			try {
				if (!EaseUtil.isNotNull(EaseApplicationContext
						.getApplicationContext())) {
					SINGLETON = new LocalPersistenceServiceRequestFactory();
				}
				else {
					SINGLETON = (ILocalPersistenceServiceRequestFactory) EaseApplicationContext
							.getApplicationContext().getBean(
									"localPersistenceServiceRequestFactory");
				}
			}
			catch (NoSuchBeanDefinitionException e) {
				SINGLETON = new LocalPersistenceServiceRequestFactory();
			}
		}
	}

	/**
	 * Instantiates a new persistence service request factory.
	 */
	private LocalPersistenceServiceRequestFactory() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createAddLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence)
	 */
	public AddLocalInventoryRequest createAddLocalInventoryRequest(
			IUserContext userContext,
			IContiguousItemSequence contiguousItemSequence) {
		if (EaseUtil.isNullOrBlank(contiguousItemSequence)) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		AddLocalInventoryRequest request = new AddLocalInventoryRequest(
				userContext, contiguousItemSequence);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createDeleteLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence)
	 */
	public DeleteLocalInventoryRequest createDeleteLocalInventoryRequest(
			IUserContext userContext,
			IContiguousItemSequence contiguousItemSequence) {
		if (EaseUtil.isNullOrBlank(contiguousItemSequence)) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		DeleteLocalInventoryRequest request = new DeleteLocalInventoryRequest(
				userContext, contiguousItemSequence);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createIssueLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, LocalInventoryItem)
	 */
	public IssueLocalInventoryRequest createIssueLocalInventoryRequest(
			IUserContext userContext, IInventoryItem domainObject) {
		IssueLocalInventoryRequest request = new IssueLocalInventoryRequest(
				userContext, domainObject);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createIssueMultipleLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, LocalInventoryItem)
	 */
	public IssueMultipleLocalInventoryRequest createIssueMultipleLocalInventoryRequest(
			IUserContext userContext, IInventoryItem domainObject, int quantity) {
		IssueMultipleLocalInventoryRequest request = new IssueMultipleLocalInventoryRequest(
				userContext, domainObject, quantity);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createMoveLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, List, IItemLocation)
	 */
	public MoveLocalInventoryRequest createMoveLocalInventoryRequest(
			IUserContext userContext, IContiguousItemSequence sequenceToUpdate,
			IItemLocation targetLocation) {
		if (sequenceToUpdate == null/* || sequenceToUpdate.isEmpty()*/) {
			throw new EaseValidationException(
					"invalid list of objects to persist in " + this);
		}
		MoveLocalInventoryRequest request = new MoveLocalInventoryRequest(
				userContext, sequenceToUpdate, targetLocation);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createRetrieveLowestSequenceRequest(gov.ca.dmv.ease.fw.process.IUserContext, String, String)
	 */
	public RetrieveLowestSequenceRequest createRetrieveLowestSequenceRequest(
			IUserContext userContext, String itemTypeCode, String officeId) {
		RetrieveLowestSequenceRequest request = new RetrieveLowestSequenceRequest(
				userContext, itemTypeCode, officeId);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createSeedLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.Collection)
	 */
	public SeedLocalInventoryRequest createSeedLocalInventoryRequest(
			IUserContext userContext,
			List <IContiguousItemSequence> sequenceList) {
		if (sequenceList == null/* || boColl.isEmpty()*/) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		SeedLocalInventoryRequest request = new SeedLocalInventoryRequest(
				userContext, sequenceList);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createSeedLocalInventoryRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.Collection)
	 */
	public SeedLocalInventoryRequest createSeedLocalInventoryRequest(
			IUserContext userContext, String officeId, String processorId,
			List <IContiguousItemSequence> sequenceList) {
		if (sequenceList == null/* || boColl.isEmpty()*/) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		SeedLocalInventoryRequest request = new SeedLocalInventoryRequest(
				userContext, officeId, processorId, sequenceList);
		request
				.setPersistenceService((IPersistenceService) getLocalPersistenceService());
		return request;
	}

	/**
	 * Gets the local persistence service.
	 * 
	 * @return the local persistence service
	 */
	private ILocalPersistenceService getLocalPersistenceService() {
		if (localPersistenceService == null) {
			setLocalPersistenceService((LocalPersistenceService) EaseApplicationContext
					.getApplicationContext().getBean("localPersistenceService"));
		}
		return localPersistenceService;
	}

	/**
	 * Sets the local persistence service.
	 * 
	 * @param localPersistenceService the local persistenceService to set
	 */
	public void setLocalPersistenceService(
			LocalPersistenceService localPersistenceService) {
		this.localPersistenceService = localPersistenceService;
	}
}
/**
 * Modification History:
 * 
 * $Log: LocalPersistenceServiceRequestFactory.java,v $
 * Revision 1.22  2011/11/03 23:42:06  mwkfh
 * added createRetrieveLowestSequenceRequest
 *
 * Revision 1.21  2011/10/27 18:30:03  mwkfh
 * synchronized initSingleton
 *
 * Revision 1.20  2011/09/23 00:20:30  mwkfh
 * added ProcessorId
 *
 * Revision 1.19  2011/07/06 17:10:48  mwkfh
 * updated for local inventory redesign
 *
 * Revision 1.18  2011/06/09 18:32:21  mwkfh
 * added DeleteLocalInventoryRequest
 *
 * Revision 1.17  2011/06/08 17:33:31  mwkfh
 * added AddLocalInventoryRequest
 *
 * Revision 1.16  2011/03/18 01:15:47  mwkfh
 * updated initSingleton to check for null app context
 *
 * Revision 1.15  2011/03/17 20:29:29  mwkfh
 * added try catch to initSingleton
 *
 * Revision 1.14  2011/01/10 21:48:06  mwkfh
 * added purge office id to seed action
 *
 * Revision 1.13  2011/01/07 17:45:53  mwkfh
 * updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 * Revision 1.12  2010/12/05 00:03:18  mwkfh
 * added IssueMultipleLocalInventoryReequest/Response
 *
 * Revision 1.11  2010/12/03 16:52:09  mwkfh
 * added move local inventory
 *
 * Revision 1.10  2010/12/02 17:00:13  mwkfh
 * allowed empty list in createSeedLocalInventoryRequest
 *
 * Revision 1.9  2010/10/22 21:11:01  mwkfh
 * deleted unneeded methods
 *
 * Revision 1.8  2010/10/06 22:32:39  mwkfh
 * updated to use IInventoryItem
 *
 * Revision 1.7  2010/09/30 23:34:39  mwkfh
 * changed SINGLETON to the interface
 *
 * Revision 1.6  2010/09/23 23:13:38  mwkfh
 * updated initSingleton()
 *
 * Revision 1.5  2010/09/23 16:25:59  mwkfh
 * updated initSingleton to return Spring bean
 *
 * Revision 1.4  2010/09/22 19:04:45  mwkfh
 * readded setLocalPersistenceService
 *
 * Revision 1.3  2010/09/21 18:51:59  mwkfh
 * removed setLocalPersistenceService()
 *
 * Revision 1.2  2010/09/20 23:21:11  mwpxp2
 * Added stubs for: getting current item coutn, for issuing inventory item, and for setting thresholds
 *
 * Revision 1.1  2010/09/20 18:25:44  mwkfh
 * moved from EASEDL
 *
 * Revision 1.5  2010/09/20 16:49:52  mwkfh
 * added issue local inv item
 *
 * Revision 1.4  2010/09/15 18:59:01  mwpxp2
 * Added static getInstance/0 and po singleton
 *
 * Revision 1.3  2010/09/14 16:31:33  mwkfh
 * updated local inventory persistence
 *
 * Revision 1.2  2010/09/14 00:44:03  mwkfh
 * made LocalPersistenceService non-static
 *
 * Revision 1.1  2010/09/13 16:54:40  mwkfh
 * added LocalPersistenceService and Seed for inventory
 *
 */
