package gov.ca.dmv.ease.bo.admin;

/**
 * Description: I am interface for employee principal implementations
 * File: IEmployeePrincipal.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/21 23:21:51 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEmployeePrincipal {
	/**
	 * Gets the principal id.
	 * 
	 * @return the principal id
	 */
	String getPrincipalId();
}
/**
 *  Modification History:
 *
 *  $Log: IEmployeePrincipal.java,v $
 *  Revision 1.1  2011/10/21 23:21:51  mwpxp2
 *  Extracted from existing implementation
 *
 */
