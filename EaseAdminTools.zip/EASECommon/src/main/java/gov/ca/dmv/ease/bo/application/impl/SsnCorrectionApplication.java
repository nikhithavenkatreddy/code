/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class captures information to update the Social Security Number on the driver record
 * File: SsnCorrectionApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class SsnCorrectionApplication extends Application {

	private static final long serialVersionUID = -8877404085461441496L;
	/** This represents if acceptable document proof submitted 
	 * Sample Codes: D - Verified by DMV; R - Verification Required; 
	 * X - Not Verified
	 */
	private CodeSetElement userVerifiedSsnCode;

	/**
	 * @return the userVerifiedSsnCode
	 */
	public CodeSetElement getUserVerifiedSsnCode() {
		return userVerifiedSsnCode;
	}

	/**
	 * @param userVerifiedSsnCode the userVerifiedSsnCode to set
	 */
	public void setUserVerifiedSsnCode(CodeSetElement userVerifiedSsnCode) {
		this.userVerifiedSsnCode = userVerifiedSsnCode;
	}
}
