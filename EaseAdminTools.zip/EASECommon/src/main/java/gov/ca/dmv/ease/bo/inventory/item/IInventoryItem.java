/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.util.Date;

/**
 * Description: I am interface for inventory item:
 * - I have type
 * - I have a sequence number
 * 
 * 
 * File: IInventoryItem.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.12 $
 * Last Changed: $Date: 2011/09/23 21:21:21 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryItem extends IBusinessObject, IItemLocation,
		IValidatable {
	/**
	 * Be available.
	 */
	void beAvailable();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#beIssued()
	 */
	void beIssued();

	/**
	 * Gets the pattern.
	 * 
	 * @return the pattern
	 */
	ISequencePattern getPattern();

	/**
	 * Gets the processor id.
	 * 
	 * @return the processor id
	 */
	String getProcessorId();

	/**
	 * Gets the sequence no.
	 * 
	 * @return the sequence no
	 */
	ISequence getSequenceNo();

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	IItemType getType();

	/**
	 * Checks for been issued.
	 * 
	 * @return the boolean
	 */
	boolean hasBeenIssued();

	/**
	 * Checks for been issued by.
	 * 
	 * @return the string
	 */
	String hasBeenIssuedBy();

	/**
	 * Checks for been issued on.
	 * 
	 * @return the date
	 */
	Date hasBeenIssuedOn();

	/**
	 * Checks for sequence no.
	 * 
	 * @param sequenceNo the sequence no
	 * 
	 * @return true, if successful
	 */
	boolean hasSequenceNo(ISequence sequenceNo);

	/**
	 * Checks for type.
	 * 
	 * @param type the type
	 * 
	 * @return true, if successful
	 */
	boolean hasType(IItemType type);

	/**
	 * Checks if is assigned to station.
	 * 
	 * @return true, if is assigned to station
	 */
	boolean isAssignedToStation();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#isAvailable()
	 */
	boolean isAvailable();

	/**
	 * Sets the target location.
	 * 
	 * @param theTarget the new target location
	 */
	void setTargetLocation(IItemLocation theTarget);
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryItem.java,v $
 *  Revision 1.12  2011/09/23 21:21:21  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.11  2010/10/11 17:46:33  mwpxp2
 *  Extended IValidatable
 *
 *  Revision 1.10  2010/10/08 01:52:24  mwpxp2
 *  Added getPattern/0
 *
 *  Revision 1.9  2010/10/05 20:38:13  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.8  2010/10/05 17:42:33  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.7  2010/09/17 21:30:04  mwpxp2
 *  Put back beAvailable/0
 *
 *  Revision 1.6  2010/09/17 21:25:17  mwpxp2
 *  Removed references to obsoleted item state
 *
 *  Revision 1.5  2010/09/15 16:08:19  mwpxp2
 *  Added setTargetLocation/1
 *
 *  Revision 1.4  2010/09/14 18:02:13  mwpxp2
 *  Extended IItemLocation - no changes to the existing code otherwise
 *
 *  Revision 1.3  2010/09/02 19:02:04  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/09/02 18:42:49  mwpxp2
 *  Added support for station assignment
 *
 *  Revision 1.1  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.6  2010/09/02 17:54:56  mwpxp2
 *  Added getOfficeId/0
 *
 *  Revision 1.5  2010/09/01 20:33:39  mwpxp2
 *  Added reference to Inventory using inventoryId
 *
 *  Revision 1.4  2010/08/31 23:30:55  mwpxp2
 *  Cleanup
 *
 *  Revision 1.3  2010/08/31 03:48:11  mwpxp2
 *  Added hasSequenceNo/1, hasType/1, isInState/1
 *
 *  Revision 1.2  2010/08/30 22:34:27  mwpxp2
 *  Changed hasBeenIssued to return boolean
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
