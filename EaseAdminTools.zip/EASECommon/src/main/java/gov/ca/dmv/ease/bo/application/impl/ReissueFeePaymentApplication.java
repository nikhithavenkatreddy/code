/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.financial.impl.Fee;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description: This class captures information pertaining to the re-issuance fee collected.
 * when the customer submits a court referral form (DL 103) 
 * File: ReissueFeePayment.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.16 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class ReissueFeePaymentApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2912979550714578623L;
	/** The date fees paid. */
	private Date dateFeesPaid;
	/** The fee indicators. */
	private Map <String, Integer> feeIndicators;
	/** FEE DETAILS LIST. */
	private List <Fee> feeDetailList;
	
	/**
	 * Instantiates a new application.
	 */
	public ReissueFeePaymentApplication() {
		super();
		setFeeRequired(true);
	}
	
	/**
	 * Gets the date fees paid.
	 *
	 * @return the dateFeesPaid
	 */
	public Date getDateFeesPaid() {
		return dateFeesPaid;
	}
	
	/**
	 * Sets the date fees paid.
	 *
	 * @param dateFeesPaid the dateFeesPaid to set
	 */
	public void setDateFeesPaid(Date dateFeesPaid) {
		this.dateFeesPaid = dateFeesPaid;
	}
	
	/**
	 * Gets the fee indicators.
	 *
	 * @return the feeIndicators
	 */
	public Map <String, Integer> getFeeIndicators() {
		if (feeIndicators == null) {
			setFeeIndicators(new HashMap <String, Integer>());
		}
		return feeIndicators;
	}
	
	/**
	 * Sets the fee indicators.
	 *
	 * @param feeIndicators the feeIndicators to set
	 */
	public void setFeeIndicators(Map <String, Integer> feeIndicators) {
		this.feeIndicators = feeIndicators;
	}
	
	/**
	 * Sets the fee detail list.
	 *
	 * @param feeDetailList the feeDetailList to set
	 */
	public void setFeeDetailList(List <Fee> feeDetailList) {
		this.feeDetailList = feeDetailList;
	}
	
	/**
	 * Gets the fee detail list.
	 *
	 * @return the feeDetailList
	 */
	public List <Fee> getFeeDetailList() {
		if (feeDetailList == null) {
			feeDetailList = new ArrayList <Fee>();
		}
		return feeDetailList;
	}
	
	/**
	 * Return total paid fees.
	 * 
	 * @return paidFees total paid fees
	 */
	public List <Fee> getPaidFeesPerFeeCode() {
		List <Fee> totalFeesPaidPerFeeCode = new ArrayList <Fee>();
		for (Fee fee : getFeeDetailList()) {
			if (fee != null && Fee.ACTION_CODE_P.equals(fee.getActionCode())) {
				totalFeesPaidPerFeeCode.add(fee);
			}
		}
		return totalFeesPaidPerFeeCode;
	}
	
	/**
	 * Return true if fee having fee code is added to totalFeesPaidPerFeeCode.
	 *
	 * @param totalFeesPaidPerFeeCode the total fees paid per fee code
	 * @param feeCode the fee code
	 * @return a boolean return true if fee having fee code is added to totalFeesPaidPerFeeCode
	 */
	protected boolean isFeeAdded(List <Fee> totalFeesPaidPerFeeCode,
			String feeCode) {
		if (EaseUtil.isNullOrBlank(totalFeesPaidPerFeeCode)
				|| EaseUtil.isNullOrBlank(feeCode)) {
			return false;
		}
		for (Fee fee : totalFeesPaidPerFeeCode) {
			if (fee != null && feeCode.equals(fee.getRateCode())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Return a fee with passed feeCode from totalFeesPaidPerFeeCode.
	 *
	 * @param totalFeesPaidPerFeeCode the total fees paid per fee code
	 * @param feeCode the fee code
	 * @return a Fee fee with passed feeCode from totalFeesPaidPerFeeCode
	 */
	protected Fee getFeeFrom(List <Fee> totalFeesPaidPerFeeCode, String feeCode) {
		if (!EaseUtil.isNullOrBlank(totalFeesPaidPerFeeCode)) {
			for (Fee fee : totalFeesPaidPerFeeCode) {
				if (fee != null && feeCode.equals(fee.getRateCode())) {
					return fee;
				}
			}
		}
		return null;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ReissueFeePaymentApplication.java,v $
 *  Revision 1.16  2012/03/14 01:57:55  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.15  2011/12/21 01:20:13  mwhys
 *  Updated getFeeIndicators() to initialize the Map. (Defect 1028)
 *
 *  Revision 1.14  2011/09/28 00:30:35  mwxxw
 *  For TTC 04M, no aggregation for fee code according to requirement.
 *
 *  Revision 1.13  2011/09/22 00:40:03  mwhxb3
 *  Refactored code to avoid null point exception.
 *
 *  Revision 1.12  2011/09/22 00:36:49  mwhxb3
 *  Refactored code to avoid null point exception.
 *
 *  Revision 1.11  2011/09/22 00:24:26  mwhxb3
 *  When fee detail in inquired, if it is null crate a new one and return.
 *
 *  Revision 1.10  2011/09/21 23:34:31  mwhxb3
 *  Check if fee is paid.
 *
 *  Revision 1.9  2011/09/21 22:24:15  mwhxb3
 *  Return total paid fees.
 *
 *  Revision 1.8  2011/01/29 22:51:55  mwrrv2
 *  Initializing isFeeRequired to true in the constructor.
 *
 *  Revision 1.7  2010/10/14 01:07:55  mwrrv3
 *  Added feeDetailList to the application.
 *
 */
