/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.license.impl.DrivingSchoolInstructorLicense;
import gov.ca.dmv.ease.bo.subject.impl.DrivingSchoolInstructor;

import java.util.List;

/**
 * Description: DrivingSchoolInstructor Application class is the subclass of
 * Application and represents the DrivingSchoolInstructor application document.
 * DrivingSchoolInstructor Application object encapsulates most of the
 * attributes of DrivingSchoolInstructor Application used for obtaining
 * DrivingSchoolInstructor license. File:
 * DrivingSchoolInstructorApplication.java Module:
 * gov.ca.dmv.ease.bo.document.impl Created: Apr 7, 2010
 * 
 * @author mwvxm6
 * @version $Revision: 1.14 $ Last Changed: $Date: 2011/01/29 22:51:56 $ Last
 *          Changed By: $Author: mwrrv2 $
 */
public class DrivingSchoolInstructorApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7003276619308844896L;
	/** The Driving School Instructor license applicant. */
	private DrivingSchoolInstructor applicant;
	/** The application types like Original/Renewal/Reinstatement. */
	private List <CodeSetElement> applicationTypeCodeList;
	/**
	 * A flag to set print required code for printing documents for this license
	 * application.
	 */
	private Boolean printRequired;

	/**
	 * Default Constructor.
	 */
	public DrivingSchoolInstructorApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * Gets the Applicant.
	 * 
	 * @return the applicant
	 */
	public DrivingSchoolInstructor getApplicant() {
		return applicant;
	}

	/**
	 * Gets the Application Type Code.
	 * 
	 * @return the applicationTypeCode
	 */
	public List <CodeSetElement> getApplicationTypeCodeList() {
		return applicationTypeCodeList;
	}

	/**
	 * Gets the Driver License. Driver License is associated with an Applicant.
	 * 
	 * @return the license
	 */
	public DrivingSchoolInstructorLicense getLicense() {
		return this.applicant.getDrivingSchoolInstructorLicense();
	}

	/**
	 * @return the isPrintRequired
	 */
	public Boolean isPrintRequired() {
		return printRequired;
	}

	/**
	 * Sets the Applicant.
	 * 
	 * @param applicant
	 *            the applicant to set
	 */
	public void setApplicant(DrivingSchoolInstructor applicant) {
		this.applicant = applicant;
	}

	/**
	 * Sets the Application Type Code.
	 * 
	 * @param applicationTypeCode
	 *            the applicationTypeCode to set
	 */
	public void setApplicationTypeCodeList(
			List <CodeSetElement> applicationTypeCodeList) {
		this.applicationTypeCodeList = applicationTypeCodeList;
	}

	/**
	 * Sets the Driver License. Driver License is associated with an Applicant.
	 * 
	 * @param license
	 *            the license to set
	 */
	public void setLicense(DrivingSchoolInstructorLicense license) {
		this.applicant.setDrivingSchoolInstructorLicense(license);
	}

	/**
	 * @param isPrintRequired
	 *            the isPrintRequired to set
	 */
	public void setPrintRequired(Boolean isPrintRequired) {
		this.printRequired = isPrintRequired;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("applicant", applicant, anIndent, aBuilder);
		outputKeyValue("applicationTypeCodeList", applicationTypeCodeList,
				anIndent, aBuilder);
		outputKeyValue("printRequired", printRequired, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 * Modification History:
 * 
 * $Log: DrivingSchoolInstructorApplication.java,v $
 * Revision 1.14  2011/01/29 22:51:56  mwrrv2
 * Initializing isFeeRequired to true in the constructor.
 *
 * Revision 1.13  2011/01/17 01:20:10  mwpxp2
 * Builk cleanup
 *
 * Revision 1.12  2010/12/07 22:08:36  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.11  2010/12/07 02:42:34  mwpxp2
 * Added toStringOn/1
 *
 * Revision 1.10  2010/09/28 17:58:07  mwjxa11
 * changed the comment
 * Revision 1.9 2010/09/25
 * 00:04:47 mwjxa11 refactored Revision 1.8 2010/09/24 23:58:16 mwjxa11 changed
 * fingerPrintRequired to printRequired Revision 1.7 2010/09/15 22:39:40 mwrrv3
 * Changed code set element to list of code set elements.
 * 
 */
