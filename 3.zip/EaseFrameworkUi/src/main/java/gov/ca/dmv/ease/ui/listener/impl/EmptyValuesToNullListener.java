/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlEaseInputText;
import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;

import java.util.Iterator;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlForm;
import javax.faces.component.html.HtmlInputSecret;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

/**
 * Description: The listener interface for receiving emptyValuesToNull events.
 * The class that is interested in processing a emptyValuesToNull
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addEmptyValuesToNullListener<code> method. When
 * the emptyValuesToNull event occurs, that object's appropriate
 * method is invoked.
 * File: EmptyValuesToNullListener.java
 * Module: gov.ca.dmv.ease.ui.listener.impl 
 * Created: Jul 28, 2009 
 * @author MWSKD2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EmptyValuesToNullListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 * This method provides notification that the processing for a 
	 * particular phase of the request processing life cycle is about to begin.
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		FacesContext facesContext = phaseEvent.getFacesContext();
		UIComponent uiFormComponent = null;
		for (Object aComponentObject : facesContext.getViewRoot().getChildren()) {
			if (aComponentObject instanceof HtmlForm) {
				uiFormComponent = (UIComponent) aComponentObject;
				setTrimToNull(facesContext, uiFormComponent);
			}
			else {
				UIComponent uiComponent = (UIComponent) aComponentObject;
				Iterator <?> childComponents = uiComponent.getChildren()
						.iterator();
				while (childComponents.hasNext()) {
					Object childComponent = childComponents.next();
					if (childComponent instanceof HtmlForm) {
						uiFormComponent = (UIComponent) childComponent;
						setTrimToNull(facesContext, uiFormComponent);
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 * Return the identifier of the request 
	 * processing phase during which this listener is 
	 * interested in processing PhaseEvent events
	 */
	public PhaseId getPhaseId() {
		return PhaseId.UPDATE_MODEL_VALUES;
	}

	/**
	 * Sets the trim to null.
	 * 
	 * @param facesContext the faces context
	 * @param uiComponent the UI component
	 */
	public void setTrimToNull(FacesContext facesContext, UIComponent uiComponent) {
		try {
			if (uiComponent instanceof HtmlInputText
					&& !(uiComponent instanceof HtmlSuggestedInputText)
					&& !(uiComponent instanceof HtmlEaseInputText)) {
				HtmlInputText htmlInputText = (HtmlInputText) uiComponent;
				if (htmlInputText.getValue() != null
						&& "".equals(htmlInputText.getValue())) {
					htmlInputText.setValue(null);
				}
				return;
			}
			if (uiComponent instanceof HtmlSelectOneMenu) {
				HtmlSelectOneMenu htmlSelectOneMenu = (HtmlSelectOneMenu) uiComponent;
				if (htmlSelectOneMenu.getValue() != null
						&& "".equals(htmlSelectOneMenu.getValue())) {
					htmlSelectOneMenu.setValue(null);
				}
				return;
			}
			if (uiComponent instanceof HtmlInputSecret) {
				HtmlInputSecret htmlInputSecret = (HtmlInputSecret) uiComponent;
				if (htmlInputSecret.getValue() != null
						&& "".equals(htmlInputSecret.getValue())) {
					htmlInputSecret.setValue(null);
				}
				return;
			}
		}
		catch (javax.faces.el.PropertyNotFoundException e) {
			doNothing();
		}
		if (uiComponent.getChildCount() == 0) {
			return;
		}
		// Recursive call 
		for (Object uiComponentChild : uiComponent.getChildren()) {
			setTrimToNull(facesContext, (UIComponent) uiComponentChild);
		}
	}

	/**
	 * Avoid empty catch block
	 */
	private void doNothing() {
	}
}
/**
 *  Modification History:
 *
 *  $Log: EmptyValuesToNullListener.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/09 16:36:19  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/08/03 20:33:27  mwrrv3
 *  Updated the code to support some of the group 5 TTCs.
 *
 *  Revision 1.2  2010/03/23 00:01:23  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/27 00:25:17  mwgxk2
 *  Added Comments.
 *
 *  Revision 1.1  2009/10/22 00:40:50  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.3  2009/10/03 21:38:44  mwpxp2
 *  Adjusted imports for fw, apph refactorings; added javadoc, file footer
 *
 */
