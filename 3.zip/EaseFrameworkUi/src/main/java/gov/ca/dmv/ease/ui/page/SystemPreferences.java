/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.page;

import java.io.Serializable;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 * Description: //TODO - provide description!
 * File: SystemPreferences.java
 * Module:  gov.ca.dmv.ease.ui.page
 * Created: Oct 26, 2009
 * @author MWSKD2
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2014/04/25 20:02:23 $
 * Last Changed By: $Author: mwjmf6 $
 */
public class SystemPreferences implements Serializable {
	/**
	 * The serialization Id
	 */
	private static final long serialVersionUID = -5193876457786513675L;
	/** The pattern. */
	private String pattern;
	/** The pattern2. */
	private String pattern2;
	/** The pattern3. */
	private String pattern3;
	/** The pattern4. */
	private String pattern4;
	/** The reg ex1. */
	private String regEx1;
	/** The reg ex10. */
	private String regEx10;
	/** The reg ex10 mesg. */
	private String regEx10Mesg;
	/** The reg ex11. */
	private String regEx11;
	/** The reg ex11 mesg. */
	private String regEx11Mesg;
	/** The reg ex12. */
	private String regEx12;
	/** The reg ex12 mesg. */
	private String regEx12Mesg;
	/** The reg ex13. */
	private String regEx13;
	/** The reg ex13 mesg. */
	private String regEx13Mesg;
	/** The reg ex14. */
	private String regEx14;
	/** The reg ex14 mesg. */
	private String regEx14Mesg;
	/** The reg ex15. */
	private String regEx15;
	/** The reg ex15 mesg. */
	private String regEx15Mesg;
	/** The reg ex16. */
	private String regEx16;
	/** The reg ex16 mesg. */
	private String regEx16Mesg;
	/** The reg ex17. */
	private String regEx17;
	/** The reg ex17 mesg. */
	private String regEx17Mesg;
	/** The reg ex18. */
	private String regEx18;
	/** The reg ex18 mesg. */
	private String regEx18Mesg;
	/** The reg ex19. */
	private String regEx19;
	/** The reg ex19 mesg. */
	private String regEx19Mesg;
	/** The reg ex1 mesg. */
	private String regEx1Mesg;
	/** The reg ex2. */
	private String regEx2;
	/** The reg ex20. */
	private String regEx20;
	/** The reg ex20 mesg. */
	private String regEx20Mesg;
	/** The regex21. */
	private String regEx21;
	/** The reg ex21 mesg. */
	private String regEx21Mesg;
	/** The regex22. */
	private String regEx22;
	/** The reg ex22 mesg. */
	private String regEx22Mesg;
	/** The reg ex2 mesg. */
	private String regEx2Mesg;
	/** The reg ex3. */
	private String regEx3;
	/** The reg ex3 mesg. */
	private String regEx3Mesg;
	/** The reg ex4. */
	private String regEx4;
	/** The reg ex4 mesg. */
	private String regEx4Mesg;
	/** The reg ex5. */
	private String regEx5;
	/** The reg ex5 mesg. */
	private String regEx5Mesg;
	/** The reg ex6. */
	private String regEx6;
	/** The reg ex6 mesg. */
	private String regEx6Mesg;
	/** The reg ex7. */
	private String regEx7;
	/** The reg ex7 mesg. */
	private String regEx7Mesg;
	/** The reg ex8. */
	private String regEx8;
	/** The reg ex8 mesg. */
	private String regEx8Mesg;
	/** The reg ex9. */
	private String regEx9;
	/** The reg ex9 mesg. */
	private String regEx9Mesg;
	/** The reg ex messages. */
	private Map <String, String> regExMessages;
	/** The scenario id. */
	private String scenarioId;
	/** The scenarios. */
	private Map <String, String> scenarios;
	/** The time zone. */
	private String timeZone;
	/** The regex 9. */
	private String regEx23;
	/** The regex 23 mesg. */
	private String regEx23Mesg;
	/** The invalidDlNo message. */
	private String invalidDlNo;
	/**
	 * The regex 24. 
	 * Added new regular expression to support A-Z 0-9 space and slash 
	 * in the street name field. 
	 */
	private String regEx24;
	/** The regex 24 mesg. */
	private String regEx24Mesg;
	/** This regular expression is used for 3 POS NAME */
	private String regEx25;
	/** The regex25mesg. */
	private String regEx25Mesg;
	/** The regex26. */
	private String regEx26;
	/** The regex26mesg. */
	private String regEx26Mesg;
	/** The regex27mesg. */
	private String regEx27Mesg;
	/** The regex27. */
	private String regEx27;
	/** Name accepts some special characters like (/ - ')*/
	private String nameRegEx;
	/**Error message for name*/
	private String nameRegExMesg;
	/** Name accepts special characters only(/-')*/
	private String noSpaceNameRegEx;
	/** The message for name*/
	private String noSpaceNameRegExMesg;
	/** Validate phone number NNN-NNN-NNNN */
	private String phoneNumberRegEx;
	/** Name with dash, no space */
	private String noSpaceNameWithDashRegEx;
	/** Error message for name */
	private String noSpaceNameWithDashRegExMesg;

	/**
	 * Gets the regex26.
	 *
	 * @return the regex26
	 */
	public String getRegEx26() {
		return regEx26;
	}

	/**
	 * Sets the regex26.
	 *
	 * @param regEx26 the new regex26
	 */
	public void setRegEx26(String regEx26) {
		this.regEx26 = regEx26;
	}

	/**
	 * Gets the regex26mesg.
	 *
	 * @return the regex26mesg
	 */
	public String getRegEx26Mesg() {
		return regEx26Mesg;
	}

	/**
	 * Sets the regex26mesg.
	 *
	 * @param regEx26Mesg the new reg ex26 mesg
	 */
	public void setRegEx26Mesg(String regEx26Mesg) {
		this.regEx26Mesg = regEx26Mesg;
	}

	/**
	 * Gets the pattern.
	 * 
	 * @return the pattern
	 */
	public String getPattern() {
		return pattern;
	}

	/**
	 * Gets the pattern2.
	 * 
	 * @return the pattern2
	 */
	public String getPattern2() {
		return pattern2;
	}

	/**
	 * Gets the pattern3.
	 * 
	 * @return the pattern3
	 */
	public String getPattern3() {
		return pattern3;
	}

	public String getPattern4() {
		return pattern4;
	}

	/**
	 * Gets the reg ex1.
	 * 
	 * @return the reg ex1
	 */
	public String getRegEx1() {
		return regEx1;
	}

	/**
	 * Gets the reg ex10.
	 * 
	 * @return the reg ex10
	 */
	public String getRegEx10() {
		return regEx10;
	}

	/**
	 * Gets the reg ex10 mesg.
	 * 
	 * @return the reg ex10 mesg
	 */
	public String getRegEx10Mesg() {
		return regEx10Mesg;
	}

	/**
	 * Gets the reg ex11.
	 * 
	 * @return the reg ex11
	 */
	public String getRegEx11() {
		return regEx11;
	}

	/**
	 * Gets the reg ex11 mesg.
	 * 
	 * @return the reg ex11 mesg
	 */
	public String getRegEx11Mesg() {
		return regEx11Mesg;
	}

	/**
	 * Gets the reg ex12.
	 * 
	 * @return the reg ex12
	 */
	public String getRegEx12() {
		return regEx12;
	}

	/**
	 * Gets the reg ex12 mesg.
	 * 
	 * @return the reg ex12 mesg
	 */
	public String getRegEx12Mesg() {
		return regEx12Mesg;
	}

	/**
	 * Gets the reg ex13.
	 * 
	 * @return the reg ex13
	 */
	public String getRegEx13() {
		return regEx13;
	}

	/**
	 * Gets the reg ex13 mesg.
	 * 
	 * @return the reg ex13 mesg
	 */
	public String getRegEx13Mesg() {
		return regEx13Mesg;
	}

	/**
	 * Gets the reg ex14.
	 * 
	 * @return the reg ex14
	 */
	public String getRegEx14() {
		return regEx14;
	}

	/**
	 * Gets the reg ex14 mesg.
	 * 
	 * @return the reg ex14 mesg
	 */
	public String getRegEx14Mesg() {
		return regEx14Mesg;
	}

	/**
	 * Gets the reg ex15.
	 * 
	 * @return the reg ex15
	 */
	public String getRegEx15() {
		return regEx15;
	}

	/**
	 * Gets the reg ex15 mesg.
	 * 
	 * @return the reg ex15 mesg
	 */
	public String getRegEx15Mesg() {
		return regEx15Mesg;
	}

	/**
	 * Gets the reg ex16.
	 * 
	 * @return the reg ex16
	 */
	public String getRegEx16() {
		return regEx16;
	}

	/**
	 * Gets the reg ex16 mesg.
	 * 
	 * @return the reg ex16 mesg
	 */
	public String getRegEx16Mesg() {
		return regEx16Mesg;
	}

	/**
	 * Gets the reg ex17.
	 * 
	 * @return the reg ex17
	 */
	public String getRegEx17() {
		return regEx17;
	}

	/**
	 * Gets the reg ex17 mesg.
	 * 
	 * @return the reg ex17 mesg
	 */
	public String getRegEx17Mesg() {
		return regEx17Mesg;
	}

	/**
	 * Gets the reg ex18.
	 * 
	 * @return the reg ex18
	 */
	public String getRegEx18() {
		return regEx18;
	}

	/**
	 * Gets the reg ex18 mesg.
	 * 
	 * @return the reg ex18 mesg
	 */
	public String getRegEx18Mesg() {
		return regEx18Mesg;
	}

	/**
	 * Gets the reg ex19.
	 * 
	 * @return the reg ex19
	 */
	public String getRegEx19() {
		return regEx19;
	}

	/**
	 * Gets the reg ex19 mesg.
	 * 
	 * @return the reg ex19 mesg
	 */
	public String getRegEx19Mesg() {
		return regEx19Mesg;
	}

	/**
	 * Gets the reg ex1 mesg.
	 * 
	 * @return the regEx1Mesg
	 */
	public String getRegEx1Mesg() {
		return regEx1Mesg;
	}

	/**
	 * Gets the reg ex2.
	 * 
	 * @return the reg ex2
	 */
	public String getRegEx2() {
		return regEx2;
	}

	/**
	 * Gets the reg ex20.
	 * 
	 * @return the reg ex20
	 */
	public String getRegEx20() {
		return regEx20;
	}

	/**
	 * Gets the reg ex20 mesg.
	 * 
	 * @return the reg ex20 mesg
	 */
	public String getRegEx20Mesg() {
		return regEx20Mesg;
	}

	/**
	 * @return the regEx21
	 */
	public String getRegEx21() {
		return regEx21;
	}

	/**
	 * @return the regEx21Mesg
	 */
	public String getRegEx21Mesg() {
		return regEx21Mesg;
	}

	public String getRegEx22() {
		return regEx22;
	}

	public String getRegEx22Mesg() {
		return regEx22Mesg;
	}

	/**
	 * Gets the reg ex2 mesg.
	 * 
	 * @return the reg ex2 mesg
	 */
	public String getRegEx2Mesg() {
		return regEx2Mesg;
	}

	/**
	 * Gets the reg ex3.
	 * 
	 * @return the reg ex3
	 */
	public String getRegEx3() {
		return regEx3;
	}

	/**
	 * Gets the reg ex3 mesg.
	 * 
	 * @return the reg ex3 mesg
	 */
	public String getRegEx3Mesg() {
		return regEx3Mesg;
	}

	/**
	 * Gets the reg ex4.
	 * 
	 * @return the reg ex4
	 */
	public String getRegEx4() {
		return regEx4;
	}

	/**
	 * Gets the reg ex4 mesg.
	 * 
	 * @return the reg ex4 mesg
	 */
	public String getRegEx4Mesg() {
		return regEx4Mesg;
	}

	/**
	 * Gets the reg ex5.
	 * 
	 * @return the reg ex5
	 */
	public String getRegEx5() {
		return regEx5;
	}

	/**
	 * Gets the reg ex5 mesg.
	 * 
	 * @return the reg ex5 mesg
	 */
	public String getRegEx5Mesg() {
		return regEx5Mesg;
	}

	/**
	 * Gets the reg ex6.
	 * 
	 * @return the reg ex6
	 */
	public String getRegEx6() {
		return regEx6;
	}

	/**
	 * Gets the reg ex6 mesg.
	 * 
	 * @return the reg ex6 mesg
	 */
	public String getRegEx6Mesg() {
		return regEx6Mesg;
	}

	/**
	 * Gets the reg ex7.
	 * 
	 * @return the reg ex7
	 */
	public String getRegEx7() {
		return regEx7;
	}

	/**
	 * Gets the reg ex7 mesg.
	 * 
	 * @return the reg ex7 mesg
	 */
	public String getRegEx7Mesg() {
		return regEx7Mesg;
	}

	/**
	 * Gets the reg ex8.
	 * 
	 * @return the reg ex8
	 */
	public String getRegEx8() {
		return regEx8;
	}

	/**
	 * Gets the reg ex8 mesg.
	 * 
	 * @return the reg ex8 mesg
	 */
	public String getRegEx8Mesg() {
		return regEx8Mesg;
	}

	/**
	 * Gets the reg ex9.
	 * 
	 * @return the reg ex9
	 */
	public String getRegEx9() {
		return regEx9;
	}

	/**
	 * Gets the reg ex9 mesg.
	 * 
	 * @return the reg ex9 mesg
	 */
	public String getRegEx9Mesg() {
		return regEx9Mesg;
	}

	/**
	 * Gets the reg ex messages.
	 * 
	 * @return the reg ex messages
	 */
	public Map <String, String> getRegExMessages() {
		return regExMessages;
	}

	/**
	 * Gets the reg ex name.
	 * 
	 * @param regexValue the regex value
	 * 
	 * @return the reg ex name
	 */
	public void getRegExName(String regexValue) {
	}

	/**
	 * Gets the scenario id.
	 * 
	 * @return the scenario id
	 */
	public String getScenarioId() {
		return scenarioId;
	}

	/**
	 * Gets the scenarios.
	 * 
	 * @return the scenarios
	 */
	@SuppressWarnings("unchecked")
	public Map getScenarios() {
		return scenarios;
	}

	/**
	 * Gets the time zone.
	 * 
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * Sets the pattern.
	 * 
	 * @param pattern the new pattern
	 */
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	/**
	 * Sets the pattern2.
	 * 
	 * @param pattern2 the new pattern2
	 */
	public void setPattern2(String pattern2) {
		this.pattern2 = pattern2;
	}

	/**
	 * Sets the pattern3.
	 * 
	 * @param pattern3 the pattern3 to set
	 */
	public void setPattern3(String pattern3) {
		this.pattern3 = pattern3;
	}

	public void setPattern4(String pattern4) {
		this.pattern4 = pattern4;
	}

	/**
	 * Sets the reg ex1.
	 * 
	 * @param regEx1 the new reg ex1
	 */
	public void setRegEx1(String regEx1) {
		this.regEx1 = regEx1;
	}

	/**
	 * Sets the reg ex10.
	 * 
	 * @param regEx10 the new reg ex10
	 */
	public void setRegEx10(String regEx10) {
		this.regEx10 = regEx10;
	}

	/**
	 * Sets the reg ex10 mesg.
	 * 
	 * @param regEx10Mesg the new reg ex10 mesg
	 */
	public void setRegEx10Mesg(String regEx10Mesg) {
		this.regEx10Mesg = regEx10Mesg;
	}

	/**
	 * Sets the reg ex11.
	 * 
	 * @param regEx11 the new reg ex11
	 */
	public void setRegEx11(String regEx11) {
		this.regEx11 = regEx11;
	}

	/**
	 * Sets the reg ex11 mesg.
	 * 
	 * @param regEx11Mesg the new reg ex11 mesg
	 */
	public void setRegEx11Mesg(String regEx11Mesg) {
		this.regEx11Mesg = regEx11Mesg;
	}

	/**
	 * Sets the reg ex12.
	 * 
	 * @param regEx12 the new reg ex12
	 */
	public void setRegEx12(String regEx12) {
		this.regEx12 = regEx12;
	}

	/**
	 * Sets the reg ex12 mesg.
	 * 
	 * @param regEx12Mesg the new reg ex12 mesg
	 */
	public void setRegEx12Mesg(String regEx12Mesg) {
		this.regEx12Mesg = regEx12Mesg;
	}

	/**
	 * Sets the reg ex13.
	 * 
	 * @param regEx13 the new reg ex13
	 */
	public void setRegEx13(String regEx13) {
		this.regEx13 = regEx13;
	}

	/**
	 * Sets the reg ex13 mesg.
	 * 
	 * @param regEx13Mesg the new reg ex13 mesg
	 */
	public void setRegEx13Mesg(String regEx13Mesg) {
		this.regEx13Mesg = regEx13Mesg;
	}

	/**
	 * Sets the reg ex14.
	 * 
	 * @param regEx14 the new reg ex14
	 */
	public void setRegEx14(String regEx14) {
		this.regEx14 = regEx14;
	}

	/**
	 * Sets the reg ex14 mesg.
	 * 
	 * @param regEx14Mesg the new reg ex14 mesg
	 */
	public void setRegEx14Mesg(String regEx14Mesg) {
		this.regEx14Mesg = regEx14Mesg;
	}

	/**
	 * Sets the reg ex15.
	 * 
	 * @param regEx15 the new reg ex15
	 */
	public void setRegEx15(String regEx15) {
		this.regEx15 = regEx15;
	}

	/**
	 * Sets the reg ex15 mesg.
	 * 
	 * @param regEx15Mesg the new reg ex15 mesg
	 */
	public void setRegEx15Mesg(String regEx15Mesg) {
		this.regEx15Mesg = regEx15Mesg;
	}

	/**
	 * Sets the reg ex16.
	 * 
	 * @param regEx16 the new reg ex16
	 */
	public void setRegEx16(String regEx16) {
		this.regEx16 = regEx16;
	}

	/**
	 * Sets the reg ex16 mesg.
	 * 
	 * @param regEx16Mesg the new reg ex16 mesg
	 */
	public void setRegEx16Mesg(String regEx16Mesg) {
		this.regEx16Mesg = regEx16Mesg;
	}

	/**
	 * Sets the reg ex17.
	 * 
	 * @param regEx17 the new reg ex17
	 */
	public void setRegEx17(String regEx17) {
		this.regEx17 = regEx17;
	}

	/**
	 * Sets the reg ex17 mesg.
	 * 
	 * @param regEx17Mesg the new reg ex17 mesg
	 */
	public void setRegEx17Mesg(String regEx17Mesg) {
		this.regEx17Mesg = regEx17Mesg;
	}

	/**
	 * Sets the reg ex18.
	 * 
	 * @param regEx18 the new reg ex18
	 */
	public void setRegEx18(String regEx18) {
		this.regEx18 = regEx18;
	}

	/**
	 * Sets the reg ex18 mesg.
	 * 
	 * @param regEx18Mesg the new reg ex18 mesg
	 */
	public void setRegEx18Mesg(String regEx18Mesg) {
		this.regEx18Mesg = regEx18Mesg;
	}

	/**
	 * Sets the reg ex19.
	 * 
	 * @param regEx19 the new reg ex19
	 */
	public void setRegEx19(String regEx19) {
		this.regEx19 = regEx19;
	}

	/**
	 * Sets the reg ex19 mesg.
	 * 
	 * @param regEx19Mesg the new reg ex19 mesg
	 */
	public void setRegEx19Mesg(String regEx19Mesg) {
		this.regEx19Mesg = regEx19Mesg;
	}

	/**
	 * Sets the reg ex1 mesg.
	 * 
	 * @param regEx1Mesg the regEx1Mesg to set
	 */
	public void setRegEx1Mesg(String regEx1Mesg) {
		this.regEx1Mesg = regEx1Mesg;
	}

	/**
	 * Sets the reg ex2.
	 * 
	 * @param regEx2 the new reg ex2
	 */
	public void setRegEx2(String regEx2) {
		this.regEx2 = regEx2;
	}

	/**
	 * Sets the reg ex20.
	 * 
	 * @param regEx20 the new reg ex20
	 */
	public void setRegEx20(String regEx20) {
		this.regEx20 = regEx20;
	}

	/**
	 * Sets the reg ex20 mesg.
	 * 
	 * @param regEx20Mesg the new reg ex20 mesg
	 */
	public void setRegEx20Mesg(String regEx20Mesg) {
		this.regEx20Mesg = regEx20Mesg;
	}

	/**
	 * @param regEx21 the regEx21 to set
	 */
	public void setRegEx21(String regEx21) {
		this.regEx21 = regEx21;
	}

	/**
	 * @param regEx21Mesg the regEx21Mesg to set
	 */
	public void setRegEx21Mesg(String regEx21Mesg) {
		this.regEx21Mesg = regEx21Mesg;
	}

	public void setRegEx22(String regEx22) {
		this.regEx22 = regEx22;
	}

	public void setRegEx22Mesg(String regEx22Mesg) {
		this.regEx22Mesg = regEx22Mesg;
	}

	/**
	 * Sets the reg ex2 mesg.
	 * 
	 * @param regEx2Mesg the new reg ex2 mesg
	 */
	public void setRegEx2Mesg(String regEx2Mesg) {
		this.regEx2Mesg = regEx2Mesg;
	}

	/**
	 * Sets the reg ex3.
	 * 
	 * @param regEx3 the new reg ex3
	 */
	public void setRegEx3(String regEx3) {
		this.regEx3 = regEx3;
	}

	/**
	 * Sets the reg ex3 mesg.
	 * 
	 * @param regEx3Mesg the new reg ex3 mesg
	 */
	public void setRegEx3Mesg(String regEx3Mesg) {
		this.regEx3Mesg = regEx3Mesg;
	}

	/**
	 * Sets the reg ex4.
	 * 
	 * @param regEx4 the new reg ex4
	 */
	public void setRegEx4(String regEx4) {
		this.regEx4 = regEx4;
	}

	/**
	 * Sets the reg ex4 mesg.
	 * 
	 * @param regEx4Mesg the new reg ex4 mesg
	 */
	public void setRegEx4Mesg(String regEx4Mesg) {
		this.regEx4Mesg = regEx4Mesg;
	}

	/**
	 * Sets the reg ex5.
	 * 
	 * @param regEx5 the new reg ex5
	 */
	public void setRegEx5(String regEx5) {
		this.regEx5 = regEx5;
	}

	/**
	 * Sets the reg ex5 mesg.
	 * 
	 * @param regEx5Mesg the new reg ex5 mesg
	 */
	public void setRegEx5Mesg(String regEx5Mesg) {
		this.regEx5Mesg = regEx5Mesg;
	}

	/**
	 * Sets the reg ex6.
	 * 
	 * @param regEx6 the new reg ex6
	 */
	public void setRegEx6(String regEx6) {
		this.regEx6 = regEx6;
	}

	/**
	 * Sets the reg ex6 mesg.
	 * 
	 * @param regEx6Mesg the new reg ex6 mesg
	 */
	public void setRegEx6Mesg(String regEx6Mesg) {
		this.regEx6Mesg = regEx6Mesg;
	}

	/**
	 * Sets the reg ex7.
	 * 
	 * @param regEx7 the new reg ex7
	 */
	public void setRegEx7(String regEx7) {
		this.regEx7 = regEx7;
	}

	/**
	 * Sets the reg ex7 mesg.
	 * 
	 * @param regEx7Mesg the new reg ex7 mesg
	 */
	public void setRegEx7Mesg(String regEx7Mesg) {
		this.regEx7Mesg = regEx7Mesg;
	}

	/**
	 * Sets the reg ex8.
	 * 
	 * @param regEx8 the new reg ex8
	 */
	public void setRegEx8(String regEx8) {
		this.regEx8 = regEx8;
	}

	/**
	 * Sets the reg ex8 mesg.
	 * 
	 * @param regEx8Mesg the new reg ex8 mesg
	 */
	public void setRegEx8Mesg(String regEx8Mesg) {
		this.regEx8Mesg = regEx8Mesg;
	}

	/**
	 * Sets the reg ex9.
	 * 
	 * @param regEx9 the new reg ex9
	 */
	public void setRegEx9(String regEx9) {
		this.regEx9 = regEx9;
	}

	/**
	 * Sets the reg ex9 mesg.
	 * 
	 * @param regEx9Mesg the new reg ex9 mesg
	 */
	public void setRegEx9Mesg(String regEx9Mesg) {
		this.regEx9Mesg = regEx9Mesg;
	}

	/**
	 * Sets the reg ex messages.
	 * 
	 * @param regExMessages the reg ex messages
	 */
	public void setRegExMessages(Map <String, String> regExMessages) {
		this.regExMessages = regExMessages;
	}

	/**
	 * Sets the scenario id.
	 * 
	 * @param scenarioId the new scenario id
	 */
	public void setScenarioId(String scenarioId) {
		this.scenarioId = scenarioId;
	}

	/**
	 * Sets the scenarios.
	 * 
	 * @param scenarios the new scenarios
	 */
	@SuppressWarnings("unchecked")
	public void setScenarios(Map scenarios) {
		this.scenarios = scenarios;
	}

	/**
	 * Sets the time zone.
	 * 
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * Start scenario.
	 * 
	 * @return the object
	 */
	@SuppressWarnings("unused")
	private Object startScenario() {
		if (!this.getScenarios().containsKey(this.getScenarioId())) {
			FacesMessage facesMessage = new FacesMessage(
					FacesMessage.SEVERITY_ERROR, "INVALID SCENARIO ID", null);
			FacesContext.getCurrentInstance().addMessage(scenarioId,
					facesMessage);
			return null;
		}
		return this.getScenarios().get(this.getScenarioId());
	}

	/**
	 * @param regEx23 the regEx23 to set
	 */
	public void setRegEx23(String regEx23) {
		this.regEx23 = regEx23;
	}

	/**
	 * @return the regEx23
	 */
	public String getRegEx23() {
		return regEx23;
	}

	/**
	 * @param regEx23Mesg the regEx23Mesg to set
	 */
	public void setRegEx23Mesg(String regEx23Mesg) {
		this.regEx23Mesg = regEx23Mesg;
	}

	/**
	 * @return the regEx23Mesg
	 */
	public String getRegEx23Mesg() {
		return regEx23Mesg;
	}

	/**
	 * @param regEx24 the regEx24 to set
	 */
	public void setRegEx24(String regEx24) {
		this.regEx24 = regEx24;
	}

	/**
	 * @return the regEx24
	 */
	public String getRegEx24() {
		return regEx24;
	}

	/**
	 * @param regEx24Mesg the regEx24Mesg to set
	 */
	public void setRegEx24Mesg(String regEx24Mesg) {
		this.regEx24Mesg = regEx24Mesg;
	}

	/**
	 * @return the regEx24Mesg
	 */
	public String getRegEx24Mesg() {
		return regEx24Mesg;
	}

	/**
	 * @param regEx25 the regEx25 to set
	 */
	public void setRegEx25(String regEx25) {
		this.regEx25 = regEx25;
	}

	/**
	 * @return the regEx25
	 */
	public String getRegEx25() {
		return regEx25;
	}

	/**
	 * @param regEx25Mesg the regEx25Mesg to set
	 */
	public void setRegEx25Mesg(String regEx25Mesg) {
		this.regEx25Mesg = regEx25Mesg;
	}

	/**
	 * @return the regEx25Mesg
	 */
	public String getRegEx25Mesg() {
		return regEx25Mesg;
	}

	/**
	 * @param regEx27Mesg the regEx27Mesg to set
	 */
	public void setRegEx27Mesg(String regEx27Mesg) {
		this.regEx27Mesg = regEx27Mesg;
	}

	/**
	 * @return the regEx27Mesg
	 */
	public String getRegEx27Mesg() {
		return regEx27Mesg;
	}

	/**
	 * @param regEx27 the regEx27 to set
	 */
	public void setRegEx27(String regEx27) {
		this.regEx27 = regEx27;
	}

	/**
	 * @return the regEx27
	 */
	public String getRegEx27() {
		return regEx27;
	}

	/**
	 * @param nameRegEx the nameRegEx to set
	 */
	public void setNameRegEx(String nameRegEx) {
		this.nameRegEx = nameRegEx;
	}

	/**
	 * @return the nameRegEx
	 */
	public String getNameRegEx() {
		return nameRegEx;
	}

	/**
	 * @return the nameRegExMesg
	 */
	public String getNameRegExMesg() {
		return nameRegExMesg;
	}

	/**
	 * @param nameRegExMesg the nameRegExMesg to set
	 */
	public void setNameRegExMesg(String nameRegExMesg) {
		this.nameRegExMesg = nameRegExMesg;
	}

	/**
	 * Get the invalidDlNo.
	 *
	 * @return the invalidDlNo
	 */
	public String getInvalidDlNo() {
		return invalidDlNo;
	}

	/**
	 * Set invalidDlNo.
	 *
	 * @param invalidDlNo the invalidDlNo to set
	 */
	public void setInvalidDlNo(String invalidDlNo) {
		this.invalidDlNo = invalidDlNo;
	}

	/**
	 * @return the noSpaceNameRegEx
	 */
	public String getNoSpaceNameRegEx() {
		return noSpaceNameRegEx;
	}

	/**
	 * @param noSpaceNameRegEx the noSpaceNameRegEx to set
	 */
	public void setNoSpaceNameRegEx(String noSpaceNameRegEx) {
		this.noSpaceNameRegEx = noSpaceNameRegEx;
	}

	/**
	 * @return the noSpaceNameRegExMesg
	 */
	public String getNoSpaceNameRegExMesg() {
		return noSpaceNameRegExMesg;
	}

	/**
	 * @param noSpaceNameRegExMesg the noSpaceNameRegExMesg to set
	 */
	public void setNoSpaceNameRegExMesg(String noSpaceNameRegExMesg) {
		this.noSpaceNameRegExMesg = noSpaceNameRegExMesg;
	}

	public String getPhoneNumberRegEx() {
		return phoneNumberRegEx;
	}

	public void setPhoneNumberRegEx(String phoneNumberRegEx) {
		this.phoneNumberRegEx = phoneNumberRegEx;
	}

	public String getNoSpaceNameWithDashRegEx() {
		return noSpaceNameWithDashRegEx;
	}

	public void setNoSpaceNameWithDashRegEx(String noSpaceNameWithDashRegEx) {
		this.noSpaceNameWithDashRegEx = noSpaceNameWithDashRegEx;
	}

	public String getNoSpaceNameWithDashRegExMesg() {
		return noSpaceNameWithDashRegExMesg;
	}

	public void setNoSpaceNameWithDashRegExMesg(String noSpaceNameWithDashRegExMesg) {
		this.noSpaceNameWithDashRegExMesg = noSpaceNameWithDashRegExMesg;
	}
	
}
/**
 *  Modification History:
 *
 *  $Log: SystemPreferences.java,v $
 *  Revision 1.3  2014/04/25 20:02:23  mwjmf6
 *  Fix CDLIS defect 81: RegEx validation - [A-Z], "-" only. Added noSpaceNameWithDashRegEx and noSpaceNameWithDashRegExMesg
 *
 *  Revision 1.2  2013/04/06 00:16:31  mwjmf6
 *  Added phone number validation reg ex, phoneNumberRegEx to validate XXX-XXX-XXXX format.
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.15  2011/02/15 22:00:28  mwrrv3
 *  variable comments corrected -- Amar Bade
 *
 *  Revision 1.14  2011/02/14 17:29:49  mwrrv3
 *  Serialization implemented for the class -- Amar Bade
 *
 *  Revision 1.13  2011/02/10 22:27:02  mwrrv3
 *  Last Name Spaces functionality implemented -- Amar Bade
 *
 *  Revision 1.12  2011/01/07 18:13:15  mwhxb3
 *  Added invalidDlNo.
 *
 *  Revision 1.11  2011/01/06 18:39:16  mwrrv3
 *  Added new regular expression for name and setter and getter methods.
 *
 *  Revision 1.10  2010/12/15 22:17:05  mwgxk2
 *  Defect ID : 2862 for DATA NOT WITHIN REQUIRED FORMAT.
 *
 *  Revision 1.9  2010/12/14 19:46:57  mwnrk
 *  Fix for 1591 defect.
 *
 *  Revision 1.8  2010/10/08 20:51:37  mwrrv3
 *  Added new req expression for last 3 position name.
 *
 *  Revision 1.7  2010/08/26 22:33:46  mwrrv3
 *  Added new regular expression to support A-Z 0-9 space and slash in the street name field.
 *
 *  Revision 1.6  2010/08/03 17:54:39  mwrrv3
 *  Fixed defect# 2008. Added new regular expression for name.
 *
 *  Revision 1.5  2010/04/22 19:29:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/04/13 18:37:10  mwskd2
 *  RegEx22 message added as per new dl seq number pattern
 *
 *  Revision 1.3  2010/04/09 02:12:51  mwrrv3
 *  Updated the mapping and aligned the controls properly.
 *
 *  Revision 1.2  2010/03/23 00:02:52  mwpxp2
 *  Fixed file footer
 *
 */
