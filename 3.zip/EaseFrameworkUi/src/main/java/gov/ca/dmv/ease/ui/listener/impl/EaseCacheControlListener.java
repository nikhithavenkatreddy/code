/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.ui.component.impl.UiPageHeading;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.Iterator;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlForm;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Description: Intercept JSF lifecycle event to update page cache to prevent browser from
 * acting upon the back button.
 * File: EaseCacheControlListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: Nov 23, 2009
 * @author mwrsk  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseCacheControlListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1477357655689558514L;
	private static final String SELECT_DL_TRANSACTION = "selectDlTransaction";
	private static final String SELECT_VR_TRANSACTION = "selectVrTransaction";
	private static final String JSF_FILE_EXTENSION = ".jsf";
	private static final String JSPX_FILE_EXTENSION = ".jspx";
	
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(EaseCacheControlListener.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 * Handle a notification that the processing for a 
	 * particular phase has just been completed
	 */
	public void afterPhase(PhaseEvent event) {

		FacesContext facesContext = event.getFacesContext();
		UIComponent uiFormComponent = null;
		
		for (Object aComponentObject : facesContext.getViewRoot().getChildren()) {
			if (aComponentObject instanceof UiPageHeading) {
				uiFormComponent = (UIComponent) aComponentObject;
				uiFormComponent = null;
			}
			if (aComponentObject instanceof HtmlForm) {
				uiFormComponent = (UIComponent) aComponentObject;
				uiFormComponent = null;
			}
			else {
				UIComponent uiComponent = (UIComponent) aComponentObject;
				Iterator <?> childComponents = uiComponent.getChildren()
						.iterator();
				while (childComponents.hasNext()) {
					Object childComponent = childComponents.next();
					if (childComponent instanceof HtmlForm) {
						uiFormComponent = (UIComponent) childComponent;
						List <UIComponent> formChildComponents = uiFormComponent.getChildren();
						for(UIComponent formChildComponent: formChildComponents){
							
							formChildComponent = null;
						}
					}
					else if (childComponent instanceof UiPageHeading) {
						uiFormComponent = (UIComponent) childComponent;
						List <UIComponent> formChildComponents = uiFormComponent.getChildren();
						for(UIComponent formChildComponent: formChildComponents){
							
							formChildComponent = null;
						}
					}
				}
			}
		}
		// }
	
	}

	/*
	 * Update HTTP header to disallow caching of page by browser
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent event) {
		FacesContext facesContext = event.getFacesContext();
		HttpServletResponse response = (HttpServletResponse) facesContext
				.getExternalContext().getResponse();
		response.addHeader("Pragma", "no-cache");
		response.addHeader("Cache-Control", "no-cache");
		response.addHeader("Cache-Control", "must-revalidate");
		response.addHeader("Expires", "Mon, 8 Aug 2006 10:00:00 GMT");
		//If the screen name is selectDlTransaction then set the current time 
		//to the user context.
		String currentScreenId = getCurrentScreenName();
		//If the current screen name is selectDlTransaction then override the  
		//current time to system time and set it to the user context.
		if (SELECT_DL_TRANSACTION.equalsIgnoreCase(currentScreenId)
				|| SELECT_VR_TRANSACTION.equalsIgnoreCase(currentScreenId)) {
			ApplicationContext applicationContext = getApplicationContext(facesContext);
			UserContext userContextBean = getUserContext(applicationContext);
			userContextBean.setSystemStartDateForTtc(CurrentDateProvider
					.getInstance().getCurrentDate());
		}
	}

	/**
	 * @param facesContext
	 * @return
	 */
	private ApplicationContext getApplicationContext(FacesContext facesContext) {
		ServletContext servletContext = (ServletContext) facesContext
				.getExternalContext().getContext();
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(servletContext);
		return applicationContext;
	}

	/**
	 * @param applicationContext
	 * @return
	 */
	private UserContext getUserContext(ApplicationContext applicationContext) {
		UserContext userContextBean = (UserContext) EaseProxyUtils
				.getProxyObject(applicationContext.getBean("userContext"));
		return userContextBean;
	}

	/**
	 * Get the current screen id/name.
	 * @return
	 */
	private String getCurrentScreenName() {
		String viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		String currentScreenId = "";
		if (!EaseUtil.isNullOrBlank(viewId)) {
			if (viewId.indexOf(JSF_FILE_EXTENSION) >= 0) {
				currentScreenId = viewId.substring(viewId.lastIndexOf("/") + 1,
						viewId.indexOf(JSF_FILE_EXTENSION));
			}
			else if (viewId.indexOf(JSPX_FILE_EXTENSION) >= 0) {
				currentScreenId = viewId.substring(viewId.lastIndexOf("/") + 1,
						viewId.indexOf(JSPX_FILE_EXTENSION));
			}
		}
		return currentScreenId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 * Return the identifier of the request processing phase during 
	 * which this listener is interested in processing PhaseEvent events.
	 */
	public PhaseId getPhaseId() {
		return PhaseId.RENDER_RESPONSE;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseCacheControlListener.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.12  2011/08/18 21:50:22  mwnrk
 *  Removed debug statements.
 *
 *  Revision 1.11  2011/08/15 22:36:31  mwark
 *  Added the UIComponentBase object reset code to remove the unused objects.
 *
 *  Revision 1.10  2011/06/22 21:16:25  mwrrv3
 *  Break the code into getApplicationContext() and getUserContext() methods and replace with constants.
 *
 *  Revision 1.9  2011/06/15 20:53:18  mwrrv3
 *  Added code to reset the system start date for every TTC.
 *
 *  Revision 1.8  2011/03/25 20:16:26  mwrrv3
 *  Rolled back to previous version 1.6, uncommented the code.
 *
 *  Revision 1.7  2011/01/23 18:28:40  mwrrv3
 *  Updated the beforePhase to comment cache.
 *
 *  Revision 1.6  2010/04/22 19:30:33  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/04/22 19:29:38  mwpxp2
 *  Fixed class comment and footer
 *
 */
