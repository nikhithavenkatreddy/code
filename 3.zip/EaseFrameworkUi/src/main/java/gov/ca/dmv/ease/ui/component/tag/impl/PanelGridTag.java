/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.PanelGrid;

import javax.faces.component.UIComponent;

/**
 * Description: //TODO - provide description!
 * File: PanelGridTag.java
 * Module:  gov.ca.dmv.ease.ui.component.tag.impl
 * Created: Sep 17, 2009
 * @author MWBVC  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PanelGridTag extends AbstractPanelGridTag {
	/**
	 * Gets the PanelGrid component type
	 * @return Component Type
	 */
	@Override
	public String getComponentType() {
		return PanelGrid.COMPONENT_TYPE;
	}

	/**
	 * Gets the PanelGrid renderer type
	 * @return Renderer Type
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.PanelGridRenderer";
	}

	/**
	 * Sets null to all attributes and releases from the state.
	 */
	@Override
	public void release() {
		super.release();
	}

	/**
	 * Sets the PanelGrid component properties
	 * @param uiComponent
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGridTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:54:17  mwpxp2
 *  Fixed class footer, javadoc
 *
 */
