/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

import static gov.ca.dmv.ease.ui.constants.PageConstants.ACTIONS_HANDLER;
import static gov.ca.dmv.ease.ui.constants.PageConstants.PAGE_TOKEN;
import gov.ca.dmv.ease.ui.handler.impl.ActionsHandler;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Description: This class is a Servlet filter to synchronize forms, work
 * hand-in-hand with the Faces synchronized form component
 *   
 * File: SynchronizationFilter.java
 * Module:  gov.ca.dmv.ease.ui.util.impl
 * Created: Sep 15, 2009
 * @author mwpxm2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SynchronizationFilter implements Filter {
	/** The filter configuration. */
	protected FilterConfig config;
	
	/** The Constant FORM_GET_METHOD. */
	private static final String FORM_GET_METHOD = "GET";
	
	/** The Constant FORM_POST_METHOD. */
	private static final String FORM_POST_METHOD = "POST";
	

	/**
	 * This method converts the given viewId to its corresponding path.
	 * 
	 * @param viewId
	 *            the view id
	 * 
	 * @return the string
	 */
	private String convertToPath(String viewId) {
		// Could be better? e.g. using View Handler.
		return viewId.replaceAll(".jspx", ".jsf");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		//destroy() method called when the filter is taken out of service.
		this.config = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		ActionsHandler handler = getActionsHandler(httpRequest);
		if (handler != null) {
			synchronized (handler) {
				//TODO - obtain token and view id in a single call to simplify ActionsHandler 
				String currentPath = convertToPath(handler.getViewId());
				String token = handler.getToken();
				if (httpRequest.getMethod().equals(FORM_GET_METHOD)) {
					String requestPath = httpRequest.getServletPath();
					if (!requestPath.equals(currentPath)) {
						redirectToCurrent(httpRequest, httpResponse,
								currentPath);
						return;
					}
				}
				else if (httpRequest.getMethod().equals(FORM_POST_METHOD)) {
					String clientToken = httpRequest.getParameter(PAGE_TOKEN);
					if (clientToken == null || !clientToken.equals(token)) {
						redirectToCurrent(httpRequest, httpResponse,
								currentPath);
						return;
					}
				}
			}
		}
		chain.doFilter(request, response);
	}

	/**
	 * This method gets the actions handler from the given request.
	 * 
	 * @param request
	 *            the request
	 * 
	 * @return the actions handler
	 */
	private ActionsHandler getActionsHandler(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			return (ActionsHandler) session.getAttribute(ACTIONS_HANDLER);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.config = filterConfig;
	}

	/**
	 * This method redirect to current URL.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @param currentPath
	 *            the current path
	 * 
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void redirectToCurrent(HttpServletRequest request,
			HttpServletResponse response, String currentPath)
			throws IOException {
		String toPath = request.getContextPath() + currentPath;
		toPath = response.encodeRedirectURL(toPath);
		response.sendRedirect(toPath);
	}
}
/**
 * Modification History:
 * 
 * $Log: SynchronizationFilter.java,v $
 * Revision 1.1  2012/10/01 02:58:07  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.6  2012/08/09 23:51:35  mwrrv3
 * Fixed FIXME code to use the constants.
 *
 * Revision 1.5  2011/08/16 20:00:35  mwpxp2
 * Added fixmes
 *
 * Revision 1.4  2011/06/13 18:23:25  mwyxg1
 * clean up
 *
 * Revision 1.3  2010/03/23 00:06:01  mwpxp2
 * Fixed clas comment
 *
 * Revision 1.2  2010/01/14 02:34:36  mwskd2
 * new files
 * Revision 1.1 2009/11/23 16:22:53 mwrsk
 * Intial commit
 * 
 * Revision 1.3 2009/10/28 00:06:08 mwskd2 Added comments
 * 
 * Revision 1.2 2009/10/22 00:40:47 mwbvc Gopi Changes - for tab support and
 * separating the inquiry to court and dcs
 * 
 * Revision 1.1 2009/10/21 23:52:36 mwbvc changed the package names and
 * refactored the code
 * 
 * Revision 1.1 2009/09/15 23:07:29 mwpxm2 Synchronized form and browser
 * protection
 * 
 */
