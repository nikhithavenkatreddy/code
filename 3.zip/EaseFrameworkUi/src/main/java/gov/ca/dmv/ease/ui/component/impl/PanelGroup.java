/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.html.HtmlPanelGroup;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

/**
 * Description: I am this and that File: PanelGroup.java
 * Module: gov.ca.dmv.ease.ui.component.impl.panelgroup 
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/17 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class PanelGroup extends HtmlPanelGroup {
	/** The Constant COMPONENT_FAMILY. */
	public static final String COMPONENT_FAMILY = "javax.faces.Panel";
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.PanelGroup";
	/** The Constant DEFAULT_COLSPAN. */
	public static final int DEFAULT_COLSPAN = Integer.MIN_VALUE;
	/** The Constant DEFAULT_RENDERER_TYPE. */
	public static final String DEFAULT_RENDERER_TYPE = "gov.ca.dmv.ease.PanelGroupRenderer";
	/** The colspan. */
	private Integer colspan;
	/** The layout. */
	private String layout;
	/** The values. */
	private Object[] values;

	/**
	 * Constructor.
	 */
	public PanelGroup() {
		super();
		setRendererType(DEFAULT_RENDERER_TYPE);
	}

	/**
	 * Gets the colspan attribute value for table column.
	 * 
	 * @return colspan of Table Column <td>
	 */
	public int getColspan() {
		if (colspan != null) {
			return colspan.intValue();
		}
		ValueBinding valueBinding = getValueBinding("colspan");
		Number nColSpan = valueBinding != null ? (Number) valueBinding
				.getValue(getFacesContext()) : null;
		return nColSpan != null ? nColSpan.intValue() : DEFAULT_COLSPAN;
	}

	/**
	 * Gets the layout attribute value for table column.
	 * 
	 * @return layout of Table Column <td>
	 */
	public String getLayout() {
		if (null != this.layout) {
			return this.layout;
		}
		ValueBinding valueBinding = getValueBinding("layout");
		if (valueBinding != null) {
			return (String) valueBinding.getValue(getFacesContext());
		}
		else {
			return null;
		}
	}

	/**
	 * Restores the PanelGroup component State with the attribute values.
	 * 
	 * @param facesContext the faces context
	 * @param state of FieldSet
	 */
	@Override
	public void restoreState(FacesContext facesContext, Object state) {
		values = (Object[]) state;
		super.restoreState(facesContext, values[0]);
		this.layout = (String) values[1];
		this.colspan = (Integer) values[2];
	}

	/**
	 * Saves the PanelGroup component State with the attribute values.
	 * 
	 * @param facesContext the faces context
	 * 
	 * @return Object of type PanelGroup
	 */
	@Override
	public Object saveState(FacesContext facesContext) {
		if (values == null) {
			values = new Object[3];
		}
		values[0] = super.saveState(facesContext);
		values[1] = layout;
		values[2] = colspan;
		return values;
	}

	/**
	 * Sets the colspan attribute value for table column.
	 * 
	 * @param colspan the colspan
	 */
	public void setColspan(int colspan) {
		this.colspan = new Integer(colspan);
	}

	/**
	 * Sets the layout attribute value for table column.
	 * 
	 * @param layout the layout
	 */
	public void setLayout(String layout) {
		this.layout = layout;
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGroup.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
