/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.codeset.impl;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bus.service.ICodeSetService;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.ui.util.impl.ListOrderedMap;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * Description: I am mock implementation of the code service
 * File: MockCodeSetService.java
 * Module:  gov.ca.dmv.ease.ui.codeset.impl
 * Created: 2009
 * @author NN  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:54:53 $
 * Last Changed By: $Author: mwsec2 $
 */
public class MockCodeSetService implements ApplicationContextAware,
		ICodeSetService {
	/** The application context. */
	private ApplicationContext applicationContext;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.service.ICodeSetService#getAllCodeSets(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public List <ICodeSet> getAllCodeSets(IUserContext userContext) {
		// unused when mocking the service
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.service.ICodeSetService#getCodeSetNamed(java.lang.String, gov.ca.dmv.ease.fw.process.IUserContext)
	 * Gets the codes from application-context-codesets.xml
	 */
	public ICodeSet getCodeSetNamed(String name, IUserContext userContext) {
		ICodeSet codeSet = new CodeSet(name);
		ICodeSetElement codeSetElement;
		ListOrderedMap codeSetMap;
		if (applicationContext.containsBean(name)) {
			codeSetMap = (ListOrderedMap) applicationContext.getBean(name);
			for (@SuppressWarnings("rawtypes")
			Iterator iterator = codeSetMap.keySet().iterator(); iterator
					.hasNext();) {
				String key = (String) iterator.next();
				codeSetElement = new CodeSetElement(
						(String) codeSetMap.get(key), key,
						(String) codeSetMap.get(key), codeSet);
				codeSet.add(codeSetElement);
			}
		}
		else {
			codeSet.add(new CodeSetElement("Missing code set definition for "
					+ name, "?", "Missing code set definition for " + name));
		}
		return codeSet;
	}

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Override
	public void reloadCodeSetRegistry() {
		// TODO Auto-generated method stub
		
	}
}
/**
 * Modification History:
 * 
 * $Log: MockCodeSetService.java,v $
 * Revision 1.2  2013/06/26 21:54:53  mwsec2
 * WAS7 upgrade merge
 *
 * Revision 1.1.2.1  2013/01/03 17:19:19  mwsec2
 * Adding support for reloading CodeSet registry via a JMX call
 *
 * Revision 1.1  2012/10/01 02:58:07  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.6  2012/08/25 18:18:31  mwpxp2
 * Fixed suppression of warnings frfom unchecked to rawtypes were applicable
 *
 * Revision 1.5  2010/10/08 20:50:59  mwrrv3
 * Implemented office city codes based on the office id.
 *
 * Revision 1.2  2010/03/22 23:42:06  mwpxp2
 * Added class header, comment
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.2  2009/10/26 23:36:50  mwgxk2
 * Comments Added.
 *
 * Revision 1.1  2009/10/22 00:40:51  mwbvc
 * Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 * Revision 1.1  2009/10/21 23:51:08  mwbvc
 * changed the package names and refactored the code
 *
 * Revision 1.8  2009/10/03 21:43:12  mwpxp2
 * Adjusted imports for fw, apph refactorings; bulk cleanup
 *
 * Revision 1.7  2009/09/16 18:25:46  mwskd2
 * changed Treemap to ListOrderedMap
 * Revision 1.5 2009/09/10 20:36:41 mwpxm2
 * CodeSet design change
 * 
 * Revision 1.4 2009/09/09 03:27:41 mwjjl7 update to support codeset redesign
 * 
 * Revision 1.3 2009/08/03 18:00:33 mwjjl7 update
 * 
 * Revision 1.2 2009/08/03 17:28:38 mwjjl7 refactor
 * 
 * Revision 1.1 2009/08/03 17:19:51 mwjjl7 refactor
 * 
 * Revision 1.2 2009/07/30 22:05:53 mwpxm2 create a code set element with data
 * 
 * Revision 1.1 2009/07/30 02:31:41 mwjjl7 initial load
 * 
 */
