/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.math.BigDecimal;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: MiscFeeAmountValidator.java is a custom validator which validates
 * the Miscellaneous Varied Fee (Fee Amount) value.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: WeightValidator.java 
 * Created: Nov 15, 2010
 * @author MWRRV3
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MiscFeeAmountValidator extends ValidatorBase {
	private static final String CONVERSION_ERROR_MESSAGE = "INVALID CHARACTER IN ALPHA NUMERIC FIELD";
	private static final String ERROR_DATA_RANGE_MESSAGE = "DATA NOT WITHIN SPECIFIED RANGE";
	private static final String ERROR_DATA_REQUIRED_FORMAT = "DATA NOT WITHIN REQUIRED FORMAT";
	private static final String ERROR_MESSAGE = "FIELD MAY ONLY CONTAIN NUMBERS";
	/** The Constant PATTERN. */
	private static final String FIVE_DIGITS_TWO_DECIMALS_PATTERN = "\\d{0,5}\\.{0,1}\\d{0,2}";
	/** Pre-compiled Pattern object. */
	private static final Pattern FIVE_DIGITS_TWO_DECIMALS = Pattern
			.compile(FIVE_DIGITS_TWO_DECIMALS_PATTERN);

	/**
	 * Instantiates a new FeeAmount validator.
	 */
	public MiscFeeAmountValidator() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		String valueString = null;
		if (value == null) {
			return;
		}
		if (value instanceof String) {
			valueString = (String) value;
		}
		//Convert String to BigDecimal and if the value is less than 0.01 or greater than 9999999.99 then throw an error.
		try {
			if (valueString.contains("$")
					|| (new BigDecimal(valueString).compareTo(new BigDecimal(
							0.00)) == -1)) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_MESSAGE));
			}
			if (((new BigDecimal(valueString)).compareTo(new BigDecimal(
					99999.99)) == 1)) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_DATA_RANGE_MESSAGE));
			}
			if (!(FIVE_DIGITS_TWO_DECIMALS.matcher(valueString).matches())) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_DATA_REQUIRED_FORMAT));
			}
		}
		catch (NumberFormatException e) {
			throw new ValidatorException(FacesUtils.createErrorMessage(
					valueString, CONVERSION_ERROR_MESSAGE));
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: MiscFeeAmountValidator.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/03/15 01:48:17  mwrrv3
 *  New validator for FeeAmount in MiscellaneousVariedFeeCollections page. Defect# 5258.
 *
 */
