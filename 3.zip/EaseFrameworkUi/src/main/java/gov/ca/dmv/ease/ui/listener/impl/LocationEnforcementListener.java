/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.tus.auth.factory.impl.AuthAndAuthServiceRequestFactory;
import gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest;
import gov.ca.dmv.ease.tus.auth.response.ILocationEnforcementResponse;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Description: The purpose of this class is to enforce location.
 * File: LocationEnforcementListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: Dec 3, 2010 
 * @author MWXXM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LocationEnforcementListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7114768666166932115L;
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(LocationEnforcementListener.class);

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		FacesContext facesContext = phaseEvent.getFacesContext();
		ServletContext servletContext = (ServletContext) facesContext
				.getExternalContext().getContext();
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(servletContext);
		UserContext userContextBean = (UserContext) EaseProxyUtils
				.getProxyObject(applicationContext.getBean("userContext")); 		
		
		if (userContextBean.isLocationAuthorized()) {
			return;
		}
		
		HttpServletRequest httpRequest = (HttpServletRequest)facesContext.getExternalContext().getRequest();
		httpRequest.getSession().setAttribute("userContext", new UserContext(userContextBean));
		
		// Call location enforcement service
		LocationEnforcementRequest request = AuthAndAuthServiceRequestFactory
	 	    .getInstance().createLocationEnforcementRequest(
				userContextBean,
				userContextBean.getIpAddress(), 
				userContextBean.getOfficeId(), 
				userContextBean.getRemoteOfficeId());
		ILocationEnforcementResponse response = request.execute();
				
		if (!response.isLocationAuthorized()) {
			LOGGER.info("User '" + userContextBean.getUserName()
					+ "' has been redirected to the Location Enforcement page!"); 
			UIViewRoot viewRoot = facesContext.getApplication()
					.getViewHandler().createView(facesContext,
							"/tabs/locationEnforcement.jsf");
			
			HttpServletRequest req = (HttpServletRequest)facesContext.getExternalContext().getRequest();						
			req.setAttribute("AuthOfficeIdList", response.getAuthOfficeIdList());
			
			facesContext.setViewRoot(viewRoot);
			facesContext.renderResponse();
			userContextBean.setLocationAuthorized(false);
		}
		else {
			userContextBean.setLocationAuthorized(true);
			LOGGER.info("User '" + userContextBean.getUserName()
					+ "' pass location enforcement");
		}
		
		LOGGER.info("Location authorized: " + response.isLocationAuthorized() + " #### ");
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 */
	public PhaseId getPhaseId() {
		return PhaseId.RESTORE_VIEW;
	}
}
/**
 *  Modification History:
 *
 *  $Log: LocationEnforcementListener.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/03/23 21:22:12  mwxxw
 *  Add userContextBean to session attribute for BPRS sign off message use.
 *
 *  Revision 1.7  2012/01/10 19:34:57  mwxxw
 *  Display AuthOfficeIdList on location enforcement page.
 *
 *  Revision 1.6  2011/06/09 20:06:44  mwyxg1
 *  clean up
 *
 *  Revision 1.5  2010/12/17 17:29:48  mwrrv3
 *  Changed the logger statement.
 *
 *  Revision 1.4  2010/12/07 23:43:43  mwxxw
 *  Add logic to set isLocationAuthorized flag after it passed location enforcement.
 *
 *  Revision 1.3  2010/12/07 20:20:08  mwxxw
 *  Add authOfficeId to the service response.
 *
 *  Revision 1.2  2010/12/04 01:33:52  mwxxw
 *  Add new phaseListener for location enforcement.
 *
 *  Revision 1.1  2010/12/04 00:46:01  mwxxw
 *  Added for Location Enforcement service.
 *
 *  Revision 1.15  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 */
