/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.validator.impl.ValidatorBase;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.validator.Validator;
import javax.faces.webapp.UIComponentTag;
import javax.faces.webapp.ValidatorTag;
import javax.servlet.jsp.JspException;

/**
 * Description: ValidatorBaseTag provides support for ValidatorBase subclasses.
 * File: ValidatorBaseTag.java
 * Module:  gov.ca.dmv.ease.ui.component.tag.impl
 * Created: Oct 19, 2009
 * @author mwbvc  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ValidatorBaseTag extends ValidatorTag {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4416508071412794682L;
	/** The detail message. */
	private String detailMessage = null;
	/** The summary message. */
	private String summaryMessage = null;

	/* (non-Javadoc)
	 * @see javax.faces.webapp.ValidatorTag#createValidator()
	 */
	@Override
	protected Validator createValidator() throws JspException {
		ValidatorBase validator = (ValidatorBase) super.createValidator();
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if (detailMessage != null) {
			if (UIComponentTag.isValueReference(detailMessage)) {
				ValueBinding vb = facesContext.getApplication()
						.createValueBinding(detailMessage);
				validator.setValueBinding("detailMessage", vb);
			}
			else {
				validator.setDetailMessage(detailMessage);
			}
		}
		if (summaryMessage != null) {
			if (UIComponentTag.isValueReference(summaryMessage)) {
				ValueBinding vb = facesContext.getApplication()
						.createValueBinding(summaryMessage);
				validator.setValueBinding("summaryMessage", vb);
			}
			else {
				validator.setSummaryMessage(summaryMessage);
			}
		}
		return validator;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.ValidatorTag#release()
	 */
	@Override
	public void release() {
		super.release();
		detailMessage = null;
		summaryMessage = null;
	}

	/**
	 * Sets the detail message.
	 * 
	 * @param detailMessage the new detail message
	 */
	public void setDetailMessage(String aString) {
		detailMessage = aString;
	}

	/**
	 * Sets the summary message.
	 * 
	 * @param summaryMessage the new summary message
	 */
	public void setSummaryMessage(String aString) {
		summaryMessage = aString;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValidatorBaseTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:57:18  mwpxp2
 *  Fixed class decorations, javadoc; property-argument aliasing
 *
 */
