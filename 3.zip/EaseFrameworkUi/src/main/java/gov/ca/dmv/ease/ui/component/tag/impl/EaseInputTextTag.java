/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText;

import javax.faces.component.UIComponent;

/**
 * Description: This class is the extension of @see AbstractInputTextTag
 * File: EaseInputTextTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: May 06, 2009
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseInputTextTag extends AbstractInputTextTag {
	/** The code set name. */
	/**
	 * Instantiates a new coded input text tag.
	 */
	public EaseInputTextTag() {
		super();
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return HtmlCodedInputText.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.EaseInputText";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#release()
	 */
	@Override
	public void release() {
		super.release();
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseInputTextTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/07/08 02:04:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/05/07 00:59:46  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *
 *  Revision 1.1  2010/05/07 00:52:18  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *
 */
