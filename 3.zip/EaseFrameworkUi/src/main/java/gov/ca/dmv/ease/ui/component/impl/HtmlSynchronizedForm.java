/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.html.HtmlForm;

/**
 * Description: This class is the extension of @see HtmlForm that protects against the following situations:
 * - Double clicking on a button
 * - Quick clicking on another button while the first button click is being processed
 * - Clicking Back button then re-submit
 * - Multiple browser windows with the same session
 * - Book-marking a page then coming back to the page without proper session startup
 * 
 * Note: Currently this component doesn't have its own attributes. Future enhancement may
 * add new attributes, e.g. pageBean attribute that links to a page bean
 * 
 * File: HtmlSynchronizedForm.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlSynchronizedForm extends HtmlForm {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.SynchronizedForm";

	/**
	 * Instantiates a new html synchronized form.
	 */
	public HtmlSynchronizedForm() {
		setRendererType("gov.ca.dmv.ease.SynchronizedForm");
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlSynchronizedForm.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
