/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.html.HtmlInputText;
import javax.faces.context.FacesContext;

/**
 * Description: This class is the extension of @see HtmlInputText with a capability of handling not only the 
 * alphanumeric characters but also the codesetname
 * File: HtmlCodedInputText.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlCodedInputText extends HtmlInputText {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.CodedInputText";
	/** The code set name. */
	private String codeSetName = null;
	/** The office Id. */
	private String officeId = null;


	/**
	 * Instantiates a new html coded input text.
	 */
	public HtmlCodedInputText() {
		setRendererType("gov.ca.dmv.ease.CodedInputText");
	}

	/**
	 * Gets the code set name.
	 * 
	 * @return the code set name
	 */
	public String getCodeSetName() {
		return codeSetName;
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.html.HtmlInputText#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext _context, Object _state) {
		Object values[] = (Object[]) _state;
		super.restoreState(_context, values[0]);
		codeSetName = (String) values[1];
		officeId = (String) values[2];
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.html.HtmlInputText#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext _context) {
		Object values[] = new Object[3];
		values[0] = super.saveState(_context);
		values[1] = codeSetName;
		values[2] = officeId;
		return values;
	}

	/**
	 * Sets the code set name.
	 * 
	 * @param codeSetName the new code set name
	 */
	public void setCodeSetName(String codeSetName) {
		this.codeSetName = codeSetName;
	}

	/**
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlCodedInputText.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/08 20:50:58  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
