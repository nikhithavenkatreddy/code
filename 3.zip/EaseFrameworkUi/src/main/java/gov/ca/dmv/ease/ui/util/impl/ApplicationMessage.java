/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

/**
 * Description: This class acts as a bean class to get all the setters and getters of Application Messages.
 * File: ApplicationMessage.java
 * Module:  gov.ca.dmv.ease.ui.util.impl
 * Created: Oct 27, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ApplicationMessage {
	/** The code. */
	private String code;
	/** The message. */
	private String message;
	/** The severity. */
	private String severity;

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Gets the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Gets the severity.
	 * 
	 * @return the severity
	 */
	public String getSeverity() {
		return severity;
	}

	/**
	 * Sets the code.
	 * 
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Sets the message.
	 * 
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Sets the severity.
	 * 
	 * @param severity the new severity
	 */
	public void setSeverity(String severity) {
		this.severity = severity;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ApplicationMessage.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 00:06:13  mwpxp2
 *  Fixed file footer
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/28 00:06:08  mwskd2
 *  Added comments
 *
 *  Revision 1.1  2009/10/21 23:52:36  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.1  2009/07/30 18:33:39  mwjjl7
 *  message handling initial work-in-progress
 *
*/
