/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import java.util.Calendar;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: The purpose of this class is to check the session status
 * in RESTORE_VIEW phase and redirect to mode selection page.
 * File: RestoreViewListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: Oct 26, 2011 
 * @author MWRRV3  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2013/09/03 17:52:39 $
 * Last Changed By: $Author: mwsec2 $
 */
public class RestoreViewListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1883007408150123696L;
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(RestoreViewListener.class);

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
		LOGGER.debug("RestoreViewListener After Phase is called.");
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		LOGGER.debug("RestoreViewListener Before Phase is called.");
		FacesContext facesContext = phaseEvent.getFacesContext();
		HttpServletRequest httpServletRequest = (HttpServletRequest) facesContext
				.getExternalContext().getRequest();
		HttpSession session = httpServletRequest.getSession(false);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("HTTP Session: " + session);
		}
		if (session == null) {
			LOGGER.debug("HTTP Session is NULL");
			redirectToModeSelection(facesContext);
		}
		else {
			LOGGER.debug("HTTP Session is NOT NULL");
			//If the web-seal session is out (20 mins) then kill the session 
			//and redirect to mode selection screen.
			long lastAccessTime = session.getLastAccessedTime();
			long currentAccessTime = Calendar.getInstance().getTimeInMillis();
			if (LOGGER.isDebugEnabled()) { 
				LOGGER.debug("Idle Time: "
						+ (((currentAccessTime - lastAccessTime) / 1000) / 60));
			}
			if ((((currentAccessTime - lastAccessTime) / 1000) / 60) > 20) {
				LOGGER.debug("Idle Time is more than 20 mins, invalidated the session");
				//Invalidate the WAS session if web-seal session is expired
				session.invalidate(); 
				redirectToModeSelection(facesContext);
			}
		}
	}

	/**
	 * Redirect the application to the mode selection screen.
	 * @param facesContext
	 */
	private void redirectToModeSelection(FacesContext facesContext) {
		UIViewRoot viewRoot = facesContext.getApplication().getViewHandler()
				.createView(facesContext, "/common/modeSelection.jsf");
		facesContext.setViewRoot(viewRoot);
		facesContext.renderResponse();
	}

	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 */
	public PhaseId getPhaseId() {
		return PhaseId.RESTORE_VIEW;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RestoreViewListener.java,v $
 *  Revision 1.3  2013/09/03 17:52:39  mwsec2
 *  put debug statements inside 'isDebugEnabled' block
 *
 *  Revision 1.2  2013/06/26 21:54:53  mwsec2
 *  WAS7 upgrade merge
 *
 *  Revision 1.1.2.1  2013/04/30 17:11:16  mwsec2
 *  adjusted logging statements
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/11/15 22:35:32  mwkkc
 *  Production Cleanup
 *
 *  Revision 1.1  2011/10/26 18:16:41  mwrrv3
 *  Phase Listener for RESTORE_VIEW phase to check the HTTP Session.
 *
 *  Revision 1.1  2011/10/26 17:53:37  mwrrv3
 *  Phase Listener for RESTORE_VIEW phase to check the HTTP Session.
 *
 */
