/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import javax.faces.component.UIComponent;

/**
 * Description: This class is the extension of @see AbstractBaseTag with all the setter and getter properties 
 * of a basic Input HTML component tag
 * File: AbstractInputTextTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractInputTextTag extends AbstractBaseTag {
	/** The converter. */
	private String converter;
	/** The immediate. */
	private String immediate;
	/** The maxlength. */
	private String maxlength;
	/** The onblur. */
	private String onblur;
	/** The onchange. */
	private String onchange;
	/** The onfocus. */
	private String onfocus;
	/** The onselect. */
	private String onselect;
	/** The readonly. */
	private String readonly;
	/** The required. */
	private String required;
	/** The size. */
	private String size;
	/** The validator. */
	private String validator;
	/** The value. */
	private String value;
	/** The value change listener. */
	private String valueChangeListener;

	/**
	 * Gets the converter.
	 * 
	 * @return the converter
	 */
	public String getConverter() {
		return converter;
	}

	/**
	 * Gets the immediate.
	 * 
	 * @return the immediate
	 */
	public String getImmediate() {
		return immediate;
	}

	/**
	 * Gets the maxlength.
	 * 
	 * @return the maxlength
	 */
	public String getMaxlength() {
		return maxlength;
	}

	/**
	 * Gets the onblur.
	 * 
	 * @return the onblur
	 */
	public String getOnblur() {
		return onblur;
	}

	/**
	 * Gets the onchange.
	 * 
	 * @return the onchange
	 */
	public String getOnchange() {
		return onchange;
	}

	/**
	 * Gets the onfocus.
	 * 
	 * @return the onfocus
	 */
	public String getOnfocus() {
		return onfocus;
	}

	/**
	 * Gets the onselect.
	 * 
	 * @return the onselect
	 */
	public String getOnselect() {
		return onselect;
	}

	/**
	 * Gets the readonly.
	 * 
	 * @return the readonly
	 */
	public String getReadonly() {
		return readonly;
	}

	/**
	 * Gets the required.
	 * 
	 * @return the required
	 */
	public String getRequired() {
		return required;
	}

	/**
	 * Gets the size.
	 * 
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * Gets the validator.
	 * 
	 * @return the validator
	 */
	public String getValidator() {
		return validator;
	}

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Gets the value change listener.
	 * 
	 * @return the value change listener
	 */
	public String getValueChangeListener() {
		return valueChangeListener;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.tag.impl.AbstractBaseTag#release()
	 */
	@Override
	public void release() {
		super.release();
		value = null;
		validator = null;
		converter = null;
		valueChangeListener = null;
		immediate = null;
		required = null;
		readonly = null;
		size = null;
		maxlength = null;
		onblur = null;
		onchange = null;
		onfocus = null;
		onselect = null;
	}

	/**
	 * Sets the converter.
	 * 
	 * @param converter the new converter
	 */
	public void setConverter(String converter) {
		this.converter = converter;
	}

	/**
	 * Sets the immediate.
	 * 
	 * @param immediate the new immediate
	 */
	public void setImmediate(String immediate) {
		this.immediate = immediate;
	}

	/**
	 * Sets the maxlength.
	 * 
	 * @param maxlength the new maxlength
	 */
	public void setMaxlength(String maxlength) {
		this.maxlength = maxlength;
	}

	/**
	 * Sets the onblur.
	 * 
	 * @param onblur the new onblur
	 */
	public void setOnblur(String onblur) {
		this.onblur = onblur;
	}

	/**
	 * Sets the onchange.
	 * 
	 * @param onchange the new onchange
	 */
	public void setOnchange(String onchange) {
		this.onchange = onchange;
	}

	/**
	 * Sets the onfocus.
	 * 
	 * @param onfocus the new onfocus
	 */
	public void setOnfocus(String onfocus) {
		this.onfocus = onfocus;
	}

	/**
	 * Sets the onselect.
	 * 
	 * @param onselect the new onselect
	 */
	public void setOnselect(String onselect) {
		this.onselect = onselect;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.tag.impl.AbstractBaseTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		addAttribute(component, "value", value);
		addAttribute(component, "validator", validator);
		addAttribute(component, "converter", converter);
		addAttribute(component, "valueChangeListener", valueChangeListener);
		addAttribute(component, "immediate", immediate);
		addAttribute(component, "required", required);
		addAttribute(component, "readonly", readonly);
		addAttribute(component, "size", size);
		addAttribute(component, "maxlength", maxlength);
		addAttribute(component, "onblur", onblur);
		addAttribute(component, "onchange", onchange);
		addAttribute(component, "onfocus", onfocus);
		addAttribute(component, "onselect", onselect);
	}

	/**
	 * Sets the readonly.
	 * 
	 * @param readonly the new readonly
	 */
	public void setReadonly(String readonly) {
		this.readonly = readonly;
	}

	/**
	 * Sets the required.
	 * 
	 * @param required the new required
	 */
	public void setRequired(String required) {
		this.required = required;
	}

	/**
	 * Sets the size.
	 * 
	 * @param size the new size
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * Sets the validator.
	 * 
	 * @param validator the new validator
	 */
	public void setValidator(String validator) {
		this.validator = validator;
	}

	/**
	 * Sets the value.
	 * 
	 * @param value the new value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Sets the value change listener.
	 * 
	 * @param valueChangeListener the new value change listener
	 */
	public void setValueChangeListener(String valueChangeListener) {
		this.valueChangeListener = valueChangeListener;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractInputTextTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
