/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import gov.ca.dmv.ease.ui.component.impl.FieldSet;

import java.io.IOException;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

/**
 * Description: This is custom renderer for component FieldSet
 * Module: gov.ca.dmv.ease.ui.component.impl.fieldset 
 * Created: Sep 16, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/16 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class FieldSetRenderer extends Renderer {
	// default renderer type
	public static final String RENDERER_TYPE = "gov.ca.dmv.ease.FieldSetRenderer";

	/**
	 * Starts encoding the JSF FieldSet component into browser understandable (html) tag. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeBegin(FacesContext facesContext, UIComponent uiComponent)
			throws IOException {
		FieldSet fieldSet = (FieldSet) uiComponent;
		if (fieldSet.isRendered()) {
			super.encodeBegin(facesContext, uiComponent);
			String legend = fieldSet.getLegend().toString();
			if (legend == null || legend.trim().equals("")) {
				return;
			}
			ResponseWriter writer = facesContext.getResponseWriter();
			writer.startElement("fieldset", fieldSet);
			writer.writeAttribute("id", uiComponent.getClientId(facesContext),
					"clientId");
			writer.writeAttribute("class", uiComponent.getAttributes().get(
					"styleClass"), "styleClass");
			writer.startElement("legend", fieldSet);
			writer.write(legend);
			writer.endElement("legend");
		}
	}

	/**
	 * writes the closing tag for JSF FieldSet component. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeEnd(FacesContext facesContext, UIComponent uiComponent)
			throws IOException {
		ResponseWriter writer = facesContext.getResponseWriter();
		writer.endElement("fieldset");
		writer.flush();
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldSetRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
