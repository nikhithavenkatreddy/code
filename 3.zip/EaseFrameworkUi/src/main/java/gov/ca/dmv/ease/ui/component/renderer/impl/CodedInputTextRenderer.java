/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import static gov.ca.dmv.ease.ui.constants.PageConstants.DATA_DOES_NOT_MATCH_VALID_CODES;
import static gov.ca.dmv.ease.ui.constants.PageConstants.FIELD_INCOMPLETE;
import static gov.ca.dmv.ease.ui.constants.PageConstants.INVALID_CHARACTER_IN_ALPHA_NUMERIC;
import gov.ca.dmv.ease.bo.code.impl.OfficeCityCode;
import gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText;
import gov.ca.dmv.ease.ui.component.impl.SuggestedSelectItem;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.FactoryFinder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.ValueBinding;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.faces.render.Renderer;

/**
 * Description: This class is the extension of @see Renderer with a small change in the behaviour the way 
 * it Renders as this component has an extra attribute called codesetname to be binded with a particular CodeSetName 
 * object entered by the user.
 * File: CodedInputTextRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CodedInputTextRenderer extends Renderer {
	/** The CODE SET VALUE PATTERN */
	protected static final Pattern CODE_SET_VALUE_PATTERN = Pattern
			.compile("([A-Z0-9]*)");

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#decode(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void decode(FacesContext context, UIComponent component) {
		getTextRenderer(context).decode(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws IOException {
		getTextRenderer(context).encodeBegin(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeChildren(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeChildren(FacesContext context, UIComponent component)
			throws IOException {
		getTextRenderer(context).encodeChildren(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		getTextRenderer(context).encodeEnd(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getConvertedValue(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object getConvertedValue(FacesContext context,
			UIComponent component, Object submittedValue)
			throws ConverterException {
		ValueBinding valueBinding = component.getValueBinding("value");
		if (valueBinding == null) {
			return null;
		}
		Class <?>valueType = valueBinding.getType(context);
		if (valueType == null) {
			return null;
		}
		// Validate against the code set if bound to a String
		if (valueType.equals(String.class)) {
			if (submittedValue == null) {
				return null;
			}
			String valueString = submittedValue.toString();
			if (valueString == null || valueString.trim().equals("")) {
				return null;
			}
			String codeSetName = ((HtmlCodedInputText) component)
					.getCodeSetName();
			String codeSetValue = valueString.toUpperCase();
			if ("CityCode".equalsIgnoreCase(codeSetName)) {
				String officeId = ""; //((HtmlSuggestedInputText) component).getOfficeId();
				ValueBinding officeValueBinding = component
						.getValueBinding("officeId");
				if (officeValueBinding != null) {
					officeId = (String) officeValueBinding.getValue(context);
				}
				if (officeId != null) {
					List <OfficeCityCode> officeCityCodeList = (List <OfficeCityCode>) FacesUtils
							.getApplicationScope().get(officeId);
					if (officeCityCodeList != null) {
						for (OfficeCityCode officeCityCode : officeCityCodeList) {
							if (officeCityCode.getCityCode().equals(
									codeSetValue)) {
								return officeCityCode.getCityCode();
							}
						}
					}
				}
			}
			else {
				if (codeSetValue != null
						&& codeSetValue.length() < ((HtmlCodedInputText) component)
								.getMaxlength()) {
					throw new ConverterException(FacesUtils.createErrorMessage(
							valueString, FIELD_INCOMPLETE));
				}
				List <SuggestedSelectItem> selectItems = (List <SuggestedSelectItem>) FacesUtils
						.getApplicationScope().get(codeSetName);
				if (selectItems == null) {
					throw new ConverterException(FacesUtils.createErrorMessage(
							valueString, DATA_DOES_NOT_MATCH_VALID_CODES));
				}
				Matcher matcher = CODE_SET_VALUE_PATTERN.matcher(codeSetValue);
				if (!matcher.matches()) {
					throw new ConverterException(FacesUtils.createErrorMessage(
							valueString, INVALID_CHARACTER_IN_ALPHA_NUMERIC));
				}
				for (SuggestedSelectItem selectItem : selectItems) {
					Object value = selectItem.getValue();
					if (value instanceof String
							&& ((String) value).equals(codeSetValue)) {
						return value;
					}
				}
			}
			throw new ConverterException(FacesUtils.createErrorMessage(
					valueString, DATA_DOES_NOT_MATCH_VALID_CODES));
		}
		Converter converter = ((UIInput) component).getConverter();
		if (converter == null) {
			converter = context.getApplication().createConverter(valueType);
		}
		if (converter != null) {
			return converter.getAsObject(context, component,
					(String) submittedValue);
		}
		else {
			return submittedValue;
		}
	}

	/**
	 * Gets the default renderer type of an HTML Input component
	 * @param context the context
	 * @return the text renderer
	 */
	protected Renderer getTextRenderer(FacesContext context) {
		RenderKitFactory rkFactory = (RenderKitFactory) FactoryFinder
				.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
		RenderKit defaultRenderKit = rkFactory.getRenderKit(context,
				RenderKitFactory.HTML_BASIC_RENDER_KIT);
		return defaultRenderKit.getRenderer(UIInput.COMPONENT_FAMILY,
				"javax.faces.Text");
	}
}
/**
 *  Modification History:
 *
 *  $Log: CodedInputTextRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/08/25 18:26:08  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.6  2012/08/14 20:36:42  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.5  2010/10/08 20:50:59  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.4  2010/08/31 21:19:05  mwrrv3
 *  Fixed defect# 2286. Added regular expression for special characters.
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
