/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.page.SystemPreferences;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.component.EditableValueHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.ibm.faces.validator.ConstraintValidator;

/**
 * Description: //TODO - provide description!
 * File: ValidateConstraint.java
 * Module:  gov.ca.dmv.ease.ui.validator
 * Created: Oct 20, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ValidateConstraint extends ConstraintValidator {
	/** The summary message. */
	private String summaryMessage;

	/**
	 * Gets the summary message.
	 * 
	 * @return the summary message
	 */
	public String getSummaryMessage() {
		return summaryMessage;
	}

	/**
	 * Sets the summary message.
	 * 
	 * @param summaryMessage the new summary message
	 */
	public void setSummaryMessage(String summaryMessage) {
		this.summaryMessage = summaryMessage;
	}

	/* (non-Javadoc)
	 * @see com.ibm.faces.validator.ConstraintValidator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object object) throws ValidatorException {
		String regExValue = "";
		if (uiComponent instanceof EditableValueHolder) {
			for (Validator validator : ((EditableValueHolder) uiComponent)
					.getValidators()) {
				if (validator instanceof ConstraintValidator) {
					regExValue = ((ConstraintValidator) validator).getRegex();
					SystemPreferences systemPreferences = (SystemPreferences) FacesUtils
							.getManagedBean(PageConstants.SYSTEM_PREF_BEAN);
					Set <String> regExMsgEntries = systemPreferences
							.getRegExMessages().keySet();
					Iterator <String> regExIterator = regExMsgEntries
							.iterator();
					while (regExIterator.hasNext()) {
						String mappedRegExValue = (regExIterator.next());
						if (mappedRegExValue.equalsIgnoreCase(regExValue)) {
							setSummaryMessage(systemPreferences
									.getRegExMessages().get(mappedRegExValue));
						}
					}
					if (object == null) {
						return;
					}
					Pattern pattern = Pattern.compile(getRegex());
					Matcher matcher = pattern.matcher((String) object);
					if (!matcher.matches()) {
						throw new ValidatorException(FacesUtils
								.createErrorMessage(object.toString(),
										getSummaryMessage()));
					}
				}
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValidateConstraint.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 00:07:22  mwpxp2
 *  Fixed javadoc, file footer
 *
 */
