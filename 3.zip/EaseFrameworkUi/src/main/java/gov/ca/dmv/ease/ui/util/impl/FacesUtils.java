/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

import static gov.ca.dmv.ease.ui.constants.PageConstants.LABEL_ATTRIBUTE_FOR;
import static gov.ca.dmv.ease.ui.constants.PageConstants.LABEL_COLON;
import static gov.ca.dmv.ease.ui.constants.PageConstants.LABEL_IPHEN;
import static javax.faces.application.FacesMessage.SEVERITY_INFO;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.ui.constants.PageConstants;

import java.util.Map;

import javax.faces.FactoryFinder;
import javax.faces.application.Application;
import javax.faces.application.ApplicationFactory;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlOutputLabel;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.render.Renderer;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Description: Utility class for JavaServer Faces. Found in JavaWorld article:
 * http://www.javaworld.com/javaworld/jw-07-2004/jw-0719-jsf.html
 * File: FacesUtils.java
 * Module:  gov.ca.dmv.ease.ui.util.impl
 * Created: Oct 27, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FacesUtils {
	/**
	 * This method adds error message.
	 * 
	 * @param msg the error message
	 */
	public static void addErrorMessage(String msg) {
		addErrorMessage(null, msg);
	}

	/**
	 * This method adds error message to a specific client.
	 * 
	 * @param clientId the client id
	 * @param msg the error message
	 */
	public static void addErrorMessage(String clientId, String msg) {
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(msg + "-uiErrorMsg"));
		FacesContext.getCurrentInstance().addMessage(clientId,
				new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg));
	}

	/**
	 * This method adds information message.
	 * 
	 * @param msg the information message
	 */
	public static void addInfoMessage(String msg) {
		addInfoMessage(null, msg);
	}

	/**
	 * This method adds information message to a specific client.
	 * 
	 * @param clientId the client id
	 * @param msg the information message
	 */
	public static void addInfoMessage(String clientId, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId,
				new FacesMessage(SEVERITY_INFO, msg, msg));
	}

	/**
	 * This method adds the message with respect to the given severity.
	 * 
	 * @param severity the severity
	 * @param message the message
	 */
	public static void addMessage(FacesMessage.Severity severity, String message) {
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(severity, message, null));
	}

	/**
	 * This method creates the error message for a given value.
	 * 
	 * @param value the value
	 * @param errorMesg the error mesg
	 * 
	 * @return the faces message
	 */
	public static FacesMessage createErrorMessage(String value, String errorMesg) {
		return new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMesg,
				"Unable to convert " + value);
	}

	/**
	 * This method returns the application.
	 * 
	 * @return the application
	 */
	private static Application getApplication() {
		ApplicationFactory appFactory = (ApplicationFactory) FactoryFinder
				.getFactory(FactoryFinder.APPLICATION_FACTORY);
		return appFactory.getApplication();
	}

	/**
	 * This method returns the Map of application scope.
	 * 
	 * @return the application scope
	 */
	@SuppressWarnings("unchecked")
	public static Map <String, Object> getApplicationScope() {
		return getFacesContext().getExternalContext().getApplicationMap();
	}

	/**
	 * This method gets the client id associated with the component.  Checks the forceId
	 * attribute of the component (if present) and uses the originally supplied
	 * id value if that attribute is true.
	 * 
	 * @param component The component for which the client id is needed.
	 * @param renderer The renderer associated with the component.
	 * @param context Additional context information to help in the request.
	 * 
	 * @return The clientId to use with the specified component.
	 */
	public static String getClientId(UIComponent component, Renderer renderer,
			FacesContext context) {
		if (component.getId() != null) {
			String clientId = component.getId();
			if (renderer != null) {
				clientId = renderer.convertClientId(context, clientId);
			}
			return clientId;
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the current screen name.
	 * 
	 * @return the current screen name
	 */
	public static String getCurrentScreenName() {
		String viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		return ArrayUtils.capitalize(viewId.substring(
				viewId.lastIndexOf("/") + 1, viewId.indexOf(".jspx")));
	}

	/**
	 * This method returns the instance of faces context.
	 * 
	 * @return the faces context
	 */
	public static FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	/**
	 * This method returns the value binding expression as a string for a given value.
	 * 
	 * @param value the value
	 * 
	 * @return the JSF el
	 */
	private static String getJsfEl(String value) {
		return "#{" + value + "}";
	}

	/**
	 * This method gets the label for an input component.
	 * 
	 * @param componentId the component id
	 * @param uiComponent the ui component
	 * 
	 * @return the label
	 */
	@SuppressWarnings("unchecked")
	public static String getLabel(String componentId, UIComponent uiComponent) {
		String labelValue = null;
		if (uiComponent instanceof HtmlOutputLabel) {
			HtmlOutputLabel htmlOutputLabel = (HtmlOutputLabel) uiComponent;
			Map <String, Object> attrs = htmlOutputLabel.getAttributes();
			String id = (String) attrs.get(LABEL_ATTRIBUTE_FOR);
			if (id != null && id.equals(componentId)) {
				labelValue = (String) htmlOutputLabel.getValue();
			}
		}
		if (labelValue != null) {
			return labelValue;
		}
		for (Object uiComponentChild : uiComponent.getChildren()) {
			if (labelValue == null) {
				labelValue = getLabel(componentId,
						(UIComponent) uiComponentChild);
			}
			else {
				break;
			}
		}
		return labelValue;
	}

	/**
	 * This method gets the label value for an input component.
	 * 
	 * @param componentId the component id
	 * @param uiFormComponent the ui form component
	 * 
	 * @return the label value
	 */
	public static String getLabelValue(String componentId,
			UIComponent uiFormComponent) {
		String labelValue = "";
		int index = componentId.indexOf(LABEL_COLON);
		if (index > 0) {
			componentId = componentId
					.substring(index + 1, componentId.length());
		}
		labelValue = getLabel(componentId, uiFormComponent);
		if (labelValue == null || "".equals(labelValue)) {
			labelValue = componentId;
		}
		else if (labelValue.contains(LABEL_COLON)) {
			labelValue = labelValue.replaceAll(LABEL_COLON, "");
		}
		else if (labelValue.contains(PageConstants.LABEL_IPHEN)) {
			labelValue = labelValue.replaceAll(LABEL_IPHEN, "");
		}
		return labelValue;
	}

	/**
	 * This method get managed bean based on the bean name.
	 * 
	 * @param beanName the bean name
	 * 
	 * @return the managed bean associated with the bean name
	 */
	public static Object getManagedBean(String beanName) {
		return getValueBinding(getJsfEl(beanName)).getValue(
				FacesContext.getCurrentInstance());
	}

	/**
	 * This method return name of current page.
	 * 
	 * @return String
	 */
	public static String getPageName() {
		return FacesContext.getCurrentInstance().getViewRoot().getViewId();
	}

	/**
	 * This method returns the HttpServeltRequest.
	 * 
	 * @return the request
	 */
	public static HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance()
				.getExternalContext().getRequest();
	}

	/**
	 * This method gets parameter value from request scope.
	 * 
	 * @param name the name of the parameter
	 * 
	 * @return the parameter value
	 */
	public static String getRequestParameter(String name) {
		return (String) FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get(name);
	}

	/**
	 * This method returns the HttpServeltResponse.
	 * 
	 * @return the response
	 */
	public static HttpServletResponse getResponse() {
		return (HttpServletResponse) FacesContext.getCurrentInstance()
				.getExternalContext().getResponse();
	}

	/**
	 * This method returns the Servlet context.
	 * 
	 * @return ServletContext
	 */
	public static ServletContext getServletContext() {
		return (ServletContext) FacesContext.getCurrentInstance()
				.getExternalContext().getContext();
	}

	/**
	 * This method returns the HttpSession.
	 * 
	 * @return the session
	 */
	public static HttpSession getSession() {
		return (HttpSession) FacesContext.getCurrentInstance()
				.getExternalContext().getSession(false);
	}

	/**
	 * This method returns the value binding for a given el expression.
	 * 
	 * @param el the el
	 * 
	 * @return the value binding
	 */
	private static ValueBinding getValueBinding(String el) {
		return getApplication().createValueBinding(el);
	}

	/**
	 * This method removes the managed bean based on the bean name.
	 * 
	 * @param beanName the bean name of the managed bean to be removed
	 */
	public static void resetManagedBean(String beanName) {
		getValueBinding(getJsfEl(beanName)).setValue(
				FacesContext.getCurrentInstance(), null);
	}

	/**
	 * This method sets the managed bean inside the session scope.
	 * 
	 * @param beanName the name of the managed bean to be stored
	 * @param managedBean the managed bean to be stored
	 */
	@SuppressWarnings("unchecked")
	public static void setManagedBeanInSession(String beanName,
			Object managedBean) {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.put(beanName, managedBean);
	}
}
/**
 *  Modification History:
 *
 *  $Log: FacesUtils.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/08/18 00:49:51  mwrrv3
 *  Code clean up and fixed PMD issues.
 *
 *  Revision 1.7  2011/06/10 23:13:13  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.6  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/06/21 23:00:43  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.3.16.2  2010/06/20 18:06:54  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.4  2010/06/08 17:16:54  mwrrv3
 *  Appended uiErrorMsg to the UI error message to distinguish between UI and BR  error messages.
 *
 *  Revision 1.3  2010/03/23 00:06:13  mwpxp2
 *  Fixed file footer
 *
 */
