/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.codeset.impl;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.ICodeSetNameConstants;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.bus.service.ICodeSetService;
import gov.ca.dmv.ease.ui.component.impl.SuggestedSelectItem;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.web.context.ServletContextAware;

/**
 * Description: This class is is used to load the code sets 
 * File: UiCodeSetLoader.java
 * Module:  gov.ca.dmv.ease.ui.codeset.impl
 * Created: Sep 15, 2009
 * @author mwbvc
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class UiCodeSetLoader implements ServletContextAware,
		ICodeSetNameConstants {
	/** The code set name. */
	private String codeSetName;
	/** The code set service. */
	private ICodeSetService codeSetService;
	/** The concatinated code description. */
	private Boolean concatinatedCodeDescription;
	/** The label. */
	private String label;
	/** The servlet context. */
	private ServletContext servletContext;
	/** The use code set element instead of string. */
	private Boolean useCodeSetElementInsteadOfString;

	/**
	 * Gets the code set service.
	 * 
	 * @return the code set service
	 */
	public ICodeSetService getCodeSetService() {
		return codeSetService;
	}

	/**
	 * Load codes from service, convert results to 
	 * SuggestedSelectItems, adds to collection and
	 * put collection into application scope under key of 
	 * passed codeSet name.
	 */
	public void load() {
		SuggestedSelectItem selectItem;
		List <SuggestedSelectItem> selectItems = new ArrayList <SuggestedSelectItem>();
		// get codes from service
		ICodeSet codeSet = this.codeSetService.getCodeSetNamed(codeSetName,
				new UserContext());
		if (codeSet == null) {
			codeSet = new CodeSet(codeSetName);
			codeSet.add(new CodeSetElement(codeSetName, "?",
					"Missing code set data for " + codeSetName, codeSet));
		}
		// convert results to SelectItems
		for (ICodeSetElement codeSetElement : codeSet.getCodeSetElements()) {
			label = codeSetElement.getName();
			if (this.concatinatedCodeDescription) {
				label = codeSetElement.getCode() + " - "
						+ codeSetElement.getName();
			}
			if (this.useCodeSetElementInsteadOfString) {
				selectItem = new SuggestedSelectItem(codeSetElement, label);
			}
			else {
				selectItem = new SuggestedSelectItem(codeSetElement.getCode(),
						label);
			}
			// add to collection
			selectItems.add(selectItem);
		}
		// put collection into application scope under key of passed codeSet name
		if (servletContext != null) {
			servletContext.setAttribute(this.codeSetName, selectItems);
		}
	}

	/**
	 * Sets the code set name.
	 * 
	 * @param codeSetName the new code set name
	 */
	public void setCodeSetName(String codeSetName) {
		this.codeSetName = codeSetName;
	}

	/**
	 * Sets the code set service.
	 * 
	 * @param codeSetService the new code set service
	 */
	public void setCodeSetService(ICodeSetService codeSetService) {
		this.codeSetService = codeSetService;
	}

	/**
	 * Sets the concatenated code description.
	 * 
	 * @param concatinatedCodeDescription the new concatenated code description
	 */
	public void setConcatinatedCodeDescription(
			Boolean concatinatedCodeDescription) {
		this.concatinatedCodeDescription = concatinatedCodeDescription;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.context.ServletContextAware#setServletContext(javax.servlet.ServletContext)
	 */
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	/**
	 * Sets the use code set element instead of string.
	 * 
	 * @param useCodeSetElementInsteadOfString the new use code set element instead of string
	 */
	public void setUseCodeSetElementInsteadOfString(
			Boolean useCodeSetElementInsteadOfString) {
		this.useCodeSetElementInsteadOfString = useCodeSetElementInsteadOfString;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: UiCodeSetLoader.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/08/31 17:58:26  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.4  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/05/29 19:43:02  mwtjc1
 *  if condition to check null servletContext is added in load method
 *
 *  Revision 1.2  2010/03/22 23:41:55  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/03 21:33:11  mwbvc
 *  changed SelectItem to SuggestedSelectItem to sort the select items
 *
 *  Revision 1.3  2009/10/27 00:16:50  mwgxk2
 *  Added Comments.
 *
 *  Revision 1.2  2009/10/22 16:55:02  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/22 00:40:51  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/21 23:51:09  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.7  2009/09/16 18:24:24  mwskd2
 *  codeSetElement constructor argument name changed from null to codesetname
 *
 *  Revision 1.6  2009/09/15 21:46:30  mwjjl7
 *  back to SelectItem with label = code set element name (or code plus name)
 *
 *  Revision 1.5  2009/09/14 16:18:56  mwakg
 *  Showing Name instead of Description if concatinatedCodeDescription is turned on
 *
 *  Revision 1.4  2009/09/13 20:45:22  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.3.2.1  2009/09/13 18:45:25  mwakg
 *  Fixed codeset service to load from DB instead of XML. Showing code as default instead of description. Only when needed description is appended for SelectItem in codeset
 *
 *  Revision 1.3  2009/09/10 20:36:41  mwpxm2
 *  CodeSet design change
 *
 *  Revision 1.2  2009/09/10 03:01:08  mwjjl7
 *  add null codeset from service protection
 *
 *  Revision 1.1  2009/09/09 16:54:46  mwjjl7
 *  refactor rename code set loader class
 *
 *  Revision 1.7  2009/09/09 03:27:41  mwjjl7
 *  update to support codeset redesign
 *
 *  Revision 1.6  2009/08/18 03:46:27  mwjjl7
 *  add try catch to load
 *
 *  Revision 1.5  2009/08/03 17:19:51  mwjjl7
 *  refactor
 *
 *  Revision 1.4  2009/07/31 00:33:36  mwpxm2
 *  Fixed label
 *
 *  Revision 1.3  2009/07/31 00:06:10  mwpxm2
 *  Added ServletContextAware
 *
 *  Revision 1.2  2009/07/30 22:12:13  mwpxm2
 *  update load
 *
 *  Revision 1.1  2009/07/30 02:31:25  mwjjl7
 *  initila load
 *
*/
