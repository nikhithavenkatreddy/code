/**
 *
 */
package gov.ca.dmv.ease.ui.handler;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.fw.process.ISessionContext;

import java.io.Serializable;
import java.util.Date;

import javax.faces.component.html.HtmlCommandButton;
import javax.faces.event.ActionEvent;

import org.springframework.context.MessageSource;

/**
 * Description: I am interface for ActionsHandler
 * File: IActionsHandler.java
 * Module:  gov.ca.dmv.ease.ui.handler
 * Created: Sep 26, 2012
 * @author mwpxp2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/05/07 23:12:54 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface IActionsHandler extends Serializable {
	/**
	 * Convert the validation messages to faces messages and add them to
	 * faces context to show in the UI page.
	 *
	 * @param context the context
	 */
	void buildFacesMessages(ProcessContext context);

	/**
	 * Triggered upon button press (for all buttons)
	 *
	 * Any button press calls the nextActivity
	 *
	 * Note: JSF actions run after actionListeners.
	 *
	 * @return String representing the outcome JSF will lookup use for navigation
	 */
	String buttonAction();

	/**
	 * Triggered upon button press (for all buttons)
	 *
	 * The triggering component's associated Action is
	 * set into the process context
	 *
	 * Note: JSF actionListeners run before actions.
	 *
	 * @param actionEvent the action event
	 */
	void buttonActionEvent(ActionEvent actionEvent);

	/**
	 * Generate token.
	 *
	 * @return the string
	 */
	String generateToken();

	/**
	 * Gets the builds the info.
	 *
	 * @return the buildInfo
	 */
	MessageSource getBuildInfo();

	/**
	 * Gets the builds the number.
	 *
	 * @return the BUILD_NUMBER
	 */
	String getBuildNumber();

	/**
	 * Gets the button1.
	 *
	 * @return the button1
	 */
	HtmlCommandButton getButton1();

	/**
	 * Gets the button10.
	 *
	 * @return the button10
	 */
	HtmlCommandButton getButton10();

	/**
	 * Gets the button11.
	 *
	 * @return the button11
	 */
	HtmlCommandButton getButton11();

	/**
	 * Gets the button12.
	 *
	 * @return the button12
	 */
	HtmlCommandButton getButton12();

	/**
	 * Gets the button2.
	 *
	 * @return the button2
	 */
	HtmlCommandButton getButton2();

	/**
	 * Gets the button3.
	 *
	 * @return the button3
	 */
	HtmlCommandButton getButton3();

	/**
	 * Gets the button4.
	 *
	 * @return the button4
	 */
	HtmlCommandButton getButton4();

	/**
	 * Gets the button5.
	 *
	 * @return the button5
	 */
	HtmlCommandButton getButton5();

	/**
	 * Gets the button6.
	 *
	 * @return the button6
	 */
	HtmlCommandButton getButton6();

	/**
	 * Gets the button7.
	 *
	 * @return the button7
	 */
	HtmlCommandButton getButton7();

	/**
	 * Gets the button8.
	 *
	 * @return the button8
	 */
	HtmlCommandButton getButton8();

	/**
	 * Gets the button9.
	 *
	 * @return the button9
	 */
	HtmlCommandButton getButton9();

	/**
	 * Gets the context path.
	 *
	 * @return the context path
	 */
	String getContextPath();

	/**
	 * Gets the current master file status.
	 *
	 * @return the current master file status
	 */
	String getCurrentMasterFileStatus();

	/**
	 * Gets the current mode.
	 *
	 * @return the current mode
	 */
	String getCurrentMode();

	/**
	 * Gets the current processor partner status.
	 *
	 * @return the current processor partner status
	 */
	String getCurrentProcessorPartnerStatus();

	/**
	 * Gets the current screen name.
	 *
	 * @return the current screen name
	 */
	String getCurrentScreenName();

	/**
	 * Gets the last cashier seq number.
	 *
	 * @return the last cashier seq number
	 */
	String getLastCashierSeqNumber();

	/**
	 * Gets the last rating seq number.
	 *
	 * @return the last rating seq number
	 */
	String getLastRatingSeqNumber();

	/**
	 * Gets the prev screen name.
	 *
	 * @return the prev screen name
	 */
	String getPrevScreenName();

	//	/**
	//	 * Gets the next activity.
	//	 *
	//	 * @return the next activity
	//	 */
	//	 InteractionActivity getNextInteractionActivity() {
	//		return (InteractionActivity) getCurrentProcessContext()
	//				.getNextActivity();
	//	}
	/**
	 * Gets the processor id.
	 *
	 * @return the processor id
	 */
	String getProcessorId();

	/**
	 * Gets the processor mode.
	 *
	 * @return the processor mode
	 */
	String getProcessorMode();

	/**
	 * Gets the rdf suspense status.
	 *
	 * @return the rdf suspense status
	 */
	String getRdfSuspenseStatus();

	/**
	 * Gets the selected action.
	 *
	 * @param actionEvent the action event
	 *
	 * @return the selected action
	 */
	String getSelectedAction(ActionEvent actionEvent);

	/**
	 * Gets the system military time.
	 *
	 * @return the system military time
	 */
	String getSystemMilitaryTime();

	/**
	 * Gets the terminal id.
	 *
	 * @return the terminal id
	 */
	String getTerminalId();

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	String getToken();

	/**
	 * Gets the token data.
	 *
	 * @return the token data
	 */
	IHandlerTokenData getTokenData();

	//Operator and Page Info details
	/**
	 * Gets the transaction screen id.
	 *
	 * @return the transaction screen id
	 */
	String getTransactionScreenId();

	/**
	 * Gets the type transaction code.
	 *
	 * @return the type transaction code
	 */
	String getTypeTransactionCode();

	/**
	 * Gets the view id.
	 *
	 * @return the view id
	 */
	String getViewId();

	/**
	 * Gets the system date.
	 *
	 * @return the system date
	 */
	Date getWorkDate();

	/**
	 * Gets the work set id (Office Id + Day of Year + Technician Id).
	 *
	 * @return the work set id
	 */
	String getWorkSetId();

	/**
	 * This wont hit the Activities.
	 *
	 * @return the string
	 */
	String mockButtonAction();

	/**
	 * Now.
	 *
	 * @param dateFormat the date format
	 *
	 * @return the string
	 */
	String now(String dateFormat);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ILoggable#outputAppLog(java.lang.StringBuilder)
	 */
	void outputAppLog(StringBuilder aStringBuilder);

	/**
	 * Popup button action.
	 *
	 * @return the string
	 */
	String popupButtonAction();

	/**
	 * Sets the builds the info.
	 *
	 * @param buildInfo the buildInfo to set
	 */
	void setBuildInfo(MessageSource buildInfo);

	/**
	 * Sets the action decorators.
	 *
	 * @param aButton the new button1
	 */
	/*	 void setActionDecorators(Map <String, UiActionDecorator> aMap) {
			actionDecorators = aMap;
		}*/
	/**
	 * Sets the button1.
	 *
	 * @param aButton the a button
	 */
	void setButton1(HtmlCommandButton aButton);

	/**
	 * Sets the button10.
	 *
	 * @param aButton the a button
	 */
	void setButton10(HtmlCommandButton aButton);

	/**
	 * Sets the button11.
	 *
	 * @param aButton the a button
	 */
	void setButton11(HtmlCommandButton aButton);

	/**
	 * Sets the button12.
	 *
	 * @param aButton the a button
	 */
	void setButton12(HtmlCommandButton aButton);

	/**
	 * Sets the button2.
	 *
	 * @param aButton the a button
	 */
	void setButton2(HtmlCommandButton aButton);

	/**
	 * Sets the button3.
	 *
	 * @param aButton the a button
	 */
	void setButton3(HtmlCommandButton aButton);

	/**
	 * Sets the button4.
	 *
	 * @param aButton the a button
	 */
	void setButton4(HtmlCommandButton aButton);

	/**
	 * Sets the button5.
	 *
	 * @param aButton the a button
	 */
	void setButton5(HtmlCommandButton aButton);

	/**
	 * Sets the button6.
	 *
	 * @param aButton the a button
	 */
	void setButton6(HtmlCommandButton aButton);

	/**
	 * Sets the button7.
	 *
	 * @param aButton the a button
	 */
	void setButton7(HtmlCommandButton aButton);

	/**
	 * Sets the button8.
	 *
	 * @param aButton the a button
	 */
	void setButton8(HtmlCommandButton aButton);

	/**
	 * Sets the button9.
	 *
	 * @param aButton the a button
	 */
	void setButton9(HtmlCommandButton aButton);

	/**
	 * Sets the session context.
	 *
	 * @param aCtx the new session context
	 */
	void setSessionContext(ISessionContext aCtx);

	/**
	 * 1- Get list of Actions from Activity
	 * 2- Decorate each contained Action
	 * 3- Set button attributes from decorated action for "action",
	 * "label text", "is rendered" and "is immediate" for each
	 * button.
	 */
	void setupButtons();
}
/**
 *  Modification History:
 *
 *  $Log: IActionsHandler.java,v $
 *  Revision 1.2  2013/05/07 23:12:54  mwsec2
 *  removed unused getBundledId method
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/09/27 00:18:11  mwpxp2
 *  Extended serializable
 *
 *  Revision 1.2  2012/09/27 00:10:07  mwpxp2
 *  Removed setMessageSource on spring type- does not look like it is used
 *
 *  Revision 1.1  2012/09/27 00:09:10  mwpxp2
 *  Initial - extracted from the existing implementation
 *
 */
