package gov.ca.dmv.ease.ui.component.renderer.impl;

import java.io.IOException;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

/**
 * Description: //TODO - provide description!
 * File: DivRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: 2009
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DivRenderer extends Renderer {
	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#decode(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void decode(FacesContext context, UIComponent component) {
		return;
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws IOException {
		ResponseWriter writer = context.getResponseWriter();
		writer.startElement("div", component);
		writer.writeAttribute("id", component.getClientId(context), "clientId");
		writer.writeAttribute("class", component.getAttributes().get(
				"styleclass"), "styleclass");
		writer.flush();
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		ResponseWriter writer = context.getResponseWriter();
		writer.endElement("div");
		writer.flush();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DivRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:50:10  mwpxp2
 *  Added class header
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/22 16:55:02  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/22 00:40:46  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/21 23:51:33  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.3  2009/08/03 22:22:03  mwbvc
 *  custom JSF component for DIV tag - to use the DIV with rendered attribute
 *
*/
