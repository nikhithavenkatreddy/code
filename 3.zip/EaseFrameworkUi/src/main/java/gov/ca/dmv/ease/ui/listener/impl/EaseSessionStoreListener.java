/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import gov.ca.dmv.ease.app.activity.impl.SubprocessActivity;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ExecutionSyncPoint;
import gov.ca.dmv.ease.app.session.factory.impl.SessionServiceRequestFactory;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.request.ISessionServiceRequest;
import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.app.session.response.impl.DeleteSessionResponse;
import gov.ca.dmv.ease.app.session.response.impl.StoreSessionResponse;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Stack;

import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Description: The purpose of this class is to store or restore the state of the session.
 * File: EaseSessionStoreListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: May 5, 2010 
 * @author MWVKM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
@Deprecated
public class EaseSessionStoreListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1883007408150123696L;
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory
			.getLog(EaseSessionStoreListener.class);
	
	/**
	 * The list of store activities.
	 *
	 * @param phaseEvent the phase event
	 */
	//private static List <String> STORE_SESSION_ACTIVITIES = createStoreActivityList();
	/**
	 * Creates the List of activities where the session is stored.
	 * 
	 * @return storeActivityList
	 */
	//	private static List <String> createStoreActivityList() {
	//		List <String> storeActivityList = new ArrayList <String>();
	//		storeActivityList.add("CollectPaymentDataActivity");
	//		return storeActivityList;
	//	}
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
		LOGGER.info("After Phase is called.");
		FacesContext facesContext = phaseEvent.getFacesContext();
		ServletContext servletContext = (ServletContext) facesContext
				.getExternalContext().getContext();
		HttpServletRequest httpServletRequest = (HttpServletRequest) facesContext
				.getExternalContext().getRequest();
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(servletContext);
		this.storeApplicationState(
				httpServletRequest.getSession(false).getId(),
				applicationContext);
	}
	
	/**
	 * The purpose of this method is to store the application state.
	 *
	 * @param sessionId the session id
	 * @param applicationContext the application context
	 */
	@SuppressWarnings("unchecked")
	private void storeApplicationState(String sessionId,
			ApplicationContext applicationContext) {
		/* Session scoped session-context from the spring configuration */
		ISessionContext sessionContext = (ISessionContext) EaseProxyUtils
				.getProxyObject(applicationContext.getBean("sessionContext"));
		IUserContext userContext = (IUserContext) EaseProxyUtils
				.getProxyObject(sessionContext.getUserContext());
		Stack <ExecutionSyncPoint> executionSyncPoints = (Stack <ExecutionSyncPoint>) EaseProxyUtils
				.getProxyObject(sessionContext.getExecutionSyncPoints());
		IProcessContext rollbackProcessContext = sessionContext
				.getRollbackProcessContext();
		SubprocessActivity rollbackSubprocessActivity = sessionContext
				.getRollbackSubprocessActivity();
		String rollbackSubprocessActivityName = null;
		if (!EaseUtil.isNullOrBlank(rollbackSubprocessActivity)) {
			rollbackSubprocessActivityName = rollbackSubprocessActivity
					.getClass().getSimpleName();
		}
		SessionData sessionData = new SessionData(sessionContext
				.getCurrentProcessContext(), userContext, executionSyncPoints,
				rollbackProcessContext, rollbackSubprocessActivityName);
		/* Save the session data */
		if (sessionData.hasRequiredData()) {
			SessionData sessionDataBean = (SessionData) EaseProxyUtils
					.getProxyObject(applicationContext.getBean("sessionData"));
			try {
				Session session = new Session(userContext, sessionId);
				if (((ChildContext) sessionData.getCurrentProcessContext())
						.isMenuProcess()) {
					//Delete Session
					//CollectTransactionTypeActivity
					//CollectModeSelectionActivity
					if (sessionDataBean.hasRequiredData()) {
						ISessionServiceRequest deleteRequest = SessionServiceRequestFactory
								.getInstance().createDeleteSessionRequest(
										userContext, session);
						ISessionServiceResponse deleteResponse = (DeleteSessionResponse) deleteRequest
								.execute();
						if (deleteResponse.hasErrors()) {
							LOGGER
									.info("Error deleting session state for user '"
											+ userContext.getUserName() + "'.");
						}
						else {
							LOGGER.info("Session state is deleted for user '"
									+ userContext.getUserName() + "'.");
						}
					}
				}
				else /*if (STORE_SESSION_ACTIVITIES.contains(sessionData
																																				.getNextInteractionActivityName()))*/{
					//Store Session
					ISessionServiceRequest storeRequest = SessionServiceRequestFactory
							.getInstance().createStoreSessionRequest(
									userContext, session, sessionData);
					ISessionServiceResponse storeResponse = (StoreSessionResponse) storeRequest
							.execute();
					if (storeResponse.hasErrors()) {
						LOGGER.info("Error storing session state for user '"
								+ userContext.getUserName() + "'.");
					}
					else {
						LOGGER.info("Session state is stored for user '"
								+ userContext.getUserName() + "'.");
					}
				}
				LOGGER.info("Last Interaction Activity Name :"
						+ sessionData.getPreviousInteractionActivityName());
				LOGGER.info("Next Interaction Activity Name :"
						+ sessionData.getCurrentInteractionActivityName());
			}
			catch (EaseValidationException e) {
				LOGGER.info(e.toString());
			}
			if (!sessionDataBean.hasRequiredData()) {
				sessionDataBean.copy(sessionData);
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		LOGGER.info("Before Phase is called.");
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 */
	public PhaseId getPhaseId() {
		//return PhaseId.INVOKE_APPLICATION;
		return PhaseId.RENDER_RESPONSE;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseSessionStoreListener.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.33  2012/09/12 00:26:40  mwhys
 *  Deprecated this class as the session is stored only for certain activities. (Defect 7189)
 *
 *  Revision 1.32  2012/06/01 21:41:47  mwhys
 *  Updated to store rollbackProcessContext. (Session Management)
 *
 *  Revision 1.31  2012/05/08 00:29:46  mwhys
 *  Refactored getters for current and previous activities.
 *
 *  Revision 1.30  2012/01/11 00:11:59  mwkfh
 *  Disabled the store activity list
 *
 *  Revision 1.29  2012/01/09 23:36:43  mwkfh
 *  updated to store only when loading CollectPaymentDataActivity
 *
 *  Revision 1.28  2012/01/07 00:41:49  mwkfh
 *  updated storeApplicationState
 *
 *  Revision 1.27  2011/06/09 20:05:52  mwyxg1
 *  clean up
 *
 *  Revision 1.26  2010/12/02 00:14:58  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.25  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 *  Revision 1.24  2010/09/24 00:25:53  mwhys
 *  Added executionSyncPoints field to the session data, so updated this file.
 *
 *  Revision 1.23  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.22  2010/08/31 22:45:11  mwkfh
 *  removed errorCollector
 *
 *  Revision 1.21  2010/08/30 18:52:36  mwkfh
 *  added errorCollector and updated new SessionData
 *
 *  Revision 1.20  2010/08/23 16:03:42  mwkfh
 *  added use of EaseUtil.isNotNull
 *
 *  Revision 1.19  2010/08/20 16:17:56  mwkfh
 *  updated conditions in storeApplicationState()
 *
 *  Revision 1.18  2010/08/19 15:43:02  mwkfh
 *  added catch for EaseValidationException
 *
 *  Revision 1.17  2010/08/18 01:00:10  mwkfh
 *  changed menu name to CollectTransactionTypeActivity
 *
 *  Revision 1.16  2010/08/11 23:54:57  mwkfh
 *  refactored private methods
 *
 *  Revision 1.15  2010/08/04 20:33:53  mwkfh
 *  changed cancelRestore to go to CollectModeSelectionActivity screen
 *
 *  Revision 1.14  2010/08/03 16:59:14  mwkfh
 *  modified activityNameToStore() and clean-up
 *
 *  Revision 1.13  2010/08/02 21:29:09  mwkfh
 *  changed the Phase and update delete in storeApplicationState()
 *
 *  Revision 1.12  2010/07/30 22:07:56  mwkfh
 *  refactored and merge session store and restore
 *
 *  Revision 1.11  2010/07/29 17:54:48  mwkfh
 *  removed save on DL menu
 *
 *  Revision 1.10  2010/07/27 18:01:05  mwkfh
 *  updated and moved session services
 *
 *  Revision 1.9  2010/07/16 15:32:40  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.4.2.4  2010/07/12 21:26:57  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.4.2.3  2010/07/08 23:27:58  mwvkm
 *  A bug is fixed w.r.t sys_id in the session table while inserting the record in the database.
 *
 *  Revision 1.4.2.2  2010/06/28 23:27:52  mwvkm
 *  A bug with session restore is fixed.
 *
 *  Revision 1.4.2.1  2010/05/20 22:59:26  mwvkm
 *  Aspects are removed/commented for Session restore POC
 *
 *  Revision 1.4  2010/05/18 23:08:45  mwvkm
 *  Changes/Updates are made for Session Restore functionality POC.
 *
 *  Revision 1.3  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.2  2010/05/05 20:00:56  mwvkm
 *  A bug is fixed in Session restore functionality.
 *
 *  Revision 1.1  2010/05/05 17:06:38  mwvkm
 *  Session store listener for faces life cycle
 *
 */
