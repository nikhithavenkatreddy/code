/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;

/**
 * Description: I am listener to servlet context events;
 * I am interested in  sessionDestroyed in order to fix a problem with Spring memory leak.
 * I try first to close WebApplicationContext, if available, and if not, I try to find spring AppContext objects and close them.
 * 
 * File: EaseServletContextListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: Jul 28, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseServletContextListener implements ServletContextListener {
	/** The SPRING_ROOT_KEY. */
	protected static final String SPRING_ROOT_KEY = "org.springframework.web.context.WebApplicationContext.ROOT";
	/** The Constant DQUOTE. */
	protected static final char DQUOTE = '"';
	/** Logger for this class. */
	protected static final Log LOGGER = LogFactory
			.getLog(EaseServletContextListener.class);
	/** The Constant SPACER. */
	protected static final String SPACER = "\n\t";
	/** The Constant SPRING_APP_CTX_IMPL1. */
	protected static final String SPRING_APP_CTX_IMPL1 = "org.springframework.context.support.AbstractApplicationContext";
	/** The Constant SPRING_APP_CTX_IMPL2. */
	protected static final String SPRING_APP_CTX_IMPL2 = "org.springframework.context.support.GenericApplicationContext";
	/** The Constant SPRING_APP_CTX_INTERFACE. */
	protected static final String SPRING_APP_CTX_INTERFACE = "org.springframework.context.ApplicationContext";
	/** The Constant SPRING_APP_CTX_NAME. */
	public static final String SPRING_APP_CTX_NAME = "UNDETERMINED";
	/** The Constant SPRING_PACKAGE. */
	protected static final String SPRING_PACKAGE = "org.springframework";

	/**
	 * Instantiates a new ease servlet context listener.
	 */
	public EaseServletContextListener() {
		super();
	}

	/**
	 * As string.
	 *
	 * @param aCtx the a ctx
	 * @return the string
	 */
	protected String asString(ServletContext aCtx) {
		StringBuilder aBuilder = new StringBuilder(512);
		aBuilder.append(aCtx.getClass()).append(SPACER);
		Enumeration <?> e = aCtx.getAttributeNames();
		while (e.hasMoreElements()) {
			String aName = (String) e.nextElement();
			aBuilder.append(SPACER).append(DQUOTE).append(aName).append(DQUOTE);
			aBuilder.append(" value: [").append(aCtx.getAttribute(aName))
					.append("]");
		}
		return aBuilder.toString();
	}

	/**
	 * Clean spring app context impl1.
	 *
	 * @param value the value
	 * @return true, if successful
	 */
	protected boolean cleanSpringAppContextImpl1(Object value) {
		try {
			AbstractApplicationContext aSpringCtx = (AbstractApplicationContext) value;
			return closeApplicationContext(aSpringCtx);
		}
		catch (ClassCastException e) {
			LOGGER.info("got e: " + e.getMessage());
			return false;
		}
	}

	/**
	 * Clean spring app context impl2.
	 *
	 * @param value the value
	 * @return true, if successful
	 */
	protected boolean cleanSpringAppContextImpl2(Object value) {
		try {
			GenericApplicationContext aSpringCtx = (GenericApplicationContext) value;
			return closeApplicationContext(aSpringCtx);
		}
		catch (ClassCastException e) {
			LOGGER.info("got e: " + e.getMessage());
			return false;
		}
	}

	/**
	 * Clean spring interface.
	 *
	 * @param value the value
	 * @return true, if successful
	 */
	protected boolean cleanSpringInterface(Object value) {
		try {
			ApplicationContext aSpringCtx = (ApplicationContext) value;
			return closeApplicationContextInterface(aSpringCtx);
		}
		catch (ClassCastException e) {
			LOGGER.info("got e: " + e.getMessage());
			return false;
		}
	}

	/**
	 * Close application context.
	 *
	 * @param aSpringCtx the a spring ctx
	 * @return true, if successful
	 */
	protected boolean closeApplicationContext(
			AbstractApplicationContext aSpringCtx) {
		LOGGER.info("App context before close() " + aSpringCtx);
		aSpringCtx.close();
		LOGGER.info("App context after close() " + aSpringCtx);
		return true;
	}

	/**
	 * Close application context interface.
	 *
	 * @param springCtx the spring ctx
	 * @return true, if successful
	 */
	protected boolean closeApplicationContextInterface(
			ApplicationContext springCtx) {
		if (springCtx instanceof AbstractApplicationContext) {
			return closeApplicationContext((AbstractApplicationContext) springCtx);
		}
		else {
			LOGGER.info("Interface " + springCtx
					+ " not a AbstractApplicationContext");
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent anEvent) {
		LOGGER.info(this + "- Servlet Context destroyed, start - event: "
				+ anEvent);
		ServletContext aCtx = anEvent.getServletContext();
		boolean result = processDestroyed(aCtx);
		LOGGER.info(this + "processDestroyed failed in: " + asString(aCtx));
		if (!result) {
			LOGGER.info(this + "- processDestroyed, result: " + result);
			boolean result2 = findAndProcessDestroyed(aCtx);
			LOGGER.info(this + "- findAndProcessDestroyed, result: " + result2);
		}
		LOGGER.info(this + "- Servlet Context destroyed, end - event: "
				+ anEvent);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent anEvent) {
		LOGGER.info(this + "- Servlet Context created, event: " + anEvent);
		ServletContext aCtx = anEvent.getServletContext();
		LOGGER.info(this + "- Servlet Context created: " + asString(aCtx));
	}

	/**
	 * Checks for spring package.
	 *
	 * @param stringValue the string value
	 * @return true, if successful
	 */
	protected boolean hasSpringPackage(String stringValue) {
		return stringValue != null && stringValue.startsWith(SPRING_PACKAGE);
	}

	/**
	 * Process destroyed.
	 *
	 * @param aCtx the a ctx
	 * @return true, if successful
	 */
	protected boolean processDestroyed(ServletContext aCtx) {
		LOGGER.info("- Servlet Context destroyed: " + asString(aCtx));
		return processSprintRoot(aCtx);
	}

	/**
	 * Process sprint root.
	 *
	 * @param aCtx the a ctx
	 * @return true, if successful
	 */
	protected boolean processSprintRoot(ServletContext aCtx) {
		Object aRoot = aCtx.getAttribute(SPRING_ROOT_KEY);
		if (aRoot == null) {
			LOGGER.info("Null value for attribute name: " + SPRING_ROOT_KEY
					+ " in context: " + aCtx);
			return false;
		}
		else {
			try {
				XmlWebApplicationContext aCast = (XmlWebApplicationContext) aRoot;
				return closeWebApplicationContext(aCast);
			}
			catch (ClassCastException e) {
				LOGGER.info("Cast exception to XmlWebApplicationContext; "
						+ e.getMessage() + " in context: " + aCtx);
				return false;
			}
		}
	}

	/**
	 * Close web application context.
	 *
	 * @param aSpringCtx the a spring ctx
	 * @return true, if successful
	 */
	protected boolean closeWebApplicationContext(
			XmlWebApplicationContext aSpringCtx) {
		LOGGER.info("XmlWebApplicationContext context before close() "
				+ aSpringCtx);
		aSpringCtx.close();
		LOGGER.info("XmlWebApplicationContext context after close() "
				+ aSpringCtx);
		return true;
	}

	/**
	 * Find and process destroyed.
	 *
	 * @param aCtx the a ctx
	 * @return true, if successful
	 */
	protected boolean findAndProcessDestroyed(ServletContext aCtx) {
		LOGGER.info("- Servlet Context destroyed: " + asString(aCtx));
		Enumeration <?> e = aCtx.getAttributeNames();
		Object aValue;
		boolean result = false;
		while (e.hasMoreElements()) {
			String aName = (String) e.nextElement();
			aValue = aCtx.getAttribute(aName);
			result = processKeyValue(aName, aValue);
		}
		return result;
	}

	/**
	 * Process key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @return true, if successful
	 */
	protected boolean processKeyValue(String aKey, Object aValue) {
		String aStringValue = aValue.toString();
		if (hasSpringPackage(aStringValue)) {
			return processSpringKeyValue(aKey, aValue, aStringValue);
		}
		else {
			LOGGER.info("Non-Spring, key: " + aKey + " value: " + aValue);
			return false;
		}
	}

	/**
	 * Process spring app context impl1.
	 *
	 * @param key the key
	 * @param value the value
	 * @param stringValue the string value
	 * @return true, if successful
	 */
	protected boolean processSpringAppContextImpl1(String key, Object value,
			String stringValue) {
		if (stringValue.startsWith(SPRING_APP_CTX_IMPL1)) {
			cleanSpringAppContextImpl1(value);
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Process spring app context impl2.
	 *
	 * @param key the key
	 * @param value the value
	 * @param stringValue the string value
	 * @return true, if successful
	 */
	protected boolean processSpringAppContextImpl2(String key, Object value,
			String stringValue) {
		if (stringValue.startsWith(SPRING_APP_CTX_IMPL2)) {
			cleanSpringAppContextImpl2(value);
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Process spring app context interface.
	 *
	 * @param key the key
	 * @param value the value
	 * @param stringValue the string value
	 * @return true, if successful
	 */
	protected boolean processSpringAppContextInterface(String key,
			Object value, String stringValue) {
		if (stringValue.startsWith(SPRING_APP_CTX_INTERFACE)) {
			cleanSpringInterface(value);
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Process spring key value.
	 *
	 * @param key the key
	 * @param value the value
	 * @param stringValue the string value
	 * @return true, if successful
	 */
	protected boolean processSpringKeyValue(String key, Object value,
			String stringValue) {
		LOGGER.info("- Spring object: " + stringValue + " key: " + key);
		if (processSpringAppContextInterface(key, value, stringValue)) {
			return true;
		}
		if (processSpringAppContextImpl1(key, value, stringValue)) {
			return true;
		}
		if (processSpringAppContextImpl2(key, value, stringValue)) {
			return true;
		}
		else {
			return false;
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseServletContextListener.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2012/08/14 20:37:23  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.4  2011/07/29 17:26:35  mwpxp2
 *  Added close on webcontext accessible using SPRING_ROOT_KEY
 *
 *  Revision 1.3  2011/07/29 04:58:05  mwpxp2
 *  Unit tested
 *
 *  Revision 1.2  2011/07/29 04:21:52  mwpxp2
 *  Implemented guessing game
 *
 *  Revision 1.1  2011/07/29 02:33:21  mwpxp2
 *  Initial
 *
 */
