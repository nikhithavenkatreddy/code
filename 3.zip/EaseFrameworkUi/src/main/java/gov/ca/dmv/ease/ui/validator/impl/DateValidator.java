/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.Date;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: DateValidator is a custom validator which validates
 * the date fee paid (DATE MUST BE EQUAL OR PRIOR TO CURRENT DATE).
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: DateValidator.java
 * Created: Sept 23, 2010
 * 
 * @author mwrrv3
 * @version $Revision: 1.1 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DateValidator extends ValidatorBase {
	
	/** The Constant errorMessage. */
	private static final String ERROR_MESSAGE = "DATE MUST BE EQUAL OR PRIOR TO CURRENT DATE";
	
	/**
	 * Instantiates a new Date validator.
	 */
	public DateValidator() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		//DATE MUST BE EQUAL OR PRIOR TO CURRENT DATE (System Date) otherwise throw an error.
		Date dateFeePaid = (Date) value;
		Date currentDate = CurrentDateProvider.getInstance().getCurrentDate();
		if (dateFeePaid.after(currentDate)) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString(), ERROR_MESSAGE));
		}
	}
}


/**
 *  Modification History:
 * 
 *  $Log: DateValidator.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/08/14 20:41:45  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.2  2011/01/05 01:56:52  mwrrv3
 *  Replaced current date with the CurrentDateProvider class.
 *
 *  Revision 1.1  2010/09/24 00:11:13  mwrrv3
 *  Initial Commit. Added date validator for date fee paid is equal or prior to current date.
 *
 */