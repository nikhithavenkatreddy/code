/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import java.util.Iterator;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

import org.apache.commons.lang.StringUtils;

/**
 * Description: This class is the extension of @see Renderer for the InputText component. When the inputText component 
 * has an error associated, it will have its styleclass changed to an error styleclass.
 * File: InputRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: Oct 26, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InputRenderer extends Renderer {
	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws java.io.IOException {
		ResponseWriter writer = context.getResponseWriter();
		writer.startElement("label", component);
		String styleClass = (String) component.getAttributes()
				.get("styleClass");
		boolean hasErrors = hasMessages(context, component);
		if (styleClass != null) {
			if (hasErrors) {
				styleClass += " error";
			}
			writer.writeAttribute("class", styleClass, null);
		}
		else if (hasErrors) {
			writer.writeAttribute("class", "error", null);
		}
		//      String renderedId = (input != null) ? input.getClientId(context) : component.getClientId(context);
		//      writer.writeAttribute("for", renderedId, null);
		//      writer.write(attrs.get("value").toString());
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void encodeEnd(FacesContext context, UIComponent component)
			throws java.io.IOException {
		ResponseWriter writer = context.getResponseWriter();
		Map <String, Object> attrs = component.getAttributes();
		String labelId = (String) attrs.get("for");
		UIInput input = null;
		if (!StringUtils.isEmpty(labelId)) {
			input = (UIInput) component.findComponent(labelId);
		}
		if ((input != null) && input.isRequired()) {
			writer.write("<span class=\"req\">*</span>");
		}
		writer.endElement("label");
	}

	/**
	 * Checks for messages.
	 * 
	 * @param context the context
	 * @param component the component
	 * 
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	private boolean hasMessages(FacesContext context, UIComponent component) {
		Iterator <String> clientIds = context.getClientIdsWithMessages();
		boolean found = false;
		while (clientIds.hasNext()) {
			String clientId = clientIds.next();
			if ((component != null)
					&& clientId.equals(component.getClientId(context))) {
				found = true;
				break;
			}
		}
		return found;
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	/**
	 * Checks if is renders children.
	 * 
	 * @return true, if is renders children
	 */
	public boolean isRendersChildren() {
		return false;
	}
}
/**
 *  Modification History:
 *
 *  $Log: InputRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
