/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;

import java.io.IOException;
import java.util.Iterator;

import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

/**
 * Description: This class contains the HTML Renderer realted utility methods.
 * File: HtmlRendererUtils.java
 * Module:  gov.ca.dmv.ease.ui.util.impl
 * Created: Sep 17, 2009 
 * @author MWBVC
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlRendererUtils {
	/** The Constant LINE_SEPARATOR. */
	private static final String LINE_SEPARATOR = "\n";

	/**
	 * This method checks the param validity.
	 * 
	 * @param facesContext the faces context
	 * @param uiComponent the ui component
	 * @param compClass the comp class
	 */
	public static void checkParamValidity(FacesContext facesContext,
			UIComponent uiComponent, Class <?> compClass) {
		if (facesContext == null) {
			throw new NullPointerException("facesContext may not be null");
		}
		if (uiComponent == null) {
			throw new NullPointerException("uiComponent may not be null");
		}
		if (compClass != null && !(compClass.isInstance(uiComponent))) {
			throw new IllegalArgumentException("uiComponent : "
					+ " is not instance of " + compClass.getName()
					+ " as it should be");
		}
	}

	/**
	 * This method checks if the given value is default attribute value or not
	 * 
	 * @param value the value
	 * 
	 * @return boolean
	 */
	public static boolean isDefaultAttributeValue(Object value) {
		if (value == null) {
			return true;
		}
		else if (value instanceof Boolean) {
			return !((Boolean) value).booleanValue();
		}
		else if (value instanceof Number) {
			if (value instanceof Integer) {
				return ((Number) value).intValue() == Integer.MIN_VALUE;
			}
			else if (value instanceof Double) {
				return ((Number) value).doubleValue() == Double.MIN_VALUE;
			}
			else if (value instanceof Long) {
				return ((Number) value).longValue() == Long.MIN_VALUE;
			}
			else if (value instanceof Byte) {
				return ((Number) value).byteValue() == Byte.MIN_VALUE;
			}
			else if (value instanceof Float) {
				return ((Number) value).floatValue() == Float.MIN_VALUE;
			}
			else if (value instanceof Short) {
				return ((Number) value).shortValue() == Short.MIN_VALUE;
			}
		}
		return false;
	}

	/**
	 * This method will take care of rendering the child.
	 * 
	 * @param facesContext the faces context
	 * @param child the child
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void renderChild(FacesContext facesContext, UIComponent child)
			throws IOException {
		if (!child.isRendered()) {
			return;
		}
		child.encodeBegin(facesContext);
		if (child.getRendersChildren()) {
			child.encodeChildren(facesContext);
		}
		else {
			renderChildren(facesContext, child);
		}
		child.encodeEnd(facesContext);
	}

	/**
	 * This method will take care of rendering its children.
	 * 
	 * @param facesContext the faces context
	 * @param component the component
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings({ "rawtypes" })
	public static void renderChildren(FacesContext facesContext,
			UIComponent component) throws IOException {
		if (component.getChildCount() > 0) {
			for (Iterator it = component.getChildren().iterator(); it.hasNext();) {
				UIComponent child = (UIComponent) it.next();
				renderChild(facesContext, child);
			}
		}
	}

	/**
	 * This method renders HTML attribute.
	 * 
	 * @param writer the writer
	 * @param componentProperty the component property
	 * @param attrName the attr name
	 * @param value the value
	 * 
	 * @return true, if the attribute was written
	 * 
	 * @throws java.io.IOException 	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static boolean renderHtmlAttribute(ResponseWriter writer,
			String componentProperty, String attrName, Object value)
			throws IOException {
		if (!isDefaultAttributeValue(value)) {
			// render JSF "styleClass" and "itemStyleClass" attributes as "class"
			String htmlAttrName = attrName
					.equals(JsfHtmlAttributes.STYLE_CLASS_ATTR) ? JsfHtmlAttributes.CLASS_ATTR
					: attrName;
			writer.writeAttribute(htmlAttrName, value, componentProperty);
			return true;
		}
		return false;
	}

	/**
	 * This method renders HTML attribute.
	 * 
	 * @param writer the writer
	 * @param component the component
	 * @param componentProperty the component property
	 * @param htmlAttrName the html attr name
	 * 
	 * @return true, if the attribute was written
	 * 
	 * @throws java.io.IOException 	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static boolean renderHtmlAttribute(ResponseWriter writer,
			UIComponent component, String componentProperty, String htmlAttrName)
			throws IOException {
		Object value = component.getAttributes().get(componentProperty);
		return renderHtmlAttribute(writer, componentProperty, htmlAttrName,
				value);
	}

	/**
	 * This method Renders HTML attributes.
	 * 
	 * @param writer the writer
	 * @param component the component
	 * @param attributes the attributes
	 * 
	 * @return true, if an attribute was written
	 * 
	 * @throws java.io.IOException 	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static boolean renderHtmlAttributes(ResponseWriter writer,
			UIComponent component, String[] attributes) throws IOException {
		boolean somethingDone = false;
		for (String attrName : attributes) {
			if (renderHtmlAttribute(writer, component, attrName, attrName)) {
				somethingDone = true;
			}
		}
		return somethingDone;
	}

	/**
	 * This method writes the attribute to the component if necessary.
	 * 
	 * @param writer the writer
	 * @param component the component
	 * @param facesContext the faces context
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void writeIdIfNecessary(ResponseWriter writer,
			UIComponent component, FacesContext facesContext)
			throws IOException {
		if (component.getId() != null
				&& !component.getId().startsWith(UIViewRoot.UNIQUE_ID_PREFIX)) {
			writer.writeAttribute(JsfHtmlAttributes.ID_ATTR,
					component.getClientId(facesContext), null);
		}
	}

	/**
	 * This method writes pretty line separator.
	 * 
	 * @param facesContext the faces context
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void writePrettyLineSeparator(FacesContext facesContext)
			throws IOException {
		facesContext.getResponseWriter().write(LINE_SEPARATOR);
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlRendererUtils.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/08/25 18:17:51  mwpxp2
 *  Fixed suppression of warnings frfom unchecked to rawtypes were applicable
 *
 *  Revision 1.2  2010/03/23 00:06:13  mwpxp2
 *  Fixed file footer
 *
 */
