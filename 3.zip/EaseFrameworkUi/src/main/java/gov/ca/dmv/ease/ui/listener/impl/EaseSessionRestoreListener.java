/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.session.factory.impl.SessionServiceRequestFactory;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest;
import gov.ca.dmv.ease.app.session.response.impl.RetrieveSessionResponse;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Description: The purpose of this class is to restore the session.
 * File: EaseSessionRestoreListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: May 5, 2010 
 * @author MWVKM  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/19 21:09:26 $
 * Last Changed By: $Author: mwhys $
 */
public class EaseSessionRestoreListener implements PhaseListener {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7114768666166932115L;
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(EaseSessionRestoreListener.class);
	
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		if (Activity.isSessionManagementEnabled()) {
			FacesContext facesContext = phaseEvent.getFacesContext();
			ServletContext servletContext = (ServletContext) facesContext
					.getExternalContext().getContext();
			ApplicationContext applicationContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(servletContext);
			SessionData sessionDataBean = (SessionData) EaseProxyUtils
					.getProxyObject(applicationContext.getBean("sessionData"));
			if ((!sessionDataBean.hasRequiredData())
					&& sessionDataBean.isSessionTimeout()) {
				sessionDataBean.setSessionTimeout(false);
				//check for stored session
				UserContext userContextBean = (UserContext) EaseProxyUtils
						.getProxyObject(applicationContext
								.getBean("userContext"));
				RetrieveSessionRequest fetchRequest = SessionServiceRequestFactory
						.getInstance().createRetrieveSessionRequest(
								userContextBean);
				RetrieveSessionResponse fetchResponse = (RetrieveSessionResponse) fetchRequest
						.execute();
				if (!fetchResponse.hasErrors()) {
					LOGGER
							.info("User '"
									+ userContextBean.getUserName()
									+ "' has been redirected to the Session Timeout page!");
					UIViewRoot viewRoot = facesContext.getApplication()
							.getViewHandler().createView(facesContext,
									"/tabs/sessionTimeout.jsf");
					facesContext.setViewRoot(viewRoot);
					facesContext.renderResponse();
				}
				else {
					LOGGER
							.info("User '"
									+ userContextBean.getUserName()
									+ "' has been redirected to the Mode Selection page!");
					UIViewRoot viewRoot = facesContext.getApplication()
							.getViewHandler().createView(facesContext,
									"/common/modeSelection.jsf");
					facesContext.setViewRoot(viewRoot);
					facesContext.renderResponse();
				}
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 */
	public PhaseId getPhaseId() {
		return PhaseId.RESTORE_VIEW;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseSessionRestoreListener.java,v $
 *  Revision 1.2  2012/10/19 21:09:26  mwhys
 *  Refactored to use method instead of field. (Session Management)
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.18  2012/05/10 21:03:54  mwhys
 *  Added a boolean flag to turn on/off session management.
 *
 *  Revision 1.17  2011/06/09 20:04:54  mwyxg1
 *  clean up
 *
 *  Revision 1.16  2011/03/07 18:54:31  mwkfh
 *  redirect to modeSelection if no save session - defect 4627
 *
 *  Revision 1.15  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 *  Revision 1.14  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.13  2010/08/11 23:55:16  mwkfh
 *  updated sessionData methods
 *
 *  Revision 1.12  2010/08/02 21:28:17  mwkfh
 *  updated the log output
 *
 *  Revision 1.11  2010/07/30 22:07:56  mwkfh
 *  refactored and merge session store and restore
 *
 *  Revision 1.10  2010/07/29 17:55:20  mwkfh
 *  updated session timeout redirection check
 *
 *  Revision 1.9  2010/07/28 21:02:31  mwskd2
 *  restore session logic is moved to EaseSessionExpirePage
 *
 *  Revision 1.8  2010/07/27 18:01:05  mwkfh
 *  updated and moved session services
 *
 *  Revision 1.7  2010/07/16 15:32:40  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.4.2.2  2010/07/12 21:26:57  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.4.2.1  2010/06/28 23:27:52  mwvkm
 *  A bug with session restore is fixed.
 *
 *  Revision 1.4  2010/05/18 23:08:45  mwvkm
 *  Changes/Updates are made for Session Restore functionality POC.
 *
 *  Revision 1.3  2010/05/14 23:53:54  mwkkc
 *  Session Management - logger fix
 *
 *  Revision 1.2  2010/05/05 20:00:56  mwvkm
 *  A bug is fixed in Session restore functionality.
 *
 *  Revision 1.1  2010/05/05 18:15:25  mwvkm
 *  Session re-store listener for faces life cycle
 *
 */
