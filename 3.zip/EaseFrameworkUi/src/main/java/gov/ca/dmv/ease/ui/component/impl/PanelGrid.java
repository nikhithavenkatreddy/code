/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;

/**
 * Description: I am this and that File: PanelGrid.java
 * Module: gov.ca.dmv.ease.ui.component.impl.panel 
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/17 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class PanelGrid extends HtmlPanelGrid {
	/** The Constant COMPONENT_FAMILY. */
	public static final String COMPONENT_FAMILY = "javax.faces.Panel";
	//PanelGrid properties
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.PanelGrid";
	/** The Constant DEFAULT_RENDERER_TYPE. */
	public static final String DEFAULT_RENDERER_TYPE = "gov.ca.dmv.ease.PanelGridRenderer";

	/**
	 * Constructor.
	 */
	public PanelGrid() {
		super();
		setRendererType(DEFAULT_RENDERER_TYPE);
	}

	/**
	 * Gets the clientId of a component.
	 * 
	 * @param facesContext the faces context
	 * 
	 * @return the client id
	 */
	@Override
	public String getClientId(FacesContext facesContext) {
		String clientId = FacesUtils.getClientId(this,
				getRenderer(facesContext), facesContext);
		if (clientId == null) {
			clientId = super.getClientId(facesContext);
		}
		return clientId;
	}

	/**
	 * Checks whether the component has o be rendered or not
	 * based on the value specified when component is defined in JSF page.
	 * 
	 * @return true/false
	 */
	@Override
	public boolean isRendered() {
		return super.isRendered();
	}

	/**
	 * Restores the component State.
	 * 
	 * @param facesContext the faces context
	 * @param state of PanelGrid
	 */
	@Override
	public void restoreState(FacesContext facesContext, Object state) {
		Object values[] = (Object[]) state;
		super.restoreState(facesContext, values[0]);
	}

	/**
	 * Saves the PanelGrid component State with the attribute values.
	 * 
	 * @param facesContext the faces context
	 * 
	 * @return Object of type PanelGrid
	 */
	@Override
	public Object saveState(FacesContext facesContext) {
		Object values[] = new Object[1];
		values[0] = super.saveState(facesContext);
		return ((values));
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGrid.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
