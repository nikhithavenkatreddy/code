/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import static gov.ca.dmv.ease.ui.component.impl.PanelGroup.DEFAULT_COLSPAN;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.CLASS_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.COLSPAN_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.ID_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.INPUT_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.INPUT_TYPE_HIDDEN;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.LI_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.NAME_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.OL_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TABLE_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TBODY_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TD_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TR_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TYPE_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.VALUE_ATTR;
import gov.ca.dmv.ease.ui.component.impl.PanelGroup;
import gov.ca.dmv.ease.ui.constants.PageConstants;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlMessages;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

/**
 * Description: This is a JSF renderer for panel grid and this is also used for 
 * rendering UI and BR error messages in the table format at the bottom of screen.
 * File: PanelGridRenderer.java
 * Module: gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/17 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class PanelGridRenderer extends AbstractPanelGridRenderer implements
		PageConstants {
	
	/** Constant for PANEL_GRID_MESSAGES - error messages. */
	private static final String PANEL_GRID_MESSAGES = "panelGrid_messages";
	
	/** The Constant WORK_DATE_NOT_CURRENT. */
	private static final String WORK_DATE_NOT_CURRENT = "0306";
	
	/** The Constant WORK_DATE_EMPTY. */
	private static final String WORK_DATE_EMPTY = "0307";

	/**
	 * Add attributes to the table cell <td> tag.
	 *
	 * @param facesContext the faces context
	 * @param writer the writer
	 * @param component the component
	 * @param columnIndex the column index
	 * @return columnIndex
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	protected int childAttributes(FacesContext facesContext,
			ResponseWriter writer, UIComponent component, int columnIndex)
			throws IOException {
		if (component instanceof PanelGroup
				&& ((PanelGroup) component).getColspan() != DEFAULT_COLSPAN) {
			int colspan = ((PanelGroup) component).getColspan();
			writer.writeAttribute(COLSPAN_ATTR, String.valueOf(colspan), null);
			columnIndex += (colspan - 1);
		}
		return columnIndex;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.renderer.impl.AbstractPanelGridRenderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void encodeEnd(FacesContext facesContext, UIComponent component)
			throws IOException {
		String clientId = component.getClientId(facesContext);
		String layout = (String) component.getAttributes().get("layout");
		List <UIComponent> childrenList = component.getChildren();
		for (UIComponent uiComponent : childrenList) {
			if (uiComponent instanceof HtmlMessages) {
				layout = ((HtmlMessages) uiComponent).getLayout();
			}
		}
		ResponseWriter writer = facesContext.getResponseWriter();
		if (clientId.equalsIgnoreCase(PANEL_GRID_MESSAGES)
				&& TABLE_ELEM.equalsIgnoreCase(layout)) {
			writeTheMessages(facesContext, component, writer, layout);
		}
		else if (clientId.equalsIgnoreCase(PANEL_GRID_MESSAGES)
				&& layout.equalsIgnoreCase(layout)) {
			writeTheMessages(facesContext, component, writer, layout);
		}
		else {
			super.encodeEnd(facesContext, component);
		}
	}

	/**
	 * Write the messages.
	 *
	 * @param facesContext the faces context
	 * @param component the component
	 * @param writer the writer
	 * @param layout the layout
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void writeTheMessages(FacesContext facesContext,
			UIComponent component, ResponseWriter writer, String layout)
			throws IOException {
		if (TABLE_ELEM.equalsIgnoreCase(layout)) {
			writer.startElement(TABLE_ELEM, component);
		}
		else {
			writer.write("<" + OL_ELEM + " class='errorMessagesOl'>");
		}
		writer.flush();
		if (TABLE_ELEM.equalsIgnoreCase(layout)) {
			writer.startElement(TBODY_ELEM, component);
		}
		StringBuilder fieldValue = new StringBuilder("");
		boolean hasBrErrors = false;
		for (Iterator <?> iterator = facesContext.getMessages(); iterator
				.hasNext();) {
			FacesMessage facesMessage = (FacesMessage) iterator.next();
			String message = facesMessage.getSummary();
			if (message != null
					&& (message.endsWith(UI_ERROR_MSG_IND) || message
							.endsWith(BR_ERROR_MSG_IND))) {
				//Skip if the message has 0577 because backing bean (ModeSelectionPage) 
				//will take care of display.
				if (message.startsWith(WORK_DATE_NOT_CURRENT)
						|| message.startsWith(WORK_DATE_EMPTY)) {
					continue;
				}
				if (!"".equals(facesMessage.getDetail())) {
					fieldValue.append(facesMessage.getDetail()).append(",");
				}
				if (TABLE_ELEM.equalsIgnoreCase(layout)) {
					writer.startElement(TR_ELEM, component);
					writer.startElement(TD_ELEM, component);
				}
				else {
					writer.startElement(LI_ELEM, component);
				}
				// If the message is UI (Screen field) error message then
				// display as red font.
				if (message.endsWith(UI_ERROR_MSG_IND)) {
					message = message.replace(UI_ERROR_MSG_IND, "");
					writer.writeAttribute(CLASS_ATTR, UI_STYLE_CLS, null);
				}
				else if (message.endsWith(BR_ERROR_MSG_IND)) {
					hasBrErrors = true;
					message = message.replace(BR_ERROR_MSG_IND, "");
					writer.writeAttribute(CLASS_ATTR, BR_STYLE_CLS, null);
				}
				writer.write(message);
				if (TABLE_ELEM.equalsIgnoreCase(layout)) {
					writer.endElement(TD_ELEM);
					writer.endElement(TR_ELEM);
					writer.startElement(OL_ELEM, component);
				}
				else {
					writer.endElement(LI_ELEM);
				}
			}
		}
		//If the system has Business Rules with error field then create a hidden field for the focus element(s).
		generateBusinessRuleErrorFields(component, writer, layout, fieldValue,
				hasBrErrors);
		if (TABLE_ELEM.equalsIgnoreCase(layout)) {
			writer.endElement(TBODY_ELEM);
			writer.endElement(TABLE_ELEM);
		}
		else {
			writer.endElement(OL_ELEM);
		}
	}

	/**
	 * Generate business rule error fields.
	 *
	 * @param component the component
	 * @param writer the writer
	 * @param layout the layout
	 * @param fieldValue the field value
	 * @param hasBrErrors the has br errors
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void generateBusinessRuleErrorFields(UIComponent component,
			ResponseWriter writer, String layout, StringBuilder fieldValue,
			boolean hasBrErrors) throws IOException {
		if (hasBrErrors && fieldValue != null
				&& fieldValue.toString().length() > 1) {
			if (TABLE_ELEM.equalsIgnoreCase(layout)) {
				writer.startElement(TR_ELEM, component);
				writer.startElement(TD_ELEM, component);
			}
			else {
				writer.startElement(LI_ELEM, component);
			}
			if (hasBrErrors) {
				writer.startElement(INPUT_ELEM, component);
				writer.writeAttribute(TYPE_ATTR, INPUT_TYPE_HIDDEN, null);
				writer.writeAttribute(NAME_ATTR, BR_ERROR_FIELD, null);
				writer.writeAttribute(ID_ATTR, BR_ERROR_FIELD, null);
				String errorFields = fieldValue.toString();
				if (fieldValue.length() > 0) {
					errorFields = fieldValue.toString().substring(0,
							fieldValue.toString().length() - 1);
				}
				writer.writeAttribute(VALUE_ATTR, errorFields, null);
				writer.endElement(INPUT_ELEM);
			}
			if (TABLE_ELEM.equalsIgnoreCase(layout)) {
				writer.endElement(TD_ELEM);
				writer.endElement(TR_ELEM);
			}
			else {
				writer.endElement(LI_ELEM);
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGridRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.17  2012/08/29 00:14:59  mwrrv3
 *  Updated encodeEnd().
 *
 *  Revision 1.16  2012/08/18 00:49:51  mwrrv3
 *  Code clean up and fixed PMD issues.
 *
 *  Revision 1.15  2012/03/10 05:43:36  mwsxv5
 *  Work date informational and error message changes.
 *
 *  Revision 1.14  2011/09/01 23:30:53  mwnrk
 *  Updated to support ADA.
 *
 *  Revision 1.13  2011/08/30 22:34:16  mwrrv3
 *  Refactored and updated the StringUtil references.
 *
 *  Revision 1.12  2011/08/26 22:36:32  mwnrk
 *  Update to support ADA.
 *
 *  Revision 1.1  2011/07/05 17:25:16  mwrrv3
 *  Moved from EaseFramework project.
 *
 *  Revision 1.11  2011/01/29 03:53:24  mwrrv3
 *  Added condition for the business rule focus value.
 *
 *  Revision 1.10  2011/01/27 19:16:49  mwrka1
 *  Undo the changes. -Raghava
 *
 *  Revision 1.9  2011/01/27 08:54:02  mwrrv3
 *  Added empty string check for field value.
 *
 *  Revision 1.8  2010/12/04 19:27:29  mwrrv3
 *  Added condition for focus field length.
 *
 *  Revision 1.7  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.6  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/06/21 23:00:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.3.10.2  2010/06/20 18:06:57  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.4  2010/06/08 17:18:31  mwrrv3
 *  Modified the code to support UI and BR error messages.
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
