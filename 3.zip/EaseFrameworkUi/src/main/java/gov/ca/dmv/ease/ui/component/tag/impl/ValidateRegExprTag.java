/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.validator.impl.EaseRegExprValidator;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.validator.Validator;
import javax.faces.webapp.UIComponentTag;
import javax.faces.webapp.ValidatorTag;
import javax.servlet.jsp.JspException;

/**
 * Description: //TODO - provide description!
 * File: ValidateRegExprTag.java
 * Module:  gov.ca.dmv.ease.ui.component.tag.impl
 * Created: 2009
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ValidateRegExprTag extends ValidatorTag {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -449945949876262076L;
	/** The regex. */
	private String regex = null;

	/**
	 * Instantiates a new validate reg expr tag.
	 */
	public ValidateRegExprTag() {
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.ValidatorTag#createValidator()
	 */
	@Override
	protected Validator createValidator() throws JspException {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		setValidatorId(EaseRegExprValidator.VALIDATOR_ID);
		EaseRegExprValidator validator = (EaseRegExprValidator) super
				.createValidator();
		if (regex != null) {
			if (UIComponentTag.isValueReference(regex)) {
				ValueBinding vb = facesContext.getApplication()
						.createValueBinding(regex);
				validator.setRegex(new String(vb.getValue(facesContext)
						.toString()));
			}
			else {
				validator.setRegex(regex);
			}
		}
		return validator;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.ValidatorTag#release()
	 */
	@Override
	public void release() {
		super.release();
		regex = null;
	}

	/**
	 * Sets the regex.
	 * 
	 * @param regex the new regex
	 */
	public void setRegex(String regex) {
		this.regex = regex;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValidateRegExprTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:55:49  mwpxp2
 *  Fixed class decorations, javadoc
 *
 */
