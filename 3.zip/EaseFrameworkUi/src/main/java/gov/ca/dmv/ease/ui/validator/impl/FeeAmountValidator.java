/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.math.BigDecimal;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: FeeAmountValidator.java is a custom validator which validates
 * the fee due value.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: WeightValidator.java 
 * Created: Nov 15, 2010
 * @author 
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FeeAmountValidator extends ValidatorBase {
	private static final String CONVERSION_ERROR_MESSAGE = "INVALID CHARACTER IN ALPHA NUMERIC FIELD";
	private static final String ERROR_DATA_RANGE_MESSAGE = "DATA NOT WITHIN SPECIFIED RANGE";
	private static final String ERROR_DATA_REQUIRED_FORMAT = "DATA NOT WITHIN REQUIRED FORMAT";
	private static final String ERROR_MESSAGE = "FIELD MAY ONLY CONTAIN NUMBERS";
	/** The Constant PATTERN. */
	private static final String SEVEN_DIGITS_TWO_DECIMALS_PATTERN = "\\d{0,7}\\.{0,1}\\d{0,2}";
	/** Pre-compiled Pattern object. */
	private static final Pattern SEVEN_DIGITS_TWO_DECIMALS = Pattern
			.compile(SEVEN_DIGITS_TWO_DECIMALS_PATTERN);

	/**
	 * Instantiates a new FeeAmount validator.
	 */
	public FeeAmountValidator() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		String valueString = null;
		if (value == null) {
			return;
		}
		if (value instanceof BigDecimal) {
			valueString = ((BigDecimal) value).toString();
		}
		if (value instanceof String) {
			valueString = (String) value;
		}
		//Convert String to BigDecimal and if the value is less than 0.01 or greater than 9999999.99 then throw an error.
		try {
			if (valueString.contains("$")
					|| (new BigDecimal(valueString).compareTo(new BigDecimal(
							0.00)) == -1)) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_MESSAGE));
			}
			if (((new BigDecimal(valueString)).compareTo(new BigDecimal(
					9999999.99)) == 1)) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_DATA_RANGE_MESSAGE));
			}
			if (!(SEVEN_DIGITS_TWO_DECIMALS.matcher(valueString).matches())) {
				throw new ValidatorException(FacesUtils.createErrorMessage(
						valueString, ERROR_DATA_REQUIRED_FORMAT));
			}
		}
		catch (NumberFormatException e) {
			throw new ValidatorException(FacesUtils.createErrorMessage(
					valueString, CONVERSION_ERROR_MESSAGE));
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: FeeAmountValidator.java,v $
 * Revision 1.1  2012/10/01 02:58:06  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.13  2012/01/19 17:20:04  mwlcr1
 * *** empty log message ***
 *
 * Revision 1.12  2012/01/19 16:24:54  mwlcr1
 * *** empty log message ***
 *
 * Revision 1.11  2011/03/15 02:50:29  mwrrv3
 * Fixed the validator issue for maximum amount allowed in cash, check and manual credit fields.
 *
 * Revision 1.10  2011/03/07 19:35:02  mwark
 * Fixed the TODO comments and fixed the logic.
 *
 * Revision 1.9  2011/03/04 18:36:55  mwpxp2
 * Externalized regex pattern into a static; added missing javadoc; added todos for static naming and handling of regex
 *
 * Revision 1.8  2011/02/28 17:48:48  mwark
 * Included a condition for MiscellaneousVariedFeeCollections page for the fee amount (5,2).
 *
 * Revision 1.7  2011/01/16 02:33:41  mwrrv3
 * Removed error code for DATA NOT WITHIN REQUIRED FORMAT message.
 *
 * Revision 1.6  2010/12/29 19:21:36  mwrrv3
 * Defect fix # 2604 -- Amar Kathi
 *
 * Revision 1.5  2010/12/28 19:37:42  mwsxv5
 * Updated teh validate method to validate different scenarios to display related error messages.
 *
 * Revision 1.4  2010/12/28 17:20:03  mwsxv5
 * Updated teh validate method to validate different scenarios to display related error messages.
 *
 * Revision 1.3  2010/12/23 06:10:39  mwkkc
 * Merged Production code from Branch
 *
 * Revision 1.1.2.3  2010/12/23 01:29:48  mwkkc
 * Rebase from head - Arch
 *
 * Revision 1.2  2010/12/21 19:21:45  mwgxk2
 * Defect ID : 2387 2C - EnterPayment. All money fields - error messages not as expected.
 *
 * Revision 1.1  2010/12/03 23:42:50  mwrrv3
 * Defect # 2831 Fix, Added FeeAmountValidator to get the correct error message when we enter special characters. -- Amar Bade
 *
 *  
 */
