/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.ui.component.impl.PanelGrid;
import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;
import gov.ca.dmv.ease.ui.util.impl.HtmlRendererUtils;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.UIPanel;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

/**
 * Description: Default Renderer for custom component PanelGrid.
 * This is the super class for EasePanelGridRenderer.
 * Module: gov.ca.dmv.ease.ui.component.impl.panel 
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/17 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class AbstractPanelGridRenderer extends Renderer {
	/**
	 * subclasses can override this method to add attributes to the table cell <td> tag
	 * @param facesContext
	 * @param writer
	 * @param component
	 * @param columnIndex
	 * @return columnIndex
	 * @throws IOException
	 */
	protected int childAttributes(FacesContext facesContext,
			ResponseWriter writer, UIComponent component, int columnIndex)
			throws IOException {
		return columnIndex;
	}

	/**
	 * Starts encoding the JSF PanelGrid component into browser understandable (html) tag. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeBegin(FacesContext facesContext, UIComponent component)
			throws IOException {
	}

	/**
	 * Starts encoding the JSF PanelGrid child components into browser understandable (html) tag. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeChildren(FacesContext context, UIComponent component)
			throws IOException {
	}

	/**
	 * writes the closing tag for JSF PanelGrid component. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeEnd(FacesContext facesContext, UIComponent component)
			throws IOException {
		HtmlRendererUtils.checkParamValidity(facesContext, component,
				UIPanel.class);
		int columns;
		if (component instanceof PanelGrid) {
			columns = ((PanelGrid) component).getColumns();
		}
		else {
			Integer cols = (Integer) component.getAttributes().get(
					JsfHtmlAttributes.COLUMNS_ATTR);
			columns = cols != null ? cols.intValue() : 0;
		}
		if (columns <= 0) {
			columns = 1;
		}
		ResponseWriter writer = facesContext.getResponseWriter();
		writer.startElement(JsfHtmlAttributes.TABLE_ELEM, component);
		HtmlRendererUtils.writeIdIfNecessary(writer, component, facesContext);
		HtmlRendererUtils.renderHtmlAttributes(writer, component,
				JsfHtmlAttributes.TABLE_PASSTHROUGH_ATTRIBUTES);
		writer.flush();
		// theader and tfooter are rendered before the tbody 
		renderHeaderOrFooter(facesContext, writer, component, columns, true); //Header facet
		renderHeaderOrFooter(facesContext, writer, component, columns, false); //Footer facet
		renderChildren(facesContext, writer, component, columns);
		writer.endElement(JsfHtmlAttributes.TABLE_ELEM);
	}

	/**
	 * Gets the child count for a given component
	 * @param component
	 * @return child count of a component
	 */
	public int getChildCount(UIComponent component) {
		return component.getChildCount();
	}

	/**
	 * Gets the children list for a given component
	 * @param component
	 * @return list of children of a component
	 */
	public List getChildren(UIComponent component) {
		return component.getChildren();
	}

	/**
	 * Are panelGrid children has to be rendered?
	 * @return boolean
	 */
	@Override
	public boolean getRendersChildren() {
		return true;
	}

	/**
	 * renders the children of table <table> tag.
	 * @param context
	 * @param writer
	 * @param component
	 * @param columns
	 * @throws IOException
	 */
	protected void renderChildren(FacesContext context, ResponseWriter writer,
			UIComponent component, int columns) throws IOException {
		writer.startElement(JsfHtmlAttributes.TBODY_ELEM, component);
		String columnClasses;
		String rowClasses;
		if (component instanceof PanelGrid) {
			columnClasses = ((PanelGrid) component).getColumnClasses();
			rowClasses = ((PanelGrid) component).getRowClasses();
		}
		else {
			columnClasses = (String) component.getAttributes().get(
					JsfHtmlAttributes.COLUMN_CLASSES_ATTR);
			rowClasses = (String) component.getAttributes().get(
					JsfHtmlAttributes.ROW_CLASSES_ATTR);
		}
		String[] columnClassesArray = (columnClasses == null) ? ArrayUtils.EMPTY_STRING_ARRAY
				: ArrayUtils.trim(ArrayUtils.splitShortString(columnClasses,
						','));
		int columnClassesCount = columnClassesArray.length;
		String[] rowClassesArray = (rowClasses == null) ? ArrayUtils.EMPTY_STRING_ARRAY
				: ArrayUtils.trim(ArrayUtils.splitShortString(rowClasses, ','));
		int rowClassesCount = rowClassesArray.length;
		int childCount = getChildCount(component);
		if (childCount > 0) {
			int columnIndex = 0;
			int rowClassIndex = 0;
			boolean rowStarted = false;
			for (Iterator it = getChildren(component).iterator(); it.hasNext();) {
				UIComponent child = (UIComponent) it.next();
				if (child.isRendered()) {
					if (columnIndex == 0) {
						//start of new/next row
						if (rowStarted) {
							//do we have to close the last row?
							writer.endElement(JsfHtmlAttributes.TR_ELEM);
							HtmlRendererUtils.writePrettyLineSeparator(context);
						}
						writer.startElement(JsfHtmlAttributes.TR_ELEM,
								component);
						if (rowClassIndex < rowClassesCount) {
							writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR,
									rowClassesArray[rowClassIndex], null);
						}
						rowStarted = true;
						rowClassIndex++;
						if (rowClassIndex == rowClassesCount) {
							rowClassIndex = 0;
						}
					}
					writer.startElement(JsfHtmlAttributes.TD_ELEM, component);
					if (columnIndex < columnClassesCount) {
						writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR,
								columnClassesArray[columnIndex], null);
					}
					columnIndex = childAttributes(context, writer, child,
							columnIndex);
					HtmlRendererUtils.renderChild(context, child);
					writer.endElement(JsfHtmlAttributes.TD_ELEM);
					columnIndex++;
					if (columnIndex >= columns) {
						columnIndex = 0;
					}
				}
			}
			if (rowStarted) {
				if (columnIndex > 0) {
					//Render empty columns, so that table is correct
					for (; columnIndex < columns; columnIndex++) {
						writer.startElement(JsfHtmlAttributes.TD_ELEM,
								component);
						if (columnIndex < columnClassesCount) {
							writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR,
									columnClassesArray[columnIndex], null);
						}
						writer.endElement(JsfHtmlAttributes.TD_ELEM);
					}
				}
				writer.endElement(JsfHtmlAttributes.TR_ELEM);
				HtmlRendererUtils.writePrettyLineSeparator(context);
			}
		}
		writer.endElement(JsfHtmlAttributes.TBODY_ELEM);
	}

	/**
	 * writes the header or footer sub tags for JSF PanelGrid component. 
	 * @param facesContext
	 * @param writer response writer
	 * @param component an UiComponent
	 * @param columns number of columns of table
	 * @param header boolean whether header or footer
	 * @throws IOException
	 */
	protected void renderHeaderOrFooter(FacesContext facesContext,
			ResponseWriter writer, UIComponent component, int columns,
			boolean header) throws IOException {
		UIComponent facet = component.getFacet(header ? "header" : "footer");
		if (facet == null) {
			return;
		}
		HtmlRendererUtils.writePrettyLineSeparator(facesContext);
		writer.startElement(header ? JsfHtmlAttributes.THEAD_ELEM
				: JsfHtmlAttributes.TFOOT_ELEM, component);
		writer.startElement(JsfHtmlAttributes.TR_ELEM, component);
		writer.startElement(header ? JsfHtmlAttributes.TH_ELEM
				: JsfHtmlAttributes.TD_ELEM, component);
		String styleClass = (component instanceof PanelGrid) ? (header ? ((PanelGrid) component)
				.getHeaderClass()
				: ((PanelGrid) component).getFooterClass())
				: (header ? (String) component.getAttributes().get(
						JsfHtmlAttributes.HEADER_CLASS_ATTR)
						: (String) component.getAttributes().get(
								JsfHtmlAttributes.FOOTER_CLASS_ATTR));
		if (styleClass != null) {
			writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR, styleClass,
					header ? JsfHtmlAttributes.HEADER_CLASS_ATTR
							: JsfHtmlAttributes.FOOTER_CLASS_ATTR);
		}
		if (header) {
			writer.writeAttribute(JsfHtmlAttributes.SCOPE_ATTR,
					JsfHtmlAttributes.SCOPE_COLGROUP_VALUE, null);
		}
		writer.writeAttribute(JsfHtmlAttributes.COLSPAN_ATTR, Integer
				.toString(columns), null);
		HtmlRendererUtils.writePrettyLineSeparator(facesContext);
		HtmlRendererUtils.renderChild(facesContext, facet);
		HtmlRendererUtils.writePrettyLineSeparator(facesContext);
		writer.endElement(header ? JsfHtmlAttributes.TH_ELEM
				: JsfHtmlAttributes.TD_ELEM);
		writer.endElement(JsfHtmlAttributes.TR_ELEM);
		writer.endElement(header ? JsfHtmlAttributes.THEAD_ELEM
				: JsfHtmlAttributes.TFOOT_ELEM);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractPanelGridRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/10 23:13:14  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
