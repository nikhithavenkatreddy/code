package gov.ca.dmv.ease.ui.page;

/**
 * Description: //TODO - provide description!
 * File: DcsBasePage.java
 * Module:  gov.ca.dmv.ease.ui.page.datacommunicationsystem
 * Created: Sep 3, 2009 
 * @author MWSV5  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Acceptance extends BasePage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7783108051322409308L;

	/**
	 * Gets the court inquiry ttc.
	 * 
	 * @return the court inquiry ttc
	 */
	public String getCourtInquiryTtc() {
		getUserContext().setTtc("COURTINQUIRY");
		return "COURTINQUIRY";
	}

	/**
	 * Gets the dcs inquiry ttc.
	 * 
	 * @return the dcs inquiry ttc
	 */
	public String getDcsInquiryTtc() {
		getUserContext().setTtc("DCSINQUIRY");
		return "DCSINQUIRY";
	}

	/**
	 * Gets the dl ttc.
	 * 
	 * @return the dl ttc
	 */
	public String getDlTtc() {
		getUserContext().setTtc("DL");
		return "DL";
	}

	/**
	 * Sets the court inquiry ttc.
	 * 
	 * @param ttc the new court inquiry ttc
	 */
	public void setCourtInquiryTtc(String ttc) {
		getUserContext().setTtc(ttc);
	}

	/**
	 * Sets the dcs inquiry ttc.
	 * 
	 * @param ttc the new dcs inquiry ttc
	 */
	public void setDcsInquiryTtc(String ttc) {
		getUserContext().setTtc(ttc);
	}

	/**
	 * Sets the dl ttc.
	 * 
	 * @param ttc the new dl ttc
	 */
	public void setDlTtc(String ttc) {
		getUserContext().setTtc(ttc);
	}
}
/**
 *  Modification History:
 *
 *  $Log: Acceptance.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:29:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/23 00:03:22  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/22 00:40:45  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.3  2009/10/03 21:41:17  mwpxp2
 *  Adjusted imports for fw, apph refactorings; added javadoc, file footer
 *
 */
