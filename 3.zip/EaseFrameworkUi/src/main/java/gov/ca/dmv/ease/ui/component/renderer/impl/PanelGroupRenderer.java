/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 29
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIPanel;
import javax.faces.context.FacesContext;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.faces.render.Renderer;

/**
 * Description: //TODO - provide description!
 * File: PanelGroupRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: Sep 17, 2009
 * @author MWBVC  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PanelGroupRenderer extends Renderer {
	public static final String RENDERER_TYPE = "gov.ca.dmv.ease.PanelGroupRenderer";

	/**
	 * Starts encoding the JSF PanelGroup component into browser understandable (html) tag. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeBegin(FacesContext facesContext, UIComponent component)
			throws IOException {
		getPanelGroupRenderer(facesContext)
				.encodeBegin(facesContext, component);
	}

	/**
	 * writes the closing tag for JSF PanelGroup component. 
	 * @param facesContext
	 * @param component an UiComponent
	 * @throws IOException
	 */
	@Override
	public void encodeEnd(FacesContext facesContext, UIComponent component)
			throws IOException {
		getPanelGroupRenderer(facesContext).encodeEnd(facesContext, component);
	}

	/**
	 * Gets the renderer for PanelGroup component
	 * @param facesContext
	 * @return renderer for component PanelGroup
	 */
	protected Renderer getPanelGroupRenderer(FacesContext facesContext) {
		RenderKitFactory rkFactory = (RenderKitFactory) FactoryFinder
				.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
		RenderKit defaultRenderKit = rkFactory.getRenderKit(facesContext,
				RenderKitFactory.HTML_BASIC_RENDER_KIT);
		return defaultRenderKit.getRenderer(UIPanel.COMPONENT_FAMILY,
				"javax.faces.Group");
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGroupRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
