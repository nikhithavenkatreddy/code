/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import javax.faces.component.UIComponent;

/**
 * Description: //TODO - provide description!
 * File: PanelGroupTag.java
 * Module:  gov.ca.dmv.ease.ui.component.tag.impl
 * Created: Sep 17, 2009
 * @author MWBVC  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PanelGroupTag extends AbstractBaseTag {
	/** The colspan. */
	private String colspan;
	/** The layout. */
	private String layout;

	/**
	 * Gets the PanelGroup component type.
	 * 
	 * @return Component Type
	 */
	@Override
	public String getComponentType() {
		return "gov.ca.dmv.ease.PanelGroup";
	}

	/**
	 * Gets the PanelGroup renderer type.
	 * 
	 * @return Renderer Type
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.PanelGroupRenderer";
	}

	/**
	 * Sets null to all attributes and releases from the state.
	 */
	@Override
	public void release() {
		super.release();
		this.layout = null;
		this.colspan = null;
	}

	/**
	 * Sets the colspan for table column.
	 * 
	 * @param colspan the colspan
	 */
	public void setColspan(String colspan) {
		this.colspan = colspan;
	}

	/**
	 * Sets the layout for table column.
	 * 
	 * @param layout the layout
	 */
	public void setLayout(String layout) {
		this.layout = layout;
	}

	/**
	 * Sets the PanelGroup component properties.
	 * 
	 * @param component the component
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		addAttribute(component, "layout", layout);
		addAttribute(component, "colspan", colspan);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PanelGroupTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/03/23 20:32:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
