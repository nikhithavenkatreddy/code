/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl.test;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.classextension.EasyMock.createMock;
import static org.easymock.classextension.EasyMock.replay;
import gov.ca.dmv.ease.app.activity.impl.FallbackableInteractionActivity;
import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.service.impl.SessionService;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ui.listener.impl.EaseSessionStoreListener;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.web.context.WebApplicationContext;

/**
 * Description: The purpose of this class is to test the EaseSessionStoreListener class.
 * File: EaseSessionStoreListenerTest.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl.test
 * Created: Aug 31, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
@ContextConfiguration(locations = { "classpath:/test-applicationContext-fw-services.xml" })
public class EaseSessionStoreListenerTest extends
		AbstractJUnit4SpringContextTests {
	/** The request header extractor. */
	private EaseSessionStoreListener easeSessionStoreListener;
	/** Mocked FacesContext */
	private FacesContext mockFacesContext;
	/** Mocked ExternalContext */
	private ExternalContext mockExternalContext;
	/** Mocked PhaseEvent */
	private PhaseEvent mockPhaseEvent;
	/** Mocked ServletContext */
	private ServletContext mockServletContext;
	/** Mocked HttpServletRequest */
	private HttpServletRequest mockHttpServletRequest;
	/** Mocked ApplicationContext */
	private WebApplicationContext mockWebApplicationContext;
	/** Mocked HttpSession */
	private HttpSession mockHttpSession;
	/** Mocked ChildContext */
	private ChildContext mockChildContext;
	/** Mocked SessionContext */
	private SessionContext mockSessionContext;
	/** Mocked UserContext */
	private UserContext mockUserContext;
	/** Mocked SessionData */
	private SessionData mockSessionData;
	/** Mocked SessionService */
	private SessionService mockSessionService;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		mockFacesContext = createMock(FacesContext.class);
		mockExternalContext = createMock(ExternalContext.class);
		mockPhaseEvent = createMock(PhaseEvent.class);
		mockServletContext = createMock(ServletContext.class);
		mockHttpServletRequest = createMock(HttpServletRequest.class);
		mockWebApplicationContext = createMock(WebApplicationContext.class);
		mockHttpSession = createMock(HttpSession.class);
		mockChildContext = createMock(ChildContext.class);
		mockSessionContext = new SessionContext();
		mockUserContext = (UserContext) UserContext.getDefaultInstanceForDb();
		mockSessionContext.setUserContext(mockUserContext);
		mockSessionContext.setCurrentProcessContext(mockChildContext);
		mockSessionData = new SessionData();
		mockSessionData.setUserContext(mockUserContext);
		mockSessionData.setCurrentProcessContext(mockChildContext);
		mockSessionService = new SessionService();
		easeSessionStoreListener = new EaseSessionStoreListener();
		Assert.assertNotNull(easeSessionStoreListener);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		mockFacesContext = null;
		mockExternalContext = null;
		mockPhaseEvent = null;
		mockServletContext = null;
		mockHttpServletRequest = null;
		mockWebApplicationContext = null;
		mockHttpSession = null;
		mockChildContext = null;
		mockSessionContext = null;
		mockUserContext = null;
		mockSessionData = null;
		mockSessionService = null;
		easeSessionStoreListener = null;
		Assert.assertNull(easeSessionStoreListener);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionStoreListener#getPhaseId()}.
	 */
	@Test
	public void testGetPhaseId() {
		Assert.assertEquals(PhaseId.RENDER_RESPONSE, easeSessionStoreListener
				.getPhaseId());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionStoreListener#beforePhase()}.
	 */
	@Test
	public void testBeforePhase() {
		easeSessionStoreListener.beforePhase(mockPhaseEvent);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionStoreListener#afterPhase()}.
	 */
	@Test
	public void testAfterPhaseDelete() {
		expect(mockPhaseEvent.getFacesContext()).andReturn(mockFacesContext);
		expect(mockFacesContext.getExternalContext()).andReturn(
				mockExternalContext);
		expect(mockExternalContext.getContext()).andReturn(mockServletContext);
		expect(mockFacesContext.getExternalContext()).andReturn(
				mockExternalContext);
		expect(mockExternalContext.getRequest()).andReturn(
				mockHttpServletRequest);
		expect(
				mockServletContext
						.getAttribute("org.springframework.web.context.WebApplicationContext.ROOT"))
				.andReturn(mockWebApplicationContext);
		expect(mockHttpServletRequest.getSession(false)).andReturn(
				mockHttpSession);
		expect(mockHttpSession.getId()).andReturn(null);
		expect(mockWebApplicationContext.getBean("sessionContext")).andReturn(
				mockSessionContext);
		expect(mockWebApplicationContext.getBean("sessionData")).andReturn(
				mockSessionData);
		expect(mockChildContext.isMenuProcess()).andReturn(true);
		InteractionActivity recordTransactionActivity = new FallbackableInteractionActivity();
		expect(mockChildContext.getCurrentInteractionActivity()).andReturn(
				recordTransactionActivity);
		expectLastCall();
		replay(mockPhaseEvent);
		replay(mockFacesContext);
		replay(mockExternalContext);
		replay(mockServletContext);
		replay(mockHttpServletRequest);
		replay(mockHttpSession);
		replay(mockWebApplicationContext);
		replay(mockChildContext);
		easeSessionStoreListener.afterPhase(mockPhaseEvent);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionStoreListener#afterPhase()}.
	 */
	@Test
	public void testAfterPhaseStore() {
		//TODO: expects RecordTransactionActivity which cannot be created here.
		expect(mockPhaseEvent.getFacesContext()).andReturn(mockFacesContext);
		expect(mockFacesContext.getExternalContext()).andReturn(
				mockExternalContext);
		expect(mockExternalContext.getContext()).andReturn(mockServletContext);
		expect(mockFacesContext.getExternalContext()).andReturn(
				mockExternalContext);
		expect(mockExternalContext.getRequest()).andReturn(
				mockHttpServletRequest);
		expect(
				mockServletContext
						.getAttribute("org.springframework.web.context.WebApplicationContext.ROOT"))
				.andReturn(mockWebApplicationContext);
		expect(mockHttpServletRequest.getSession(false)).andReturn(
				mockHttpSession);
		expect(mockHttpSession.getId()).andReturn("1");
		expect(mockWebApplicationContext.getBean("sessionContext")).andReturn(
				mockSessionContext);
		expect(mockWebApplicationContext.getBean("sessionData")).andReturn(
				mockSessionData);
		expect(mockChildContext.isMenuProcess()).andReturn(false);
		InteractionActivity recordTransactionActivity = new FallbackableInteractionActivity();
		expect(mockChildContext.getCurrentInteractionActivity()).andReturn(
				recordTransactionActivity);
		//expect(mockWebApplicationContext.getBean("sessionService")).andReturn(
		//		mockSessionService);
		expect(mockChildContext.getCurrentInteractionActivity()).andReturn(
				recordTransactionActivity);
		expectLastCall();
		replay(mockPhaseEvent);
		replay(mockFacesContext);
		replay(mockExternalContext);
		replay(mockServletContext);
		replay(mockHttpServletRequest);
		replay(mockHttpSession);
		replay(mockWebApplicationContext);
		replay(mockChildContext);
		easeSessionStoreListener.afterPhase(mockPhaseEvent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseSessionStoreListenerTest.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/01/07 00:42:30  mwkfh
 *  updated tests
 *
 *  Revision 1.2  2010/09/30 23:15:30  mwkfh
 *  updated test
 *
 *  Revision 1.1  2010/09/24 16:03:43  mwkfh
 *  new tests
 *
 */
