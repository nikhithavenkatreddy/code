/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl.test;

import static org.junit.Assert.*;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;
import gov.ca.dmv.ease.ui.validator.impl.ValidatorBase;

import org.junit.Before;
import org.junit.Test;

/**
 * Description: Unit test for ValidatorBase
 * File: ValidatorBaseTest.java
 * Module:  gov.ca.dmv.ease.ui.validator.impl.test
 * Created: Jun 2, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ValidatorBaseTest extends ValidatorBase {
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreAttachedState(javax.faces.context.FacesContext, java.lang.Object)}.
	 */
	@Test
	public void testRestoreAttachedState() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveAttachedState(javax.faces.context.FacesContext, java.lang.Object)}.
	 */
	@Test
	public void testSaveAttachedState() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#getDetailMessage()}.
	 */
	@Test
	public void testGetDetailMessage() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#getSummaryMessage()}.
	 */
	@Test
	public void testGetSummaryMessage() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#getValueBinding(java.lang.String)}.
	 */
	@Test
	public void testGetValueBinding() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#isTransient()}.
	 */
	@Test
	public void testIsTransient() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)}.
	 */
	@Test
	public void testRestoreState() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)}.
	 */
	@Test
	public void testSaveState() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#setDetailMessage(java.lang.String)}.
	 */
	@Test
	public void testSetDetailMessage() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#setSummaryMessage(java.lang.String)}.
	 */
	@Test
	public void testSetSummaryMessage() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#setTransient(boolean)}.
	 */
	@Test
	public void testSetTransient() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#setValueBinding(java.lang.String, javax.faces.el.ValueBinding)}.
	 */
	@Test
	public void testSetValueBinding() {
		fail("Not yet implemented"); // TODO
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		throw new ValidatorException(FacesUtils.createErrorMessage(
				"some value", "some error message"));
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValidatorBaseTest.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/06/02 22:55:13  mwpxp2
 *  Initial stub
 *
 */
