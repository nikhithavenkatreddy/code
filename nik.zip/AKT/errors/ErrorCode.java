package gov.ca.dmv.AKT.errors;

public final class ErrorCode {
	
	public static final int NO_ERROR = 0;
	public static final int NULL_APPLICATION = 1;
	public static final int NULL_EXAM_LIST = 2;
	public static final int NULL_SESSION = 3;
	public static final int PASS_EXAM = 4;
	public static final int PROVISIONAL = 5;
	public static final int OUT_OF_STATE = 6;
	public static final int DL_EXPIRES_WITHIN_30_DAYS = 7;
	public static final int YOB_VALIDATION_FAILED_3_TIMES = 8;
	public static final int YOB_VALIDATION_FAILED = 9;
	public static final int SESSION_TERMINATED = 10;
	public static final int FORCE_FAILED = 11;
	public static final int DUPLICATE_PARENT_QUESTION = 12;
	public static final int DUPLICATE_LANG_QUESTION = 13;
	public static final int PARENT_QUESTION_NOT_CREATED = 14;
	public static final int JDBC_FAILURE = 15;
	public static final int INTEGRITY_FAILURE = 16;
	public static final int ACCESS_FAILURE = 17;
	public static final int CATCHALL_FAILURE = 18;
	public static final int PAUSE_ERROR = 19;
	public static final int YOB_ENDED_SESSION = 20;
	public static final int NONE = 8;
	public static final int NULL_EXAM_LIST2 = 21;
	public static final int NULL_CATEGORY_LIST = 22;
	public static final int NULL_TEST_LIST = 23;
	public static final int MISSING_WORKSTATION = 24;
	public static final int NULL_CATEGORY_LIST2 = 30;
	public static final int NULL_TEST_LIST2 = 32;
	public static final int NULL_QUESTION = 33;
	public static final int NULL_QUESTIONLIST = 35;
	public static final int NULL_LANG = 39;
	public static final int NULL_HANDBOOK = 41;
	public static final int NULL_QUESTION_IDS = 43;
	public static final int INCORRECT_TEST_LANG = 44;
	public static final int NULL_QUESTION_LANG = 48;
	public static final int OPEN_SESSION = 50;
	public static final int MISSING_QUES_LANG = 52;
	public static final int MISSING_ANSWERS = 54;
	public static final int MISSING_HANDBOOKREF = 56;
	public static final int MISSING_LANG = 58;
	public static final int MISSING_QUESTIONS = 61;
	public static final int MISSING_QPF_TESTS = 65;
	public static final int MISSING_QPF = 67;
	public static final int MISSING_TEST = 70;
	public static final int MISSING_EXAMS = 74;
	public static final int MISSING_EXAM_QUESTION = 76;
	public static final int MISSING_FO = 78;
	public static final int MISSING_VAULT = 80;
	public static final int MISSING_APPLICATION = 82;
	public static final int MISSING_EXAM_HISTORY = 84;
	public static final int MISSING_PR_EVENT = 86;
	public static final int MISSING_SESSION = 89;
	public static final int MISSING_TEST_PLAN = 99;
	public static final int MISSING_THRESHOLD = 105;
	public static final int MISSING_QUES_GEN = 107;
	public static final int MISSING_EXAM_ANSWERS = 109;
	public static final int PASS_FAIL_ERROR = 113;
	public static final int INCORRECT_DL = 141;
	public static final int INCOMPLETE_TEST = 142; 
	public static final int NO_SELECTION = 143;
	public static final int MISSING_REQUIRED = 144;
	public static final int INCORRECT_CREDENTIALS = 145;
	public static final int TEST_IS_TAKING = 146;
	public static final int NO_MATCH_FOUND = 147;
	public static final int INCORRECT_LANG = 148;
	public static final int UNAUTH_TERM_ACCESS = 149;
	public static final int AUTH_TERM_ACCESS = 150;
	public static final int MISSING_AUDIT = 151;
	public static final int RECORD_NOT_FOUND = 152;
	public static final int INVALID_GROUP = 153;
	public static final int SINGLE_PAUSE_ALLOWED = 154;
	public static final int INPUT_OUT_OF_RANGE = 155;
	public static final int DUPLICATE_TEST_ID = 156;
	public static final int MISSING_CATEGORY = 157;
	public static final int DUPLICATE_CATEGORY_ID=158;
	public static final int	DUPLICATE_HANDBOOKREF=159;
	public static final int	NO_MISSING_QUESTIONS=160;
	public static final int MISSING_CREDENTIALS = 161;
	public static final int NEED_STUDY = 162;
	
	public static final String ERROR_MESSAGE(int errorCode) {
		if(errorCode == NULL_APPLICATION)
			return "See Field Office Technician";
		
		else if(errorCode == NULL_EXAM_LIST)
			return "No outstanding tests. See Field Office Technician";
		
		else if(errorCode == NULL_SESSION)
			return "Previous session has not ended. See Field Office Technician";
	
		else if(errorCode == PASS_EXAM)
			return "No outstanding tests. See Field Office Technician";
		
		else if(errorCode == PROVISIONAL)
			return "Please wait 7 days to take another test";
		
		else if(errorCode == OUT_OF_STATE)
			return "See Field Office Technician";
		
		else if(errorCode == DL_EXPIRES_WITHIN_30_DAYS)
			return "See Field Office Technician";
		
		else if(errorCode == YOB_VALIDATION_FAILED_3_TIMES)
			return "Information entered does not match our records. See Field Office Technician";
		
		else if(errorCode == YOB_VALIDATION_FAILED)
			return "Information entered does not match our records. Please re-enter your year of birth";
		
		else if(errorCode == SESSION_TERMINATED)
			return "Session has been terminated";
		
		else if(errorCode == FORCE_FAILED)
			return "See Field Office Technician";
		
		else if(errorCode == NONE)
			return "Session has been terminated";
		
		else if(errorCode == MISSING_WORKSTATION)
			return "Missing workstation map exception";
		
		else if(errorCode == DUPLICATE_PARENT_QUESTION)
			return "The parent question by this question id already exists. Please change the question id or modify the existing question";
		
		else if(errorCode == DUPLICATE_LANG_QUESTION)
			return "The question id for the language selected already exists. Please choose a different question id/language or modify the existing question";
		
		else if(errorCode == PARENT_QUESTION_NOT_CREATED)
			return "Parent question has to be created before creating language specific question";
		
		else if(errorCode == JDBC_FAILURE)
			return "Connectivity to the database is not able to be established";
		
		else if(errorCode == INTEGRITY_FAILURE)
			return "Unable to insert or update due to integrity violation";
		
		else if(errorCode == ACCESS_FAILURE)
			return "Unable to access database due to permission error";
		
		else if(errorCode == CATCHALL_FAILURE)
			return "General database exception";
		
		else if(errorCode == PAUSE_ERROR)
			return "See Field Office Technician to resume exam";
		
		else if(errorCode == YOB_ENDED_SESSION)
			return "See Field Office Technician to reset the Y.O.B validation";
		
		else if(errorCode == NULL_EXAM_LIST2)
			return "You failed a test 3 times. See Field Office Technician";
		
		else if(errorCode == NULL_CATEGORY_LIST)
			return "No categories found exception";
		
		else if(errorCode == NULL_TEST_LIST)
			return "No tests record found";
		
		else if(errorCode == NULL_CATEGORY_LIST2)
			return "No categories found exception";
		
		else if(errorCode == NULL_TEST_LIST2)
			return "No tests record found";
		
		else if(errorCode == NULL_QUESTION)
			return "No question found exception";
		
		else if(errorCode == NULL_QUESTIONLIST)
			return "No question list found exception";
		
		else if(errorCode == NULL_LANG)
			return "No languages found exception";
		
		else if(errorCode == NULL_HANDBOOK)
			return "No handbook reference found exception";
		
		else if(errorCode == NULL_QUESTION_IDS)
			return "No questions found exception";
		
		else if(errorCode == INCORRECT_TEST_LANG)
			return "This test is not available in the language you chose.";
		
		else if(errorCode == OPEN_SESSION)
			return "Test already in progress";
		
		else if(errorCode == MISSING_QUES_LANG)
			return "Missing language specific question exception";
		
		else if(errorCode == MISSING_ANSWERS)
			return "Missing answers exception";
		
		else if(errorCode == MISSING_ANSWERS)
			return "Missing handbookref exception";
		
		else if(errorCode == MISSING_LANG)
			return "Missing language exception";
		
		else if(errorCode == MISSING_QUESTIONS)
			return "Missing questions exception";
		
		else if(errorCode == NO_MISSING_QUESTIONS)
			return "No Missing questions available for this test";
		
		else if(errorCode == MISSING_QPF_TESTS)
			return "No tests are eligible for quick pass fail";
		
		else if(errorCode == MISSING_QPF)
			return "Missing quick pass fail exception";
		
		else if(errorCode == MISSING_TEST)
			return "Missing test exception";
		
		else if(errorCode == MISSING_EXAMS)
			return "Missing exams exception";
		
		else if(errorCode == MISSING_EXAM_QUESTION)
			return "Missing exam question exception";
		
		else if(errorCode == MISSING_FO)
			return "Invalid terminal exception";
		
		else if(errorCode == MISSING_VAULT)
			return "Missing vault exception";
		
		else if(errorCode == MISSING_APPLICATION)
			return "Missing application exception";
		
		else if(errorCode == MISSING_EXAM_HISTORY)
			return "Missing exam history exception";
		
		else if(errorCode == MISSING_PR_EVENT)
			return "Missing pause restart event exception";
		
		else if(errorCode == MISSING_SESSION)
			return "Missing session exception";
		
		else if(errorCode == MISSING_TEST_PLAN)
			return "Missing test plan exception";
		
		else if(errorCode == MISSING_THRESHOLD)
			return "Missing threshold exception";
		
		else if(errorCode == MISSING_QUES_GEN)
			return "Missing question gen exception";
		
		else if(errorCode == MISSING_EXAM_ANSWERS)
			return "Missing exam answers exception";
		
		else if(errorCode == PASS_FAIL_ERROR)
			return "Pass/Fail exception";
		
		else if(errorCode == INCORRECT_DL)
			return "Please enter valid entry";
		
		else if(errorCode == INCOMPLETE_TEST)
			return "Applicant has not completed a test";
		
		else if(errorCode == NO_SELECTION)
			return "Please make a selection";
		
		else if(errorCode == MISSING_REQUIRED)
			return "Please enter required information";
		
		else if(errorCode == INCORRECT_CREDENTIALS)
			return "Username or Password is incorrect. Please try again";
		
		else if(errorCode == MISSING_CREDENTIALS)
			return "Secondary Verification Credentials are required for commercial tests";
			
		else if(errorCode == TEST_IS_TAKING)
			return "There is currently exams taking, can not update DAF.";
			
		else if(errorCode == NO_MATCH_FOUND)
			return "No Match Found.";
		
		else if(errorCode == INCORRECT_LANG)
			return "The test is not available in the language selected. Please choose a different language.";
		
		else if(errorCode == MISSING_AUDIT)
			return "Missing audit exception";
		
		else if(errorCode == RECORD_NOT_FOUND)
			return "Record not found";
		
		else if(errorCode == INVALID_GROUP)
			return "Accessing with invalid group";
		
		else if(errorCode == SINGLE_PAUSE_ALLOWED)
			return "An applicant can be paused only once";
		
		else if(errorCode == NO_ERROR)
			return "Operation Successful";
		
		else if(errorCode == DUPLICATE_TEST_ID)
			return "This test ID already exists. Please change test ID";
		
		else if(errorCode == INPUT_OUT_OF_RANGE)
			return "Input is out of range. Save Failed.";
		
		else if(errorCode == MISSING_CATEGORY)
			return "Missing category exception";
		
		else if(errorCode == DUPLICATE_CATEGORY_ID)
			return "Category ID already exists";
		
		else if(errorCode == DUPLICATE_HANDBOOKREF)
			return "Handbook Sec ID already exists for this Language";
		
		else if(errorCode == NEED_STUDY)
			return "You did not pass this test. Please study the handbook before returning to re-take the test.";
		
		else
			return null;	
		
	}
	
	public static final String ERROR_LOG(int errorCode) {
		if(errorCode == NULL_APPLICATION)
			return "Possible reasons for the error: (i)No application found for the vault id," +
					" (ii)Field office id didn't match or (iii)No active vault for today.";
		
		else if(errorCode == NULL_EXAM_LIST)
			return "Possible reasons for error: No exam was found for the criteria application id " +
					"and no exam end time";
		
		else if(errorCode == NULL_SESSION)
			return "Possible reasons for error: (i)Active session for the application id was found or " +
					"(ii)Not been 5 minutes since the previous session ended";
		
		else if(errorCode == PASS_EXAM)
			return "Possible reasons for error: (i)Has passed all active exams";
		
		else if(errorCode == PROVISIONAL)
			return "Possible reasons for error: (i)Has not passed the exams and (ii) is provisional";
		
		else if(errorCode == OUT_OF_STATE)
			return "Possible reasons for error: (i)Has not passed the exams and (ii) the applicant is out of state";
		
		else if(errorCode == DL_EXPIRES_WITHIN_30_DAYS)
			return "Possible reasons for error: (i)Has not passed the exams and (ii) the DL expires within 30 days";
		
		else if(errorCode == YOB_VALIDATION_FAILED_3_TIMES)
			return "Possible reasons for error: (i)Failed YOB validation 3 times";
		
		else if(errorCode == YOB_VALIDATION_FAILED)
			return "Possible reasons for error: (i)Failed YOB validation (less than 3 times)";
		
		else if(errorCode == SESSION_TERMINATED)
			return "Possible reasons for error: (i)Applicant ended the session";
		
		else if(errorCode == FORCE_FAILED)
			return "Possible reasons for error: (i)Field Office force failed the exam";
		
		else if(errorCode == NONE)
			return "Possible reasons for error: (i)Has not passed the exams, (ii) not provisional, not out of state and Dl doesn't expire in 30 days";
		
		else if(errorCode == DUPLICATE_PARENT_QUESTION)
			return "Possible reasons for error: (i)An active parent question record for that question id already exists";
		
		else if(errorCode == DUPLICATE_LANG_QUESTION)
			return "Possible reasons for error: (i)An active language specific question record for that question id already exists";
		
		else if(errorCode == PARENT_QUESTION_NOT_CREATED)
			return "Possible reasons for error: (i)Parent question for that question id has to be created before creating language specific question";
		
		else if(errorCode == PAUSE_ERROR)
			return "Possible reasons for error: (i)Applicant has a paused exam which needs to be unpaused by the technician for the applicant to resume the exam";
		
		else if(errorCode == NULL_EXAM_LIST2)
			return "Possible reasons for error: Failed exam 3 times";
		
		else if(errorCode == NULL_CATEGORY_LIST)
			return "No categories found in the database for the hql executed in public List<Category> load() method in class CategoryPersistenceImpl";
		
		else if(errorCode == NULL_CATEGORY_LIST2)
			return "No categories found in the database for the hql executed in public List<Category> loadByQuestionId(Object[] params) method in class CategoryPersistenceImpl";
		
		else if(errorCode == NULL_TEST_LIST)
			return "No tests found in the database for the hql executed in public List<Test> load() method in class TestPersistenceImpl";
		
		else if(errorCode == OPEN_SESSION)
			return "Test already in progress";
		
		else if(errorCode == NULL_EXAM_LIST)
			return "No outstanding tests. See Field Office Technician";
		
		else if(errorCode == NEED_STUDY)
			return "You did not pass this test. Please study the handbook before returning to re-take the test.";
		
		else
			return null;
	}
}
