package gov.ca.dmv.AKT.errors;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.dao.*;

public class ExceptionResolver 

{

	public static int JDBC_FAILURE = 15;

	public static int INTEGRITY_FAILURE = 16;

	public static int ACCESS_FAILURE = 17;

	public static int CATCHALL_FAILURE = 18;

	private static final Logger logger = Logger.getLogger(ExceptionResolver.class);

	public static int resolve(Exception e)

	{

		logger.error(getStackTraceAsString(e));
		
		int retVal = 0;

		if (e instanceof DataAccessResourceFailureException)

		{

			retVal = JDBC_FAILURE;

		}

		else if (e instanceof DataRetrievalFailureException)

		{

			retVal = ACCESS_FAILURE;

		}

		else if (e instanceof DataIntegrityViolationException)

		{     

			retVal = INTEGRITY_FAILURE; 

		}

		else

		{

			retVal = CATCHALL_FAILURE; 

		}

		return retVal;

	}
	
	public static String getStackTraceAsString(Exception exception) { 
		StringWriter sw = new StringWriter(); 
		PrintWriter pw = new PrintWriter(sw); 
		pw.print(" [ "); 
		pw.print(exception.getClass().getName()); 
		pw.print(" ] "); 
		pw.print(exception.getMessage()); 
		exception.printStackTrace(pw); 
		return sw.toString(); 
	}

}