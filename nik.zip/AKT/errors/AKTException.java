package gov.ca.dmv.AKT.errors;

import gov.ca.dmv.AKT.constants.Constant;

/**
 * I am the root exception for AKT.
 * @author mwwxw2
 *
 */
public class AKTException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	/**
     * Instantiates a new AKT exception.
     */
    public AKTException() {
        super();
    }

    /**
     * The Constructor.
     *
     * @param message the message
     */
    public AKTException(String message) {
        super(message);
    }

    /**
     * The Constructor.
     *
     * @param message the message
     * @param cause the cause
     */
    public AKTException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * The Constructor.
     *
     * @param cause the cause
     */
    public AKTException(Throwable cause) {
        super(cause);
    }

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    public int getErrorCode() {
    	int error = ExceptionResolver.resolve(this);
        if(error == Constant.ZERO && getMessage() != null)
        	return Constant.NEGATIVE_ONE;
        return error;
    }
}
