package gov.ca.dmv.AKT.security.bean;

public interface IDMVStaff {

	String getRemoteIP();

	void setRemoteIP(String remoteIP);

	String getOfficeID();

	void setOfficeID(String officeID);

	String getTechID();

	void setTechID(String techID);

	String getFirstName();

	void setFirstName(String firstName);

	String getLastName();

	void setLastName(String lastName);

	String getUserId();

	void setUserId(String userId);

	String getGroupList();

	void setGroupList(String groupList);

	boolean isMemberOf(String group);

	String validateAndReturnTechGroup();
	
	String validateAndReturnHQTechGroup();

	boolean hasGlobalView();

	String getAppType(String group);

	String getOfficeType(String group);

}