package gov.ca.dmv.AKT.security.bean;

import gov.ca.dmv.AKT.constants.Constant;

public class DMVStaff implements IDMVStaff 
{
	private String lastName;
	private String userId;
	private String groupList;	
	private String firstName;
	private String officeID;
	private String techID;
	private String remoteIP;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getRemoteIP()
	 */
	@Override
	public String getRemoteIP() {
		return remoteIP;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setRemoteIP(java.lang.String)
	 */
	@Override
	public void setRemoteIP(String remoteIP) {
		this.remoteIP = remoteIP;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getOfficeID()
	 */
	@Override
	public String getOfficeID() {
		return officeID;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setOfficeID(java.lang.String)
	 */
	@Override
	public void setOfficeID(String officeID) {
		this.officeID = officeID;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getTechID()
	 */
	@Override
	public String getTechID() {
		return techID;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setTechID(java.lang.String)
	 */
	@Override
	public void setTechID(String techID) {
		this.techID = techID;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getFirstName()
	 */
	@Override
	public String getFirstName() {
		return firstName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setFirstName(java.lang.String)
	 */
	@Override
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getLastName()
	 */
	@Override
	public String getLastName() {
		return lastName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setLastName(java.lang.String)
	 */
	@Override
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getUserId()
	 */
	@Override
	public String getUserId() {
		return userId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setUserId(java.lang.String)
	 */
	@Override
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getGroupList()
	 */
	@Override
	public String getGroupList() {
		return groupList;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#setGroupList(java.lang.String)
	 */
	@Override
	public void setGroupList(String groupList) {
		this.groupList = groupList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#isMemberOf(java.lang.String)
	 */
	@Override
	public boolean isMemberOf(String group)
	{
		boolean flag = false;
		if (groupList.toUpperCase().indexOf(group.toUpperCase()) > Constant.NEGATIVE_ONE)
		{
			flag = true;
		}
		return flag;	
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#validateAndReturnTechGroup()
	 */
	@Override
	public String validateAndReturnTechGroup()
	{
		String group = null;
		String[] validGroups = {Constant.FO_ADMIN_GROUP, Constant.FO_USER_GROUP,
								Constant.HQ_ADMIN_GROUP, Constant.HQ_USER_GROUP,
				                Constant.DS_ADMIN_GROUP, Constant.DS_USER_GROUP, 
				                Constant.OL_ADMIN_GROUP, Constant.OL_USER_GROUP,
				                Constant.CHP_ADMIN_GROUP, Constant.CHP_USER_GROUP,
				                Constant.CPD_ADMIN_GROUP, Constant.CPD_USER_GROUP, 
				                Constant.ISS_ADMIN_GROUP, Constant.ISS_USER_GROUP,
				                };
		for(String givenGroup: validGroups) {
			if(isMemberOf(givenGroup)) {
				return givenGroup;
			}
		}
		return group;
	}
	
	public String validateAndReturnHQTechGroup()
	{
		String group = null;
		String[] validGroups = {Constant.HQ_ADMIN_GROUP, Constant.HQ_USER_GROUP};
		for(String givenGroup: validGroups) {
			if(isMemberOf(givenGroup)) {
				return givenGroup;
			}
		}
		return group;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#hasGlobalView()
	 */
	@Override
	public boolean hasGlobalView(){
		String[] validGroups = {Constant.CPD_ADMIN_GROUP, Constant.CPD_USER_GROUP, 
				                Constant.ISS_ADMIN_GROUP, Constant.ISS_USER_GROUP,
				                };
		for(String givenGroup: validGroups) {
			if(isMemberOf(givenGroup)) {
				return true;
			}
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getAppType(java.lang.String)
	 */
	@Override
	public String getAppType(String group)
	{
		String appType = null;
		
		if (group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) ||
			group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			appType = Constant.APP_TYPE_DS;
		}
		else if (group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) ||
			group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			appType = Constant.APP_TYPE_OL;
		}
		else if (group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) ||
				group.equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
				appType = Constant.APP_TYPE_CHP;
			}
		else {
			appType = Constant.APP_TYPE_FO;
		}
		return appType;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.security.bean.IDMVStaff#getOfficeType(java.lang.String)
	 */
	@Override
	public String getOfficeType(String group)
	{
		String officeType = null;
		
		if (group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || 	group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			officeType = Constant.OFFICE_TYPE_DS;
		}
		else if (group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			officeType = Constant.OFFICE_TYPE_OL;
		}
		else if (group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) ||	group.equalsIgnoreCase(Constant.FO_USER_GROUP)){
			officeType = Constant.OFFICE_TYPE_FO;
		}
		else if (group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) ||	group.equalsIgnoreCase(Constant.CHP_USER_GROUP)){
			officeType = Constant.OFFICE_TYPE_CHP;
		}
		return officeType;
	}
}
