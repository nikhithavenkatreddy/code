package gov.ca.dmv.AKT.integration.PersistenceImpl;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.SessionPersistence;

import java.util.Date;
import java.util.List;

public class SessionPersistenceImpl extends DMVHibernateSupport implements SessionPersistence {

	//This method is called to load the session by application id//
	@SuppressWarnings("unchecked")
	public List<ISession> load(Object param) throws AKTException {
		List<ISession> sessionList = null;
		try {
			String hql = "from Session where applicationId = ? order by sessionStartTime desc";
			sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object param) method in SessionPersistenceImpl class", e);
		}
		return sessionList;
	}

	/*
	 * This method is called to get a list of all sessions
	 */
	@SuppressWarnings("unchecked")
	public List<ISession> loadAllSessions(Object[] params) throws AKTException {
		List<ISession> sessionList = null;
		try {
			StringBuffer hql = new StringBuffer();
			hql.append("from Session as session ");
			hql.append("where session.applicationId in (select applicationId from Application as app where app.officeId = ? and app.applicationType = ? )");
			sessionList = (List<ISession>) getHibernateTemplate().find(hql.toString(), params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllSessions(Object[] params) method in SessionPersistenceImpl class", e);
		}
		return sessionList;
	}
	
	/*
	 * This method is called to save session
	 */
	public void save(ISession session) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(session);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(Session session) method in SessionPersistenceImpl class", e);
		}
	}

	//This method is called to update the session with session end time//
	@SuppressWarnings("unchecked")
	public void update(Object param, Date endTime) throws AKTException {
		try {
			String hql = "From Session where sessionId = ?";
			List<ISession> sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
			for(ISession session: sessionList) {
				session.setSessionEndTime(endTime);
				getHibernateTemplate().update(session);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object param, Date endTime) method in SessionPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load a list of sessions by office id for failed yob
	 */
	@SuppressWarnings("unchecked")
	public List<ISession> loadFailedYOB(Object[] params) throws AKTException {
		List<ISession> sessionList = null;
		try {
			String hql = "from Session where officeId = ? and yobValidationFlag = ? and yobOverrideTime = ?";
			sessionList = (List<ISession>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadFailedYOB(Object[] params) method in SessionPersistenceImpl class", e);
		}
		return sessionList;
	}

	/*
	 * This method is called to update the session with yob override time
	 */
	@SuppressWarnings("unchecked")
	public void updateYOBOverrideTime(Object param, Date overrideTime) throws AKTException {
		try {
			String hql = "From Session where sessionId = ?";
			List<ISession> sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
			for(ISession session: sessionList) {
				session.setYobOverrideTime(overrideTime);
				getHibernateTemplate().saveOrUpdate(session);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in updateYOBOverrideTime(Object param, Date overrideTime) method in SessionPersistenceImpl class", e);
		}
	}

	//This method is called to reset the session with session end time, yob override timestamp, yob validation flag, sessionStatusCode//
	@SuppressWarnings("unchecked")
	public void reset(Object param, Date sessionEndTime, Date yobOverrideTime, String yobValidationFlag, String sessionStatusCode) throws AKTException {
		try {
			String hql = "from Session where sessionId = ?";
			List<ISession> sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
			for(ISession session: sessionList) {
				session.setSessionEndTime(sessionEndTime);
				session.setYobOverrideTime(yobOverrideTime);
				session.setYobValidationFlag(yobValidationFlag);
				session.setSessionStatusCode(sessionStatusCode);
				getHibernateTemplate().saveOrUpdate(session);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in reset(Object param, Date sessionEndTime, Date yobOverrideTime, String yobValidationFlag) method in SessionPersistenceImpl class", e);
		}
	}

	//This method is called to reset the session with workstationIPAddress//
	@SuppressWarnings("unchecked")
	public void resetTerminal(Object param, String workstationIPAddress) throws AKTException {
		try {
			String hql = "from Session where sessionId = ?";
			List<ISession> sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
			for(ISession session: sessionList) {
				session.setWorkstationIPAddress(workstationIPAddress);
				getHibernateTemplate().saveOrUpdate(session);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in reset(Object param, Date sessionEndTime, Date yobOverrideTime, String yobValidationFlag) method in SessionPersistenceImpl class", e);
		}
	}
	
	//This method is called to update the session with session end time and yob validation flag//
	@SuppressWarnings("unchecked")
	public void updateWithYOBFail(Object param, Date endTime, String yobValidationFlag) throws AKTException {
		try {
			String hql = "From Session where sessionId = ?";
			List<ISession> sessionList = (List<ISession>) getHibernateTemplate().find(hql, param);
			for(ISession session: sessionList) {
				session.setSessionEndTime(endTime);
				session.setYobValidationFlag(yobValidationFlag);
				getHibernateTemplate().update(session);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in updateWithYOBFail(Object param, Date endTime, String yobValidationFlag) method in SessionPersistenceImpl class", e);
		}
	}
		
}
