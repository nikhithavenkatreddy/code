package gov.ca.dmv.AKT.integration.PersistenceImpl;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults;
import gov.ca.dmv.AKT.integration.BeansImpl.Exam;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.ExamPersistence;
import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

public class ExamPersistenceImpl extends DMVHibernateSupport implements ExamPersistence {
	/*
	 * This method is called to load exam by session id and no end time.
	 */
	@SuppressWarnings("unchecked")
	public List<QuesPassRate> getQuesPassRateList(Date fromDate, Date toDate) throws AKTException {
		List<QuesPassRate> quesPassRateList = null;
		try {
			String hql = "select b.testId, a.questionId, b.langId, " +
						 "CAST (sum(CASE WHEN a.answerStatus = 'Y' THEN 1 ELSE 0 END) AS double)/sum(CASE WHEN a.answerStatus in ('Y','N') THEN 1 ELSE 0 END)*100.00 AS PERCENT_PASS, " + 
						 "CAST (sum(CASE WHEN a.answerStatus = 'N' THEN 1 ELSE 0 END) AS double)/sum(CASE WHEN a.answerStatus in ('Y','N') THEN 1 ELSE 0 END)*100.00 AS PERCENT_FAIL " +
						 "from ExamQuestionSecondary a, ExamSecondary b " +
						 "where a.eqPrimaryKey.examId = b.examId and b.lastModUserTime between ? AND ?" +
						 "GROUP BY b.testId, a.questionId, b.langId ";					
			quesPassRateList = (List<QuesPassRate>)getHibernateTemplate().find(hql,fromDate,toDate);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new AKTException("Exception in loadBySessionId(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return quesPassRateList;
	}
	
	//This method is called to load exam by exam id//
	@SuppressWarnings("unchecked")
	public List<IExam> loadByExamId(Object param) throws AKTException{
		List<IExam> examList = null;
		try {
			String hql = "from Exam where examId = ? and 1=1";
			examList = (List<IExam>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByExamId(Object param) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	//This method is called to load exam by exam id//
		@SuppressWarnings("unchecked")
		public List<IExamHistory> loadByExamHistId(Object param) throws AKTException{
			List<IExamHistory> examHistList = null;
			try {
				String hql = "from ExamHistory where pastExamId = ?";
				examHistList = (List<IExamHistory>) getHibernateTemplate().find(hql, param);
			}
			catch(Exception e) {
				throw new AKTException("Exception in loadByExamHistId(Object param) method in ExamPersistenceImpl class", e);
			}
			return examHistList;
		}

	//This method's called to load exams by app id, no end time and session id different from current session id//
	@SuppressWarnings("unchecked")
	public List<IExam> loadByAppIdAndDifferentSessionId(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where applicationId = ? and examEndTime = ? and sessionId != ?";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByAppIdAndDifferentSessionId(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	/*
	 * This method is called to update an exam with pass fail ind, reason code and exam end time
	 */
	@SuppressWarnings("unchecked")
	public void update(Object param, Date endTime, String reasonCode, String passFailIndicator) throws AKTException {
		try {
			String hql = "from Exam where examId = ?";
			List<IExam> examList = (List<IExam>) getHibernateTemplate().find(hql, param);
			for(IExam exam: examList) {
				exam.setCompletionReasonCode(reasonCode);
				exam.setExamEndTime(endTime);
				exam.setPassFailIndicator(passFailIndicator);
				getHibernateTemplate().saveOrUpdate(exam);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object param, Date endTime, String reasonCode, String passFailIndicator) method in ExamPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to save a list of exams
	 */
	public void save(IExam exam) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(exam);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(Exam exam) method in ExamPersistenceImpl class", e);
		}
	}

	//This method is called to load the exam answer by exam id and answer id//
	@SuppressWarnings("unchecked")
	public List<IExamAnswer> loadExamAnswer(Object[] params) {
		String hql = "from ExamAnswer where eaPrimaryKey.examId = ? and eaPrimaryKey.answerId = ?";
		return (List<IExamAnswer>) getHibernateTemplate().find(hql, params);
	}

	//This method is called to load exams by start time not equal to null and end time equal to null//
	@SuppressWarnings("unchecked")
	public List<IExam> loadByStartDateAndNoEndDate(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where examStartTime != ? and examEndTime = ? and officeId = ?";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByStartDateAndNoEndDate(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	//This method is called to load exams by start time not equal to null and end time equal to null//
	@SuppressWarnings("unchecked")
	public List<IExam> loadByStartDateAndNoEndDateAndAppType(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			//StringBuffer hql = new StringBuffer("select Exam ");
			//hql.append("from Exam as exam, Application app where app.applicationId = exam.applicationId "); 
			//hql.append("and exam.examStartTime != ? and exam.examEndTime = ? and exam.officeId = ? and app.applicationType = ?");
			
			StringBuffer hql = new StringBuffer();
			hql.append("from Exam as exam where ((exam.examStartTime != ? and exam.examEndTime = ?) or exam.completionReasonCode in ('P', 'R', 'A', 'Z', 'W')) ");
			hql.append("and exam.officeId = ? ");
		    hql.append("and exam.applicationId in (select applicationId from Application as app where app.applicationType = ?)");
			examList = (List<IExam>) getHibernateTemplate().find(hql.toString(), params);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new AKTException("Exception in loadByStartDateAndNoEndDate(Object[] params) method in ExamPersistenceImpl class", e);			
		}
		return examList;
	}

	//This method is called to remove any stub exam based on application id, test id and no start time//
	@SuppressWarnings("unchecked")
	public void deleteStub(Object[] params) throws AKTException {
		String hql = "from Exam where applicationId = ? and testId = ? and examStartTime = ?";
		try {
			List<IExam> examList = (List<IExam>) getHibernateTemplate().find(hql, params);
			for(IExam exam: examList) {
				getHibernateTemplate().delete(exam);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in deleteStub(Object[] params) method in ExamPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to save exam question records in exam question table
	 */
	public void save(IExamQuestion examQuestion) throws AKTException {
		try {
			getHibernateTemplate().update(examQuestion);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(ExamQuestion examQuestion) method in ExamPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to save exam answer records in exam answer table.
	 */
	public void save(IExamAnswer examAnswer) {
		getHibernateTemplate().saveOrUpdate(examAnswer);
	}

	/*
	 * This method is called to get completed exam records by testId, FO and different examId.
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadByTestIdAndDiffExamId(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where examId != ? and testId = ? and officeId = ? and examStartTime != ? and examEndTime != ? order by examStartTime desc";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByTestIdAndDiffExamId(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to get exam question record by exam id.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamQuestion> getExamQues(Object param) throws AKTException {
		List<IExamQuestion> examQuesList = null;
		try {
			String hql = "from ExamQuestion where eqPrimaryKey.examId = ?";
			examQuesList = (List<IExamQuestion>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in getExamQues(Object param) method in ExamPersistenceImpl class", e);
		}
		return examQuesList;
	}

	/*
	 * This method is called to update exam with ease transaction time.
	 */
	@SuppressWarnings("unchecked")
	public void updateEaseTransactionTime(Object param, Date easeTransactionTime) {
		String hql = "from Exam where examId = ?";
		List<IExam> examList = (List<IExam>) getHibernateTemplate().find(hql, param);
		for(IExam exam: examList) {
			exam.setEaseTimestamp(easeTransactionTime);
			getHibernateTemplate().saveOrUpdate(exam);
		}
	}

	/*
	 * This method is called to load exam by session id and no end time.
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadBySessionId(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			StringBuffer hql = new StringBuffer();
			hql.append("from Exam as exam where exam.sessionId = ? and exam.examStartTime != ? and exam.examEndTime = ? ");
			hql.append("and exam.applicationId in (select applicationId from Application as app where app.applicationType = ?)");
			examList = (List<IExam>) getHibernateTemplate().find(hql.toString(), params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadBySessionId(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to save exam history record in the exam history table.
	 */
	public void save(IExamHistory examHistory) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(examHistory);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(ExamHistory examHistory) method in ExamPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to get exam question record based on exam id and question presented order.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamQuestion> loadExamQues(Object[] params) {
		String hql = "from ExamQuestion where eqPrimaryKey.examId = ? and eqPrimaryKey.questionPresentedOrder = ? and 1=1";
		return (List<IExamQuestion>) getHibernateTemplate().find(hql, params);
	}

	/*
	 * This method is called to load exam answer record by exam id and question gen id.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamAnswer> loadByExamIdAndQuestionGenId(Object[] params) {
		String hql = "from ExamAnswer where eaPrimaryKey.examId = ? and questionGenId = ?";
		return (List<IExamAnswer>) getHibernateTemplate().find(hql, params);
	}

	/*
	 * This method is called to load the stub exam created for taking a sign test
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadSignExam(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where applicationId = ? and signTestFlag = ? and examStartTime = ?";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadSignExam(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	/*
	 * This method is called to get a list of timed out exams
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadQuitExams(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			StringBuffer hql = new StringBuffer();
			hql.append("from Exam as exam where exam.officeId = ? and exam.completionReasonCode = ? ");
			hql.append("and exam.applicationId in (select applicationId from Application as app where app.applicationType = ?)");
			examList = (List<IExam>) getHibernateTemplate().find(hql.toString(), params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQuitExams(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	/*
	 * This method is called to get a list of timed out exams
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadAllExams(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			StringBuffer hql = new StringBuffer();
			hql.append("from Exam as exam where exam.officeId = ? ");
			hql.append("and exam.applicationId in (select applicationId from Application as app where app.applicationType = ?)");
			examList = (List<IExam>) getHibernateTemplate().find(hql.toString(), params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllExams(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	/*
	 * This method is called to get missed exam question records by exam id that were incorrectly answered by the applicant.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamQuestion> getMissedExamQues(Object[] params) throws AKTException {
		List<IExamQuestion> eqList = null;
		try {
			String hql = "from ExamQuestion where eqPrimaryKey.examId = ? and answerStatus = ?";
			eqList = (List<IExamQuestion>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in getMissedExamQues(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return eqList;
	}

	/*
	 * This method is called to get exam answer by exam id and question gen id.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamAnswer> getExamAnsw(Object[] params) throws AKTException {
		List<IExamAnswer> eaList = null;
		try {
			String hql = "from ExamAnswer where eaPrimaryKey.examId = ? and questionGenId = ?";
			eaList = (List<IExamAnswer>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in getExamAnsw(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return eaList;
	}

	/*
	 * This method is called to get exam answer by exam id and question gen id.
	 */
	@SuppressWarnings("unchecked")
	public List<IExamAnswer> getExamAnswOrderByAnswPresOrd(Object[] params) throws AKTException {
		List<IExamAnswer> eaList = null;
		try {
			String hql = "from ExamAnswer where eaPrimaryKey.examId = ? and questionGenId = ? order by answerPresentedOrder asc";
			eaList = (List<IExamAnswer>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in getExamAnswOrderByAnswPresOrd(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return eaList;
	}
	
	@SuppressWarnings("unchecked")
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenIds(Integer examId, List<Integer> questionGenIds) throws AKTException {
		List<IExamAnswer> eaList = null;
		try {
			eaList = getHibernateTemplate().getSessionFactory().openSession().createCriteria(ExamAnswer.class)
											.add(Restrictions.eq("eaPrimaryKey.examId", examId))
											.add(Restrictions.in("questionGenId", questionGenIds))
											.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in getExamAnswOrderByAnswPresOrd(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return eaList;
	}
	
	/*
	 * This method is called to load completed exams by application id
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadCompletedExams(Object[] params) throws AKTException {
		List<IExam> examList = null;
		List<IExam> examSecList = null;
		try {
			String hql = "from Exam where applicationId = ? and passFailIndicator != ? order by examEndTime desc";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
			
			if (examList == null || examList.isEmpty()) {
				String hql1 = "from ExamSecondary where applicationId = ? and passFailIndicator != ? order by examEndTime desc";
				examSecList = (List<IExam>) getHibernateTemplate().find(hql1, params);
				
				examList.addAll(examSecList);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadCompletedExams(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to get exam by application id, test id, no end time and pass fail indicator is blank
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadByAppIdAndTestId(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where applicationId = ? and testId = ? and examEndTime = ? and passFailIndicator = ? order by lastModUserTime desc";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByAppIdAndTestId(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to load distinct tests
	 */
	@SuppressWarnings("unchecked")
	public List<String> loadDistinctTests() throws AKTException {
		List<String> strList = null;
		try {
			String hql = "Select distinct testId from Exam";
			strList = (List<String>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadDistinctTests() method in ExamPersistenceImpl class", e);
		}
		return strList;
	}

	/*
	 * This method is called to get exams by testId
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadExamsByTestId(Object param) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where testId = ? and passFailIndicator in ('P', 'F')";
			examList = (List<IExam>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadExamsByTestId(Object param) method in ExamPersistenceImpl class", e);
		}
		return examList; 
	}

	/*
	 * This method is called to load all the outstanding exams between a date range to generate report
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadOutstandingExams(Object[] params) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where (completionReasonCode = ? or  completionReasonCode = ?) and (examStartTime between ? and ?) and officeId = ?";
			examList = (List<IExam>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadOutstandingExams(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to generate reports for records that did not get updated at EASE end
	 */
	@SuppressWarnings("unchecked")
	public List<AKTSResults> loadEASEExceptionRecords(Object[] params) throws AKTException {
		List<AKTSResults> resList = null;
		try {
			String hql = "from AKTSResults where resultStatusCode != ? and resultStatusCode != ? and officeId = ? order by resultSentTimestamp desc";
			resList = (List<AKTSResults>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadEASEExceptionRecords(Object[] params) method in ExamPersistenceImpl class", e);
		}
		return resList;
	}

	/*
	 * This method is called to update the exception report record with the status code to indicate it has been manually updated in the EASE DB
	 */
	@SuppressWarnings("unchecked")
	public void updateExceptionRep(Object param) throws AKTException {
		try {
			String hql = "from AKTSResults where sysId = ?";
			List<AKTSResults> results = (List<AKTSResults>) getHibernateTemplate().find(hql, param);
			for(AKTSResults result: results) {
				result.setResultStatusCode(Constant.EASE_PROCESSED);
				getHibernateTemplate().saveOrUpdate(result);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in updateExceptionRep(Object param) method in ExamPersistenceImpl class", e);
		}
	}

	public void save(List<IExamQuestion> examQuestionList) throws AKTException {
		try {
			for(IExamQuestion eq: examQuestionList) {
				getHibernateTemplate().save(eq);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(List<IExamQuestion> examQuestionList) method in ExamPersistenceImpl class", e);
		}
	}

	public void saveExamAnsList(List<IExamAnswer> examAnswerList) throws AKTException {
		try {
			for(IExamAnswer ea: examAnswerList) {
				getHibernateTemplate().save(ea);
			}
		} catch (Exception e) {
			throw new AKTException("Exception in saveExamAnsList(List<IExamAnswer> examAnswerList) method in ExamPersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to load exams by application id that have not started yet.
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadExamsNotStartedByAppId(Object param) throws AKTException {
		List<IExam> examList = null;
		try {
			examList =  getHibernateTemplate().getSessionFactory().openSession().createCriteria(Exam.class)
			.add(Restrictions.eq("applicationId", param)).add(Restrictions.eq("examStartTime", Constant.defaultDate))
			.add(Restrictions.eq("examEndTime", Constant.defaultDate)).add(Restrictions.eq("passFailIndicator", Constant.SINGLE_SPACE)).list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadExamsNotStartedByAppId() method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to return a list of paused exams based on a list of application ids.
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadPausedExamsByAppIds(List<Integer> appIds) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where completionReasonCode = 'S' and applicationId in (:ids)";
			Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(hql);
			query.setParameterList("ids", appIds);
			examList = query.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadPausedExamsByAppIds(List<Integer> appIds) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}

	/*
	 * This method is called to return a list of exams based on a list of application ids.
	 */
	@SuppressWarnings("unchecked")
	public List<IExam> loadAllExamsByAppIds(List<Integer> appIds) throws AKTException {
		List<IExam> examList = null;
		try {
			String hql = "from Exam where applicationId in (:ids)";
			Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(hql);
			query.setParameterList("ids", appIds);
			examList = query.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadPausedExamsByAppIds(List<Integer> appIds) method in ExamPersistenceImpl class", e);
		}
		return examList;
	}
	
	/*
	 * This method is called to get exam question record by exam id ordered by last mod user time.
	 */
	@SuppressWarnings("unchecked")
	public List<ExamQuestion> getExamQuesOrderedByModTime(Object param) throws AKTException {
		List<ExamQuestion> examQuesList = null;
		try {
			String hql = "from ExamQuestion where eqPrimaryKey.examId = ? order by lastModUserTime desc";
			examQuesList = (List<ExamQuestion>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in getExamQuesOrderedByModTime(Object param) method in ExamPersistenceImpl class", e);
		}
		return examQuesList;
	}
}
