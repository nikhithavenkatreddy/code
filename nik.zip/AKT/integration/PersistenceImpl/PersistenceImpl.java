package gov.ca.dmv.AKT.integration.PersistenceImpl;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class PersistenceImpl extends DMVHibernateSupport implements IPersistence {

	/*
	 * This method is called to retrieve a list of objects based on the attributes set on the object passed as a parameter to the method.
	 */
	@SuppressWarnings("unchecked")
	public List loadAll(Class entityClass) throws AKTException {
		try {
			return (List) getHibernateTemplate().loadAll(entityClass);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAll(Object object) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to retrieve a list of objects based on the attributes set on the object passed as a parameter to the method.
	 */
	@SuppressWarnings("unchecked")
	public List findByExample(Object object) throws AKTException {
		try {
			return (List) getHibernateTemplate().findByExample(object);
		}
		catch(Exception e) {
			throw new AKTException("Exception in findByExample(Object object) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to retrieve a list of objects based on the id.
	 */
	@SuppressWarnings("unchecked")
	public Object findById(Object obj, Object Id) throws AKTException {
		try {
			obj = getHibernateTemplate().getSessionFactory().openSession().get(obj.getClass(), (Serializable)Id);
			return obj;
		}
		catch(Exception e) {
			throw new AKTException("Exception in findById(Object obj, Object Id) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to update a record.
	 */
	public void update(Object object) throws AKTException {
		try {
			getHibernateTemplate().update(object);
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object object) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to update a list of records.
	 */
	public void updateList(List objects) throws AKTException {
		try {
			for(Object object: objects) {
				getHibernateTemplate().update(object);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in updateList(List objects) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to delete a list of records.
	 */
	public void deleteList(List objects) throws AKTException {
		try {			
			getHibernateTemplate().deleteAll(objects);			
		}
		catch(Exception e) {
			throw new AKTException("Exception in deleteList(List objects) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to insert a new record.
	 */
	public void save(Object object) throws AKTException {
		try {
			getHibernateTemplate().save(object);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(Object object) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to insert a list of new records.
	 */
	public void saveList(List objects) throws AKTException {
		Object temp = null;
		try {
			for(Object object: objects) {
				temp = object;
				getHibernateTemplate().save(object);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveList(List objects) method in PersistenceImpl class with " + temp.toString(), e);
		}
	}
	
	/*
	 * This method is called to insert or update a list of new records.
	 */
	public void saveOrUpdateList(List objects) throws AKTException {
		try {
			for(Object object: objects) {
				getHibernateTemplate().saveOrUpdate(object);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveOrUpdateList(List objects) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to insert or update a list of new records.
	 */
	public void saveOrUpdate(Object object) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(object);
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveOrUpdate(Object object) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to load records with conditions set for the 'where' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithConditionsAndOrderBy(Class obj, Map<String, Object> params, List<String> orders) throws AKTException {
		try {
			Criteria criteria = getHibernateTemplate().getSessionFactory().openSession().createCriteria(obj);
			Set set = params.entrySet();
			Iterator i = set.iterator();
			while(i.hasNext()) {
				Map.Entry<String, Object> param = (Map.Entry<String, Object>) i.next();
				criteria.add(Restrictions.eq(param.getKey(), param.getValue()));
			}
			if(orders != null) {
				for(String str: orders) {
					criteria.addOrder(Order.desc(str));
				}
			}
			return criteria.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadWithConditionsAndOrderBy(Object obj, Map<String, Object> params, List<String> orders) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to load records with conditions set for the 'where' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithLikeConditionsAndOrderBy(Class obj, Map<String, Object> params, List<String> orders) throws AKTException {
		try {
			Criteria criteria = getHibernateTemplate().getSessionFactory().openSession().createCriteria(obj);
			Set set = params.entrySet();
			Iterator i = set.iterator();
			while(i.hasNext()) {
				Map.Entry<String, Object> param = (Map.Entry<String, Object>) i.next();
				criteria.add(Restrictions.like(param.getKey(), param.getValue()));
			}
			if(orders != null) {
				for(String str: orders) {
					criteria.addOrder(Order.desc(str));
				}
			}
			return criteria.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadWithLikeConditionsAndOrderBy(Object obj, Map<String, Object> params, List<String> orders) method in PersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to load records with conditions set for the 'where' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithLikeConditionsIgnoreCaseAndOrderBy(Class obj, Map<String, Object> params, List<String> orders) throws AKTException {
		try {
			Criteria criteria = getHibernateTemplate().getSessionFactory().openSession().createCriteria(obj);
			Set set = params.entrySet();
			Iterator i = set.iterator();
			while(i.hasNext()) {
				Map.Entry<String, Object> param = (Map.Entry<String, Object>) i.next();
				String value = (String)param.getValue();
				if (value == null || value.isEmpty()) {
					// do not add condition in this case.
				}
				else if (value.contains(Constant.PER)) {
					criteria.add(Restrictions.ilike(param.getKey(), param.getValue()));
				}
				else {
					criteria.add(Restrictions.eq(param.getKey(), param.getValue()));
				}
			}
			if(orders != null) {
				for(String str: orders) {
					criteria.addOrder(Order.desc(str));
				}
			}
			return criteria.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadWithLikeConditionsIgnoreCaseAndOrderBy(Object obj, Map<String, Object> params, List<String> orders) method in PersistenceImpl class", e);
		}
	}
	/*
	 * This method is called to return a list of audit records based on a list of ids.
	 */
	@SuppressWarnings("unchecked")
	public List<Audit> loadAuditsByIds(List<String> idList) throws AKTException {
		List<Audit> auditList = null;
		try {
			String hql = "from Audit where key in (:ids)";
			Query query = getHibernateTemplate().getSessionFactory().openSession().createQuery(hql);
			query.setParameterList("ids", idList);
			auditList = query.list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAuditsByIds(List<Integer> idList) method in PersistenceImpl class", e);
		}
		return auditList;
	}
}
