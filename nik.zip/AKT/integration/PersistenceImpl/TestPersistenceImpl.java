package gov.ca.dmv.AKT.integration.PersistenceImpl;

import java.util.List;

import org.hibernate.criterion.Restrictions;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.TestPersistence;

public class TestPersistenceImpl extends DMVHibernateSupport implements TestPersistence{
	
	/*
	 * This method is called to load test by test id
	 */
	@SuppressWarnings("unchecked")
	public List<Test> loadByTestId(Object param) throws AKTException {
		List<Test> testList = null;
		try {
			String hql = "from Test where testId = ?";
			testList = (List<Test>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByTestId(Object param) method in TestPersistenceImpl class");
		}
		return testList;
	}

	/*
	 * This method is called to load the quick pass fail event by test id, order by timestamp descending
	 */
	@SuppressWarnings("unchecked")
	public List<QuickPassFailEvent> load(Object param) throws AKTException {
		List<QuickPassFailEvent> qpfList = null;
		try {
			String hql = "from QuickPassFailEvent where testId = ? order by timestamp desc";
			qpfList = (List<QuickPassFailEvent>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object param) method in TestPersistenceImpl class", e);
		}
		return qpfList;
	}

	//This method is called to load the test plans by test id//
	@SuppressWarnings("unchecked")
	public List<TestPlan> loadTestPlan(Object param) {
		String hql = "from TestPlan where tpPrimaryKey.testId = ?";
		return (List<TestPlan>) getHibernateTemplate().find(hql, param);
	}

	/*
	 * This method is called to get test name in corresponding language by test id and language id
	 */
	@SuppressWarnings("unchecked")
	public List<TestLang> load(Object[] params) throws AKTException {
		List<TestLang> testLangList = null;
		try {
			String hql = "from TestLang where tlPrimaryKey.testId = ? and langId = ?";
			testLangList = (List<TestLang>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object[] params) method in TestPersistenceImpl class", e);
		}
		return testLangList;
	}

	/*
	 * This method is called to a load a list of test eligible for quick pass fail.
	 */
	@SuppressWarnings("unchecked")
	public List<Test> loadQPFList(Object[] params) throws AKTException {
		List<Test> testList = null;
		try {
			String hql = "from Test where quickPassFailInd = ? and testStatusCode != ?";
			testList = (List<Test>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQPFList(Object[] params) method in TestPersistenceImpl class", e);
		}
		return testList;
	}
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to load test by ease test id.
	 */
	public List<Test> loadByEaseTestId(Object param) throws AKTException {
		List<Test> testList = null;
		try {
			String hql = "from Test where easeTestId = ?";
			testList = (List<Test>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByEaseTestId(Object param) method in TestPersistenceImpl class", e);
		}
		return testList; 
	}

	/*
	 * This method is called to load a list of tests based on the question id
	 */
	@SuppressWarnings("unchecked")
	public List<Test> loadByQuestionId(Object[] params) throws AKTException {
		List<Test> testList = null;
		try {
			String hql = "from Test where testId in " +
					"(Select qlPrimaryKey.testId from QuestionList where qlPrimaryKey.questionId = ? " +
					"and questionStatus = ?)";
			testList = (List<Test>) getHibernateTemplate().find(hql,params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByQuestionId(Object[] params) method in TestPersistenceImpl class", e);
		}
		return testList;
	}

	/*
	 * This method is called to submit the quick pass fail choices made by the HQ user to set the tests with 
	 * quick pass fail flag on/off
	 */
	public void saveQPFEvent(QuickPassFailEvent qpf) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(qpf);
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveQPFEvent(QuickPassFailEvent qpf) method in TestPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load the sign test
	 */
	@SuppressWarnings("unchecked")
	public List<Test> loadSignTest(Object param) throws AKTException {
		List<Test> testList = null;
		try {
			String hql = "from Test where signTestFlag = ? order by lastModUserTime desc";
			testList = (List<Test>) getHibernateTemplate().find(hql,param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadSignTest(Object param) method in TestPersistenceImpl class", e);
		}
		return testList; 
	}

	/*
	 * This method is called to save the test
	 */
	public void save(Test test) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(test);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(Test test) method in TestPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load all test plans
	 */
	@SuppressWarnings("unchecked")
	public List<TestPlan> loadAllTestPlans() throws AKTException {
		List<TestPlan> testPlanList = null;
		try {
			String hql = "from TestPlan";
			testPlanList = (List<TestPlan>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllTestPlans() method in TestPersistenceImpl class", e);
		}
		return testPlanList;
	}

	/*
	 * This method is called to load all active test lang
	 */
	@SuppressWarnings("unchecked")
	public List<TestLang> loadAllTestLang(Object param) throws AKTException {
		List<TestLang> testLangList = null;
		try {
			String hql = "from TestLang where testLangStatus = ?";
			testLangList = (List<TestLang>) getHibernateTemplate().find(hql,param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllTestLang(Object param) method in TestPersistenceImpl class", e);
		}
		return testLangList;
	}
	
}
