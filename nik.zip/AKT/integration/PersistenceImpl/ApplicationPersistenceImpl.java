package gov.ca.dmv.AKT.integration.PersistenceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;
import gov.ca.dmv.AKT.integration.BeansImpl.ApplicationSecondary;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.BeansImpl.VaultSecondary;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.ApplicationPersistence;

public class ApplicationPersistenceImpl extends DMVHibernateSupport implements ApplicationPersistence {

	//This method is called to load application by vault id//
	@SuppressWarnings("unchecked")
	public List<Application> loadByVaultId(Object param) throws AKTException {
		List<Application> appList = null;
		try {
			String hql = "from Application where vaultId = ?";
			appList = (List<Application>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByVaultId(Object param) method in ApplicationPersistenceImpl", e);
		}
		return appList;
	}

	/*
	 * This method is called to update the akt status ind for exam history by application id and ease test id
	 */
	@SuppressWarnings("unchecked")
	public void update(Object[] params, String aktStatusIndicator, Date aktUpdateTimestamp) throws AKTException {
		try {
			String hql = "from ExamHistory where applicationId = ? and easeTestId = ?";
			List<IExamHistory> examHistoryList = (List<IExamHistory>) getHibernateTemplate().find(hql, params);
			for(IExamHistory examHistory: examHistoryList) {
				examHistory.setAktStatusIndicator(aktStatusIndicator);
				examHistory.setAktUpdatedTimestamp(aktUpdateTimestamp);
				getHibernateTemplate().saveOrUpdate(examHistory);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object[] params, String aktStatusIndicator, Date aktUpdateTimestamp method in ApplicationPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to update the application with force fail set to true.
	 */
	@SuppressWarnings("unchecked")
	public void update(Object param, String forceFailIndicator) throws AKTException {
		try {
			String hql = "from Application where applicationId = ?";
			List<Application> applicationList = (List<Application>) getHibernateTemplate().find(hql, param);
			for(IApplication application: applicationList) {
				application.setForceFailFlag(forceFailIndicator);
				getHibernateTemplate().saveOrUpdate(application);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object param, String forceFailIndicator) method in ApplicationPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to save/update application record in the application table.
	 */
	public void saveApplication(IApplication application) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(application);
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveApplication(Application application) method in ApplicationPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load application from the application table by application id.
	 */
	@SuppressWarnings("unchecked")
	public List<Application> load(Object param) throws AKTException {
		List<Application> appList = null;
		try {
			String hql = "from Application where applicationId = ?";
			appList = (List<Application>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object param) method in ApplicationPersistenceImpl class", e);
		}
		return appList;
	}

	@SuppressWarnings("unchecked")
	public List<IExamHistory> loadExamHistoryByAppId(Object param) throws AKTException {
		List<IExamHistory> ehList = null;
		try {
			String hql = "from ExamHistory where applicationId = ?";
			ehList = (List<IExamHistory>) getHibernateTemplate().find(hql, param); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadExamHistoryByAppId(Object param) method in ApplicationPersistenceImpl class", e);
		}
		return ehList;
	}

	@SuppressWarnings("unchecked")
	public List<IApplication> loadTodaysApps(String officeId, String appType) throws AKTException {
		List<IApplication> appList = null;
		java.util.Date tomorrow = Constant.getTomorrowsDate();
	    java.util.Date yesterday = Constant.getYesterdaysDate();
		try {
			appList = getHibernateTemplate().getSessionFactory().openSession().createCriteria(Application.class)
			.add(Restrictions.conjunction().add(Restrictions.lt("applicationTimestamp", tomorrow))
					.add(Restrictions.gt("applicationTimestamp", yesterday)).add(Restrictions.eq("officeId", officeId))
					.add(Restrictions.eq("applicationType", appType)))
					.addOrder(Order.desc("applicationTimestamp")).list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadTodaysApps() method in ApplicationPersistenceImpl class", e);
		}
		return appList;
	}

	/*
	 * This method is called to get a list of field office type applications (no ds/ol apps) based on the office id and date range (inclusive).
	 */
	@SuppressWarnings("unchecked")
	public List<IApplication> loadAppsByOfficeIdAndDateRange(String officeId, Date fromDate, Date toDate, String appType) throws AKTException {
		List<IApplication> appList = null;
		try {
			appList = getHibernateTemplate().getSessionFactory().openSession().createCriteria(Application.class)
			.add(Restrictions.conjunction().add(Restrictions.le("applicationTimestamp", toDate))
					.add(Restrictions.ge("applicationTimestamp", fromDate)).add(Restrictions.eq("officeId", officeId))
					.add(Restrictions.eq("applicationType", appType)))
					.addOrder(Order.desc("applicationTimestamp")).list();
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAppsByOfficeIdAndDateRange(String officeId, Date fromDate, Date toDate) method in ApplicationPersistenceImpl class", e);
		}
		return appList;
	}

	/*
	 * This method is called to get a list of todays' or past applications based on the app type (across the office ids) and list of vaults.
	 */
	@SuppressWarnings("unchecked")
	public List<IApplication> loadAppsByAppTypeAndVaultList(boolean today, String appType, String dlNum, String lastName, Date fromDate, Date toDate) throws AKTException {
		List<IApplication> appList = null;
		String app;
		String vault;
		if(today) {
			app = new Application().getClass().getName();
			vault = new Vault().getClass().getName();
		} else {
			app = new ApplicationSecondary().getClass().getName();
			vault = new VaultSecondary().getClass().getName();
		}
		String hql = "select a from " + app + " a, " + vault + " v where v.vaultId = a.vaultId and a.applicationType = ? and v.lastModUserTime between ? and ?";
		List<Object> parList = new ArrayList<Object>();
		parList.add(appType);
		parList.add(fromDate);
		parList.add(toDate);
		if(dlNum != null && !dlNum.isEmpty()) {
			hql = hql + " and v.dlNumber = ?";
			parList.add(dlNum);
		}
		if(lastName != null && !lastName.isEmpty()) {
			hql = hql + " and v.applicationLastName like ?";
			parList.add(lastName);
		}
		Object[] param = parList.toArray(new Object[parList.size()]);
		try {
			appList = (List<IApplication>) getHibernateTemplate().find(hql, param);
		} catch(Exception e) {
			throw new AKTException("Exception in loadAppsByAppTypeAndVaultList(boolean today, String appType, String dlNum, String lastName, Date fromDate, Date toDate) method in ApplicationPersistenceImpl class", e);
		}
		if(appList == null) {
			appList = new ArrayList<IApplication>();
		}
		return appList;
	}
}