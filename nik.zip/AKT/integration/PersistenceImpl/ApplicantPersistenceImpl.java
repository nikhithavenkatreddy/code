package gov.ca.dmv.AKT.integration.PersistenceImpl;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.BeansImpl.VaultSecondary;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.ApplicantPersistence;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class ApplicantPersistenceImpl extends DMVHibernateSupport implements ApplicantPersistence {

	/*
	 * This method is called to load vault by vault id.
	 */
	@SuppressWarnings("unchecked")
	public List<Vault> load(Object param) throws AKTException {
		List<Vault> vaultList = null;
		try {
			String hql = "from Vault where vaultId = ?";
			vaultList = (List<Vault>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object param) method in ApplicantPersistenceImpl class", e);
		}
		return vaultList;
	}

	/*
	 * This method is called to load vault by DL and order by vault timestamp descending
	 */
	@SuppressWarnings("unchecked")
	public List<Vault> loadByDL(Object param) throws AKTException {
		List<Vault> vaultList = null;
		try {
			String hql = "from Vault where dlNumber = ? order by vaultTimestamp desc";
			vaultList = (List<Vault>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByDL(Object param) method in ApplicantPersistenceImpl", e);
		}
		return vaultList;
	}
	
	/*
	 * This method is called to load vault by DL and vault timestamp
	 */
	@SuppressWarnings("unchecked")
	public List<Vault> loadByDLAndVaultTstamp(Object[] params) throws AKTException {
		List<Vault> vaultList = null;
		try {
			String hql = "from Vault where dlNumber = ? and vaultTimestamp = ?";
			vaultList = (List<Vault>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByDLAndVaultTstamp(Object[] params) method in ApplicantPersistenceImpl class", e);
		}
		return vaultList; 
	}

	/*
	 * This method is called to save vault record in the vault table.
	 */
	public void save(IVault vault) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(vault);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(Vault vault) method in ApplicantPersistenceImpl class", e);
		}
	}
	
	/*
	 * This method is called to partial-search today or past vault records based on DL # and Last name
	 */
	@SuppressWarnings("unchecked")
	public List<IVault> loadByDLLastNameAndDateRange(String dlNum, String lastName, Date fromDate, Date toDate, boolean today) throws AKTException {
		List<IVault> vaultList = null;
		Object vault;
		if(today) {
			vault = new Vault();
		} else {
			vault = new VaultSecondary();
		}
		try {
			Criteria criteria = getHibernateTemplate().getSessionFactory().openSession().createCriteria(vault.getClass());
			if (dlNum != null && !dlNum.isEmpty()) {
				criteria.add(Restrictions.eq("dlNumber", dlNum));
			}
			criteria.add(Restrictions.ilike("applicationLastName", lastName));
			criteria.add(Restrictions.le("vaultTimestamp", toDate)).add(Restrictions.ge("vaultTimestamp", fromDate)).addOrder(Order.desc("vaultTimestamp"));
			vaultList = criteria.list();
		} catch(Exception e) {
			throw new AKTException("Exception in loadByDLAndLastName(Object param1, Object param2) method in ApplicantPersistenceImpl class", e);
		}
		return vaultList;
	}
	
	/*
	 * This method is called to get a list of vaults
	 */
	@SuppressWarnings("unchecked")
	public List<Vault> loadAllVaults(Object[] params) throws AKTException {
		List<Vault> vaultList = null;
		try {
			StringBuffer hql = new StringBuffer();
			hql.append("from Vault as vault ");
			hql.append("where vault.vaultId in (select vaultId from Application as app where app.officeId = ? and app.applicationType = ? )");
			vaultList = (List<Vault>) getHibernateTemplate().find(hql.toString(), params);
		} catch(Exception e) {
			throw new AKTException("Exception in loadAllVaults(Object[] params) method in ApplicantPersistenceImpl class", e);
		}
		return vaultList;
	}
}
