package gov.ca.dmv.AKT.integration.PersistenceImpl;

import java.util.List;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.SearchPersistence;

public class SearchPersistenceImpl extends DMVHibernateSupport implements SearchPersistence {

	@SuppressWarnings("unchecked")
	public List<QuestionLang> load(Object param) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where changeReviewStatusCode <> 'D' and questionId in "
					+ "(Select qlPrimaryKey.questionId from QuestionList where qlPrimaryKey.categoryId = ?)";
			quesLangList = (List<QuestionLang>)getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object param) method in SearchPersistenceImpl class", e);
		}
		return quesLangList; 
	}

	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadForTest(Object param) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where changeReviewStatusCode <> 'D' and questionId in "
					+ "(Select qlPrimaryKey.questionId from QuestionList where qlPrimaryKey.testId = ?)";
			quesLangList = (List<QuestionLang>)getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadForTest(Object param) method in SearchPersistenceImpl class", e);
		}
		return quesLangList;
	}
	
	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadByTestAndCategory(Object[] params) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where changeReviewStatusCode <> 'D' and questionId in "
					+ "(Select qlPrimaryKey.questionId from QuestionList where qlPrimaryKey.categoryId = ? and qlPrimaryKey.testId = ?)";
			quesLangList = (List<QuestionLang>)getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByTestAndCategory(Object[] params) method in SearchPersistenceImpl class", e);
		}
		return quesLangList;
	}

	//This method is called to load active questions based on the test id//
	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadActiveQuestions(Object[] params) {
		String hql = "from QuestionLang where langId = ? and questionLangStatus = ? and questionId in (Select questionId from Question where questionStatus = ? and questionId in (Select qlPrimaryKey.questionId from QuestionList where questionStatus = ? and qlPrimaryKey.categoryId = ? and qlPrimaryKey.testId = ?))";
		return (List<QuestionLang>)getHibernateTemplate().find(hql, params);
	}

	
}
