package gov.ca.dmv.AKT.integration.PersistenceImpl;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.ThresholdDictionary;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.MiscPersistence;

import java.util.List;

public class MiscPersistenceImpl extends DMVHibernateSupport implements MiscPersistence {

	@SuppressWarnings("unchecked")
	//Called by the LangBOList to load all the languages//
	public List<Lang> load() throws AKTException {
		List<Lang> langList = null;
		try {
			String hql = "from Lang ORDER BY displayOrder";
			langList = (List<Lang>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load() method in MiscPersistenceImpl class", e);
		}
		return langList;
	}
	
	@SuppressWarnings("unchecked")
	//This method is called to load language by language id code//
	public List<Lang> loadByLanguageIdCode(Object param) throws AKTException {
		List<Lang> langList = null;
		try {
			String hql = "from Lang where langId = ?";
			langList = (List<Lang>) getHibernateTemplate().find(hql,param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByLanguageIdCode(Object param) method in MiscPersistenceImpl class", e);
		}
		return langList;
	}

	/*
	 * This method is called to get the threshold value for a threshold name
	 */
	@SuppressWarnings("unchecked")
	public List<ThresholdDictionary> loadThreshold(Object param) throws AKTException {
		List<ThresholdDictionary> tdList = null;
		try {
			String hql = "from ThresholdDictionary where thresholdName = ?";
			tdList = (List<ThresholdDictionary>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadThreshold(Object param) method in MiscPersistenceImpl class", e);
		}
		return tdList;
	}

	/*
	 * This method is called to save the ease received string
	 */
	public void saveEaseReceivedString(IEaseInboundMessage message) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(message);
		}
		catch(Exception e) {
			throw new AKTException("Exception in saveEaseReceivedString(EaseInboundMessage message) method in MiscPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load ease inbound messaged based on the string received from ease
	 */
	@SuppressWarnings("unchecked")
	public List<IEaseInboundMessage> loadEaseInboundMessage(Object param) throws AKTException {
		List<IEaseInboundMessage> msgList = null;
		try {
			String hql = "from EaseInboundMessage where easeMessageId = ?";
			msgList = (List<IEaseInboundMessage>) getHibernateTemplate().find(hql, param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadEaseInboundMessage(Object param) method in MiscPersistenceImpl class", e);
		}
		return msgList;
	}

	@SuppressWarnings("unchecked")
	public List<WorkstationMap> loadAllWorkstationMap() throws AKTException {
		List<WorkstationMap> wmList = null;
		try {
			String hql = "from WorkstationMap";
			wmList = (List<WorkstationMap>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllWorkstationMap() method in MiscPersistenceImpl class", e);
		}
		return wmList;
	}
	
	/*
	 * This method is called to get all threshold records
	 */
	@SuppressWarnings("unchecked")
	public List<ThresholdDictionary> loadAllThreshold() throws AKTException {
		List<ThresholdDictionary> tdList = null;
		try {
			String hql = "from ThresholdDictionary";
			tdList = (List<ThresholdDictionary>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllThreshold() method in MiscPersistenceImpl class", e);
		}
		return tdList;
	}
}
