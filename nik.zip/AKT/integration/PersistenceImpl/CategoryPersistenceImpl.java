package gov.ca.dmv.AKT.integration.PersistenceImpl;


import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.CategoryPersistence;

import java.util.List;

public class CategoryPersistenceImpl extends DMVHibernateSupport implements CategoryPersistence {
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to get a list of question list by question id
	 */
	public List<QuestionList> load(Object[] params) throws AKTException
	{
		List<QuestionList> qlColl = null;
		try {
			String hql = "from QuestionList where qlPrimaryKey.questionId = ? and questionStatus = ?";
			qlColl = (List<QuestionList>) getHibernateTemplate().find(hql,params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load(Object[] params) method in CategoryPersistenceImpl class", e);
		}
		return qlColl;
	}
	
	@SuppressWarnings("unchecked")
	public List<QuestionList> loadByQuestionIdAndQuestionStatus(Object[] params)
	{
		String hql = "from QuestionList where qlPrimaryKey.questionId = ? and questionStatus = ?";
		return (List<QuestionList>) getHibernateTemplate().find(hql,params);
	}
	
	@SuppressWarnings("unchecked")
	public List<Category> load2(Object param)
	{
		String hql = "from Category where categoryId = ?";
		return (List<Category>) getHibernateTemplate().find(hql,param);
	}
	
	public void save(QuestionList questionList) throws AKTException {
		try {
			getHibernateTemplate().saveOrUpdate(questionList);
		}
		catch(Exception e) {
			throw new AKTException("Exception in save(QuestionList questionList) method in CategoryPersistenceImpl class", e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void update(Object param, QuestionList ql) throws AKTException {
		try {
			String hql = "from QuestionList where qlPrimaryKey.questionId = ?";
			List<QuestionList> questionListCollection2 = (List<QuestionList>) getHibernateTemplate().find(hql,param);
			for(QuestionList ql2: questionListCollection2) 
			{
				ql2.setQuestionStatus(Constant.INACTIVE);
				ql2.setLastModUsername(ql.getLastModUsername());
				ql2.setLastModUserTime(ql.getLastModUserTime());
				getHibernateTemplate().saveOrUpdate(ql2);
			}
		}
		catch(Exception e) {
			throw new AKTException("Exception in update(Object param, QuestionList ql) method in CategoryPersistenceImpl class", e);
		}
	}

	/*
	 * This method is called to load categories by question id
	 */
	@SuppressWarnings("unchecked")
	public List<Category> loadByQuestionId(Object[] params) throws AKTException {
		List<Category> catList = null;
		try {
			String hql = "from Category where categoryId in " +
					"(Select qlPrimaryKey.categoryId from QuestionList where qlPrimaryKey.questionId = ? " +
					"and questionStatus = ?)";
			catList = (List<Category>) getHibernateTemplate().find(hql,params); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByQuestionId(Object[] params) method in CategoryPersistenceImpl class", e);
		}
		return catList;
	}
	
	//This method is called to load categories by question id//
	@SuppressWarnings("unchecked")
	public List<TestPlan> loadByTestId(Object[] params) throws AKTException {
		List<TestPlan> testPlanList = null;
		try {
			String hql = "from TestPlan where tpPrimaryKey.testId = ?";
			testPlanList = (List<TestPlan>) getHibernateTemplate().find(hql,params); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByTestId(String testId) method in CategoryPersistenceImpl class", e);
		}
		return testPlanList;
	}
}
