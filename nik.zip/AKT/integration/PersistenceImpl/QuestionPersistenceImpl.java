package gov.ca.dmv.AKT.integration.PersistenceImpl;

import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.BeansImpl.Question;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;
import gov.ca.dmv.AKT.integration.Hibernate.DMVHibernateSupport;
import gov.ca.dmv.AKT.integration.Persistence.QuestionPersistence;

public class QuestionPersistenceImpl extends DMVHibernateSupport implements QuestionPersistence {

	@SuppressWarnings("unchecked")
	//This method is called to load the list of all handbook references//
	public List<HandbookRef> load() throws AKTException {
		List<HandbookRef> hbList = null;
		try {
			String hql = "from HandbookRef";
			hbList = (List<HandbookRef>) getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in load() method in QuestionPersistenceImpl class", e);
		}
		return hbList;
	}
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to load handbook reference by handbook reference
	 */
	public List<HandbookRef> loadByHandbookRef(Object[] params) throws AKTException {
		List<HandbookRef> hbList = null;
		try {
			String hql = "from HandbookRef where hrPrimaryKey.handbookRef = ? and hrPrimaryKey.langId = ?";
			hbList = (List<HandbookRef>) getHibernateTemplate().find(hql,params); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByHandbookRef(Object[] params) method in QuestionPersistenceImpl class", e);
		}
		return hbList;
	}
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to load all question langs by question lang id and last mod user time
	 */
	public List<QuestionLang> loadByQuestionLangIdAndLastModUserTime(Object[] params) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where questionLangId = ? and lastModUserTime = ?";
			quesLangList = (List<QuestionLang>) getHibernateTemplate().find(hql,params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByQuestionLangIdAndLastModUserTime(Object[] params) method in QuestionPersistenceImpl class", e);
		}
		return quesLangList;
	}
	
	public void save(QuestionList questionList) {
		getHibernateTemplate().saveOrUpdate(questionList);
	}
	
	@SuppressWarnings("unchecked")
	//**This method is called to update answers by question gen id in AKT140**//
	public void updateByQuestionGenId(Object param) {
		String hql = "from Answer where questionGenId = ?";
		List<Answer> answerList2 = (List<Answer>) getHibernateTemplate().find(hql, param);
		for(Answer answer2: answerList2) {
			answer2.setAnswerStatus(Constant.INACTIVE);
			getHibernateTemplate().saveOrUpdate(answer2);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void update2(Object param) {
		String hql = "from Answer where answerGenId = ?";
		List<Answer> answerList2 = (List<Answer>) getHibernateTemplate().find(hql, param);
		for(Answer a: answerList2) {
			a.setAnswerStatus(Constant.INACTIVE);
			getHibernateTemplate().saveOrUpdate(a);
		}
	}

	/*
	 * This method is called to load answer by answer gen id
	 */
	@SuppressWarnings("unchecked")
	public List<Answer> loadByAnsGenId(Object param) throws AKTException {
		List<Answer> ansList = null;
		try {
			String hql = "from Answer where answerGenId = ?";
			ansList = (List<Answer>) getHibernateTemplate().find(hql,param); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadByAnsGenId(Object param) method in QuestionPersistenceImpl class", e);
		}
		return ansList;
	}

	/*
	 * This method is called to get the list of all parent question ids.
	 */
	@SuppressWarnings("unchecked")
	public List<String> loadAllQuestionIds() throws AKTException {
		List<String> strList = null;
		try {
			String hql = "Select questionId from Question";
			strList = (List<String>)getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllQuestionIds() method in QuestionPersistenceImpl class", e);
		}
		return strList;
	}
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to load question lang by question lang id (active or inactive)
	 */
	public List<QuestionLang> loadQuesLang(Object param) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where questionLangId = ? and changeReviewStatusCode <> 'D'";
			quesLangList = (List<QuestionLang>) getHibernateTemplate().find(hql,param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQuesLang(Object param) method in QuestionPersistenceImpl class", e);
		}
		return quesLangList;
	}
	
	@SuppressWarnings("unchecked")
	/*
	 * This method is called to load question lang by question lang id (active or inactive)
	 */
	public List<QuestionLang> loadQuesLangByPartialText(Object[] params) throws AKTException {
		List<QuestionLang> quesLangList = null;
		try {
			String hql = "from QuestionLang where langId = ? and changeReviewStatusCode <> 'D' and questionText like ?";
			quesLangList = (List<QuestionLang>) getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQuesLang(Object param) method in QuestionPersistenceImpl class", e);
		}
		return quesLangList;
	}

	@SuppressWarnings("unchecked")
	public List<Question> loadAllActiveQuestions(Object param) throws AKTException {
		List<Question> quesList = null;
		try {
			String hql = "from Question where questionStatus = ?";
			quesList = (List<Question>) getHibernateTemplate().find(hql,param); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllActiveQuestions(Object param) method in QuestionPersistenceImpl class", e);
		}
		return quesList;
	}

	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadAllActiveQuestionLang(Object[] params) throws AKTException {
		List<QuestionLang> qlList = null;
		try {
			String hql = "from QuestionLang where questionLangStatus = ? and changeReviewStatusCode != ? and changeReviewStatusCode != ? and changeReviewStatusCode != ?";
			qlList = (List<QuestionLang>) getHibernateTemplate().find(hql,params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllActiveQuestionLang(Object param) method in QuestionPersistenceImpl class", e);
		}
		return qlList;
	}

	@SuppressWarnings("unchecked")
	public List<Answer> loadAllActiveAnswers(Object param) throws AKTException {
		List<Answer> ansList = null;
		try {
			String hql = "from Answer where answerStatus = ?";
			ansList = (List<Answer>) getHibernateTemplate().find(hql,param);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllActiveAnswers(Object param) method in QuestionPersistenceImpl class", e);
		}
		return ansList;
	}

	@SuppressWarnings("unchecked")
	public List<QuestionList> loadAllActiveQuesList(Object param) throws AKTException {
		List<QuestionList> quesList = null;
		try {
			String hql = "from QuestionList where questionStatus = ?";
			quesList = (List<QuestionList>) getHibernateTemplate().find(hql,param); 
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadAllActiveQuesList(Object param) method in QuestionPersistenceImpl class", e);
		}
		return quesList;
	}
	
	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadQuestionLang() throws AKTException {
		List<QuestionLang> qlList = null;
		try {
			String hql = "from QuestionLang";
			qlList = getHibernateTemplate().find(hql);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQuestionLang() method in QuestionPersistenceImpl class", e);
		}
		return qlList;
	}
	
	/*
	 * This method is called to load the active language specific question by question lang id.
	 */
	@SuppressWarnings("unchecked")
	public List<QuestionLang> loadActiveQuestionLangByQuesLangId(Object[] params) throws AKTException {
		List<QuestionLang> qlList = null;
		try {
			String hql = "from QuestionLang where questionLangId = ? and questionLangStatus = ? and changeReviewStatusCode != ? and changeReviewStatusCode != ?";
			qlList = getHibernateTemplate().find(hql, params);
		}
		catch(Exception e) {
			throw new AKTException("Exception in loadQuestionLang() method in QuestionPersistenceImpl class", e);
		}
		return qlList;
	}
}
