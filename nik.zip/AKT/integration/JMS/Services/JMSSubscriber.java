
package gov.ca.dmv.AKT.integration.JMS.Services;

import gov.ca.dmv.AKT.business.Services.ExamSeedData;
import gov.ca.dmv.AKT.business.Services.ForceFailRegistryService;
import gov.ca.dmv.AKT.constants.Constant;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

public class JMSSubscriber implements MessageListener {

	private static final Logger logger = Logger.getLogger(JMSSubscriber.class);
	private ForceFailRegistryService forceFailRegistryService;
	private ExamSeedData examSeedData;
	
	public ForceFailRegistryService getForceFailRegistryService() {
		return forceFailRegistryService;
	}

	public void setForceFailRegistryService(ForceFailRegistryService forceFailRegistryService) {
		this.forceFailRegistryService = forceFailRegistryService;
	}

	public ExamSeedData getExamSeedData() {
		return examSeedData;
	}

	public void setExamSeedData(ExamSeedData examSeedData) {
		this.examSeedData = examSeedData;
	}

	public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
            	String receivedString = ((TextMessage) message).getText();
            	
            	// Update force fail registry
            	if(receivedString.startsWith(Constant.FORCE_FAIL_ADD)) {
            		forceFailRegistryService.addForceFailRequest(Integer.parseInt(receivedString.trim().substring(Constant.ONE)));
            		if(logger.isInfoEnabled()) {
                		logger.info("Received the force fail request: " + receivedString);
                	}
            	}
            	else if(receivedString.startsWith(Constant.FORCE_FAIL_DELETE)) {
            		forceFailRegistryService.removeForceFailRequest(Integer.parseInt(receivedString.trim().substring(Constant.ONE)));
            		if(logger.isInfoEnabled()) {
                		logger.info("Received the force fail request: " + receivedString);
                	}
            	}
            	else { // Update the workstation map for Transfer Terminal 
            		String ipAddr = receivedString.substring(0, 15).trim();
            		String officeId = receivedString.substring(15, 18).trim();
            		String locatingOfficeId = receivedString.substring(18).trim();
            		examSeedData.updateWorkstationMapByIpAddr(ipAddr, officeId, locatingOfficeId);
            		if(logger.isInfoEnabled()) {
                		logger.info("Received the update workstation map request: " + receivedString);
                	}
            	}
            }
            catch (JMSException ex) {
            	logger.error(ex.getMessage(), ex);
                throw new RuntimeException(ex);
            }
        }
        else {
            throw new IllegalArgumentException("Message must be of type TextMessage");
        }		

   }
}
