
package gov.ca.dmv.AKT.integration.JMS.Services;

import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectSent;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.ancientprogramming.fixedformat4j.format.FixedFormatManager;
import com.ancientprogramming.fixedformat4j.format.impl.FixedFormatManagerImpl;

import javax.jms.Queue;
import javax.jms.ConnectionFactory;

public class JMSSender {
	
	  private JmsTemplate jmsTemplate;
	  private Queue queue;
	  private EASEObjectSent easeObjectSent;
	  private static FixedFormatManager manager = new FixedFormatManagerImpl();
	  private static final Logger logger = Logger.getLogger(JMSSender.class);
	  
	  public EASEObjectSent getEaseObjectSent() {
		return easeObjectSent;
	  }

	  public void setEaseObjectSent(EASEObjectSent easeObjectSent) {
		this.easeObjectSent = easeObjectSent;
	  }

	  public void setConnectionFactory(ConnectionFactory connectionFactory) {
	    this.jmsTemplate = new JmsTemplate(connectionFactory);
	  }

	  public void setQueue(Queue queue) {
	    this.queue = queue;
	  }

	  public void sendMesage() {
	    this.jmsTemplate.send(this.queue, new MessageCreator() {
	      public Message createMessage(Session session) throws JMSException {
	    	  String m = manager.export(easeObjectSent);
	    	  if(logger.isInfoEnabled()) {
	    	  	  if(easeObjectSent.getDlNumber().length() > 3)
		    		  logger.info("SENDING EASE THE RESULTS FOR DL# ENDING WITH: " + easeObjectSent.getDlNumber().substring((easeObjectSent.getDlNumber().length() - 4), easeObjectSent.getDlNumber().length()));
	    	  }
	    	  return session.createTextMessage(m);
	    	  //return session.createTextMessage("AKTSB1234510        TEST                       MQSTR                      01121966NYNA             0CA0NAB0YBK0NGK0N                                    448KM571207102013075110B"); 
	      }
	    });
	  }

}
