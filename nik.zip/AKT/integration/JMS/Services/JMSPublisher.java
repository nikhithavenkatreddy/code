
package gov.ca.dmv.AKT.integration.JMS.Services;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.log4j.Logger;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import javax.jms.Topic;
import javax.jms.ConnectionFactory;

public class JMSPublisher {
	
	private JmsTemplate jmsTemplate;
	private Topic topic;
	private String message;
	private static final Logger logger = Logger.getLogger(JMSPublisher.class);
	  
	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.jmsTemplate = new JmsTemplate(connectionFactory);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setTopic(Topic topic) {
	    this.topic = topic;
	}

	public void sendMesage() {
		this.jmsTemplate.send(this.topic, new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				if(logger.isInfoEnabled()) {
					logger.info("Sending request to topic: " + message);
				}
				return session.createTextMessage(message);
			}
		});
	}

}
