
package gov.ca.dmv.AKT.integration.JMS.Services;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectReceived;
import gov.ca.dmv.AKT.presentation.Controller.HQUserController;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import com.ancientprogramming.fixedformat4j.format.FixedFormatManager;  
import com.ancientprogramming.fixedformat4j.format.impl.FixedFormatManagerImpl;  

public class JMSReceiver implements MessageListener {
	//private static final Logger LOG = Logger.getLogger(JmsReceiver.class);
	private static FixedFormatManager manager = new FixedFormatManagerImpl();
	private EaseAppBusDelegate easeAppBusDelegate; 
	private static final Logger logger = Logger.getLogger(JMSReceiver.class);
	public EaseAppBusDelegate getEaseAppBusDelegate() {
		return easeAppBusDelegate;
	}

	public void setEaseAppBusDelegate(EaseAppBusDelegate easeAppBusDelegate) {
		this.easeAppBusDelegate = easeAppBusDelegate;
	}
	
	private int saveReceivedString(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/*try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
        	easeAppBusDelegate.saveReceivedString(easeAppDTO);
        	err = easeAppDTO.getErrorCode();
        	/* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}  */
		return err;
	}
	
	private int createApp(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/* try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
			easeAppBusDelegate.createApp(easeAppDTO);
			err = easeAppDTO.getErrorCode();
        	/* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}   */
		return err;
	}
	
	private int updateEaseReceivedIndicator(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/* try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
			easeAppBusDelegate.updateEaseReceivedIndicator(easeAppDTO);
			err = easeAppDTO.getErrorCode();
        	/* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}  */
		return err;
	}

	public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
            	String receivedString = ((TextMessage) message).getText();
            	if(logger.isInfoEnabled()) {
            		logger.info("RECEIVED MQ STRING FROM EASE");
            	}
                EASEObjectReceived easeObj = manager.load(EASEObjectReceived.class, receivedString);
                if(logger.isInfoEnabled()) {
                	if(easeObj.getDlNumber().length() > 3)
	            		logger.info("RECEIVED MQ STRING FROM EASE FOR DL# ENDING WITH: " + easeObj.getDlNumber().substring((easeObj.getDlNumber().length() - 4), easeObj.getDlNumber().length()));
            	}
                EaseAppDTO easeAppDTO = new EaseAppDTO();
                easeAppDTO.setReceivedString(receivedString);
                int errorCode1 = saveReceivedString(easeAppDTO);
            	if(errorCode1 == ErrorCode.NO_ERROR) {
            		easeAppDTO.create(easeObj);
    				int errorCode2 = createApp(easeAppDTO);
    				if(errorCode2 == ErrorCode.NO_ERROR) {
    					easeAppDTO.setEaseReceivedMessageInd(Constant.YES);
    					updateEaseReceivedIndicator(easeAppDTO);
    				}
    				else {
    					easeAppDTO.setEaseReceivedMessageInd(Constant.NO);
    					updateEaseReceivedIndicator(easeAppDTO);
    				}
            	}	
            }
            catch (JMSException ex) {
                throw new RuntimeException(ex);
            }
        }
        else {
            throw new IllegalArgumentException("Message must be of type TextMessage");
        }		

   }
}
