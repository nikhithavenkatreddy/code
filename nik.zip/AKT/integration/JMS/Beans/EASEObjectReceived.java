package gov.ca.dmv.AKT.integration.JMS.Beans;

import com.ancientprogramming.fixedformat4j.annotation.Record;  
import com.ancientprogramming.fixedformat4j.annotation.Field;  
import com.ancientprogramming.fixedformat4j.annotation.Align;  

@Record
public class EASEObjectReceived {

	private String requestType;
	private String dlNumber;
	private String expirationDate;
	private String firstName;
	private String lastName;
	private String birthDate;
	private String outOfStateIndicator;
	private String originalIndicator;
	private String ThirdRbmIndicator;
	private String appliedForClass1;
	private String appliedForClass2;
	private String appliedForEndorsement1;
	private String appliedForEndorsement2;
	private String appliedForEndorsement3;
	private String appliedForEndorsement4;
	private String appliedForEndorsement5;
	private String appliedForEndorsement6;
	private String signTestHistory;
	private String test01;
	private String test01History;
	private String test01Optional;
	private String test02;
	private String test02History;
	private String test02Optional;
	private String test03;
	private String test03History;
	private String test03Optional;
	private String test04;
	private String test04History;
	private String test04Optional;
	private String test05;
	private String test05History;
	private String test05Optional;
	private String test06;
	private String test06History;
	private String test06Optional;
	private String test07;
	private String test07History;
	private String test07Optional;
	private String test08;
	private String test08History;
	private String test08Optional;
	private String test09;
	private String test09History;
	private String test09Optional;
	private String test10;
	private String test10History;
	private String test10Optional;
	private String test11;
	private String test11History;
	private String test11Optional;
	private String test12;
	private String test12History;
	private String test12Optional;
	private String test13;
	private String test13History;
	private String test13Optional;
	private String officeId;
	private String techId;
	private String applicationId;
	private String messageSendDate;
	private String messageSendTime;
	private String audioVideoTestCode;
	
	@Field(offset = 1, length = 4, align = Align.RIGHT, paddingChar = ' ')
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	@Field(offset = 5, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	@Field(offset = 13, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	@Field(offset = 21, length = 27, align = Align.RIGHT, paddingChar = ' ')
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Field(offset = 48, length = 27, align = Align.RIGHT, paddingChar = ' ')
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Field(offset = 75, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	@Field(offset = 83, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getOutOfStateIndicator() {
		return outOfStateIndicator;
	}
	public void setOutOfStateIndicator(String outOfStateIndicator) {
		this.outOfStateIndicator = outOfStateIndicator;
	}
	@Field(offset = 84, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getOriginalIndicator() {
		return originalIndicator;
	}
	public void setOriginalIndicator(String originalIndicator) {
		this.originalIndicator = originalIndicator;
	}
	@Field(offset = 85, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getThirdRbmIndicator() {
		return ThirdRbmIndicator;
	}
	public void setThirdRbmIndicator(String thirdRbmIndicator) {
		ThirdRbmIndicator = thirdRbmIndicator;
	}
	@Field(offset = 86, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForClass1() {
		return appliedForClass1;
	}
	public void setAppliedForClass1(String appliedForClass1) {
		this.appliedForClass1 = appliedForClass1;
	}
	@Field(offset = 87, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForClass2() {
		return appliedForClass2;
	}
	public void setAppliedForClass2(String appliedForClass2) {
		this.appliedForClass2 = appliedForClass2;
	}
	@Field(offset = 88, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement1() {
		return appliedForEndorsement1;
	}
	public void setAppliedForEndorsement1(String appliedForEndorsement1) {
		this.appliedForEndorsement1 = appliedForEndorsement1;
	}
	@Field(offset = 90, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement2() {
		return appliedForEndorsement2;
	}
	public void setAppliedForEndorsement2(String appliedForEndorsement2) {
		this.appliedForEndorsement2 = appliedForEndorsement2;
	}
	@Field(offset = 92, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement3() {
		return appliedForEndorsement3;
	}
	public void setAppliedForEndorsement3(String appliedForEndorsement3) {
		this.appliedForEndorsement3 = appliedForEndorsement3;
	}
	@Field(offset = 94, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement4() {
		return appliedForEndorsement4;
	}
	public void setAppliedForEndorsement4(String appliedForEndorsement4) {
		this.appliedForEndorsement4 = appliedForEndorsement4;
	}
	@Field(offset = 96, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement5() {
		return appliedForEndorsement5;
	}
	public void setAppliedForEndorsement5(String appliedForEndorsement5) {
		this.appliedForEndorsement5 = appliedForEndorsement5;
	}
	@Field(offset = 98, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getAppliedForEndorsement6() {
		return appliedForEndorsement6;
	}
	public void setAppliedForEndorsement6(String appliedForEndorsement6) {
		this.appliedForEndorsement6 = appliedForEndorsement6;
	}
	@Field(offset = 100, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getSignTestHistory() {
		return signTestHistory;
	}
	public void setSignTestHistory(String signTestHistory) {
		this.signTestHistory = signTestHistory;
	}
	@Field(offset = 101, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest01() {
		return test01;
	}
	public void setTest01(String test01) {
		this.test01 = test01;
	}
	@Field(offset = 103, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest01History() {
		return test01History;
	}
	public void setTest01History(String test01History) {
		this.test01History = test01History;
	}
	@Field(offset = 104, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest01Optional() {
		return test01Optional;
	}
	public void setTest01Optional(String test01Optional) {
		this.test01Optional = test01Optional;
	}
	@Field(offset = 105, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest02() {
		return test02;
	}
	public void setTest02(String test02) {
		this.test02 = test02;
	}
	@Field(offset = 107, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest02History() {
		return test02History;
	}
	public void setTest02History(String test02History) {
		this.test02History = test02History;
	}
	@Field(offset = 108, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest02Optional() {
		return test02Optional;
	}
	public void setTest02Optional(String test02Optional) {
		this.test02Optional = test02Optional;
	}
	@Field(offset = 109, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest03() {
		return test03;
	}
	public void setTest03(String test03) {
		this.test03 = test03;
	}
	@Field(offset = 111, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest03History() {
		return test03History;
	}
	public void setTest03History(String test03History) {
		this.test03History = test03History;
	}
	@Field(offset = 112, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest03Optional() {
		return test03Optional;
	}
	public void setTest03Optional(String test03Optional) {
		this.test03Optional = test03Optional;
	}
	@Field(offset = 113, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest04() {
		return test04;
	}
	public void setTest04(String test04) {
		this.test04 = test04;
	}
	@Field(offset = 115, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest04History() {
		return test04History;
	}
	public void setTest04History(String test04History) {
		this.test04History = test04History;
	}
	@Field(offset = 116, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest04Optional() {
		return test04Optional;
	}
	public void setTest04Optional(String test04Optional) {
		this.test04Optional = test04Optional;
	}
	@Field(offset = 117, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest05() {
		return test05;
	}
	public void setTest05(String test05) {
		this.test05 = test05;
	}
	@Field(offset = 119, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest05History() {
		return test05History;
	}
	public void setTest05History(String test05History) {
		this.test05History = test05History;
	}
	@Field(offset = 120, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest05Optional() {
		return test05Optional;
	}
	public void setTest05Optional(String test05Optional) {
		this.test05Optional = test05Optional;
	}
	@Field(offset = 121, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest06() {
		return test06;
	}
	public void setTest06(String test06) {
		this.test06 = test06;
	}
	@Field(offset = 123, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest06History() {
		return test06History;
	}
	public void setTest06History(String test06History) {
		this.test06History = test06History;
	}
	@Field(offset = 124, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest06Optional() {
		return test06Optional;
	}
	public void setTest06Optional(String test06Optional) {
		this.test06Optional = test06Optional;
	}
	@Field(offset = 125, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest07() {
		return test07;
	}
	public void setTest07(String test07) {
		this.test07 = test07;
	}
	@Field(offset = 127, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest07History() {
		return test07History;
	}
	public void setTest07History(String test07History) {
		this.test07History = test07History;
	}
	@Field(offset = 128, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest07Optional() {
		return test07Optional;
	}
	public void setTest07Optional(String test07Optional) {
		this.test07Optional = test07Optional;
	}
	@Field(offset = 129, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest08() {
		return test08;
	}
	public void setTest08(String test08) {
		this.test08 = test08;
	}
	@Field(offset = 131, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest08History() {
		return test08History;
	}
	public void setTest08History(String test08History) {
		this.test08History = test08History;
	}
	@Field(offset = 132, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest08Optional() {
		return test08Optional;
	}
	public void setTest08Optional(String test08Optional) {
		this.test08Optional = test08Optional;
	}
	@Field(offset = 133, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest09() {
		return test09;
	}
	public void setTest09(String test09) {
		this.test09 = test09;
	}
	@Field(offset = 135, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest09History() {
		return test09History;
	}
	public void setTest09History(String test09History) {
		this.test09History = test09History;
	}
	@Field(offset = 136, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest09Optional() {
		return test09Optional;
	}
	public void setTest09Optional(String test09Optional) {
		this.test09Optional = test09Optional;
	}
	@Field(offset = 137, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest10() {
		return test10;
	}
	public void setTest10(String test10) {
		this.test10 = test10;
	}
	@Field(offset = 139, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest10History() {
		return test10History;
	}
	public void setTest10History(String test10History) {
		this.test10History = test10History;
	}
	@Field(offset = 140, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest10Optional() {
		return test10Optional;
	}
	public void setTest10Optional(String test10Optional) {
		this.test10Optional = test10Optional;
	}
	@Field(offset = 141, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest11() {
		return test11;
	}
	public void setTest11(String test11) {
		this.test11 = test11;
	}
	@Field(offset = 143, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest11History() {
		return test11History;
	}
	public void setTest11History(String test11History) {
		this.test11History = test11History;
	}
	@Field(offset = 144, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest11Optional() {
		return test11Optional;
	}
	public void setTest11Optional(String test11Optional) {
		this.test11Optional = test11Optional;
	}
	@Field(offset = 145, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest12() {
		return test12;
	}
	public void setTest12(String test12) {
		this.test12 = test12;
	}
	@Field(offset = 147, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest12History() {
		return test12History;
	}
	public void setTest12History(String test12History) {
		this.test12History = test12History;
	}
	@Field(offset = 148, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest12Optional() {
		return test12Optional;
	}
	public void setTest12Optional(String test12Optional) {
		this.test12Optional = test12Optional;
	}
	@Field(offset = 149, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTest13() {
		return test13;
	}
	public void setTest13(String test13) {
		this.test13 = test13;
	}
	@Field(offset = 151, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest13History() {
		return test13History;
	}
	public void setTest13History(String test13History) {
		this.test13History = test13History;
	}
	@Field(offset = 152, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTest13Optional() {
		return test13Optional;
	}
	public void setTest13Optional(String test13Optional) {
		this.test13Optional = test13Optional;
	}
	@Field(offset = 153, length = 3, align = Align.RIGHT, paddingChar = ' ')
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	@Field(offset = 156, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	@Field(offset = 158, length = 4, align = Align.RIGHT, paddingChar = ' ')
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	@Field(offset = 162, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getMessageSendDate() {
		return messageSendDate;
	}
	public void setMessageSendDate(String messageSendDate) {
		this.messageSendDate = messageSendDate;
	}
	@Field(offset = 170, length = 6, align = Align.RIGHT, paddingChar = ' ')
	public String getMessageSendTime() {
		return messageSendTime;
	}
	public void setMessageSendTime(String messageSendTime) {
		this.messageSendTime = messageSendTime;
	}
	@Field(offset = 176, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getAudioVideoTestCode() {
		return audioVideoTestCode;
	}
	public void setAudioVideoTestCode(String audioVideoTestCode) {
		this.audioVideoTestCode = audioVideoTestCode;
	}
}
