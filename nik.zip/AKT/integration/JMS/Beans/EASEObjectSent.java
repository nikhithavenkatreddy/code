package gov.ca.dmv.AKT.integration.JMS.Beans;
import com.ancientprogramming.fixedformat4j.annotation.Align;
import com.ancientprogramming.fixedformat4j.annotation.Record;  
import com.ancientprogramming.fixedformat4j.annotation.Field;  

@Record
public class EASEObjectSent {

	private String officeId;
	private String applicationId;
	private String dlNumber;
	private String testType;
	private String testResult;
	private String testLang;
	private String testDate;
	private String testTime;
	private String techId;
	
	@Field(offset = 1, length = 3, align = Align.RIGHT, paddingChar = ' ')
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	@Field(offset = 4, length = 4, align = Align.RIGHT, paddingChar = ' ')
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	@Field(offset = 8, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	@Field(offset = 16, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}
	@Field(offset = 18, length = 1, align = Align.RIGHT, paddingChar = ' ')
	public String getTestResult() {
		return testResult;
	}
	public void setTestResult(String testResult) {
		this.testResult = testResult;
	}
	@Field(offset = 19, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTestLang() {
		return testLang;
	}
	public void setTestLang(String testLang) {
		this.testLang = testLang;
	}
	@Field(offset = 21, length = 8, align = Align.RIGHT, paddingChar = ' ')
	public String getTestDate() {
		return testDate;
	}
	public void setTestDate(String testDate) {
		this.testDate = testDate;
	}
	@Field(offset = 29, length = 6, align = Align.RIGHT, paddingChar = ' ')
	public String getTestTime() {
		return testTime;
	}
	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}
	@Field(offset = 35, length = 2, align = Align.RIGHT, paddingChar = ' ')
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	public String toString() {
		String returnString = officeId.trim() + applicationId.trim() + dlNumber.trim() + testType.trim() + testResult.trim() + testLang.trim() + 
				              testDate.trim() + testTime.trim() + techId.trim();
		return returnString;
	}
}
