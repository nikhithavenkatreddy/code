package gov.ca.dmv.AKT.integration.webservice;



@javax.jws.WebService (endpointInterface="gov.ca.dmv.AKT.integration.webservice.EASEApplication", targetNamespace="urn:gov.ca.dmv.akt.service", serviceName="EASEApplication", portName="EASEApplicationSOAP")
public class EASEApplicationSOAPImpl{

    public EASEAppReceipt processApplication(EASEApplication_Type in) {
        // TODO Auto-generated method stub
        return null;
    }

}