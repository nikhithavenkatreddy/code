package gov.ca.dmv.AKT.integration.Beans;

import java.io.Serializable;
import java.util.Date;

public interface IExamHistory extends Serializable {

	Integer getPastExamId();

	void setPastExamId(Integer pastExamId);

	Integer getApplicationId();

	void setApplicationId(Integer applicationId);

	String getEaseTestId();

	void setEaseTestId(String easeTestId);

	String getEaseStatusIndicator();

	void setEaseStatusIndicator(String easeStatusIndicator);

	Date getEaseReceivedTimestamp();

	void setEaseReceivedTimestamp(Date easeReceivedTimestamp);

	String getAktStatusIndicator();

	void setAktStatusIndicator(String aktStatusIndicator);

	Date getAktUpdatedTimestamp();

	void setAktUpdatedTimestamp(Date aktUpdatedTimestamp);

	String getLastModusername();

	void setLastModusername(String lastModusername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

}