package gov.ca.dmv.AKT.integration.Beans;

import java.util.Date;

public interface ISession {

	Integer getSessionId();

	void setSessionId(Integer sessionId);

	Integer getApplicationId();

	void setApplicationId(Integer applicationId);

	String getWorkstationIPAddress();

	void setWorkstationIPAddress(String workstationIPAddress);

	String getOfficeId();

	void setOfficeId(String officeId);

	Date getSessionStartTime();

	void setSessionStartTime(Date sessionStartTime);

	Date getSessionEndTime();

	void setSessionEndTime(Date sessionEndTime);

	String getYobValidationFlag();

	void setYobValidationFlag(String yobValidationFlag);

	Date getYobOverrideTime();

	void setYobOverrideTime(Date yobOverrideTime);

	String getLanguageCode();

	void setLanguageCode(String languageCode);

	Integer getVaultId();

	void setVaultId(Integer vaultId);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

	String getSessionStatusCode();

	void setSessionStatusCode(String sessionStatusCode);

}