package gov.ca.dmv.AKT.integration.Beans;

import java.io.Serializable;
import java.util.Date;

public interface IEaseInboundMessage extends Serializable {

	Integer getEaseMessageId();

	void setEaseMessageId(Integer easeMessageId);

	Date getEaseMessageReceivedTimestamp();

	void setEaseMessageReceivedTimestamp(Date easeMessageReceivedTimestamp);

	String getEaseApplicationMessage();

	void setEaseApplicationMessage(String easeApplicationMessage);

	String getEaseMessageIndicator();

	void setEaseMessageIndicator(String easeMessageIndicator);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

}