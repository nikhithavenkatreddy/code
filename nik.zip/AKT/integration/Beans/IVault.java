package gov.ca.dmv.AKT.integration.Beans;

import java.util.Date;

public interface IVault {

	Integer getVaultId();

	void setVaultId(Integer vaultId);

	String getApplicationLastName();

	void setApplicationLastName(String applicationLastName);

	String getApplicationFirstName();

	void setApplicationFirstName(String applicationFirstName);

	String getDlNumber();

	void setDlNumber(String dlNumber);

	java.sql.Date getBirthDate();

	void setBirthDate(java.sql.Date birthDate);

	Date getVaultTimestamp();

	void setVaultTimestamp(Date vaultTimestamp);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);
	
	String getState();
	
	void setState(String state);
}