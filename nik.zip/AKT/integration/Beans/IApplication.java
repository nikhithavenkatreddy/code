package gov.ca.dmv.AKT.integration.Beans;

import java.io.Serializable;
import java.util.Date;

public interface IApplication extends Serializable {

	String getAudioVideoTestCode();

	void setAudioVideoTestCode(String audioVideoTestCode);

	String getApplicationType();

	void setApplicationType(String applicationType);

	String getSignTestSatisfiedFlag();

	void setSignTestSatisfiedFlag(String signTestSatisfiedFlag);

	String getEaseApplicationId();

	void setEaseApplicationId(String easeApplicationId);

	Integer getApplicationId();

	void setApplicationId(Integer applicationId);

	Integer getVaultId();

	void setVaultId(Integer vaultId);

	String getClassLicenseCode();

	void setClassLicenseCode(String classLicenseCode);

	String getEndorsementCode();

	void setEndorsementCode(String endorsementCode);

	String getOfficeId();

	void setOfficeId(String officeId);

	String getOsFlag();

	void setOsFlag(String osFlag);

	java.sql.Date getDlExpirationDate();

	void setDlExpirationDate(java.sql.Date dlExpirationDate);

	Date getApplicationTimestamp();

	void setApplicationTimestamp(Date applicationTimestamp);

	String getRenewalFlag();

	void setRenewalFlag(String renewalFlag);

	String getPauseCount();

	void setPauseCount(String pauseCount);

	String getApplicationStatusCode();

	void setApplicationStatusCode(String applicationStatusCode);

	String getForceFailFlag();

	void setForceFailFlag(String forceFailFlag);

	String getTechId();

	void setTechId(String techId);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

}