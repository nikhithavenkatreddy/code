package gov.ca.dmv.AKT.integration.Beans;

import gov.ca.dmv.AKT.integration.BeansImpl.EAPrimaryKey;

import java.io.Serializable;
import java.util.Date;

public interface IExamAnswer extends Serializable {

	EAPrimaryKey getEaPrimaryKey();

	void setEaPrimaryKey(EAPrimaryKey eaPrimaryKey);

	Integer getQuestionGenId();

	void setQuestionGenId(Integer questionGenId);

	String getCorrectAnswerFlag();

	void setCorrectAnswerFlag(String correctAnswerFlag);

	Integer getAnswerPresentedOrder();

	void setAnswerPresentedOrder(Integer answerPresentedOrder);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

}