package gov.ca.dmv.AKT.integration.Beans;

import gov.ca.dmv.AKT.integration.BeansImpl.EQPrimaryKey;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;

import java.io.Serializable;
import java.util.Date;

public interface IExamQuestion extends Serializable  {

	Integer getQuestionGenId();

	void setQuestionGenId(Integer questionGenId);

	QuestionLang getQuestionLang();

	void setQuestionLang(QuestionLang questionLang);

	EQPrimaryKey getEqPrimaryKey();

	void setEqPrimaryKey(EQPrimaryKey eqPrimaryKey);

	String getQuestionLangId();

	void setQuestionLangId(String questionLangId);

	String getQuestionId();

	void setQuestionId(String questionId);

	String getAnswerChoice();

	void setAnswerChoice(String answerChoice);

	String getAnswerStatus();

	void setAnswerStatus(String answerStatus);

	Integer getAnswerElapsedTime();

	void setAnswerElapsedTime(Integer answerElapsedTime);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);

}