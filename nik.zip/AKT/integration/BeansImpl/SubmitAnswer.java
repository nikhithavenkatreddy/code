package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class SubmitAnswer {

	private Integer examId;
	private Integer answerGenId;
	private String  questionGenId;
	private int     questionPresentedOrder;
	private Date    questionPresentedTime;
	private String  answerChoice;
	
	public String getAnswerChoice() {
		return answerChoice;
	}
	public void setAnswerChoice(String answerChoice) {
		this.answerChoice = answerChoice;
	}
	public Date getQuestionPresentedTime() {
		return questionPresentedTime;
	}
	public void setQuestionPresentedTime(Date questionPresentedTime) {
		this.questionPresentedTime = questionPresentedTime;
	}
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Integer getAnswerGenId() {
		return answerGenId;
	}
	public void setAnswerGenId(Integer answerGenId) {
		this.answerGenId = answerGenId;
	}
	public String getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(String questionGenId) {
		this.questionGenId = questionGenId;
	}
	public int getQuestionPresentedOrder() {
		return questionPresentedOrder;
	}
	public void setQuestionPresentedOrder(int questionPresentedOrder) {
		this.questionPresentedOrder = questionPresentedOrder;
	}
	
}
