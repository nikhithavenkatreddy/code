package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.List;

public class QuestionCategoryTestList {

	private Question       question;
	private List<Category> categoryList;
	private List<Test>     testList;
	
	public List<Test> getTestList() {
		return testList;
	}
	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
}
