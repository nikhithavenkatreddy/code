package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.List;

public class QuestionLangQuickPF {

	private List<QuestionLang> questionLangList;
	private QuickPassFailEvent quickPassFailEvent;
	private boolean            firstCDL;
	
	public boolean isFirstCDL() {
		return firstCDL;
	}
	public void setFirstCDL(boolean firstCDL) {
		this.firstCDL = firstCDL;
	}
	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}
	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}
	public QuickPassFailEvent getQuickPassFailEvent() {
		return quickPassFailEvent;
	}
	public void setQuickPassFailEvent(QuickPassFailEvent quickPassFailEvent) {
		this.quickPassFailEvent = quickPassFailEvent;
	}
	
}
