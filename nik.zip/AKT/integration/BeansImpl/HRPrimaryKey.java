package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class HRPrimaryKey implements Serializable{

	private String handbookRef;
	private String langId;
	
	public String getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(String handbookRef) {
		this.handbookRef = handbookRef;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	
}
