package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.ISession;

import java.util.Date;

public class Session implements ISession {

	private Integer sessionId;
	private Integer applicationId;
	private String  workstationIPAddress;
	private String  officeId;
	private Date    sessionStartTime;
	private Date    sessionEndTime;
	private String  yobValidationFlag;
	private Date    yobOverrideTime;
	private String  languageCode;
	private Integer vaultId;
	private String  sessionStatusCode;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getSessionStatusCode()
	 */
	@Override	
	public String getSessionStatusCode() {
		return sessionStatusCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setSessionStatusCode()
	 */
	@Override
	public void setSessionStatusCode(String sessionStatusCode) {
		this.sessionStatusCode = sessionStatusCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getSessionId()
	 */
	@Override
	public Integer getSessionId() {
		return sessionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setSessionId(java.lang.Integer)
	 */
	@Override
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getApplicationId()
	 */
	@Override
	public Integer getApplicationId() {
		return applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setApplicationId(java.lang.Integer)
	 */
	@Override
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getWorkstationIPAddress()
	 */
	@Override
	public String getWorkstationIPAddress() {
		return workstationIPAddress;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setWorkstationIPAddress(java.lang.String)
	 */
	@Override
	public void setWorkstationIPAddress(String workstationIPAddress) {
		this.workstationIPAddress = workstationIPAddress;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getOfficeId()
	 */
	@Override
	public String getOfficeId() {
		return officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setOfficeId(java.lang.String)
	 */
	@Override
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getSessionStartTime()
	 */
	@Override
	public Date getSessionStartTime() {
		return sessionStartTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setSessionStartTime(java.util.Date)
	 */
	@Override
	public void setSessionStartTime(Date sessionStartTime) {
		this.sessionStartTime = sessionStartTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getSessionEndTime()
	 */
	@Override
	public Date getSessionEndTime() {
		return sessionEndTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setSessionEndTime(java.util.Date)
	 */
	@Override
	public void setSessionEndTime(Date sessionEndTime) {
		this.sessionEndTime = sessionEndTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getYobValidationFlag()
	 */
	@Override
	public String getYobValidationFlag() {
		return yobValidationFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setYobValidationFlag(java.lang.String)
	 */
	@Override
	public void setYobValidationFlag(String yobValidationFlag) {
		this.yobValidationFlag = yobValidationFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getYobOverrideTime()
	 */
	@Override
	public Date getYobOverrideTime() {
		return yobOverrideTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setYobOverrideTime(java.util.Date)
	 */
	@Override
	public void setYobOverrideTime(Date yobOverrideTime) {
		this.yobOverrideTime = yobOverrideTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getLanguageCode()
	 */
	@Override
	public String getLanguageCode() {
		return languageCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setLanguageCode(java.lang.String)
	 */
	@Override
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getVaultId()
	 */
	@Override
	public Integer getVaultId() {
		return vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setVaultId(java.lang.Integer)
	 */
	@Override
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.ISession#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
