package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class QuickPassFailEvent {

	private Date    timestamp;
	private String  testId;
	private String  quickPassFlag;
	private String  quickFailFlag;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
	public String getQuickPassFlag() {
		return quickPassFlag;
	}
	public void setQuickPassFlag(String quickPassFlag) {
		this.quickPassFlag = quickPassFlag;
	}
	public String getQuickFailFlag() {
		return quickFailFlag;
	}
	public void setQuickFailFlag(String quickFailFlag) {
		this.quickFailFlag = quickFailFlag;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
