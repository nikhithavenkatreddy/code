package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.List;

public class TestCategory {

	private String         testId;
	private List<Category> categoryList;
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
}
