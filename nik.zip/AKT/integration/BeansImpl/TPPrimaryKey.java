package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TPPrimaryKey implements Serializable{

	private String  categoryId;
	private String  testId;
	
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
}
