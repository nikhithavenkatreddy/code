package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.constants.Constant;

public class QuesReport {

	private String questionLangId;
	private int    count = Constant.ZERO;
	private int    passCount = Constant.ZERO;
	private int    failCount = Constant.ZERO;
	private String langId;
	
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getQuestionLangId() {
		return questionLangId;
	}
	public void setQuestionLangId(String questionLangId) {
		this.questionLangId = questionLangId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getPassCount() {
		return passCount;
	}
	public void setPassCount(int passCount) {
		this.passCount = passCount;
	}
	public int getFailCount() {
		return failCount;
	}
	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}
	
}
