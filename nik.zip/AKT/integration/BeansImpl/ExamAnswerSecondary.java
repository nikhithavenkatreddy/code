package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;

import java.util.Date;

@SuppressWarnings("serial")
public class ExamAnswerSecondary implements IExamAnswer {

	private EAPrimaryKey eaPrimaryKey;
	private Integer      questionGenId;
	private String       correctAnswerFlag;
	private Integer      answerPresentedOrder;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public ExamAnswerSecondary() {
		eaPrimaryKey = new EAPrimaryKey();
	}
	public EAPrimaryKey getEaPrimaryKey() {
		return eaPrimaryKey;
	}
	public void setEaPrimaryKey(EAPrimaryKey eaPrimaryKey) {
		this.eaPrimaryKey = eaPrimaryKey;
	}
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	public String getCorrectAnswerFlag() {
		return correctAnswerFlag;
	}
	public void setCorrectAnswerFlag(String correctAnswerFlag) {
		this.correctAnswerFlag = correctAnswerFlag;
	}
	public Integer getAnswerPresentedOrder() {
		return answerPresentedOrder;
	}
	public void setAnswerPresentedOrder(Integer answerPresentedOrder) {
		this.answerPresentedOrder = answerPresentedOrder;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
