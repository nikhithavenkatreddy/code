package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class QuestionList implements Serializable{

	private QLPrimaryKey qlPrimaryKey;
	private String       questionStatus;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public QuestionList() {
		qlPrimaryKey = new QLPrimaryKey();
	}
	public QLPrimaryKey getQlPrimaryKey() {
		return qlPrimaryKey;
	}
	public void setQlPrimaryKey(QLPrimaryKey qlPrimaryKey) {
		this.qlPrimaryKey = qlPrimaryKey;
	}
	public String getQuestionStatus() {
		return questionStatus;
	}
	public void setQuestionStatus(String questionStatus) {
		this.questionStatus = questionStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
