package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class Lang {

	private String langId;
	private String langName;
	private String progLangCode;
	private Integer displayOrder;
	private String lastModUsername;
	private Date   lastModUserTime;
	private String nativeLangName;
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getLangName() {
		return langName;
	}
	public void setLangName(String langName) {
		this.langName = langName;
	}
	public String getProgLangCode() {
		return progLangCode;
	}
	public void setProgLangCode(String progLangCode) {
		this.progLangCode = progLangCode;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public Integer getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getNativeLangName() {
		return nativeLangName;
	}
	public void setNativeLangName(String nativeLangName) {
		this.nativeLangName = nativeLangName;
	}
	
	
}
