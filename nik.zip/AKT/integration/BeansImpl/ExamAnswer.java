package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;

import java.util.Date;

public class ExamAnswer implements IExamAnswer {

	private EAPrimaryKey eaPrimaryKey;
	private Integer      questionGenId;
	private String       correctAnswerFlag;
	private Integer      answerPresentedOrder;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public ExamAnswer() {
		eaPrimaryKey = new EAPrimaryKey();
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getEaPrimaryKey()
	 */
	@Override
	public EAPrimaryKey getEaPrimaryKey() {
		return eaPrimaryKey;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setEaPrimaryKey(gov.ca.dmv.AKT.integration.BeansImpl.EAPrimaryKey)
	 */
	@Override
	public void setEaPrimaryKey(EAPrimaryKey eaPrimaryKey) {
		this.eaPrimaryKey = eaPrimaryKey;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getQuestionGenId()
	 */
	@Override
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setQuestionGenId(java.lang.Integer)
	 */
	@Override
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getCorrectAnswerFlag()
	 */
	@Override
	public String getCorrectAnswerFlag() {
		return correctAnswerFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setCorrectAnswerFlag(java.lang.String)
	 */
	@Override
	public void setCorrectAnswerFlag(String correctAnswerFlag) {
		this.correctAnswerFlag = correctAnswerFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getAnswerPresentedOrder()
	 */
	@Override
	public Integer getAnswerPresentedOrder() {
		return answerPresentedOrder;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setAnswerPresentedOrder(java.lang.Integer)
	 */
	@Override
	public void setAnswerPresentedOrder(Integer answerPresentedOrder) {
		this.answerPresentedOrder = answerPresentedOrder;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamAnswer#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
