package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;

import java.util.Date;

@SuppressWarnings("serial")
public class ExamQuestionSecondary implements IExamQuestion {

	private EQPrimaryKey eqPrimaryKey;
	private QuestionLang questionLang;
	private Integer      questionGenId;
	private String       questionLangId;
	private String       questionId;
	private String       answerChoice;
	private String       answerStatus;
	private Integer      answerElapsedTime;
	private String       lastModUsername;
	private Date         lastModUserTime;
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}
	public ExamQuestionSecondary() {
		eqPrimaryKey = new EQPrimaryKey();
	}
	public EQPrimaryKey getEqPrimaryKey() {
		return eqPrimaryKey;
	}
	public void setEqPrimaryKey(EQPrimaryKey eqPrimaryKey) {
		this.eqPrimaryKey = eqPrimaryKey;
	}
	public String getQuestionLangId() {
		return questionLangId;
	}
	public void setQuestionLangId(String questionLangId) {
		this.questionLangId = questionLangId;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getAnswerChoice() {
		return answerChoice;
	}
	public void setAnswerChoice(String answerChoice) {
		this.answerChoice = answerChoice;
	}
	public String getAnswerStatus() {
		return answerStatus;
	}
	public void setAnswerStatus(String answerStatus) {
		this.answerStatus = answerStatus;
	}
	public Integer getAnswerElapsedTime() {
		return answerElapsedTime;
	}
	public void setAnswerElapsedTime(Integer answerElapsedTime) {
		this.answerElapsedTime = answerElapsedTime;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
