package gov.ca.dmv.AKT.integration.BeansImpl;

public class EaseTest {

	private String  easeTestId;
	private String  easeStatusIndicator;
	private Integer applicationId;
	private String  officeId;
	private String  signTestSatisfiedFlag;
	private boolean stubRequired;
	private String  signTestHistory;
	
	public String getSignTestHistory() {
		return signTestHistory;
	}
	public void setSignTestHistory(String signTestHistory) {
		this.signTestHistory = signTestHistory;
	}
	public boolean isStubRequired() {
		return stubRequired;
	}
	public void setStubRequired(boolean stubRequired) {
		this.stubRequired = stubRequired;
	}
	public String getSignTestSatisfiedFlag() {
		return signTestSatisfiedFlag;
	}
	public void setSignTestSatisfiedFlag(String signTestSatisfiedFlag) {
		this.signTestSatisfiedFlag = signTestSatisfiedFlag;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getEaseStatusIndicator() {
		return easeStatusIndicator;
	}
	public void setEaseStatusIndicator(String easeStatusIndicator) {
		this.easeStatusIndicator = easeStatusIndicator;
	}
	
}
