package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.ISession;

public class ActiveSessionAndExam {

	private ISession session;
	private IExam    exam;
	
	public ISession getSession() {
		return session;
	}
	public void setSession(ISession session) {
		this.session = session;
	}
	public IExam getExam() {
		return exam;
	}
	public void setExam(IExam exam) {
		this.exam = exam;
	}
	
}
