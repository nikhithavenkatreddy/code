package gov.ca.dmv.AKT.integration.BeansImpl;

public class TestCategory2 {

	private String         testId;
	private String         categoryId;
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
}
