package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class Office {

	private String  officeId;
	private Integer buildingId;
	private String 	officeName;
	private String 	officeCityName;
	private String 	regionCode;	
	private String 	l1ServerIpAddr;
	private String 	officeTypeCode;
	private String  newFunctionOnFlag;
	
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public Integer getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(Integer buildingId) {
		this.buildingId = buildingId;
	}
	
	public String getOfficeName() {
		return officeName;
	}
	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	public String getOfficeCityName() {
		return officeCityName;
	}
	public void setOfficeCityName(String officeCityName) {
		this.officeCityName = officeCityName;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getL1ServerIpAddr() {
		return l1ServerIpAddr;
	}
	public void setL1ServerIpAddr(String l1ServerIpAddr) {
		this.l1ServerIpAddr = l1ServerIpAddr;
	}
	public String getOfficeTypeCode() {
		return officeTypeCode;
	}
	public void setOfficeTypeCode(String officeTypeCode) {
		this.officeTypeCode = officeTypeCode;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getNewFunctionOnFlag() {
		return newFunctionOnFlag;
	}
	public void setNewFunctionOnFlag(String newFunctionOnFlag) {
		this.newFunctionOnFlag = newFunctionOnFlag;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}	
	
}
