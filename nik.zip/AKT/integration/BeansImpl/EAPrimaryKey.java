package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class EAPrimaryKey implements Serializable{

	private Integer examId;
	private Integer answerId;

	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Integer getAnswerId() {
		return answerId;
	}
	public void setAnswerId(Integer answerId) {
		this.answerId = answerId;
	}

}
