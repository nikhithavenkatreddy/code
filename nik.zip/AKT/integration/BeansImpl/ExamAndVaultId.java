package gov.ca.dmv.AKT.integration.BeansImpl;

public class ExamAndVaultId {

	private IExam exam;
	private int  vaultId;
	
	public IExam getExam() {
		return exam;
	}
	public void setExam(IExam exam2) {
		this.exam = exam2;
	}
	public int getVaultId() {
		return vaultId;
	}
	public void setVaultId(int vaultId) {
		this.vaultId = vaultId;
	}
	
}
