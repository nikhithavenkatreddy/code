package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;

import java.util.Date;

@SuppressWarnings("serial")
public class ExamQuestion implements IExamQuestion{

	private EQPrimaryKey eqPrimaryKey;
	private QuestionLang questionLang;
	private Integer      questionGenId;
	private String       questionLangId;
	private String       questionId;
	private String       answerChoice;
	private String       answerStatus;
	private Integer      answerElapsedTime;
	private String       lastModUsername;
	private Date         lastModUserTime;
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getQuestionGenId()
	 */
	@Override
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setQuestionGenId(java.lang.Integer)
	 */
	@Override
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getQuestionLang()
	 */
	@Override
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setQuestionLang(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang)
	 */
	@Override
	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}
	public ExamQuestion() {
		eqPrimaryKey = new EQPrimaryKey();
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getEqPrimaryKey()
	 */
	@Override
	public EQPrimaryKey getEqPrimaryKey() {
		return eqPrimaryKey;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setEqPrimaryKey(gov.ca.dmv.AKT.integration.BeansImpl.EQPrimaryKey)
	 */
	@Override
	public void setEqPrimaryKey(EQPrimaryKey eqPrimaryKey) {
		this.eqPrimaryKey = eqPrimaryKey;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getQuestionLangId()
	 */
	@Override
	public String getQuestionLangId() {
		return questionLangId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setQuestionLangId(java.lang.String)
	 */
	@Override
	public void setQuestionLangId(String questionLangId) {
		this.questionLangId = questionLangId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getQuestionId()
	 */
	@Override
	public String getQuestionId() {
		return questionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setQuestionId(java.lang.String)
	 */
	@Override
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getAnswerChoice()
	 */
	@Override
	public String getAnswerChoice() {
		return answerChoice;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setAnswerChoice(java.lang.String)
	 */
	@Override
	public void setAnswerChoice(String answerChoice) {
		this.answerChoice = answerChoice;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getAnswerStatus()
	 */
	@Override
	public String getAnswerStatus() {
		return answerStatus;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setAnswerStatus(java.lang.String)
	 */
	@Override
	public void setAnswerStatus(String answerStatus) {
		this.answerStatus = answerStatus;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getAnswerElapsedTime()
	 */
	@Override
	public Integer getAnswerElapsedTime() {
		return answerElapsedTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setAnswerElapsedTime(java.lang.Integer)
	 */
	@Override
	public void setAnswerElapsedTime(Integer answerElapsedTime) {
		this.answerElapsedTime = answerElapsedTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamQuestion#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
	@Override
	public String toString() {
		return "The Exam Id is " + this.eqPrimaryKey.getExamId() + " and the Question Presented Order is " + this.eqPrimaryKey.getQuestionPresentedOrder();
	}
}
