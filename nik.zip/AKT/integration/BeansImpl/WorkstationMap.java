package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class WorkstationMap {

	private String  workstationIPAddress;
	private String  officeId;
	private String  locatingOfficeId;
	private String  workstationId;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public String getLocatingOfficeId() {
		return locatingOfficeId;
	}
	public void setLocatingOfficeId(String locatingOfficeId) {
		this.locatingOfficeId = locatingOfficeId;
	}
	public String getWorkstationIPAddress() {
		return workstationIPAddress;
	}
	public void setWorkstationIPAddress(String workstationIPAddress) {
		this.workstationIPAddress = workstationIPAddress;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getWorkstationId() {
		return workstationId;
	}
	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
