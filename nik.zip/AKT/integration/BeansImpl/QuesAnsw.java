package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.List;

public class QuesAnsw {

	private QuestionLang   questionLang;
	private List<Answer>   answerList;
	private List<Category> categoryList;
	private HandbookRef    handbookRef;
	private boolean        error;
	private String         errorMsg;
	private int            applicantAnswId;
	private int            order;
	private boolean        skipped;
	private boolean        skippedThreeTimes;
	private boolean 	   queNotAnswered;
	
	public boolean isQueNotAnswered() {
		return queNotAnswered;
	}
	public void setQueNotAnswered(boolean queNotAnswered) {
		this.queNotAnswered = queNotAnswered;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public boolean isSkipped() {
		return skipped;
	}
	public void setSkipped(boolean skipped) {
		this.skipped = skipped;
	}
	public boolean isSkippedThreeTimes() {
		return skippedThreeTimes;
	}
	public void setSkippedThreeTimes(boolean skippedThreeTimes) {
		this.skippedThreeTimes = skippedThreeTimes;
	}
	public int getApplicantAnswId() {
		return applicantAnswId;
	}
	public void setApplicantAnswId(int applicantAnswId) {
		this.applicantAnswId = applicantAnswId;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	public void setQuestionLang(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang) {
		this.questionLang = quesLang;
	}
	public List<Answer> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public HandbookRef getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(HandbookRef handbookRef) {
		this.handbookRef = handbookRef;
	}

}

