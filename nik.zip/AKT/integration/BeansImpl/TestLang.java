package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class TestLang {

	private TLPrimaryKey tlPrimaryKey;
	private String       langId;
	private String       testLangName;
	private String       testLangStatus;
	private boolean      signTestSatisfied;
	private boolean      print;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public TestLang() {
		tlPrimaryKey = new TLPrimaryKey();
	}
	public boolean isPrint() {
		return print;
	}
	public void setPrint(boolean print) {
		this.print = print;
	}
	public boolean isSignTestSatisfied() {
		return signTestSatisfied;
	}
	public void setSignTestSatisfied(boolean signTestSatisfied) {
		this.signTestSatisfied = signTestSatisfied;
	}
	public TLPrimaryKey getTlPrimaryKey() {
		return tlPrimaryKey;
	}
	public void setTlPrimaryKey(TLPrimaryKey tlPrimaryKey) {
		this.tlPrimaryKey = tlPrimaryKey;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getTestLangName() {
		return testLangName;
	}
	public void setTestLangName(String testLangName) {
		this.testLangName = testLangName;
	}
	public String getTestLangStatus() {
		return testLangStatus;
	}
	public void setTestLangStatus(String testLangStatus) {
		this.testLangStatus = testLangStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
