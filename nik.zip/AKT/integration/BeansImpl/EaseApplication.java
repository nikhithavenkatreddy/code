package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IVault;

import java.util.List;

public class EaseApplication {

	private IVault          vault;
	private IApplication    application;
	private List<EaseTest> easeTestListRequired;
	private List<EaseTest> easeTestListOptional;
	
	public List<EaseTest> getEaseTestListRequired() {
		return easeTestListRequired;
	}
	public void setEaseTestListRequired(List<EaseTest> easeTestListRequired) {
		this.easeTestListRequired = easeTestListRequired;
	}
	public List<EaseTest> getEaseTestListOptional() {
		return easeTestListOptional;
	}
	public void setEaseTestListOptional(List<EaseTest> easeTestListOptional) {
		this.easeTestListOptional = easeTestListOptional;
	}
	public IVault getVault() {
		return vault;
	}
	public void setVault(IVault vault) {
		this.vault = vault;
	}
	public IApplication getApplication() {
		return application;
	}
	public void setApplication(IApplication application2) {
		this.application = application2;
	}

}
