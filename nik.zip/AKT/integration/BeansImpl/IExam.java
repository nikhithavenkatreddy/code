package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public interface IExam extends Serializable {

	String getSecondaryVerificationId();

	void setSecondaryVerificationId(String secondaryVerificationId);

	String getSignTestFlag();

	void setSignTestFlag(String signTestFlag);

	String getLangId();

	void setLangId(String langId);

	String getTestTypeCode();

	void setTestTypeCode(String testTypeCode);

	String getOptionalTestInd();

	void setOptionalTestInd(String optionalTestInd);

	String getQuickPassFailFlag();

	void setQuickPassFailFlag(String quickPassFailFlag);

	Integer getExamId();

	void setExamId(Integer examId);

	Integer getApplicationId();

	void setApplicationId(Integer applicationId);

	String getTestId();

	void setTestId(String testId);

	String getPassFailIndicator();

	void setPassFailIndicator(String passFailIndicator);

	String getCdlFlag();

	void setCdlFlag(String cdlFlag);

	String getOfficeId();

	void setOfficeId(String officeId);

	Date getExamStartTime();

	void setExamStartTime(Date examStartTime);

	Date getExamEndTime();

	void setExamEndTime(Date examEndTime);

	String getCompletionReasonCode();

	void setCompletionReasonCode(String completionReasonCode);

	Integer getIncorrectAnswerCount();

	void setIncorrectAnswerCount(Integer incorrectAnswerCount);

	Integer getMaxIncorrectNumber();

	void setMaxIncorrectNumber(Integer maxIncorrectNumber);

	Integer getExamQuestionNumber();

	void setExamQuestionNumber(Integer examQuestionNumber);

	Integer getQuestionAnsweredCount();

	void setQuestionAnsweredCount(Integer questionAnsweredCount);

	Integer getCorrectQuestionCount();

	void setCorrectQuestionCount(Integer correctQuestionCount);

	Date getEaseTimestamp();

	void setEaseTimestamp(Date easeTimestamp);

	Integer getExamOrder();

	void setExamOrder(Integer examOrder);

	Integer getSessionId();

	void setSessionId(Integer sessionId);

	String getEaseTestId();

	void setEaseTestId(String easeTestId);

	String getLastModUsername();

	void setLastModUsername(String lastModUsername);

	Date getLastModUserTime();

	void setLastModUserTime(Date lastModUserTime);
	
	BigDecimal getScore();	
	
	void setScore(BigDecimal score);
	
	void setScoreToNull();

	Integer getRemainingTime();

	void setRemainingTime(Integer remainingTime);
}