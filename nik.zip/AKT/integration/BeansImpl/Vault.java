package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IVault;

import java.util.Date;

public class Vault implements IVault {
	private Integer       vaultId;
	private String        applicationLastName;
	private String        applicationFirstName;
	private String        dlNumber;
	private String        state;
	private java.sql.Date birthDate;
	private Date          vaultTimestamp;
	private String        lastModUsername;
	private Date          lastModUserTime;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getVaultId()
	 */
	@Override
	public Integer getVaultId() {
		return vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setVaultId(java.lang.Integer)
	 */
	@Override
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getApplicationLastName()
	 */
	@Override
	public String getApplicationLastName() {
		return applicationLastName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setApplicationLastName(java.lang.String)
	 */
	@Override
	public void setApplicationLastName(String applicationLastName) {
		this.applicationLastName = applicationLastName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getApplicationFirstName()
	 */
	@Override
	public String getApplicationFirstName() {
		return applicationFirstName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setApplicationFirstName(java.lang.String)
	 */
	@Override
	public void setApplicationFirstName(String applicationFirstName) {
		this.applicationFirstName = applicationFirstName;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getDlNumber()
	 */
	@Override
	public String getDlNumber() {
		return dlNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setDlNumber(java.lang.String)
	 */
	@Override
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getBirthDate()
	 */
	@Override
	public java.sql.Date getBirthDate() {
		return birthDate;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setBirthDate(java.sql.Date)
	 */
	@Override
	public void setBirthDate(java.sql.Date birthDate) {
		this.birthDate = birthDate;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getVaultTimestamp()
	 */
	@Override
	public Date getVaultTimestamp() {
		return vaultTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setVaultTimestamp(java.util.Date)
	 */
	@Override
	public void setVaultTimestamp(Date vaultTimestamp) {
		this.vaultTimestamp = vaultTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.Beans.IVault#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
