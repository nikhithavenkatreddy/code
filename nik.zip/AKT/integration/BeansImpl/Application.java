package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IApplication;

import java.util.Date;

@SuppressWarnings("serial")
public class Application implements IApplication {

	private Integer       applicationId;
	private Integer       vaultId;
	private String        classLicenseCode;
	private String        endorsementCode;
	private String        officeId;
	private String        osFlag;
	private java.sql.Date dlExpirationDate;
	private Date          applicationTimestamp;
	private String        renewalFlag;
	private String        pauseCount;
	private String        applicationStatusCode;
	private String        forceFailFlag;
	private String        techId;
	private String        easeApplicationId;
	private String        signTestSatisfiedFlag;
	private String        applicationType;
	private String        lastModUsername;
	private Date          lastModUserTime;
	private String        audioVideoTestCode;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getAudioVideoTestCode()
	 */
	@Override
	public String getAudioVideoTestCode() {
		return audioVideoTestCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setAudioVideoTestCode(java.lang.String)
	 */
	@Override
	public void setAudioVideoTestCode(String audioVideoTestCode) {
		this.audioVideoTestCode = audioVideoTestCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getApplicationType()
	 */
	@Override
	public String getApplicationType() {
		return applicationType;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setApplicationType(java.lang.String)
	 */
	@Override
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getSignTestSatisfiedFlag()
	 */
	@Override
	public String getSignTestSatisfiedFlag() {
		return signTestSatisfiedFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setSignTestSatisfiedFlag(java.lang.String)
	 */
	@Override
	public void setSignTestSatisfiedFlag(String signTestSatisfiedFlag) {
		this.signTestSatisfiedFlag = signTestSatisfiedFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getEaseApplicationId()
	 */
	@Override
	public String getEaseApplicationId() {
		return easeApplicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setEaseApplicationId(java.lang.String)
	 */
	@Override
	public void setEaseApplicationId(String easeApplicationId) {
		this.easeApplicationId = easeApplicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getApplicationId()
	 */
	@Override
	public Integer getApplicationId() {
		return applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setApplicationId(java.lang.Integer)
	 */
	@Override
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getVaultId()
	 */
	@Override
	public Integer getVaultId() {
		return vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setVaultId(java.lang.Integer)
	 */
	@Override
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getClassLicenseCode()
	 */
	@Override
	public String getClassLicenseCode() {
		return classLicenseCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setClassLicenseCode(java.lang.String)
	 */
	@Override
	public void setClassLicenseCode(String classLicenseCode) {
		this.classLicenseCode = classLicenseCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getEndorsementCode()
	 */
	@Override
	public String getEndorsementCode() {
		return endorsementCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setEndorsementCode(java.lang.String)
	 */
	@Override
	public void setEndorsementCode(String endorsementCode) {
		this.endorsementCode = endorsementCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getOfficeId()
	 */
	@Override
	public String getOfficeId() {
		return officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setOfficeId(java.lang.String)
	 */
	@Override
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getOsFlag()
	 */
	@Override
	public String getOsFlag() {
		return osFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setOsFlag(java.lang.String)
	 */
	@Override
	public void setOsFlag(String osFlag) {
		this.osFlag = osFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getDlExpirationDate()
	 */
	@Override
	public java.sql.Date getDlExpirationDate() {
		return dlExpirationDate;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setDlExpirationDate(java.sql.Date)
	 */
	@Override
	public void setDlExpirationDate(java.sql.Date dlExpirationDate) {
		this.dlExpirationDate = dlExpirationDate;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getApplicationTimestamp()
	 */
	@Override
	public Date getApplicationTimestamp() {
		return applicationTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setApplicationTimestamp(java.util.Date)
	 */
	@Override
	public void setApplicationTimestamp(Date applicationTimestamp) {
		this.applicationTimestamp = applicationTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getRenewalFlag()
	 */
	@Override
	public String getRenewalFlag() {
		return renewalFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setRenewalFlag(java.lang.String)
	 */
	@Override
	public void setRenewalFlag(String renewalFlag) {
		this.renewalFlag = renewalFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getPauseCount()
	 */
	@Override
	public String getPauseCount() {
		return pauseCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setPauseCount(java.lang.String)
	 */
	@Override
	public void setPauseCount(String pauseCount) {
		this.pauseCount = pauseCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getApplicationStatusCode()
	 */
	@Override
	public String getApplicationStatusCode() {
		return applicationStatusCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setApplicationStatusCode(java.lang.String)
	 */
	@Override
	public void setApplicationStatusCode(String applicationStatusCode) {
		this.applicationStatusCode = applicationStatusCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getForceFailFlag()
	 */
	@Override
	public String getForceFailFlag() {
		return forceFailFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setForceFailFlag(java.lang.String)
	 */
	@Override
	public void setForceFailFlag(String forceFailFlag) {
		this.forceFailFlag = forceFailFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getTechId()
	 */
	@Override
	public String getTechId() {
		return techId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setTechId(java.lang.String)
	 */
	@Override
	public void setTechId(String techId) {
		this.techId = techId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IApplication#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
