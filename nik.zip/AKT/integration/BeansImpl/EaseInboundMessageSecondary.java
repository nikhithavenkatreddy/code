package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;

import java.util.Date;

@SuppressWarnings("serial")
public class EaseInboundMessageSecondary implements IEaseInboundMessage {

	private Integer easeMessageId;
	private Date    easeMessageReceivedTimestamp;
	private String  easeApplicationMessage;
	private String  easeMessageIndicator;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public Integer getEaseMessageId() {
		return easeMessageId;
	}
	public void setEaseMessageId(Integer easeMessageId) {
		this.easeMessageId = easeMessageId;
	}
	public Date getEaseMessageReceivedTimestamp() {
		return easeMessageReceivedTimestamp;
	}
	public void setEaseMessageReceivedTimestamp(Date easeMessageReceivedTimestamp) {
		this.easeMessageReceivedTimestamp = easeMessageReceivedTimestamp;
	}
	public String getEaseApplicationMessage() {
		return easeApplicationMessage;
	}
	public void setEaseApplicationMessage(String easeApplicationMessage) {
		this.easeApplicationMessage = easeApplicationMessage;
	}
	public String getEaseMessageIndicator() {
		return easeMessageIndicator;
	}
	public void setEaseMessageIndicator(String easeMessageIndicator) {
		this.easeMessageIndicator = easeMessageIndicator;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
