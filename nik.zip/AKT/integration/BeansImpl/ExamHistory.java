package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IExamHistory;

import java.util.Date;

public class ExamHistory implements IExamHistory {
	
	private Integer pastExamId;
	private Integer applicationId;
	private String  easeTestId;
	private String  easeStatusIndicator;
	private Date    easeReceivedTimestamp;
	private String  aktStatusIndicator;
	private Date    aktUpdatedTimestamp;
	private String  lastModusername;
	private Date    lastModUserTime;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getPastExamId()
	 */
	@Override
	public Integer getPastExamId() {
		return pastExamId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setPastExamId(java.lang.Integer)
	 */
	@Override
	public void setPastExamId(Integer pastExamId) {
		this.pastExamId = pastExamId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getApplicationId()
	 */
	@Override
	public Integer getApplicationId() {
		return applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setApplicationId(java.lang.Integer)
	 */
	@Override
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getEaseTestId()
	 */
	@Override
	public String getEaseTestId() {
		return easeTestId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setEaseTestId(java.lang.String)
	 */
	@Override
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getEaseStatusIndicator()
	 */
	@Override
	public String getEaseStatusIndicator() {
		return easeStatusIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setEaseStatusIndicator(java.lang.String)
	 */
	@Override
	public void setEaseStatusIndicator(String easeStatusIndicator) {
		this.easeStatusIndicator = easeStatusIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getEaseReceivedTimestamp()
	 */
	@Override
	public Date getEaseReceivedTimestamp() {
		return easeReceivedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setEaseReceivedTimestamp(java.util.Date)
	 */
	@Override
	public void setEaseReceivedTimestamp(Date easeReceivedTimestamp) {
		this.easeReceivedTimestamp = easeReceivedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getAktStatusIndicator()
	 */
	@Override
	public String getAktStatusIndicator() {
		return aktStatusIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setAktStatusIndicator(java.lang.String)
	 */
	@Override
	public void setAktStatusIndicator(String aktStatusIndicator) {
		this.aktStatusIndicator = aktStatusIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getAktUpdatedTimestamp()
	 */
	@Override
	public Date getAktUpdatedTimestamp() {
		return aktUpdatedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setAktUpdatedTimestamp(java.util.Date)
	 */
	@Override
	public void setAktUpdatedTimestamp(Date aktUpdatedTimestamp) {
		this.aktUpdatedTimestamp = aktUpdatedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getLastModusername()
	 */
	@Override
	public String getLastModusername() {
		return lastModusername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setLastModusername(java.lang.String)
	 */
	@Override
	public void setLastModusername(String lastModusername) {
		this.lastModusername = lastModusername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExamHistory#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
