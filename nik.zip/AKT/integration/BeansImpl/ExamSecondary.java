package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.constants.Constant;

import java.math.BigDecimal;
import java.util.Date;

@SuppressWarnings("serial")
public class ExamSecondary implements IExam {
	private Integer examId;
	private Integer applicationId;
	private String  testId;
	private String  passFailIndicator;
	private String  cdlFlag;
	private String  quickPassFailFlag;
	private String  officeId;
	private Date    examStartTime;
	private Date    examEndTime;
	private String  completionReasonCode;
	private Integer incorrectAnswerCount;
	private Integer maxIncorrectNumber;
	private Integer examQuestionNumber;
	private Integer questionAnsweredCount;
	private Integer correctQuestionCount;
	private Date    easeTimestamp;
	private Integer examOrder;
	private Integer sessionId;
	private String  easeTestId;
	private String  langId;
	private String  testTypeCode;
	private String  optionalTestInd;
	private String  signTestFlag;
	private BigDecimal score = new BigDecimal(0.00);
	private String  lastModUsername;
	private Date    lastModUserTime;
	private Integer	remainingTime;
	private String  secondaryVerificationId;
	
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getRemainingTime()
	 */
	@Override
	public Integer getRemainingTime() {
		return remainingTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setRemainingTime(Integer remainingTime)
	 */
	@Override
	public void setRemainingTime(Integer remainingTime) {
		this.remainingTime = remainingTime;
	}
	@Override
	public BigDecimal getScore() {
		this.setScore();
		return score;
	}
	private void setScore() {
		if (this.getPassFailIndicator() == null ||
			this.getPassFailIndicator().equals(Constant.SINGLE_SPACE) ||
			this.getCdlFlag() == null || 
			this.getCompletionReasonCode() == null ||
			this.getExamQuestionNumber() == null) {
			return;
		}
		if(this.getCdlFlag().equalsIgnoreCase(Constant.NO)) {
			double score = ((double)((double)this.getCorrectQuestionCount()/(double)this.getExamQuestionNumber()) * 100.0);
			BigDecimal scoreDec = new BigDecimal(String.valueOf(score));
			scoreDec = scoreDec.setScale(2, BigDecimal.ROUND_HALF_UP);
			this.score = scoreDec;
		}
	}
	
	@Override
	public void setScore(BigDecimal score) {
		//this.score = score;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getSecondaryVerificationId()
	 */
	@Override
	public String getSecondaryVerificationId() {
		return secondaryVerificationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setSecondaryVerificationId(java.lang.String)
	 */
	@Override
	public void setSecondaryVerificationId(String secondaryVerificationId) {
		this.secondaryVerificationId = secondaryVerificationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getSignTestFlag()
	 */
	@Override
	public String getSignTestFlag() {
		return signTestFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setSignTestFlag(java.lang.String)
	 */
	@Override
	public void setSignTestFlag(String signTestFlag) {
		this.signTestFlag = signTestFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getLangId()
	 */
	@Override
	public String getLangId() {
		return langId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setLangId(java.lang.String)
	 */
	@Override
	public void setLangId(String langId) {
		this.langId = langId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getTestTypeCode()
	 */
	@Override
	public String getTestTypeCode() {
		return testTypeCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setTestTypeCode(java.lang.String)
	 */
	@Override
	public void setTestTypeCode(String testTypeCode) {
		this.testTypeCode = testTypeCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getOptionalTestInd()
	 */
	@Override
	public String getOptionalTestInd() {
		return optionalTestInd;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setOptionalTestInd(java.lang.String)
	 */
	@Override
	public void setOptionalTestInd(String optionalTestInd) {
		this.optionalTestInd = optionalTestInd;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getQuickPassFailFlag()
	 */
	@Override
	public String getQuickPassFailFlag() {
		return quickPassFailFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setQuickPassFailFlag(java.lang.String)
	 */
	@Override
	public void setQuickPassFailFlag(String quickPassFailFlag) {
		this.quickPassFailFlag = quickPassFailFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getExamId()
	 */
	@Override
	public Integer getExamId() {
		return examId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setExamId(java.lang.Integer)
	 */
	@Override
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getApplicationId()
	 */
	@Override
	public Integer getApplicationId() {
		return applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setApplicationId(java.lang.Integer)
	 */
	@Override
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getTestId()
	 */
	@Override
	public String getTestId() {
		return testId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setTestId(java.lang.String)
	 */
	@Override
	public void setTestId(String testId) {
		this.testId = testId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getPassFailIndicator()
	 */
	@Override
	public String getPassFailIndicator() {
		return passFailIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setPassFailIndicator(java.lang.String)
	 */
	@Override
	public void setPassFailIndicator(String passFailIndicator) {
		this.passFailIndicator = passFailIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getCdlFlag()
	 */
	@Override
	public String getCdlFlag() {
		return cdlFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setCdlFlag(java.lang.String)
	 */
	@Override
	public void setCdlFlag(String cdlFlag) {
		this.cdlFlag = cdlFlag;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getOfficeId()
	 */
	@Override
	public String getOfficeId() {
		return officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setOfficeId(java.lang.String)
	 */
	@Override
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getExamStartTime()
	 */
	@Override
	public Date getExamStartTime() {
		return examStartTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setExamStartTime(java.util.Date)
	 */
	@Override
	public void setExamStartTime(Date examStartTime) {
		this.examStartTime = examStartTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getExamEndTime()
	 */
	@Override
	public Date getExamEndTime() {
		return examEndTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setExamEndTime(java.util.Date)
	 */
	@Override
	public void setExamEndTime(Date examEndTime) {
		this.examEndTime = examEndTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getCompletionReasonCode()
	 */
	@Override
	public String getCompletionReasonCode() {
		return completionReasonCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setCompletionReasonCode(java.lang.String)
	 */
	@Override
	public void setCompletionReasonCode(String completionReasonCode) {
		this.completionReasonCode = completionReasonCode;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getIncorrectAnswerCount()
	 */
	@Override
	public Integer getIncorrectAnswerCount() {
		return incorrectAnswerCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setIncorrectAnswerCount(java.lang.Integer)
	 */
	@Override
	public void setIncorrectAnswerCount(Integer incorrectAnswerCount) {
		this.incorrectAnswerCount = incorrectAnswerCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getMaxIncorrectNumber()
	 */
	@Override
	public Integer getMaxIncorrectNumber() {
		return maxIncorrectNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setMaxIncorrectNumber(java.lang.Integer)
	 */
	@Override
	public void setMaxIncorrectNumber(Integer maxIncorrectNumber) {
		this.maxIncorrectNumber = maxIncorrectNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getExamQuestionNumber()
	 */
	@Override
	public Integer getExamQuestionNumber() {
		return examQuestionNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setExamQuestionNumber(java.lang.Integer)
	 */
	@Override
	public void setExamQuestionNumber(Integer examQuestionNumber) {
		this.examQuestionNumber = examQuestionNumber;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getQuestionAnsweredCount()
	 */
	@Override
	public Integer getQuestionAnsweredCount() {
		return questionAnsweredCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setQuestionAnsweredCount(java.lang.Integer)
	 */
	@Override
	public void setQuestionAnsweredCount(Integer questionAnsweredCount) {
		this.questionAnsweredCount = questionAnsweredCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getCorrectQuestionCount()
	 */
	@Override
	public Integer getCorrectQuestionCount() {
		return correctQuestionCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setCorrectQuestionCount(java.lang.Integer)
	 */
	@Override
	public void setCorrectQuestionCount(Integer correctQuestionCount) {
		this.correctQuestionCount = correctQuestionCount;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getEaseTimestamp()
	 */
	@Override
	public Date getEaseTimestamp() {
		return easeTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setEaseTimestamp(java.util.Date)
	 */
	@Override
	public void setEaseTimestamp(Date easeTimestamp) {
		this.easeTimestamp = easeTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getExamOrder()
	 */
	@Override
	public Integer getExamOrder() {
		return examOrder;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setExamOrder(java.lang.Integer)
	 */
	@Override
	public void setExamOrder(Integer examOrder) {
		this.examOrder = examOrder;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getSessionId()
	 */
	@Override
	public Integer getSessionId() {
		return sessionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setSessionId(java.lang.Integer)
	 */
	@Override
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getEaseTestId()
	 */
	@Override
	public String getEaseTestId() {
		return easeTestId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setEaseTestId(java.lang.String)
	 */
	@Override
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IExam#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
	public void setScoreToNull() {
		this.score = null;
	}
}
