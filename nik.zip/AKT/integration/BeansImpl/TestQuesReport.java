package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.List;

public class TestQuesReport {

	private String           testId;
	private List<QuesReport> quesReports;
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public List<QuesReport> getQuesReports() {
		return quesReports;
	}
	public void setQuesReports(List<QuesReport> quesReports) {
		this.quesReports = quesReports;
	}
	
}
