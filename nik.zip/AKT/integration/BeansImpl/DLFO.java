package gov.ca.dmv.AKT.integration.BeansImpl;

public class DLFO {

	private String  dlNumber;
	private String  officeId;
	
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	
}
