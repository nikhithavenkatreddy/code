package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;
import java.util.Date;

public class Answer implements Serializable{

	private Integer answerGenId;
	private Integer questionGenId;
	private String  answerId;
	private String  correctAnswerInd;
	private String  answerText;
	private String  answerStatus;
	private String  signImage;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private String  answerAudio;
	private String  answerVideo;
	private String  changeReviewStatusCode;
	
	public String getAnswerAudio() {
		return answerAudio;
	}
	public void setAnswerAudio(String answerAudio) {
		this.answerAudio = answerAudio;
	}
	public String getAnswerVideo() {
		return answerVideo;
	}
	public void setAnswerVideo(String answerVideo) {
		this.answerVideo = answerVideo;
	}
	public String getChangeReviewStatusCode() {
		return changeReviewStatusCode;
	}
	public void setChangeReviewStatusCode(String changeReviewStatusCode) {
		this.changeReviewStatusCode = changeReviewStatusCode;
	}
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	public String getSignImage() {
		return signImage;
	}
	public void setSignImage(String signImage) {
		this.signImage = signImage;
	}
	public Integer getAnswerGenId() {
		return answerGenId;
	}
	public void setAnswerGenId(Integer answerGenId) {
		this.answerGenId = answerGenId;
	}
	public String getAnswerId() {
		return answerId;
	}
	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}
	public String getCorrectAnswerInd() {
		return correctAnswerInd;
	}
	public void setCorrectAnswerInd(String correctAnswerInd) {
		this.correctAnswerInd = correctAnswerInd;
	}
	public String getAnswerText() {
		return answerText;
	}
	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}
	public String getAnswerStatus() {
		return answerStatus;
	}
	public void setAnswerStatus(String answerStatus) {
		this.answerStatus = answerStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
