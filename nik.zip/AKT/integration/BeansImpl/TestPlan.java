package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class TestPlan implements Serializable{

	private TPPrimaryKey tpPrimaryKey;
	private Integer      categoryOrder;
	private Integer      categoryQuestionCount;
	private String       gradableFlag;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public TestPlan() {
		tpPrimaryKey = new TPPrimaryKey();
	}
	public TPPrimaryKey getTpPrimaryKey() {
		return tpPrimaryKey;
	}
	public void setTpPrimaryKey(TPPrimaryKey tpPrimaryKey) {
		this.tpPrimaryKey = tpPrimaryKey;
	}
	public Integer getCategoryOrder() {
		return categoryOrder;
	}
	public void setCategoryOrder(Integer categoryOrder) {
		this.categoryOrder = categoryOrder;
	}
	public Integer getCategoryQuestionCount() {
		return categoryQuestionCount;
	}
	public void setCategoryQuestionCount(Integer categoryQuestionCount) {
		this.categoryQuestionCount = categoryQuestionCount;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getGradableFlag() {
		return gradableFlag;
	}
	public void setGradableFlag(String gradableFlag) {
		this.gradableFlag = gradableFlag;
	}
	
}
