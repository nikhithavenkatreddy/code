package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IVault;

import java.util.Date;

public class VaultSecondary implements IVault {
	private Integer vaultId;
	private String  applicationLastName;
	private String  applicationFirstName;
	private String  dlNumber;
	private String  state;
	private java.sql.Date    birthDate;
	private Date    vaultTimestamp;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public Integer getVaultId() {
		return vaultId;
	}
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	public String getApplicationLastName() {
		return applicationLastName;
	}
	public void setApplicationLastName(String applicationLastName) {
		this.applicationLastName = applicationLastName;
	}
	public String getApplicationFirstName() {
		return applicationFirstName;
	}
	public void setApplicationFirstName(String applicationFirstName) {
		this.applicationFirstName = applicationFirstName;
	}
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	public java.sql.Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(java.sql.Date birthDate) {
		this.birthDate = birthDate;
	}
	public Date getVaultTimestamp() {
		return vaultTimestamp;
	}
	public void setVaultTimestamp(Date vaultTimestamp) {
		this.vaultTimestamp = vaultTimestamp;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
