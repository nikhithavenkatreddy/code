package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class ThresholdDictionary {

	private String thresholdName;
	private String thresholdValue;
	private String lastModUsername;
	private Date   lastModUserTime;
	
	public String getThresholdName() {
		return thresholdName;
	}
	public void setThresholdName(String thresholdName) {
		this.thresholdName = thresholdName;
	}
	public String getThresholdValue() {
		return thresholdValue;
	}
	public void setThresholdValue(String thresholdValue) {
		this.thresholdValue = thresholdValue;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
