package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class EQPrimaryKey implements Serializable{

	private Integer examId;
	private Integer questionPresentedOrder;
	
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Integer getQuestionPresentedOrder() {
		return questionPresentedOrder;
	}
	public void setQuestionPresentedOrder(Integer questionPresentedOrder) {
		this.questionPresentedOrder = questionPresentedOrder;
	}
	
}
