package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class HandbookRef {

	private HRPrimaryKey hrPrimaryKey;
	private String handbookSectionName;
	private String handbookSectionDesc;
	private String lastModUsername;
	private Date lastModUserTime;
	
	public HandbookRef() {
		hrPrimaryKey = new HRPrimaryKey();
	}
	public HRPrimaryKey getHrPrimaryKey() {
		return hrPrimaryKey;
	}
	public void setHrPrimaryKey(HRPrimaryKey hrPrimaryKey) {
		this.hrPrimaryKey = hrPrimaryKey;
	}
	public String getHandbookSectionName() {
		return handbookSectionName;
	}
	public void setHandbookSectionName(String handbookSectionName) {
		this.handbookSectionName = handbookSectionName;
	}
	public String getHandbookSectionDesc() {
		return handbookSectionDesc;
	}
	public void setHandbookSectionDesc(String handbookSectionDesc) {
		this.handbookSectionDesc = handbookSectionDesc;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
	
}
