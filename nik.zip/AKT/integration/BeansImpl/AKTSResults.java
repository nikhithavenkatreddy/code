package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class AKTSResults {

	private Integer sysId;
	private String  officeId;
	private String  techId;
	private Integer appId;
	private String  dlNumber;
	private String  easeTestId;
	private String  passFailInd;
	private String  langId;
	private Date    resultSentTimestamp;
	private String  resultStatusCode;
	private String  creatorId;
	private Date    createTimestamp;
	private String  modifiedBy;
	private Date    modifiedTimestamp;
	
	public Integer getSysId() {
		return sysId;
	}
	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getPassFailInd() {
		return passFailInd;
	}
	public void setPassFailInd(String passFailInd) {
		this.passFailInd = passFailInd;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public Date getResultSentTimestamp() {
		return resultSentTimestamp;
	}
	public void setResultSentTimestamp(Date resultSentTimestamp) {
		this.resultSentTimestamp = resultSentTimestamp;
	}
	public String getResultStatusCode() {
		return resultStatusCode;
	}
	public void setResultStatusCode(String resultStatusCode) {
		this.resultStatusCode = resultStatusCode;
	}
	public String getCreatorId() {
		return creatorId;
	}
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}
	public Date getCreateTimestamp() {
		return createTimestamp;
	}
	public void setCreateTimestamp(Date createTimestamp) {
		this.createTimestamp = createTimestamp;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedTimestamp() {
		return modifiedTimestamp;
	}
	public void setModifiedTimestamp(Date modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
	}
	
}
