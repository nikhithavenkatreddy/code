package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class ExamHistorySecondary {
	
	private Integer pastExamId;
	private Integer applicationId;
	private String  easeTestId;
	private String  easeStatusIndicator;
	private Date    easeReceivedTimestamp;
	private String  aktStatusIndicator;
	private Date    aktUpdatedTimestamp;
	private String  lastModusername;
	private Date    lastModUserTime;
	
	public Integer getPastExamId() {
		return pastExamId;
	}
	public void setPastExamId(Integer pastExamId) {
		this.pastExamId = pastExamId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getEaseStatusIndicator() {
		return easeStatusIndicator;
	}
	public void setEaseStatusIndicator(String easeStatusIndicator) {
		this.easeStatusIndicator = easeStatusIndicator;
	}
	public Date getEaseReceivedTimestamp() {
		return easeReceivedTimestamp;
	}
	public void setEaseReceivedTimestamp(Date easeReceivedTimestamp) {
		this.easeReceivedTimestamp = easeReceivedTimestamp;
	}
	public String getAktStatusIndicator() {
		return aktStatusIndicator;
	}
	public void setAktStatusIndicator(String aktStatusIndicator) {
		this.aktStatusIndicator = aktStatusIndicator;
	}
	public Date getAktUpdatedTimestamp() {
		return aktUpdatedTimestamp;
	}
	public void setAktUpdatedTimestamp(Date aktUpdatedTimestamp) {
		this.aktUpdatedTimestamp = aktUpdatedTimestamp;
	}
	public String getLastModusername() {
		return lastModusername;
	}
	public void setLastModusername(String lastModusername) {
		this.lastModusername = lastModusername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
