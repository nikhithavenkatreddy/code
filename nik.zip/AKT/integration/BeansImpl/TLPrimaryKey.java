package gov.ca.dmv.AKT.integration.BeansImpl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TLPrimaryKey implements Serializable{

	private String testLangId;
	private String testId;
	
	public String getTestLangId() {
		return testLangId;
	}
	public void setTestLangId(String testLangId) {
		this.testLangId = testLangId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
}
