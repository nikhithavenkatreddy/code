package gov.ca.dmv.AKT.integration.BeansImpl;

import java.util.Date;

public class TimeLimit {

	private Integer timeLimitId;
	private String  timeLimitName;
	private String  timeLimitDescription;
	private Integer timeLimitValue;	
	private Integer timeLimitRangeMin;
	private Integer timeLimitRangeMax;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	public Integer getTimeLimitRangeMin() {
		return timeLimitRangeMin;
	}
	public void setTimeLimitRangeMin(Integer timeLimitRangeMin) {
		this.timeLimitRangeMin = timeLimitRangeMin;
	}
	public Integer getTimeLimitRangeMax() {
		return timeLimitRangeMax;
	}
	public void setTimeLimitRangeMax(Integer timeLimitRangeMax) {
		this.timeLimitRangeMax = timeLimitRangeMax;
	}
	public Integer getTimeLimitId() {
		return timeLimitId;
	}
	public void setTimeLimitId(Integer timeLimitId) {
		this.timeLimitId = timeLimitId;
	}
	public String getTimeLimitName() {
		return timeLimitName;
	}
	public void setTimeLimitName(String timeLimitName) {
		this.timeLimitName = timeLimitName;
	}
	public String getTimeLimitDescription() {
		return timeLimitDescription;
	}
	public void setTimeLimitDescription(String timeLimitDescription) {
		this.timeLimitDescription = timeLimitDescription;
	}
	public Integer getTimeLimitValue() {
		return timeLimitValue;
	}
	public void setTimeLimitValue(Integer timeLimitValue) {
		this.timeLimitValue = timeLimitValue;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
	
	
}
