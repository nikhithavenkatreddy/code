package gov.ca.dmv.AKT.integration.BeansImpl;

import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;

import java.util.Date;

@SuppressWarnings("serial")
public class EaseInboundMessage implements IEaseInboundMessage {

	private Integer easeMessageId;
	private Date    easeMessageReceivedTimestamp;
	private String  easeApplicationMessage;
	private String  easeMessageIndicator;
	private String  lastModUsername;
	private Date    lastModUserTime;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getEaseMessageId()
	 */
	@Override
	public Integer getEaseMessageId() {
		return easeMessageId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setEaseMessageId(java.lang.Integer)
	 */
	@Override
	public void setEaseMessageId(Integer easeMessageId) {
		this.easeMessageId = easeMessageId;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getEaseMessageReceivedTimestamp()
	 */
	@Override
	public Date getEaseMessageReceivedTimestamp() {
		return easeMessageReceivedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setEaseMessageReceivedTimestamp(java.util.Date)
	 */
	@Override
	public void setEaseMessageReceivedTimestamp(Date easeMessageReceivedTimestamp) {
		this.easeMessageReceivedTimestamp = easeMessageReceivedTimestamp;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getEaseApplicationMessage()
	 */
	@Override
	public String getEaseApplicationMessage() {
		return easeApplicationMessage;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setEaseApplicationMessage(java.lang.String)
	 */
	@Override
	public void setEaseApplicationMessage(String easeApplicationMessage) {
		this.easeApplicationMessage = easeApplicationMessage;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getEaseMessageIndicator()
	 */
	@Override
	public String getEaseMessageIndicator() {
		return easeMessageIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setEaseMessageIndicator(java.lang.String)
	 */
	@Override
	public void setEaseMessageIndicator(String easeMessageIndicator) {
		this.easeMessageIndicator = easeMessageIndicator;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getLastModUsername()
	 */
	@Override
	public String getLastModUsername() {
		return lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setLastModUsername(java.lang.String)
	 */
	@Override
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#getLastModUserTime()
	 */
	@Override
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.AKT.integration.BeansImpl.IEaseInboundMessage#setLastModUserTime(java.util.Date)
	 */
	@Override
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
