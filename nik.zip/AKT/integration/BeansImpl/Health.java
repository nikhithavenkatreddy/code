package gov.ca.dmv.AKT.integration.BeansImpl;

public class Health {

	private String cacheStatus;
	
	public String getCacheStatus() {
		return cacheStatus;
	}
	public void setCacheStatus(String cacheStatus) {
		this.cacheStatus = cacheStatus;
	}
}
