package gov.ca.dmv.AKT.integration.Hibernate;

import org.apache.log4j.Logger;
import org.hibernate.EmptyInterceptor;

public class DB2Interceptor extends EmptyInterceptor {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(DB2Interceptor.class.getName());
	@Override
	public String onPrepareStatement(String str) {

		// Transform the original query into lower case
		String compstr = str.toLowerCase();

		// Check if we're dealing with a simple select statement
		/*if (compstr.matches("^select.*") && compstr.matches(".*and 1=1.*") && !compstr.matches(".*order by.*")) {
		//if (compstr.matches("^select.*") && !compstr.matches(".*order by.*")) {
			if (!compstr.matches(".*for update with cs.*")) {
				str += " for update with cs ";

				//if (logger.isDebugEnabled()) {
					//logger.debug("Appending \"WITH UR\" to query.");
				//}
			}
		}*/
		//else if (compstr.matches("^select.*") && !compstr.matches(".*and 1=1.*")) {
		if (compstr.matches("^select.*")) {
			if (!compstr.matches(".*with ur.*")) {
				//str.replaceAll("and rahul", "");
				str += " with ur ";
				/*
				if (logger.isDebugEnabled()) {
					logger.debug("Appending \"FOR READ ONLY\" to query.");
				}*/
			}
		}
		return str;
	}

}
