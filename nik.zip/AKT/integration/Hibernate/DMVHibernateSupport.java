package gov.ca.dmv.AKT.integration.Hibernate;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public abstract class DMVHibernateSupport extends HibernateDaoSupport {

}
