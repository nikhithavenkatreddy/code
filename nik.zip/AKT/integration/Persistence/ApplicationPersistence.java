package gov.ca.dmv.AKT.integration.Persistence;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;

import java.util.Date;
import java.util.List;

/**
 * 
 * @author MWRZA
 *
 * Application Persistence acts as the persistence layer to persist records related to application and exam history
 *  
 * load(Object param): This method is called to load application from the application table by application id.
 * 
 * 
 */
public interface ApplicationPersistence {

	public List<Application> loadByVaultId(Object param);
	public void              update(Object[] params, String aktStatusIndicator, Date aktUpdateTimestamp);
	public void              update(Object param, String forceFailIndicator);
	/**
	 * 
	 * @param application.
	 * This method is called to save/update the application record in the application table.
	 */
	public void              saveApplication(IApplication application);
	public List<Application> load(Object param);
	public List<IExamHistory> loadExamHistoryByAppId(Object param);
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return List<Application>.
	 * This method is called to load today's applications based on the office id.
	 */
	public List<IApplication> loadTodaysApps(String officeId, String appType);
	/**
	 * 
	 * @param officeId.
	 * @param fromDate.
	 * @param toDate.
	 * @param appType.
	 * @return List<Application>.
	 * This method is called to get a list of field office type applications (no ds/ol apps) based on the office id, appType and date range (inclusive). 
	 */
	public List<IApplication> loadAppsByOfficeIdAndDateRange(String officeId, Date fromDate, Date toDate, String appType);

	/**
	 * @param today.
	 * @param appType.
	 * This method is called to get a list of todays' or past applications based on the app type (across the office ids) and list of vaults.
	 */
	public List<IApplication> loadAppsByAppTypeAndVaultList(boolean today, String appType, String dlNum, String lastName, Date fromDate, Date toDate);
	
}
