package gov.ca.dmv.AKT.integration.Persistence;

import java.util.List;

import gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;

public interface TestPersistence {

	//public List<Test>               load();
	public List<Test>               loadByTestId(Object param);
	public List<QuickPassFailEvent> load(Object param);
	public List<TestPlan>           loadTestPlan(Object param);
	public List<TestLang>           load(Object[] params);
	public List<Test>               loadQPFList(Object[] params);
	public List<Test>               loadByEaseTestId(Object param);
	/**
	 * 
	 * @param params (Contains the question id and question status).
	 * @return List<Test>.
	 * This method is called to load the test based on the question id.
	 */
	public List<Test>               loadByQuestionId(Object[] params);
	public void                     saveQPFEvent(QuickPassFailEvent qpf);
	public List<Test>               loadSignTest(Object param);
	public void                     save(Test test);
	public List<TestPlan>           loadAllTestPlans();
	public List<TestLang>           loadAllTestLang(Object param);	
}
