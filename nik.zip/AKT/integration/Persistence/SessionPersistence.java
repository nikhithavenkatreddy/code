package gov.ca.dmv.AKT.integration.Persistence;

import gov.ca.dmv.AKT.integration.Beans.ISession;

import java.util.Date;
import java.util.List;

public interface SessionPersistence {

	public List<ISession> load(Object param);
	public List<ISession> loadAllSessions(Object[] params);
	public void save(ISession session);
	public void update(Object param, Date endTime);
	public List<ISession> loadFailedYOB(Object[] params);
	public void updateYOBOverrideTime(Object param, Date overrideTime);
	public void reset(Object param, Date sessionEndTime, Date yobOverrideTime, String yobValidationFlag, String sessionStatusCode);
	public void resetTerminal(Object param, String workstationIPAddress);
	public void updateWithYOBFail(Object param, Date endTime, String yobValidationFlag);

}
