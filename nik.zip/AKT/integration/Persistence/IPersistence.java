package gov.ca.dmv.AKT.integration.Persistence;

import gov.ca.dmv.AKT.integration.BeansImpl.Audit;

import java.util.List;
import java.util.Map;

/**
 * @author MWRZA
 * IPersistence provides the generic persistence layer to persist any object
 * 
 */
public interface IPersistence {
	/**
	 * This method return all records from the class table.
	 * @param entityClass
	 * @return
	 */
	public List loadAll(Class entityClass);
	/**
	 * 
	 * @param object contains the values of its attributes that are treated as 'where' clause parameters.
	 * @return List<object>.
	 * This method returns a list of the object passed as a parameter to the method based on the attributes set on the object.
	 */
	@SuppressWarnings("unchecked")
	public List findByExample(Object object);
	/**
	 * 
	 * @param object that is updated.
	 * This method is called to update a record.
	 */
	public void update(Object object);
	/**
	 * 
	 * @param objects that needs to be updated.
	 * This method is called to update a list of records.
	 */
	@SuppressWarnings("unchecked")
	public void updateList(List objects);
	/**
	 * @param objects that needs to be deleted
	 * This method is called to delete a list of records.
	 */
	public void deleteList(List objects);
	/**
	 * 
	 * @param object that will be inserted into its table.
	 * This method is called to save a new record.
	 */
	public void save(Object object);
	
	/**
	 * 
	 * @param object that will be inserted into its table.
	 * This method is called to save or update a new record.
	 */
	public void saveOrUpdate(Object object);
	
	/**
	 * 
	 * @param object that will be inserted or updated into its table.
	 * This method is called to save a new record.
	 */

	public void saveOrUpdateList(List object);
		
	/**
	 * 
	 * @param objects that will be inserted into their table.
	 * This method is called to save a list of new records.
	 */
	@SuppressWarnings("unchecked")
	public void saveList(List objects);
	/**
	 * 
	 * @param obj contains the class of the object that is expected to be retrieved.
	 * @param params contains the where clause parameters and its corresponding values.
	 * @param orders define the columns by which the result set needs to be ordered by.
	 * @return List<obj>.
	 * This method is called to load records with conditions set for the 'where' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithConditionsAndOrderBy(Class obj, Map<String, Object> params, List<String> orders);
	/**
	 * 
	 * @param obj contains the class of the object that is expected to be retrieved.
	 * @param params contains the where clause parameters and its corresponding values.
	 * @param orders define the columns by which the result set needs to be ordered by.
	 * @return List<obj>.
	 * This method is called to load records with conditions set for the case-insensitive 'where' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithLikeConditionsIgnoreCaseAndOrderBy(Class obj, Map<String, Object> params, List<String> orders);
	/**
	 * 
	 * @param obj gives the class of the object we are trying to find by its id.
	 * @param Id is the id of obj.
	 * @return the object that is retrieved by id.
	 * This method is called to retrieve an object based on the id.
	 */
	public Object findById(Object obj, Object Id);
	/**
	 * 
	 * @param obj contains the class of the object that is expected to be retrieved.
	 * @param params contains the where clause/like clause parameters and its corresponding values.
	 * @param orders define the columns by which the result set needs to be ordered by.
	 * @return List<obj>.
	 * This method is called to load records with conditions set for the 'where/like' and 'order by' clause.
	 */
	@SuppressWarnings("unchecked")
	public List loadWithLikeConditionsAndOrderBy(Class obj, Map<String, Object> params, List<String> orders);
	
	/**
	 * This method is called to return a list of audit records based on a list of ids.
	 */
	public List<Audit> loadAuditsByIds(List<String> idList);
}
