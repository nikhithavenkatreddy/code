package gov.ca.dmv.AKT.integration.Persistence;

import java.util.List;

import gov.ca.dmv.AKT.integration.BeansImpl.Category;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;

public interface CategoryPersistence {

	public List<Category> load2(Object param);
	/**
	 * 
	 * @param params (Contains the parent question id and question status).
	 * @return List<QuestionList>.
	 * This method is called to load the question list record based on the question id.
	 */
	public List<QuestionList> load(Object[] params);
	public List<QuestionList> loadByQuestionIdAndQuestionStatus(Object[] params);
	public void update(Object param, QuestionList ql);
	/**
	 * 
	 * @param params (Contains the parent question id and question status).
	 * @return List<Category>.
	 * This method is called to load the category based on the question id.
	 */
	public List<Category> loadByQuestionId(Object[] params);
	public List<TestPlan> loadByTestId(Object[] params);
	
}
