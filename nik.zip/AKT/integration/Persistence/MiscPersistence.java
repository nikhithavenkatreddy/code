package gov.ca.dmv.AKT.integration.Persistence;

import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.ThresholdDictionary;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;

import java.util.List;

/**
 * 
 * @author MWRZA
 *
 * MiscPersistence acts as the persistence layer to persist objects like language, workstationmap, threshold dictionary and ease inbound message.
 * 
 * loadByWorkstationIP(Object param): This method is called to load the workstation map record by ip address.
 */
public interface MiscPersistence {

	public List<Lang>                load();
	public List<Lang>                loadByLanguageIdCode(Object param);
	public List<ThresholdDictionary> loadThreshold(Object param);
	public void                      saveEaseReceivedString(IEaseInboundMessage message);
	public List<IEaseInboundMessage>  loadEaseInboundMessage(Object param);
	public List<WorkstationMap>      loadAllWorkstationMap();
	public List<ThresholdDictionary> loadAllThreshold();
}
