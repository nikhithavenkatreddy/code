package gov.ca.dmv.AKT.integration.Persistence;

import java.util.Date;
import java.util.List;

import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;

/**
 * 
 * @author MWRZA
 *
 * ApplicantPersistence acts as the persistence layer to persist vault and applicant information
 * 
 * load(Object param): This method is called to load vault by vault id.
 */
public interface ApplicantPersistence {

	public List<Vault> load(Object param);
	public List<Vault> loadByDL(Object param);
	public void        save(IVault vault);
	public List<Vault> loadByDLAndVaultTstamp(Object[] params);
	
	/**
	 * 
	 * @param param1 is the DL #.
	 * @param param2 is the applicant's last name.
	 * @param fromDate.
	 * @param toDate.
	 * @param today.
	 * @return List<IVault>.
	 * This method is called to partial-search today or past vault records based on DL # and Last name
	 */
	public List<IVault> loadByDLLastNameAndDateRange(String dlNum, String lastName, Date fromDate, Date toDate, boolean today);
	/**
	 * 
	 * @param params (Contains office id and app type).
	 * @return List<IVault>.
	 * This method is called to load a list of vaults based on office id and app type.
	 */
	public List<Vault> loadAllVaults(Object[] params) ;
}
