package gov.ca.dmv.AKT.integration.Persistence;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.util.Date;
import java.util.List;
/**
 * 
 * @author MWRZA
 *
 * ExamPersistence acts as a persistence layer to persist information regarding exams.
 * 
 * loadByTestIdAndDiffExamId(Object[] params): This method is called to get exam by testId, FO and different examId.
 */
public interface ExamPersistence {

	//public List<IExam>              load(Object[] params);
	public List<IExam>              loadByExamId(Object param);
	public List<IExamHistory>       loadByExamHistId(Object param);
	public List<IExam>              loadByAppIdAndDifferentSessionId(Object[] params);
	public void                    update(Object param, Date endTime, String reasonCode, String passFailIndicator);
	public void                    save(IExam exam);
	public List<IExamAnswer>        loadExamAnswer(Object[] params);
	public List<IExam>              loadByStartDateAndNoEndDate(Object[] params);
	public List<IExam>              loadByStartDateAndNoEndDateAndAppType(Object[] params);
	public void                    deleteStub(Object[] params);
	public void                    save(IExamQuestion examQuestion);
	public void                    save(IExamAnswer examAnswer);
	/**
	 * 
	 * @param params (Contains the exam id, test id, office id, exam start time and exam end time).
	 * @return List<IExam>.
	 * This method is called to get completed exam records by testId, FO and different examId.
	 */
	public List<IExam>              loadByTestIdAndDiffExamId(Object[] params);
	/**
	 * 
	 * @param param is exam id.
	 * @return List<IExamQuestion>.
	 * This method returns a list of exam question records based on the exam id.
	 */
	public List<IExamQuestion>      getExamQues(Object param);
	public void                    updateEaseTransactionTime(Object param, Date easeTransactionTime);
	/**
	 * 
	 * @param params (Contains session id and app type).
	 * @return List<IExam>.
	 * This method is called to load a list of exams that have started but not ended based on the session id and app type.
	 */
	public List<IExam>              loadBySessionId(Object[] params);
	public void                    save(IExamHistory examHistory);
	public List<IExamQuestion>      loadExamQues(Object[] params);
	public List<IExamAnswer>        loadByExamIdAndQuestionGenId(Object[] params);
	public List<IExam>              loadSignExam(Object[] params);
	/**
	 * 
	 * @param params (exam id and answer status = no).
	 * @return List<IExamQuestion>.
	 * This method is called to get a list of exam question records based on the exam id that were incorrectly answered by the applicant.
	 */
	public List<IExamQuestion>      getMissedExamQues(Object[] params);
	/**
	 * 
	 * @param params (exam id and question gen id)
	 * @return List<IExamAnswer>.
	 * This method is called to get a list of exam answer records based on exam id and question gen id.
	 */
	public List<IExamAnswer>        getExamAnsw(Object[] params);
	/**
	 * 
	 * @param params (Contains app id).
	 * @return List<IExam>.
	 * This method is called to load the completed exams based on the app id.
	 */
	public List<IExam>             loadCompletedExams(Object[] params);
	public List<IExam>              loadByAppIdAndTestId(Object[] params);
	/**
	 * 
	 * @param params (Contains office id and app type).
	 * @return List<IExam>.
	 * This method is called to load a list of quit exams based on office id and app type.
	 */
	public List<IExam>              loadQuitExams(Object[] params);
	public List<IExam> 				loadAllExams(Object[] params);
	public List<String>            loadDistinctTests();
	public List<IExam>              loadExamsByTestId(Object param);
	public List<IExam>              loadOutstandingExams(Object[] params);
	/**
	 * 
	 * @param params (result status code and office id).
	 * @return List<AKTSResults>.
	 * This method is called to generate reports for records that did not get updated at the EASE end.
	 */
	public List<AKTSResults>       loadEASEExceptionRecords(Object[] params);
	public void                    updateExceptionRep(Object param);
	public void                    save(List<IExamQuestion> examQuestionList);
	public void                    saveExamAnsList(List<IExamAnswer> examAnswerList);
	/**
	 * 
	 * @param param is the application id.
	 * @return List<IExam>.
	 * This method is called to load exams by application id that have not started yet.
	 */
	public List<IExam>              loadExamsNotStartedByAppId(Object param);
	/**
	 * 
	 * @param appIds (Contains the application ids).
	 * @return List<IExam>.
	 * This method is called to return a list of paused exams based on a list of application ids.
	 */
	public List<IExam> loadPausedExamsByAppIds(List<Integer> appIds);
	/**
	 * This method is called to return a list of non-completed exams based on a list of application ids.
	 * @param appIds
	 * @return
	 */
	public List<IExam> loadAllExamsByAppIds(List<Integer> appIds);
	
	/**
	 * This method is called to return a list of records for question pass/fail rate report.
	 * @return
	 */
	public List<QuesPassRate> getQuesPassRateList(Date fromDate, Date toDate);
	
	/**
	 * This method is called to return a list of exams' questions based on exam id.
	 * @param appIds
	 * @return
	 */	
	public List<ExamQuestion> getExamQuesOrderedByModTime(Object param);
	public List<IExamAnswer> getExamAnswOrderByAnswPresOrd(Object[] params);
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenIds(Integer examId, List<Integer> questionGenIds) throws AKTException;
}
