package gov.ca.dmv.AKT.integration.Persistence;

import java.util.List;

import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.BeansImpl.Question;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;

public interface QuestionPersistence {

	public List<HandbookRef> load();
	public List<HandbookRef> loadByHandbookRef(Object[] params);
	//public List<Question> load(Object param);
	public List<QuestionLang> loadByQuestionLangIdAndLastModUserTime(Object[] params);
	public void save(QuestionList questionList);
	public void updateByQuestionGenId(Object param);
	public void update2(Object param);
	public List<Answer> loadByAnsGenId(Object param);
	/**
	 * 
	 * @return List<String>.
	 * This method is called to get a list of all parent question ids.
	 */
	public List<String> loadAllQuestionIds();
	public List<QuestionLang> loadQuesLang(Object param);
	public List<Question> loadAllActiveQuestions(Object param);
	public List<QuestionLang> loadAllActiveQuestionLang(Object[] params);
	public List<Answer> loadAllActiveAnswers(Object param);
	public List<QuestionList> loadAllActiveQuesList(Object param);
	public List<QuestionLang> loadQuestionLang();
	/**
	 * 
	 * @param params (Contains question lang id, question lang status and change review status code).
	 * @return List<QuestionLang>.
	 * This method is called to load the active language specific question by question lang id.
	 */
	public List<QuestionLang> loadActiveQuestionLangByQuesLangId(Object[] params);
	/**
	 * Load Ques Lang By Partial Text.
	 * @param params
	 * @return
	 */
	public List<QuestionLang> loadQuesLangByPartialText(Object[] params);
}
