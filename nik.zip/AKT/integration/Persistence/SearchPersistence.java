package gov.ca.dmv.AKT.integration.Persistence;

import java.util.List;

import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;

public interface SearchPersistence {

	public List<QuestionLang> load(Object param);
	public List<QuestionLang> loadForTest(Object param);
	public List<QuestionLang> loadActiveQuestions(Object[] params);
	public List<QuestionLang> loadByTestAndCategory(Object[] params);

}
