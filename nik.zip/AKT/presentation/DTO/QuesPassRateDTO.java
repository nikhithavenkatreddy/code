package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.util.List;

public class QuesPassRateDTO {

	private int                errorCode;
	private List<QuesPassRate> quesReports;
	private String          fromDate;
	private String          toDate;
	
	public List<QuesPassRate> getQuesReports() {
		return quesReports;
	}

	public void setQuesReports(List<QuesPassRate> quesReports) {
		this.quesReports = quesReports;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
	
}
