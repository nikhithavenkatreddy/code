package gov.ca.dmv.AKT.presentation.DTO;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectReceived;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectSent;
import gov.ca.dmv.AKT.presentation.Beans.Application;
import gov.ca.dmv.AKT.presentation.Beans.EaseTest;
import gov.ca.dmv.AKT.presentation.Beans.Exam;
import gov.ca.dmv.AKT.presentation.Beans.Vault;

public class EaseAppDTO {

	private Vault          vault;
	private Application    application;
	private List<EaseTest> easeTestListRequired;
	private List<EaseTest> easeTestListOptional;
	private Exam           exam;
	private EASEObjectSent easeObjectSent;
	private int            errorCode;
	private Integer        easeMsgId;
	private String         receivedString;
	private String         easeReceivedMessageInd;
	private String         signTestHistory;
	private boolean 	   messageSent;
	

	public boolean isMessageSent() {
		return messageSent;
	}

	public void setMessageSent(boolean messageSent) {
		this.messageSent = messageSent;
	}

	public String getSignTestHistory() {
		return signTestHistory;
	}

	public void setSignTestHistory(String signTestHistory) {
		this.signTestHistory = signTestHistory;
	}

	public String getEaseReceivedMessageInd() {
		return easeReceivedMessageInd;
	}

	public void setEaseReceivedMessageInd(String easeReceivedMessageInd) {
		this.easeReceivedMessageInd = easeReceivedMessageInd;
	}

	public String getReceivedString() {
		return receivedString;
	}

	public void setReceivedString(String receivedString) {
		this.receivedString = receivedString;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public EASEObjectSent getEaseObjectSent() {
		return easeObjectSent;
	}

	public void setEaseObjectSent(EASEObjectSent easeObjectSent) {
		this.easeObjectSent = easeObjectSent;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public List<EaseTest> getEaseTestListRequired() {
		return easeTestListRequired;
	}

	public void setEaseTestListRequired(List<EaseTest> easeTestListRequired) {
		this.easeTestListRequired = easeTestListRequired;
	}

	public List<EaseTest> getEaseTestListOptional() {
		return easeTestListOptional;
	}

	public void setEaseTestListOptional(List<EaseTest> easeTestListOptional) {
		this.easeTestListOptional = easeTestListOptional;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Vault getVault() {
		return vault;
	}

	public void setVault(Vault vault) {
		this.vault = vault;
	}
	
	public IVault getVaultAfterBusTierConversion() {
		IVault vault2 = new gov.ca.dmv.AKT.integration.BeansImpl.Vault();
		vault2.setApplicationFirstName(vault.getApplicationFirstName());
		vault2.setApplicationLastName(vault.getApplicationLastName());
		vault2.setBirthDate(vault.getBirthDate());
		vault2.setDlNumber(vault.getDlNumber());
		vault2.setLastModUsername(vault.getLastModUsername());
		vault2.setLastModUserTime(vault.getLastModUserTime());
		vault2.setVaultId(vault.getVaultId());
		vault2.setVaultTimestamp(vault.getVaultTimestamp());
		return vault2;
	}
	
	public IApplication getApplicationAfterBusTierConversion() {
		IApplication app2 = new gov.ca.dmv.AKT.integration.BeansImpl.Application();
		app2.setApplicationId(application.getApplicationId());
		app2.setApplicationStatusCode(application.getApplicationStatusCode());
		app2.setApplicationTimestamp(application.getApplicationTimestamp());
		app2.setClassLicenseCode(application.getClassLicenseCode());
		app2.setDlExpirationDate(application.getDlExpirationDate());
		app2.setEndorsementCode(application.getEndorsementCode());
		app2.setForceFailFlag(application.getForceFailFlag());
		app2.setLastModUsername(application.getLastModUsername());
		app2.setLastModUserTime(application.getLastModUserTime());
		app2.setOfficeId(application.getOfficeId());
		app2.setOsFlag(application.getOsFlag());
		app2.setPauseCount(application.getPauseCount());
		app2.setRenewalFlag(application.getRenewalFlag());
		app2.setTechId(application.getTechId());
		app2.setVaultId(application.getVaultId());
		app2.setEaseApplicationId(application.getEaseApplicationId());
		app2.setSignTestSatisfiedFlag(application.getSignTestSatisfiedFlag());
		//app2.setAssignedStatus(application.getAssignedStatus());
		//app2.setAssignedTimestamp(application.getAssignedTimestamp());
		app2.setApplicationType(application.getApplicationType());
		app2.setAudioVideoTestCode(application.getAudioVideoTestCode());
		return app2;
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest> getEaseTestListRequiredAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest> easeTestListRequired1 =	new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest>();
		for(EaseTest easeTest: easeTestListRequired) {
			gov.ca.dmv.AKT.integration.BeansImpl.EaseTest easeTest1 = new gov.ca.dmv.AKT.integration.BeansImpl.EaseTest();
			easeTest1.setEaseStatusIndicator(easeTest.getEaseStatusIndicator());
			easeTest1.setEaseTestId(easeTest.getEaseTestId());
			easeTestListRequired1.add(easeTest1);
		}
		return easeTestListRequired1;
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest> getEaseTestListOptionalAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest> easeTestListOptional1 =	new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.EaseTest>();
		for(EaseTest easeTest: easeTestListOptional) {
			gov.ca.dmv.AKT.integration.BeansImpl.EaseTest easeTest1 = new gov.ca.dmv.AKT.integration.BeansImpl.EaseTest();
			easeTest1.setEaseStatusIndicator(easeTest.getEaseStatusIndicator());
			easeTest1.setEaseTestId(easeTest.getEaseTestId());
			easeTestListOptional1.add(easeTest1);
		}
		return easeTestListOptional1;
	}
	
	public void setExamAfterPreTierConversion(IExam exam3) {
		Exam exam2 = new Exam();
		exam2.setApplicationId(exam3.getApplicationId());
		exam2.setCdlFlag(exam3.getCdlFlag());
		exam2.setCompletionReasonCode(exam3.getCompletionReasonCode());
		exam2.setCorrectQuestionCount(exam3.getCorrectQuestionCount());
		exam2.setEaseTestId(exam3.getEaseTestId());
		exam2.setEaseTimestamp(exam3.getEaseTimestamp());
		exam2.setExamEndTime(exam3.getExamEndTime());
		exam2.setExamId(exam3.getExamId());
		exam2.setExamOrder(exam3.getExamOrder());
		exam2.setExamQuestionNumber(exam3.getExamQuestionNumber());
		exam2.setExamStartTime(exam3.getExamStartTime());
		exam2.setIncorrectAnswerCount(exam3.getIncorrectAnswerCount());
		exam2.setLangId(exam3.getLangId());
		exam2.setLastModUsername(exam3.getLastModUsername());
		exam2.setLastModUserTime(exam3.getLastModUserTime());
		exam2.setMaxIncorrectNumber(exam3.getMaxIncorrectNumber());
		exam2.setOfficeId(exam3.getOfficeId());
		exam2.setOptionalTestInd(exam3.getOptionalTestInd());
		exam2.setPassFailIndicator(exam3.getPassFailIndicator());
		exam2.setQuestionAnsweredCount(exam3.getQuestionAnsweredCount());
		exam2.setQuickPassFailFlag(exam3.getQuickPassFailFlag());
		exam2.setSessionId(exam3.getSessionId());
		exam2.setSignTestFlag(exam3.getSignTestFlag());
		exam2.setTestId(exam3.getTestId());
		exam2.setTestTypeCode(exam3.getTestTypeCode());
		exam2.setSecondaryVerificationId(exam3.getSecondaryVerificationId());
		setExam(exam2);
	}
	
	public void create(EASEObjectReceived easeObj) {
		Vault vault = new Vault();
		String firstName = easeObj.getFirstName().trim();
		if(firstName.trim().length() < Constant.ONE)
			firstName = Constant.SINGLE_SPACE;
		vault.setApplicationFirstName(firstName);
		vault.setApplicationLastName(easeObj.getLastName().trim());
		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		java.util.Date birthDateUtil = null;
		java.util.Date dlExpirationDateUtil = null;
		try {
			birthDateUtil = formatter.parse(easeObj.getBirthDate().trim());
			if(easeObj.getExpirationDate().trim().length() < Constant.EIGHT)
				dlExpirationDateUtil = Constant.defaultDate;
			else
				dlExpirationDateUtil = formatter.parse(easeObj.getExpirationDate().trim());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date birthDateSql = new Date(birthDateUtil.getTime());
		vault.setBirthDate(birthDateSql);
		vault.setDlNumber(easeObj.getDlNumber().trim());
		vault.setLastModUsername(easeObj.getTechId());
		java.util.Date currentDate = new java.util.Date();
		vault.setLastModUserTime(currentDate);
		vault.setVaultTimestamp(currentDate);
		
		Application app = new Application();
		app.setApplicationTimestamp(currentDate);
		app.setClassLicenseCode(easeObj.getAppliedForClass1().trim() + easeObj.getAppliedForClass2().trim());
		Date dlExpirationDateSql = new Date(dlExpirationDateUtil.getTime());
		app.setDlExpirationDate(dlExpirationDateSql);
		app.setEaseApplicationId(easeObj.getApplicationId().trim());
		//We are only going to consider 5 endorsements out of the 6 endorsements sent by EASE
		String endorsement = easeObj.getAppliedForEndorsement1().trim() + easeObj.getAppliedForEndorsement2().trim() + easeObj.getAppliedForEndorsement3().trim() + easeObj.getAppliedForEndorsement4().trim() + easeObj.getAppliedForEndorsement5().trim();
		if(endorsement.trim().length() < Constant.ONE)
			endorsement = Constant.SINGLE_SPACE;
		app.setEndorsementCode(endorsement);
		//
		app.setForceFailFlag(Constant.NO);
		app.setLastModUsername(easeObj.getTechId());
		app.setLastModUserTime(currentDate);
		app.setOfficeId(easeObj.getOfficeId().trim());
		app.setOsFlag(easeObj.getOutOfStateIndicator().trim());
		app.setPauseCount(String.valueOf(Constant.ZERO));
		if(easeObj.getOriginalIndicator().trim().equalsIgnoreCase(Constant.YES))
			app.setRenewalFlag(Constant.NO);
		else
			app.setRenewalFlag(Constant.YES);
		if(easeObj.getSignTestHistory().trim().equalsIgnoreCase(Constant.PASS))
			app.setSignTestSatisfiedFlag(Constant.YES);
		else
			app.setSignTestSatisfiedFlag(Constant.NO);
		app.setTechId(easeObj.getTechId().trim());
		app.setApplicationStatusCode(Constant.SINGLE_SPACE);
		//app.setAssignedStatus(Constant.SINGLE_SPACE);
		//app.setAssignedTimestamp(currentDate);
		app.setApplicationType(Constant.APP_TYPE_FO);
		app.setAudioVideoTestCode(easeObj.getAudioVideoTestCode());
		
		List<EaseTest> easeTestListRequired = new ArrayList<EaseTest>();
		List<EaseTest> easeTestListOptional = new ArrayList<EaseTest>();
		if(easeObj.getTest01().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest01().trim());
			if(easeObj.getTest01().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest01History().trim());
			if(easeObj.getTest01Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest02().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest02().trim());
			if(easeObj.getTest02().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest02History().trim());
			if(easeObj.getTest02Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest03().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest03().trim());
			if(easeObj.getTest03().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest03History().trim());
			if(easeObj.getTest03Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest04().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest04().trim());
			if(easeObj.getTest04().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest04History().trim());
			if(easeObj.getTest04Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest05().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest05().trim());
			if(easeObj.getTest05().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest05History().trim());
			if(easeObj.getTest05Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest06().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest06().trim());
			if(easeObj.getTest06().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest06History().trim());
			if(easeObj.getTest06Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest07().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest07().trim());
			if(easeObj.getTest07().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest07History().trim());
			if(easeObj.getTest07Optional().trim().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest08().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest08().trim());
			if(easeObj.getTest08().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest08History().trim());
			if(easeObj.getTest08Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest09().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest09().trim());
			if(easeObj.getTest09().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest09History().trim());
			if(easeObj.getTest09Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest10().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest10().trim());
			if(easeObj.getTest10().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest10History().trim());
			if(easeObj.getTest10Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest11().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest11().trim());
			if(easeObj.getTest11().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest11History().trim());
			if(easeObj.getTest11Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest12().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest12().trim());
			if(easeObj.getTest12().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest12History().trim());
			if(easeObj.getTest12Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		if(easeObj.getTest13().trim().length() != Constant.ZERO) {
			EaseTest easeTest = new EaseTest();
			easeTest.setEaseTestId(easeObj.getTest13().trim());
			if(easeObj.getTest13().trim().equalsIgnoreCase(Constant.EASE_PROVISIONAL))
				app.setApplicationStatusCode(Constant.PROVISIONAL);
			easeTest.setEaseStatusIndicator(easeObj.getTest13History().trim());
			if(easeObj.getTest13Optional().equalsIgnoreCase(Constant.YES))
				easeTestListOptional.add(easeTest);
			else
				easeTestListRequired.add(easeTest);
		}
		
		this.vault = vault;
		this.application = app;
		this.easeTestListOptional = easeTestListOptional;
		this.easeTestListRequired = easeTestListRequired;
		this.signTestHistory = easeObj.getSignTestHistory();
	}

	public Integer getEaseMsgId() {
		return easeMsgId;
	}

	public void setEaseMsgId(Integer easeMsgId) {
		this.easeMsgId = easeMsgId;
	}
}
