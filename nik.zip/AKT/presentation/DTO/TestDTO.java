package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.QPFList;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.ArrayList;
import java.util.List;

public class TestDTO {

	private List<Test> testList;
	private List<Lang> langList;
	private int        errorCode;
	private String     techId;
	private String     group;
	
	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<Lang> getLangList() {
		return langList;
	}

	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}

	public List<Test> getTestList() {
		return testList;
	}

	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	
	public void setTestListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList2) {
		List<Test> testList1 = new ArrayList<Test>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Test test2: testList2)
		{
			Test test = new Test();
			test.setCdlFlag(test2.getCdlFlag().trim().equals(Constant.YES));
			test.setDefaultLangFlag(test2.getDefaultLangFlag());
			test.setEaseTestId(test2.getEaseTestId());
			test.setLastModUsername(test2.getLastModUsername());
			test.setLastModUserTime(test2.getLastModUserTime());
			test.setMaxIncorrectNum(test2.getMaxIncorrectNum());
			test.setQuickPassFailInd(test2.getQuickPassFailInd().trim().equals(Constant.YES));
			test.setTestQuestionCount(test2.getTestQuestionCount());
			test.setTestId(test2.getTestId());
			test.setTestName(test2.getTestName());
			test.setTestStatusCode(test2.getTestStatusCode());
			test.setTestTypeCode(test2.getTestTypeCode());
			test.setOptionalTestInd(test2.getOptionalTestInd());
			test.setTestOrder(test2.getTestOrder());
			test.setSignTestFlag(test2.getSignTestFlag());
			test.setRequiredSignTest(test2.getRequiredSignTest());
			test.setEnglishOnlyFlag(test2.getEnglishOnlyFlag());
			test.setTestOrigin(test2.getTestOrigin());
			test.setTimeLimit(test2.getTimeLimit());
			if (test2.getQuickFailInd().equals(Constant.YES)) {
				test.setQuickFailInd(true);
			} 
			else {
				test.setQuickFailInd(false);
			}
			
			if (test2.getQuickPassInd().equals(Constant.YES)) {
				test.setQuickPassInd(true);
			} 
			else {
				test.setQuickPassInd(false);
			}
				
			testList1.add(test);
		}
		setTestList(testList1);
	}
	
	public void setLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList1) {
		List<Lang> langList2 = new ArrayList<Lang>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang: langList1) {
			Lang lang2 = new Lang();
			lang2.setLangId(lang.getLangId());
			lang2.setLangName(lang.getLangName());
			lang2.setLastModUsername(lang.getLastModUsername());
			lang2.setLastModUserTime(lang.getLastModUserTime());
			lang2.setProgLangCode(lang.getProgLangCode());
			langList2.add(lang2);
		}
		setLangList(langList2);
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Test> getTestListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Test>();
		for(Test test2: testList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Test test = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
			test.setCdlFlag(test2.isCdlFlag()?Constant.YES:Constant.NO);
			test.setDefaultLangFlag(test2.getDefaultLangFlag());
			test.setEaseTestId(test2.getEaseTestId());
			test.setLastModUsername(test2.getLastModUsername());
			test.setLastModUserTime(test2.getLastModUserTime());
			test.setMaxIncorrectNum(test2.getMaxIncorrectNum());
			test.setQuickPassFailInd(test2.isQuickPassFailInd()?Constant.YES:Constant.NO);
			test.setTestQuestionCount(test2.getTestQuestionCount());
			test.setTestId(test2.getTestId());
			test.setTestName(test2.getTestName());
			test.setTestStatusCode(test2.getTestStatusCode());
			test.setTestTypeCode(test2.getTestTypeCode());
			test.setOptionalTestInd(test2.getOptionalTestInd());
			test.setTestOrder(test2.getTestOrder());
			test.setSignTestFlag(test2.getSignTestFlag());
			test.setRequiredSignTest(test2.getRequiredSignTest());
			test.setEnglishOnlyFlag(test2.getEnglishOnlyFlag());
			test.setQuickFailInd(test2.isQuickFailInd()?Constant.YES:Constant.NO);
			test.setQuickPassInd(test2.isQuickPassInd()?Constant.YES:Constant.NO);
			test.setTestOrigin(test2.getTestOrigin());
			test.setTimeLimit(test2.getTimeLimit());
			testList2.add(test);
		}
		return testList2;
	}
}
