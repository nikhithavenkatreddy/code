package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.integration.BeansImpl.TPPrimaryKey;
import gov.ca.dmv.AKT.presentation.Beans.Test;
import gov.ca.dmv.AKT.presentation.Beans.TestPlan;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestPlanDTO {
	private Test test = new Test();
	private List<TestPlan> testPlanList;
	private int        errorCode;
	
	public Test getTest() {
		return test;
	}

	public void setTest(Test test) {
		this.test = test;
	}

	public List<TestPlan> getTestPlanList() {
		return testPlanList;
	}

	public void setTestPlanList(List<TestPlan> testPlanList) {
		this.testPlanList = testPlanList;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
	public void setTestQuestionCount() {
		int totalQuestions = 0;
		for (TestPlan testPlan : testPlanList) {
			totalQuestions = totalQuestions + testPlan.getCategoryQuestionCount();
		}
		test.setTestQuestionCount(Integer.toString(totalQuestions));
	}
	
	public void setTestIdInTestPlan() {
		for (TestPlan testPlan : testPlanList) {
			testPlan.setTestId(test.getTestId());
		}
	}
	
	public void setTestAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.Test test2) {
		Test test = new Test();
		test.setCdlFlag(test2.getCdlFlag().trim().equals(Constant.YES));
		test.setDefaultLangFlag(test2.getDefaultLangFlag());
		test.setEaseTestId(test2.getEaseTestId());
		test.setLastModUsername(test2.getLastModUsername());
		test.setLastModUserTime(test2.getLastModUserTime());
		test.setMaxIncorrectNum(test2.getMaxIncorrectNum());
		test.setQuickPassFailInd(test2.getQuickPassFailInd().trim().equals(Constant.YES));
		test.setTestQuestionCount(test2.getTestQuestionCount());
		test.setTestId(test2.getTestId());
		test.setTestName(test2.getTestName());
		test.setTestStatusCode(test2.getTestStatusCode());
		test.setTestTypeCode(test2.getTestTypeCode());
		test.setOptionalTestInd(test2.getOptionalTestInd());
		test.setTestOrder(test2.getTestOrder());
		test.setSignTestFlag(test2.getSignTestFlag());
		test.setRequiredSignTest(test2.getRequiredSignTest());
		test.setEnglishOnlyFlag(test2.getEnglishOnlyFlag());
		test.setTimeLimit(test2.getTimeLimit());
		test.setTestOrigin(test2.getTestOrigin().trim());
		if (test2.getQuickFailInd().equals(Constant.YES)) {
			test.setQuickFailInd(true);
		} 
		else {
			test.setQuickFailInd(false);
		}
		
		if (test2.getQuickPassInd().equals(Constant.YES)) {
			test.setQuickPassInd(true);
		} 
		else {
			test.setQuickPassInd(false);
		}
		setTest(test);
	}
	
	public gov.ca.dmv.AKT.integration.BeansImpl.Test getTestAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.Test test1 = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
		test1.setCdlFlag(test.isCdlFlag()?Constant.YES:Constant.NO);
		test1.setDefaultLangFlag(test.getDefaultLangFlag());
		test1.setEaseTestId(test.getEaseTestId());
		test1.setLastModUsername(test.getLastModUsername());
		test1.setLastModUserTime(test.getLastModUserTime());
		test1.setMaxIncorrectNum(test.getMaxIncorrectNum());
		test1.setQuickPassFailInd(test.isQuickPassFailInd()?Constant.YES:Constant.NO);
		test1.setTestQuestionCount(test.getTestQuestionCount());
		test1.setTestId(test.getTestId().trim().toUpperCase());
		test1.setTestName(test.getTestName());
		test1.setTestStatusCode(test.getTestStatusCode());
		test1.setTestTypeCode(test.getTestTypeCode());
		test1.setOptionalTestInd(test.getOptionalTestInd());
		test1.setTestOrigin(test.getTestOrigin());
		test1.setTimeLimit(test.getTimeLimit());
		test1.setTestOrder(test.getTestOrder());
		test1.setSignTestFlag(test.getSignTestFlag());
		test1.setRequiredSignTest(test.getRequiredSignTest());
		test1.setEnglishOnlyFlag(test.getEnglishOnlyFlag());
		test1.setQuickFailInd(test.isQuickFailInd()?Constant.YES:Constant.NO);
		test1.setQuickPassInd(test.isQuickPassInd()?Constant.YES:Constant.NO);
		
		return test1;
	}

	public gov.ca.dmv.AKT.integration.BeansImpl.Test getDefaultTestAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.Test test1 = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
		test1.setCdlFlag(Constant.NO);
		test1.setDefaultLangFlag(Constant.DEFAULT_LANG);
		test1.setEaseTestId(Constant.SINGLE_SPACE);
		test1.setLastModUsername(Constant.SINGLE_SPACE);
		test1.setLastModUserTime(new Date());
		test1.setMaxIncorrectNum(Constant.ZERO);
		test1.setQuickPassFailInd(Constant.NO);
		test1.setTestQuestionCount(String.valueOf(Constant.ZERO));
		test1.setTestId(Constant.SINGLE_SPACE);
		test1.setTestName(Constant.SINGLE_SPACE);
		test1.setTestStatusCode(Constant.ACTIVE);
		test1.setTestTypeCode(Constant.ORIGINAL);
		test1.setOptionalTestInd(Constant.NO);
		test1.setTestOrigin(Constant.APP_TYPE_FO);
		test1.setTimeLimit(Constant.ZERO);
		test1.setTestOrder(Constant.ONE);
		test1.setSignTestFlag(Constant.NO);
		test1.setRequiredSignTest(Constant.NO);
		test1.setEnglishOnlyFlag(Constant.NO);
		test1.setQuickFailInd(Constant.NO);
		test1.setQuickPassInd(Constant.NO);
		
		return test1;
	}
	
	public void setTestPlanListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList2) {
		List<TestPlan> testPlanList1 = new ArrayList<TestPlan>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.TestPlan testPlan2: testPlanList2)
		{
			TestPlan testPlan = new TestPlan();
			testPlan.setTestId(testPlan2.getTpPrimaryKey().getTestId());
			testPlan.setCategoryId(testPlan2.getTpPrimaryKey().getCategoryId());
			testPlan.setCategoryOrder(testPlan2.getCategoryOrder());
			testPlan.setCategoryQuestionCount(testPlan2.getCategoryQuestionCount());
			testPlan.setGradableFlag(testPlan2.getGradableFlag());
			testPlan.setLastModUsername(testPlan2.getLastModUsername());
			testPlan.setLastModUserTime(testPlan2.getLastModUserTime());
			
			testPlanList1.add(testPlan);
		}
		setTestPlanList(testPlanList1);
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> getTestPlanListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan>();
		for(TestPlan testPlan2: testPlanList) {
			gov.ca.dmv.AKT.integration.BeansImpl.TestPlan testPlan = new gov.ca.dmv.AKT.integration.BeansImpl.TestPlan();
			TPPrimaryKey tpPrimaryKey = new TPPrimaryKey();
			tpPrimaryKey.setTestId(testPlan2.getTestId());
			tpPrimaryKey.setCategoryId(testPlan2.getCategoryId());
			testPlan.setTpPrimaryKey(tpPrimaryKey);
			testPlan.setCategoryOrder(testPlan2.getCategoryOrder());
			testPlan.setCategoryQuestionCount(testPlan2.getCategoryQuestionCount());
			testPlan.setGradableFlag(testPlan2.getStringGradableFlag());
			testPlan.setLastModUsername(testPlan2.getLastModUsername());
			testPlan.setLastModUserTime(testPlan2.getLastModUserTime());
			
			testPlanList2.add(testPlan);
		}
		return testPlanList2;
	}
}
