package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.ReturnMessage;

public class QuesAnswDTO {

	private QuestionLang    questionLang;
	private List<Answer>    answerList;
	private List<Category>  categoryList;
	private HandbookRef     handbookRef;
	private ReturnMessage   returnMessage;
	private Lang            lang;
	private int             errorCode;
	private Integer         questionGenId;
	
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public Lang getLang() {
		return lang;
	}
	public void setLang(Lang lang) {
		this.lang = lang;
	}
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}
	public List<Answer> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public HandbookRef getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(HandbookRef handbookRef) {
		this.handbookRef = handbookRef;
	}
	public ReturnMessage getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(ReturnMessage returnMessage) {
		this.returnMessage = returnMessage;
	}
	public gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang getQuestionLangAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang questionLang1 = new gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang();
		questionLang1.setQuestionGenId(questionLang.getQuestionGenId());
		questionLang1.setHandbookRef(questionLang.getHandbookRef());
		questionLang1.setLangId(questionLang.getLangId());
		questionLang1.setLastModUsername(questionLang.getLastModUsername());
		questionLang1.setLastModUserTime(questionLang.getLastModUserTime());
		questionLang1.setQuestionId(questionLang.getQuestionId());
		questionLang1.setQuestionLangId(questionLang.getQuestionLangId());
		questionLang1.setQuestionLangStatus(Constant.INACTIVE);
		if(questionLang.getQuestionLangStatus().trim().equals(Constant.ACTIVE_PRES) || questionLang.getQuestionLangStatus().trim().equals(Constant.ACTIVE)) {
			questionLang1.setQuestionLangStatus(Constant.ACTIVE);
		}
		questionLang1.setQuestionText(questionLang.getQuestionText());
		questionLang1.setSignImage(questionLang.getSignImage());
		questionLang1.setQuestionAudio(questionLang.getQuestionAudio());
		questionLang1.setQuestionVideo(questionLang.getQuestionVideo());
		if (questionLang.getChangeReviewStatusCode() != null) {
			questionLang1.setChangeReviewStatusCode(questionLang.getChangeReviewStatusCode());
		}
		else {
			questionLang1.setChangeReviewStatusCode(Constant.SINGLE_SPACE);
		}
		return questionLang1;
	}
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> getAnswerListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Answer>();
		for(gov.ca.dmv.AKT.presentation.Beans.Answer answer2: answerList)
		{
			gov.ca.dmv.AKT.integration.BeansImpl.Answer answer = new gov.ca.dmv.AKT.integration.BeansImpl.Answer();
			if (answer2.getAnswerGenId() != null && answer2.getAnswerGenId() > 0 ) {
				answer.setAnswerGenId(answer2.getAnswerGenId());
			}
			answer.setAnswerId(answer2.getAnswerId());
			if(answer2.getAnswerStatus().trim().equalsIgnoreCase(Constant.ACTIVE_PRES))
				answer.setAnswerStatus(Constant.ACTIVE);
			else
				answer.setAnswerStatus(Constant.INACTIVE);
			answer.setAnswerText(answer2.getAnswerText());
			if(answer2.isCorrectAnswerInd())
				answer.setCorrectAnswerInd(Constant.CORRECT);
			else
				answer.setCorrectAnswerInd(Constant.INCORRECT);
			answer.setLastModUsername(answer2.getLastModUsername());
			answer.setLastModUserTime(answer2.getLastModUserTime());
			answer.setQuestionGenId(answer2.getQuestionGenId());
			answer.setSignImage(answer2.getSignImage());
			answer.setAnswerAudio(answer2.getAnswerAudio());
			answer.setAnswerVideo(answer2.getAnswerVideo());
			if (answer2.getChangeReviewStatusCode() != null) {
				answer.setChangeReviewStatusCode(answer2.getChangeReviewStatusCode());
			}
			else {
				answer.setChangeReviewStatusCode(Constant.SINGLE_SPACE);
			}
			answerList2.add(answer);
		}
		return answerList2;
	}
	public void setAnswerListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList1) {
		List<Answer> answerList2 = new ArrayList<Answer>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Answer ans: answerList1)
		{
			Answer ans2 = new Answer();
			ans2.setAnswerId(ans.getAnswerId());
			if(ans.getAnswerStatus().trim().equalsIgnoreCase(Constant.ACTIVE))
				ans2.setAnswerStatus(Constant.ACTIVE_PRES);
			else
				ans2.setAnswerStatus(Constant.INACTIVE_PRES);
			ans2.setAnswerText(ans.getAnswerText());
			ans2.setAnswerGenId(ans.getAnswerGenId());
			if(ans.getCorrectAnswerInd().equalsIgnoreCase(Constant.CORRECT))
				ans2.setCorrectAnswerInd(true);
			else
				ans2.setCorrectAnswerInd(false);
			ans2.setLastModUsername(ans.getLastModUsername());
			ans2.setLastModUserTime(ans.getLastModUserTime());
			ans2.setSignImage(ans.getSignImage());
			ans2.setQuestionGenId(ans.getQuestionGenId());
			ans2.setAnswerAudio(ans.getAnswerAudio());
			ans2.setAnswerVideo(ans.getAnswerVideo());
			ans2.setChangeReviewStatusCode(ans.getChangeReviewStatusCode());
			answerList2.add(ans2);
		}
		setAnswerList(answerList2);
	}
	public void setQuestionLangAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang questionLang2) {
		QuestionLang questionLang = new QuestionLang();
		questionLang.setQuestionGenId(questionLang2.getQuestionGenId());
		questionLang.setHandbookRef(questionLang2.getHandbookRef());
		questionLang.setLangId(questionLang2.getLangId());
		questionLang.setLastModUsername(questionLang2.getLastModUsername());
		questionLang.setLastModUserTime(questionLang2.getLastModUserTime());
		questionLang.setQuestionId(questionLang2.getQuestionId());
		questionLang.setQuestionLangId(questionLang2.getQuestionLangId());
		if(questionLang2.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.ACTIVE))
			questionLang.setQuestionLangStatus(Constant.ACTIVE_PRES);
		else
			questionLang.setQuestionLangStatus(Constant.INACTIVE_PRES);
		questionLang.setQuestionText(questionLang2.getQuestionText());
		questionLang.setSignImage(questionLang2.getSignImage());
		questionLang.setQuestionAudio(questionLang2.getQuestionAudio());
		questionLang.setQuestionVideo(questionLang2.getQuestionVideo());
		questionLang.setChangeReviewStatusCode(questionLang2.getChangeReviewStatusCode());
		setQuestionLang(questionLang);
	}
	public void setHandbookRefAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef handbookRef2) {
		HandbookRef handbookRef = new HandbookRef();
		handbookRef.setHandbookRef(handbookRef2.getHrPrimaryKey().getHandbookRef());
		handbookRef.setLangId(handbookRef2.getHrPrimaryKey().getLangId());
		handbookRef.setHandbookSectionDesc(handbookRef2.getHandbookSectionDesc());
		handbookRef.setHandbookSectionName(handbookRef2.getHandbookSectionName());
		handbookRef.setLastModUsername(handbookRef2.getLastModUsername());
		handbookRef.setLastModUserTime(handbookRef2.getLastModUserTime());
		setHandbookRef(handbookRef);
	}
	public void setLangAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang3) {
		gov.ca.dmv.AKT.presentation.Beans.Lang lang4 = new gov.ca.dmv.AKT.presentation.Beans.Lang();
		lang4.setLangId(lang3.getLangId());
		lang4.setLangName(lang3.getLangName());
		lang4.setLastModUsername(lang3.getLastModUsername());
		lang4.setLastModUserTime(lang3.getLastModUserTime());
		lang4.setProgLangCode(lang3.getProgLangCode());
		setLang(lang4);
	}
}

