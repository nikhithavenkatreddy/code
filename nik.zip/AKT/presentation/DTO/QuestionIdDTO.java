package gov.ca.dmv.AKT.presentation.DTO;

import java.util.List;

public class QuestionIdDTO {

	private List<String> questionIdList;
	private int          errorCode;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<String> getQuestionIdList() {
		return questionIdList;
	}

	public void setQuestionIdList(List<String> questionIdList2) {
		this.questionIdList = questionIdList2;
	}
	
}
