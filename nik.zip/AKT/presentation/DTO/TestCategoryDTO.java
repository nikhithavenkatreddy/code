package gov.ca.dmv.AKT.presentation.DTO;

import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.TestCategory;

public class TestCategoryDTO {

	private List<TestCategory> testCategoryList;

	public List<TestCategory> getTestCategoryList() {
		return testCategoryList;
	}

	public void setTestCategoryList(List<TestCategory> testCategoryList) {
		this.testCategoryList = testCategoryList;
	}
	
}
