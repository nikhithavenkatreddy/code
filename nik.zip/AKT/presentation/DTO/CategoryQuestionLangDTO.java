package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;

public class CategoryQuestionLangDTO {

	private Category           category;
	private List<QuestionLang> questionLangList;
	private int                errorCode;
	private String             langId;
	
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}
	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}
	public void setQuestionLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> questionLangList1) {
		List<QuestionLang> quesList = new ArrayList<QuestionLang>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ql: questionLangList1) {
			QuestionLang ql2 = new QuestionLang();
			ql2.setQuestionGenId(ql.getQuestionGenId());
			ql2.setHandbookRef(ql.getHandbookRef());
			ql2.setLangId(ql.getLangId());
			ql2.setLastModUsername(ql.getLastModUsername());
			ql2.setLastModUserTime(ql.getLastModUserTime());
			ql2.setQuestionId(ql.getQuestionId());
			ql2.setQuestionLangId(ql.getQuestionLangId());
			if(ql.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.ACTIVE))
				ql2.setQuestionLangStatus(Constant.ACTIVE_PRES);
			else
				ql2.setQuestionLangStatus(Constant.INACTIVE_PRES);
			ql2.setQuestionText(ql.getQuestionText());
			ql2.setSignImage(ql.getSignImage());
			ql2.setQuestionAudio(ql.getQuestionAudio());
			ql2.setQuestionVideo(ql.getQuestionVideo());
			ql2.setChangeReviewStatusCode(ql.getChangeReviewStatusCode());
			quesList.add(ql2);
		}
		setQuestionLangList(quesList);
	}
}
