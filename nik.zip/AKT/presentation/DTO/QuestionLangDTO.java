package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.ReturnMessage;

public class QuestionLangDTO {
	
	private List<QuestionLang> questionLangList;
	private List<Category>     categoryList;
	private ReturnMessage      returnMessage;
	private int                errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public ReturnMessage getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(ReturnMessage returnMessage) {
		this.returnMessage = returnMessage;
	}

	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}

	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
	public void setQuestionLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList) {
		List<QuestionLang> quesLangList1 = new ArrayList<QuestionLang>();
		if (quesLangList == null) {
			setQuestionLangList(quesLangList1);
			return;
		}
		for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang2: quesLangList) {
			QuestionLang quesLang = new QuestionLang();
			quesLang.setQuestionGenId(quesLang2.getQuestionGenId());
			quesLang.setHandbookRef(quesLang2.getHandbookRef());
			quesLang.setLangId(quesLang2.getLangId());
			quesLang.setLastModUsername(quesLang2.getLastModUsername());
			quesLang.setLastModUserTime(quesLang2.getLastModUserTime());
			quesLang.setQuestionId(quesLang2.getQuestionId());
			quesLang.setQuestionLangId(quesLang2.getQuestionLangId());
			if(quesLang2.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.ACTIVE))
				quesLang.setQuestionLangStatus(Constant.ACTIVE_PRES);
			else
				quesLang.setQuestionLangStatus(Constant.INACTIVE_PRES);
			quesLang.setQuestionText(quesLang2.getQuestionText());
			quesLang.setSignImage(quesLang2.getSignImage());
			quesLang.setQuestionAudio(quesLang2.getQuestionAudio());
			quesLang.setQuestionVideo(quesLang2.getQuestionVideo());
			quesLang.setChangeReviewStatusCode(quesLang2.getChangeReviewStatusCode());
			quesLangList1.add(quesLang);
		}
		setQuestionLangList(quesLangList1);
	}
}
