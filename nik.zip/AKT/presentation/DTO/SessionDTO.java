package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.presentation.Beans.Session;

public class SessionDTO {

	private Session session;
	private String  dlNumber;
	private Integer resumeExamId;
	private int     errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public Integer getResumeExamId() {
		return resumeExamId;
	}

	public void setResumeExamId(Integer resumeExamId) {
		this.resumeExamId = resumeExamId;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}
	
	public String getDlNumber() {
		return dlNumber;
	}

	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}

	public ISession getSessionAfterBusTierConversion() {
		ISession session1 = new gov.ca.dmv.AKT.integration.BeansImpl.Session();
		session1.setApplicationId(session.getApplicationId());
		session1.setLanguageCode(session.getLanguageCode());
		session1.setLastModUsername(session.getLastModUsername());
		session1.setLastModUserTime(session.getLastModUserTime());
		session1.setOfficeId(session.getOfficeId());
		session1.setSessionEndTime(session.getSessionEndTime());
		session1.setSessionId(session.getSessionId());
		session1.setSessionStartTime(session.getSessionStartTime());
		session1.setVaultId(session.getVaultId());
		session1.setWorkstationIPAddress(session.getWorkstationIPAddress());
		session1.setYobOverrideTime(session.getYobOverrideTime());
		session1.setYobValidationFlag(session.getYobValidationFlag());
		session1.setSessionStatusCode(session.getSessionStatusCode());
		return session1;
	}
	
	public void setSessionAfterPreTierConversion(ISession session) {
		Session session1 = new Session();
		session1.setApplicationId(session.getApplicationId());
		session1.setLanguageCode(session.getLanguageCode());
		session1.setLastModUsername(session.getLastModUsername());
		session1.setLastModUserTime(session.getLastModUserTime());
		session1.setOfficeId(session.getOfficeId());
		session1.setSessionEndTime(session.getSessionEndTime());
		session1.setSessionId(session.getSessionId());
		session1.setSessionStartTime(session.getSessionStartTime());
		session1.setVaultId(session.getVaultId());
		session1.setWorkstationIPAddress(session.getWorkstationIPAddress());
		session1.setYobOverrideTime(session.getYobOverrideTime());
		session1.setYobValidationFlag(session.getYobValidationFlag());
		session1.setSessionStatusCode(session.getSessionStatusCode());
		setSession(session1);
	}
}
