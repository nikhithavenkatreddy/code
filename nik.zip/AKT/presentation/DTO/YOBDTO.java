package gov.ca.dmv.AKT.presentation.DTO;
import gov.ca.dmv.AKT.presentation.Beans.YOB;

public class YOBDTO {
	private YOB           yob;
	private boolean       validationSuccessful;
	private int           errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public YOB getYob() {
		return yob;
	}

	public void setYob(YOB yob) {
		this.yob = yob;
	}
	
	public gov.ca.dmv.AKT.integration.BeansImpl.YOB getYobAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.YOB yob1 = new gov.ca.dmv.AKT.integration.BeansImpl.YOB();
		yob1.setYob(yob.getYob());
		yob1.setVaultId(yob.getVaultId());
		yob1.setDob(yob.getDob());
		yob1.setThreeCharLasstName(yob.getThreeCharLastName());
		return yob1;
	}

	public boolean isValidationSuccessful() {
		return validationSuccessful;
	}

	public void setValidationSuccessful(boolean validationSuccessful) {
		this.validationSuccessful = validationSuccessful;
	}
	
	
}
