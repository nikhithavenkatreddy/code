package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.QPFList;

import java.util.ArrayList;
import java.util.List;

public class QPFListDTO {

	private List<QPFList> qpfCollection;
	private int           errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<QPFList> getQpfCollection() {
		return qpfCollection;
	}

	public void setQpfCollection(List<QPFList> qpfCollection) {
		this.qpfCollection = qpfCollection;
	}
	
	public void setQpfCollectionAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.QPFList> qpfCollection1) {
		List<QPFList> qpfCollection2 = new ArrayList<QPFList>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.QPFList qpfList: qpfCollection1) {
			QPFList qpfList2 = new QPFList();
			qpfList2.setQuickPassFlag(qpfList.getQuickPassFlag());
			qpfList2.setQuickFailFlag(qpfList.getQuickFailFlag());
			qpfList2.setTestName(qpfList.getTestName());
			qpfList2.setTestId(qpfList.getTestId());
			qpfCollection2.add(qpfList2);
		}
		setQpfCollection(qpfCollection2);
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.QPFList> getQpfCollectionAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.QPFList> qpfCollection2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QPFList>();
		for(QPFList qpfList: qpfCollection) {
			gov.ca.dmv.AKT.integration.BeansImpl.QPFList qpfList2 = new gov.ca.dmv.AKT.integration.BeansImpl.QPFList();
			qpfList2.setQuickPassFlag(qpfList.getQuickPassFlag());
			qpfList2.setQuickFailFlag(qpfList.getQuickFailFlag());
			qpfList2.setTestName(qpfList.getTestName());
			qpfList2.setTestId(qpfList.getTestId());
			qpfCollection2.add(qpfList2);
		}
		return qpfCollection2;
	}
}
