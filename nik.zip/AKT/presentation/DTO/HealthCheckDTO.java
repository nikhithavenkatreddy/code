package gov.ca.dmv.AKT.presentation.DTO;

public class HealthCheckDTO {
	
	private String cacheStatus;
	private String dbStatus;
	
	public String getCacheStatus() {
		return cacheStatus;
	}
	public void setCacheStatus(String cacheStatus) {
		this.cacheStatus = cacheStatus;
	}
	public String getDbStatus() {
		return dbStatus;
	}
	public void setDbStatus(String dbStatus) {
		this.dbStatus = dbStatus;
	}
	
}
