package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryDTO {

	private List<Category> categoryList;
	private int            errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public void setCategoryListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Category> categoryList3) {
		List<Category> categoryList2 = new ArrayList<Category>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Category cat: categoryList3) {
			Category category = new Category();
			category.setCategoryDesc(cat.getCategoryDesc());
			category.setCategoryId(cat.getCategoryId());
			category.setCategoryName(cat.getCategoryName());
			category.setLastModUsername(cat.getLastModUsername());
			category.setLastModUserTime(cat.getLastModUserTime());
			categoryList2.add(category);
		}
		setCategoryList(categoryList2);
	}
}
