package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;

public class HandbookRefDTO {

	private List<HandbookRef> handbookRefList;
	private int               errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public List<HandbookRef> getHandbookRefList() {
		return handbookRefList;
	}
	public void setHandbookRefList(List<HandbookRef> handbookRefList) {
		this.handbookRefList = handbookRefList;
	}
	public void setHandbookRefListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef> handbookRefList1) {
		List<HandbookRef> handbookRefList2 = new ArrayList<HandbookRef>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef handbookRef: handbookRefList1) {
			HandbookRef handbookRef2 = new HandbookRef();
			handbookRef2.setHandbookRef(handbookRef.getHrPrimaryKey().getHandbookRef());
			handbookRef2.setHandbookSectionDesc(handbookRef.getHandbookSectionDesc());
			handbookRef2.setHandbookSectionName(handbookRef.getHandbookSectionName());
			handbookRef2.setLangId(handbookRef.getHrPrimaryKey().getLangId());
			handbookRef2.setLastModUsername(handbookRef.getLastModUsername());
			handbookRef2.setLastModUserTime(handbookRef.getLastModUserTime());
			handbookRefList2.add(handbookRef2);
		}
		setHandbookRefList(handbookRefList2);
	}
	
}
