package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.ActiveSession;

import java.util.List;

public class ActiveSessionDTO {

	private List<ActiveSession> activeSessionList;
	private String              officeId;
	private int                 errorCode;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public List<ActiveSession> getActiveSessionList() {
		return activeSessionList;
	}

	public void setActiveSessionList(List<ActiveSession> activeSessionList) {
		this.activeSessionList = activeSessionList;
	}
	
}
