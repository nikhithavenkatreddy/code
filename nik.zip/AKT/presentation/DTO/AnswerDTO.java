package gov.ca.dmv.AKT.presentation.DTO;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.SubmitAnswer;

import java.util.List;

public class AnswerDTO {

	private SubmitAnswer  submitAnswer;
	private int           errorCode;
	private boolean       appTypeES;
	
	private boolean       incorrectAnswer;
	private QuestionLang  questionLang;
	private List<Answer>  answerList;
	private HandbookRef   handbookRef;
	
	public boolean isIncorrectAnswer() {
		return incorrectAnswer;
	}

	public void setIncorrectAnswer(boolean incorrectAnswer) {
		this.incorrectAnswer = incorrectAnswer;
	}

	public QuestionLang getQuestionLang() {
		return questionLang;
	}

	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}

	public List<Answer> getAnswerList() {
		return answerList;
	}

	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}

	public HandbookRef getHandbookRef() {
		return handbookRef;
	}

	public void setHandbookRef(HandbookRef handbookRef) {
		this.handbookRef = handbookRef;
	}

	public boolean isAppTypeES() {
		return appTypeES;
	}

	public void setAppTypeES(boolean appTypeES) {
		this.appTypeES = appTypeES;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public SubmitAnswer getSubmitAnswer() {
		return submitAnswer;
	}

	public void setSubmitAnswer(SubmitAnswer submitAnswer) {
		this.submitAnswer = submitAnswer;
	}
	
	public gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer getSubmitAnswerAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer submitAnswer1 = new gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer();
		submitAnswer1.setAnswerGenId(submitAnswer.getAnswerGenId());
		submitAnswer1.setExamId(submitAnswer.getExamId());
		submitAnswer1.setQuestionGenId(submitAnswer.getQuestionGenId());
		submitAnswer1.setQuestionPresentedOrder(submitAnswer.getQuestionPresentedOrder());
		submitAnswer1.setQuestionPresentedTime(submitAnswer.getQuestionPresentedTime());
		submitAnswer1.setAnswerChoice(submitAnswer.getAnswerChoice());
		return submitAnswer1;
	}
}
