package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.presentation.Beans.TimeLimit;

public class TimeLimitDTO {

	private List<TimeLimit> timeLimitList;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private int 	errorCode;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getLastModUsername() {
		return lastModUsername;
	}

	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}

	public Date getLastModUserTime() {
		return lastModUserTime;
	}

	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}

	public List<TimeLimit> getTimeLimitList() {
		return timeLimitList;
	}

	public void setTimeLimitList(List<TimeLimit> timeLimitList) {
		this.timeLimitList = timeLimitList;
	}

	public void setTimeLimitListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> timeLimitList1){
		List<TimeLimit> tLimitList = new ArrayList<TimeLimit>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit timeLimit1 : timeLimitList1 ){
			TimeLimit tLimit = new TimeLimit();
			tLimit.setTimeLimitId(timeLimit1.getTimeLimitId());
			tLimit.setTimeLimitValue(((double)timeLimit1.getTimeLimitValue())/TimeLimitTypeConstant.SECONDS);
			tLimit.setTimeLimitName(timeLimit1.getTimeLimitName());
			tLimit.setTimeLimitRangeMax(((double)timeLimit1.getTimeLimitRangeMax())/TimeLimitTypeConstant.SECONDS);
			tLimit.setTimeLimitRangeMin(((double)timeLimit1.getTimeLimitRangeMin())/TimeLimitTypeConstant.SECONDS);
			tLimitList.add(tLimit);
		}
		setTimeLimitList(tLimitList);
	}
}
