package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.Beans.EndOfDayReport;
import gov.ca.dmv.AKT.presentation.Beans.Volume;

import java.util.List;

public class ReportDTO {

	private List<Volume>    volumeList;
	private List<Applicant> applicantList;
	private EndOfDayReport  endOfDayReport;
	private String          fromDate;
	private String          toDate;
	private String          officeId;
	private String          group;
	private String 			dl;
	private String 			lastName;
	private int             errorCode;
	
	public String getDl() {
		return dl;
	}

	public void setDl(String dl) {
		this.dl = dl;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public EndOfDayReport getEndOfDayReport() {
		return endOfDayReport;
	}

	public void setEndOfDayReport(EndOfDayReport endOfDayReport) {
		this.endOfDayReport = endOfDayReport;
	}

	public List<Applicant> getApplicantList() {
		return applicantList;
	}

	public void setApplicantList(List<Applicant> applicantList) {
		this.applicantList = applicantList;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public List<Volume> getVolumeList() {
		return volumeList;
	}

	public void setVolumeList(List<Volume> volumeList) {
		this.volumeList = volumeList;
	}
	
}
