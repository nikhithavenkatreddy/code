package gov.ca.dmv.AKT.presentation.DTO;

import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.Applicant;

public class FailedYOBDTO {

	private List<Applicant> applicantList;
	private String          officeId;
	private int             errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public List<Applicant> getApplicantList() {
		return applicantList;
	}

	public void setApplicantList(List<Applicant> applicantList) {
		this.applicantList = applicantList;
	}
	
}
