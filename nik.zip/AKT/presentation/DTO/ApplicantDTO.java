package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.Beans.ExceptionApplicant;
import gov.ca.dmv.AKT.presentation.Beans.Search;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ApplicantDTO {

	private List<Applicant>          applicantList;
	private String                   officeId;
	private int                      errorCode;
	private Date                     fromDate;
	private Date                     toDate;
	private Integer                  sysId;
	private List<ExceptionApplicant> exceptionApplicantList;
	private List<Search>             searchList;
	private String                   group;
	private String                   techId;
	private String 			         applicationType;
	
	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public Integer getSysId() {
		return sysId;
	}

	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}

	public List<ExceptionApplicant> getExceptionApplicantList() {
		return exceptionApplicantList;
	}

	public void setExceptionApplicantList(List<ExceptionApplicant> exceptionApplicantList) {
		this.exceptionApplicantList = exceptionApplicantList;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<Applicant> getApplicantList() {
		return applicantList;
	}

	public void setApplicantList(List<Applicant> applicantList) {
		this.applicantList = applicantList;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public void setSearchList(List<Search> searchList) {
		this.searchList = searchList;
	}

	public List<Search> getSearchList() {
		return searchList;
	}

	public List<gov.ca.dmv.AKT.integration.BeansImpl.Search> getSearchListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Search> searchList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Search>();
		for(Search search: searchList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Search search2 = new gov.ca.dmv.AKT.integration.BeansImpl.Search();
			search2.setDl(search.getDl());
			search2.setLastName(search.getLastName());
			search2.setOfficeId(search.getOfficeId());
			search2.setRequestType(search.getRequestType());
			search2.setGroup(search.getGroup());
			searchList2.add(search2);
		}
		return searchList2;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	
}
