package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.Question;
import gov.ca.dmv.AKT.presentation.Beans.Test;

public class QuestionDTO {

	private Question       question;
	private List<Category> categoryList;
	private List<Test>     testList;
	private int            errorCode;
	
	public List<Test> getTestList() {
		return testList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public gov.ca.dmv.AKT.integration.BeansImpl.Question getQuestionAfterBusTierConversion() {
		gov.ca.dmv.AKT.integration.BeansImpl.Question quest = new gov.ca.dmv.AKT.integration.BeansImpl.Question();
		quest.setLastModUsername(question.getLastModUsername());
		quest.setLastModUserTime(question.getLastModUserTime());
		quest.setQuestionId(question.getQuestionId());
		quest.setQuestionStatus(Constant.INACTIVE);
		if(question.getQuestionStatus() != null && question.getQuestionStatus().trim().equalsIgnoreCase(Constant.ACTIVE_PRES))
			quest.setQuestionStatus(Constant.ACTIVE);
		quest.setChangeReviewStatusCode(question.getChangeReviewStatusCode());
		return quest;
	}
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Category> getCategoryListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Category> categoryList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Category>();
		for(Category category: categoryList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Category cat = new gov.ca.dmv.AKT.integration.BeansImpl.Category();
			cat.setCategoryDesc(category.getCategoryDesc());
			cat.setCategoryId(category.getCategoryId());
			cat.setCategoryName(category.getCategoryName());
			cat.setLastModUsername(category.getLastModUsername());
			cat.setLastModUserTime(category.getLastModUserTime());
			categoryList2.add(cat);
		}
		return categoryList2;
	}
	public void setCategoryListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Category> categoryList1) {
		List<Category> categoryList2 = new ArrayList<Category>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Category category: categoryList1) {
			Category category2 = new Category();
			category2.setCategoryDesc(category.getCategoryDesc());
			category2.setCategoryId(category.getCategoryId());
			category2.setCategoryName(category.getCategoryName());
			category2.setLastModUsername(category.getLastModUsername());
			category2.setLastModUserTime(category.getLastModUserTime());
			categoryList2.add(category2);
		}
		setCategoryList(categoryList2);
	}
	public void setQuestionAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.Question question1) {
		Question question2 = new Question();
		question2.setLastModUsername(question1.getLastModUsername());
		question2.setLastModUserTime(question1.getLastModUserTime());
		question2.setQuestionId(question1.getQuestionId());
		question2.setQuestionStatus(Constant.INACTIVE_PRES);
		if(question1.getQuestionStatus().trim().equals(Constant.ACTIVE))
			question2.setQuestionStatus(Constant.ACTIVE_PRES);
		question2.setChangeReviewStatusCode(question1.getChangeReviewStatusCode());
		setQuestion(question2);
	}
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Test> getTestListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList1 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Test>();
		for(Test test: testList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Test test1 = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
			test1.setCdlFlag(Constant.NO);
			if(test.isCdlFlag()) {
				test1.setCdlFlag(Constant.YES);
			}
			test1.setDefaultLangFlag(test.getDefaultLangFlag());
			test1.setEaseTestId(test.getEaseTestId());
			test1.setLastModUsername(test.getLastModUsername());
			test1.setLastModUserTime(test.getLastModUserTime());
			test1.setMaxIncorrectNum(test.getMaxIncorrectNum());
			test1.setQuickPassFailInd(Constant.NO);
			if(test.isQuickPassFailInd()) {
				test1.setQuickPassFailInd(Constant.YES);
			}
			test1.setTestId(test.getTestId());
			test1.setTestName(test.getTestName());
			test1.setTestQuestionCount(test.getTestQuestionCount());
			test1.setTestStatusCode(Constant.INACTIVE);
			if(test.getTestStatusCode() != null && 
			   (test.getTestStatusCode().equals(Constant.ACTIVE_PRES) || test.getTestStatusCode().equals(Constant.ACTIVE)))
				test1.setTestStatusCode(Constant.ACTIVE);
			test1.setTestTypeCode(test.getTestTypeCode());
			test1.setOptionalTestInd(test.getOptionalTestInd());
			test1.setTestOrder(test.getTestOrder());
			test1.setSignTestFlag(test.getSignTestFlag());
			test1.setQuickFailInd(test.isQuickFailInd()?Constant.YES:Constant.NO);
			test1.setQuickPassInd(test.isQuickPassInd()?Constant.YES:Constant.NO);
			testList1.add(test1);
		}
		return testList1;
	}
	public void setTestListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList1) {
		List<Test> testList2 = new ArrayList<Test>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Test test: testList1) {
			Test test1 = new Test();
			test1.setCdlFlag(test.getCdlFlag().trim().equals(Constant.YES));
			test1.setDefaultLangFlag(test.getDefaultLangFlag());
			test1.setEaseTestId(test.getEaseTestId());
			test1.setLastModUsername(test.getLastModUsername());
			test1.setLastModUserTime(test.getLastModUserTime());
			test1.setMaxIncorrectNum(test.getMaxIncorrectNum());
			test1.setQuickPassFailInd(test.getQuickPassFailInd().trim().equals(Constant.YES));
			test1.setTestId(test.getTestId());
			test1.setTestName(test.getTestName());
			test1.setTestQuestionCount(test.getTestQuestionCount());
			test1.setTestStatusCode(Constant.INACTIVE_PRES);
			if(test.getTestStatusCode().trim().equals(Constant.ACTIVE))
				test1.setTestStatusCode(Constant.ACTIVE_PRES);
			test1.setTestTypeCode(test.getTestTypeCode());
			test1.setOptionalTestInd(test.getOptionalTestInd());
			test1.setTestOrder(test.getTestOrder());
			test1.setSignTestFlag(test.getSignTestFlag());
			if (test.getQuickFailInd().equals(Constant.YES)) {
				test1.setQuickFailInd(true);
			} 
			else {
				test1.setQuickFailInd(false);
			}
			
			if (test.getQuickPassInd().equals(Constant.YES)) {
				test1.setQuickPassInd(true);
			} 
			else {
				test1.setQuickPassInd(false);
			}
			test1.setQuickFailInd(test.getQuickFailInd().equals(Constant.YES)?true:false);
			test1.setQuickPassInd(test.getQuickPassInd().equals(Constant.YES)?true:false);
			testList2.add(test1);
		}
		setTestList(testList2);
	}
}
