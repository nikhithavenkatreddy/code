package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.Lang;

public class LangDTO {
	
	private List<Lang> langList;
	private int        errorCode;
	private int        setNo;
	private Lang       english;
	private Lang       spanish;
	
	public Lang getEnglish() {
		return english;
	}

	public void setEnglish(Lang english) {
		this.english = english;
	}

	public Lang getSpanish() {
		return spanish;
	}

	public void setSpanish(Lang spanish) {
		this.spanish = spanish;
	}

	public int getSetNo() {
		return setNo;
	}

	public void setSetNo(int setNo) {
		this.setNo = setNo;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<Lang> getLangList() {
		return langList;
	}

	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	
	public void setLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList3) {
		List<Lang> langList2 = new ArrayList<Lang>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang: langList3) {
			Lang lang2 = new Lang();
			lang2.setLangId(lang.getLangId());
			lang2.setLangName(lang.getLangName());
			lang2.setLastModUsername(lang.getLastModUsername());
			lang2.setLastModUserTime(lang.getLastModUserTime());
			lang2.setProgLangCode(lang.getProgLangCode());
			lang2.setNativeLangName(lang.getNativeLangName());
			langList2.add(lang2);
		}
		setLangList(langList2);
	}
	
	public void setEnglishAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.Lang english) {
		Lang eng = new Lang();
		eng.setLangId(english.getLangId());
		eng.setLangName(english.getLangName());
		eng.setLastModUsername(english.getLastModUsername());
		eng.setLastModUserTime(english.getLastModUserTime());
		eng.setProgLangCode(english.getProgLangCode());
		eng.setNativeLangName(english.getNativeLangName());
		setEnglish(eng);
	}
	
	public void setSpanishAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.Lang spanish) {
		Lang spa = new Lang();
		spa.setLangId(spanish.getLangId());
		spa.setLangName(spanish.getLangName());
		spa.setLastModUsername(spanish.getLastModUsername());
		spa.setLastModUserTime(spanish.getLastModUserTime());
		spa.setProgLangCode(spanish.getProgLangCode());
		spa.setNativeLangName(spanish.getNativeLangName());
		setSpanish(spa);
	}
}
