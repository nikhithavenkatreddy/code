package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.WorkstationMap;

import java.util.ArrayList;
import java.util.List;

public class WorkstationMapDTO {

	private List<WorkstationMap> workstationMapList;
	private List<String>		 officeIDList;
	private boolean              reserved;
	private int                  errorCode;

	public boolean isReserved() {
		return reserved;
	}

	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<WorkstationMap> getWorkstationMapList() {
		return workstationMapList;
	}

	public void setWorkstationMapList(List<WorkstationMap> workstationMapList) {
		this.workstationMapList = workstationMapList;
	}
	
	public void setWorkstationMapListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap> wmList) {
		List<WorkstationMap> wmList2 = new ArrayList<WorkstationMap>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap wm: wmList) {
			WorkstationMap wm2 = new WorkstationMap();
			wm2.setLastModUsername(wm.getLastModUsername());
			wm2.setLastModUserTime(wm.getLastModUserTime());
			wm2.setOfficeId(wm.getOfficeId());
			wm2.setWorkstationId(wm.getWorkstationId());
			wm2.setWorkstationIPAddress(wm.getWorkstationIPAddress());
			wmList2.add(wm2);
		}
		setWorkstationMapList(wmList2);
	}
	
	public WorkstationMap getWorkstationMapAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap wm) {		
		WorkstationMap wm2 = new WorkstationMap();
		wm2.setLastModUsername(wm.getLastModUsername());
		wm2.setLastModUserTime(wm.getLastModUserTime());
		wm2.setOfficeId(wm.getOfficeId());
		wm2.setWorkstationId(wm.getWorkstationId());
		if(wm.getLocatingOfficeId()!=null && wm.getLocatingOfficeId().trim().length() > 0){
			wm2.setWorkstationId(wm.getLocatingOfficeId().trim() + "-" + wm.getWorkstationId());
		}
		wm2.setWorkstationIPAddress(wm.getWorkstationIPAddress());
		
		return wm2;
	}

	public List<String> getOfficeIDList() {
		return officeIDList;
	}

	public void setOfficeIDList(List<String> officeIDList) {
		this.officeIDList = officeIDList;
	}

	
}
