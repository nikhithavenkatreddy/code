package gov.ca.dmv.AKT.presentation.DTO;

import gov.ca.dmv.AKT.presentation.Beans.Search;

import java.util.ArrayList;
import java.util.List;

public class SearchDTO {

	private List<Search> searchList;
	private int          errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<Search> getSearchList() {
		return searchList;
	}

	public void setSearchList(List<Search> searchList) {
		this.searchList = searchList;
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Search> getSearchListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Search> searchList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Search>();
		for(Search search: searchList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Search search2 = new gov.ca.dmv.AKT.integration.BeansImpl.Search();
			search2.setDl(search.getDl());
			search2.setLastName(search.getLastName());
			search2.setRequestType(search.getRequestType());
			search2.setOfficeId(search.getOfficeId());
			searchList2.add(search2);
		}
		return searchList2;
	}
}
