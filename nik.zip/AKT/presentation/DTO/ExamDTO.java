package gov.ca.dmv.AKT.presentation.DTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.Exam;
import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.QuesAnsw;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.Session;
import gov.ca.dmv.AKT.presentation.Beans.Test;
import gov.ca.dmv.AKT.presentation.Beans.TestLang;
import gov.ca.dmv.AKT.presentation.Beans.Vault;

public class ExamDTO {

	private List<Exam>         examList;
	private String             langIdCode;
	private List<TestLang>     testLangList;
	private Session            session;
	private List<Test>         testList;
	private Vault              vault;
	private String             workstationId;
	private List<ExamTestLang> examTestLangList;
	private int                questionPresentedOrder;
	private QuesAnsw           quesAnsw;
	private String             result;
	private int                errorCode;
	private List<QuesAnsw>     quesAnswList;
	private String             testName;
	private int                maxIncorrect;
	private boolean            pausedAllowed;
	private boolean            quitAllowed;
	private boolean            progressBarAllowed;
	private boolean            provisional;
	private Integer            signExamId;
	private boolean            airbrakes;
	private boolean            signExam;
	private Integer            reqSignExamId;
	private String             officeId;
	private List<Lang>         langList;
	private boolean            print;
	private String             progLangCode;
	private String             printStatus;
	private String             techId;
	private String             testId;
	private String             userId;
	private String 			   applicationType;
	private boolean            audioAllowed;
	private boolean            videoAllowed;
	private boolean            handbookRefAllowed;
	private boolean            timedTest;
	private long               timeLeftFor15MinRemainder = -1;
	private long               timeDurationFor15MinRemainder = 0;
	private long               timeLeftForGradingTest = -1;
	private long               timeToReviewMissedQuestions= 0;
	private boolean            timedTestTimedOut = false;
	private boolean            skipped;
	private boolean            skippedThreeTimes;
	private int				   answeredQuestions;
	private int				   totalQuestions;
	private String             forceFailAction;          
	private Date			   questionPresentedTime;
	
	public boolean isHandbookRefAllowed() {
		return handbookRefAllowed;
	}

	public void setHandbookRefAllowed(boolean handbookRefAllowed) {
		this.handbookRefAllowed = handbookRefAllowed;
	}

	public boolean isProvisional() {
		return provisional;
	}

	public void setProvisional(boolean provisional) {
		this.provisional = provisional;
	}

	public long getTimeToReviewMissedQuestions() {
		return timeToReviewMissedQuestions;
	}

	public void setTimeToReviewMissedQuestions(long timeToReviewMissedQuestions) {
		this.timeToReviewMissedQuestions = timeToReviewMissedQuestions;
	}

	public long getTimeDurationFor15MinRemainder() {
		return timeDurationFor15MinRemainder;
	}

	public void setTimeDurationFor15MinRemainder(long timeDurationFor15MinRemainder) {
		this.timeDurationFor15MinRemainder = timeDurationFor15MinRemainder;
	}

	public Date getQuestionPresentedTime() {
		return questionPresentedTime;
	}

	public void setQuestionPresentedTime(Date questionPresentedTime) {
		this.questionPresentedTime = questionPresentedTime;
	}

	public boolean isProgressBarAllowed() {
		return progressBarAllowed;
	}

	public void setProgressBarAllowed(boolean progressBarAllowed) {
		this.progressBarAllowed = progressBarAllowed;
	}

	public boolean isQuitAllowed() {
		return quitAllowed;
	}

	public void setQuitAllowed(boolean quitAllowed) {
		this.quitAllowed = quitAllowed;
	}

	public boolean isTimedTest() {
		return timedTest;
	}

	public void setTimedTest(boolean timedTest) {
		this.timedTest = timedTest;
	}

	public int getAnsweredQuestions() {
		return answeredQuestions;
	}

	public void setAnsweredQuestions(int answeredQuestions) {
		this.answeredQuestions = answeredQuestions;
	}

	public int getTotalQuestions() {
		return totalQuestions;
	}

	public void setTotalQuestions(int totalQuestions) {
		this.totalQuestions = totalQuestions;
	}

	public boolean isSkipped() {
		return skipped;
	}

	public void setSkipped(boolean skipped) {
		this.skipped = skipped;
	}

	public boolean isSkippedThreeTimes() {
		return skippedThreeTimes;
	}

	public void setSkippedThreeTimes(boolean skippedThreeTimes) {
		this.skippedThreeTimes = skippedThreeTimes;
	}

	public String getForceFailAction() {
		return forceFailAction;
	}

	public void setForceFailAction(String forceFailAction) {
		this.forceFailAction = forceFailAction;
	}

	public boolean isTimedTestTimedOut() {
		return timedTestTimedOut;
	}

	public void setTimedTestTimedOut(boolean timedTestTimedOut) {
		this.timedTestTimedOut = timedTestTimedOut;
	}

	public long getTimeLeftForReminder() {
		return timeLeftFor15MinRemainder;
	}

	public void setTimeLeftForReminder(long timeLeftFor15MinRemainder) {
		this.timeLeftFor15MinRemainder = timeLeftFor15MinRemainder;
	}

	public long getTimeLeftForGradingTest() {
		return timeLeftForGradingTest;
	}

	public void setTimeLeftForGradingTest(long timeLeftForGradingTest) {
		this.timeLeftForGradingTest = timeLeftForGradingTest;
	}



	public boolean isAudioAllowed() {
		return audioAllowed;
	}

	public void setAudioAllowed(boolean audioAllowed) {
		this.audioAllowed = audioAllowed;
	}

	public boolean isVideoAllowed() {
		return videoAllowed;
	}

	public void setVideoAllowed(boolean videoAllowed) {
		this.videoAllowed = videoAllowed;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTestId() {
		return testId;
	}

	public void setTestId(String testId) {
		this.testId = testId;
	}

	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}

	public String getPrintStatus() {
		return printStatus;
	}

	public void setPrintStatus(String printStatus) {
		this.printStatus = printStatus;
	}

	public String getProgLangCode() {
		return progLangCode;
	}

	public void setProgLangCode(String progLangCode) {
		this.progLangCode = progLangCode;
	}

	public boolean isPrint() {
		return print;
	}

	public void setPrint(boolean print) {
		this.print = print;
	}

	public List<Lang> getLangList() {
		return langList;
	}

	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public Integer getReqSignExamId() {
		return reqSignExamId;
	}

	public void setReqSignExamId(Integer reqSignExamId) {
		this.reqSignExamId = reqSignExamId;
	}

	public boolean isSignExam() {
		return signExam;
	}

	public void setSignExam(boolean signExam) {
		this.signExam = signExam;
	}

	public boolean isAirbrakes() {
		return airbrakes;
	}

	public void setAirbrakes(boolean airbrakes) {
		this.airbrakes = airbrakes;
	}

	public Integer getSignExamId() {
		return signExamId;
	}

	public void setSignExamId(Integer signExamId) {
		this.signExamId = signExamId;
	}

	public boolean isPausedAllowed() {
		return pausedAllowed;
	}

	public void setPausedAllowed(boolean pausedAllowed) {
		this.pausedAllowed = pausedAllowed;
	}

	public int getMaxIncorrect() {
		return maxIncorrect;
	}

	public void setMaxIncorrect(int maxIncorrect) {
		this.maxIncorrect = maxIncorrect;
	}

	public String getTestName() {
		return testName;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public List<QuesAnsw> getQuesAnswList() {
		return quesAnswList;
	}

	public void setQuesAnswList(List<QuesAnsw> quesAnswList) {
		this.quesAnswList = quesAnswList;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public QuesAnsw getQuesAnsw() {
		return quesAnsw;
	}

	public void setQuesAnsw(QuesAnsw quesAnsw) {
		this.quesAnsw = quesAnsw;
	}

	public int getQuestionPresentedOrder() {
		return questionPresentedOrder;
	}

	public void setQuestionPresentedOrder(int questionPresentedOrder) {
		this.questionPresentedOrder = questionPresentedOrder;
	}

	public List<ExamTestLang> getExamTestLangList() {
		return examTestLangList;
	}

	public void setExamTestLangList(List<ExamTestLang> examTestLangList) {
		this.examTestLangList = examTestLangList;
	}

	public String getWorkstationId() {
		return workstationId;
	}

	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}

	public Vault getVault() {
		return vault;
	}

	public void setVault(Vault vault) {
		this.vault = vault;
	}

	public List<Test> getTestList() {
		return testList;
	}

	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public List<TestLang> getTestLangList() {
		return testLangList;
	}

	public void setTestLangList(List<TestLang> testLangList) {
		this.testLangList = testLangList;
	}

	public String getLangIdCode() {
		return langIdCode;
	}

	public void setLangIdCode(String langIdCode) {
		this.langIdCode = langIdCode;
	}

	public List<Exam> getExamList() {
		return examList;
	}

	public void setExamList(List<Exam> examList) {
		this.examList = examList;
	}
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Exam> getExamListAfterBusTierConversion() {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Exam> examList1 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Exam>();
		for(Exam exam: examList) {
			gov.ca.dmv.AKT.integration.BeansImpl.Exam exam2 = new gov.ca.dmv.AKT.integration.BeansImpl.Exam();
			exam2.setApplicationId(exam.getApplicationId());
			exam2.setCdlFlag(exam.getCdlFlag());
			exam2.setCompletionReasonCode(exam.getCompletionReasonCode());
			exam2.setCorrectQuestionCount(exam.getCorrectQuestionCount());
			exam2.setEaseTestId(exam.getEaseTestId());
			exam2.setEaseTimestamp(exam.getEaseTimestamp());
			exam2.setExamEndTime(exam.getExamEndTime());
			exam2.setExamId(exam.getExamId());
			exam2.setExamOrder(exam.getExamOrder());
			exam2.setExamQuestionNumber(exam.getExamQuestionNumber());
			exam2.setExamStartTime(exam.getExamStartTime());
			exam2.setIncorrectAnswerCount(exam.getIncorrectAnswerCount());
			exam2.setLastModUsername(exam.getLastModUsername());
			exam2.setLastModUserTime(exam.getLastModUserTime());
			exam2.setMaxIncorrectNumber(exam.getMaxIncorrectNumber());
			exam2.setOfficeId(exam.getOfficeId());
			exam2.setPassFailIndicator(exam.getPassFailIndicator());
			exam2.setQuestionAnsweredCount(exam.getQuestionAnsweredCount());
			exam2.setSessionId(exam.getSessionId());
			exam2.setTestId(exam.getTestId());
			exam2.setQuickPassFailFlag(exam.getQuickPassFailFlag());
			exam2.setTestTypeCode(exam.getTestTypeCode());
			exam2.setLangId(exam.getLangId());
			exam2.setOptionalTestInd(exam.getOptionalTestInd());
			exam2.setSignTestFlag(exam.getSignTestFlag());
			exam2.setSecondaryVerificationId(exam.getSecondaryVerificationId());
			examList1.add(exam2);
		}
		return examList1;
	}
	
	public void setExamListAfterPreTierConversion(List<IExam> examList1) {
		List<Exam> examList2 = new ArrayList<Exam>();
		for(IExam exam: examList1) {
			Exam exam2 = new Exam();
			exam2.setApplicationId(exam.getApplicationId());
			exam2.setCdlFlag(exam.getCdlFlag());
			exam2.setCompletionReasonCode(exam.getCompletionReasonCode());
			exam2.setCorrectQuestionCount(exam.getCorrectQuestionCount());
			exam2.setEaseTestId(exam.getEaseTestId());
			exam2.setEaseTimestamp(exam.getEaseTimestamp());
			exam2.setExamEndTime(exam.getExamEndTime());
			exam2.setExamId(exam.getExamId());
			exam2.setExamOrder(exam.getExamOrder());
			exam2.setExamQuestionNumber(exam.getExamQuestionNumber());
			exam2.setExamStartTime(exam.getExamStartTime());
			exam2.setIncorrectAnswerCount(exam.getIncorrectAnswerCount());
			exam2.setLastModUsername(exam.getLastModUsername());
			exam2.setLastModUserTime(exam.getLastModUserTime());
			exam2.setMaxIncorrectNumber(exam.getMaxIncorrectNumber());
			exam2.setOfficeId(exam.getOfficeId());
			exam2.setPassFailIndicator(exam.getPassFailIndicator());
			exam2.setQuestionAnsweredCount(exam.getQuestionAnsweredCount());
			exam2.setSessionId(exam.getSessionId());
			exam2.setTestId(exam.getTestId());
			exam2.setQuickPassFailFlag(exam.getQuickPassFailFlag());
			exam2.setTestTypeCode(exam.getTestTypeCode());
			exam2.setLangId(exam.getLangId());
			exam2.setOptionalTestInd(exam.getOptionalTestInd());
			exam2.setSignTestFlag(exam.getSignTestFlag());
			exam2.setSecondaryVerificationId(exam.getSecondaryVerificationId());
			examList2.add(exam2);
		}
		setExamList(examList2);
	}
	
	public void setTestLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.TestLang> testLangList1) {
		List<TestLang> testLangList2 = new ArrayList<TestLang>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang1: testLangList1) {
			TestLang testLang = new TestLang();
			testLang.setLangId(testLang1.getLangId());
			testLang.setLastModUsername(testLang1.getLastModUsername());
			testLang.setLastModUserTime(testLang1.getLastModUserTime());
			testLang.setTestId(testLang1.getTlPrimaryKey().getTestId());
			testLang.setTestLangId(testLang1.getTlPrimaryKey().getTestLangId());
			testLang.setTestLangName(testLang1.getTestLangName());
			testLang.setTestLangStatus(testLang1.getTestLangStatus());
			testLangList2.add(testLang);
		}
		setTestLangList(testLangList2);
	}
	
	public void setTestListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList1) {
		List<Test> testList2 = new ArrayList<Test>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Test test1: testList1) {
			Test test2 = new Test();
			test2.setCdlFlag(test1.getCdlFlag().trim().equalsIgnoreCase(Constant.YES));
			test2.setDefaultLangFlag(test1.getDefaultLangFlag());
			test2.setEaseTestId(test1.getEaseTestId());
			test2.setLastModUsername(test1.getLastModUsername());
			test2.setLastModUserTime(test1.getLastModUserTime());
			test2.setMaxIncorrectNum(test1.getMaxIncorrectNum());
			test2.setQuickPassFailInd(test1.getQuickPassFailInd().trim().equalsIgnoreCase(Constant.YES));
			test2.setTestQuestionCount(test1.getTestQuestionCount());
			test2.setTestId(test1.getTestId());
			test2.setTestName(test1.getTestName());
			test2.setTestStatusCode(test1.getTestStatusCode());
			test2.setTestTypeCode(test1.getTestTypeCode());
			test2.setOptionalTestInd(test1.getOptionalTestInd());
			test2.setTestOrder(test1.getTestOrder());
			test2.setSignTestFlag(test1.getSignTestFlag());
			test2.setRequiredSignTest(test1.getRequiredSignTest());
			if (test1.getQuickFailInd().equals(Constant.YES)) {
				test2.setQuickFailInd(true);
			} 
			else {
				test2.setQuickFailInd(false);
			}
			
			if (test1.getQuickPassInd().equals(Constant.YES)) {
				test2.setQuickPassInd(true);
			} 
			else {
				test2.setQuickPassInd(false);
			}
			testList2.add(test2);
		}
		setTestList(testList2);
	}
	
	public void setVaultAfterPreTierConversion(IVault vault1) {
		Vault vault2 = new Vault();
		vault2.setApplicationFirstName(vault1.getApplicationFirstName());
		vault2.setApplicationLastName(vault1.getApplicationLastName());
		vault2.setBirthDate(vault1.getBirthDate());
		vault2.setDlNumber(vault1.getDlNumber());
		vault2.setLastModUsername(vault1.getLastModUsername());
		vault2.setLastModUserTime(vault1.getLastModUserTime());
		vault2.setVaultId(vault1.getVaultId());
		vault2.setVaultTimestamp(vault1.getVaultTimestamp());
		setVault(vault2);
	}
	
	public void setQuesAnswAfterPreTierConversion(gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw quesAnsw1) {
		QuesAnsw quesAnsw = new QuesAnsw();
		List<Answer> answerList2 = new ArrayList<Answer>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Answer ans: quesAnsw1.getAnswerList())
		{
			Answer ans2 = new Answer();
			ans2.setAnswerId(ans.getAnswerId());
			ans2.setAnswerStatus(ans.getAnswerStatus());
			ans2.setAnswerText(ans.getAnswerText());
			ans2.setAnswerGenId(ans.getAnswerGenId());
			ans2.setCorrectAnswerInd(false);
			if(ans.getCorrectAnswerInd().trim().equalsIgnoreCase(Constant.CORRECT))
				ans2.setCorrectAnswerInd(true);
			ans2.setLastModUsername(ans.getLastModUsername());
			ans2.setLastModUserTime(ans.getLastModUserTime());
			ans2.setSignImage(ans.getSignImage());
			ans2.setQuestionGenId(ans.getQuestionGenId());
			ans2.setAnswerAudio(ans.getAnswerAudio());
			ans2.setAnswerVideo(ans.getAnswerVideo());
			ans2.setChangeReviewStatusCode(ans.getChangeReviewStatusCode());
			String langId = ans2.getAnswerId().substring((ans2.getAnswerId().length()-2), ans2.getAnswerId().length());
			if ( !( langId.equals(Constant.LANG_ENGLISH) || langId.equals(Constant.LANG_SPANISH) ) ) {
				int len = ans2.getLengthofAnswerText()/7;
				ans2.setLengthofAnswerText(len);
			}
			answerList2.add(ans2);
		}
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang2 = quesAnsw1.getQuestionLang();
		QuestionLang quesLang = new QuestionLang();
		quesLang.setQuestionGenId(quesLang2.getQuestionGenId());
		quesLang.setHandbookRef(quesLang2.getHandbookRef());
		quesLang.setLangId(quesLang2.getLangId());
		quesLang.setLastModUsername(quesLang2.getLastModUsername());
		quesLang.setLastModUserTime(quesLang2.getLastModUserTime());
		quesLang.setQuestionId(quesLang2.getQuestionId());
		quesLang.setQuestionLangId(quesLang2.getQuestionLangId());
		quesLang.setQuestionLangStatus(quesLang2.getQuestionLangStatus());
		quesLang.setQuestionText(quesLang2.getQuestionText());
		quesLang.setSignImage(quesLang2.getSignImage());
		quesLang.setQuestionAudio(quesLang2.getQuestionAudio());
		quesLang.setQuestionVideo(quesLang2.getQuestionVideo());
		quesLang.setChangeReviewStatusCode(quesLang2.getChangeReviewStatusCode());
	
		quesAnsw.setAnswerList(answerList2);
		quesAnsw.setQuestionLang(quesLang);
		setQuesAnsw(quesAnsw);
	}

	public void setQuesAnswListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw> quesAnswList1) {
		List<QuesAnsw> quesAnswList = new ArrayList<QuesAnsw>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw quesAnsw1: quesAnswList1) {
			QuesAnsw quesAnsw = new QuesAnsw();
			quesAnsw.setQueNotAnswered(quesAnsw1.isQueNotAnswered()); //added this line
			HandbookRef hb = new HandbookRef();
			gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef hb2 = quesAnsw1.getHandbookRef();
			if(hb2 != null) {
				hb.setHandbookRef(hb2.getHrPrimaryKey().getHandbookRef());
				hb.setHandbookSectionDesc(hb2.getHandbookSectionDesc());
				hb.setHandbookSectionName(hb2.getHandbookSectionName());
				hb.setLangId(hb2.getHrPrimaryKey().getLangId());
				hb.setLastModUsername(hb2.getLastModUsername());
				hb.setLastModUserTime(hb2.getLastModUserTime());
			}
			quesAnsw.setHandbookRef(hb);
			quesAnsw.setApplicantAnswId(quesAnsw1.getApplicantAnswId());
			List<Answer> answerList2 = new ArrayList<Answer>();
			for(gov.ca.dmv.AKT.integration.BeansImpl.Answer ans: quesAnsw1.getAnswerList())
			{
				Answer ans2 = new Answer();
				ans2.setAnswerId(ans.getAnswerId());
				ans2.setAnswerStatus(ans.getAnswerStatus());
				ans2.setAnswerText(ans.getAnswerText());
				ans2.setAnswerGenId(ans.getAnswerGenId());
				ans2.setCorrectAnswerInd(false);
				if(ans.getCorrectAnswerInd().trim().equalsIgnoreCase(Constant.CORRECT)) {
					ans2.setCorrectAnswerInd(true);
				}
				ans2.setLastModUsername(ans.getLastModUsername());
				ans2.setLastModUserTime(ans.getLastModUserTime());
				ans2.setSignImage(ans.getSignImage());
				ans2.setAnswerAudio(ans.getAnswerAudio());
				ans2.setAnswerVideo(ans.getAnswerVideo());
				ans2.setChangeReviewStatusCode(ans.getChangeReviewStatusCode());
				answerList2.add(ans2);
			}
			gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang2 = quesAnsw1.getQuestionLang();
			QuestionLang quesLang = new QuestionLang();
			quesLang.setQuestionGenId(quesLang2.getQuestionGenId());
			quesLang.setHandbookRef(quesLang2.getHandbookRef());
			quesLang.setLangId(quesLang2.getLangId());
			quesLang.setLastModUsername(quesLang2.getLastModUsername());
			quesLang.setLastModUserTime(quesLang2.getLastModUserTime());
			quesLang.setQuestionId(quesLang2.getQuestionId());
			quesLang.setQuestionLangId(quesLang2.getQuestionLangId());
			quesLang.setQuestionLangStatus(quesLang2.getQuestionLangStatus());
			quesLang.setQuestionText(quesLang2.getQuestionText());
			quesLang.setSignImage(quesLang2.getSignImage());
			quesLang.setQuestionAudio(quesLang2.getQuestionAudio());
			quesLang.setQuestionVideo(quesLang2.getQuestionVideo());
			quesLang.setChangeReviewStatusCode(quesLang2.getChangeReviewStatusCode());

			quesAnsw.setAnswerList(answerList2);
			quesAnsw.setQuestionLang(quesLang);
			quesAnswList.add(quesAnsw);
		}
		setQuesAnswList(quesAnswList);
	}
	
	public void setLangListAfterPreTierConversion(List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList3) {
		List<Lang> langList2 = new ArrayList<Lang>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang: langList3) {
			Lang lang2 = new Lang();
			lang2.setLangId(lang.getLangId());
			lang2.setLangName(lang.getLangName());
			lang2.setLastModUsername(lang.getLastModUsername());
			lang2.setLastModUserTime(lang.getLastModUserTime());
			lang2.setProgLangCode(lang.getProgLangCode());
			langList2.add(lang2);
		}
		setLangList(langList2);
	}
}
