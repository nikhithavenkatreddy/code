package gov.ca.dmv.AKT.presentation.Filter;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSReceiver;
import gov.ca.dmv.AKT.security.bean.DMVStaff;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
public class AuthorizationFilter implements Filter {
	private static final Logger logger = Logger.getLogger(AuthorizationFilter.class);
    /**
     * Default constructor. 
     */
    public AuthorizationFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req1 = (HttpServletRequest) request;
		HttpSession session = req1.getSession();
		IDMVStaff staff = new DMVStaff();
		
		String userId = req1.getHeader(Constant.USER_ID);
		if(userId != null)
			userId.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe user id: " + userId);
		}
		staff.setUserId(cleanse(userId));
		
		String ip = req1.getHeader(Constant.REMOTE_IP);
		if(ip != null)
			ip.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe ip: " + ip);
		}
		staff.setRemoteIP(cleanse(ip));

		String groups = req1.getHeader(Constant.GROUP_LIST);
		if(groups != null)
			groups.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe groups: " + groups);
		}
		staff.setGroupList(cleanse(groups));
		
		String firstName = format(req1.getHeader(Constant.FIRST_NAME));
		if(firstName != null)
			firstName.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe user first name: " + firstName);
		}
		staff.setFirstName(cleanse(firstName));
		
		String lastName = format(req1.getHeader(Constant.LAST_NAME));
		if(lastName != null)
			lastName.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe last Name: " + lastName);
		}
		staff.setLastName(cleanse(lastName));
      
		String officeID = req1.getHeader(Constant.OFFICE_ID);
		if(officeID != null)
			officeID.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe office Id:'" + officeID + "'");
		}
	    staff.setOfficeID(cleanse(officeID));
        
		String techID = req1.getHeader(Constant.TECH_ID);
		if(techID != null)
			techID.trim();
		if(logger.isInfoEnabled()) {
			logger.info("TIMe/TAMe Tech Id: " + techID);
		}
		staff.setTechID(cleanse(techID));
		
		session.setAttribute(Constant.CREDENTIAL, staff);

		chain.doFilter(request, response);
	}

	private String cleanse(String input)
	{
		String output = "";
		if (input != null && ! input.equals(Constant.NOT_FOUND))
		{
			output = input.trim();
		}
		return output;
	}
	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	private String format(String source)
	{
		if (source != null)
		{
			return source.replaceAll(Constant.HTML_SPACE, Constant.SINGLE_SPACE );

		}
		else
		{
			return "";
		}
	}

}
