package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.ExamBusDelegate;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;
import gov.ca.dmv.AKT.presentation.Beans.SubmitAnswer;
import gov.ca.dmv.AKT.presentation.Beans.Vault;
import gov.ca.dmv.AKT.presentation.Command.Answer;
import gov.ca.dmv.AKT.presentation.Command.Exam;
import gov.ca.dmv.AKT.presentation.DTO.AnswerDTO;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.Model.ExamList;
import gov.ca.dmv.AKT.presentation.Model.ExamResult;
import gov.ca.dmv.AKT.presentation.Model.MessageEndOfExam;
import gov.ca.dmv.AKT.presentation.Model.QuesAnsw;
import gov.ca.dmv.AKT.presentation.Model.ReviewModel;

import java.io.IOException;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;

public class ExamController extends AKTBaseController {
	private ExamBusDelegate    examBusDelegate;
	private EaseAppBusDelegate easeAppBusDelegate; 
	private static final Logger logger = Logger.getLogger(ExamController.class);
	
	public EaseAppBusDelegate getEaseAppBusDelegate() {
		return easeAppBusDelegate;
	}

	public void setEaseAppBusDelegate(EaseAppBusDelegate easeAppBusDelegate) {
		this.easeAppBusDelegate = easeAppBusDelegate;
	}

	public ExamBusDelegate getExamBusDelegate() {
		return examBusDelegate;
	}

	public void setExamBusDelegate(ExamBusDelegate examBusDelegate) {
		this.examBusDelegate = examBusDelegate;
	}
	
	/*
	 * This method is called to generate the exam
	 */
	public ModelAndView GenerateExam(HttpServletRequest request, HttpServletResponse response, HttpSession session, Exam command) {
		try {
			gov.ca.dmv.AKT.presentation.Command.Exam examCmnd = (gov.ca.dmv.AKT.presentation.Command.Exam) command;
			int examId;
			if(request.getParameter("reqSignExamId") != null && request.getParameter("reqSignExamId").length() > Constant.ZERO) {
				examId = Integer.parseInt(request.getParameter("reqSignExamId").trim());
			}
			else {
				examId = Integer.parseInt(examCmnd.getExamId().trim());
			}
			Integer sessionId = (Integer) session.getAttribute("sessionId");
			String  langIdCode = (String) session.getAttribute("langIdCode");
			ExamDTO examDTO = new ExamDTO();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			exam.setLangId(langIdCode);
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			ModelAndView modelAndView = null;
		    
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.generateExam(examDTO, false);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				if(examDTO.getSignExamId() != null) {
					examId = examDTO.getSignExamId();
				}
				modelAndView = new ModelAndView("redirect:Question.do").addObject("examId", examId).addObject("present_order", 1);
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
			
			return modelAndView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	
	/*
	 * This method is called to present the test list
	 */
	public ModelAndView TestList(HttpServletRequest request, HttpServletResponse response, HttpSession session, Exam command) {
		try {
			Integer resumeExamId = (Integer) session.getAttribute("resumeExamId");
			Integer sessionId = (Integer) session.getAttribute("sessionId");
			Integer applicationId = (Integer) session.getAttribute("applicationId");
			String  langIdCode = (String) session.getAttribute("langIdCode");
			ExamDTO examDTO = new ExamDTO();
			ModelAndView modelAndView = null;
			if(resumeExamId != null) {
				gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
				exam.setExamId(resumeExamId);
				List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = 
						new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
				examList.add(exam);
				examDTO.setExamList(examList);			
				examBusDelegate.resumeExam(examDTO);
				//to get the correct present_order
				int skippedQuestsions = examBusDelegate.getSkippedQuestionsCount();
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					session.setAttribute("resumeExamId", null);
					gov.ca.dmv.AKT.presentation.Beans.Exam exam1 = examDTO.getExamList().get(Constant.FIRST_ELEMENT);		
					return new ModelAndView("redirect:Question.do").addObject("examId", exam1.getExamId()).addObject("present_order", exam1.getQuestionAnsweredCount() + skippedQuestsions + 1);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				}
			}
			else {
				gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
				exam.setApplicationId(applicationId);
				exam.setSessionId(sessionId);
				List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = 
						new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
				examList.add(exam);
				examDTO.setExamList(examList);
				examDTO.setLangIdCode(langIdCode);
				examBusDelegate.getExams(examDTO);
			}
			ExamList examModel = new ExamList();
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				examModel.setExamTestLangList(examDTO.getExamTestLangList());
				examModel.setAirbrakes(false);
				if(examDTO.isAirbrakes()) {
					examModel.setAirbrakes(true);
				}
				modelAndView = new ModelAndView("testlist", "Exam", new Exam()).addObject("exammodel", examModel).addObject("timelimit",examBusDelegate.getScreenTimeout("testlist")); 
			}
			else if(examDTO.getErrorCode() == ErrorCode.NULL_EXAM_LIST2) {
				gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
				errorModel.setErrorCode(ErrorCode.NULL_EXAM_LIST2);
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.NULL_EXAM_LIST2));
				}
				modelAndView = new ModelAndView("error").addObject("errormodel", errorModel);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView GradeTimedExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			String examIdString = request.getParameter("examId");
			if(examIdString != null) {
				Integer examId = Integer.parseInt(examIdString);
				ExamDTO examDTO = new ExamDTO();
				List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
				gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
				exam.setExamId(examId);
				examList.add(exam);
				examDTO.setExamList(examList);
				examDTO.setTimedTestTimedOut(true);
				int errCode = gradeExam(examDTO);
				String result = examDTO.getResult();
				ExamResult examResult = new ExamResult();
				if(result.equalsIgnoreCase(Constant.PASS))
					examResult.setPass(true);
				else
					examResult.setPass(false);
				examResult.setExamId(examId);
				if(errCode == ErrorCode.NO_ERROR) {
					view = new ModelAndView("examresult", "Exam", new Exam()).addObject("provisional",examDTO.isProvisional()).addObject("resultmodel", examResult).addObject("timelimit",examBusDelegate.getScreenTimeout("examresult")).addObject("timedTest", true);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(errCode));
					view = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
				}
			}
			return view;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView Question(HttpServletRequest request, HttpServletResponse response, HttpSession session, Answer command) {
		try {
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			int appId = (Integer) session.getAttribute("applicationId");
			exam.setApplicationId(appId);
			exam.setExamId(Integer.parseInt(request.getParameter("examId")));		
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			int order = Integer.parseInt(request.getParameter("present_order"));
			examDTO.setQuestionPresentedOrder(order);
			examDTO.setWorkstationId(getRemoteIP(request)); //request.getHeader(Constant.REMOTE_IP).trim());
			examBusDelegate.showQuestion(examDTO);
			ModelAndView modelAndView = null;
			QuesAnsw quesAnswModel = new QuesAnsw();
			quesAnswModel.setSignFlag(true);
			quesAnswModel.setAudioAllowed(false);
			quesAnswModel.setVideoAllowed(false);
			if(examDTO.isAudioAllowed())
				quesAnswModel.setAudioAllowed(true);
			if(examDTO.isVideoAllowed())
				quesAnswModel.setVideoAllowed(true);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: examDTO.getQuesAnsw().getAnswerList()) {
					if(ans.getSignImage().trim().length() == Constant.ZERO) {
						ans.setSignImage(null);
						quesAnswModel.setSignFlag(false);
					}
					if(ans.getAnswerAudio().trim().length() == Constant.ZERO) {
						ans.setAnswerAudio(null);
					}
					if(ans.getAnswerVideo().trim().length() == Constant.ZERO) {
						ans.setAnswerVideo(null);
					}
				}
				quesAnswModel.setAnswerList(examDTO.getQuesAnsw().getAnswerList());
				if(examDTO.getQuesAnsw().getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
					examDTO.getQuesAnsw().getQuestionLang().setSignImage(null);
				}
				if(examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio().trim().length() == Constant.ZERO) {
					examDTO.getQuesAnsw().getQuestionLang().setQuestionAudio(null);
				}
				if(examDTO.getQuesAnsw().getQuestionLang().getQuestionVideo().trim().length() == Constant.ZERO) {
					examDTO.getQuesAnsw().getQuestionLang().setQuestionVideo(null);
				}
				quesAnswModel.setQuestionLang(examDTO.getQuesAnsw().getQuestionLang());
				quesAnswModel.setQuestionPresentedOrder(examDTO.getQuestionPresentedOrder());
				quesAnswModel.setSkipped(examDTO.isSkipped());
				quesAnswModel.setSkippedThreeTimes(examDTO.isSkippedThreeTimes());
				quesAnswModel.setExamId(Integer.parseInt(request.getParameter("examId")));
				quesAnswModel.setQuestionPresentedTime(new Date());
				quesAnswModel.setPauseAllowed(examDTO.isPausedAllowed());
				quesAnswModel.setQuitAllowed(examDTO.isQuitAllowed());
				quesAnswModel.setProgressBarAllowed(examDTO.isProgressBarAllowed());
				
				modelAndView = new ModelAndView("examquest", "Answer", new Answer()).addObject("quesanswmodel", quesAnswModel).addObject("timedTest", false).addObject("qAnswered",examDTO.getAnsweredQuestions()).addObject("qTotal", examDTO.getTotalQuestions()); 
				if(examDTO.isTimedTest()) {
					modelAndView = new ModelAndView("examquest", "Answer", new Answer()).addObject("quesanswmodel", quesAnswModel).addObject("timedTest", true).addObject("timeforrem", examDTO.getTimeLeftForReminder()).addObject("timedurationforrem", examDTO.getTimeDurationFor15MinRemainder()).addObject("testendrem", examDTO.getTimeLeftForGradingTest()).addObject("qAnswered",examDTO.getAnsweredQuestions()).addObject("qTotal", examDTO.getTotalQuestions());
				}
				modelAndView.addObject("perquestion",examBusDelegate.getScreenTimeout("perquestion")).addObject("warning",examBusDelegate.getScreenTimeout("warning")).addObject("qextn",examBusDelegate.getScreenTimeout("qextn"));
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelAndView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
			}
			return modelAndView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * Get remote IP address.
	 * @param request
	 * @return
	 */
	private String getRemoteIP(HttpServletRequest request) {
		String remoteIP = null;
		if (request.getHeader(Constant.REMOTE_IP) != null && !request.getHeader(Constant.REMOTE_IP).isEmpty()) {
			remoteIP = request.getHeader(Constant.REMOTE_IP).trim();
		}
		else {
			remoteIP = request.getHeader("X-FORWARDED-FOR");  
			if (remoteIP == null) {  
				remoteIP = request.getRemoteAddr();  
			}
			
			if (remoteIP.equals("0:0:0:0:0:0:0:1")) {
				remoteIP = "165.153.122.172";
			}
		}
		return remoteIP;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This method is called to skip a question. The skipped questions should be presented to the applicant at the end of the test.
	 */
	public ModelAndView SkipQuestion(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			int examId = Integer.parseInt(request.getParameter("examId"));
			int order = Integer.parseInt(request.getParameter("order"));		
			
			String questionPresentedTime1 = request.getParameter("questionPresentedTime");	
			SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
			Date questionPresentedTime = null;
			try {
				questionPresentedTime = formatter.parse(questionPresentedTime1);
			} catch (ParseException e) {
				questionPresentedTime = new Date();
			}		
			
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			ExamDTO examDTO = new ExamDTO();
			examDTO.setExamList(examList);
			examDTO.setQuestionPresentedOrder(order);
			examDTO.setQuestionPresentedTime(questionPresentedTime);
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.skipQuestion(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				view = new ModelAndView("redirect:Question.do").addObject("examId", examId).addObject("present_order", ++order);
			}
			else if (examDTO.getErrorCode() == ErrorCode.FORCE_FAILED) {
				ut.commit();
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.FORCE_FAILED));
				}
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					int errCode = updateExamWithEaseTstamp(examDTO,easeAppDTO.isMessageSent());
					if(errCode == ErrorCode.NO_ERROR) {
						examDTO.setForceFailAction(Constant.FORCE_FAIL_DELETE);
						examBusDelegate.publishForceFailRequest(examDTO);
						gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
						errorModel.setErrorCode(ErrorCode.FORCE_FAILED);
						view = new ModelAndView("error").addObject("errormodel", errorModel);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(errCode));
						view = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					view = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				view = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
			return view;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}		
	}
	
	private int failExam(ExamDTO examDTO) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.failExam(examDTO);
			retVal = examDTO.getErrorCode();
			if(retVal == ErrorCode.NO_ERROR || retVal == ErrorCode.FORCE_FAILED) {
				ut.commit();
			} else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	public ModelAndView FailInactiveExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			Integer sessionId = (Integer) session.getAttribute("sessionId");
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			int examId = Integer.parseInt(request.getParameter("examId"));		
			String questionPresentedTime1 = request.getParameter("questionPresentedTime");	
			SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
			Date questionPresentedTime = null;
			try {
				questionPresentedTime = formatter.parse(questionPresentedTime1);
			} catch (ParseException e) {
				questionPresentedTime = new Date();
			}	
			
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setQuestionPresentedTime(questionPresentedTime);
			ModelAndView modelView = null;
			int errorCd = failExam(examDTO);
			if(errorCd == ErrorCode.NO_ERROR) {
				modelView = new ModelAndView("inactivity");
				if(examDTO.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_FO)) {
					EaseAppDTO easeAppDTO = new EaseAppDTO();
					exam.setExamId(examId);
					easeAppDTO.setExam(exam);
					easeAppBusDelegate.sendResult(easeAppDTO);
					if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						ExamDTO examDTO2 = new ExamDTO();
						gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
						exam2.setExamId(easeAppDTO.getExam().getExamId());
						List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
						examList2.add(exam2);
						examDTO2.setExamList(examList2);
						int errCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
						if(errCode != ErrorCode.NO_ERROR) {
							logger.error(ErrorCode.ERROR_MESSAGE(errCode));
							modelView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
						}
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
						modelView = new ModelAndView("inactivity").addObject("errors", errors);
					}
				}
			}
			else if(errorCd == ErrorCode.FORCE_FAILED) {
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.FORCE_FAILED));
				}
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					int errCode = updateExamWithEaseTstamp(examDTO,easeAppDTO.isMessageSent());
					if(errCode == ErrorCode.NO_ERROR) {
						examDTO.setForceFailAction(Constant.FORCE_FAIL_DELETE);
						examBusDelegate.publishForceFailRequest(examDTO);
						gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
						errorModel.setErrorCode(ErrorCode.FORCE_FAILED);
						modelView = new ModelAndView("error").addObject("errormodel", errorModel);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(errCode));
						modelView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					modelView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelView = new ModelAndView("inactivity").addObject("errors", errors);
			}
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	private int gradeAnswer(AnswerDTO answerDTO)
	{
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.gradeAnswer(answerDTO);
			retVal = answerDTO.getErrorCode();
			if(retVal == ErrorCode.FORCE_FAILED) {
				ut.commit();
			}
			else if(retVal == ErrorCode.NO_ERROR) {
				ut.commit();
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
				ut.rollback();
			}
		}
		catch(Exception e)
		{
			logger.error(e);
		}
		return retVal;
	}
	
	private int gradeExam(ExamDTO examDTO) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.gradeExam(examDTO);
			retVal = examDTO.getErrorCode();
			if(retVal == ErrorCode.NO_ERROR) {
				ut.commit();
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	private int updateExamWithEaseTstamp(ExamDTO examDTO, boolean isMessageSent) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			if(isMessageSent){
				Context context = new InitialContext();
				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
				ut.begin();
				examBusDelegate.updateExamWithEaseTstamp(examDTO);
				retVal = examDTO.getErrorCode();
				if(retVal == ErrorCode.NO_ERROR) {
					ut.commit();
				}
				else {
					ut.rollback();
					logger.error(ErrorCode.ERROR_MESSAGE(retVal));
				}
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	public ModelAndView SubmitAnswer(HttpServletRequest request, HttpServletResponse response, HttpSession session, Answer command) {
		try {
			Answer answerCmnd = (Answer) command;
			ModelAndView modelView = null;
			SubmitAnswer answer = new SubmitAnswer();
			int examId = Integer.parseInt(answerCmnd.getExamId());
			if(answerCmnd.getAnswerGenId() == null || answerCmnd.getAnswerGenId().trim().equalsIgnoreCase(""))
				answer.setAnswerGenId(Constant.ZERO);
			else 
				answer.setAnswerGenId(Integer.parseInt(answerCmnd.getAnswerGenId()));
			answer.setExamId(examId);
			int order = Integer.parseInt(answerCmnd.getQuestionPresentedOrder());
			answer.setQuestionPresentedOrder(order);
			answer.setQuestionPresentedTime(answerCmnd.getQuestionPresentedTime());
			AnswerDTO answerDTO = new AnswerDTO();
			answerDTO.setSubmitAnswer(answer);
			int retVal = gradeAnswer(answerDTO);
			if (retVal == ErrorCode.FORCE_FAILED) {
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(retVal));
				}
				if(answerDTO.isAppTypeES()) {
					gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
					exam.setExamId(examId);
					EaseAppDTO easeAppDTO = new EaseAppDTO();
					easeAppDTO.setExam(exam);
					easeAppBusDelegate.sendResult(easeAppDTO);
					if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						ExamDTO examDTO2 = new ExamDTO();
						gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
						exam2.setExamId(easeAppDTO.getExam().getExamId());
						List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
						examList2.add(exam2);
						examDTO2.setExamList(examList2);
						int errorCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
						if(errorCode != ErrorCode.NO_ERROR) {
							logger.error("Failed to update the ease timsestamp for the exam id: " + easeAppDTO.getExam().getExamId());
						}
						else {
							examDTO2.setForceFailAction(Constant.FORCE_FAIL_DELETE);
							examBusDelegate.publishForceFailRequest(examDTO2);
						}
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					}
				}
				gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
				errorModel.setErrorCode(ErrorCode.FORCE_FAILED);
				modelView = new ModelAndView("error").addObject("errormodel", errorModel);
			}
			else if(retVal == ErrorCode.NO_ERROR) {
				ExamDTO examDTO = new ExamDTO();
				List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
				gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();	
				exam.setExamId(examId);
				examList.add(exam);
				examDTO.setExamList(examList);
				examDTO.setSignExam(false);
				int retVal2 = gradeExam(examDTO);
				if(retVal2 == ErrorCode.NO_ERROR) {
					String result = examDTO.getResult();
					if (result == null)
					{
						//Display the missed question first
						if(answerDTO.isIncorrectAnswer() && !examDTO.isTimedTest()) {
							modelView = prepareMissedQuestionView(answerDTO, examId, order, result, examDTO);
						}
						else {
							modelView = new ModelAndView("redirect:Question.do").addObject("examId", examId).addObject("present_order", ++order);
						}
					}
					else
					{
						ExamResult examResult = new ExamResult();
						if(result.equalsIgnoreCase(Constant.PASS))
							examResult.setPass(true);
						else
							examResult.setPass(false);
						examResult.setExamId(examId);
						String officeType = examSeedData.getOfficeTypeByOfficeId(examDTO.getOfficeId());
						boolean chpFail3rdTime = examBusDelegate.getExamTakenCount(examId);
						boolean chpTest = officeType.equals(Constant.APP_TYPE_CHP);
						modelView = new ModelAndView("examresult", "Exam", new Exam()).addObject("provisional",examDTO.isProvisional()).addObject("timedTest", examDTO.isTimedTest()).addObject("resultmodel", examResult).addObject("timelimit",examBusDelegate.getScreenTimeout("examresult"));
						modelView.addObject("chpTest",chpTest).addObject("chpFail3rdTime",chpFail3rdTime).addObject("provisional",examDTO.isProvisional());
						//Display the missed question first
						if(answerDTO.isIncorrectAnswer() && !examDTO.isTimedTest()) {						
							modelView = prepareMissedQuestionView(answerDTO, examId, order, result, examDTO); 
						}
						if(answerDTO.isAppTypeES()) {
							EaseAppDTO easeAppDTO = new EaseAppDTO();
							easeAppDTO.setExam(exam);
							easeAppBusDelegate.sendResult(easeAppDTO);
							if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
								ExamDTO examDTO2 = new ExamDTO();
								gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
								exam2.setExamId(easeAppDTO.getExam().getExamId());
								List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
								examList2.add(exam2);
								examDTO2.setExamList(examList2);
								int errCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
								if(errCode != ErrorCode.NO_ERROR) {
									logger.error(ErrorCode.ERROR_MESSAGE(errCode));
									modelView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
								}
							}
							else {
								logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
								List<String> errors = new ArrayList<String>();
								errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
								modelView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
							}
						}
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					modelView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(answerDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(answerDTO.getErrorCode()));
				modelView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
			}
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * 
	 * @param answerDTO
	 * @param examId
	 * @param order
	 * @param result
	 * @param question
	 * @return
	 * After a user submits an answer one of the following three things can happen:
	 * 1. Present next question
	 * 2. Display the result
	 * 3. At the completion of sign exam, generate the exam that requires a sign exam to be displayed first.
	 * The boolean fields (question and result) indicate which of the above three actions needs to be triggered.
	 * Prepare the view based on the action triggered.
	 */
	private ModelAndView prepareMissedQuestionView(AnswerDTO answerDTO, Integer examId, int order, String result, ExamDTO examDTO) {
		try {
			// Prepare for missed question view
			QuesAnsw quesAnswModel = new QuesAnsw();
			quesAnswModel.setSignFlag(true);
			quesAnswModel.setPauseAllowed(false);
			quesAnswModel.setExamId(examId);
			for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: answerDTO.getAnswerList()) {
				if(ans.getSignImage() != null && ans.getSignImage().trim().length() == Constant.ZERO) {
					ans.setSignImage(null);
					quesAnswModel.setSignFlag(false);
				}
				else if(ans.getSignImage() == null) {
					quesAnswModel.setSignFlag(false);
				}
			}
			quesAnswModel.setAnswerList(answerDTO.getAnswerList());
			if(answerDTO.getQuestionLang().getSignImage() != null &&
			   answerDTO.getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
				answerDTO.getQuestionLang().setSignImage(null);
			}
			quesAnswModel.setQuestionLang(answerDTO.getQuestionLang());
			quesAnswModel.setHandbookRef(answerDTO.getHandbookRef());
			
			if(result == null) {
				quesAnswModel.setNavUrl("Question.do?examId=" + examId + "&present_order=" + ++order);
			}
			else {
				// Prepare for test result view
				boolean pass = result.equalsIgnoreCase(Constant.PASS);
				boolean timedTest = examDTO.isTimedTest();
				boolean	provisional	= examDTO.isProvisional();
				
				String officeType = examSeedData.getOfficeTypeByOfficeId(examDTO.getOfficeId());
				boolean chpFail3rdTime = examBusDelegate.getExamTakenCount(examId);
				boolean chpTest = officeType.equals(Constant.APP_TYPE_CHP);
				
				quesAnswModel.setNavUrl("DisplayResult.do?examId=" + examId + "&pass=" + pass + 
						                "&timedTest=" + timedTest + "&provisional=" + provisional + 
						                "&chpTest=" + chpTest + "&chpFail3rdTime=" + chpFail3rdTime);
			}
			
			return new ModelAndView("review").addObject("quesanswmodel", quesAnswModel).addObject("timelimit",examBusDelegate.getScreenTimeout("review"));
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		} 
	}
	
	public ModelAndView DisplayResult(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		try {
			int examId = Integer.parseInt(request.getParameter("examId"));
			boolean pass = Boolean.parseBoolean(request.getParameter("pass"));
			boolean timedTest = Boolean.parseBoolean(request.getParameter("timedTest"));
			boolean provisional = Boolean.parseBoolean(request.getParameter("provisional"));
			boolean chpTest = Boolean.parseBoolean(request.getParameter("chpTest"));
			boolean chpFail3rdTime = Boolean.parseBoolean(request.getParameter("chpFail3rdTime"));
			
			ExamResult examResult = new ExamResult();
			examResult.setExamId(examId);
			examResult.setPass(pass);
			ModelAndView modelView = new ModelAndView("examresult", "Exam", new Exam()).addObject("provisional",provisional).addObject("resultmodel", examResult).addObject("timelimit",examBusDelegate.getScreenTimeout("examresult")).addObject("timedTest", timedTest)
					.addObject("chpTest",chpTest).addObject("chpFail3rdTime",chpFail3rdTime);
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	
	public ModelAndView DisplayEndExam(HttpServletRequest request, HttpServletResponse response, HttpSession session, Exam command) {
		try {
			ModelAndView modelAndView = null;
			Exam examCmnd = (Exam) command;
			Integer sessionId = (Integer) session.getAttribute("sessionId");
			Integer applicationId = (Integer) session.getAttribute("applicationId");
			String  langIdCode = (String) session.getAttribute("langIdCode");
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			int examId = Integer.parseInt(examCmnd.getExamId());
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			exam.setApplicationId(applicationId);
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setLangIdCode(langIdCode);
			examDTO.setErrorCode(ErrorCode.NO_ERROR);
			examBusDelegate.getEndExamMsg(examDTO);
			gov.ca.dmv.AKT.integration.BeansImpl.IExam exam1 = examBusDelegate.getExamById(examId);
			boolean hasDifferentExams = false;
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				for (ExamTestLang exam2 : examDTO.getExamTestLangList()) {
					if( !exam2.getTestId().equalsIgnoreCase(exam1.getTestId()) ){
						hasDifferentExams = true;
					}
				}
				if(hasDifferentExams){
					modelAndView = new ModelAndView("additionaltests").addObject("examId", examId).addObject("timelimit",examBusDelegate.getScreenTimeout("additionaltests"));
				} else {
					modelAndView = new ModelAndView("redirect:/session/EndSession.do");
				}
			}
			else if(examDTO.getErrorCode() == ErrorCode.ACCESS_FAILURE || examDTO.getErrorCode() == ErrorCode.CATCHALL_FAILURE
					|| examDTO.getErrorCode() == ErrorCode.JDBC_FAILURE || examDTO.getErrorCode() == ErrorCode.INTEGRITY_FAILURE) {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
			else {
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				}
				MessageEndOfExam endExamModel = new MessageEndOfExam();
				endExamModel.setErrorCode(examDTO.getErrorCode());
				modelAndView = new ModelAndView("displayendofexam").addObject("endexammodel", endExamModel);
			}
			return modelAndView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView AdditionalTests(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			int examId = Integer.parseInt(request.getParameter("examId"));
			Integer sessionId = (Integer) session.getAttribute("sessionId");
			Integer applicationId = (Integer) session.getAttribute("applicationId");
			String  langIdCode = (String) session.getAttribute("langIdCode");
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			exam.setApplicationId(applicationId);
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setLangIdCode(langIdCode);
			examDTO.setErrorCode(ErrorCode.NO_ERROR);
			examBusDelegate.getEndExamMsg(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				view = new ModelAndView("perjury").addObject("timelimit",examBusDelegate.getScreenTimeout("perjury"));
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				view = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
			return view;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private int quitExam(ExamDTO examDTO) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.quitExam(examDTO);
			retVal = examDTO.getErrorCode();
			if(retVal == ErrorCode.NO_ERROR || retVal == ErrorCode.FORCE_FAILED) {
				ut.commit();
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	public ModelAndView QuitExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			int sessionId = (Integer) session.getAttribute("sessionId");
			int examId = Integer.parseInt(request.getParameter("examId"));
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			ModelAndView modelAndView = null;
			int errCd = quitExam(examDTO);
			if(errCd == ErrorCode.NO_ERROR) {
				ExamResult examResult = new ExamResult();
				examResult.setPass(false);
				examResult.setExamId(examId);
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					ExamDTO examDTO2 = new ExamDTO();
					gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
					exam2.setExamId(easeAppDTO.getExam().getExamId());
					List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
					examList2.add(exam2);
					examDTO2.setExamList(examList2);
					int errCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
					if(errCode == ErrorCode.NO_ERROR) {
						boolean provisional = easeAppDTO.getApplication().getApplicationStatusCode().trim().equalsIgnoreCase(Constant.PROVISIONAL);
						modelAndView = new ModelAndView("examresult", "Exam", new Exam()).addObject("provisional",provisional).addObject("resultmodel", examResult).addObject("timelimit",examBusDelegate.getScreenTimeout("examresult")).addObject("timedTest", examDTO.isTimedTest());
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(errCode));
						modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					modelAndView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else if(errCd == ErrorCode.FORCE_FAILED) {
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.FORCE_FAILED));
				}
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					int errCode = updateExamWithEaseTstamp(examDTO,easeAppDTO.isMessageSent());
					if(errCode == ErrorCode.NO_ERROR) {
						examDTO.setForceFailAction(Constant.FORCE_FAIL_DELETE);
						examBusDelegate.publishForceFailRequest(examDTO);
						gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
						errorModel.setErrorCode(ErrorCode.FORCE_FAILED);
						modelAndView = new ModelAndView("error").addObject("errormodel", errorModel);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(errCode));
						modelAndView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					modelAndView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelAndView = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
			}
			return modelAndView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView PauseExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			int sessionId = (Integer) session.getAttribute("sessionId");
			int examId = Integer.parseInt(request.getParameter("examId"));
			int applicationId = (Integer) session.getAttribute("applicationId");
			int vaultId = (Integer) session.getAttribute("vaultId");
			
			String questionPresentedTime1 = request.getParameter("questionPresentedTime");	
			SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
			Date questionPresentedTime = null;
			try {
				questionPresentedTime = formatter.parse(questionPresentedTime1);
			} catch (ParseException e) {
				questionPresentedTime = new Date();
			}	
			
			Vault vault = new Vault();
			vault.setVaultId(vaultId);
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			exam.setApplicationId(applicationId);
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setVault(vault);
			examDTO.setQuestionPresentedTime(questionPresentedTime);
			ModelAndView view = null;
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.pauseExam(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				view = new ModelAndView("redirect:/session/InitialScreen.do");
			}
			else if(examDTO.getErrorCode() == ErrorCode.FORCE_FAILED) {
				ut.commit();
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.FORCE_FAILED));
				}
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					int errCode = updateExamWithEaseTstamp(examDTO,easeAppDTO.isMessageSent());
					if(errCode == ErrorCode.NO_ERROR) {
						examDTO.setForceFailAction(Constant.FORCE_FAIL_DELETE);
						examBusDelegate.publishForceFailRequest(examDTO);
						gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
						errorModel.setErrorCode(ErrorCode.FORCE_FAILED);
						view = new ModelAndView("error").addObject("errormodel", errorModel);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(errCode));
						view = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(errCode));
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
					view = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
				}
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				view = new ModelAndView("error").addObject("errormodel", new gov.ca.dmv.AKT.presentation.Model.Error()).addObject("errors", errors);
			}
			return view;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}		
	}
	
	public ModelAndView PauseConfirmation(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		int examId = Integer.parseInt(request.getParameter("examId"));
		int order = Integer.parseInt(request.getParameter("order"));
		return new ModelAndView("pauseconfirmation").addObject("examId", examId).addObject("order", order);
	}

	public ModelAndView ReviewMissedExamQuestions(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			examList.add(exam);
			examDTO.setWorkstationId(getRemoteIP(request));
			examDTO.setExamList(examList);
			examBusDelegate.getMissedQuestionsFromSessionData(examDTO);		
			ReviewModel reviewModel = new ReviewModel();
			ModelAndView modelView = null;
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				for(gov.ca.dmv.AKT.presentation.Beans.QuesAnsw quesAnsw: examDTO.getQuesAnswList()) {
					quesAnsw.setSignFlag(true);
					if(quesAnsw.getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
						quesAnsw.getQuestionLang().setSignImage(null);
					}
					for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: quesAnsw.getAnswerList()) {
						if(ans.getSignImage().trim().length() == Constant.ZERO) {
							ans.setSignImage(null);
							quesAnsw.setSignFlag(false);
						}
					}
				}
				reviewModel.setQuesAnswList(examDTO.getQuesAnswList());
				reviewModel.setExamId(examId);

					String langId = (String)request.getSession().getAttribute("langIdCode");
					modelView = new ModelAndView("reviewExam", "Exam", new Exam()).addObject("reviewmodel", reviewModel).addObject("lang", langId).addObject("timelimit",examDTO.getTimeToReviewMissedQuestions()).addObject("handbookRefAllowed",examDTO.isHandbookRefAllowed());
				
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));			
			}
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView SampleQuestion(HttpServletRequest request, HttpServletResponse response, HttpSession session) {		
		try {
			boolean audioFlg = false;
			boolean videoFlg = false;
			
			String audioVideoTestCd = examBusDelegate.getApplicantAudioVideoInd();
			if (audioVideoTestCd.equals("A")) {
				audioFlg = true;
			}
			else if (audioVideoTestCd.equals("V")) {
				videoFlg = true;
			}
			else if (audioVideoTestCd.equals("B")) {
				audioFlg = true;
				videoFlg = true;
			}
			return new ModelAndView("samplequestion").addObject("audioflag", audioFlg).addObject("videoflag", videoFlg).addObject("timelimit",examBusDelegate.getScreenTimeout("samplequestion"));
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView PerjuryStatement(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		return new ModelAndView("perjury").addObject("timelimit",examBusDelegate.getScreenTimeout("perjury"));
	}
	
	public void createErrorLogRecord(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		PrintStream printStream = null;
		try {
			printStream = new PrintStream(response.getOutputStream());
			String messageToLog  = request.getParameter("messageToLog");
			logger.error(messageToLog);
			printStream.print("Success");
		} catch (IOException e) {
			logger.error(e.getMessage(), e);				
		}
		return;
	}
}
