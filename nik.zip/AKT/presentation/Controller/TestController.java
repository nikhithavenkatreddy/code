package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectReceived;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSReceiver;
import gov.ca.dmv.AKT.integration.Persistence.QuestionPersistence;
import gov.ca.dmv.AKT.presentation.Command.FOMain;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.ancientprogramming.fixedformat4j.format.FixedFormatManager;
import com.ancientprogramming.fixedformat4j.format.impl.FixedFormatManagerImpl;

/*
 * This class is used to simply test internationalization. This controller needs to be removed before going live.
 */
public class TestController extends MultiActionController {
	
	private QuestionPersistence questionPersistence;
	
	private static FixedFormatManager manager = new FixedFormatManagerImpl();
	private EaseAppBusDelegate easeAppBusDelegate; 
	private static final Logger logger = Logger.getLogger(JMSReceiver.class);
	
	public EaseAppBusDelegate getEaseAppBusDelegate() {
		return easeAppBusDelegate;
	}

	public void setEaseAppBusDelegate(EaseAppBusDelegate easeAppBusDelegate) {
		this.easeAppBusDelegate = easeAppBusDelegate;
	}
	
	public QuestionPersistence getQuestionPersistence() {
		return questionPersistence;
	}

	public void setQuestionPersistence(QuestionPersistence questionPersistence) {
		this.questionPersistence = questionPersistence;
	}

//	public ModelAndView TestInternationalization(HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView view = new ModelAndView("test");
//		try {
//			request.setCharacterEncoding("UTF-8");
//		} catch (UnsupportedEncodingException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		if(request.getMethod().equalsIgnoreCase("GET")) {
//			return view;
//		}
//		
//		String text1 = request.getParameter("text1");
//		Date cur = new Date();
////		try {
////			text1 = new String(text1.getBytes(), "UTF-8");
////		} catch (UnsupportedEncodingException e1) {
////			// TODO Auto-generated catch block
////			e1.printStackTrace();
////		}
//		QuestionLang8 ql8 = new QuestionLang8();
//		ql8.setHandbookRef("Bxxxx");
//		ql8.setLangId("xx");
//		ql8.setLastModUsername(Constant.LASTMODUSR_NME);
//		ql8.setLastModUserTime(cur);
//		ql8.setQuestionId("xxxxxxxxQ");
//		ql8.setQuestionLangId("xxxxxxxxQxx");
//		ql8.setQuestionLangStatus(Constant.ACTIVE);
//		ql8.setQuestionText(text1);
//		ql8.setSignImage(Constant.SINGLE_SPACE);
//		
//		try {
//			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("C:\\Rahul\\uni.txt")));
//			writer.write(text1);
//			writer.newLine();
//			writer.flush();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		QuestionLang16 ql16 = new QuestionLang16();
//		ql16.setHandbookRef("Bxxxx");
//		ql16.setLangId("xx");
//		ql16.setLastModUsername(Constant.LASTMODUSR_NME);
//		ql16.setLastModUserTime(cur);
//		ql16.setQuestionId("xxxxxxxxQ");
//		ql16.setQuestionLangId("xxxxxxxxQxx");
//		ql16.setQuestionLangStatus(Constant.ACTIVE);
//		ql16.setQuestionText(text1);
//		ql16.setSignImage(Constant.SINGLE_SPACE);
//		
//		QuestionLangBln qlBln = new QuestionLangBln();
//		qlBln.setHandbookRef("Bxxxx");
//		qlBln.setLangId("xx");
//		qlBln.setLastModUsername(Constant.LASTMODUSR_NME);
//		qlBln.setLastModUserTime(cur);
//		qlBln.setQuestionId("xxxxxxxxQ");
//		qlBln.setQuestionLangId("xxxxxxxxQxx");
//		qlBln.setQuestionLangStatus(Constant.ACTIVE);
//		qlBln.setQuestionText(text1);
//		qlBln.setSignImage(Constant.SINGLE_SPACE);
//		
//		QuestionLang ql = new QuestionLang();
//		ql.setHandbookRef("Bxxxx");
//		ql.setLangId("xx");
//		ql.setLastModUsername(Constant.LASTMODUSR_NME);
//		ql.setLastModUserTime(cur);
//		ql.setQuestionId("xxxxxxxxQ");
//		ql.setQuestionLangId("xxxxxxxxQxx");
//		ql.setQuestionLangStatus(Constant.ACTIVE);
//		ql.setQuestionText(text1);
//		ql.setSignImage(Constant.SINGLE_SPACE);
//		
//		questionPersistence.save(ql8);
//		questionPersistence.save(ql16);
//		questionPersistence.save(qlBln);
//		questionPersistence.save(ql);
//		
//		
//		response.setCharacterEncoding("UTF-8");
//		return view;
//	}
//	
	public ModelAndView ViewInternationalization(HttpServletRequest request, HttpServletResponse response ) {
		response.setCharacterEncoding("UTF-8");
		request.getSession().setAttribute("localelanguage", "hi_IN");
		ModelAndView view = new ModelAndView("test2");
//		List<QuestionLang8> ql8List = questionPersistence.loadQuestionLang8();
////		for(QuestionLang8 q: ql8List) {
////			String text = q.getQuestionText();
////			try {
////				System.out.println("text: " + text);
////				text = new String(text.getBytes(), "ISO-8859-1");
////				System.out.println("text2: " + text);
////				q.setQuestionText(text);
////			} catch (UnsupportedEncodingException e) {
////				// TODO Auto-generated catch block
////				e.printStackTrace();
////			}
////		}
//		List<QuestionLang16> ql16List = questionPersistence.loadQuestionLang16();
//		List<QuestionLangBln> qlBlnList = questionPersistence.loadQuestionLangBln();
//		List<QuestionLang> qlList = questionPersistence.loadQuestionLang();
//		return view.addObject("ql8List", ql8List).addObject("ql16List", ql16List).addObject("qlBlnList", qlBlnList).addObject("qlList", qlList);
		return view;
	}
	
	private int saveReceivedString(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/* try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
        	easeAppBusDelegate.saveReceivedString(easeAppDTO);
        	err = easeAppDTO.getErrorCode();
            /* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} */
		return err;
	}
	
	private int createApp(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/* try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
			easeAppBusDelegate.createApp(easeAppDTO);
			err = easeAppDTO.getErrorCode();
            /* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}  */
		return err;
	}
	
	private int updateEaseReceivedIndicator(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		/* try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  */
			easeAppBusDelegate.updateEaseReceivedIndicator(easeAppDTO);
			err = easeAppDTO.getErrorCode();
        	/* if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} */
		return err;
	}

	public ModelAndView CreateTestRecord(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		modelAndView = new ModelAndView("fomain", "FOMain", new FOMain());
		
        try {
        	String dlNum = "C1234604";
        	String receivedString = "AKTS" + dlNum + "        TESTED                     COMMERCIAL                 01011980NYNA DTHMPVSBTV  0CA0NHM0NAB0YBK0NTK0NDT0NPV0NGK0N                    448DG543511152013091831";
        	if(logger.isInfoEnabled()) {
        		logger.info("RECEIVED MQ STRING FROM EASE");
        	}
            EASEObjectReceived easeObj = manager.load(EASEObjectReceived.class, receivedString);
            if(logger.isInfoEnabled()) {
            	if(easeObj.getDlNumber().length() > 3)
            		logger.info("RECEIVED MQ STRING FROM EASE FOR DL# ENDING WITH: " + easeObj.getDlNumber().substring((easeObj.getDlNumber().length() - 4), easeObj.getDlNumber().length()));
        	}
            
            Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
            EaseAppDTO easeAppDTO = new EaseAppDTO();
            easeAppDTO.setReceivedString(receivedString);
            int errorCode1 = saveReceivedString(easeAppDTO);
        	if(errorCode1 == ErrorCode.NO_ERROR) {
        		easeAppDTO.create(easeObj);
				int errorCode2 = createApp(easeAppDTO);
				if(errorCode2 == ErrorCode.NO_ERROR) {
					easeAppDTO.setEaseReceivedMessageInd(Constant.YES);
					updateEaseReceivedIndicator(easeAppDTO);
				}
				else {
					easeAppDTO.setEaseReceivedMessageInd(Constant.YES);
					updateEaseReceivedIndicator(easeAppDTO);
				}
				ut.commit();
        	}
        	else {
        		ut.rollback();
        	}        	
        }
        catch (Exception ex) {
        	ex.printStackTrace();            
        }      
        
        return modelAndView;
   }
}
