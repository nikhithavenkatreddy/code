package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.Services.AuditService;
import gov.ca.dmv.AKT.business.Services.ExamSeedData;
import gov.ca.dmv.AKT.business.Services.ExamSessionData;
import gov.ca.dmv.AKT.constants.Constant;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class AKTBaseController extends MultiActionController {
	private AuditService auditService;
	protected ExamSeedData examSeedData;
	protected ExamSessionData examSessionData;
	
	public ExamSeedData getExamSeedData() {
		return examSeedData;
	}

	public void setExamSeedData(ExamSeedData examSeedData) {
		this.examSeedData = examSeedData;
	}

	public AuditService getAuditService() {
		return auditService;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}

	public ModelAndView handleException(Exception e, Logger logger, String key, String techId) {
		logger.error(e.getMessage(), e);
		auditService.saveAudit(this.getClass().getSimpleName(), getMethodName(1), Constant.SINGLE_SPACE, 
				getStackTrace(e), key, techId);	
		ModelAndView view = null;
		if (this.getClass().getSimpleName().contains("HQ")) {
			view = new ModelAndView("redirect:Welcome.do");
		}
		else if (this.getClass().getSimpleName().contains("FO")) {
			view = new ModelAndView("redirect:FOMainPage.do");
		}
		else if (this.getClass().getSimpleName().contains("Session")) {
			view = new ModelAndView("redirect:InitialScreen.do");
		}
		else if (this.getClass().getSimpleName().contains("Exam")) {
			view = new ModelAndView("redirect:InitialScreen.do");
		}
		else {
			view = new ModelAndView("error");
		}
		
		return view;
	}
	
	public static String getStackTrace (Throwable t) {
	    StringWriter sw = new StringWriter();
	    t.printStackTrace(new PrintWriter(sw));
	    
	    String returnStr = null;
	    if (sw.toString().length() >= 800) {
	    	returnStr = sw.toString().substring(0, 799);
	    }
	    else {
	    	returnStr = sw.toString();
	    }
	    return returnStr;
	}
	
	/**
	 * Get the method name for a depth in call stack. <br />
	 * Utility function
	 * @param depth depth in the call stack (0 means current method, 1 means call method, ...)
	 * @return method name
	 */
	public static String getMethodName(final int depth)
	{
	  final StackTraceElement[] ste = Thread.currentThread().getStackTrace();

	  //System. out.println(ste[ste.length-depth].getClassName()+"#"+ste[ste.length-depth].getMethodName());
	  // return ste[ste.length - depth].getMethodName();  //Wrong, fails for depth = 0
	  return ste[ste.length - 1 - depth].getMethodName(); //Thank you Tom Tresansky
	}

	public ExamSessionData getExamSessionData() {
		return examSessionData;
	}

	public void setExamSessionData(ExamSessionData examSessionData) {
		this.examSessionData = examSessionData;
	}
}
