package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.ExamBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.FOBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.SessionBusDelegate;
import gov.ca.dmv.AKT.comparators.ApplicantComparator;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.SearchRequestTypeConstant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.Beans.Exam;
import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.QuesAnsw;
import gov.ca.dmv.AKT.presentation.Beans.Session;
import gov.ca.dmv.AKT.presentation.Beans.Vault;
import gov.ca.dmv.AKT.presentation.Beans.Volume;
import gov.ca.dmv.AKT.presentation.Beans.WorkstationMap;
import gov.ca.dmv.AKT.presentation.Command.ApplicantInformation;
import gov.ca.dmv.AKT.presentation.Command.DatePicker;
import gov.ca.dmv.AKT.presentation.Command.FOMain;
import gov.ca.dmv.AKT.presentation.Command.ForceFail;
import gov.ca.dmv.AKT.presentation.Command.PrintTest;
import gov.ca.dmv.AKT.presentation.Command.PrintTests;
import gov.ca.dmv.AKT.presentation.Command.Search;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.DTO.FailedYOBDTO;
import gov.ca.dmv.AKT.presentation.DTO.ReportDTO;
import gov.ca.dmv.AKT.presentation.DTO.SessionDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.WorkstationMapDTO;
import gov.ca.dmv.AKT.presentation.Model.ApplicantModel;
import gov.ca.dmv.AKT.presentation.Model.ExceptionReport;
import gov.ca.dmv.AKT.presentation.Model.PrintTestModel;
import gov.ca.dmv.AKT.presentation.Model.PrintTestsModel;
import gov.ca.dmv.AKT.presentation.Model.ReviewModel;
import gov.ca.dmv.AKT.presentation.Model.SubYOBLockout;
import gov.ca.dmv.AKT.presentation.Model.TerminalStatus;
import gov.ca.dmv.AKT.presentation.Model.TestList;
import gov.ca.dmv.AKT.presentation.Validators.ApplicantInfoValidator;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;

public class FOUserController extends AKTBaseController { 
	
	private SessionBusDelegate  sessionBusDelegate;
	private ExamBusDelegate     examBusDelegate;
	private EaseAppBusDelegate  easeAppBusDelegate; 
	private FOBusDelegate       foBusDelegate;
	private static final Logger logger = Logger.getLogger(FOUserController.class);
	BindingResult               errors;
	
	public BindingResult getErrors() {
		return errors;
	}

	public void setErrors(BindingResult errors) {
		this.errors = errors;
	}

	public FOBusDelegate getFoBusDelegate() {
		return foBusDelegate;
	}

	public void setFoBusDelegate(FOBusDelegate foBusDelegate) {
		this.foBusDelegate = foBusDelegate;
	}

	public EaseAppBusDelegate getEaseAppBusDelegate() {
		return easeAppBusDelegate;
	}

	public void setEaseAppBusDelegate(EaseAppBusDelegate easeAppBusDelegate) {
		this.easeAppBusDelegate = easeAppBusDelegate;
	}
	
	public ExamBusDelegate getExamBusDelegate() {
		return examBusDelegate;
	}

	public void setExamBusDelegate(ExamBusDelegate examBusDelegate) {
		this.examBusDelegate = examBusDelegate;
	}

	public SessionBusDelegate getSessionBusDelegate() {
		return sessionBusDelegate;
	}

	public void setSessionBusDelegate(SessionBusDelegate sessionBusDelegate) {
		this.sessionBusDelegate = sessionBusDelegate;
	}

	/*
	 * The method below checks if the binding of properties in a page has any errors.
	 */
	protected void bind(HttpServletRequest request, Object command)	throws Exception {
			ServletRequestDataBinder binder = createBinder(request, command);
			binder.bind(request);
			errors = binder.getBindingResult();
	}
	
	/*
	 * The method below invokes the respective validator for the fields in a page.
	 */
	public void validate(Object command) {
		Validator[] validators = getValidators();
		if (validators != null){
			for(int index = 0; index < validators.length; index++) {
				Validator validator = validators[index];
				if(validator instanceof ApplicantInfoValidator) {
					if(((ApplicantInfoValidator) validator).supports(command.getClass())) {
						ValidationUtils.invokeValidator(validators[index], command, errors);
					}
				}
			}
		}
	}
	
	/*
	 * The method below creates the list of errors that occurred during the binding of a property in a page and
	 * these errors will be displayed on the page as validation errors
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void saveError(HttpServletRequest request, String msg, String field) {
		List errors = (List) request.getAttribute("errors");
		if (errors == null) {
			errors = new ArrayList();
		}
		errors.add(msg);
		request.setAttribute("errors", errors);
		request.setAttribute("field", field);
	}
	
	public ModelAndView FOMainPage(HttpServletRequest request, HttpServletResponse response, HttpSession session, FOMain command) {
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff  = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			if(group != null && !staff.hasGlobalView()) {
				boolean validGroup = foBusDelegate.isGroupValid(staff.getOfficeID(),group);
				String option1  = "Enter Applicant Information"; 
				String option2	= "View Active Sessions";
				String option3  = "Manually Assign Test";
				String option4  = "Reset Authentication";
				String option5 	= "View Test Status";
				String option6	= "View Test Results";
				String option7  = "Print Missed Questions";
				String option8 = "Generate Exception Report";
				String option9 = "Generate Historical Tests Report";
				String option10 = "Manual (Printed) AKTE Test(s)";
				String option11 = "End of Day";
				String option12 = "Generate Field Office Volume Report";
				String option13 = "Print Finished Test(s)";
				String option14 = "Print Finished Ambulance Test(s)";
				String option15 = "Generate Test(s)";//all
				String option16 = "Transfer Terminal";
				List<String> options = new ArrayList<String>();
				
				options.add(option1);
				options.add(option2);
				options.add(option3);
				options.add(option4);
				options.add(option5);
				options.add(option6);
				options.add(option7);
				options.add(option8);
				options.add(option9);
				options.add(option10);
				options.add(option11);
				if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.DS_USER_GROUP) || 
				   group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP) || 
				   group.trim().equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.FO_USER_GROUP)) {
					options.add(option12);
				}
				if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.DS_USER_GROUP) || 
				   group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP) || 
				   group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
					options.add(option13);
				}
				if(group.trim().equalsIgnoreCase(Constant.ISS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.ISS_USER_GROUP)||
				   group.trim().equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.FO_USER_GROUP)) {
				   options.add(option14);
				}
				options.add(option15);
				if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || 
				   group.trim().equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) ) {
					options.add(option16);
				}
				gov.ca.dmv.AKT.presentation.Model.FOMain foMainModel = new gov.ca.dmv.AKT.presentation.Model.FOMain();
				foMainModel.setOptions(options);
				foMainModel.setHeadingBasedOnGroup(group);
				modelAndView = new ModelAndView("fomain", "FOMain", new FOMain()).addObject("fomainmodel", foMainModel).addObject("staff", staff).addObject("size", foMainModel.getOptions().size());
				if(!validGroup){
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(ErrorCode.INVALID_GROUP));
					modelAndView.addObject("errors", errors);
				}
				if(request.getMethod().equalsIgnoreCase("POST") && validGroup) {
					FOMain foMainCmnd = (FOMain) command;
					if(foMainCmnd.getOption() == null) {
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(ErrorCode.NO_SELECTION));
						return new ModelAndView("fomain", "FOMain", new FOMain()).addObject("fomainmodel", foMainModel).addObject("staff", staff).addObject("errors", errors).addObject("size", foMainModel.getOptions().size());
					}
					String option = foMainCmnd.getOption().trim();
					if(option.equalsIgnoreCase(option1)) {
						modelAndView = new ModelAndView("redirect:ApplicantInfo.do");
					}
					else if(option.equalsIgnoreCase(option2)) {
						modelAndView = new ModelAndView("redirect:ActiveSessions.do");
					}
					else if(option.equalsIgnoreCase(option3)) {
						modelAndView = new ModelAndView("redirect:TerminalStatus.do");
					}
					else if(option.equalsIgnoreCase(option4)) {
						modelAndView = new ModelAndView("redirect:FailedToAuthenticate.do");
					}
					else if(option.equalsIgnoreCase(option5)) {
						modelAndView = new ModelAndView("redirect:TestStatus.do");
					}
					else if(option.equalsIgnoreCase(option6)) {
						modelAndView = new ModelAndView("redirect:TestResults.do");
					}
					else if(option.equalsIgnoreCase(option7)) {
						modelAndView = new ModelAndView("redirect:PrintMissedQuestions.do");
					}
					else if(option.equalsIgnoreCase(option8)) {
						modelAndView = new ModelAndView("redirect:ExceptionReport.do");
					}
					else if(option.equalsIgnoreCase(option9)) {
						modelAndView = new ModelAndView("redirect:HistoricalReport.do");
					}
					else if(option.equalsIgnoreCase(option10)) {
						modelAndView = new ModelAndView("redirect:PrintTestQueue.do");
					}
					else if(option.equalsIgnoreCase(option11)) {
						modelAndView = new ModelAndView("redirect:OutstandingReport.do");
					}				
					else if(option.equalsIgnoreCase(option12)) {
						modelAndView = new ModelAndView("redirect:VolumeReport.do");
					}
					else if(option.equalsIgnoreCase(option13) || option.equalsIgnoreCase(option14) ) {
						modelAndView = new ModelAndView("redirect:PrintFinishedTests.do");
					}
					else if(option.equalsIgnoreCase(option15)) {
						modelAndView = new ModelAndView("redirect:PrintTestList.do");
					}
					else {
						modelAndView = new ModelAndView("redirect:TransferTerminalView.do");
					}
				}
			}
			else if(staff.hasGlobalView()){
				String option1	= "View Test Results";
				String option2	= "Print Finished Ambulance Test(s)";
				List<String> options = new ArrayList<String>();
				 if (staff.getGroupList().trim().equalsIgnoreCase(Constant.CPD_ADMIN_GROUP) || staff.getGroupList().trim().equalsIgnoreCase(Constant.CPD_USER_GROUP)){
					 options.add(option1);
				 }
				 else{
					 options.add(option1);	 
					 options.add(option2);
				}
				gov.ca.dmv.AKT.presentation.Model.FOMain foMainModel = new gov.ca.dmv.AKT.presentation.Model.FOMain();
				foMainModel.setOptions(options);
				foMainModel.setHeadingBasedOnGroup(group);
				
				modelAndView = new ModelAndView("fomain", "FOMain", new FOMain()).addObject("fomainmodel", foMainModel).addObject("staff", staff).addObject("size", foMainModel.getOptions().size());
				if(request.getMethod().equalsIgnoreCase("POST")) {
					FOMain foMainCmnd = (FOMain) command;
					if(foMainCmnd.getOption() == null) {
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(ErrorCode.NO_SELECTION));
						return new ModelAndView("fomain", "FOMain", new FOMain()).addObject("fomainmodel", foMainModel).addObject("staff", staff).addObject("errors", errors).addObject("size", foMainModel.getOptions().size());
					}
					
					String option = foMainCmnd.getOption().trim(); 
					if(option.equalsIgnoreCase(option1)) {
						modelAndView = new ModelAndView("redirect:TestResultsAll.do");
					}
					if(option.equalsIgnoreCase(option2)) {
						modelAndView = new ModelAndView("redirect:PrintFinishedTests.do");
					}
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to search by DL # or search by Last Name based on the request type.
	 */
	public ModelAndView Search(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String officeId = staff.getOfficeID().trim();
			Search search = (Search) command;
			if(staff.hasGlobalView()){
				officeId = search.getOfficeId().trim();
			}
			String workstationId = search.getWorkstationId();
			ApplicantDTO appDTO = new ApplicantDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Search> searchList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Search>();
			gov.ca.dmv.AKT.presentation.Beans.Search searchBean = new gov.ca.dmv.AKT.presentation.Beans.Search();
			searchBean.setDl(search.getDl());
			searchBean.setLastName(search.getLastName());
			searchBean.setRequestType(search.getRequestType());
			searchBean.setOfficeId(officeId);
			searchBean.setGroup(group);
			searchList.add(searchBean);
			appDTO.setSearchList(searchList);
			foBusDelegate.search(appDTO);
			appDTO.setOfficeId(officeId);
			ApplicantModel appModel = new ApplicantModel();
			if (appDTO.getApplicantList() != null) {
				java.util.Collections.sort(appDTO.getApplicantList(), new ApplicantComparator());
			}
			appModel.setApplicantList(appDTO.getApplicantList());
			if(search.getRequestType() == SearchRequestTypeConstant.TEST_QUEUE_REQUEST) {
				view = searchTestQueueHelper(staff, workstationId, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PRINT_TEST_QUEUE_REQUEST) {
				view = searchPrintQueueHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PRINT_MISSED_QUES_REQUEST) {
				view = searchPrintMissedQuestions(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TEST_RESULTS) {
				view = searchTestResults(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TEST_RESULTS_ALL_OFFICES) {
				view = searchTestResultsAllOffices(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PAUSE_REQUEST) {
				view = searchPauseHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.FAIL_TO_AUTHENTICATE_REQUEST) {
				view = searchFailedToAuthHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.DISCONNECTED_REQUEST) {
				view = searchDisconnectedHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TIMEOUT_REQUEST) {
				view = searchTimeoutHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.QUIT_REQUEST) {
				view = searchQuitHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.IN_PROGRESS_REQUEST) {
				view = searchInProgressHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TEST_STATUS){
				view = searchTestStatusHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.VIEW_ACITVE_SESSIONS){
				view = searchActiveSessionsHelper(staff, appDTO, appModel);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.EOD_REPORT){
				view = searchEndOfDayHelper(staff, appDTO, appModel);
			}
			if(command!=null){
				view.addObject("dl_rinput", command.getDl()).addObject("last_name_rinput", command.getLastName()).addObject("office_id_rinput", command.getOfficeId());
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private ModelAndView searchTestStatusHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
		boolean searchFail=false;
		String failStatus="";
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR  || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("teststatus", "Search", search).addObject("status", appModel).addObject("staff", staff).addObject("actionStatus", searchFail).addObject("returnStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("teststatus", "Search", search).addObject("status", appModel).addObject("errors", errors).addObject("staff", staff);
		}
		return view;		
	}
	
	private ModelAndView searchEndOfDayHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.EOD_REPORT);
		boolean searchFail=false;
		String failStatus="";
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR  || appDTO.getErrorCode() == ErrorCode.RECORD_NOT_FOUND || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("incompleteexams", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("actionStatus", searchFail).addObject("returnStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("incompleteexams", "Search", search).addObject("status", appModel).addObject("errors", errors).addObject("staff", staff);
		}
		return view;		
	}
	
	private ModelAndView searchActiveSessionsHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.VIEW_ACITVE_SESSIONS);
		boolean searchFail=false;
		String failStatus="";
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR  || appDTO.getErrorCode() == ErrorCode.RECORD_NOT_FOUND || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("activesessionlist", "Search", search).addObject("terminatesessionmodel", appModel).addObject("staff", staff).addObject("actionStatus", searchFail).addObject("failStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("activesessionlist", "Search", search).addObject("status", appModel).addObject("errors", errors).addObject("staff", staff);
		}
		return view;		
	}
	
	private ModelAndView searchInProgressHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.IN_PROGRESS_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("forcefaillist", "ForceFail", new ForceFail()).addObject("Search", search).addObject("forcefailmodel", appModel).addObject("staff", staff).addObject("forceFailSuccess", false);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("forcefaillist", "ForceFail", new ForceFail()).addObject("Search", search).addObject("forcefailmodel", appModel).addObject("staff", staff).addObject("errors", errors).addObject("forceFailSuccess", false);
		}
		return view;
	}
	
	private ModelAndView searchQuitHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.QUIT_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("quitexams", "Search", search).addObject("quit", appModel).addObject("staff", staff).addObject("resumed", false);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("quitexams", "Search", search).addObject("quit", appModel).addObject("errors", errors).addObject("staff", staff).addObject("resumed", false);
		}
		return view;
	}
	
	private ModelAndView searchTimeoutHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.TIMEOUT_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("timedoutexams", "Search", search).addObject("to", appModel).addObject("staff", staff).addObject("resumed", false);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("timedoutexams", "Search", search).addObject("to", appModel).addObject("errors", errors).addObject("staff", staff).addObject("resumed", false);
		}
		return view;
	}

	private ModelAndView searchDisconnectedHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.DISCONNECTED_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("disconnectedsessions", "Search", search).addObject("ds", appModel).addObject("staff", staff).addObject("comp", false);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			if (appDTO.getErrorCode() != ErrorCode.MISSING_EXAMS) {
				errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode())); 
			}
			view = new ModelAndView("disconnectedsessions", "Search", search).addObject("ds", appModel).addObject("errors", errors).addObject("staff", staff).addObject("comp", false);
		}
		return view;
	}
	
	private ModelAndView searchPrintQueueHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view;
		Search search = new Search();
		String failStatus="";
		search.setRequestType(SearchRequestTypeConstant.PRINT_TEST_QUEUE_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			if(appDTO.getApplicantList().size()==0){
				appDTO.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("printtestqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("failStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("printtestqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("errors", errors);
		}
		return view;
	}
	
	private ModelAndView searchFailedToAuthHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view;
		Search search = new Search();
		String failStatus="";
		search.setRequestType(SearchRequestTypeConstant.FAIL_TO_AUTHENTICATE_REQUEST);
		sessionBusDelegate.getFailedToAuthApplicantList(appDTO);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			if(appDTO.getApplicantList().size()==0){
				appDTO.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("failedtoauthenticate", "Search", search).addObject("failedtoauthenticatelist", appDTO.getApplicantList()).addObject("staff", staff).addObject("failStatus", failStatus);;
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("failedtoauthenticate", "Search", search).addObject("failedtoauthenticatelist", appDTO.getApplicantList()).addObject("staff", staff).addObject("errors", errors);
		}
		return view;
	}
	
	private ModelAndView searchPauseHelper(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.PAUSE_REQUEST);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("pausedexamslist", "Search", search).addObject("pausedexamsmodel", appModel).addObject("staff", staff).addObject("pop", false);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("pausedexamslist", "Search", search).addObject("pausedexamsmodel", appModel).addObject("staff", staff).addObject("pop", false).addObject("errors", errors);
		}
		return view;
	}

	private ModelAndView searchTestQueueHelper(IDMVStaff staff, String workstationId, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.TEST_QUEUE_REQUEST);
		search.setWorkstationId(workstationId);
		boolean searchFail=false;
		String failStatus="";
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR || appDTO.getErrorCode() == ErrorCode.RECORD_NOT_FOUND || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("testqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("wid", workstationId).addObject("fail",searchFail).addObject("failStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("testqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("errors", errors).addObject("wid", workstationId);
		}
		return view;
	}
	
	private ModelAndView searchPrintMissedQuestions(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.PRINT_MISSED_QUES_REQUEST);
		boolean incomplete = false;
		boolean incorrectDL = false;
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR || appDTO.getErrorCode() == ErrorCode.INCOMPLETE_TEST || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL) {
			if(appDTO.getErrorCode() == ErrorCode.INCOMPLETE_TEST) {
				incomplete = true;
			}
			else if(appDTO.getErrorCode() == ErrorCode.INCORRECT_DL) {
				incorrectDL = true;
			}
			view = new ModelAndView("dl", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("incompTest", incomplete).addObject("incorrDL", incorrectDL);
		}
		else {
			logger.info(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			if(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()).equals(ErrorCode.ERROR_MESSAGE(ErrorCode.MISSING_REQUIRED))) {
				errors.add("Provide either DL Number or Last Name");
			} else {
				errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			}
			view = new ModelAndView("dl", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("errors", errors).addObject("incompTest", incomplete).addObject("incorrDL", incorrectDL);
		}
		return view;
	}
	
	private ModelAndView searchTestResults(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.TEST_RESULTS);
		boolean searchFail=false;
		String failStatus="";
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR || appDTO.getErrorCode() == ErrorCode.RECORD_NOT_FOUND || appDTO.getErrorCode() == ErrorCode.INCOMPLETE_TEST || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("testresults", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("fail",searchFail).addObject("failStatus", failStatus);
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("testresults", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("errors", errors);
		}
		return view;
	}	
	
	private ModelAndView searchTestResultsAllOffices(IDMVStaff staff, ApplicantDTO appDTO, ApplicantModel appModel) {
		ModelAndView view = null;
		Search search = new Search();
		search.setRequestType(SearchRequestTypeConstant.TEST_RESULTS_ALL_OFFICES);
		boolean searchFail=false;
		String failStatus="";
		WorkstationMapDTO wmDTO = new WorkstationMapDTO();
		foBusDelegate.getAllOffices(wmDTO);
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR || appDTO.getErrorCode() == ErrorCode.RECORD_NOT_FOUND || appDTO.getErrorCode() == ErrorCode.INCOMPLETE_TEST || appDTO.getErrorCode() == ErrorCode.INCORRECT_DL || appDTO.getErrorCode() == ErrorCode.MISSING_REQUIRED ) {
			if(appDTO.getErrorCode() != ErrorCode.NO_ERROR){
				searchFail = true;
				failStatus = ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode());
			}
			view = new ModelAndView("testresultsall", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("fail",searchFail).addObject("failStatus", failStatus).addObject("officeIDs", wmDTO.getOfficeIDList());
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
			view = new ModelAndView("testresultsall", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("errors", errors).addObject("officeIDs", wmDTO.getOfficeIDList());
		}
		return view;
	}
	/*
	 * This method is called to display the terminal status.
	 */
	public ModelAndView TerminalStatus(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			if(group != null) {
				String officeId = staff.getOfficeID().trim();
				WorkstationMapDTO wmDTO = new WorkstationMapDTO();
				WorkstationMap wm = new WorkstationMap();
				wm.setOfficeId(officeId);
				List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
				wmList.add(wm);
				wmDTO.setWorkstationMapList(wmList);
				foBusDelegate.getTerminalStatusByOfficeId(wmDTO);
				List<TerminalStatus> terminalStatusList = new ArrayList<TerminalStatus>();
				if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					wmList = wmDTO.getWorkstationMapList();
					for(WorkstationMap wmap: wmList) {
						TerminalStatus terminal = new TerminalStatus();
						terminal.setTerminalId(wmap.getWorkstationId());
						terminal.setTerminalStatus(Constant.TERMINAL_RESERVED_UI);
						if(wmap.getStatus().trim().equalsIgnoreCase(Constant.TERMINAL_AVAILABLE))
							terminal.setTerminalStatus(Constant.TERMINAL_AVAILABLE_UI);
						terminal.setIpAddress(wmap.getWorkstationIPAddress().trim());
						terminalStatusList.add(terminal);
					}
					view = new ModelAndView("terminalstatus").addObject("terminals", terminalStatusList).addObject("staff", staff).addObject("group", group).addObject("available", Constant.TERMINAL_AVAILABLE_UI);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
					view = new ModelAndView("terminalstatus").addObject("terminals", terminalStatusList).addObject("staff", staff).addObject("group", group).addObject("errors", errors);
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to display the test queue screen.
	 */
	public ModelAndView TestQueue(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView view = null;
			if(group != null) {
				String officeId = staff.getOfficeID().trim();
				String workstationId = request.getParameter("terminalId").trim();
				ApplicantDTO applicantDTO = new ApplicantDTO();
				List<Applicant> appList = new ArrayList<Applicant>();
				Applicant app = new Applicant();
				app.setOfficeId(officeId);
				appList.add(app);
				applicantDTO.setApplicantList(appList);
				applicantDTO.setGroup(group);
				foBusDelegate.getTestQueueData(applicantDTO);
				ApplicantModel appModel = new ApplicantModel();
				java.util.Collections.sort(applicantDTO.getApplicantList(), new ApplicantComparator());
				appModel.setApplicantList(applicantDTO.getApplicantList());
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_QUEUE_REQUEST);
				search.setWorkstationId(workstationId);
				if(applicantDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					view = new ModelAndView("testqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("wid", workstationId);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
					view = new ModelAndView("testqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("errors", errors).addObject("wid", workstationId);
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to reserve a terminal by setting the status code in the workstation map record
	 */
	public void ReserveTerminal(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		OutputStream out = null;		
		try {
			out = response.getOutputStream();
			PrintStream printStream = new PrintStream(out);
			printStream.print(false);
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to assign a terminal to the applicant by creating a session
	 */
	public void AssignTerminal(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String officeId = staff.getOfficeID().trim();
			int appId = Integer.parseInt(request.getParameter("applicationId").trim());
			String wid = request.getParameter("wid").trim();
			ApplicantDTO applicantDTO = new ApplicantDTO();
			List<Applicant> appList = new ArrayList<Applicant>();
			Applicant app = new Applicant();
			app.setApplicationId(appId);
			app.setWorkstationId(wid);
			app.setOfficeId(officeId);
			appList.add(app);
			applicantDTO.setApplicantList(appList);
			foBusDelegate.assignTerminal(applicantDTO);
			OutputStream out = null;
			try {
				out = response.getOutputStream();
			} catch (IOException e) {
				logger.error(e);
			}
			PrintStream printStream = new PrintStream(out);
			if(applicantDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				printStream.print("assigned");
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				if(applicantDTO.getErrorCode() == ErrorCode.MISSING_WORKSTATION) {
					printStream.print("This terminal has already been reserved by another user");
				} else {
					printStream.print("Error");
				}
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * Generate end of the day report.
	 */
	public ModelAndView EndOfDayReport(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();		
			if (group == null) {
				return view;
			}
			String officeId = staff.getOfficeID().trim();
			String applicationType = staff.getAppType(group);
			String queueClearedFlg = request.getParameter("queueCleared");
			if (queueClearedFlg != null && queueClearedFlg.equals(Constant.YES)) {
				view = new ModelAndView("endofdayreport").addObject("queueCleared", Constant.YES);
				return view;
			}
			String examTakingWhenClearQueueFlg = request.getParameter("examTakingWhenClearQueue");
			if (examTakingWhenClearQueueFlg == null || examTakingWhenClearQueueFlg.equals(Constant.NO)) {
				ExamDTO examDTO = new ExamDTO();
				examDTO.setOfficeId(officeId);
				examDTO.setApplicationType(applicationType);
				examDTO.setUserId(staff.getUserId());
				int errorCode1 = checkExamTaking(examDTO, officeId);
				if (errorCode1 != ErrorCode.NO_ERROR) {
					view = new ModelAndView("redirect:OutstandingReport.do?examTaking=Y");	
					return view;
				}
			}
			
			ReportDTO reportDTO = new ReportDTO();
			reportDTO.setOfficeId(officeId);
			reportDTO.setGroup(group);
			examBusDelegate.getEndOfDayReport(reportDTO);
			if(reportDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				if (examTakingWhenClearQueueFlg != null && examTakingWhenClearQueueFlg.equals(Constant.YES)) {
					view = new ModelAndView("endofdayreport").addObject("endOfDayReport", reportDTO.getEndOfDayReport())
			           .addObject("staff", staff).addObject("examTaking", Constant.YES);
				}
				else {
					view = new ModelAndView("endofdayreport").addObject("endOfDayReport", reportDTO.getEndOfDayReport())
					           .addObject("staff", staff).addObject("examTaking", Constant.NO);
				}
					       				
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(reportDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(reportDTO.getErrorCode()));
				view = new ModelAndView("endofdayreport").addObject("endOfDayReport", reportDTO.getEndOfDayReport())
				           .addObject("errors", errors).addObject("staff", staff);
			}							
			
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * Fail any outstanding exams at the end of the day
	 */
	public ModelAndView OutstandingReport(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();		
			if (group == null) {
				return view;
			}
			String officeId = staff.getOfficeID().trim();
			String applicationType = staff.getAppType(group);
			Search search = new Search();
			search.setRequestType(SearchRequestTypeConstant.EOD_REPORT);
			ApplicantDTO applicantDTO = new ApplicantDTO();
			applicantDTO.setOfficeId(officeId);
			applicantDTO.setApplicationType(applicationType);
			examBusDelegate.getIncompleteExams(applicantDTO);
			ApplicantModel appModel = new ApplicantModel();
			appModel.setApplicantList(applicantDTO.getApplicantList());
			if(applicantDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				String examTakingFlg = request.getParameter("examTaking");
				if (examTakingFlg != null && examTakingFlg.equals(Constant.YES)) {
					view = new ModelAndView("incompleteexams","Search", search).addObject("appmodel", appModel).addObject("staff", staff)
					       .addObject("examTaking", Constant.YES);
				}
				else {
					view = new ModelAndView("incompleteexams","Search", search).addObject("appmodel", appModel).addObject("staff", staff)
							.addObject("examTaking", Constant.NO);
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				view = new ModelAndView("incompleteexams","Search", search).addObject("appmodel", appModel).addObject("errors", errors).addObject("staff", staff);
			}		
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * Fail any outstanding exams at the end of the day
	 */
	public ModelAndView FailOutstandingExams(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();		
			if (group == null) {
				return view;
			}
			String officeId = staff.getOfficeID().trim();
			String applicationType = staff.getAppType(group);
			

			ExamDTO examDTO = new ExamDTO();
			examDTO.setOfficeId(officeId);
			examDTO.setApplicationType(applicationType);
			examDTO.setUserId(staff.getUserId());
			int errorCode1 = checkExamTaking(examDTO, officeId);
			if (errorCode1 != ErrorCode.NO_ERROR) {
				view = new ModelAndView("redirect:EndOfDayReport.do?examTakingWhenClearQueue=Y");
				return view;
				
			}
			int errorCode = failExams(examDTO);
			if(errorCode == ErrorCode.NO_ERROR) {
				for(Exam exam: examDTO.getExamList()) {
					gov.ca.dmv.AKT.presentation.Beans.Exam exam1 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
					exam1.setExamId(exam.getExamId());
					EaseAppDTO easeAppDTO = new EaseAppDTO();
					easeAppDTO.setExam(exam1);
					easeAppBusDelegate.sendResult(easeAppDTO);
					if(easeAppDTO.getErrorCode() != ErrorCode.NO_ERROR) {
						logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
						ApplicantModel appModel = new ApplicantModel();
						view = new ModelAndView("endofdayreport").addObject("appmodel", appModel).addObject("errors", errors).addObject("staff", staff);
					}
					else {
						ExamDTO examDTO2 = new ExamDTO();
						gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
						exam2.setExamId(easeAppDTO.getExam().getExamId());
						List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
						examList2.add(exam2);
						examDTO2.setExamList(examList2);
						int errCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
						if(errCode == ErrorCode.NO_ERROR) {
							view = new ModelAndView("redirect:EndOfDayReport.do?queueCleared=Y");
						}
						else {
							logger.error(ErrorCode.ERROR_MESSAGE(errCode));
							List<String> errors = new ArrayList<String>();
							errors.add(ErrorCode.ERROR_MESSAGE(errCode));
							ApplicantModel appModel = new ApplicantModel();
							view = new ModelAndView("endofdayreport").addObject("appmodel", appModel).addObject("errors", errors).addObject("staff", staff);
						}
					}
				}
			}
			else {
				List<String> errors = new ArrayList<String>();
				if(errorCode == ErrorCode.MISSING_EXAMS) {
					errors.add("All Exams Cleared");
				} else {
					errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
				}
				ApplicantModel appModel = new ApplicantModel();
				view = new ModelAndView("endofdayreport").addObject("appmodel", appModel).addObject("errors", errors).addObject("staff", staff);
			}	    
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private int checkExamTaking(ExamDTO examDTO, String officeId) {
		int retVal = 0;
		WorkstationMapDTO wmDTO = new WorkstationMapDTO();
		WorkstationMap wm = new WorkstationMap();
		wm.setOfficeId(officeId);
		List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
		wmList.add(wm);
		wmDTO.setWorkstationMapList(wmList);
		foBusDelegate.getTerminalStatusByOfficeId(wmDTO);
		if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			wmList = wmDTO.getWorkstationMapList();
			for(WorkstationMap wmap: wmList) {
				if(wmap.getStatus().trim().equalsIgnoreCase(Constant.TERMINAL_TESTING)) {
					retVal = ErrorCode.TEST_IS_TAKING;
					break;
				}				
			}			
		}
		return retVal;
	}	
	
	public ModelAndView FailedToAuthenticate(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String appType = staff.getAppType(group);
			
			FailedYOBDTO failedYOBDTO = new FailedYOBDTO();
			String officeId = staff.getOfficeID().trim();
			failedYOBDTO.setOfficeId(officeId);
			sessionBusDelegate.getFailedYOBList(failedYOBDTO, appType);
			ModelAndView modelView = null;
			Search search = new Search();
			search.setRequestType(SearchRequestTypeConstant.FAIL_TO_AUTHENTICATE_REQUEST);	
			if(failedYOBDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				List<Applicant> applicantList = failedYOBDTO.getApplicantList();
				List<SubYOBLockout> subYOBLockoutList = new ArrayList<SubYOBLockout>();
				if(applicantList != null && applicantList.size() > Constant.ZERO) {
					for(Applicant app: applicantList) {
						SubYOBLockout yobLockoutModel = new SubYOBLockout();
						yobLockoutModel.setApplicationId(app.getApplicationId());
						yobLockoutModel.setWorkstationId(app.getWorkstationId());
						yobLockoutModel.setDlNumber(app.getDlNumber());
						yobLockoutModel.setFirstName(app.getFirstName());
						yobLockoutModel.setLastName(app.getLastName());
						yobLockoutModel.setSessionId(app.getSessionId());
						subYOBLockoutList.add(yobLockoutModel);
					}
				}
				modelView = new ModelAndView("failedtoauthenticate", "Search", search).addObject("failedtoauthenticatelist", subYOBLockoutList).addObject("staff", staff);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(failedYOBDTO.getErrorCode()));
				List<SubYOBLockout> subYOBLockoutList = new ArrayList<SubYOBLockout>();
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(failedYOBDTO.getErrorCode()));
				modelView = new ModelAndView("failedtoauthenticate", "Search", search).addObject("failedtoauthenticatelist", subYOBLockoutList).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public void ResetYOB(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHTTP) {
		try {
			SessionDTO sessionDTO = new SessionDTO();
			Session session = new Session();
			int sessionId = Integer.parseInt(request.getParameter("sessionId").trim());
			int appId = Integer.parseInt(request.getParameter("appId").trim());
			session.setSessionId(sessionId);
			sessionDTO.setSession(session);
			sessionBusDelegate.overrideYOBValidation(sessionDTO);
			boolean isManuallyAssigned = foBusDelegate.isApplicantManuallyAssignedByAppId(appId);
			
			OutputStream out = null;
			try {
				out = response.getOutputStream();
			} catch (IOException e) {
				logger.error(e);
			}
			PrintStream printStream = new PrintStream(out);
			if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				if (isManuallyAssigned) {
					printStream.print("unlocked-toAssignTerminal");
				}
				else {
					printStream.print("unlocked");
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
				printStream.print("Error");
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}		
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This method is called to view the active sessions
	 */
	public ModelAndView ActiveSessions(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();		
			if (group == null) {
				return modelView;
			}
			String officeId = staff.getOfficeID().trim();
			String applicationType = staff.getAppType(group);
			String terminateSessionSuccess = request.getParameter("terminateSessionSuccess");
			String terminateAllSessionSuccess = request.getParameter("terminateAllSessionSuccess");
			
			String returnStatus="";
			if(terminateSessionSuccess != null){
				returnStatus="Session is Terminated";
			}
			else if(terminateAllSessionSuccess != null){
				returnStatus="All sessions have been terminated";
			}
			Search search = new Search();
			search.setRequestType(SearchRequestTypeConstant.VIEW_ACITVE_SESSIONS);
			ApplicantDTO applicantDTO = new ApplicantDTO();
			applicantDTO.setOfficeId(officeId);
			applicantDTO.setApplicationType(applicationType);
			sessionBusDelegate.getActiveExams(applicantDTO);
			ApplicantModel terminateSessionModel = new ApplicantModel();
			if(applicantDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				terminateSessionModel.setApplicantList(applicantDTO.getApplicantList());
				if (returnStatus.length()>0) {
					modelView = new ModelAndView("activesessionlist", "Search", search).addObject("terminatesessionmodel", terminateSessionModel)
					.addObject("staff", staff).addObject("terminateSessionSuccess", true).addObject("returnStatus", returnStatus);
				}			
				else {
					modelView = new ModelAndView("activesessionlist", "Search", search).addObject("terminatesessionmodel", terminateSessionModel)
						.addObject("staff", staff).addObject("terminateSessionSuccess", false);
				}
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				modelView = new ModelAndView("activesessionlist", "Search", search).addObject("terminatesessionmodel", terminateSessionModel).addObject("errors", errors).addObject("staff", staff).addObject("group", group).addObject("terminateSessionSuccess", false);
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	
	/*
	 * This method is called to terminate an active session that is in a abnormally active state
	 */
	public ModelAndView TerminateSession(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			if (group == null) {
				return modelView;
			}

			int examId = Integer.parseInt(request.getParameter("examId").trim());
			int sessionId = Integer.parseInt(request.getParameter("sessionId").trim());
			Exam exam = new Exam();
			exam.setExamId(examId);
			exam.setSessionId(sessionId);
			List<Exam> examList = new ArrayList<Exam>();
			examList.add(exam);
			ExamDTO examDTO = new ExamDTO();
			examDTO.setExamList(examList);
			examDTO.setUserId(staff.getUserId());
				
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.terminateActiveSession(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:ActiveSessions.do?terminateSessionSuccess=Y");
			}
			else {
				ut.rollback();
				ApplicantModel terminateSessionModel = new ApplicantModel();				
				
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				modelView = new ModelAndView("activesessionlist").addObject("terminatesessionmodel", terminateSessionModel).addObject("errors", errors).addObject("staff", staff).addObject("group", group).addObject("terminateSessionSuccess", false);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	/*
	 * This method is called to terminate an active session that is in a abnormally active state
	 */
	public ModelAndView TerminateAllSessions(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();		
			if (group == null) {
				return modelView;
			}
			String officeId = staff.getOfficeID().trim();
			String applicationType = staff.getAppType(group);
			
			ApplicantDTO applicantDTO = new ApplicantDTO();
			applicantDTO.setOfficeId(officeId);
			applicantDTO.setApplicationType(applicationType);		
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.terminateAllActiveSession(applicantDTO);
			if(applicantDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:ActiveSessions.do?terminateAllSessionSuccess=Y");
			}
			else {
				ut.rollback();
				ApplicantModel terminateSessionModel = new ApplicantModel();				
				
				logger.error(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(applicantDTO.getErrorCode()));
				modelView = new ModelAndView("activesessionlist").addObject("terminatesessionmodel", terminateSessionModel).addObject("errors", errors).addObject("staff", staff).addObject("group", group).addObject("terminateSessionSuccess", false);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	private int updateExamWithEaseTstamp(ExamDTO examDTO,boolean isMessageSent) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			if(isMessageSent){
				Context context = new InitialContext();
				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
				ut.begin();
				examBusDelegate.updateExamWithEaseTstamp(examDTO);
				retVal = examDTO.getErrorCode();
				if(retVal == ErrorCode.NO_ERROR) {
					ut.commit();
				}
				else {
					ut.rollback();
					logger.error(ErrorCode.ERROR_MESSAGE(retVal));
				}
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	private int forceFailExam(ExamDTO examDTO) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.forceFailExam(examDTO);
			retVal = examDTO.getErrorCode();
			if(retVal == ErrorCode.NO_ERROR) {
				ut.commit();
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	private int failExams(ExamDTO examDTO) {
		int retVal = ErrorCode.NO_ERROR;
		try
		{			
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.failIncompleteExams(examDTO);
			retVal = examDTO.getErrorCode();
			if(retVal == ErrorCode.NO_ERROR) {
				ut.commit();
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(retVal));
			}
		}
		catch(Exception e) {
			logger.error(e);
		}
		return retVal;
	}
	
	/*
	 * This method is called to force fail an exam
	 */
	public ModelAndView ForceFail_old(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
		gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
		exam.setExamId(Integer.parseInt(request.getParameter("examId")));
		ExamDTO examDTO = new ExamDTO();
		List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = 
				new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
		examList.add(exam);
		examDTO.setExamList(examList);
		/*
		 * forceFailExam() method here is the same as failExam() method in the sequence diagram.
		 */
		ModelAndView modelView = null;
		int errorCode = forceFailExam(examDTO);
		if(errorCode == ErrorCode.NO_ERROR) {
			modelView = new ModelAndView("redirect:ActiveSessionsList.do?forceFailSuccess=Y");
//			EaseAppDTO easeAppDTO = new EaseAppDTO();
//			easeAppDTO.setExam(exam);
//			easeAppBusDelegate.sendResult(easeAppDTO);
//			if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
//				ExamDTO examDTO2 = new ExamDTO();
//				gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
//				exam2.setExamId(easeAppDTO.getExam().getExamId());
//				List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
//				examList2.add(exam2);
//				examDTO2.setExamList(examList2);
//				int errCode = updateExamWithEaseTstamp(examDTO2);
//				if(errCode == ErrorCode.NO_ERROR) {
//					modelView = new ModelAndView("redirect:ActiveSessionsList.do");
//				}
//				else {
//					logger.error(ErrorCode.ERROR_MESSAGE(errCode));
//					ForceFailModel forceFailModel = new ForceFailModel();
//					List<String> errors = new ArrayList<String>();
//					errors.add(ErrorCode.ERROR_MESSAGE(errCode));
//					modelView = new ModelAndView("forcefaillist", "ForceFail", new ForceFail()).addObject("forcefailmodel", forceFailModel).addObject("errors", errors).addObject("staff", staff);
//				}
//			}
//			else {
//				logger.error(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
//				ForceFailModel forceFailModel = new ForceFailModel();
//				List<String> errors = new ArrayList<String>();
//				errors.add(ErrorCode.ERROR_MESSAGE(easeAppDTO.getErrorCode()));
//				modelView = new ModelAndView("forcefaillist", "ForceFail", new ForceFail()).addObject("forcefailmodel", forceFailModel).addObject("errors", errors).addObject("staff", staff);
//			}
		}
		else {
			logger.error(ErrorCode.ERROR_MESSAGE(errorCode));
			ApplicantModel forceFailModel = new ApplicantModel();
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
			modelView = new ModelAndView("forcefaillist", "ForceFail", new ForceFail()).addObject("forcefailmodel", forceFailModel).addObject("errors", errors).addObject("staff", staff);
		}
		return modelView;
	}
	
	/*
	 * This method is called to force fail an exam
	 */
	public ModelAndView ForceFail(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			String workStationId = request.getParameter("workStationId").trim();
			String examType = request.getParameter("examType").trim();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setForceFailAction(Constant.FORCE_FAIL_ADD);
			examBusDelegate.publishForceFailRequest(examDTO);
			/*
			 * forceFailExam() method here is the same as failExam() method in the sequence diagram.
			 */
			ModelAndView modelView = null;
			int errorCode = forceFailExam(examDTO);
			if(errorCode == ErrorCode.NO_ERROR) {
				modelView = new ModelAndView("redirect:TestStatus.do?forceFailSuccess=Y&examId=" + examId +"&workStationId="+ workStationId +"&examType=" + examType); 
			}
			else {
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				
				logger.error(ErrorCode.ERROR_MESSAGE(errorCode));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
				modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to resume a quit exam
	 */
	public ModelAndView ResumeQuitExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			ExamDTO examDTO = new ExamDTO();
			List<Exam> examList = new ArrayList<Exam>();
			Exam exam = new Exam();
			exam.setExamId(examId);
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setUserId(staff.getUserId());
			ModelAndView modelView = null;
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.resumeQuitExam(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:TestStatus.do?quitResumeSuccess=Y&examId=" + examId);
			}
			else {
				ut.rollback();
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				
				modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	
	/*
	 * This method is called to resume a timed out exam exam
	 */
	
	public ModelAndView ResumeTimedOutExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			ExamDTO examDTO = new ExamDTO();
			List<Exam> examList = new ArrayList<Exam>();
			Exam exam = new Exam();
			exam.setExamId(examId);
			examList.add(exam);
			examDTO.setExamList(examList);
			examDTO.setUserId(staff.getUserId());
			ModelAndView modelView = null;
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.resumeTimedOutExam(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:TestStatus.do?timeoutResumeSuccess=Y&examId=" + examId);
			}
			else {				
				ut.rollback();
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				
				modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	
	/*
	 * This method is called to resume a disconnected exam
	 */
	public ModelAndView ResumeDisconnectedSession(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			Exam exam = new Exam();
			exam.setExamId(examId);
			List<Exam> examList = new ArrayList<Exam>();
			examList.add(exam);
			ExamDTO examDTO = new ExamDTO();
			examDTO.setExamList(examList);
			examDTO.setUserId(staff.getUserId());
			ModelAndView modelView = null;
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			examBusDelegate.resumeExam2(examDTO);
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:TestStatus.do?disconnectResumeSuccess=Y&examId=" + examId);
			}
			else {
				ut.rollback();
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				
				
				modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	
	/*
	 * This method is called to unpause a test by a technician
	 */
	public ModelAndView UnpauseExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String userId = staff.getUserId();
			Exam exam = new Exam();
			int examId = Integer.parseInt(request.getParameter("examId"));
			exam.setExamId(examId);
			List<Exam> examList = new ArrayList<Exam>();
			examList.add(exam);
			ExamDTO examDTO = new ExamDTO();
			examDTO.setExamList(examList);
			examDTO.setUserId(userId);
			examBusDelegate.unpauseExam(examDTO);
			ModelAndView view = null;
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				view = new ModelAndView("redirect:TestStatus.do?unPauseSuccess=Y&examId=" + examId);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				view = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}	
	/*
	 * This method is called to pause a test by a technician.
	 */
	public ModelAndView PauseExam(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String userId = staff.getUserId();
			Exam exam = new Exam();
			exam.setExamId(Integer.parseInt(request.getParameter("examId")));
			List<Exam> examList = new ArrayList<Exam>();
			examList.add(exam);
			ExamDTO examDTO = new ExamDTO();
			examDTO.setExamList(examList);
			examDTO.setUserId(userId);
			examBusDelegate.pauseExamFO(examDTO);
			ModelAndView view = null;
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				view = new ModelAndView("redirect:TestStatus.do?pauseSuccess=Y");
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				view = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	private List<Lang> getLangByGroup(String group, List<Lang> list) {
		List<Lang> list1 = new ArrayList<Lang>();
		for (Lang lang : list) {
			String langId = lang.getLangId();
			if( group.equals(Constant.OL_ADMIN_GROUP) || group.equals(Constant.OL_USER_GROUP)) {
				if( langId.equals(Constant.LANG_ENGLISH)){
					list1.add(lang);
				}
			} else if(group.equals(Constant.CHP_ADMIN_GROUP) || group.equals(Constant.CHP_USER_GROUP)){
				if( langId.equals(Constant.LANG_ENGLISH) || langId.equals(Constant.LANG_SPANISH)) {
					list1.add(lang);
				}
			}
		}
		
		if(list1.isEmpty() || list1.size() == 0 || group.equals(Constant.FO_ADMIN_GROUP) || group.equals(Constant.FO_USER_GROUP)
				|| group.equals(Constant.DS_ADMIN_GROUP) || group.equals(Constant.DS_USER_GROUP)){
			list1 = list;
		}
		return list1;
	}
	
	/*
	 * This method is called to present a list of test for print when EASE is not accessible.
	 */
	public ModelAndView PrintTestList(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			String err = request.getParameter("err");
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			ModelAndView modelView = null;
			String group = staff.validateAndReturnTechGroup();
			
			TestDTO testDTO = new TestDTO();
			testDTO.setGroup(group);
			examBusDelegate.getTestList(testDTO);
			gov.ca.dmv.AKT.presentation.Model.TestList testListModel = new gov.ca.dmv.AKT.presentation.Model.TestList();
			if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				testListModel.setLangList(getLangByGroup(group,testDTO.getLangList()));
				testListModel.setTestList(testDTO.getTestList());
				modelView = new ModelAndView("printtestlist", "PrintTest", new PrintTest()).addObject("testlistmodel", testListModel).addObject("staff", staff).addObject("group", group);
				if(err != null) {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(Integer.parseInt(err)));
					modelView = new ModelAndView("printtestlist", "PrintTest", new PrintTest()).addObject("testlistmodel", testListModel).addObject("staff", staff).addObject("errors", errors).addObject("group", group);
				}
			}
			else {
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
				logger.error(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
				modelView = new ModelAndView("printtestlist", "PrintTest", new PrintTest()).addObject("testlistmodel", testListModel).addObject("errors", errors).addObject("staff", staff).addObject("group", group);
			}		
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to present a list of test for print.
	 */
	public ModelAndView PrintTest(HttpServletRequest request, HttpServletResponse response, HttpSession session, PrintTest command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			PrintTest printTest = (PrintTest) command;
			Random rand = new Random();
			int randomNumber = rand.nextInt(9000) + 1000;
			List<PrintTestModel> printTestModelList = new ArrayList<PrintTestModel>();
			ModelAndView view = null;
			ExamDTO examDTO = null;
			String group = staff.validateAndReturnTechGroup();
			for(int count=0; count<printTest.getNumberTests(); count++){
				examDTO = new ExamDTO();
				Exam exam = new Exam();
				exam.setTestId(printTest.getTestId());
				exam.setLangId(printTest.getLangId());
				List<Exam> examList = new ArrayList<Exam>();
				examList.add(exam);
				examDTO.setExamList(examList);
				examBusDelegate.generatePrintExam(examDTO);
				PrintTestModel printTestModel = new PrintTestModel();
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					for(QuesAnsw quesAnsw: examDTO.getQuesAnswList()) {
						quesAnsw.setSignFlag(true);
						if(quesAnsw.getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
							quesAnsw.getQuestionLang().setSignImage(null);
						}
						for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: quesAnsw.getAnswerList()) {
							if(ans.getSignImage().trim().length() == Constant.ZERO) {
								ans.setSignImage(null);
								quesAnsw.setSignFlag(false);
							}
						}
					}
					
					printTestModel.setQuesAnswList(examDTO.getQuesAnswList());
					printTestModel.setTestName(examDTO.getTestName());
					printTestModel.setRandomNumber(randomNumber + count);
					printTestModel.setMaxIncorrect(examDTO.getMaxIncorrect());
					printTestModel.setLangId(printTest.getLangId());
					printTestModel.setTestId(examDTO.getTestId().trim());
					viewPrintLocaleHelper(examDTO, printTestModel);
					printTestModelList.add(printTestModel);
				}
				else {
					break;
				}
			}
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR){
				PrintTestModel printModel = new PrintTestModel();
				printModel.setLangId(printTest.getLangId());
				printModel.setTestId(examDTO.getTestId().trim());
				printModel.setRandomNumber(randomNumber);
				printModel.setMaxIncorrect(randomNumber + printTest.getNumberTests()-1);
				view = new ModelAndView("printtest").addObject("printmodel", printModel).addObject("printtestmodellist", printTestModelList).addObject("staff", staff).addObject("group", group);
			}
			else{
				if(logger.isInfoEnabled()) {
					logger.info(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					if(examDTO.getErrorCode() == ErrorCode.INCORRECT_LANG) {
						view = new ModelAndView("redirect:PrintTestList.do?err=" + examDTO.getErrorCode()).addObject("group", group);
					}
					else {
						view = new ModelAndView("printtest").addObject("printtestmodellist", new ArrayList<PrintTestModel>()).addObject("errors", errors).addObject("staff", staff).addObject("group", group);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public void AuditTestGenerated(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ExamDTO examDTO = new ExamDTO();
			Exam exam = new Exam();
			exam.setTestId(request.getParameter("testId"));
			exam.setLangId(request.getParameter("langId"));
			exam.setLastModUsername(request.getParameter("userId"));
			String startAt = request.getParameter("startAt");
			examDTO.setPrintStatus(startAt);
			String endAt = request.getParameter("endAt");
			examDTO.setResult(endAt);
			List<Exam> examList = new ArrayList<Exam>();
			examList.add(exam);
			examDTO.setExamList(examList);
			foBusDelegate.auditTestGenerated(examDTO);
			if(examDTO.getErrorCode() != ErrorCode.NO_ERROR) {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to display a list of quit exams
	 */
	public ModelAndView TestStatus(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView modelView = null;
			if(group != null) {
				String appType = staff.getAppType(group);
				String officeId = staff.getOfficeID();
				ApplicantDTO appDTO = new ApplicantDTO();
				appDTO.setOfficeId(officeId);
				appDTO.setApplicationType(appType);
				appDTO.setGroup(group);
				foBusDelegate.getAllExams(appDTO);
				ApplicantModel statusModel = new ApplicantModel();
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_STATUS);
				
				// Set return status for action
				String forceFailSuccess = request.getParameter("forceFailSuccess");			
				String quitResumeSuccess = request.getParameter("quitResumeSuccess");
				String timeoutResumeSuccess = request.getParameter("timeoutResumeSuccess");
				String disconnectResumeSuccess = request.getParameter("disconnectResumeSuccess");
				String unPauseSuccess = request.getParameter("unPauseSuccess");
				String pauseSuccess = request.getParameter("pauseSuccess");
				String examId = request.getParameter("examId");
				String workStationId = request.getParameter("workStationId");
				String examType = request.getParameter("examType");
				boolean isDS = false;
				if(staff.getOfficeType(group).trim().equals(Constant.OFFICE_TYPE_DS)){
					isDS=true;
				}
				
				if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					if (appDTO.getApplicantList() != null) {
						java.util.Collections.sort(appDTO.getApplicantList(), new ApplicantComparator());
					}
					statusModel.setApplicantList(appDTO.getApplicantList());
					String returnStatus="";
					if(forceFailSuccess!=null){
						returnStatus="The "+ examType +" for Terminal " + workStationId +" has been terminated";
					}
					else if(quitResumeSuccess!=null || timeoutResumeSuccess !=null || disconnectResumeSuccess !=null || unPauseSuccess!=null){
						returnStatus="Applicant can resume the test";
					}
					else if(pauseSuccess!=null){
						returnStatus="Applicant has been paused";
					}
					modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("staff", staff).addObject("isDS", isDS);
					if(returnStatus.length()>0){
						boolean isManuallyAssigned = false;
						if (examId != null) {
							isManuallyAssigned = foBusDelegate.isApplicantManuallyAssignedByExamId(Integer.parseInt(examId));
						}
						modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("staff", staff)
								    .addObject("actionStatus", true).addObject("returnStatus", returnStatus).addObject("isDS", isDS)
								    .addObject("isManuallyAssigned", isManuallyAssigned);										
					}		
				}
				else {
					statusModel = new ApplicantModel();
					logger.error(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
					modelView = new ModelAndView("teststatus", "Search", search).addObject("status", statusModel).addObject("errors", errors).addObject("staff", staff);
				}
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView PrintMissedQuestions(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView view = null;
			if(group != null) {
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.PRINT_MISSED_QUES_REQUEST);
				ApplicantModel appModel = new ApplicantModel();
				view = new ModelAndView("dl", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("incompTest", false).addObject("incorrDL", false);
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView ReviewMissedQuestions(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			int examId = Integer.parseInt(request.getParameter("examId").trim());
			int beginId = 0;
			if (request.getParameter("startPoint") != null) {
				beginId = Integer.parseInt(request.getParameter("startPoint").trim());
			}
			ExamDTO examDTO = new ExamDTO();
			List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Exam>();
			gov.ca.dmv.AKT.presentation.Beans.Exam exam = new gov.ca.dmv.AKT.presentation.Beans.Exam();
			exam.setExamId(examId);
			examList.add(exam);
			examDTO.setExamList(examList);
			//if(request.getParameter("fo") != null && request.getParameter("fo").trim().equalsIgnoreCase("true")) {
				examBusDelegate.generateMissedQuestions(examDTO);
			/*
			}
			else {
				examBusDelegate.getMissedQuestionsFromSessionData(examDTO);
			} */
			ReviewModel reviewModel = new ReviewModel();
			List<PrintTestModel> models = new ArrayList<PrintTestModel>();
			PrintTestModel printTestModel = new PrintTestModel();
			ModelAndView modelView = null;
			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				for(gov.ca.dmv.AKT.presentation.Beans.QuesAnsw quesAnsw: examDTO.getQuesAnswList()) {
					quesAnsw.setSignFlag(true);
					if(quesAnsw.getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
						quesAnsw.getQuestionLang().setSignImage(null);
					}
					for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: quesAnsw.getAnswerList()) {
						if(ans.getSignImage().trim().length() == Constant.ZERO) {
							ans.setSignImage(null);
							quesAnsw.setSignFlag(false);
						}
					}
				}
				reviewModel.setQuesAnswList(examDTO.getQuesAnswList());
				printTestModel.setQuesAnswList(examDTO.getQuesAnswList());
				reviewModel.setExamId(examId);
				if(request.getParameter("fo") != null && request.getParameter("fo").trim().equalsIgnoreCase("true")) {
					IDMVStaff staff = (IDMVStaff) examBusDelegate.getDMVStaff(session); 
					setPrintModelWithInternationalizedText(printTestModel, examDTO);
					models.add(printTestModel);
					modelView = new ModelAndView("printtest2").addObject("printtestmodels", models).addObject("staff", staff).addObject("review", true);
				}
				else {
					String langId = (String)request.getSession().getAttribute("langIdCode");
					modelView = new ModelAndView("review", "Exam", new Exam()).addObject("reviewmodel", reviewModel).addObject("lang", langId);
					if (beginId + 2 <= examDTO.getQuesAnswList().size()) {
						modelView.addObject("begin", beginId);
					}
					else {
						modelView.addObject("begin", beginId).addObject("last", true); 
					}
				}
			}
			else if (examDTO.getErrorCode() == ErrorCode.NO_MISSING_QUESTIONS){
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				if(request.getParameter("fo") != null && request.getParameter("fo").trim().equalsIgnoreCase("true")) {
					IDMVStaff staff = (IDMVStaff)examBusDelegate.getDMVStaff(session);
					setPrintModelWithInternationalizedText(printTestModel, examDTO);
					models.add(printTestModel);
					modelView = new ModelAndView("printtest2").addObject("printtestmodels", models).addObject("staff", staff).addObject("errors", errors).addObject("review", true);
				}
				else {
					modelView = new ModelAndView("redirect:/session/EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
				}
			}
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private void setPrintModelWithInternationalizedText(PrintTestModel printTestModel, ExamDTO examDTO) {
		ReloadableResourceBundleMessageSource res = new ReloadableResourceBundleMessageSource();
		res.setBasename(Constant.BASE_NAME);
		Locale loc = new Locale(examDTO.getProgLangCode());
		printTestModel.setInstruction8(res.getMessage("print.instruction.message8", null, loc));
		printTestModel.setInstruction9(res.getMessage("print.instruction.message9", null, loc));
		printTestModel.setInstruction10(res.getMessage("print.instruction.message10", null, loc));
		printTestModel.setInstruction11(res.getMessage("print.instruction.message11", null, loc));
	}
	
	public ModelAndView TestResults(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView view = null;
			if(group != null) {
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_RESULTS);
				ApplicantModel appModel = new ApplicantModel();
				view = new ModelAndView("testresults", "Search", search).addObject("staff", staff).addObject("appmodel", appModel);
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView TestResultsAll(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView view = null;
			if(group != null) {
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.TEST_RESULTS_ALL_OFFICES);
				ApplicantModel appModel = new ApplicantModel();
				WorkstationMapDTO wmDTO = new WorkstationMapDTO();
				foBusDelegate.getAllOffices(wmDTO);			
				view = new ModelAndView("testresultsall", "Search", search).addObject("staff", staff).addObject("appmodel", appModel).addObject("officeIDs", wmDTO.getOfficeIDList());
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	/*
	 * This method is called to generate reports for records that did not get updated at EASE end
	 */
	public ModelAndView ExceptionReport(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String officeId = staff.getOfficeID();
			if(group != null) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					ApplicantDTO appDTO = new ApplicantDTO();
					appDTO.setOfficeId(officeId);
					examBusDelegate.generateExceptionRep(appDTO);
					ExceptionReport repModel = new ExceptionReport();
					if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						repModel.setExceptionApplicantList(appDTO.getExceptionApplicantList());
						view = new ModelAndView("exceptionreport").addObject("repmodel", repModel).addObject("staff", staff).addObject("group", group);
					}
					else {
						List<String> errors = new ArrayList<String>();
						if( appDTO.getErrorCode() == ErrorCode.MISSING_VAULT) {
							errors.add(ErrorCode.ERROR_MESSAGE(ErrorCode.RECORD_NOT_FOUND));
						} else {
							errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
						}
						view = new ModelAndView("exceptionreport").addObject("repmodel", repModel).addObject("staff", staff).addObject("group", group).addObject("errors", errors);
					}
				}
				else {
					Integer sysId = null;
					if(request.getParameter("sysId") != null) {
						sysId = Integer.parseInt(request.getParameter("sysId").trim());
					}
					ApplicantDTO appDTO = new ApplicantDTO();
					appDTO.setSysId(sysId);
					examBusDelegate.updateExceptionRep(appDTO);
					if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						view = new ModelAndView("redirect:ExceptionReport.do");
					}
					else {
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
						view = new ModelAndView("exceptionreport").addObject("repmodel", new ExceptionReport()).addObject("staff", staff).addObject("group", group).addObject("errors", errors);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to present a list of test for print.
	 */
	public ModelAndView PrintTestQueue(HttpServletRequest request, HttpServletResponse response, HttpSession session, Search command) {
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			ModelAndView view = null;
			String group = staff.validateAndReturnTechGroup();
			if(group != null) {
				String officeId = staff.getOfficeID().trim();
				ApplicantDTO appDTO = new ApplicantDTO();
				List<Applicant> appList = new ArrayList<Applicant>();
				Applicant app = new Applicant();
				app.setOfficeId(officeId);
				appList.add(app);
				appDTO.setApplicantList(appList);
				appDTO.setGroup(group);
				foBusDelegate.getPrintTestQueue(appDTO);
				ApplicantModel appModel = new ApplicantModel();
				java.util.Collections.sort(appDTO.getApplicantList(), new ApplicantComparator());
				appModel.setApplicantList(appDTO.getApplicantList());
				Search search = new Search();
				search.setRequestType(SearchRequestTypeConstant.PRINT_TEST_QUEUE_REQUEST);
				if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					view = new ModelAndView("printtestqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff);
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(appDTO.getErrorCode()));
					view = new ModelAndView("printtestqueue", "Search", search).addObject("appmodel", appModel).addObject("staff", staff).addObject("errors", errors);
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to get the list of printable tests available to an applicant based on his DL#. 
	 */
	public ModelAndView PrintTestsAndAnswers(HttpServletRequest request, HttpServletResponse response, HttpSession session, PrintTests command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			if(group != null) {
				String dl = request.getParameter("dl").trim();
				String type = request.getParameter("type").trim();
				ExamDTO examDTO = new ExamDTO();
				Vault vault = new Vault();
				vault.setDlNumber(dl);
				examDTO.setVault(vault);
				examDTO.setPrintStatus(Constant.PRINT_TEST_STATUS);
				if(type.equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS))
					examDTO.setPrintStatus(Constant.PRINT_ANSWER_KEY_STATUS);
				foBusDelegate.getAvailableTestsForPrint(examDTO);
				PrintTests pCmnd = new PrintTests();
				PrintTestsModel model = new PrintTestsModel();
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					pCmnd.setExamTestLangList(examDTO.getExamTestLangList());
					pCmnd.setAnswerKey(true);
					String back = "PrintTestsAndAnswers.do?dl=" + dl + "&type=" + type;
					pCmnd.setBack(back);
					model.setVault(examDTO.getVault());
					view = new ModelAndView("printtestsforans", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff);
					if(type.equalsIgnoreCase(Constant.PRINT_TEST_STATUS)) {
						pCmnd.setAnswerKey(false);
						pCmnd.setSelectedExamId(examDTO.getExamTestLangList().get(Constant.FIRST_ELEMENT).getExamId());
						view = new ModelAndView("printtests", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff);
					}
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					view = new ModelAndView("printtestsforans", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff).addObject("errors", errors);
					if(type.equalsIgnoreCase(Constant.PRINT_TEST_STATUS)) {
						view = new ModelAndView("printtests", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff).addObject("errors", errors);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView UpdateScore(HttpServletRequest request, HttpServletResponse response, HttpSession session, PrintTests command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String userId = staff.getUserId();
			if(group != null) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					String dl = request.getParameter("dl").trim();
					view = updateScoreDisplay(dl, staff);
				}
				else {
					PrintTests ptCommand = (PrintTests) command;
					view = submitUpdatedScore(ptCommand, userId, group, staff);
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	private ModelAndView updateScoreDisplay(String dl, IDMVStaff staff) {
		ModelAndView view;
		ExamDTO examDTO = new ExamDTO();
		Vault vault = new Vault();
		vault.setDlNumber(dl);
		examDTO.setVault(vault);
		foBusDelegate.getTestsToUpdateScore(examDTO);
		PrintTests ptCommand = new PrintTests();
		ptCommand.setDl(dl);
		PrintTestsModel model = new PrintTestsModel();
		if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			ptCommand.setExamTestLangList(examDTO.getExamTestLangList());
			model.setVault(examDTO.getVault());
			view = new ModelAndView("updatescore", "PrintTests", ptCommand).addObject("model", model).addObject("staff", staff);
		}
		else {
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			view = new ModelAndView("updatescore", "PrintTests", ptCommand).addObject("model", model).addObject("staff", staff).addObject("errors", errors);
		}
		return view;
	}
	
	private ModelAndView submitUpdatedScore(PrintTests command, String userId, String group, IDMVStaff staff) {
		ModelAndView view = null;
		int errorCode = ErrorCode.NO_ERROR;
		List<ExamTestLang> updatedList = new ArrayList<ExamTestLang>();
		for(ExamTestLang etl: command.getExamTestLangList()) {
			if(!etl.isCompleted() && !etl.isDisabled() && !etl.getScore().equals("")) {
				updatedList.add(etl);
			}
		}
		ExamDTO examDTO = new ExamDTO();
		examDTO.setExamTestLangList(updatedList);
		examDTO.setUserId(userId);
		if(group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			examDTO.setApplicationType(Constant.APP_TYPE_OL);
		}
		
		foBusDelegate.updateScore(examDTO, group, this);
		view = updateScoreDisplay(command.getDl(), staff);
		errorCode = examDTO.getErrorCode();
		if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			if(group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.FO_USER_GROUP)) {
				//
				// comment this block of code for Defect 240.  Moved it to a callback function to be used in 
				// foBusDelegate.updateScore
				//				
				
//				for(Exam exam: examDTO.getExamList()) {
//					EaseAppDTO easeAppDTO = new EaseAppDTO();
//					easeAppDTO.setExam(exam);
//					easeAppBusDelegate.sendResult(easeAppDTO);
//					errorCode = easeAppDTO.getErrorCode();
//					if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
//						ExamDTO examDTO2 = new ExamDTO();
//						Exam exam2 = new Exam();
//						exam2.setExamId(exam.getExamId());
//						List<Exam> examList = new ArrayList<Exam>();
//						examList.add(exam2);
//						examDTO2.setExamList(examList);
//						errorCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
//					}
//					if(errorCode != ErrorCode.NO_ERROR) {
//						List<String> errors = new ArrayList<String>();
//						errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
//						view.addObject("errors", errors); 
//					}
//				}
			}
		}
		else {
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
			view.addObject("errors", errors); 
		}
		return view;
	}
	
	/*
	 * callback function
	 */
	public void sendExamInfoToEase(ExamDTO examDTO, Exam exam, String group) {
		int errorCode = ErrorCode.NO_ERROR;

		if(group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.FO_USER_GROUP)) {
				EaseAppDTO easeAppDTO = new EaseAppDTO();
				easeAppDTO.setExam(exam);
				easeAppBusDelegate.sendResult(easeAppDTO);
				if(easeAppDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					ExamDTO examDTO2 = new ExamDTO();
					Exam exam2 = new Exam();
					exam2.setExamId(exam.getExamId());
					List<Exam> examList = new ArrayList<Exam>();
					examList.add(exam2);
					examDTO2.setExamList(examList);
					errorCode = updateExamWithEaseTstamp(examDTO2,easeAppDTO.isMessageSent());
				}
				if(errorCode != ErrorCode.NO_ERROR) {
					examDTO.setErrorCode(errorCode);
				}
		}
	}
	
	/*
	 * This method is called to get the list of printable tests available to an applicant based on his DL#. 
	 */
	public ModelAndView PrintFinishedTests(HttpServletRequest request, HttpServletResponse response, HttpSession session, PrintTests command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String appType = staff.getAppType(group);
			PrintTests printTests = (PrintTests)command;
			if (printTests.getOfficeId() == null) {
				printTests.setOfficeId(staff.getOfficeID());
			}
 			if(group != null) {
				String dl = request.getParameter("dl")==null? null: request.getParameter("dl").trim();
				String lastName = request.getParameter("lastName")==null? null: request.getParameter("lastName").trim();
				ExamDTO examDTO = new ExamDTO();
				Vault vault = new Vault();
				vault.setDlNumber(dl);
				vault.setApplicationLastName(lastName);
				examDTO.setVault(vault);
				examDTO.setPrintStatus(Constant.PRINT_TEST_STATUS);
				examDTO.setOfficeId(printTests.getOfficeId());
				foBusDelegate.getFinishedTestsForPrint(examDTO, appType);
				WorkstationMapDTO wmDTO = new WorkstationMapDTO();
				foBusDelegate.getAllOffices(wmDTO);	
				PrintTests pCmnd = new PrintTests();
				PrintTestsModel model = new PrintTestsModel();
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR && 
				   examDTO.getExamTestLangList() != null) {
					List<ExamTestLang> testListAmbulance= new ArrayList<ExamTestLang>();
					if(group.trim().equalsIgnoreCase(Constant.ISS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.ISS_USER_GROUP) 
							|| group.trim().equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.FO_USER_GROUP)){
						for(int i=0;i<examDTO.getExamTestLangList().size();i++){
							String ambulanceTestCheck=examDTO.getExamTestLangList().get(i).getTestId().trim();
							if(Constant.AMBULANCE_TEST_ID.equals(ambulanceTestCheck)){
								testListAmbulance.add(examDTO.getExamTestLangList().get(i));
								pCmnd.setExamTestLangList(testListAmbulance);
								pCmnd.setAnswerKey(true);
								String back = "PrintFinishedTests.do?dl=" + dl;
								pCmnd.setBack(back);
								model.setVault(examDTO.getVault());
								pCmnd.setFinishedTest(true);
							    view = new ModelAndView("printfinishedtests", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff).addObject("officeIDs", wmDTO.getOfficeIDList());
							} 	
							else {
								List<String> errors = new ArrayList<String>();
								examDTO.setErrorCode(ErrorCode.NO_MATCH_FOUND);
								errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
								view = new ModelAndView("printfinishedtests", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff).addObject("errors",errors).addObject("officeIDs", wmDTO.getOfficeIDList());
							}
						} 
					}
					else{
						pCmnd.setExamTestLangList(examDTO.getExamTestLangList());
						pCmnd.setAnswerKey(true);
						String back = "PrintFinishedTests.do?dl=" + dl;
						pCmnd.setBack(back);
						model.setVault(examDTO.getVault());
						pCmnd.setFinishedTest(true);
						view = new ModelAndView("printfinishedtests", "PrintTests", pCmnd).addObject("model", model).addObject("staff", staff).addObject("officeIDs", wmDTO.getOfficeIDList());	
					}
					if (group.equals(Constant.DS_ADMIN_GROUP) || group.equals(Constant.DS_USER_GROUP)) {
						view.addObject("ds_user", true);
					}
					else if (group.equals(Constant.OL_ADMIN_GROUP) || group.equals(Constant.OL_USER_GROUP)) {
						view.addObject("ol_user", true);
					}
					else if (group.equals(Constant.FO_ADMIN_GROUP) || group.equals(Constant.FO_USER_GROUP)) {
						view.addObject("fo_user", true);
					}
					else if (group.equals(Constant.ISS_ADMIN_GROUP) || group.equals(Constant.ISS_USER_GROUP)) {
						view.addObject("iss_user", true);
					}
					else if (group.equals(Constant.CHP_ADMIN_GROUP) || group.equals(Constant.CHP_USER_GROUP)) {
						view.addObject("chp_user", true);
					}
				}
				else {
					List<String> errors = new ArrayList<String>();
					if ((dl == null || dl.length() == 0)&(lastName == null || lastName.length() == 0)){
						view = new ModelAndView("printfinishedtests", "PrintTests", pCmnd).addObject("model", model)
											.addObject("staff", staff).addObject("officeIDs", wmDTO.getOfficeIDList());
					}
					else {
						examDTO.setErrorCode(ErrorCode.NO_MATCH_FOUND);
						errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
						view = new ModelAndView("printfinishedtests", "PrintTests", pCmnd).addObject("model", model)
											.addObject("staff", staff).addObject("errors", errors).addObject("officeIDs", wmDTO.getOfficeIDList());
					}
					
					if (group.equals(Constant.DS_ADMIN_GROUP) || group.equals(Constant.DS_USER_GROUP)) {
						view.addObject("ds_user", true);
					}
					else if (group.equals(Constant.OL_ADMIN_GROUP) || group.equals(Constant.OL_USER_GROUP)) {
						view.addObject("ol_user", true);
					}
					else if (group.equals(Constant.ISS_ADMIN_GROUP) || group.equals(Constant.ISS_USER_GROUP)) {
						view.addObject("iss_user", true);
					}
					else if (group.equals(Constant.FO_ADMIN_GROUP) || group.equals(Constant.FO_USER_GROUP)) {
							view.addObject("fo_user", true);
					}
					else if (group.equals(Constant.CHP_ADMIN_GROUP) || group.equals(Constant.CHP_USER_GROUP)) {
						view.addObject("chp_user", true);
					}
				}
			}
 			view.addObject("dl_rinput", printTests.getDl()).addObject("last_name_rinput", printTests.getLastName()).addObject("office_id_rinput", printTests.getOfficeId());
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to view/print the printable test.
	 */
	public ModelAndView ViewPrint(HttpServletRequest request, HttpServletResponse response, HttpSession session, PrintTests command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String userId = staff.getUserId();
			if(group != null) {
				String dl = request.getParameter("dl");
				String type = request.getParameter("type");
				PrintTests cmd = (PrintTests) command;
				ExamDTO examDTO = new ExamDTO();
				examDTO.setExamTestLangList(cmd.getExamTestLangList());
				examDTO.setUserId(userId);
				List<PrintTestModel> models = new ArrayList<PrintTestModel>();
				boolean reprint = false;
				String back = cmd.getBack();
				//Integer examId = cmd.getSelectedExamId();
				String examIds = "";
				for(ExamTestLang etl: cmd.getExamTestLangList()) {
					if(!cmd.isAnswerKey() && !cmd.isFinishedTest() && etl.getExamId().equals(cmd.getSelectedExamId())) {
						etl.setPrintChecked(true);
					}
					if(etl.isPrintChecked()) {
						Exam exam = new Exam();
						exam.setExamId(etl.getExamId());
						exam.setLangId(etl.getLangId());
						examIds = etl.getExamId() + "," + examIds;
						List<Exam> examList = new ArrayList<Exam>();
						examList.add(exam);
						examDTO.setExamList(examList);
						examDTO.setPrint(true);
						if(cmd.isAnswerKey()) {
							foBusDelegate.getAnswerKey(examDTO);
						}
						else if(cmd.isFinishedTest()) {
							examBusDelegate.generateFinishedTests(examDTO);
						}
						else {
							examBusDelegate.generateExam(examDTO, true);
						}
						if(examDTO.getErrorCode() != ErrorCode.NO_ERROR) {
							break;
						}
						for(QuesAnsw quesAnsw: examDTO.getQuesAnswList()) {
							quesAnsw.setSignFlag(true);
							if(quesAnsw.getQuestionLang().getSignImage().trim().length() == Constant.ZERO) {
								quesAnsw.getQuestionLang().setSignImage(null);
							}
							for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: quesAnsw.getAnswerList()) {
								if(ans.getSignImage().trim().length() == Constant.ZERO) {
									ans.setSignImage(null);
									quesAnsw.setSignFlag(false);
								}
							}
						}
						PrintTestModel printTestModel = new PrintTestModel();
						printTestModel.setQuesAnswList(examDTO.getQuesAnswList());
						printTestModel.setTestName(examDTO.getTestName());
						printTestModel.setRandomNumber(etl.getExamId());
						printTestModel.setMaxIncorrect(examDTO.getMaxIncorrect());
						printTestModel.setLangId(etl.getLangId());
						printTestModel.setTestId(examDTO.getTestId());
						printTestModel.setExamId(exam.getExamId());
						if(!cmd.isAnswerKey() && !cmd.isFinishedTest()) {
							viewPrintLocaleHelper(examDTO, printTestModel);
							if(etl.getPrintReprintValue().equalsIgnoreCase(Constant.REPRINT))
								reprint = true;
						}
						models.add(printTestModel);
					}
				}
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					for(ExamTestLang etl: cmd.getExamTestLangList()) {
						if(etl.getExamId() == models.get(Constant.ZERO).getExamId()) {
							if(etl.getPrintReprintValue() != null) {
								if(etl.getPrintReprintValue().equalsIgnoreCase(Constant.REPRINT))
									reprint = true;
							}
						}
					}
					view = new ModelAndView("printtest2").addObject("printtestmodels", models).addObject("staff", staff).addObject("reprint", reprint).addObject("back", back).addObject("examId", examIds).addObject("dlNumber",dl).addObject("type",type);
					if(cmd.isAnswerKey()) {
						view.addObject("ans", true);
					}
					else if(cmd.isFinishedTest()) {
						view.addObject("finished", true);
					}
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
					view = new ModelAndView("printtest2").addObject("printtestmodels", models).addObject("staff", staff).addObject("examId", examIds).addObject("reprint", reprint).addObject("back", back).addObject("dlNumber",dl).addObject("type",type).addObject("errors", errors);
					if(cmd.isAnswerKey()) {
						view.addObject("ans", true);
					}
					else if(cmd.isFinishedTest()) {
						view.addObject("finished", true);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	/*
	 * This is a helper method for loading the instructions based on the language applicable that needs to be displayed on the print test page.
	 */
	private void viewPrintLocaleHelper(ExamDTO examDTO,	PrintTestModel printTestModel) {
		ReloadableResourceBundleMessageSource res = new ReloadableResourceBundleMessageSource();
		res.setBasename(Constant.BASE_NAME);
		Locale loc = new Locale(examDTO.getProgLangCode());
		printTestModel.setInstruction1(res.getMessage("print.instruction.message1", null, loc));
		printTestModel.setInstruction2(res.getMessage("print.instruction.message2", null, loc));
		printTestModel.setInstruction3(res.getMessage("print.instruction.message3", null, loc));
		printTestModel.setInstruction4(res.getMessage("print.instruction.message4", null, loc));
		printTestModel.setInstruction5(res.getMessage("print.instruction.message5", null, loc));
		printTestModel.setInstruction6(res.getMessage("print.instruction.message6", null, loc));
		printTestModel.setInstruction7(res.getMessage("print.instruction.message7", null, loc));
		printTestModel.setInstruction11(res.getMessage("print.instruction.message11", null, loc));
	}
	
	/*
	 * This is an ajax call to change the print status in the completion reason code field for the exam record being printed.
	 */
	public void ChangeCompletionReasonCode(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		try {
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String userId = staff.getUserId();
			Integer examId = null;
			ExamDTO examDTO = new ExamDTO();
			List<Exam> examList = new ArrayList<Exam>();
			Scanner sc = new Scanner(request.getParameter("examId").trim());
			sc.useDelimiter(",");
			while(sc.hasNext()) {
				examId = Integer.parseInt(sc.next());
				Exam exam = new Exam();
				exam.setExamId(examId);
				examList.add(exam);
			}
			examDTO.setExamList(examList);
			examDTO.setUserId(userId);
			foBusDelegate.changeCompletionReasonCode(examDTO);
			if(examDTO.getErrorCode() != ErrorCode.NO_ERROR) {
				logger.error(ErrorCode.ERROR_MESSAGE(examDTO.getErrorCode()));
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to present the enter applicant information screen.
	 */
	public ModelAndView ApplicantInfo(HttpServletRequest request, HttpServletResponse response, HttpSession session, ApplicantInformation command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			if(group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP) || group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || 
					group.equalsIgnoreCase(Constant.CHP_USER_GROUP) || group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP) || 
					group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.FO_USER_GROUP)) {
				ApplicantInformation appInfoView = new ApplicantInformation();
				view = applicantInfoViewHelper(staff, group, appInfoView);
				boolean showAudio = true;
				boolean showVideo = true;
				if(group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CHP_USER_GROUP) || group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || 
						group.equalsIgnoreCase(Constant.OL_USER_GROUP) || group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP) ||
						group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.FO_USER_GROUP)){
					showVideo = false;
				}
				if(group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CHP_USER_GROUP) || group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || 
						group.equalsIgnoreCase(Constant.OL_USER_GROUP) || group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
					showAudio = false;
				}
				if(request.getMethod().equalsIgnoreCase("GET")) {
					view.addObject("applicantInformation", appInfoView).addObject("showAudio",showAudio).addObject("showVideo",showVideo);
				} else {
					ApplicantInformation appInfo = (ApplicantInformation) command;
					appInfo.getCheckedExamHistList();
					validate(appInfo);
					if(errors.hasErrors()) {
						List<String> errs = new ArrayList<String>();
						errs.add(ErrorCode.ERROR_MESSAGE(ErrorCode.MISSING_REQUIRED));
						view.addObject("applicantInformation", errors.getTarget()).addAllObjects(errors.getModel()).addObject("errors", errs);
					} else {
						if(submitApplicantInfo(staff, appInfo)) {
							view.addObject("applicantInformation", appInfoView).addObject("success", true).addObject("showAudio",showAudio).addObject("showVideo",showVideo);
						} else {
							view.addObject("applicantInformation", appInfoView).addObject("success", false).addObject("showAudio",showAudio).addObject("showVideo",showVideo);
						}
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	/*
	 * This method is called to create the view for applicant info screen.
	 */
	private ModelAndView applicantInfoViewHelper(IDMVStaff staff, String group, ApplicantInformation appInfoView) {
		ModelAndView view;
		TestDTO testDTO = new TestDTO();
		testDTO.setGroup(group);
		foBusDelegate.getAppInfo(testDTO);
		TestList model = new TestList();
		model.setHeadingBasedOnGroup(group);
		if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			model.setTestList(testDTO.getTestList());
			appInfoView.setTestListForView(model.getTestList());
			view = new ModelAndView("appinfo").addObject("model", model).addObject("staff", staff);
		}
		else {
			List<String> errors = new ArrayList<String>();
			errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
			view = new ModelAndView("appinfo").addObject("model", model).addObject("staff", staff).addObject("errors", errors);
		}
		return view;
	}

	/*
	 * This method is called to submit the information from applicant info screen.
	 */
	public boolean submitApplicantInfo(IDMVStaff staff, ApplicantInformation appInfo) {
		try {
			String group = staff.validateAndReturnTechGroup();
			//group = Constant.DS_ADMIN_GROUP;
			String officeId = staff.getOfficeID();
			String techId = staff.getTechID();
			Applicant app = new Applicant();
			app.setDlNumber(appInfo.getDl());
			app.setDob(appInfo.getDob());
			app.setFirstName(appInfo.getFirstName());
			app.setLastName(appInfo.getLastName());
			app.setTestList(appInfo.getTestList());
			app.setAudio(appInfo.isAudio());
			app.setVideo(appInfo.isVideo());
			app.setState(appInfo.getState());
			List<Applicant> appList = new ArrayList<Applicant>();
			appList.add(app);
			ApplicantDTO appDTO = new ApplicantDTO();
			appDTO.setApplicantList(appList);
			appDTO.setGroup(group);
			appDTO.setOfficeId(officeId);
			appDTO.setTechId(techId);
			foBusDelegate.submitAppInfo(appDTO,appInfo.getExamHistList()); 
			if(appDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				return true;
			}
			else {
				return false;
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
			return false;
		}
	}
	
	public ModelAndView VolumeReport(HttpServletRequest request, HttpServletResponse response, HttpSession session, DatePicker command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String officeId = staff.getOfficeID();
			if(group != null) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					view = new ModelAndView("datesforvolume", "DatePicker", new DatePicker()).addObject("staff", staff);
				}
				else {
					DatePicker dateCmd = (DatePicker) command;
					ReportDTO repDTO = new ReportDTO();
					if(!dateCmd.getFromDate().equals("") && !dateCmd.getToDate().equals("")) {
						repDTO.setFromDate(dateCmd.getFromDate());
						repDTO.setToDate(dateCmd.getToDate() + "/23/59/59");
						repDTO.setOfficeId(officeId);
						repDTO.setGroup(group);
						foBusDelegate.getVolumeReport(repDTO);
						if(repDTO.getErrorCode() == ErrorCode.NO_ERROR) {
							view = new ModelAndView("volumereport").addObject("volumes", repDTO.getVolumeList()).addObject("staff", staff);
						}
						else {
							List<String> errors = new ArrayList<String>();
							errors.add(ErrorCode.ERROR_MESSAGE(repDTO.getErrorCode()));
							view = new ModelAndView("volumereport").addObject("volumes", new ArrayList<Volume>()).addObject("staff", staff).addObject("errors", errors);
						}
					}
					else {
						List<String> errors = new ArrayList<String>();
						errors.add("Please select a date range");
						view = new ModelAndView("datesforvolume", "DatePicker", new DatePicker()).addObject("staff", staff).addObject("errors", errors);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView HistoricalReport(HttpServletRequest request, HttpServletResponse response, HttpSession session, DatePicker command) {
		try {
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			String officeId = staff.getOfficeID();
			if(group != null) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					view = new ModelAndView("datesforhistorical", "DatePicker", new DatePicker()).addObject("staff", staff);
				}
				else {
					DatePicker dateCmd = (DatePicker) command;
					ReportDTO repDTO = new ReportDTO();
					if(dateCmd.getFromDate() != null && dateCmd.getToDate() != null && dateCmd.getFromDate().length() > Constant.ZERO && dateCmd.getToDate().length() > Constant.ZERO) {
						repDTO.setFromDate(dateCmd.getFromDate());
						repDTO.setToDate(dateCmd.getToDate() + "/23/59/59");
						repDTO.setDl(dateCmd.getDl().trim());
						repDTO.setLastName(dateCmd.getLastName().trim());
						repDTO.setOfficeId(officeId);
						repDTO.setGroup(group);
						foBusDelegate.getHistoricalReport(repDTO);
						if(repDTO.getErrorCode() == ErrorCode.NO_ERROR) {
							java.util.Collections.sort(repDTO.getApplicantList(), new ApplicantComparator());
							view = new ModelAndView("historicalreport").addObject("report", repDTO.getApplicantList()).addObject("staff", staff);
						}
						else {
							List<String> errors = new ArrayList<String>();
							if( repDTO.getErrorCode() == ErrorCode.MISSING_EXAMS) {
								errors.add("Record Not Found");
							} else {
								errors.add(ErrorCode.ERROR_MESSAGE(repDTO.getErrorCode()));
							}
							view = new ModelAndView("historicalreport").addObject("report", new ArrayList<Applicant>()).addObject("staff", staff).addObject("errors", errors);
						}
					}
					else {
						List<String> errors = new ArrayList<String>();
						errors.add("Please select a date range");
						view = new ModelAndView("datesforhistorical", "DatePicker", new DatePicker()).addObject("staff", staff).addObject("errors", errors);
					}
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method here is used for transferring terminal from one office to other
	 */
	public ModelAndView TransferTerminalView(HttpServletRequest request, HttpServletResponse response, HttpSession session, TerminalStatus command) {
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)foBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
		
			if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) ) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					List<TerminalStatus> terminalStatusList = new ArrayList<TerminalStatus>();
					List<String> officeIdList = new ArrayList<String>();	
					
					boolean success=false;
					String transferTerminalSuccess = request.getParameter("transferTerminalSuccess");
					if(transferTerminalSuccess != null){
						success=true;
					}
					
					String officeId = staff.getOfficeID().trim();
					WorkstationMapDTO wmDTO = new WorkstationMapDTO();
					WorkstationMap wm = new WorkstationMap();
					wm.setOfficeId(officeId);
					List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
					wmList.add(wm);
					wmDTO.setWorkstationMapList(wmList);
					foBusDelegate.getTerminalStatusByOfficeId(wmDTO);
					
					if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						wmList = wmDTO.getWorkstationMapList();
						for(WorkstationMap wmap: wmList) {
							if(wmap.getStatus().trim().equalsIgnoreCase(Constant.TERMINAL_AVAILABLE)){
								TerminalStatus terminal = new TerminalStatus();
								terminal.setTerminalId(wmap.getWorkstationId());
								terminal.setIpAddress(wmap.getWorkstationIPAddress().trim());
								terminalStatusList.add(terminal);
							}
						}	
						officeIdList = wmDTO.getOfficeIDList();
						modelAndView = new ModelAndView("viewtransferterminal", "TerminalCommand", new TerminalStatus()).addObject("offices", officeIdList).addObject("terminals", terminalStatusList).addObject("staff", staff).addObject("success",success);
					}
					else{
						logger.error(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
						modelAndView = new ModelAndView("viewtransferterminal", "TerminalCommand", new TerminalStatus()).addObject("terminals", terminalStatusList).addObject("errors", errors).addObject("staff", staff);
					}
				}
				else{
					String officeId = staff.getOfficeID().trim();
					WorkstationMapDTO wmDTO = new WorkstationMapDTO();
					WorkstationMap wm = new WorkstationMap();
					wm.setOfficeId(officeId);
					wm.setWorkstationIPAddress(command.getIpAddress());
					List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
					wmList.add(wm);
					List<String> officeList= new ArrayList<String>();
					officeList.add(command.getOfficeId());
					wmDTO.setWorkstationMapList(wmList); 
					wmDTO.setOfficeIDList(officeList);
					
					foBusDelegate.transferTerminal(wmDTO);
					if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						modelAndView = new ModelAndView("redirect:TransferTerminalView.do?transferTerminalSuccess=Y");
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(wmDTO.getErrorCode()));
						modelAndView = new ModelAndView("viewtransferterminal", "TerminalCommand", new TerminalStatus()).addObject("errors", errors).addObject("staff", staff);						
					}
				}
			}
			return modelAndView;
		}
		catch(Exception e){
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);		
		}
		
	}
}
