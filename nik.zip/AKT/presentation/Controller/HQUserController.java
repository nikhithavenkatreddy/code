package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.AdminBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.ExamBusDelegate;
import gov.ca.dmv.AKT.comparators.CategoryComparator;
import gov.ca.dmv.AKT.comparators.HandbookComparator;
import gov.ca.dmv.AKT.comparators.QuesPassFailReportComparator;
import gov.ca.dmv.AKT.comparators.TestComparator;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSSender;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.Question;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.Test;
import gov.ca.dmv.AKT.presentation.Beans.TestPlan;
import gov.ca.dmv.AKT.presentation.Command.CreateParentQuestion;
import gov.ca.dmv.AKT.presentation.Command.CreateQuestion;
import gov.ca.dmv.AKT.presentation.Command.DatePicker;
import gov.ca.dmv.AKT.presentation.Command.HQMain;
import gov.ca.dmv.AKT.presentation.Command.ModifyParentQuestion;
import gov.ca.dmv.AKT.presentation.Command.ModifyQuestion;
import gov.ca.dmv.AKT.presentation.Command.PresentParentQuestion;
import gov.ca.dmv.AKT.presentation.Command.SearchQuestion;
import gov.ca.dmv.AKT.presentation.Command.TestCommand;
import gov.ca.dmv.AKT.presentation.Command.UpdateQuestion;
import gov.ca.dmv.AKT.presentation.DTO.CategoryDTO;
import gov.ca.dmv.AKT.presentation.DTO.CategoryQuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.HandbookRefDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesAnswDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesPassRateDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionIdDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestPlanDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestQuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.TimeLimitDTO;
import gov.ca.dmv.AKT.presentation.Model.Create;
import gov.ca.dmv.AKT.presentation.Model.CreateParent;
import gov.ca.dmv.AKT.presentation.Model.EligibleQPF;
import gov.ca.dmv.AKT.presentation.Model.ModifyParent;
import gov.ca.dmv.AKT.presentation.Model.QuesAnsw;
import gov.ca.dmv.AKT.presentation.Model.QuesRep;
import gov.ca.dmv.AKT.presentation.Model.Search;
import gov.ca.dmv.AKT.presentation.Model.SearchResult;
import gov.ca.dmv.AKT.presentation.Model.TestList;
import gov.ca.dmv.AKT.presentation.Validators.CreateParentValidator;
import gov.ca.dmv.AKT.presentation.Validators.CreateValidator;
import gov.ca.dmv.AKT.presentation.Validators.ModifyParentValidator;
import gov.ca.dmv.AKT.presentation.Validators.ModifyValidator;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;

public class HQUserController extends AKTBaseController {
	
	private AdminBusDelegate   adminBusDelegate;
	private ExamBusDelegate    examBusDelegate;
	BindingResult              errors;
	private JMSSender          jmsSender;
	private static final Logger logger = Logger.getLogger(HQUserController.class);
	
	public JMSSender getJmsSender() {
		return jmsSender;
	}

	public void setJmsSender(JMSSender jmsSender) {
		this.jmsSender = jmsSender;
	}

	public BindingResult getErrors() {
		return errors;
	}

	public void setErrors(BindingResult errors) {
		this.errors = errors;
	}

	public ExamBusDelegate getExamBusDelegate() {
		return examBusDelegate;
	}

	public void setExamBusDelegate(ExamBusDelegate examBusDelegate) {
		this.examBusDelegate = examBusDelegate;
	}

	public AdminBusDelegate getAdminBusDelegate() {
		return adminBusDelegate;
	}

	public void setAdminBusDelegate(AdminBusDelegate adminBusDelegate) {
		this.adminBusDelegate = adminBusDelegate;
	}
	
//	private ApplicantPersistence applicantPersistence;
//	private ApplicationPersistence applicationPersistence;
//	private ExamPersistence examPersistence;
//	public ExamPersistence getExamPersistence() {
//		return examPersistence;
//	}
//
//	public void setExamPersistence(ExamPersistence examPersistence) {
//		this.examPersistence = examPersistence;
//	}
//	public ApplicationPersistence getApplicationPersistence() {
//		return applicationPersistence;
//	}
//	public void setApplicationPersistence(
//			ApplicationPersistence applicationPersistence) {
//		this.applicationPersistence = applicationPersistence;
//	}
//	public ApplicantPersistence getApplicantPersistence() {
//		return applicantPersistence;
//	}
//	public void setApplicantPersistence(ApplicantPersistence applicantPersistence) {
//		this.applicantPersistence = applicantPersistence;
//	}
	
	/*
	 * The method below checks if the binding of properties in a page has any errors
	 */
	protected void bind(HttpServletRequest request, Object command)	throws Exception {
			ServletRequestDataBinder binder = createBinder(request, command);
			binder.bind(request);
			errors = binder.getBindingResult();
	}
	
	//**The method below invokes the respective validator for the fields in a page**//
	public void validate(Object command) {
		Validator[] validators = getValidators();
		if (validators != null){
			for(int index = 0; index < validators.length; index++) 
			{
				Validator validator = validators[index];
				if(validator instanceof CreateValidator) {
					if(((CreateValidator) validator).supports(command.getClass())) {
						ValidationUtils.invokeValidator(validators[index], command, errors);
					}
				}
				else if(validator instanceof ModifyValidator) {
					if(((ModifyValidator) validator).supports(command.getClass())) {
						ValidationUtils.invokeValidator(validators[index], command, errors);
					}
				} 
				else if(validator instanceof CreateParentValidator) {
					if(((CreateParentValidator) validator).supports(command.getClass())) {
						ValidationUtils.invokeValidator(validators[index], command, errors);
					}
				}
				else if(validator instanceof ModifyParentValidator) {
					if(((ModifyParentValidator) validator).supports(command.getClass())) {
						ValidationUtils.invokeValidator(validators[index], command, errors);
					}
				}
				else if(validator.supports(command.getClass())) {
					ValidationUtils.invokeValidator(validators[index], command, errors);
				}
			}
		}
	}
	
	/*
	 * The method below creates the list of errors that occurred during the binding of a property in a page and
	 * these errors will be displayed on the page as validation errors
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void saveError(HttpServletRequest request, String msg, String field) {
		List errors = (List) request.getAttribute("errors");
		if (errors == null) {
			errors = new ArrayList();
		}
		errors.add(msg);
		request.setAttribute("errors", errors);
		request.setAttribute("field", field);
	}
	
//	public ModelAndView TestMQ(HttpServletRequest request, HttpServletResponse response) {
//		/*
//		EASEObjectSent obj = new EASEObjectSent();
//		obj.setOfficeId("791");
//		obj.setApplicationId("1666");
//		obj.setDlNumber("D7491340");
//		SimpleDateFormat formatter = new SimpleDateFormat(Constant.EASE_DATE_FORMAT);
//		SimpleDateFormat formatter2 = new SimpleDateFormat(Constant.EASE_TIME_FORMAT);
//		String testDate = formatter.format(new Date());
//		String testTime = formatter2.format(new Date());
//		obj.setTestDate(testDate);
//		obj.setTestLang("en");
//		obj.setTestResult(Constant.EASE_PASS);
//		obj.setTestTime(testTime);
//		obj.setTestType("A1");
//		jmsSender.setEaseObjectSent(obj);
//		jmsSender.sendMesage();*/
//		
//		SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
//		java.util.Date birthDateUtil = null;
//		java.util.Date dlExpUtil = null;
//		java.util.Date modDate = new java.util.Date();
//		try {
//			birthDateUtil = formatter.parse("01011980");
//			dlExpUtil     = formatter.parse("01012016");
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//		java.sql.Date birthDateSql = new java.sql.Date(birthDateUtil.getTime());
//		java.sql.Date dlExpSql = new java.sql.Date(dlExpUtil.getTime());
//		for(int i=0; i<200; i++) {
//			//Vault-Begin
//			gov.ca.dmv.AKT.integration.Beans.Vault vault = new gov.ca.dmv.AKT.integration.Beans.Vault();
//			//vault.setVaultId(i+1);
//			vault.setApplicationFirstName("FIRST" + (i+1));
//			vault.setApplicationLastName("LAST" + (i+1));
//			vault.setBirthDate(birthDateSql);
//			if(i < 9)
//				vault.setDlNumber("D123450" + (i+1));
//			else if(i >= 9 && i < 99)
//				vault.setDlNumber("D12345" + (i+1));
//			else if(i == 99)
//				vault.setDlNumber("D1234600");
//			else if(i > 99 && i < 109)
//				vault.setDlNumber("D123460" + ((i+1)%100));
//			else if(i == 199)
//				vault.setDlNumber("D1234700");
//			else
//				vault.setDlNumber("D12346" + ((i+1)%100));
//			vault.setLastModUsername("MWJK");
//			vault.setLastModUserTime(modDate);
//			vault.setVaultTimestamp(modDate);
//			applicantPersistence.save(vault);
//			//Vault-End
//			
//			//Application-Begin
//			gov.ca.dmv.AKT.integration.Beans.Application app = new gov.ca.dmv.AKT.integration.Beans.Application();
//			//app.setApplicationId((i+1));
//			app.setApplicationStatusCode(" ");
//			app.setApplicationTimestamp(modDate);
//			app.setClassLicenseCode("F");
//			app.setDlExpirationDate(dlExpSql);
//			app.setEaseApplicationId(String.valueOf(i+1));
//			app.setEndorsementCode(" ");
//			app.setForceFailFlag("N");
//			app.setLastModUsername("MWJK");
//			app.setLastModUserTime(modDate);
//			app.setOfficeId("448");
//			app.setOsFlag("N");
//			app.setPauseCount("0");
//			app.setRenewalFlag("Y");
//			app.setSignTestSatisfiedFlag("N");
//			app.setTechId("TI");
//			app.setVaultId(vault.getVaultId());
//			applicationPersistence.saveApplication(app);
//			//Application-End
//			
//			//Exam-Begin
//			gov.ca.dmv.AKT.integration.Beans.Exam exam1 = new gov.ca.dmv.AKT.integration.Beans.Exam();
//			gov.ca.dmv.AKT.integration.Beans.Exam exam2 = new gov.ca.dmv.AKT.integration.Beans.Exam();
//			exam1.setApplicationId(app.getApplicationId());
//			exam2.setApplicationId(app.getApplicationId());
//			exam1.setCdlFlag("N");
//			exam2.setCdlFlag("N");
//			exam1.setCompletionReasonCode(" ");
//			exam2.setCompletionReasonCode(" ");
//			exam1.setCorrectQuestionCount(0);
//			exam2.setCorrectQuestionCount(0);
//			exam1.setEaseTestId("BK");
//			exam2.setEaseTestId("SI");
//			exam1.setEaseTimestamp(Constant.defaultDate);
//			exam2.setEaseTimestamp(Constant.defaultDate);
//			exam1.setExamEndTime(Constant.defaultDate);
//			exam2.setExamEndTime(Constant.defaultDate);
//			//exam1.setExamId((i+1));
//			//exam2.setExamId((100+i+1));
//			exam1.setExamOrder(1);
//			exam2.setExamOrder(1);
//			exam1.setExamQuestionNumber(36);
//			exam2.setExamQuestionNumber(12);
//			exam1.setExamStartTime(Constant.defaultDate);
//			exam2.setExamStartTime(Constant.defaultDate);
//			exam1.setIncorrectAnswerCount(0);
//			exam2.setIncorrectAnswerCount(0);
//			exam1.setLangId(" ");
//			exam2.setLangId(" ");
//			exam1.setLastModUsername("MWJK");
//			exam2.setLastModUsername("MWJK");
//			exam1.setLastModUserTime(modDate);
//			exam2.setLastModUserTime(modDate);
//			exam1.setMaxIncorrectNumber(6);
//			exam2.setMaxIncorrectNumber(3);
//			exam1.setOfficeId("448");
//			exam2.setOfficeId("448");
//			exam1.setOptionalTestInd("N");
//			exam2.setOptionalTestInd("N");
//			exam1.setPassFailIndicator(" ");
//			exam2.setPassFailIndicator(" ");
//			exam1.setQuestionAnsweredCount(0);
//			exam2.setQuestionAnsweredCount(0);
//			exam1.setQuickPassFailFlag(" ");
//			exam2.setQuickPassFailFlag(" ");
//			exam1.setSessionId(0);
//			exam2.setSessionId(0);
//			exam1.setSignTestFlag("N");
//			exam2.setSignTestFlag("Y");
//			exam1.setTestId("A1");
//			exam2.setTestId("R9");
//			exam1.setTestTypeCode("O");
//			exam2.setTestTypeCode("O");
//			examPersistence.save(exam1);
//			examPersistence.save(exam2);
//			//Exam-End
//			
//			//ExamHistory-Begin
//			gov.ca.dmv.AKT.integration.Beans.ExamHistory eh1 = new gov.ca.dmv.AKT.integration.Beans.ExamHistory();
//			gov.ca.dmv.AKT.integration.Beans.ExamHistory eh2 = new gov.ca.dmv.AKT.integration.Beans.ExamHistory();
//			eh1.setAktStatusIndicator(" ");
//			eh2.setAktStatusIndicator(" ");
//			eh1.setAktUpdatedTimestamp(modDate);
//			eh2.setAktUpdatedTimestamp(modDate);
//			eh1.setApplicationId(app.getApplicationId());
//			eh2.setApplicationId(app.getApplicationId());
//			eh1.setEaseReceivedTimestamp(modDate);
//			eh2.setEaseReceivedTimestamp(modDate);
//			eh1.setEaseStatusIndicator("0");
//			eh2.setEaseStatusIndicator("0");
//			eh1.setEaseTestId("BK");
//			eh2.setEaseTestId("SI");
//			eh1.setLastModusername("MWJK");
//			eh2.setLastModusername("MWJK");
//			eh1.setLastModUserTime(modDate);
//			eh2.setLastModUserTime(modDate);
//			eh1.setPastExamId(exam1.getExamId());
//			eh2.setPastExamId(exam2.getExamId());
//			examPersistence.save(eh1);
//			examPersistence.save(eh2);
//			//ExamHistory-End
//		}
//		return new ModelAndView("welcome");
//	}
		
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * This method loads the HqMainPage
	 * @return
	 */
	public ModelAndView Welcome(HttpServletRequest request, HttpServletResponse response, HttpSession session, HQMain command) {
		try{
			ModelAndView view = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnHQTechGroup();
			int sizeLists;
			List<String> optionsA = new ArrayList<String>();
			List<String> optionsB = new ArrayList<String>();
			List<String> optionsC = new ArrayList<String>();
			HQMain hqMain;
			if(group!=null){
			    hqMain=command;
				String optionA1 = "Create Test Type";
				String optionA2	= "Search and Modify Test Type";
				String optionA3 = "Create Category";
				String optionA4 = "Search And Modify Category";
				String optionA5 = "Create Handbook Section";
				String optionA6	= "Search And Modify Handbook Section";
				String optionA7 = "Generate Test";		
				optionsA.add(optionA1);
				optionsA.add(optionA2);
				optionsA.add(optionA3);
				optionsA.add(optionA4);
				optionsA.add(optionA5);
				optionsA.add(optionA6);
				optionsA.add(optionA7);
				
				String optionB1 = "Create parent Questions";
				String optionB2 = "Create Language Specific Questions";
				String optionB3= "Search  Questions";
				String optionB4= "Review Modified Questions";
				optionsB.add(optionB1);
				optionsB.add(optionB2);
				optionsB.add(optionB3);
				
				String optionC1 = "Adjust Time Limit for General Test";
				String optionC2 = "Quick Pass/Quick Fail";
				String optionC3 = "Question Pass/Fail Rate";
				optionsC.add(optionC1);
				optionsC.add(optionC2);
				optionsC.add(optionC3);
				if(request.getMethod().equalsIgnoreCase("GET")) {
					if(group.trim().equalsIgnoreCase(Constant.HQ_ADMIN_GROUP)) {
						optionsB.add(optionB4);
					}				
					if(staff.isMemberOf(Constant.HQ_USER_GROUP)) {
						 sizeLists=optionsA.size()+optionsB.size()+optionsC.size()+Constant.EIGHT;
						 view = new ModelAndView("HqMainPage","command",hqMain).addObject("staff", staff).addObject("TestMaintenanceList", optionsA).addObject("QuestionMaintenanceList", optionsB).addObject("OtherMaintenanceList", optionsC).addObject("sizeLists",sizeLists);
					}
				
					else if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP)) {
						 sizeLists=optionsA.size()+optionsB.size()+optionsC.size()+Constant.EIGHT;
						 view = new ModelAndView("HqMainPage","command",hqMain).addObject("staff", staff).addObject("group", "ADMIN").addObject("TestMaintenanceList", optionsA).addObject("QuestionMaintenanceList", optionsB).addObject("OtherMaintenanceList", optionsC).addObject("sizeLists",sizeLists);
					}
				}
				if(request.getMethod().equalsIgnoreCase("POST")) {
					hqMain=command;
					if(hqMain.getOption() == null) {
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(ErrorCode.NO_SELECTION));
						if(staff.isMemberOf(Constant.HQ_USER_GROUP)) {
						   sizeLists=optionsA.size()+optionsB.size()+optionsC.size()+Constant.EIGHT;
						   view = new ModelAndView("HqMainPage","command",hqMain).addObject("errors", errors).addObject("staff", staff).addObject("TestMaintenanceList", optionsA).addObject("QuestionMaintenanceList", optionsB).addObject("OtherMaintenanceList", optionsC).addObject("sizeLists",sizeLists);
						}
						else if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP)) {
						   sizeLists=optionsA.size()+optionsB.size()+optionsC.size()+Constant.EIGHT;
						   view = new ModelAndView("HqMainPage","command",hqMain).addObject("errors", errors).addObject("staff", staff).addObject("group", "ADMIN").addObject("TestMaintenanceList", optionsA).addObject("QuestionMaintenanceList", optionsB).addObject("OtherMaintenanceList", optionsC).addObject("sizeLists",sizeLists);
						}
					}
					else{
						String option;
						option=	hqMain.getOption().trim();
						if(option.equalsIgnoreCase(optionA1)) {
							view = new ModelAndView("redirect:CreateTestType.do");
						}
						if(option.equalsIgnoreCase(optionA2)) {
							view = new ModelAndView("redirect:SearchTestType.do");
						}
						if(option.equalsIgnoreCase(optionA3)) {
							view = new ModelAndView("redirect:CreateTestCategoryView.do");
						}
						if(option.equalsIgnoreCase(optionA4)) {
							view = new ModelAndView("redirect:SearchTestCategory.do");
						}
						if(option.equalsIgnoreCase(optionA5)) {
							view = new ModelAndView("redirect:CreateHandbookSection.do");
						}
						if(option.equalsIgnoreCase(optionA6)) {
							view = new ModelAndView("redirect:SearchHandbookSection.do");
						}
						if(option.equalsIgnoreCase(optionA7)) {
							view = new ModelAndView("redirect:../fouser/PrintTestList.do");
						}
						if(option.equalsIgnoreCase(optionB1)) {
							view = new ModelAndView("redirect:CreateParent.do");
						}
						if(option.equalsIgnoreCase(optionB2)) {
							view = new ModelAndView("redirect:Create.do");
						}
					
						if(option.equalsIgnoreCase(optionB3)) {
							view = new ModelAndView("redirect:Search.do");
						}
						if(option.equalsIgnoreCase(optionB4)) {
							view = new ModelAndView("redirect:PendingReview.do");
						}
						if(option.equalsIgnoreCase(optionC1)) {
							view = new ModelAndView("redirect:DisplayTimeLimit.do");
						}
						if(option.equalsIgnoreCase(optionC2)) {
							view = new ModelAndView("redirect:EligibleQuickPassFail.do");
						}
						if(option.equalsIgnoreCase(optionC3)) {
							view = new ModelAndView("redirect:QuestionPassRate.do");
						}
					}
				}
			}
			return view;
		}
		catch(Exception e){
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	
	}
	
	
	private CreateParent CreateParentDisplay() {
		CategoryDTO categoryDTO = new CategoryDTO();
		TestDTO     testDTO     = new TestDTO();
		CreateParent parentModel = new CreateParent();
		parentModel.setErrorCode(ErrorCode.NO_ERROR);
		adminBusDelegate.getCategoryList(categoryDTO);
		parentModel.setErrorCode(categoryDTO.getErrorCode());
		if(categoryDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			adminBusDelegate.getTestList(testDTO);
			parentModel.setErrorCode(testDTO.getErrorCode());
		}
		List<gov.ca.dmv.AKT.presentation.Beans.Category> categoryList = categoryDTO.getCategoryList();
		List<gov.ca.dmv.AKT.presentation.Beans.Test>     testList     = testDTO.getTestList();
		java.util.Collections.sort(categoryList,  new CategoryComparator());
		java.util.Collections.sort(testList,  new TestComparator());
		parentModel.setCategoryList(categoryList);
		parentModel.setTestList(testList);
		return parentModel;
	}
	
	/*
	 * This method here is used for creating the parent question and assign categories to which the question
	 * belongs to 
	 */
	public ModelAndView CreateParent(HttpServletRequest request, HttpServletResponse response, HttpSession session,	CreateParentQuestion command) {		
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					CreateParent parentModel = CreateParentDisplay();
					if(parentModel.getErrorCode() == ErrorCode.NO_ERROR) {
						modelAndView = new ModelAndView("createparent", "CreateParentQuestion", new CreateParentQuestion())
						.addObject("parentmodel", parentModel).addObject("staff", staff);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(parentModel.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(parentModel.getErrorCode()));
						modelAndView = new ModelAndView("createparent", "CreateParentQuestion", new CreateParentQuestion())
						.addObject("parentmodel", parentModel).addObject("errors", errors).addObject("staff", staff);
					}
				}
				else {
					validate(command);
					CreateParentQuestion createParent = (CreateParentQuestion) command;
					if (errors.hasErrors()) {
						String field = errors.getFieldError().getField();
						saveError(request, errors.getFieldError().getCode(), field);
						modelAndView = new ModelAndView("createparent","CreateParentQuestion",createParent)
						.addObject("parentmodel", CreateParentDisplay()).addObject("staff", staff);
					}
					else {
						QuestionDTO questionDTO = new QuestionDTO();
						Question question = createParent.createQuestion();
						Category category = new Category();
						category.setCategoryId(createParent.getCategoryId());
						List<Category> categoryList = new ArrayList<Category>();
						categoryList.add(category);
						Test test = new Test();
						test.setTestId(createParent.getTestId());
						List<Test> testList = new ArrayList<Test>();
						testList.add(test);
						questionDTO.setCategoryList(categoryList);
						questionDTO.setTestList(testList);
						questionDTO.setQuestion(question);
						try
						{
							Context context = new InitialContext();
							UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
							ut.begin();	
							adminBusDelegate.saveParentQuestion(questionDTO);
							if(questionDTO.getErrorCode() == ErrorCode.NO_ERROR)
							{
								ut.commit();
								modelAndView = new ModelAndView("redirect:ViewParent.do?questionId=" + question.getQuestionId().trim());
							}	
							else {
								ut.rollback();
								logger.error(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
								List<String> errors = new ArrayList<String>();
								errors.add(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
								modelAndView = new ModelAndView("createparent","CreateParentQuestion",createParent)
								.addObject("parentmodel", CreateParentDisplay()).addObject("errors", errors).addObject("staff", staff);						
							}
						}
						catch (Exception e)
						{
							logger.error(e);
							modelAndView = new ModelAndView("createparent","CreateParentQuestion",createParent)
							.addObject("parentmodel", CreateParentDisplay());
						}
					}
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	/*
	 * This method is called to view the parent question and its categories by question id
	 */
	public ModelAndView ViewParent(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView modelAndView = null;
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				QuestionDTO questionDTO = new QuestionDTO();
				Question question = new Question();
				question.setQuestionId(request.getParameter("questionId").trim());
				questionDTO.setQuestion(question);
				adminBusDelegate.getParentQuestion(questionDTO);
				ModifyParent parentModel = new ModifyParent();
				if(questionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					parentModel.setCategoryList(questionDTO.getCategoryList());
					parentModel.setQuestion(questionDTO.getQuestion());
					parentModel.setTestList(questionDTO.getTestList());
					PresentParentQuestion ppq = new PresentParentQuestion();
					ppq.setQuestionId(questionDTO.getQuestion().getQuestionId());
					ppq.setQuestionStatus(questionDTO.getQuestion().getQuestionStatus());
					ppq.setCategoryId(questionDTO.getCategoryList().get(Constant.FIRST_ELEMENT).getCategoryId());
					ppq.setTestId(questionDTO.getTestList().get(Constant.FIRST_ELEMENT).getTestId());
					modelAndView = new ModelAndView("viewparent", "PresentParentQuestion", ppq).addObject("parentmodel", parentModel).addObject("staff", staff);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
					modelAndView = new ModelAndView("viewparent", "PresentParentQuestion", new PresentParentQuestion()).addObject("parentmodel", parentModel).addObject("errors", errors).addObject("staff", staff);
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to present modify parent question interface
	 */
	public ModelAndView PresentModifyParent(HttpServletRequest request, HttpServletResponse response, HttpSession session, PresentParentQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			PresentParentQuestion presentParent = (PresentParentQuestion) command;
			CategoryDTO categoryDTO = new CategoryDTO();
			TestDTO testDTO = new TestDTO();
			int errorCode = ErrorCode.NO_ERROR;
			adminBusDelegate.getCategoryList(categoryDTO);
			errorCode = categoryDTO.getErrorCode();
			if(categoryDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				adminBusDelegate.getTestList(testDTO);
				errorCode = testDTO.getErrorCode();
			}
			ModifyParent parentModel = new ModifyParent();
			ModifyParentQuestion modifyParentQuestion = new ModifyParentQuestion();
			ModelAndView modelAndView = null;
			if(errorCode == ErrorCode.NO_ERROR) {
				List<Category> catList1 = categoryDTO.getCategoryList();
				List<Category> catList2 = new ArrayList<Category>();
				Category cat1 = null;
				for(Category cat2: catList1) {
					if(cat2.getCategoryId().trim().equals(presentParent.getCategoryId().trim())) {
						cat1 = cat2;
						break;
					}
				}
				catList1.remove(cat1);
				java.util.Collections.sort(catList1,  new CategoryComparator());
				catList2.add(cat1);
				catList2.addAll(catList1);
				List<Test> testList1 = testDTO.getTestList();
				List<Test> testList2 = new ArrayList<Test>();
				Test test1 = null;
				for(Test test2: testList1) {
					if(test2.getTestId().trim().equals(presentParent.getTestId().trim())) {
						test1 = test2;
						break;
					}
				}
				testList1.remove(test1);
				java.util.Collections.sort(testList1,  new TestComparator());
				testList2.add(test1);
				testList2.addAll(testList1);
				parentModel.setCategoryList(catList2);
				parentModel.setTestList(testList2);
				Question question = new Question();
				question.setQuestionId(presentParent.getQuestionId().trim());
				question.setQuestionStatus(presentParent.getQuestionStatus().trim());
				parentModel.setQuestion(question);
				modifyParentQuestion.setQuestionId(presentParent.getQuestionId().trim());
				modelAndView = new ModelAndView("modifyparent", "ModifyParentQuestion", modifyParentQuestion)
				.addObject("parentmodel", parentModel).addObject("staff", staff);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(errorCode));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
				modelAndView = new ModelAndView("modifyparent", "ModifyParentQuestion", modifyParentQuestion)
				.addObject("parentmodel", parentModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private gov.ca.dmv.AKT.presentation.Model.ModifyParent modifyParentHelper(ModifyParentQuestion modifyParent) {
		CategoryDTO categoryDTO = new CategoryDTO();
		TestDTO testDTO = new TestDTO();
		adminBusDelegate.getCategoryList(categoryDTO);
		adminBusDelegate.getTestList(testDTO);
		ModifyParent parentModel = new ModifyParent();
		parentModel.setCategoryList(categoryDTO.getCategoryList());
		parentModel.setTestList(testDTO.getTestList());
		Question question = new Question();
		question.setQuestionId(modifyParent.getQuestionId().trim());
		question.setQuestionStatus(modifyParent.getQuestionStatus().trim());
		parentModel.setQuestion(question);
		return parentModel;
	}
	
	/*
	 * This method is called to modify parent question
	 */
	public ModelAndView ModifyParent(HttpServletRequest request, HttpServletResponse response, HttpSession session, ModifyParentQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView model = null;
			validate(command);
			ModifyParentQuestion modifyParent = (ModifyParentQuestion) command;
			if (errors.hasErrors()) {
				String field = errors.getFieldError().getField();
				saveError(request, errors.getFieldError().getCode(), field);
				model = new ModelAndView("modifyparent", "ModifyParentQuestion", modifyParent)
				.addObject("parentmodel", modifyParentHelper(modifyParent)).addObject("staff", staff);
			}
			else {
				QuestionDTO questionDTO = new QuestionDTO();
				Question question = modifyParent.createQuestion();
				List<Category> categoryList = new ArrayList<Category>();
				Category category = new Category();
				category.setCategoryId(modifyParent.getCategoryId());
				categoryList.add(category);
				List<Test> testList = new ArrayList<Test>();
				Test test = new Test();
				test.setTestId(modifyParent.getTestId());
				testList.add(test);
				questionDTO.setCategoryList(categoryList);
				questionDTO.setQuestion(question);
				questionDTO.setTestList(testList);
				try
				{
					Context context = new InitialContext();
					UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
					ut.begin();
					adminBusDelegate.updateParentQuestion(questionDTO);
					if(questionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						model = new ModelAndView("redirect:ViewParent.do?questionId=" + question.getQuestionId().trim());
						ut.commit();
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(questionDTO.getErrorCode()));
						model = new ModelAndView("modifyparent", "ModifyParentQuestion", modifyParent)
						.addObject("parentmodel", modifyParentHelper(modifyParent)).addObject("errors", errors).addObject("staff", staff);
						ut.rollback();
					}
				}
				catch(Exception e)
				{
					logger.error(e);
					model = new ModelAndView("modifyparent", "ModifyParentQuestion", modifyParent)
					.addObject("parentmodel", modifyParentHelper(modifyParent));
				}
			}
			return model;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * The method below is used for loading the necessary objects in order to display the create question page
	 */
	private Create createDisplay() {
		LangDTO langDTO = new LangDTO();
		adminBusDelegate.getLangList(langDTO);
		List<gov.ca.dmv.AKT.presentation.Beans.Lang> langList = null;
		HandbookRefDTO handbookRefDTO = new HandbookRefDTO();
		QuestionIdDTO questionIdDTO = new QuestionIdDTO();
		List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList = null;
		langList = langDTO.getLangList();
		adminBusDelegate.getHandbookRefList(handbookRefDTO);
		handbookRefList = handbookRefDTO.getHandbookRefList();
		adminBusDelegate.getAllQuestionId(questionIdDTO);
		Create createModel = new Create();
		createModel.setErrorCode(questionIdDTO.getErrorCode());
		if(questionIdDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			java.util.Collections.sort(handbookRefList,  new HandbookComparator());
			java.util.Collections.sort(questionIdDTO.getQuestionIdList());
			createModel.setHandbookRefList(handbookRefList);
			createModel.setLangList(langList);
			createModel.setQuestionIdList(questionIdDTO.getQuestionIdList());
		}
		return createModel;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * @return
	 * This method is called to present the create language specific questions page.
	 */
	public ModelAndView Create(HttpServletRequest request, HttpServletResponse response, HttpSession session, CreateQuestion command) {
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					Create createModel = createDisplay();
					if(createModel.getErrorCode() == ErrorCode.NO_ERROR) {
						modelAndView = new ModelAndView("create", "CreateQuestion", new CreateQuestion())
						.addObject("createmodel", createModel).addObject("staff", staff);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(createModel.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(createModel.getErrorCode()));
						modelAndView = new ModelAndView("create", "CreateQuestion", new CreateQuestion())
						.addObject("createmodel", createModel).addObject("staff", staff);
					}
				}
				/*
				 * Validate the question and answers submitted through the create question page and save them into the
				 * database if there are no outstanding errors
				 */
				else {
					validate(command);
					CreateQuestion createQuestion = (CreateQuestion) command;
					if (errors.hasErrors()) {
						String field = errors.getFieldError().getField();
						saveError(request, errors.getFieldError().getCode(), field);
						modelAndView = new ModelAndView("create","CreateQuestion",createQuestion)
						.addObject("createmodel", createDisplay()).addObject("staff", staff);
					}
					else {
						QuesAnswDTO quesAnswDTO = new QuesAnswDTO();
						QuestionLang questionLang = createQuestion.createQuestionLang();
						List<Answer> answerList = createQuestion.createAnswerList();			
						quesAnswDTO.setQuestionLang(questionLang);
						quesAnswDTO.setAnswerList(answerList);
						try
						{
							Context context = new InitialContext();
							UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
							ut.begin();
							adminBusDelegate.saveQuestion(quesAnswDTO);
							if(quesAnswDTO.getErrorCode() == ErrorCode.NO_ERROR) {
								ut.commit();
								modelAndView = new ModelAndView("redirect:View.do?questionId=" + quesAnswDTO.getQuestionGenId());
							}
							else {
								ut.rollback();
								logger.error(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
								List<String> errors = new ArrayList<String>();
								errors.add(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
								modelAndView = new ModelAndView("create","CreateQuestion",createQuestion)
								.addObject("createmodel", createDisplay()).addObject("errors", errors).addObject("staff", staff);
							}
						}
						catch(Exception e)
						{
							logger.error(e);
							modelAndView = new ModelAndView("create","CreateQuestion",createQuestion)
							.addObject("createmodel", createDisplay());
						}
					}
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This method is called to view the question lang with answers.
	 */
	public ModelAndView View(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView modelAndView = null;
			String group = null;
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP)) {
					group = Constant.ADMIN;
				}
				String autoGenId = request.getParameter("questionId").trim();
				QuesAnswDTO quesAnswDTO = new QuesAnswDTO();
				QuestionLang questionLang = new QuestionLang();
				questionLang.setQuestionGenId(Integer.parseInt(autoGenId));
				quesAnswDTO.setQuestionLang(questionLang);
				adminBusDelegate.getQuesAnsw(quesAnswDTO);
				String err = request.getParameter("err");
				if(quesAnswDTO.getErrorCode() == ErrorCode.NO_ERROR && err == null) {
					QuesAnsw quesAnswModel = new QuesAnsw();
					quesAnswModel.setAnswerList(quesAnswDTO.getAnswerList());
					quesAnswModel.setHandbookRef(quesAnswDTO.getHandbookRef());
					quesAnswModel.setLang(quesAnswDTO.getLang());
					quesAnswModel.setQuestionLang(quesAnswDTO.getQuestionLang());
					modelAndView = new ModelAndView("view", "ModifyQuestion", new ModifyQuestion())
					.addObject("quesanswmodel", quesAnswModel).addObject("staff", staff).addObject("group", group);
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					if(err != null) {
						errors.add(err);
					}
					else {
						errors.add(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
					}
					modelAndView = new ModelAndView("view", "ModifyQuestion", new ModifyQuestion())
					.addObject("quesanswmodel", new QuesAnsw()).addObject("errors", errors).addObject("staff", staff).addObject("group", group);
				}
			}
			return modelAndView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	//This method is called to inactivate a question in all languages//
//	public ModelAndView Inactivate(HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView modelAndView = null;
//		if(request.getMethod().equalsIgnoreCase("POST")) {
//			QuestionDTO questionDTO = new QuestionDTO();
//			Question question = new Question();
//			question.setQuestionId(request.getParameter("questionId").trim());
//			questionDTO.setQuestion(question);
//			adminBusDelegate.inactivateQuestion(questionDTO);
//			modelAndView = new ModelAndView("redirect:View.do?questionId=" + request.getParameter("questionLangId").trim());
//		}
//		return modelAndView;
//	}
	
	//This method is called to activate a question in all languages//
//	public ModelAndView Activate(HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView modelAndView = null;
//		if(request.getMethod().equalsIgnoreCase("POST")) {
//			QuestionDTO questionDTO = new QuestionDTO();
//			Question question = new Question();
//			question.setQuestionId(request.getParameter("questionId").trim());
//			questionDTO.setQuestion(question);
//			adminBusDelegate.activateQuestion(questionDTO);
//			modelAndView = new ModelAndView("redirect:View.do?questionId=" + request.getParameter("questionLangId").trim());
//		}
//		return modelAndView;
//	}
		
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * @return
	 * This method is called to present the modify question page.
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView Modify(HttpServletRequest request, HttpServletResponse response, HttpSession session, ModifyQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModifyQuestion modifyQuestion = (ModifyQuestion) command;
			UpdateQuestion uq = new UpdateQuestion();
			QuesAnswDTO quesAnswDTO = new QuesAnswDTO();
			QuestionLang questionLang = new QuestionLang();
			questionLang.setQuestionGenId(Integer.parseInt(modifyQuestion.getAutoGenId()));
			quesAnswDTO.setQuestionLang(questionLang);
			ModelAndView modelView = null;
			adminBusDelegate.getQuesAnswByAutoGenId(quesAnswDTO);
			Map<String,String> listMap = new HashMap<String,String>();
			ArrayList<Map> langList = new ArrayList<Map>();
			if(quesAnswDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				uq.updateCommandWithAnswerList(quesAnswDTO.getAnswerList());
				uq.updateCommandWithQuestionLang(quesAnswDTO.getQuestionLang());
				LangDTO langDTO2 = new LangDTO();
				adminBusDelegate.getLangList(langDTO2);
				List<gov.ca.dmv.AKT.presentation.Beans.Lang> langList2 = langDTO2.getLangList();
				for(gov.ca.dmv.AKT.presentation.Beans.Lang l: langList2) {
					if(quesAnswDTO.getQuestionLang().getLangId().equals(l.getLangId())) {
						uq.setLangId(l.getLangId());
						listMap.put("langId",l.getLangId());
						listMap.put("langName",l.getLangName());
						langList.add(listMap);
						break;
					}
				}
				HandbookRefDTO handbookRefDTO = new HandbookRefDTO();
				adminBusDelegate.getHandbookRefList(handbookRefDTO);
				List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList = handbookRefDTO.getHandbookRefList();
				gov.ca.dmv.AKT.presentation.Beans.HandbookRef hb = null;
				for(gov.ca.dmv.AKT.presentation.Beans.HandbookRef h: handbookRefList) {
					if(quesAnswDTO.getQuestionLang().getHandbookRef().equals(h.getHandbookRef())
							&& quesAnswDTO.getQuestionLang().getLangId().equals(h.getLangId())) {
						//uq.setHandbookRef(h.getHandbookRef());
						hb = h;
						break;
					}
				}
				handbookRefList.remove(hb);
				java.util.Collections.sort(handbookRefList,  new HandbookComparator());
				List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList2 = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.HandbookRef>();
				handbookRefList2.add(hb);
				handbookRefList2.addAll(handbookRefList);
				Create modifyModel = new Create();
				modifyModel.setHandbookRefList(handbookRefList2);
				modifyModel.setLangList(langList2);
				modifyModel.setQuestionId(uq.getQuestionId());
				modifyModel.setQuestionGenId(Integer.parseInt(uq.getAutoGenId()));
				modelView = new ModelAndView("modifyquestion", "UpdateQuestion", uq)
				.addObject("modifymodel", modifyModel).addObject("staff", staff).addObject("langLang",langList);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getErrorCode()));
				modelView = new ModelAndView("modifyquestion", "UpdateQuestion", uq)
				.addObject("modifymodel", new Create()).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		} catch (NumberFormatException e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private gov.ca.dmv.AKT.presentation.Model.Create modifyQuestionHelper(UpdateQuestion updateQuestion) {
		LangDTO langDTO2 = new LangDTO();
		adminBusDelegate.getLangList(langDTO2);
		HandbookRefDTO handbookRefDTO = new HandbookRefDTO();
		adminBusDelegate.getHandbookRefList(handbookRefDTO);
		Create modifyModel = new Create();
		modifyModel.setHandbookRefList(handbookRefDTO.getHandbookRefList());
		modifyModel.setLangList(langDTO2.getLangList());
		modifyModel.setQuestionId(updateQuestion.getQuestionId());
		modifyModel.setQuestionGenId(Integer.parseInt(updateQuestion.getAutoGenId()));
		return modifyModel;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * @return
	 * This method is called to save the modifications made to a language specific question and its answers.
	 */
	public ModelAndView ModifyQuestion(HttpServletRequest request, HttpServletResponse response, HttpSession session, UpdateQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			validate(command);
			ModelAndView model = null;
			UpdateQuestion updateQuestion = (UpdateQuestion) command;
			if (errors.hasErrors()) {
				String field = errors.getFieldError().getField();
				saveError(request, errors.getFieldError().getCode(), field);
				model = new ModelAndView("modifyquestion","UpdateQuestion", updateQuestion).addObject("modifymodel", modifyQuestionHelper(updateQuestion)).addObject("staff", staff);
			}
			else {
				QuesAnswDTO quesAnswDTO = new QuesAnswDTO();
				quesAnswDTO.setQuestionLang(updateQuestion.createQuestionLang());
				quesAnswDTO.setAnswerList(updateQuestion.createAnswerList());
			
//				Context context = new InitialContext();
//				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
//				ut.begin();
				adminBusDelegate.updateQuestion(quesAnswDTO);
				if(quesAnswDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					model = new ModelAndView("redirect:View.do?questionId=" + quesAnswDTO.getQuestionGenId());
					//ut.commit();
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getReturnMessage().getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(quesAnswDTO.getReturnMessage().getErrorCode()));
					model = new ModelAndView("modifyquestion","UpdateQuestion", updateQuestion).addObject("modifymodel", modifyQuestionHelper(updateQuestion)).addObject("errors", errors).addObject("staff", staff);
					//ut.rollback();
				}
			}
			return model;			
		}
		catch(Exception e)
		{
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * This is method to display how the modified question may look.
	 * @return
	 */
	public ModelAndView Preview(HttpServletRequest request, HttpServletResponse response, HttpSession session, UpdateQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			validate(command);
			ModelAndView model = null;
			UpdateQuestion updateQuestion = (UpdateQuestion) command;
		
			if (errors.hasErrors()) {
				String field = errors.getFieldError().getField();
				saveError(request, errors.getFieldError().getCode(), field);
				model = new ModelAndView("modifyquestion","UpdateQuestion", updateQuestion).addObject("modifymodel", modifyQuestionHelper(updateQuestion)).addObject("staff", staff);
			}

            QuesAnsw quesAnswModel = new QuesAnsw();  
        	QuesAnswDTO quesAnswDTO = new QuesAnswDTO();
        	QuestionLang quesLang= new QuestionLang();
        	
			quesAnswModel.setSignFlag(true);
			quesAnswModel.setAudioAllowed(true);
			quesAnswModel.setVideoAllowed(true);
			quesAnswModel.setQuitAllowed(true);
			quesAnswModel.setPauseAllowed(true);
			quesAnswModel.setSkipped(false);
			
			
           if(updateQuestion.getAnswerAudio1().trim().length()==Constant.ZERO && updateQuestion.getAnswerAudio2().trim().length()==Constant.ZERO &&
              updateQuestion.getAnswerAudio3().trim().length()==Constant.ZERO && updateQuestion.getAnswerAudio4().trim().length()==Constant.ZERO &&
              updateQuestion.getQuestionAudio().trim().length()==Constant.ZERO)
			{
        	   quesAnswModel.setAudioAllowed(false);
			}
            
           
           if(updateQuestion.getAnswerSignImage1().trim().length()==Constant.ZERO &&
               updateQuestion.getAnswerSignImage2().trim().length()==Constant.ZERO && updateQuestion.getAnswerSignImage3().trim().length()==Constant.ZERO &&
               updateQuestion.getAnswerSignImage4().trim().length()==Constant.ZERO)
        	{
        	   quesAnswModel.setSignFlag(false);        	
        	}
           if(updateQuestion.getSignImage().trim().length()!=Constant.ZERO ){
        	   quesLang.setSignImage(updateQuestion.getSignImage().trim());
           }
            
           if(updateQuestion.getAnswerVideo1().trim().length()==Constant.ZERO && updateQuestion.getAnswerVideo2().trim().length()==Constant.ZERO &&
               updateQuestion.getAnswerVideo3().trim().length()==Constant.ZERO && updateQuestion.getAnswerVideo4().trim().length()==Constant.ZERO &&
               updateQuestion.getQuestionVideo().trim().length()==Constant.ZERO)
           {
        	   quesAnswModel.setVideoAllowed(false);
           }
           
           quesAnswDTO.setQuestionLang(updateQuestion.createQuestionLang());
           quesAnswDTO.setAnswerList(updateQuestion.createAnswerList());
           quesAnswModel.setAnswerList(quesAnswDTO.getAnswerList());
           quesLang.setQuestionText(updateQuestion.getQuestionText());
           quesLang.setQuestionAudio(updateQuestion.getQuestionAudio());
           quesLang.setQuestionVideo(updateQuestion.getQuestionVideo());
           quesAnswModel.setQuestionLang(quesLang);			
		
           model=new ModelAndView("previewModifiedQuestion","UpdateQuestion",updateQuestion).addObject("quesanswmodel",quesAnswModel );
           return model;
		}
		catch(Exception e){
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	 
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * This method is used to display again modified question when clicking back on preview page but is not saved.
	 * @return
	 */
	public ModelAndView PreviewModifiedDisplay(HttpServletRequest request, HttpServletResponse response, HttpSession session, UpdateQuestion command) {
		try {
			ModelAndView model = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			validate(command);
			UpdateQuestion updateQuestion = (UpdateQuestion) command;
		    model= new ModelAndView("modifyquestion","UpdateQuestion",updateQuestion).addObject("modifymodel", modifyQuestionHelper(updateQuestion)).addObject("staff", staff);
		    return model;
		}
		catch(Exception e){
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	    
	}
	public ModelAndView Search(HttpServletRequest request, HttpServletResponse response, HttpSession session, SearchQuestion command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String group = null;
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP))
				group = Constant.ADMIN;
			else if(staff.isMemberOf(Constant.HQ_USER_GROUP))
				group = Constant.USER;
			if(request.getMethod().equalsIgnoreCase("GET")) {
				return SearchGet(staff, group);
			}
			else {
				SearchQuestion search = (SearchQuestion) command;
				return SearchPost(request, session, search);
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	private ModelAndView SearchGet(IDMVStaff staff, String group) {
		try {
			LangDTO langDTO = new LangDTO();
			int errorCode = ErrorCode.NO_ERROR;
			ModelAndView modelView = null;
			adminBusDelegate.getLangList(langDTO);
			if(langDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				List<gov.ca.dmv.AKT.presentation.Beans.Lang> langList = langDTO.getLangList();
				TestDTO testDTO = new TestDTO();
				adminBusDelegate.getTestList(testDTO);
				if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					List<gov.ca.dmv.AKT.presentation.Beans.Test> testList = testDTO.getTestList();
					CategoryDTO categoryDTO = new CategoryDTO();
					adminBusDelegate.getCategoryList(categoryDTO);
					if(categoryDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						List<gov.ca.dmv.AKT.presentation.Beans.Category> categoryList = categoryDTO.getCategoryList();
						Category cat = new Category();
						cat.setCategoryName(Constant.DASHES);
						cat.setCategoryId(String.valueOf(Constant.ZERO));
						categoryList.add(cat);
						Test test = new Test();
						test.setTestId(String.valueOf(Constant.ZERO));
						test.setTestName(Constant.DASHES);
						testList.add(test);
						Search searchModel  = new Search();
						java.util.Collections.sort(categoryList,  new CategoryComparator());
						java.util.Collections.sort(testList, new TestComparator());
						searchModel.setCategoryList(categoryList);
						searchModel.setLangList(langList);
						searchModel.setTestList(testList);
						modelView = new ModelAndView("search", "SearchQuestion", new SearchQuestion())
						.addObject("searchmodel", searchModel).addObject("staff", staff).addObject("group", group);
					}
					else {
						errorCode = categoryDTO.getErrorCode();
					}
				}
				else {
					errorCode = testDTO.getErrorCode(); 
				}
			}
			else {
				errorCode = langDTO.getErrorCode();
			}
			if(errorCode != ErrorCode.NO_ERROR) {
				logger.error(ErrorCode.ERROR_MESSAGE(errorCode));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
				modelView = new ModelAndView("search", "SearchQuestion", new SearchQuestion())
				.addObject("searchmodel", new Search()).addObject("errors", errors).addObject("staff", staff).addObject("group", group);
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private ModelAndView SearchPost(HttpServletRequest request, HttpSession session, SearchQuestion search) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			SearchResult searchResultModel = new SearchResult();
			int errorCode = ErrorCode.NO_ERROR;
			if(request.getParameter("Search1") != null) {
				QuestionLangDTO questionLangDTO = new QuestionLangDTO();
				List<QuestionLang> questionLangList = new ArrayList<QuestionLang>();
				QuestionLang questionLang = new QuestionLang();
				if (search.getQuestionId() != null && search.getQuestionId().length() > 0) {
					questionLang.setQuestionLangId(search.getQuestionId().trim() + search.getLangId().trim());
				}
				else {
					questionLang.setLangId(search.getLangId().trim());
					questionLang.setQuestionText(search.getQuestionText().trim());
				}
				questionLangList.add(questionLang);
				questionLangDTO.setQuestionLangList(questionLangList);
				adminBusDelegate.findQuestions(questionLangDTO);
				if(questionLangDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					searchResultModel.setQuestionLangList(questionLangDTO.getQuestionLangList());
					searchResultModel.setSize(questionLangDTO.getQuestionLangList().size());
				}
				else {
					if(questionLangDTO.getErrorCode() == ErrorCode.NULL_QUESTION_LANG) {
						searchResultModel.setQuestionLangList(new ArrayList<QuestionLang>());
						searchResultModel.setSize(Constant.ZERO);
					}
					else {
						errorCode = questionLangDTO.getErrorCode();
					}
				}
			}
			else if(request.getParameter("Search2") != null) {
				if(!search.getCategoryId().equalsIgnoreCase(String.valueOf(Constant.ZERO))) {
					/*
					 * Only by category
					 */
					if(search.getTestId().equalsIgnoreCase(String.valueOf(Constant.ZERO))) {
						CategoryQuestionLangDTO categoryQuesDTO = new CategoryQuestionLangDTO();
						Category category = new Category();
						category.setCategoryId(search.getCategoryId());
						categoryQuesDTO.setCategory(category);
						categoryQuesDTO.setLangId(search.getLangId().trim());
						adminBusDelegate.findQuestions(categoryQuesDTO);
						if(categoryQuesDTO.getErrorCode() == ErrorCode.NO_ERROR) {
							searchResultModel.setQuestionLangList(categoryQuesDTO.getQuestionLangList());
							searchResultModel.setSize(categoryQuesDTO.getQuestionLangList().size());
						}
						else {
							if(categoryQuesDTO.getErrorCode() == ErrorCode.MISSING_QUESTIONS) {
								searchResultModel.setQuestionLangList(new ArrayList<QuestionLang>());
								searchResultModel.setSize(Constant.ZERO);
							}
							else {
								errorCode = categoryQuesDTO.getErrorCode();
							}
						}
					}
					/*
					 * Both by test and category 
					 */
					else {
						TestQuestionDTO tqlDTO = new TestQuestionDTO();
						Test test = new Test();
						test.setTestId(search.getTestId());
						tqlDTO.setTest(test);
						Category cat = new Category();
						cat.setCategoryId(search.getCategoryId());
						tqlDTO.setCategory(cat);
						tqlDTO.setLangId(search.getLangId().trim());
						adminBusDelegate.findQuestions2(tqlDTO);
						if(tqlDTO.getErrorCode() == ErrorCode.NO_ERROR) {
							searchResultModel.setQuestionLangList(tqlDTO.getQuestionLangList());
							searchResultModel.setSize(tqlDTO.getQuestionLangList().size());
						}
						else {
							if(tqlDTO.getErrorCode() == ErrorCode.MISSING_QUESTIONS) {
								searchResultModel.setQuestionLangList(new ArrayList<QuestionLang>());
								searchResultModel.setSize(Constant.ZERO);
							}
							else {
								errorCode = tqlDTO.getErrorCode();
							}
						}
					}
				}
				/*
				 * Only by test
				 */
				else {
					TestQuestionDTO tqlDTO = new TestQuestionDTO();
					Test test = new Test();
					test.setTestId(search.getTestId());
					tqlDTO.setTest(test);
					tqlDTO.setLangId(search.getLangId().trim());
					adminBusDelegate.findQuestions(tqlDTO);
					if(tqlDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						searchResultModel.setQuestionLangList(tqlDTO.getQuestionLangList());
						searchResultModel.setSize(tqlDTO.getQuestionLangList().size());
					}
					else {
						if(tqlDTO.getErrorCode() == ErrorCode.MISSING_QUESTIONS) {
							searchResultModel.setQuestionLangList(new ArrayList<QuestionLang>());
							searchResultModel.setSize(Constant.ZERO);
						}
						else {
							errorCode = tqlDTO.getErrorCode();
						}
					}
				}
			}
			ModelAndView modelView = null;
			if(errorCode == ErrorCode.NO_ERROR) {
				modelView = new ModelAndView("searchresult").addObject("searchresultmodel", searchResultModel).addObject("staff", staff);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(errorCode));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(errorCode));
				modelView = new ModelAndView("search", "SearchQuestion", new SearchQuestion())
				.addObject("searchmodel", new Search()).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to get a list of eligible quick pass fail.
	 */
	public ModelAndView EligibleQuickPassFail(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestDTO command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			TestDTO testDTO = new TestDTO();
			List<String> success = new ArrayList<String>();
			if(request.getParameter("success")!=null){
				success.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
			}
			examBusDelegate.getEligibleQPFTestList(testDTO);
			
			ModelAndView view = null;
			EligibleQPF qpfModel = new EligibleQPF();
			if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				qpfModel.setTestList(testDTO.getTestList());
				view = new ModelAndView("qpf", "TestDTO", testDTO).addObject("qpfmodel", qpfModel).addObject("success",success)
						.addObject("staff", staff);
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
				view = new ModelAndView("qpf", "TestDTO", testDTO).addObject("qpfmodel", qpfModel)
						.addObject("staff", staff).addObject("errors", errors);
			}
			
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method is called to update a list of eligible quick pass fail.
	 */
	public ModelAndView UpdateQuickPassFail(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestDTO command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			TestDTO testDTONew = (TestDTO)command;
			Map<String, Boolean> indMap = new HashMap<String, Boolean>();
			for (Test test1: testDTONew.getTestList()) {
				indMap.put(test1.getTestId().trim() + "Pass", test1.isQuickPassInd());
				indMap.put(test1.getTestId().trim() + "Fail", test1.isQuickFailInd());			
			}
			TestDTO testDTO = new TestDTO();
			examBusDelegate.getEligibleQPFTestList(testDTO);
			
			// Set the right indicator for each test from the input.
			for (Test test: testDTO.getTestList()) {
				test.setQuickPassInd(indMap.get(test.getTestId().trim() + "Pass"));
				test.setQuickFailInd(indMap.get(test.getTestId().trim() + "Fail"));				
			}
			
			ModelAndView view = null;
			try
			{
				Context context = new InitialContext();
				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
				ut.begin();
				examBusDelegate.submitQPFChoices(testDTO);
				if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					ut.commit();
					view = new ModelAndView("redirect:EligibleQuickPassFail.do").addObject("success",true);
				}
				else {
					ut.rollback();
					logger.error(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
					EligibleQPF qpfModel = new EligibleQPF();
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
					view = new ModelAndView("qpf", "TestDTO", testDTO).addObject("qpfmodel", qpfModel)
							.addObject("errors", errors).addObject("staff", staff).addObject("group", group);
				}
			}
			catch(Exception e) {
				logger.error(e);
				EligibleQPF qpfModel = new EligibleQPF();
				view = new ModelAndView("qpf", "TestDTO", testDTO).addObject("qpfmodel", qpfModel)
						.addObject("staff", staff).addObject("group", group);
			}

			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView DisplayTestListForPassRate(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestPlanDTO command) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(request.getMethod().equalsIgnoreCase("GET")) {
				TestDTO testDTO = new TestDTO();
				adminBusDelegate.getTestList(testDTO);
				List<Test> testList = testDTO.getTestList();
				TestList testListModel = new TestList();
				TestPlanDTO testPlanDTO = new TestPlanDTO();
				testPlanDTO.setTest(new Test());
				if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					testListModel.setTestList(testList);
					modelView = new ModelAndView("passrate", "testPlanDTO", testPlanDTO).addObject("testlistmodel", testListModel)
							.addObject("staff", staff);
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
					modelView = new ModelAndView("passrate", "testPlanDTO", testPlanDTO).addObject("testlistmodel", testListModel)
							.addObject("staff", staff).addObject("errors", errors);
				}
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView DisplayPassRate(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestPlanDTO command) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(request.getMethod().equalsIgnoreCase("GET")) {
				TestDTO testDTO = new TestDTO();
				adminBusDelegate.getTestList(testDTO);
				List<Test> testList = testDTO.getTestList();
				TestList testListModel = new TestList();
				TestPlanDTO testPlanDTO = new TestPlanDTO();
				testPlanDTO.setTest(new Test());
				if(testDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					testListModel.setTestList(testList);
					modelView = new ModelAndView("passrate", "testPlanDTO", testPlanDTO).addObject("testlistmodel", testListModel)
							.addObject("staff", staff);
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
					modelView = new ModelAndView("passrate", "testPlanDTO", testPlanDTO).addObject("testlistmodel", testListModel)
							.addObject("staff", staff).addObject("errors", errors);
				}
			}
			else {
				TestPlanDTO testPlanDTO = (TestPlanDTO)command;
				String testId = testPlanDTO.getTest().getTestId();
				
				Test test = new Test();
				test.setTestId(testId);
				testPlanDTO.setTest(test);
				adminBusDelegate.getTest(testPlanDTO);
				
				if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR) {				
					// Set the test plan list.
					adminBusDelegate.getTestPlanList(testPlanDTO);				
					if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						modelView = new ModelAndView("modifypassrate", "testPlanDTO", testPlanDTO).addObject("staff", staff);
					}
					else {
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
						modelView = new ModelAndView("modifypassrate", "testPlanDTO", testPlanDTO)
								       .addObject("staff", staff).addObject("errors", errors);
					}
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
					modelView = new ModelAndView("modifypassrate", "testPlanDTO", testPlanDTO)
							       .addObject("staff", staff).addObject("errors", errors);
				}
			}
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView DisplayTimeLimit(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			ModelAndView modelView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);		
			TimeLimitDTO timeLimitDTO = new TimeLimitDTO();
			List<String> success = new ArrayList<String>();
			if(request.getParameter("success")!=null){
				success.add(ErrorCode.ERROR_MESSAGE(timeLimitDTO.getErrorCode()));
			}
			
			adminBusDelegate.getTimeLimitList(timeLimitDTO);
			
			if(timeLimitDTO.getErrorCode() == ErrorCode.NO_ERROR) {	
					modelView = new ModelAndView("modifytimelimit", "timeLimitDTO", timeLimitDTO).addObject("staff", staff).addObject("success", success);
			}
			else {
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(timeLimitDTO.getErrorCode()));
				modelView = new ModelAndView("modifytimelimit", "timeLimitDTO", timeLimitDTO).addObject("staff", staff).addObject("errors", errors);
			}
			
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	
	public ModelAndView UpdateTimeLimit(HttpServletRequest request, HttpServletResponse response, HttpSession session, TimeLimitDTO command){
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView modelView = null;
			TimeLimitDTO timeLimitDTO = (TimeLimitDTO)command; 
			timeLimitDTO.setLastModUsername(staff.getUserId());
			timeLimitDTO.setLastModUserTime(new Date());
			
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			adminBusDelegate.updateTimeLimits(timeLimitDTO);
			if(timeLimitDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				modelView = new ModelAndView("redirect:DisplayTimeLimit.do").addObject("success", true);
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(timeLimitDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(timeLimitDTO.getErrorCode()));
				modelView = new ModelAndView("modifytimelimit", "timeLimitDTO", timeLimitDTO).addObject("errors", errors).addObject("staff", staff);
			}
			
			return modelView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView UpdatePassRate(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestPlanDTO command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView modelView = null;
			TestPlanDTO testPlanDTO = (TestPlanDTO)command; 
		
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			// Add all question count from each category
			testPlanDTO.setTestQuestionCount();
			adminBusDelegate.updateTest(testPlanDTO);
			if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				testPlanDTO.setTestIdInTestPlan();
				adminBusDelegate.updateTestPlanByTestId(testPlanDTO);
				ut.commit();
				if (testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					modelView = new ModelAndView("redirect:DisplayTestListForPassRate.do");
				}
				else {
					ut.rollback();
					logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
					TestList testListModel = new TestList();
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
					modelView = new ModelAndView("passrate", "testPlanDTO", new TestPlanDTO())
					            .addObject("testlistmodel", testListModel).addObject("errors", errors).addObject("staff", staff);
				}
			}
			else {
				ut.rollback();
				logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
				TestList testListModel = new TestList();
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
				modelView = new ModelAndView("passrate", "testPlanDTO", new TestPlanDTO())
				            .addObject("testlistmodel", testListModel).addObject("errors", errors).addObject("staff", staff);
			}
			return modelView;
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		
	}
	
	public ModelAndView QuestionPassRate(HttpServletRequest request, HttpServletResponse response, HttpSession session, DatePicker command) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String group = staff.validateAndReturnTechGroup();
			ModelAndView view = null;
			if(request.getMethod().equalsIgnoreCase("GET")) {
				view = new ModelAndView("quesreport", "DatePicker", new DatePicker());
			}
			else {
				DatePicker dateCmd = (DatePicker) command;
				QuesPassRateDTO quesDTO = new QuesPassRateDTO();
				if(!dateCmd.getFromDate().equals("") && !dateCmd.getToDate().equals("")) {
					quesDTO.setFromDate(dateCmd.getFromDate());
					quesDTO.setToDate(dateCmd.getToDate());
				examBusDelegate.getQuesPassRateList(quesDTO);
				QuesRep quesRepModel = new QuesRep();
				if(quesDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					java.util.Collections.sort(quesDTO.getQuesReports(),  new QuesPassFailReportComparator());
					quesRepModel.setQuesPassRateList(quesDTO.getQuesReports());
					view = new ModelAndView("quesreport", "DatePicker", dateCmd).addObject("reports", quesRepModel).addObject("staff", staff).addObject("group", group);
				}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(quesDTO.getErrorCode()));
					view = new ModelAndView("quesreport","DatePicker", dateCmd).addObject("reports", quesRepModel).addObject("staff", staff).addObject("group", group).addObject("errors", errors);
				}
			}
				else {
					List<String> errors = new ArrayList<String>();
					errors.add("Please select a date range");
					view = new ModelAndView("quesreport", "DatePicker", new DatePicker()).addObject("staff", staff).addObject("errors", errors);
				}
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method here is used for creating the parent question and assign categories to which the question
	 * belongs to 
	 */
	public ModelAndView ModifyTestType(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestPlanDTO command) {
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			TestPlanDTO testPlanDTO = command;
			if(request.getMethod().equalsIgnoreCase("GET")) {
				adminBusDelegate.loadTestType(testPlanDTO);
				if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR){
					modelAndView = new ModelAndView("modifytesttype", "TestTypeCommand", testPlanDTO)
					.addObject("categories", testPlanDTO.getTestPlanList()).addObject("staff", staff);
				}
				else{
					logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
					modelAndView = new ModelAndView("modifytesttype", "TestTypeCommand", testPlanDTO)
					.addObject("categories", testPlanDTO.getTestPlanList()).addObject("errors", errors).addObject("staff", staff);
				}
			}
			else{
				testPlanDTO.getTest().setLastModUsername(staff.getUserId());
				@SuppressWarnings("unchecked")
				List<TestPlan> sessionTestPlanList = (List<TestPlan>) session.getAttribute("sessionTestPlanList");
				try{
					Context context = new InitialContext();
					UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
					ut.begin();
					adminBusDelegate.updateTestType(testPlanDTO);
					if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR){
						ut.commit();
						modelAndView = new ModelAndView("redirect:ViewTestType.do?testId="+testPlanDTO.getTest().getTestId());
					}
					else{		
						ut.rollback();
						adminBusDelegate.fillTestPlanList(testPlanDTO,sessionTestPlanList);
						logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
						modelAndView = new ModelAndView("modifytesttype", "TestTypeCommand", testPlanDTO)
						.addObject("categories", testPlanDTO.getTestPlanList()).addObject("errors", errors).addObject("staff", staff);
					}
				}
				catch(Exception e){
					logger.error(e.getMessage(), e);
					adminBusDelegate.fillTestPlanList(testPlanDTO,sessionTestPlanList);
					modelAndView = new ModelAndView("viewtesttype", "TestTypeCommand", new TestPlanDTO())
					.addObject("categories", testPlanDTO.getTestPlanList()).addObject("staff", staff);
				}	
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method here is used for creating the parent question and assign categories to which the question
	 * belongs to 
	 */
	public ModelAndView CreateTestType(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestPlanDTO command) {		
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if(request.getMethod().equalsIgnoreCase("GET")) {
					TestPlanDTO testPlanDTO = new TestPlanDTO();
					adminBusDelegate.getAllCategoriesTestPlanList(testPlanDTO);
					if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						session.setAttribute("sessionTestPlanList", testPlanDTO.getTestPlanList());
						modelAndView = new ModelAndView("createtesttype", "TestTypeCommand", testPlanDTO)
						.addObject("categories", testPlanDTO.getTestPlanList()).addObject("staff", staff);
					}
					else {
						logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
						modelAndView = new ModelAndView("createtesttype", "TestTypeCommand", new TestPlanDTO())
						.addObject("categories", testPlanDTO.getTestPlanList()).addObject("errors", errors).addObject("staff", staff);
					}
				}
				else if (request.getMethod().equalsIgnoreCase("POST")){
					TestPlanDTO testPlanDTO = command;
					testPlanDTO.getTest().setLastModUsername(staff.getUserId());
					@SuppressWarnings("unchecked")
					List<TestPlan> sessionTestPlanList = (List<TestPlan>) session.getAttribute("sessionTestPlanList");
					try{
						Context context = new InitialContext();
						UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
						ut.begin();
						adminBusDelegate.saveTestType(testPlanDTO);
						if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR){
							ut.commit();
							modelAndView = new ModelAndView("redirect:ViewTestType.do?testId="+testPlanDTO.getTest().getTestId());
						}
						else{		
							ut.rollback();
							adminBusDelegate.fillTestPlanList(testPlanDTO,sessionTestPlanList);
							logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
							List<String> errors = new ArrayList<String>();
							errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
							modelAndView = new ModelAndView("createtesttype", "TestTypeCommand", testPlanDTO)
							.addObject("categories", testPlanDTO.getTestPlanList()).addObject("errors", errors).addObject("staff", staff);
						}
					}
					catch(Exception e){
						logger.error(e);
						adminBusDelegate.fillTestPlanList(testPlanDTO,sessionTestPlanList);
						modelAndView = new ModelAndView("viewtesttype", "TestTypeCommand", new TestPlanDTO())
						.addObject("categories", testPlanDTO.getTestPlanList()).addObject("staff", staff);
					}				
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	/*
	 * This method here is used for creating the parent question and assign categories to which the question
	 * belongs to 
	 */
	public ModelAndView ViewTestType(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String testId = request.getParameter("testId").trim().toUpperCase();
			Test test = new Test();
			test.setTestId(testId);
			TestPlanDTO testPlanDTO = new TestPlanDTO();
			testPlanDTO.setTest(test);
			adminBusDelegate.loadTestType(testPlanDTO);
			if(testPlanDTO.getErrorCode() == ErrorCode.NO_ERROR){
				modelAndView = new ModelAndView("viewtesttype", "TestTypeCommand", testPlanDTO)
				.addObject("categories", testPlanDTO.getTestPlanList()).addObject("staff", staff);
			}
			else{
				logger.error(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(testPlanDTO.getErrorCode()));
				modelAndView = new ModelAndView("viewtesttype", "TestTypeCommand", testPlanDTO)
				.addObject("categories", testPlanDTO.getTestPlanList()).addObject("errors", errors).addObject("staff", staff);
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/*
	 * This method here is used for creating the parent question and assign categories to which the question
	 * belongs to 
	 */
	public ModelAndView SearchTestType(HttpServletRequest request, HttpServletResponse response, HttpSession session, TestCommand command) {		
		try {
			ModelAndView modelAndView = null;
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				TestDTO testDTO= new TestDTO();
				if(request.getMethod().equalsIgnoreCase("GET")) {
					modelAndView = new ModelAndView("searchtesttype", "TestCommand", new TestCommand()).addObject("testList", testDTO.getTestList()).addObject("staff", staff);
				}
				else{
					List<Test> testList = new ArrayList<Test>();
					Test test =  new Test();
					test.setTestId(command.getTestId());
					test.setTestName(command.getTestName());
					testList.add(test);
					testDTO.setTestList(testList);
					adminBusDelegate.searchTestType(testDTO);
					if(testDTO.getErrorCode() == ErrorCode.NO_ERROR){
						modelAndView = new ModelAndView("searchtesttype", "TestCommand", command).addObject("testList", testDTO.getTestList()).addObject("staff", staff);					
					}
					else{
						logger.error(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(testDTO.getErrorCode()));
						modelAndView = new ModelAndView("searchtesttype", "TestCommand", command).addObject("staff", staff).addObject("errors", errors);
					}
				}
			}
			return modelAndView;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This method is called to get a list of questions and answers that are awaiting review.
	 */
	public ModelAndView PendingReview(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			ModelAndView view = null;
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP)) {
				QuestionLangDTO quesLangDTO = new QuestionLangDTO();
				adminBusDelegate.getPendingReviewQuesAns(quesLangDTO);
				SearchResult searchResultModel = new SearchResult();
				searchResultModel.setQuestionLangList(quesLangDTO.getQuestionLangList());
				searchResultModel.setSize(quesLangDTO.getQuestionLangList().size());
				view = new ModelAndView("pendingreview").addObject("searchresultmodel", searchResultModel).addObject("staff", staff);
			}
			return view;
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This method is called to approve/deny a question and its answers that were reviewed.
	 */
	public ModelAndView ApproveDeny(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView view = null;
		QuestionLangDTO quesLangDTO = new QuestionLangDTO();
		QuestionLang ql = new QuestionLang();
		if(request.getParameter("qid") != null) {
			ql.setQuestionGenId(Integer.parseInt(request.getParameter("qid")));
		}
		if(request.getParameter("cmd") != null) {
			ql.setChangeReviewStatusCode(request.getParameter("cmd"));
		}
		List<QuestionLang> quesLangList = new ArrayList<QuestionLang>();
		quesLangList.add(ql);
		quesLangDTO.setQuestionLangList(quesLangList);
		adminBusDelegate.approveDenyQuestion(quesLangDTO);
		if(quesLangDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			view = new ModelAndView("redirect:PendingReview.do");
		}
		else {
			String error = ErrorCode.ERROR_MESSAGE(quesLangDTO.getErrorCode());
			view = new ModelAndView("redirect:View?questionId=" + request.getParameter("qid") + "&err=" + error);
		}
		return view;
	}

	
		
	/**
	 * @param command
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This controller is called to create a new category.
	 */
	
	public ModelAndView CreateTestCategoryView(HttpServletRequest request,HttpServletResponse response, HttpSession session, Category command) {
		ModelAndView modelAndView = null;
		try{
			Category category = new Category();
			CategoryDTO categoryDTO= new CategoryDTO();
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			if (staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if (request.getMethod().equalsIgnoreCase("GET")) {
					modelAndView = new ModelAndView("createTestCategoryView", "CategoryTypeCommand", category);
				} 
				else if(request.getMethod().equalsIgnoreCase("POST")) {
						category = command;
						List<Category> categoryList = new ArrayList<Category>();
						categoryList.add(category);
						categoryDTO.setCategoryList(categoryList);
						Context context = new InitialContext();
						UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
						ut.begin();
						adminBusDelegate.saveCategoryType(categoryDTO);
						if(categoryDTO.getErrorCode() == ErrorCode.NO_ERROR){
							ut.commit();
							modelAndView = new ModelAndView("redirect:ViewCategory.do?categoryId="+category.getCategoryId());
						}
						else{
							ut.rollback();
							if(categoryDTO.getErrorCode() != ErrorCode.DUPLICATE_CATEGORY_ID){
							logger.error(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
							}
							List<String> errors = new ArrayList<String>();
							errors.add(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
							modelAndView = new ModelAndView("createTestCategoryView", "CategoryTypeCommand", category).addObject("errors", errors);
						}		
			     }
			}
		}
		catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		
		return modelAndView;
	}
	
	/**
	 
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * This controller is called to view a newly created category.
	 */
	public ModelAndView ViewCategory(HttpServletRequest request, HttpServletResponse response, HttpSession session){
	
		ModelAndView modelAndView = null;
		try{
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			String categoryId = request.getParameter("categoryId").trim();
			Category category = new Category();
			category.setCategoryId(categoryId);
			CategoryDTO categoryDTO = new CategoryDTO();
			List<Category> categoryList = new ArrayList<Category>();
				categoryList.add(category);
				categoryDTO.setCategoryList(categoryList);
			
			CategoryDTO categoryDTO1= adminBusDelegate.loadCategory(categoryDTO);
			if(categoryDTO1.getErrorCode() == ErrorCode.NO_ERROR){
				modelAndView = new ModelAndView("viewTestCategory", "CategoryTypeCommand", categoryDTO1.getCategoryList().get(Constant.FIRST_ELEMENT));
			}
			else{
				logger.error(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
				List<String> errors = new ArrayList<String>();
				errors.add(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
				modelAndView = new ModelAndView("viewTestCategory", "CategoryTypeCommand", categoryDTO1).addObject("errors", errors);
			}
			
			}
		   catch(Exception e){
				logger.error(e.getMessage(), e);
			}
	
		return  modelAndView;
		
	}	
/**
 * 	
 * @param request
 * @param response
 * @param session
 * @param command
 * @return
 * This controller is used to modify a newly  category.
 */
	public ModelAndView ModifyTestCategory(HttpServletRequest request, HttpServletResponse response, HttpSession session, Category command) {
		ModelAndView modelAndView = null;
	 	try{
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			CategoryDTO categoryDTO= new CategoryDTO();
			Category category= new Category();
			category=command;
			List<Category> categoryList = new ArrayList<Category>();
			categoryList.add(category);
			categoryDTO.setCategoryList(categoryList);	
			
			if(request.getMethod().equalsIgnoreCase("GET")) {			
				CategoryDTO categoryDto1 =	adminBusDelegate.loadCategory(categoryDTO);
				if(categoryDto1.getErrorCode() == ErrorCode.NO_ERROR){
					modelAndView = new ModelAndView("modifyCategoryType", "CategoryTypeCommand", categoryDto1.getCategoryList().get(Constant.FIRST_ELEMENT)).addObject("CategoryId", categoryDto1.getCategoryList().get(Constant.FIRST_ELEMENT));
				}
			}
			else if(request.getMethod().equalsIgnoreCase("POST")) {
					Context context = new InitialContext();
					UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
					ut.begin();
				    CategoryDTO categoryDto1 =	adminBusDelegate.updateCategory(categoryDTO);
				    if(categoryDto1.getErrorCode() == ErrorCode.NO_ERROR){
				    	ut.commit();
				    	modelAndView = new ModelAndView("viewTestCategory", "CategoryTypeCommand", categoryDto1.getCategoryList().get(Constant.FIRST_ELEMENT));
				    }
				    else{
						ut.rollback();
						logger.error(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(categoryDTO.getErrorCode()));
						modelAndView = new ModelAndView("modifyCategoryType", "CategoryTypeCommand", categoryDto1).addObject("errors", errors);
				}
		      }
	 	}
	 	catch(Exception e){
	 		logger.error(e);		 		
	 	}
		return modelAndView;
	}
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * @return
	 * This controller is used to search a category by id and/or name.
	 */
	public ModelAndView SearchTestCategory(HttpServletRequest request, HttpServletResponse response, HttpSession session, Category command) {
		ModelAndView modelAndView = null;
		try{
			IDMVStaff staff = (IDMVStaff)adminBusDelegate.getDMVStaff(session);
			CategoryDTO categoryDto= new CategoryDTO();
			Category category= new Category();
			if(request.getMethod().equalsIgnoreCase("GET")) {
					modelAndView = new ModelAndView("searchTestCategory", "CategoryTypeCommand", category);
				}
			else if(request.getMethod().equalsIgnoreCase("POST")) {
				category=command;
				List<Category> categoryList = new ArrayList<Category>();
				categoryList.add(category);
				categoryDto.setCategoryList(categoryList);
				CategoryDTO categoryDto1 =	adminBusDelegate.searchCategory(categoryDto);	
				
			    if(categoryDto1.getErrorCode() == ErrorCode.NO_ERROR){
					modelAndView = new ModelAndView("searchTestCategory", "CategoryTypeCommand", category).addObject("categoryList",categoryDto1.getCategoryList());	
				}
			    else{
			    	if(categoryDto.getErrorCode() != ErrorCode.NO_MATCH_FOUND){
					logger.error(ErrorCode.ERROR_MESSAGE(categoryDto.getErrorCode()));
					}
			    	logger.error(ErrorCode.ERROR_MESSAGE(categoryDto1.getErrorCode()));
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(categoryDto1.getErrorCode()));
					modelAndView = new ModelAndView("searchTestCategory", "CategoryTypeCommand", category).addObject("errors", errors); 			    	
			    }
			}   
		}
		catch(Exception e){
			logger.error(e);
		}
		
		return modelAndView;
	}
	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param command
	 * This controller is used to create a new handbook section reference
	 * @return
	 */
	public ModelAndView CreateHandbookSection(HttpServletRequest request, HttpServletResponse response, HttpSession session, HandbookRef command){
	ModelAndView modelAndView=null;	
		try{
			IDMVStaff staff = (IDMVStaff) session.getAttribute(Constant.CREDENTIAL);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				if (staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
					HandbookRef handbook=new HandbookRef();
					handbook=command;
					List<String> errors = new ArrayList<String>();
					HandbookRefDTO handbookDTO= new HandbookRefDTO();
					LangDTO langDTO= new LangDTO();
					List<Lang> langList= new ArrayList<Lang>();
					if(request.getMethod().equalsIgnoreCase("GET")){
						adminBusDelegate.getLangList(langDTO);
						if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
							langList= langDTO.getLangList();
						 }
						else{
							logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
							 errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
						 }
						modelAndView=new ModelAndView("createHandbookSection","HandbookSectionCommand",handbook).addObject("langList", langList).addObject("errors", errors);
					}
					else if(request.getMethod().equalsIgnoreCase("POST")){
							List<HandbookRef> handbookRefList = new ArrayList<HandbookRef>(); 
							handbookRefList.add(handbook);
							handbookDTO.setHandbookRefList(handbookRefList);
							Context context = new InitialContext();
							UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
							ut.begin();
							adminBusDelegate.getLangList(langDTO);
							if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
								langList= langDTO.getLangList();
								handbookDTO= adminBusDelegate.saveHanbookSection(handbookDTO);
								if(handbookDTO.getErrorCode()==ErrorCode.NO_ERROR){
									ut.commit();
									request.setAttribute("langId", handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT).getLangId());
									request.setAttribute("handbookRef", handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT).getHandbookRef());
									modelAndView = new ModelAndView("forward:ViewHandbookSection.do");
									
								}
								else{
									ut.rollback();
										if(handbookDTO.getErrorCode() != ErrorCode.DUPLICATE_HANDBOOKREF){
											logger.error(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
										}								
									errors.add(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
									modelAndView = new ModelAndView("createHandbookSection","HandbookSectionCommand",handbook).addObject("errors", errors).addObject("langList", langList);					
								}
							 }
							else{
								logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
								 errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
							 }		
				   }
			  }
			}
	   }
	   catch(Exception e){
		   logger.error(e);			
	   }
	return modelAndView;
	}
	
	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * This controller is used is view a handbook section reference.
	 * @return
	 */
	public ModelAndView ViewHandbookSection(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		
		ModelAndView modelAndView = null;
		try{
			
			IDMVStaff staff = (IDMVStaff) session.getAttribute(Constant.CREDENTIAL);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				List<String> errors = new ArrayList<String>();
				List<Lang> langList= new ArrayList<Lang>();
				HandbookRef handbook = new HandbookRef();
				String handbookRef = (String)(request.getAttribute("handbookRef"));
				String langId= (String)(request.getAttribute("langId"));
				if(handbookRef==null && langId==null){ 
					handbookRef =request.getParameter("handbookRef").trim();
					langId =request.getParameter("langId").trim();
					}
				LangDTO langDTO= new LangDTO();
				List<Lang> langList1= new ArrayList<Lang>();
				adminBusDelegate.getLangList(langDTO);
				if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
					langList1= langDTO.getLangList();
					handbook.setHandbookRef(handbookRef);
					handbook.setLangId(langId);
					HandbookRefDTO handbookDTO= new HandbookRefDTO();
					List<HandbookRef> handbookRefList = new ArrayList<HandbookRef>();
					handbookRefList.add(handbook);
					handbookDTO.setHandbookRefList(handbookRefList);
					HandbookRefDTO  handbookDTO1= adminBusDelegate.loadHandbok(handbookDTO);
	     			if(handbookDTO1.getErrorCode() == ErrorCode.NO_ERROR){
	     				for(Lang lan:langList1){	
	     					if(langId.trim().equals (lan.getLangId().trim())){    		    		
		    		    		langList.add(lan);
		    		    		langDTO.setLangList(langList);
	     					}
	     				}
	     			modelAndView = new ModelAndView("viewHandbookSection", "HandbookSectionCommand", handbookDTO1.getHandbookRefList().get(Constant.FIRST_ELEMENT)).addObject("langList", langList);
					}
					else{
						logger.error(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
						errors.add(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
						modelAndView = new ModelAndView("viewHandbookSection", "HandbookSectionCommand", handbookDTO1).addObject("errors", errors).addObject("langDTO", langDTO.getLangList());
					    }
				}
				else{
					logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
					 errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
					}
			}
		}
	   catch(Exception e){
		   logger.error(e);
	   }
	return  modelAndView;
		
	}	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param HandbookSectionCommand
	 * This controller is used is modify a handbook section reference.
	 * @return
	 */
	
	public ModelAndView ModifyHandbookSection(HttpServletRequest request, HttpServletResponse response, HttpSession session,HandbookRef HandbookSectionCommand){
		ModelAndView modelAndView= null;
		try{
			IDMVStaff staff = (IDMVStaff) session.getAttribute(Constant.CREDENTIAL);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				List<String> errors = new ArrayList<String>();
				HandbookRefDTO  handbookDTO = new HandbookRefDTO();
				HandbookRef handbookRef= new HandbookRef();
				List<HandbookRef> handbookRefList = new ArrayList<HandbookRef>();
				LangDTO langDTO= new LangDTO();
				List<Lang> langList1=new ArrayList<Lang>();
				List<Lang> langList= new ArrayList<Lang>();
				handbookRef = HandbookSectionCommand;
				handbookRefList.add(handbookRef);
				handbookDTO.setHandbookRefList(handbookRefList);
				String langId=handbookRef.getLangId();
				Context context = new InitialContext();
				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
					if(request.getMethod().equalsIgnoreCase("GET")){
						adminBusDelegate.getLangList(langDTO);
							if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
								langList1= langDTO.getLangList();
								handbookDTO = adminBusDelegate.loadHandbok(handbookDTO);	
								if(handbookDTO.getErrorCode() == ErrorCode.NO_ERROR){
				     				for(Lang lan:langList1){	
				     					if(langId.trim().equals (lan.getLangId().trim())){
					    		    		langList.add(lan);
					    		    		langDTO.setLangList(langList);
				     					}
				     				}
								}
								else{logger.error(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
								 errors.add(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
									
								}
								modelAndView= new ModelAndView("modifyHandbookSection","HandbookSectionCommand",handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT)).addObject("langList", langList).addObject("errors", errors).
											  addObject("language", langList.get(Constant.FIRST_ELEMENT).getLangId());
						 	}
					}
					
				    else if (request.getMethod().equalsIgnoreCase("POST")){
						ut.begin();
						adminBusDelegate.updateHanbookSection(handbookDTO);
						if(handbookDTO.getErrorCode()==ErrorCode.NO_ERROR){
							ut.commit();
							request.setAttribute("langId", handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT).getLangId());
							request.setAttribute("handbookRef", handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT).getHandbookRef());
							modelAndView = new ModelAndView("forward:ViewHandbookSection.do");		
					    	}
				    	else{
				    		ut.rollback();
							if(handbookDTO.getErrorCode() != ErrorCode.DUPLICATE_HANDBOOKREF){
								logger.error(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
							}
							
							errors.add(ErrorCode.ERROR_MESSAGE(handbookDTO.getErrorCode()));
							modelAndView= new ModelAndView("modifyHandbookSection","HandbookSectionCommand",handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT)).addObject("langList", langList).addObject("errors", errors).
										  addObject("language", langList.get(Constant.FIRST_ELEMENT));
							}
				    }
				    else{
				    	logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
						 errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
				    }
			}	
		}
		catch(Exception e ){
			logger.error(e);
		}
	return modelAndView;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param session
	 * @param HandbookSectionCommand
	 * This controller is used is search a handbook section reference by handbookRef and/or langId.
	 * @return
	 */
	
	public ModelAndView SearchHandbookSection(HttpServletRequest request, HttpServletResponse response, HttpSession session, HandbookRef HandbookSectionCommand ){
		
		ModelAndView modelAndView= null;
		LangDTO langDTO= new LangDTO();
		List<String> errors = new ArrayList<String>();
		try{
			IDMVStaff staff = (IDMVStaff) session.getAttribute(Constant.CREDENTIAL);
			if(staff.isMemberOf(Constant.HQ_ADMIN_GROUP) || staff.isMemberOf(Constant.HQ_USER_GROUP)) {
				boolean langSelected=false;
				HandbookRef handbook= new HandbookRef();
				List<Lang> langList=new ArrayList<Lang>();
				handbook=HandbookSectionCommand;
				HandbookRefDTO handbookRefDTO= new HandbookRefDTO();
				List<HandbookRef> handbookRefList= new ArrayList<HandbookRef>();
					if(request.getMethod().equalsIgnoreCase("GET")){
						adminBusDelegate.getLangList(langDTO);
						if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
							langList=langDTO.getLangList();
							modelAndView= new ModelAndView("searchHandbookSection","HandbookSectionCommand",handbook).addObject("langList", langList).addObject("langSelected",langSelected);
						}
						else{
					    	logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
							errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
							modelAndView= new ModelAndView("searchHandbookSection","HandbookSectionCommand",handbook).addObject("langList", langList).addObject("errors", errors);
					    }	
					}
					else if (request.getMethod().equalsIgnoreCase("POST")){
						handbookRefList.add(handbook);
						handbookRefDTO.setHandbookRefList(handbookRefList);
						adminBusDelegate.getLangList(langDTO);
						if(langDTO.getErrorCode()==ErrorCode.NO_ERROR){
							langList=langDTO.getLangList();
							handbookRefDTO=adminBusDelegate.searchHandbookRefList(handbookRefDTO);
							if(handbookRefDTO.getErrorCode()==ErrorCode.NO_ERROR){
								List<Lang> SelectedlangList=new ArrayList<Lang>();
								String selectedLang=handbook.getLangId();
								if(selectedLang.equals(null) || selectedLang.equals("")){		
									SelectedlangList.addAll(langList);
								}
								else{
									langSelected= true;
									SelectedlangList= selectedDropDownLangList(handbook,langList);
								}
									modelAndView= new ModelAndView("searchHandbookSection","HandbookSectionCommand",handbook).addObject("langList", SelectedlangList).addObject("errors", errors).addObject("handbookResultList", handbookRefDTO.getHandbookRefList()).addObject("langSelected",langSelected);;									
								}
							else{
								List<Lang> SelectedlangList=new ArrayList<Lang>();
								String selectedLang=handbook.getLangId();
								if(selectedLang.equals(null) || selectedLang.equals("")){	
									SelectedlangList.addAll(langList);
								}
								else{
									langSelected= true;
									SelectedlangList= selectedDropDownLangList(handbook,langList);
								}
								errors.add(ErrorCode.ERROR_MESSAGE(handbookRefDTO.getErrorCode()));
								modelAndView= new ModelAndView("searchHandbookSection","HandbookSectionCommand",handbook).addObject("langList", SelectedlangList).addObject("langSelected",langSelected).addObject("errors", errors);;				
								}
						}
						else{
							if(handbookRefDTO.getErrorCode() != ErrorCode.NO_MATCH_FOUND){
								logger.error(ErrorCode.ERROR_MESSAGE(handbookRefDTO.getErrorCode()));
							}
							errors.add(ErrorCode.ERROR_MESSAGE(handbookRefDTO.getErrorCode()));
								modelAndView= new ModelAndView("searchHandbookSection","HandbookSectionCommand",handbook).addObject("langList", langList).addObject("errors", errors);		    
						    }
					}
					
			}	
			else{
				 logger.error(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
				 errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
			}
		}		
		catch(Exception e){	
			logger.error(e);
		}
	 return modelAndView;
	}	
	
	/**
	 * This method is called to display the drop down menu starting from selected language 
	 * @param handbook
	 * @param langList
	 * @return list
	 */
	private List<Lang>selectedDropDownLangList(HandbookRef handbook,List<Lang> langList){
		List<Lang> SelectedlangList=new ArrayList<Lang>();
		String selectedLang=handbook.getLangId();
		List<Lang> tempList2=new ArrayList<Lang>();
		List<Lang> tempList=new ArrayList<Lang>();
		int i=Constant.ZERO;
		while( i<langList.size()){	
			if(selectedLang.equals(langList.get(i).getLangId())){
				for(int j=i;j<langList.size();j++){
				tempList2.add(langList.get(i));
				i++;
				}
			}
			else if(i<langList.size()){
				tempList.add(langList.get(i));
				i++;
			}
		}
		SelectedlangList.addAll(tempList2);
		SelectedlangList.addAll(tempList);
		return SelectedlangList;
	}
}