package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectReceived;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSReceiver;
import gov.ca.dmv.AKT.presentation.Command.FOMain;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.ancientprogramming.fixedformat4j.format.FixedFormatManager;
import com.ancientprogramming.fixedformat4j.format.impl.FixedFormatManagerImpl;

/*
 * This class is used to simply test internationalization. This controller needs to be removed before going live.
 */
public class Test2Controller extends MultiActionController {
	
	private static FixedFormatManager manager = new FixedFormatManagerImpl();
	private EaseAppBusDelegate easeAppBusDelegate; 
	private static final Logger logger = Logger.getLogger(JMSReceiver.class);
	
	public EaseAppBusDelegate getEaseAppBusDelegate() {
		return easeAppBusDelegate;
	}

	public void setEaseAppBusDelegate(EaseAppBusDelegate easeAppBusDelegate) {
		this.easeAppBusDelegate = easeAppBusDelegate;
	}
	
	private int saveReceivedString(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  
        	easeAppBusDelegate.saveReceivedString(easeAppDTO);
        	err = easeAppDTO.getErrorCode();
            if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		return err;
	}
	
	private int createApp(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();  
			easeAppBusDelegate.createApp(easeAppDTO);
			err = easeAppDTO.getErrorCode();
            if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}  
		return err;
	}
	
	private int updateEaseReceivedIndicator(EaseAppDTO easeAppDTO) {
		int err = ErrorCode.NO_ERROR;
		try {
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin(); 
			easeAppBusDelegate.updateEaseReceivedIndicator(easeAppDTO);
			err = easeAppDTO.getErrorCode();
        	if(err == ErrorCode.NO_ERROR) {
        		ut.commit();
        	}
        	else {
        		ut.rollback();
        	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
		return err;
	}

	public ModelAndView CreateTestRecord(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		modelAndView = new ModelAndView("fomain", "FOMain", new FOMain());
		
        try {
        	String dlNum = "C1234604";
        	String receivedString = "AKTS" + dlNum + "        TESTED                     COMMERCIAL                 01011980NYNA DTHMPVSBTV  0CA0NHM0NAB0YBK0NTK0NDT0NPV0NGK0N                    448DG543511152013091831";
        	if(logger.isInfoEnabled()) {
        		logger.info("RECEIVED MQ STRING FROM EASE");
        	}
            EASEObjectReceived easeObj = manager.load(EASEObjectReceived.class, receivedString);
            if(logger.isInfoEnabled()) {
            	if(easeObj.getDlNumber().length() > 3)
            		logger.info("RECEIVED MQ STRING FROM EASE FOR DL# ENDING WITH: " + easeObj.getDlNumber().substring((easeObj.getDlNumber().length() - 4), easeObj.getDlNumber().length()));
        	}
            EaseAppDTO easeAppDTO = new EaseAppDTO();
            easeAppDTO.setReceivedString(receivedString);
            int errorCode1 = saveReceivedString(easeAppDTO);
        	if(errorCode1 == ErrorCode.NO_ERROR) {
        		easeAppDTO.create(easeObj);
				int errorCode2 = createApp(easeAppDTO);
				if(errorCode2 == ErrorCode.NO_ERROR) {
					easeAppDTO.setEaseReceivedMessageInd(Constant.YES);
					updateEaseReceivedIndicator(easeAppDTO);
				}
				else {
					easeAppDTO.setEaseReceivedMessageInd(Constant.YES);
					updateEaseReceivedIndicator(easeAppDTO);
				}
        	}	
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }      
        
        return modelAndView;
   }	
}
