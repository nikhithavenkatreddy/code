package gov.ca.dmv.AKT.presentation.Controller;

import gov.ca.dmv.AKT.business.BusDelegates.FOBusDelegate;
import gov.ca.dmv.AKT.business.BusDelegates.SessionBusDelegate;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Office;
import gov.ca.dmv.AKT.presentation.Beans.Session;
import gov.ca.dmv.AKT.presentation.Beans.WorkstationMap;
import gov.ca.dmv.AKT.presentation.Beans.YOB;
import gov.ca.dmv.AKT.presentation.Command.Barcode;
import gov.ca.dmv.AKT.presentation.Command.Lang;
import gov.ca.dmv.AKT.presentation.Command.YOBValidation;
import gov.ca.dmv.AKT.presentation.DTO.HealthCheckDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.SessionDTO;
import gov.ca.dmv.AKT.presentation.DTO.WorkstationMapDTO;
import gov.ca.dmv.AKT.presentation.DTO.YOBDTO;
import gov.ca.dmv.AKT.presentation.Model.LangList;
import gov.ca.dmv.AKT.presentation.Model.YOBList;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;

public class SessionController extends AKTBaseController {
	private SessionBusDelegate sessionBusDelegate;
	private FOBusDelegate foBusDelegate;
	private static final Logger logger = Logger.getLogger(SessionController.class);
	
	public FOBusDelegate getFoBusDelegate() {
		return foBusDelegate;
	}

	public void setFoBusDelegate(FOBusDelegate foBusDelegate) {
		this.foBusDelegate = foBusDelegate;
	}

	public SessionBusDelegate getSessionBusDelegate() {
		return sessionBusDelegate;
	}

	public void setSessionBusDelegate(SessionBusDelegate sessionBusDelegate) {
		this.sessionBusDelegate = sessionBusDelegate;
	}

	/*
	 * This method is called to present the language choice and handle the submission of the choice
	 */
	public ModelAndView InitialScreen(HttpServletRequest request, HttpServletResponse response, Lang command) {
		return new ModelAndView("initialscreen", "initialscreen", new Lang());
	}
	
	/*
	 * This method is called to present the language choice and handle the submission of the choice
	 */
	public ModelAndView ScanFingerprint(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp, Lang command) {
		Office office = null;
		try {
			String terminalIP = getRemoteIP(request);
			office = sessionBusDelegate.getOfficeByTerminalIP(terminalIP);
			sessionHttp.setAttribute("addtnl_messages_timeout",sessionBusDelegate.getScreenTimeout("addtnl_messages_screen"));
			sessionHttp.setAttribute("dlNumberEnterFailCount", 0);
			return new ModelAndView("scanfingerprint", "scanfingerprint", new Lang())
		           .addObject("l1IPAddr", office.getL1ServerIpAddr().trim());
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);	
		}
	}
	
	public void CheckTerminalReserved(HttpServletRequest request, HttpServletResponse response, Lang command) {
		String ipAddress = getRemoteIP(request); 
		OutputStream out = null;
		try {
			out = response.getOutputStream();
		
			PrintStream printStream = new PrintStream(out);
			if(isTerminalReserved(ipAddress)) {
				printStream.print("reserved");
			}
			else {
				printStream.print("Error");
			}
		} catch (Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	/*
	 * This method is called to present the language choice and handle the submission of the choice
	 */
	public ModelAndView SelectLang(HttpServletRequest request, HttpServletResponse response, Lang command) {
		try {
			if (request.getMethod().equalsIgnoreCase("GET")) {
				LangDTO langDTO = new LangDTO();
				langDTO.setSetNo(Constant.ONE);
				if (request.getParameter("setno") != null)
					langDTO.setSetNo(Integer.parseInt(request
							.getParameter("setno")));

				if (request.getParameter("isReserved") != null)
					request.getSession().setAttribute("isReserved",
							request.getParameter("isReserved"));
				//else
					//request.getSession().setAttribute("isReserved", "no");

				sessionBusDelegate.getLangList(langDTO);
				LangList langListModel = new LangList();
				if (langDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					getNativeLangNames(langDTO.getLangList(),
							langDTO.getSpanish(), langDTO.getSetNo());

					langListModel.setEnglish(langDTO.getEnglish());
					langListModel.setSpanish(langDTO.getSpanish());

					String terminalIP = getRemoteIP(request);
					Office office = sessionBusDelegate
							.getOfficeByTerminalIP(terminalIP);
					if (office.getOfficeTypeCode().trim()
							.equals(Constant.OFFICE_TYPE_OL)) {
						request.getSession().setAttribute("localelanguage",
								langDTO.getEnglish().getProgLangCode());
						request.getSession().setAttribute("langIdCode",
								langDTO.getEnglish().getLangId()); //OL default to English
						return new ModelAndView("video").addObject(
								"Instructions_File_Name",
								Constant.INSTRUCTION_FILE_NAME).addObject(
								"Instructions_File_Ext",
								Constant.INSTRUCTION_FILE_EXT);
					} else {
						if (!office.getOfficeTypeCode().trim()
								.equals(Constant.OFFICE_TYPE_CHP)) {
							langListModel.setLangList(langDTO.getLangList());
						}
						return new ModelAndView("selectlang", "SelectLang", new Lang())
						               .addObject("langlistmodel", langListModel)
						               .addObject("setno", langDTO.getSetNo())
						               .addObject("officeId", office.getOfficeId());
					}
				} else {
					List<String> errors = new ArrayList<String>();
					errors.add(ErrorCode.ERROR_MESSAGE(langDTO.getErrorCode()));
					return new ModelAndView("selectlang", "SelectLang",
							new Lang())
							.addObject("langlistmodel", langListModel)
							.addObject("setno", langDTO.getSetNo())
							.addObject("errors", errors);
				}
			} else {	// Temporary fix to default instruction video to English if any other language except Spanish
				Lang langCmnd = (Lang) command;
				request.getSession().setAttribute("localelanguage",
						langCmnd.getLanguage());
				request.getSession().setAttribute("langIdCode",
						langCmnd.getLangIdCode());
				if (langCmnd.getLangIdCode().equals("02")){ //Spanish
					return new ModelAndView("video").addObject(
						"Instructions_File_Name",
						Constant.INSTRUCTION_FILE_NAME_ES).addObject(
						"Instructions_File_Ext", Constant.INSTRUCTION_FILE_EXT);
				} else { 
					return new ModelAndView("video").addObject(
						"Instructions_File_Name",
						Constant.INSTRUCTION_FILE_NAME_EN).addObject(
						"Instructions_File_Ext", Constant.INSTRUCTION_FILE_EXT);
				}
			}
//	Visit this later for enhancement when we have video instructions for other languages - 07/17/2017
//			else {
//				Lang langCmnd = (Lang) command;
//				request.getSession().setAttribute("localelanguage",
//						langCmnd.getLanguage());
//				request.getSession().setAttribute("langIdCode",
//						langCmnd.getLangIdCode());
//				return new ModelAndView("video").addObject(
//						"Instructions_File_Name",
//						Constant.INSTRUCTION_FILE_NAME).addObject(
//						"Instructions_File_Ext", Constant.INSTRUCTION_FILE_EXT);
//			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView Authentication(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		try {
			String isReserved = (String) request.getSession().getAttribute("isReserved");
			if(isReserved!=null && isReserved.trim().toLowerCase().equals("yes")) {
				return new ModelAndView("redirect:GetDLInfo.do");
			}
			else {
				String terminalIP = getRemoteIP(request);
				Office office = sessionBusDelegate.getOfficeByTerminalIP(terminalIP);
				ModelAndView retMV = null;
				//office.setNewFunctionOnFlag("Y");  // TODO
				//office.setOfficeTypeCode("FO");    // TODO
				if (office.getOfficeTypeCode().equalsIgnoreCase("FO") &&
					office.getNewFunctionOnFlag().equals(Constant.YES)) {
					retMV = new ModelAndView("redirect:ScanFingerprint.do");
				}
				else {
					retMV = new ModelAndView("redirect:GetDLInfo.do?scanBarCodeFlag=N");
				}
				
				return retMV;
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView ReAuthentication(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		try {
			ModelAndView retMV = null;
			
			// Set AdditionalTestFlag in session
			examSessionData.setAdditionalTestFlag(true);
			
			// Terminate the old session here
			SessionDTO sessionDTO = new SessionDTO();
			Session session = new Session();
			session.setSessionId((Integer)sessionHttp.getAttribute("sessionId"));
			sessionDTO.setSession(session);
			sessionBusDelegate.terminateSession(sessionDTO);
			
			String isReserved = (String) request.getSession().getAttribute("isReserved");
			if(isReserved != null && isReserved.trim().toLowerCase().equals("yes")) {
				return new ModelAndView("redirect:GetDLInfo.do");
			}
			else {
				retMV = new ModelAndView("redirect:Authentication.do");
				return retMV;			
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	private void getNativeLangNames(List<gov.ca.dmv.AKT.presentation.Beans.Lang> langList, gov.ca.dmv.AKT.presentation.Beans.Lang spanish, int setNo) {
		ReloadableResourceBundleMessageSource res = new ReloadableResourceBundleMessageSource();
		res.setBasename(Constant.BASE_NAME);
		for(gov.ca.dmv.AKT.presentation.Beans.Lang lang: langList) {
			Locale loc = new Locale(lang.getProgLangCode());
			String engName = lang.getLangName();
			lang.setLangName(res.getMessage("lang.name", null, loc) + " - " + engName);
			lang.setLangName(engName);
		}
		if(setNo == Constant.ONE) {
			Locale loc = new Locale(spanish.getProgLangCode());
			String engName = spanish.getLangName();
			spanish.setLangName(res.getMessage("lang.name", null, loc) + " - " + engName);
			spanish.setLangName(engName);
		}
	}
	
	/**
	 * Check to see if the terminal is reserved.
	 * @param ipAddress
	 * @return
	 */
	private boolean isTerminalReserved(String ipAddress) {
		WorkstationMapDTO wmDTO = new WorkstationMapDTO();
		WorkstationMap wm = new WorkstationMap();
		wm.setWorkstationIPAddress(ipAddress);
		List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
		wmList.add(wm);
		wmDTO.setWorkstationMapList(wmList);
		foBusDelegate.getTerminalStatusByIP(wmDTO);
		
		if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			wmList = wmDTO.getWorkstationMapList();
			for(WorkstationMap wmap: wmList) {
				if (wmap.getStatus() != null && wmap.getStatus().equals(Constant.TERMINAL_RESERVED)) {
					return true;
				}				
			}
		}
		return false;
	}

	private YOBList YOBValidationDisplay() {
		List<String> years = new ArrayList<String>();							
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
		int currYear = Integer.parseInt(format.format(new Date()));							
		for(int i = currYear - 10; i >= Constant.STARTING_YEAR; i--)
			years.add(String.valueOf(i));
		YOBList yobModel = new YOBList();
		yobModel.setYears(years);
		return yobModel;
	}
	
	/*
	 * This method is called to present the yob validation and handle its submission
	 */
	public ModelAndView YOBValidation(HttpServletRequest request, HttpServletResponse response, HttpSession session, YOBValidation command) {
		ModelAndView retMV = null;
		try {
			Integer vaultId = (Integer) session.getAttribute("vaultId");
			Integer yobValdnFailCount = (Integer) session.getAttribute("yobFailCounter");
			if(request.getMethod().equalsIgnoreCase("GET")) {
				retMV = new ModelAndView("validateyob", "YOBValidation", new YOBValidation()).addObject("yobmodel", YOBValidationDisplay()).addObject("timelimit",sessionBusDelegate.getScreenTimeout("validateyob"));
			}
			else 
			{
				YOBValidation yobValidation = (YOBValidation) command;
				YOBDTO yobDTO = new YOBDTO();
				YOB yob = new YOB();
//			if(yobValidation.getYob() == null || yobValidation.getYob().length() <= Constant.ZERO) {
//				yob.setYob(Constant.DEFAULT_YOB);
//			}
//			else {
//				yob.setYob(yobValidation.getYob().trim());
//			}
				yob.setDob(yobValidation.getDob().trim());
				yob.setThreeCharLastName(yobValidation.getThreeCharLastName().trim());
				yob.setVaultId(vaultId);
				yobDTO.setYob(yob);
				sessionBusDelegate.validateYOB(yobDTO);
				if(yobDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					if(!yobDTO.isValidationSuccessful()) {
						if(yobValdnFailCount.equals(2)) {
							Session session1 = new Session();
							session1.setSessionId((Integer) session.getAttribute("sessionId"));
							SessionDTO sessionDTO = new SessionDTO();
							sessionDTO.setSession(session1);
							sessionBusDelegate.endSession(sessionDTO);
							//session.invalidate();
							request.getSession().setAttribute("addtnl_messages_timeout",sessionBusDelegate.getScreenTimeout("addtnl_messages_screen"));
							gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
							errorModel.setErrorCode(ErrorCode.YOB_VALIDATION_FAILED_3_TIMES);
							if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
								retMV = new ModelAndView("error").addObject("errormodel", errorModel);
							}
							else {
								logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
								retMV = new ModelAndView("redirect:EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
							}
						}
						else {
							yobValdnFailCount++;
							session.setAttribute("yobFailCounter", yobValdnFailCount);
							gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
							errorModel.setErrorCode(ErrorCode.YOB_VALIDATION_FAILED);
							if(logger.isInfoEnabled()) {
								logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.YOB_VALIDATION_FAILED));
							}
							retMV = new ModelAndView("yoberror").addObject("errormodel", errorModel);
						}
					}
					else {
						retMV = new ModelAndView("redirect:TestRulesScreen.do");
					}
				}
				else {
					logger.error(ErrorCode.ERROR_MESSAGE(yobDTO.getErrorCode()));
					retMV = new ModelAndView("redirect:EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(yobDTO.getErrorCode()));
				}
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);		
		}
		return retMV;
	}
	
	/*
	 * This method is called to handle submit on yob idle
	 */
	public ModelAndView YOBIdle(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		try {
			SessionDTO sessionDTO = new SessionDTO();
			Session session = new Session();
			session.setSessionId((Integer)sessionHttp.getAttribute("sessionId"));
			sessionDTO.setSession(session);
			sessionBusDelegate.terminateSession(sessionDTO);
			if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				return new ModelAndView("redirect:InitialScreen.do");
			}
			else {
				logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
				return new ModelAndView("redirect:EndSession.do").addObject("errormessage", ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}

	
	public ModelAndView GetDLInfo (HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp, Barcode command) {
		ModelAndView modelAndView = null;
		try {
			Integer dlNumberEnterFailCount = (Integer) sessionHttp.getAttribute("dlNumberEnterFailCount");
			String scanBarCodeFlag = request.getParameter("scanBarCodeFlag");
			if(request.getMethod().equalsIgnoreCase("GET")) {
				if (scanBarCodeFlag != null && scanBarCodeFlag.equals(Constant.YES)) {
					modelAndView = new ModelAndView("scanbarcode");
					sessionHttp.setAttribute("dlNumberEnterFailCount", 0);
				}
				else {
					modelAndView = new ModelAndView("getdlinfo").addObject("timelimit",sessionBusDelegate.getScreenTimeout("getdlinfo"));
					if (dlNumberEnterFailCount == null || dlNumberEnterFailCount < 0) {
						sessionHttp.setAttribute("dlNumberEnterFailCount", 0);
					}
				}
			}
			else
			{
				Barcode barcodeCmnd = (Barcode) command;
				SessionDTO sessionDTO = new SessionDTO();
				Session session = new Session();
				
				session.setWorkstationIPAddress(getRemoteIP(request));
				sessionHttp.setAttribute("addtnl_messages_timeout",sessionBusDelegate.getScreenTimeout("addtnl_messages_screen"));
				session.setAdditionalTestFlag(examSessionData.getAdditionalTestFlag());
				session.setLanguageCode((String) sessionHttp.getAttribute("langIdCode"));
				sessionDTO.setSession(session);
				sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
			
				if (request.getParameter("dlId") != null) {
					sessionDTO.setDlNumber(request.getParameter("dlId").trim());
				}
				else {
					sessionDTO.setDlNumber(barcodeCmnd.getDlNumberAfterTransformation().trim());
				}
			
				Context context = new InitialContext();
				UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
				ut.begin();
				sessionBusDelegate.createSession(sessionDTO);
				if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					ut.commit();
					
					if (request.getParameter("dlId") != null) {
						sessionHttp.setAttribute("vaultId", sessionDTO.getSession().getVaultId());
						sessionHttp.setAttribute("applicationId", sessionDTO.getSession().getApplicationId());
						sessionHttp.setAttribute("sessionId", sessionDTO.getSession().getSessionId());
						sessionHttp.setAttribute("resumeExamId", sessionDTO.getResumeExamId());
						//sessionHttp.setAttribute("yobFailCounter", 0);
						//modelAndView = new ModelAndView("testrules").addObject("timelimit",sessionBusDelegate.getScreenTimeout("testrules"));
					}
					else {
						sessionHttp.setAttribute("vaultId", sessionDTO.getSession().getVaultId());
						sessionHttp.setAttribute("applicationId", sessionDTO.getSession().getApplicationId());
						sessionHttp.setAttribute("sessionId", sessionDTO.getSession().getSessionId());
						sessionHttp.setAttribute("resumeExamId", sessionDTO.getResumeExamId());
						sessionHttp.setAttribute("yobFailCounter", 0);
						modelAndView = new ModelAndView("redirect:YOBValidation.do");
					}					
				}
				else {
					ut.rollback();
					gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
					dlNumberEnterFailCount++;
					sessionHttp.setAttribute("dlNumberEnterFailCount", dlNumberEnterFailCount);
					if((sessionDTO.getErrorCode() != ErrorCode.MISSING_SESSION && sessionDTO.getErrorCode() != ErrorCode.JDBC_FAILURE && 
					    sessionDTO.getErrorCode() != ErrorCode.ACCESS_FAILURE && sessionDTO.getErrorCode() != ErrorCode.CATCHALL_FAILURE && 
					    sessionDTO.getErrorCode() != ErrorCode.INTEGRITY_FAILURE && dlNumberEnterFailCount == 3) ||
					    sessionDTO.getErrorCode() == ErrorCode.NEED_STUDY || sessionDTO.getErrorCode() == ErrorCode.NULL_EXAM_LIST) {
						
						errorModel.setErrorCode(sessionDTO.getErrorCode());
						logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
						modelAndView = new ModelAndView("error").addObject("errormodel", errorModel);
					} else {
						logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
						List<String> errors = new ArrayList<String>();
						errors.add(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
						modelAndView = new ModelAndView("getdlinfo").addObject("errormodel", errorModel).addObject("errors", errors)
								                                    .addObject("timelimit",sessionBusDelegate.getScreenTimeout("getdlinfo"))
								                                    .addObject("dlretry", "Y");
					}
				}
			}			
		}
		catch(Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		return modelAndView;
	}
	
	//@RequestMapping(value = "/ScanFingerprint", method = RequestMethod.POST)
	//public @ResponseBody String CreateSessionForDL(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
	/**
	 * Supporting Ajax call after fingerprint scan.
	 * @param request
	 * @param response
	 * @param sessionHttp
	 */
	public void CreateSessionForDL(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		OutputStream out = null;
		PrintStream printStream = null;
		try {
			out = response.getOutputStream();
			printStream = new PrintStream(out);
					
			SessionDTO sessionDTO = new SessionDTO();
			Session session = new Session();
			
			session.setWorkstationIPAddress(getRemoteIP(request));
			session.setLanguageCode((String) sessionHttp.getAttribute("langIdCode"));
			session.setAdditionalTestFlag(examSessionData.getAdditionalTestFlag());
			sessionDTO.setSession(session);
			sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
			if (request.getParameter("dlId") != null) {
				sessionDTO.setDlNumber(request.getParameter("dlId").trim());
			}
			
			Context context = new InitialContext();
			UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
			ut.begin();
			sessionBusDelegate.createSession(sessionDTO);
			if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
				ut.commit();
				
				if (request.getParameter("dlId") != null) {
					sessionHttp.setAttribute("vaultId", sessionDTO.getSession().getVaultId());
					sessionHttp.setAttribute("applicationId", sessionDTO.getSession().getApplicationId());
					sessionHttp.setAttribute("sessionId", sessionDTO.getSession().getSessionId());
					sessionHttp.setAttribute("resumeExamId", sessionDTO.getResumeExamId());
					printStream.print("Success");
				}									
			}
			else {
				ut.rollback();
				if (sessionDTO.getErrorCode() == ErrorCode.NEED_STUDY) {
					printStream.print("NeedStudy");
				}
				else {
					printStream.print("Error");
				}
			}
		}
		catch(Exception e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
			printStream.print("Error");
		}
		return;
	}
	
	public void createAuditRecord_old(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		OutputStream out = null;
		PrintStream printStream = null;
		try {
			out = response.getOutputStream();
			printStream = new PrintStream(out);
					
			String terminalIP = getRemoteIP(request);
			String errorCode = request.getParameter("errorCode");
			String errorDesc = "Unknow Error";
			
			if (errorCode.equals("1")) {
				errorDesc = "There is some other session with the fingerprint device on the workstation";
			}
			else if (errorCode.equals("-1")) {
				errorDesc = "The application could not find the fingerprint device";
			}
			else if (errorCode.equals("-10")) {
				errorDesc = "A browser is already running the plugin";
			}
			else if (errorCode.equals("N")) {
				errorDesc = "The fingerprint is not matching from L1 Server";
			}
			else if (errorCode.equals("Q")) {
				errorDesc = "The fingerprint is in low quality";
			}
			else if (errorCode.equals("3T")) {
				errorDesc = "Reached max of 3 retries, go to secondary verification";
			}
			else if (errorCode.equals("NI")) {
				errorDesc = "Unable to retrieve information by DL number";
			}
	        
			if(logger.isInfoEnabled()) {
				logger.info(errorDesc);
			}
			IErrorWL errorWL = sessionBusDelegate.saveAudit("FINGERPRINT", "ERROR", "", errorDesc, terminalIP, Constant.LASTMODUSR_NME);
			
			if (errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
				printStream.print("Success"); 
			}
			else {
				printStream.print("Error");
			}
		} catch (IOException e) {
			handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);			
		}
		return;
	}
	
	/**
	 * Create Audit Record for fingerprint authentication.
	 * @param request
	 * @param response
	 * @param sessionHttp
	 */
	public void createAuditRecord(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		OutputStream out = null;
		PrintStream printStream = null;
		try {
			out = response.getOutputStream();
			printStream = new PrintStream(out);
					
			String terminalIP = getRemoteIP(request);
			Office office = sessionBusDelegate.getOfficeByTerminalIP(terminalIP);
			String errorCode = request.getParameter("errorCode");
			String dlNumber  = request.getParameter("dlNumber");
			String errorDesc = "Unknow Error";
			
			if (errorCode.equals("1")) {
				errorDesc = "There is some other session with the fingerprint device on the workstation";
			}
			else if (errorCode.equals("-1")) {
				errorDesc = "The application could not find the fingerprint device";
			}
			else if (errorCode.equals("-10")) {
				errorDesc = "A browser is already running the plugin";
			}
			else if (errorCode.equals("N")) {
				errorDesc = "The fingerprint is not matching from L1 Server";
			}
			else if (errorCode.equals("Q")) {
				errorDesc = "The fingerprint is in low quality";
			}
			else if (errorCode.equals("3T")) {
				errorDesc = "Reached max of 3 retries, go to secondary verification";
			}
			else if (errorCode.equals("NI")) {
				if (dlNumber.length() > 4) {
					errorDesc = "Unable to retrieve information by DL number ending " + dlNumber.substring(dlNumber.length()-4);
				}
				else {
					errorDesc = "Unable to retrieve information by DL number ending " + dlNumber;
				}
			}
			else if (errorCode.equals("NS")) {
				if (dlNumber.length() > 4) {
					errorDesc = "Need to study the handbook before returning to re-take the test for DL number ending " + dlNumber.substring(dlNumber.length()-4);
				}
				else {
					errorDesc = "Need to study the handbook before returning to re-take the test for DL number ending " + dlNumber;
				}
			}
			else if (errorCode.equals("L1F")) {
				errorDesc = "Fail to connect to L1 server";
			}
	        
			if(logger.isInfoEnabled()) {
				logger.info(errorDesc);
			}
			IErrorWL errorWL = sessionBusDelegate.saveAudit("FINGERPRINT", "ERROR", office.getL1ServerIpAddr(), errorDesc, terminalIP, Constant.LASTMODUSR_NME);
			
			if (errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
				printStream.print("Success"); 
			}
			else {
				printStream.print("Error");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);				
		}
		return;
	}
	
	public ModelAndView TestRulesScreen(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp, Lang command) {
		try {
			Integer part = Constant.ONE;
			if(request.getParameter("part") != null){
				part = Integer.parseInt(request.getParameter("part"));
			}
			String terminalIP = getRemoteIP(request);
			Office office = sessionBusDelegate.getOfficeByTerminalIP(terminalIP);
			
			return new ModelAndView("testrules").addObject("part",part).addObject("type", office.getOfficeTypeCode().trim())
					                            .addObject("timelimit",sessionBusDelegate.getScreenTimeout("testrules"));
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * Get remote IP address.
	 * @param request
	 * @return
	 */
	private String getRemoteIP(HttpServletRequest request) {
		String remoteIP = null;
		if (request.getHeader(Constant.REMOTE_IP) != null && !request.getHeader(Constant.REMOTE_IP).isEmpty()) {
			remoteIP = request.getHeader(Constant.REMOTE_IP).trim();
		}
		else {
			remoteIP = request.getHeader("X-FORWARDED-FOR");  
			if (remoteIP == null) {  
				remoteIP = request.getRemoteAddr();  
			}
			
			if (remoteIP.equals("0:0:0:0:0:0:0:1")) {
				//remoteIP = "165.153.66.205"; //UAT
				remoteIP = "165.153.122.172"; //Jawad/DEV
			}
		}
		return remoteIP;
	}

	/*
	 * This method is called to handle the barcode scan submission
	 */
	public ModelAndView ScanBarcode (HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp, Barcode command) {
		ModelAndView modelAndView = null;
		try {
			if(request.getMethod().equalsIgnoreCase("GET")) {
				modelAndView = new ModelAndView("scanbarcode");
			}
			else
			{
				Barcode barcodeCmnd = (Barcode) command;
				SessionDTO sessionDTO = new SessionDTO();
				Session session = new Session();
				session.setWorkstationIPAddress(getRemoteIP(request));
				//request.getHeader(Constant.REMOTE_IP).trim());
				//session.setWorkstationIPAddress("165.153.32.13");
				//System.out.println(request.getRemoteAddr());
				session.setLanguageCode((String) sessionHttp.getAttribute("langIdCode"));
				sessionDTO.setSession(session);
				sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
				sessionDTO.setDlNumber(barcodeCmnd.getDlNumberAfterTransformation().trim());
				try
				{
					Context context = new InitialContext();
					UserTransaction ut = (UserTransaction) context.lookup(Constant.USR_TRANSACTION);
					ut.begin();
					sessionBusDelegate.createSession(sessionDTO);
					if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						ut.commit();
						sessionHttp.setAttribute("vaultId", sessionDTO.getSession().getVaultId());
						sessionHttp.setAttribute("applicationId", sessionDTO.getSession().getApplicationId());
						sessionHttp.setAttribute("sessionId", sessionDTO.getSession().getSessionId());
						sessionHttp.setAttribute("resumeExamId", sessionDTO.getResumeExamId());
						sessionHttp.setAttribute("yobFailCounter", 0);
						modelAndView = new ModelAndView("redirect:YOBValidation.do");
					}
					else {
						ut.rollback();
						gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
						if(sessionDTO.getErrorCode() != ErrorCode.MISSING_SESSION && sessionDTO.getErrorCode() != ErrorCode.JDBC_FAILURE && sessionDTO.getErrorCode() != ErrorCode.ACCESS_FAILURE && sessionDTO.getErrorCode() != ErrorCode.CATCHALL_FAILURE && sessionDTO.getErrorCode() != ErrorCode.INTEGRITY_FAILURE) {
							errorModel.setErrorCode(sessionDTO.getErrorCode());
							logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
							modelAndView = new ModelAndView("error").addObject("errormodel", errorModel);
						}
						else {
							logger.error(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
							List<String> errors = new ArrayList<String>();
							errors.add(ErrorCode.ERROR_MESSAGE(sessionDTO.getErrorCode()));
							modelAndView = new ModelAndView("scanbarcode").addObject("errormodel", errorModel).addObject("errors", errors);
						}
					}
				}
				catch(Exception e) {
					logger.error(e);
					gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
					modelAndView = new ModelAndView("scanbarcode").addObject("errormodel", errorModel);
				}
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
		return modelAndView;
	}
	
	public ModelAndView EndSession(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		try {
			SessionDTO sessionDTO = new SessionDTO();
			Session session = new Session();
			session.setSessionId((Integer)sessionHttp.getAttribute("sessionId"));
			sessionDTO.setSession(session);
			sessionBusDelegate.terminateSession(sessionDTO);
			request.getSession().setAttribute("addtnl_messages_timeout",sessionBusDelegate.getScreenTimeout("addtnl_messages_screen"));
			gov.ca.dmv.AKT.presentation.Model.Error errorModel = new gov.ca.dmv.AKT.presentation.Model.Error();
			errorModel.setErrorCode(ErrorCode.SESSION_TERMINATED);
			if(logger.isInfoEnabled()) {
				logger.info(ErrorCode.ERROR_MESSAGE(ErrorCode.SESSION_TERMINATED));
			}
			if(request.getParameter("errormessage") != null) {
				List<String> errors = new ArrayList<String>();
				errors.add(request.getParameter("errormessage").trim());	
				return new ModelAndView("error").addObject("errormodel", errorModel).addObject("errors", errors);
			}
			else {
				return new ModelAndView("error").addObject("errormodel", errorModel);
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	public ModelAndView EndHttpSession(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		sessionHttp.invalidate();
		return new ModelAndView("redirect:InitialScreen.do");
	}
	
	/*public ModelAndView Navigate(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		return new ModelAndView("taketest");
	}*/
	
	public ModelAndView Navigate(HttpServletRequest request, HttpServletResponse response, HttpSession sessionHttp) {
		try {
			Integer resumeExamId = (Integer) sessionHttp.getAttribute("resumeExamId");
			
			String terminalIP = getRemoteIP(request);
			Office office = sessionBusDelegate.getOfficeByTerminalIP(terminalIP);
			//Check to see if additional tests exist
			String additionaTestsExist = String.valueOf(examSessionData.getAdditionalTestFlag());
			boolean skipSampleQuestion = office.getOfficeTypeCode().trim().equals(Constant.OFFICE_TYPE_DS) || office.getOfficeTypeCode().trim().equals(Constant.OFFICE_TYPE_OL);
			if(resumeExamId != null || skipSampleQuestion || additionaTestsExist == "true") {
				return new ModelAndView("perjury").addObject("timelimit",sessionBusDelegate.getScreenTimeout("perjury"));
			}
			else {
				return new ModelAndView("samplequestionconfirm").addObject("timelimit",sessionBusDelegate.getScreenTimeout("samplequestionconfirm"));
			}
		} catch (Exception e) {
			return handleException(e, logger, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE);
		}
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * This method is called for checking if the cache was loaded with seed data correctly and if there's a valid db connection.
	 * This information will be used for sending a nagios alert in case loading cache or connecting to the db failed.
	 */
	public ModelAndView HealthCheck(HttpServletRequest request, HttpServletResponse response) {
		HealthCheckDTO healthDTO = new HealthCheckDTO();
		sessionBusDelegate.getHealthReport(healthDTO);
		return new ModelAndView("healthcheck").addObject("dbstatus", healthDTO.getDbStatus()).addObject("cachestatus", healthDTO.getCacheStatus());
	}
}
