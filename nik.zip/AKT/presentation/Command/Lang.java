package gov.ca.dmv.AKT.presentation.Command;

public class Lang {

	private String language;
	private String langIdCode;

	public String getLangIdCode() {
		return langIdCode;
	}

	public void setLangIdCode(String langIdCode) {
		this.langIdCode = langIdCode;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
}
