package gov.ca.dmv.AKT.presentation.Command;

import gov.ca.dmv.AKT.presentation.Beans.TestPlan;

import java.util.List;

public class TestCommand {

	private String testId;
	private String testName;
	
	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getTestId() {
		return testId;
	}

	public void setTestId(String testId) {
		this.testId = testId;
	}
	
}
