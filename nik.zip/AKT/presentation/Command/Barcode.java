package gov.ca.dmv.AKT.presentation.Command;

import gov.ca.dmv.AKT.constants.Constant;

public class Barcode {

	private String dlNumber;

	public String getDlNumber() {
		return dlNumber;
	}

	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	
	public String getDlNumberAfterTransformation() {
		if(dlNumber != null && dlNumber.length() > 0) {
			if(dlNumber.length() > 9) {
				dlNumber = Constant.SINGLE_SPACE;
			}
			return dlNumber.substring(Constant.STARTING_POSITION, dlNumber.length()-Constant.ONE);
		}
		return dlNumber;
	}
}
