package gov.ca.dmv.AKT.presentation.Command;

public class FOMain {

	private String option;

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}
	
}
