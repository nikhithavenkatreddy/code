package gov.ca.dmv.AKT.presentation.Command;

public class DL {

	private String dl;

	public String getDl() {
		return dl;
	}

	public void setDl(String dl) {
		this.dl = dl;
	}
	
}
