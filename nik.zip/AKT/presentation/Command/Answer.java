package gov.ca.dmv.AKT.presentation.Command;

import java.util.Date;

public class Answer {

	private String answerGenId;
	private String questionPresentedOrder;
	private String examId;
	private Date   questionPresentedTime;
	private String answerChoice;
	
	public String getAnswerChoice() {
		return answerChoice;
	}

	public void setAnswerChoice(String answerChoice) {
		this.answerChoice = answerChoice;
	}

	public Date getQuestionPresentedTime() {
		return questionPresentedTime;
	}

	public void setQuestionPresentedTime(Date questionPresentedTime) {
		this.questionPresentedTime = questionPresentedTime;
	}

	public String getQuestionPresentedOrder() {
		return questionPresentedOrder;
	}

	public void setQuestionPresentedOrder(String questionPresentedOrder) {
		this.questionPresentedOrder = questionPresentedOrder;
	}

	public String getExamId() {
		return examId;
	}

	public void setExamId(String examId) {
		this.examId = examId;
	}

	public String getAnswerGenId() {
		return answerGenId;
	}

	public void setAnswerGenId(String answerGenId) {
		this.answerGenId = answerGenId;
	}
	
}
