package gov.ca.dmv.AKT.presentation.Command;

import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;

import java.util.List;

public class PrintTests {

	private List<ExamTestLang> examTestLangList;
	private boolean            answerKey;
	private Integer            selectedExamId;
	private String             back;
	private String             dl;
	private String			   lastName;
	private boolean            finishedTest;
	private String  		   officeId;
	
	public boolean isFinishedTest() {
		return finishedTest;
	}

	public void setFinishedTest(boolean finishedTest) {
		this.finishedTest = finishedTest;
	}

	public String getDl() {
		return dl;
	}

	public void setDl(String dl) {
		this.dl = dl;
	}

	public String getBack() {
		return back;
	}

	public void setBack(String back) {
		this.back = back;
	}

	public Integer getSelectedExamId() {
		return selectedExamId;
	}

	public void setSelectedExamId(Integer selectedExamId) {
		this.selectedExamId = selectedExamId;
	}

	public boolean isAnswerKey() {
		return answerKey;
	}

	public void setAnswerKey(boolean answerKey) {
		this.answerKey = answerKey;
	}

	public List<ExamTestLang> getExamTestLangList() {
		return examTestLangList;
	}

	public void setExamTestLangList(List<ExamTestLang> examTestLangList) {
		this.examTestLangList = examTestLangList;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
}
