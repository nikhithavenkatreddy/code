package gov.ca.dmv.AKT.presentation.Command;

public class UpdateAnswer {

	private String answerO;
	private String answerId1;
	private String answerText1;
	private String answerStatus1;
	private String answerId2;
	private String answerText2;
	private String answerStatus2;
	private String answerId3;
	private String answerText3;
	private String answerStatus3;
	private String answerId4;
	private String answerText4;
	private String answerStatus4;
	private String questionLangId;
	
	public String getAnswerO() {
		return answerO;
	}
	public void setAnswerO(String answerO) {
		this.answerO = answerO;
	}
	public String getAnswerId1() {
		return answerId1;
	}
	public void setAnswerId1(String answerId1) {
		this.answerId1 = answerId1;
	}
	public String getAnswerText1() {
		return answerText1;
	}
	public void setAnswerText1(String answerText1) {
		this.answerText1 = answerText1;
	}
	public String getAnswerStatus1() {
		return answerStatus1;
	}
	public void setAnswerStatus1(String answerStatus1) {
		this.answerStatus1 = answerStatus1;
	}
	public String getAnswerId2() {
		return answerId2;
	}
	public void setAnswerId2(String answerId2) {
		this.answerId2 = answerId2;
	}
	public String getAnswerText2() {
		return answerText2;
	}
	public void setAnswerText2(String answerText2) {
		this.answerText2 = answerText2;
	}
	public String getAnswerStatus2() {
		return answerStatus2;
	}
	public void setAnswerStatus2(String answerStatus2) {
		this.answerStatus2 = answerStatus2;
	}
	public String getAnswerId3() {
		return answerId3;
	}
	public void setAnswerId3(String answerId3) {
		this.answerId3 = answerId3;
	}
	public String getAnswerText3() {
		return answerText3;
	}
	public void setAnswerText3(String answerText3) {
		this.answerText3 = answerText3;
	}
	public String getAnswerStatus3() {
		return answerStatus3;
	}
	public void setAnswerStatus3(String answerStatus3) {
		this.answerStatus3 = answerStatus3;
	}
	public String getAnswerId4() {
		return answerId4;
	}
	public void setAnswerId4(String answerId4) {
		this.answerId4 = answerId4;
	}
	public String getAnswerText4() {
		return answerText4;
	}
	public void setAnswerText4(String answerText4) {
		this.answerText4 = answerText4;
	}
	public String getAnswerStatus4() {
		return answerStatus4;
	}
	public void setAnswerStatus4(String answerStatus4) {
		this.answerStatus4 = answerStatus4;
	}
	public String getQuestionLangId() {
		return questionLangId;
	}
	public void setQuestionLangId(String questionLangId) {
		this.questionLangId = questionLangId;
	}
	
}
