package gov.ca.dmv.AKT.presentation.Command;

public class ModifyQuestion {

	private String autoGenId;
	private String categoryId;
	private char   quesAnswFlag;
	
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getAutoGenId() {
		return autoGenId;
	}
	public void setAutoGenId(String autoGenId) {
		this.autoGenId = autoGenId;
	}
	public char getQuesAnswFlag() {
		return quesAnswFlag;
	}
	public void setQuesAnswFlag(char quesAnswFlag) {
		this.quesAnswFlag = quesAnswFlag;
	}
	
}
