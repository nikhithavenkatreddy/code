package gov.ca.dmv.AKT.presentation.Command;

public class Exam {

	private String examId;

	public String getExamId() {
		return examId;
	}

	public void setExamId(String examId) {
		this.examId = examId;
	}
	
}
