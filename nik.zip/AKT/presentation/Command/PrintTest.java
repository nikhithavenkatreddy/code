package gov.ca.dmv.AKT.presentation.Command;

public class PrintTest {

	private String testId;
	private String langId;
	private Integer numberTests;
	
	public Integer getNumberTests() {
		return numberTests;
	}
	public void setNumberTests(Integer numberTests) {
		this.numberTests = numberTests;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	
}
