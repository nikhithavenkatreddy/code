package gov.ca.dmv.AKT.presentation.Command;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Question;

import java.util.Date;

public class CreateParentQuestion {

	private String       questionId;
	private String       questionStatus;
	private String       categoryId;
	private String       testId;
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getQuestionStatus() {
		return questionStatus;
	}
	public void setQuestionStatus(String questionStatus) {
		this.questionStatus = questionStatus;
	}
	public Question createQuestion() {
		Question question = new Question();
		question.setQuestionId(getQuestionId().trim());
		question.setQuestionStatus(getQuestionStatus().trim());
		question.setLastModUsername(Constant.LASTMODUSR_NME);
		question.setLastModUserTime(new Date());
		question.setChangeReviewStatusCode(Constant.SINGLE_SPACE);
		return question;
	}
}
