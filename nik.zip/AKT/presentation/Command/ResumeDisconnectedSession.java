package gov.ca.dmv.AKT.presentation.Command;

public class ResumeDisconnectedSession {

	private int examId;

	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}
	
}
