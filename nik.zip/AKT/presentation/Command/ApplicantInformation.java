package gov.ca.dmv.AKT.presentation.Command;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.ExamHistory;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.ArrayList;
import java.util.List;

public class ApplicantInformation {

	private String       lastName;
	private String       lastNameError;
	private String       firstName;			
//	private String       firstNameError;	//First Name not a required field - Defect #181
	private String       dob;
	private String       dobError;
	private String       dl;
	private String       dlError;
	private String       state;
	private String       stateError;
	private boolean      audio;
	private boolean      video;
	private List<ExamHistory> examHistList;
	private String       testListError;
	private String       heading;
	

	
	public List<ExamHistory> getExamHistList() {
		return examHistList;
	}
	public void setExamHistList(List<ExamHistory> examHistList) {
		this.examHistList = examHistList;
	}
	public String getLastNameError() {
		return lastNameError;
	}
	public void setLastNameError(String lastNameError) {
		this.lastNameError = lastNameError;
	}
//	public String getFirstNameError() {
//		return firstNameError;
//	}
//	public void setFirstNameError(String firstNameError) {
//		this.firstNameError = firstNameError;
//	}
	public String getDobError() {
		return dobError;
	}
	public void setDobError(String dobError) {
		this.dobError = dobError;
	}
	public String getDlError() {
		return dlError;
	}
	public void setDlError(String dlError) {
		this.dlError = dlError;
	}
	public String getTestListError() {
		return testListError;
	}
	public void setTestListError(String testListError) {
		this.testListError = testListError;
	}
	public String getHeading() {
		return heading;
	}
	public void setHeading(String heading) {
		this.heading = heading;
	}
	public boolean isAudio() {
		return audio;
	}
	public void setAudio(boolean audio) {
		this.audio = audio;
	}
	public boolean isVideo() {
		return video;
	}
	public void setVideo(boolean video) {
		this.video = video;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDl() {
		return dl;
	}
	public void setDl(String dl) {
		this.dl = dl;
	}

	public List<String> getTestList() {
		List<String> testList= new ArrayList<String>();
		for(ExamHistory examhist: examHistList){
			testList.add(examhist.getEaseTestId());
		}		
		return testList;
	}
	
	public void setHeadingBasedOnGroup(String group) {
		setHeading(Constant.FOD_HEADER);
		if(group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			setHeading(Constant.DS_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			setHeading(Constant.OL_HEADER);
		}
	}
	public void setTestListForView(List<Test> testList) {
		List<ExamHistory> examHistList1= new ArrayList<ExamHistory>();	
		for(Test test:testList){
			ExamHistory examhist = new ExamHistory();
			examHistList1.add(examhist);
		}
		examHistList = examHistList1;
	}
	public void getCheckedExamHistList() {
		List<ExamHistory> examHistList1= new ArrayList<ExamHistory>();	
		for(ExamHistory examhist: examHistList){
			if(examhist.getEaseTestId()!=null && examhist.getEaseTestId().length()>1){
				examHistList1.add(examhist);
			}
		}
		examHistList = examHistList1;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStateError() {
		return stateError;
	}
	public void setStateError(String stateError) {
		this.stateError = stateError;
	}
}
