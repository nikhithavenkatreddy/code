package gov.ca.dmv.AKT.presentation.Command;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;

public class UpdateQuestion {
	
	private String flag;
	private String fromPage;
	
	// Question fields
	private String autoGenId;
	private String questionId;
	private String questionText;
	private String signImage;
	private String questionAudio;
	private String questionVideo;
	private String questionStatus;
	
	private String handbookRef;
	private String categoryId;
	private String langId;
	
	// Answer fields
	private String answerO;
	
	private String answerGenId1;
	private String answerId1;
	private String answerText1;
	private String answerStatus1;
	private String answerSignImage1;
	private String answerAudio1;
	private String answerVideo1;
	
	private String answerGenId2;
	private String answerId2;
	private String answerText2;
	private String answerStatus2;
	private String answerSignImage2;
	private String answerAudio2;
	private String answerVideo2;
	
	private String answerGenId3;
	private String answerId3;
	private String answerText3;
	private String answerStatus3;
	private String answerSignImage3;
	private String answerAudio3;
	private String answerVideo3;
	
	private String answerGenId4;
	private String answerId4;
	private String answerText4;
	private String answerStatus4;
	private String answerSignImage4;
	private String answerAudio4;
	private String answerVideo4;
	
	public String getQuestionAudio() {
		return questionAudio;
	}
	public void setQuestionAudio(String questionAudio) {
		this.questionAudio = questionAudio;
	}
	public String getQuestionVideo() {
		return questionVideo;
	}
	public void setQuestionVideo(String questionVideo) {
		this.questionVideo = questionVideo;
	}
	public String getAnswerAudio1() {
		return answerAudio1;
	}
	public void setAnswerAudio1(String answerAudio1) {
		this.answerAudio1 = answerAudio1;
	}
	public String getAnswerVideo1() {
		return answerVideo1;
	}
	public void setAnswerVideo1(String answerVideo1) {
		this.answerVideo1 = answerVideo1;
	}
	public String getAnswerAudio2() {
		return answerAudio2;
	}
	public void setAnswerAudio2(String answerAudio2) {
		this.answerAudio2 = answerAudio2;
	}
	public String getAnswerVideo2() {
		return answerVideo2;
	}
	public void setAnswerVideo2(String answerVideo2) {
		this.answerVideo2 = answerVideo2;
	}
	public String getAnswerAudio3() {
		return answerAudio3;
	}
	public void setAnswerAudio3(String answerAudio3) {
		this.answerAudio3 = answerAudio3;
	}
	public String getAnswerVideo3() {
		return answerVideo3;
	}
	public void setAnswerVideo3(String answerVideo3) {
		this.answerVideo3 = answerVideo3;
	}
	public String getAnswerAudio4() {
		return answerAudio4;
	}
	public void setAnswerAudio4(String answerAudio4) {
		this.answerAudio4 = answerAudio4;
	}
	public String getAnswerVideo4() {
		return answerVideo4;
	}
	public void setAnswerVideo4(String answerVideo4) {
		this.answerVideo4 = answerVideo4;
	}
	public String getAnswerSignImage1() {
		return answerSignImage1;
	}
	public void setAnswerSignImage1(String answerSignImage1) {
		this.answerSignImage1 = answerSignImage1;
	}
	public String getAnswerSignImage2() {
		return answerSignImage2;
	}
	public void setAnswerSignImage2(String answerSignImage2) {
		this.answerSignImage2 = answerSignImage2;
	}
	public String getAnswerSignImage3() {
		return answerSignImage3;
	}
	public void setAnswerSignImage3(String answerSignImage3) {
		this.answerSignImage3 = answerSignImage3;
	}
	public String getAnswerSignImage4() {
		return answerSignImage4;
	}
	public void setAnswerSignImage4(String answerSignImage4) {
		this.answerSignImage4 = answerSignImage4;
	}
	public String getAutoGenId() {
		return autoGenId;
	}
	public void setAutoGenId(String autoGenId) {
		this.autoGenId = autoGenId;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getFromPage() {
		return fromPage;
	}
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getQuestionText() {
		return questionText;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	public String getSignImage() {
		return signImage;
	}
	public void setSignImage(String signImage) {
		this.signImage = signImage;
	}
	public String getQuestionStatus() {
		return questionStatus;
	}
	public void setQuestionStatus(String questionStatus) {
		this.questionStatus = questionStatus;
	}
	public String getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(String handbookRef) {
		this.handbookRef = handbookRef;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getAnswerO() {
		return answerO;
	}
	public void setAnswerO(String answerO) {
		this.answerO = answerO;
	}
	public String getAnswerId1() {
		return answerId1;
	}
	public void setAnswerId1(String answerId1) {
		this.answerId1 = answerId1;
	}
	public String getAnswerText1() {
		return answerText1;
	}
	public void setAnswerText1(String answerText1) {
		this.answerText1 = answerText1;
	}
	public String getAnswerStatus1() {
		return answerStatus1;
	}
	public void setAnswerStatus1(String answerStatus1) {
		this.answerStatus1 = answerStatus1;
	}
	public String getAnswerId2() {
		return answerId2;
	}
	public void setAnswerId2(String answerId2) {
		this.answerId2 = answerId2;
	}
	public String getAnswerText2() {
		return answerText2;
	}
	public void setAnswerText2(String answerText2) {
		this.answerText2 = answerText2;
	}
	public String getAnswerStatus2() {
		return answerStatus2;
	}
	public void setAnswerStatus2(String answerStatus2) {
		this.answerStatus2 = answerStatus2;
	}
	public String getAnswerId3() {
		return answerId3;
	}
	public void setAnswerId3(String answerId3) {
		this.answerId3 = answerId3;
	}
	public String getAnswerText3() {
		return answerText3;
	}
	public void setAnswerText3(String answerText3) {
		this.answerText3 = answerText3;
	}
	public String getAnswerStatus3() {
		return answerStatus3;
	}
	public void setAnswerStatus3(String answerStatus3) {
		this.answerStatus3 = answerStatus3;
	}
	public String getAnswerId4() {
		return answerId4;
	}
	public void setAnswerId4(String answerId4) {
		this.answerId4 = answerId4;
	}
	public String getAnswerText4() {
		return answerText4;
	}
	public void setAnswerText4(String answerText4) {
		this.answerText4 = answerText4;
	}
	public String getAnswerStatus4() {
		return answerStatus4;
	}
	public void setAnswerStatus4(String answerStatus4) {
		this.answerStatus4 = answerStatus4;
	}
	public void updateCommandWithAnswerList(List<Answer> answerList) {
		Iterator<Answer> i = answerList.iterator();
		Answer ans1 = i.next();
		setAnswerGenId1(ans1.getAnswerGenId().toString());
		setAnswerId1(ans1.getAnswerId());
		if(ans1.isCorrectAnswerInd())
			setAnswerO(String.valueOf(Constant.ONE));
		setAnswerStatus1(ans1.getAnswerStatus());
		setAnswerText1(ans1.getAnswerText());
		setAnswerSignImage1(ans1.getSignImage());
		setAnswerAudio1(ans1.getAnswerAudio());
		setAnswerVideo1(ans1.getAnswerVideo());
		
		Answer ans2 = i.next();
		setAnswerGenId2(ans2.getAnswerGenId().toString());
		setAnswerId2(ans2.getAnswerId());
		if(ans2.isCorrectAnswerInd())
			setAnswerO(String.valueOf(Constant.TWO));
		setAnswerStatus2(ans2.getAnswerStatus());
		setAnswerText2(ans2.getAnswerText());
		setAnswerSignImage2(ans2.getSignImage());
		setAnswerAudio2(ans2.getAnswerAudio());
		setAnswerVideo2(ans2.getAnswerVideo());
		
		if(answerList.size() > 2) {
			Answer ans3 = i.next();
			setAnswerGenId3(ans3.getAnswerGenId().toString());
			setAnswerId3(ans3.getAnswerId());
			if(ans3.isCorrectAnswerInd())
				setAnswerO(String.valueOf(Constant.THREE));
			setAnswerStatus3(ans3.getAnswerStatus());
			setAnswerText3(ans3.getAnswerText());
			setAnswerSignImage3(ans3.getSignImage());
			setAnswerAudio3(ans3.getAnswerAudio());
			setAnswerVideo3(ans3.getAnswerVideo());
		}
		
		if(answerList.size() > 3) {
			Answer ans4 = i.next();
			setAnswerGenId4(ans4.getAnswerGenId().toString());
			setAnswerId4(ans4.getAnswerId());
			if(ans4.isCorrectAnswerInd())
				setAnswerO(String.valueOf(Constant.FOUR));
			setAnswerStatus4(ans4.getAnswerStatus());
			setAnswerText4(ans4.getAnswerText());
			setAnswerSignImage4(ans4.getSignImage());
			setAnswerAudio4(ans4.getAnswerAudio());
			setAnswerVideo4(ans4.getAnswerVideo());
		}
	}
	public void updateCommandWithQuestionLang(QuestionLang questionLang) {
		setAutoGenId(String.valueOf(questionLang.getQuestionGenId()));
		setQuestionId(questionLang.getQuestionId());
		setQuestionStatus(questionLang.getQuestionLangStatus());
		setQuestionText(questionLang.getQuestionText());
		setSignImage(questionLang.getSignImage());
		setQuestionAudio(questionLang.getQuestionAudio());
		setQuestionVideo(questionLang.getQuestionVideo());
	}
	public QuestionLang createQuestionLang() {
		QuestionLang questionLang = new QuestionLang();
		questionLang.setQuestionGenId(Integer.parseInt(getAutoGenId().trim()));
		questionLang.setHandbookRef(getHandbookRef().trim());
		questionLang.setLangId(getLangId().trim());
		//?????????//
		questionLang.setLastModUsername(Constant.LASTMODUSR_NME);
		//????????//
		questionLang.setLastModUserTime(new Date());
		questionLang.setQuestionId(getQuestionId().trim());
		questionLang.setQuestionLangId(getQuestionId().trim() + getLangId().trim());
		questionLang.setQuestionLangStatus(getQuestionStatus().trim());
		questionLang.setQuestionText(getQuestionText().trim());
		questionLang.setSignImage(getSignImage().trim());
		questionLang.setQuestionAudio(getQuestionAudio().trim());
		questionLang.setQuestionVideo(getQuestionVideo().trim());
		return questionLang;
	}
	public List<Answer> createAnswerList() {
		List<Answer> answerList = new ArrayList<Answer>();
		
		// Answer1
		Answer answer1 = new Answer();
		if (getAnswerGenId1() != null && !getAnswerGenId1().equals("")) {
			answer1.setAnswerGenId(Integer.parseInt(getAnswerGenId1()));
		}
		answer1.setQuestionGenId(Integer.parseInt(getAutoGenId().trim()));
		answer1.setAnswerId(getAnswerId1().trim());
		answer1.setAnswerStatus(getAnswerStatus1().trim());
		answer1.setAnswerText(getAnswerText1().trim());
		if(getAnswerO().trim().equals(String.valueOf(Constant.ONE)))
			answer1.setCorrectAnswerInd(true);
		else
			answer1.setCorrectAnswerInd(false);
		//???
		answer1.setLastModUsername(Constant.LASTMODUSR_NME);
		//???
		answer1.setLastModUserTime(new Date());
		answer1.setSignImage(getAnswerSignImage1().trim());
		answer1.setAnswerAudio(getAnswerAudio1().trim());
		answer1.setAnswerVideo(getAnswerVideo1().trim());
		answerList.add(answer1);
		
		// Answer 2
		Answer answer2 = new Answer();
		if (getAnswerGenId2() != null && !getAnswerGenId2().equals("")) {
			answer2.setAnswerGenId(Integer.parseInt(getAnswerGenId2()));
		}
		answer2.setQuestionGenId(Integer.parseInt(getAutoGenId().trim()));
		answer2.setAnswerId(getAnswerId2().trim());
		answer2.setAnswerStatus(getAnswerStatus2().trim());
		answer2.setAnswerText(getAnswerText2().trim());
		if(getAnswerO().equals(String.valueOf(Constant.TWO)))
			answer2.setCorrectAnswerInd(true);
		else
			answer2.setCorrectAnswerInd(false);
		//???
		answer2.setLastModUsername(Constant.LASTMODUSR_NME);
		//???
		answer2.setLastModUserTime(new Date());
		answer2.setSignImage(getAnswerSignImage2().trim());
		answer2.setAnswerAudio(getAnswerAudio2().trim());
		answer2.setAnswerVideo(getAnswerVideo2().trim());
		answerList.add(answer2);
		
		// Answer 3
		if(getAnswerId3() != null && !getAnswerId3().trim().equals(Constant.NULL_STRING)) {
			Answer answer3 = new Answer();
			if (getAnswerGenId3() != null && !getAnswerGenId3().equals("")) {
				answer3.setAnswerGenId(Integer.parseInt(getAnswerGenId3()));
			}
			answer3.setQuestionGenId(Integer.parseInt(getAutoGenId().trim()));
			answer3.setAnswerId(getAnswerId3().trim());
			answer3.setAnswerStatus(getAnswerStatus3().trim());
			answer3.setAnswerText(getAnswerText3().trim());
			if(getAnswerO().trim().equals(String.valueOf(Constant.THREE)))
				answer3.setCorrectAnswerInd(true);
			else
				answer3.setCorrectAnswerInd(false);
			//???
			answer3.setLastModUsername(Constant.LASTMODUSR_NME);
			//???
			answer3.setLastModUserTime(new Date());
			answer3.setSignImage(getAnswerSignImage3().trim());
			answer3.setAnswerAudio(getAnswerAudio3().trim());
			answer3.setAnswerVideo(getAnswerVideo3().trim());
			answerList.add(answer3);
		}
		
		// Answer 4
		if(getAnswerId4() != null && !getAnswerId4().trim().equals(Constant.NULL_STRING)) {
			Answer answer4 = new Answer();
			if (getAnswerGenId4() != null && !getAnswerGenId4().equals("")) {
				answer4.setAnswerGenId(Integer.parseInt(getAnswerGenId4()));
			}
			answer4.setQuestionGenId(Integer.parseInt(getAutoGenId().trim()));
			answer4.setAnswerId(getAnswerId4().trim());
			answer4.setAnswerStatus(getAnswerStatus4().trim());
			answer4.setAnswerText(getAnswerText4().trim());
			if(getAnswerO().trim().equals(String.valueOf(Constant.FOUR)))
				answer4.setCorrectAnswerInd(true);
			else
				answer4.setCorrectAnswerInd(false);
			//???
			answer4.setLastModUsername(Constant.LASTMODUSR_NME);
			//???
			answer4.setLastModUserTime(new Date());
			answer4.setSignImage(getAnswerSignImage4().trim());
			answer4.setAnswerAudio(getAnswerAudio4().trim());
			answer4.setAnswerVideo(getAnswerVideo4().trim());
			answerList.add(answer4);
		}
		return answerList;
	}
	public String getAnswerGenId1() {
		return answerGenId1;
	}
	public void setAnswerGenId1(String answerGenId1) {
		this.answerGenId1 = answerGenId1;
	}
	public String getAnswerGenId2() {
		return answerGenId2;
	}
	public void setAnswerGenId2(String answerGenId2) {
		this.answerGenId2 = answerGenId2;
	}
	public String getAnswerGenId3() {
		return answerGenId3;
	}
	public void setAnswerGenId3(String answerGenId3) {
		this.answerGenId3 = answerGenId3;
	}
	public String getAnswerGenId4() {
		return answerGenId4;
	}
	public void setAnswerGenId4(String answerGenId4) {
		this.answerGenId4 = answerGenId4;
	}
}
