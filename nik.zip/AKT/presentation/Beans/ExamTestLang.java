package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;
import java.util.List;

public class ExamTestLang {

	private Integer    examId;
	private String     testLangName;
	private String     langId;
	private String     language;
	private boolean    printChecked;
	private boolean    disabled;
	private List<Lang> langList;
	private String     printReprintValue;
	private Integer    score;
	private boolean    completed;
	private boolean    cdl;
	private String     username;
	private String     password;
	private String     result;
	private Date       examEndTime;
	private String     secondaryVerification;
	private String     testId;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isCdl() {
		return cdl;
	}
	public void setCdl(boolean cdl) {
		this.cdl = cdl;
	}
	public boolean isCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getPrintReprintValue() {
		return printReprintValue;
	}
	public void setPrintReprintValue(String printReprintValue) {
		this.printReprintValue = printReprintValue;
	}
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public boolean isDisabled() {
		return disabled;
	}
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}
	public boolean isPrintChecked() {
		return printChecked;
	}
	public void setPrintChecked(boolean printChecked) {
		this.printChecked = printChecked;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public String getTestLangName() {
		return testLangName;
	}
	public void setTestLangName(String testLangName) {
		this.testLangName = testLangName;
	}
	public Date getExamEndTime() {
		return examEndTime;
	}
	public void setExamEndTime(Date examEndTime) {
		this.examEndTime = examEndTime;
	}
	public String getSecondaryVerification() {
		return secondaryVerification;
	}
	public void setSecondaryVerification(String secondaryVerification) {
		this.secondaryVerification = secondaryVerification;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
}
