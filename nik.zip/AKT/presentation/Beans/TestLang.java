package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class TestLang {

	private String testLangId;
	private String testId;
	private String langId;
	private String testLangName;
	private String testLangStatus;
	private String lastModUsername;
	private Date   lastModUserTime;
	
	public String getTestLangId() {
		return testLangId;
	}
	public void setTestLangId(String testLangId) {
		this.testLangId = testLangId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getTestLangName() {
		return testLangName;
	}
	public void setTestLangName(String testLangName) {
		this.testLangName = testLangName;
	}
	public String getTestLangStatus() {
		return testLangStatus;
	}
	public void setTestLangStatus(String testLangStatus) {
		this.testLangStatus = testLangStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
