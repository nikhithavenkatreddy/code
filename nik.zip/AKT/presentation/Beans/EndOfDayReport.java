package gov.ca.dmv.AKT.presentation.Beans;

/**
 * I am created for holding data for End Of Day Report.
 * @author MWXXW
 *
 */
public class EndOfDayReport {

	private String officeId;
	private int totalTestTakenCnt;
	private int nonPrintedPassCnt;
	private int nonPrintedFailCnt;
	private int printedPassCnt;
	private int printedFailCnt;
	
	private int pausedTestsCnt;
	private int quitTestsCnt;
	private int timeoutTestsCnt;
	private int disconnectedTestsCnt;
	
	public int getTotalTestTakenCnt() {
		totalTestTakenCnt = nonPrintedPassCnt + nonPrintedFailCnt + printedPassCnt + printedFailCnt;
		return totalTestTakenCnt;
	}

	public int getNonPrintedPassCnt() {
		return nonPrintedPassCnt;
	}

	public void setNonPrintedPassCnt(int nonPrintedPassCnt) {
		this.nonPrintedPassCnt = nonPrintedPassCnt;
	}

	public int getNonPrintedFailCnt() {
		return nonPrintedFailCnt;
	}

	public void setNonPrintedFailCnt(int nonPrintedFailCnt) {
		this.nonPrintedFailCnt = nonPrintedFailCnt;
	}

	public int getPrintedPassCnt() {
		return printedPassCnt;
	}

	public void setPrintedPassCnt(int printedPassCnt) {
		this.printedPassCnt = printedPassCnt;
	}

	public int getPrintedFailCnt() {
		return printedFailCnt;
	}

	public void setPrintedFailCnt(int printedFailCnt) {
		this.printedFailCnt = printedFailCnt;
	}

	public int getPausedTestsCnt() {
		return pausedTestsCnt;
	}

	public void setPausedTestsCnt(int pausedTestsCnt) {
		this.pausedTestsCnt = pausedTestsCnt;
	}

	public int getQuitTestsCnt() {
		return quitTestsCnt;
	}

	public void setQuitTestsCnt(int quitTestsCnt) {
		this.quitTestsCnt = quitTestsCnt;
	}

	public int getTimeoutTestsCnt() {
		return timeoutTestsCnt;
	}

	public void setTimeoutTestsCnt(int timeoutTestsCnt) {
		this.timeoutTestsCnt = timeoutTestsCnt;
	}

	public int getDisconnectedTestsCnt() {
		return disconnectedTestsCnt;
	}

	public void setDisconnectedTestsCnt(int disconnectedTestsCnt) {
		this.disconnectedTestsCnt = disconnectedTestsCnt;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}	
}
