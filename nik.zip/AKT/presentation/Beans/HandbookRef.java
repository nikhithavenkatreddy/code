package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class HandbookRef {

	private String handbookRef;
	private String handbookSectionName;
	private String handbookSectionDesc;
	private String langId;
	private String langName;
	private String lastModUsername;
	private Date lastModUserTime;
	
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(String handbookRef) {
		this.handbookRef = handbookRef;
	}
	public String getHandbookSectionName() {
		return handbookSectionName;
	}
	public void setHandbookSectionName(String handbookSectionName) {
		this.handbookSectionName = handbookSectionName;
	}
	public String getHandbookSectionDesc() {
		return handbookSectionDesc;
	}
	public void setHandbookSectionDesc(String handbookSectionDesc) {
		this.handbookSectionDesc = handbookSectionDesc;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getLangName() {
		return langName;
	}
	public void setLangName(String langName) {
		this.langName = langName;
	}
	
}
