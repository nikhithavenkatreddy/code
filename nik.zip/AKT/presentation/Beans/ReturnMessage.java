package gov.ca.dmv.AKT.presentation.Beans;

public class ReturnMessage {

	private boolean        error;
	private Integer        autoGenId;
	private int            errorCode;
	private String         errorMsg;
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public Integer getAutoGenId() {
		return autoGenId;
	}
	public void setAutoGenId(Integer autoGenId) {
		this.autoGenId = autoGenId;
	}

}
