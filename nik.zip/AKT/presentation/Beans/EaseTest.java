package gov.ca.dmv.AKT.presentation.Beans;

public class EaseTest {

	private String easeTestId;
	private String easeStatusIndicator;
	
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getEaseStatusIndicator() {
		return easeStatusIndicator;
	}
	public void setEaseStatusIndicator(String easeStatusIndicator) {
		this.easeStatusIndicator = easeStatusIndicator;
	}
	
}
