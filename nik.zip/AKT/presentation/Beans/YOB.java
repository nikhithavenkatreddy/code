package gov.ca.dmv.AKT.presentation.Beans;

public class YOB {
	private String  yob;
	private Integer vaultId;
	private String  dob;
	private String  threeCharLastName;
	
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getThreeCharLastName() {
		return threeCharLastName;
	}

	public void setThreeCharLastName(String threeCharLastName) {
		this.threeCharLastName = threeCharLastName;
	}

	public String getYob() {
		return yob;
	}

	public void setYob(String yob) {
		this.yob = yob;
	}

	public Integer getVaultId() {
		return vaultId;
	}

	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
}
