package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class QuestionLang {

	private Integer questionGenId;
	private String  questionId;
	private String  questionLangId;
	private String  langId;
	private String  signImage;
	private String  questionText;
	private String  handbookRef;
	private String  questionLangStatus;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private String  questionAudio;
	private String  questionVideo;
	private String  changeReviewStatusCode;
	
	public String getChangeReviewStatusCode() {
		return changeReviewStatusCode;
	}
	public void setChangeReviewStatusCode(String changeReviewStatusCode) {
		this.changeReviewStatusCode = changeReviewStatusCode;
	}
	public String getQuestionAudio() {
		return questionAudio;
	}
	public void setQuestionAudio(String questionAudio) {
		this.questionAudio = questionAudio;
	}
	public String getQuestionVideo() {
		return questionVideo;
	}
	public void setQuestionVideo(String questionVideo) {
		this.questionVideo = questionVideo;
	}
	public Integer getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(Integer questionGenId) {
		this.questionGenId = questionGenId;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getQuestionLangId() {
		return questionLangId;
	}
	public void setQuestionLangId(String questionLangId) {
		this.questionLangId = questionLangId;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getSignImage() {
		return signImage;
	}
	public void setSignImage(String signImage) {
		this.signImage = signImage;
	}
	public String getQuestionText() {
		return questionText;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	public String getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(String handbookRef) {
		this.handbookRef = handbookRef;
	}
	public String getQuestionLangStatus() {
		return questionLangStatus;
	}
	public void setQuestionLangStatus(String questionLangStatus) {
		this.questionLangStatus = questionLangStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
