package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class ActiveSession {

	private String    workstationId;
	private Integer   examId;
	private Applicant applicant;
	private String    testName;
	private Integer   vaultId;
	private Integer   applicationId;
	private Date      examStartTime;
	
	public Date getExamStartTime() {
		return examStartTime;
	}
	public void setExamStartTime(Date examStartTime) {
		this.examStartTime = examStartTime;
	}
	public String getWorkstationId() {
		return workstationId;
	}
	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Applicant getApplicant() {
		return applicant;
	}
	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public Integer getVaultId() {
		return vaultId;
	}
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	
}
