package gov.ca.dmv.AKT.presentation.Beans;

import java.util.List;

public class Credential {
	private String firstName;
	private String lastName;
	private List<String> groups;
	private String fieldOffId;
	private String techId;
	
}
