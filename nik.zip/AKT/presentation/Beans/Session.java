package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class Session {

	private Integer sessionId;
	private Integer applicationId;
	private String  workstationIPAddress;
	private String  officeId;
	private Date    sessionStartTime;
	private Date    sessionEndTime;
	private String  yobValidationFlag;
	private Date    yobOverrideTime;
	private String  languageCode;
	private Integer vaultId;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private String sessionStatusCode;
	private Boolean additionalTestFlag;
	
	
	public Boolean getAdditionalTestFlag() {
		return additionalTestFlag;
	}
	public void setAdditionalTestFlag(Boolean additionalTestFlag) {
		this.additionalTestFlag = additionalTestFlag;
	}
	public String getSessionStatusCode() {
		return sessionStatusCode;
	}
	public void setSessionStatusCode(String sessionStatusCode) {
		this.sessionStatusCode = sessionStatusCode;
	}
	public Integer getSessionId() {
		return sessionId;
	}
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public String getWorkstationIPAddress() {
		return workstationIPAddress;
	}
	public void setWorkstationIPAddress(String workstationIPAddress) {
		this.workstationIPAddress = workstationIPAddress;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public Date getSessionStartTime() {
		return sessionStartTime;
	}
	public void setSessionStartTime(Date sessionStartTime) {
		this.sessionStartTime = sessionStartTime;
	}
	public Date getSessionEndTime() {
		return sessionEndTime;
	}
	public void setSessionEndTime(Date sessionEndTime) {
		this.sessionEndTime = sessionEndTime;
	}
	public String getYobValidationFlag() {
		return yobValidationFlag;
	}
	public void setYobValidationFlag(String yobValidationFlag) {
		this.yobValidationFlag = yobValidationFlag;
	}
	public Date getYobOverrideTime() {
		return yobOverrideTime;
	}
	public void setYobOverrideTime(Date yobOverrideTime) {
		this.yobOverrideTime = yobOverrideTime;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public Integer getVaultId() {
		return vaultId;
	}
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
