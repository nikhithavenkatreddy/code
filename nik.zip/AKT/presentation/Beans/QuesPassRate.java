package gov.ca.dmv.AKT.presentation.Beans;

public class QuesPassRate {

	private String testName;
	private String question;
	private String language;
	private Double passRate;
	private Double failRate;
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Double getPassRate() {
		return passRate;
	}
	public void setPassRate(Double passRate) {
		this.passRate = passRate;
	}
	public Double getFailRate() {
		return failRate;
	}
	public void setFailRate(Double failRate) {
		this.failRate = failRate;
	}
	
	
}
