package gov.ca.dmv.AKT.presentation.Beans;

import gov.ca.dmv.AKT.constants.Constant;

import java.math.BigDecimal;
import java.util.Date;

public class Exam {
	private Integer examId;
	private Integer applicationId;
	private String  testId;
	private String  passFailIndicator;
	private String  cdlFlag;
	private String  quickPassFailFlag;
	private String  officeId;
	private Date    examStartTime;
	private Date    examEndTime;
	private String  completionReasonCode;
	private Integer incorrectAnswerCount;
	private Integer maxIncorrectNumber;
	private Integer examQuestionNumber;
	private Integer questionAnsweredCount;
	private Integer correctQuestionCount;
	private Date    easeTimestamp;
	private Integer examOrder;
	private Integer sessionId;
	private String  easeTestId;
	private String  langId;
	private String  testTypeCode;
	private String  optionalTestInd;
	private String  signTestFlag;
	private BigDecimal score;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private String  secondaryVerificationId;
	
	public String getSecondaryVerificationId() {
		return secondaryVerificationId;
	}
	public void setSecondaryVerificationId(String secondaryVerificationId) {
		this.secondaryVerificationId = secondaryVerificationId;
	}
	public String getSignTestFlag() {
		return signTestFlag;
	}
	public void setSignTestFlag(String signTestFlag) {
		this.signTestFlag = signTestFlag;
	}
	public String getLangId() {
		return langId;
	}
	public void setLangId(String langId) {
		this.langId = langId;
	}
	public String getTestTypeCode() {
		return testTypeCode;
	}
	public void setTestTypeCode(String testTypeCode) {
		this.testTypeCode = testTypeCode;
	}
	public String getOptionalTestInd() {
		return optionalTestInd;
	}
	public void setOptionalTestInd(String optionalTestInd) {
		this.optionalTestInd = optionalTestInd;
	}
	public String getQuickPassFailFlag() {
		return quickPassFailFlag;
	}
	public void setQuickPassFailFlag(String quickPassFailFlag) {
		this.quickPassFailFlag = quickPassFailFlag;
	}
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getPassFailIndicator() {
		return passFailIndicator;
	}
	public void setPassFailIndicator(String passFailIndicator) {
		this.passFailIndicator = passFailIndicator;
	}
	public String getCdlFlag() {
		return cdlFlag;
	}
	public void setCdlFlag(String cdlFlag) {
		this.cdlFlag = cdlFlag;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public Date getExamStartTime() {
		return examStartTime;
	}
	public void setExamStartTime(Date examStartTime) {
		this.examStartTime = examStartTime;
	}
	public Date getExamEndTime() {
		return examEndTime;
	}
	public void setExamEndTime(Date examEndTime) {
		this.examEndTime = examEndTime;
	}
	public String getCompletionReasonCode() {
		return completionReasonCode;
	}
	public void setCompletionReasonCode(String completionReasonCode) {
		this.completionReasonCode = completionReasonCode;
	}
	public Integer getIncorrectAnswerCount() {
		return incorrectAnswerCount;
	}
	public void setIncorrectAnswerCount(Integer incorrectAnswerCount) {
		this.incorrectAnswerCount = incorrectAnswerCount;
	}
	public Integer getMaxIncorrectNumber() {
		return maxIncorrectNumber;
	}
	public void setMaxIncorrectNumber(Integer maxIncorrectNumber) {
		this.maxIncorrectNumber = maxIncorrectNumber;
	}
	public Integer getExamQuestionNumber() {
		return examQuestionNumber;
	}
	public void setExamQuestionNumber(Integer examQuestionNumber) {
		this.examQuestionNumber = examQuestionNumber;
	}
	public Integer getQuestionAnsweredCount() {
		return questionAnsweredCount;
	}
	public void setQuestionAnsweredCount(Integer questionAnsweredCount) {
		this.questionAnsweredCount = questionAnsweredCount;
	}
	public Integer getCorrectQuestionCount() {
		return correctQuestionCount;
	}
	public void setCorrectQuestionCount(Integer correctQuestionCount) {
		this.correctQuestionCount = correctQuestionCount;
	}
	public Date getEaseTimestamp() {
		return easeTimestamp;
	}
	public void setEaseTimestamp(Date easeTimestamp) {
		this.easeTimestamp = easeTimestamp;
	}
	public Integer getExamOrder() {
		return examOrder;
	}
	public void setExamOrder(Integer examOrder) {
		this.examOrder = examOrder;
	}
	public Integer getSessionId() {
		return sessionId;
	}
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public BigDecimal getScore() {
		this.setScore();
		return score;
	}
	private void setScore() {
		if(this.getCdlFlag().equalsIgnoreCase(Constant.NO)) {
			double score = ((double)((double)this.getCorrectQuestionCount()/(double)this.getExamQuestionNumber()) * 100.0);
			BigDecimal scoreDec = new BigDecimal(String.valueOf(score));
			scoreDec = scoreDec.setScale(2, BigDecimal.ROUND_HALF_UP);
			this.score = scoreDec;
		}
	}
}