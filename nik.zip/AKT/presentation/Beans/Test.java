package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class Test {

	private String  testId;
	private String  testName;
	private boolean quickPassFailInd;
	private Integer maxIncorrectNum;
	private String  testStatusCode;
	private String  defaultLangFlag;
	private boolean cdlFlag;
	private String  testQuestionCount;
	private String  easeTestId;
	private String  testTypeCode;
	private String  optionalTestInd;
	private Integer testOrder;
	private String  signTestFlag;
	private String  requiredSignTest;
	private String  englishOnlyFlag;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private boolean  quickPassInd;
	private boolean  quickFailInd;
	private String 	testOrigin;
	private Integer timeLimit;
	
	
	public String getTestOrigin() {
		return testOrigin;
	}
	public void setTestOrigin(String testOrigin) {
		this.testOrigin = testOrigin;
	}
	public Integer getTimeLimit() {
		return timeLimit;
	}
	public void setTimeLimit(Integer timeLimit) {
		this.timeLimit = timeLimit;
	}
	public boolean isQuickPassInd() {
		return quickPassInd;
	}
	public void setQuickPassInd(boolean quickPassInd) {
		this.quickPassInd = quickPassInd;
	}
	public boolean isQuickFailInd() {
		return quickFailInd;
	}
	public void setQuickFailInd(boolean quickFailInd) {
		this.quickFailInd = quickFailInd;
	}
	public String getEnglishOnlyFlag() {
		return englishOnlyFlag;
	}
	public void setEnglishOnlyFlag(String englishOnlyFlag) {
		this.englishOnlyFlag = englishOnlyFlag;
	}
	public String getRequiredSignTest() {
		return requiredSignTest;
	}
	public void setRequiredSignTest(String requiredSignTest) {
		this.requiredSignTest = requiredSignTest;
	}
	public String getSignTestFlag() {
		return signTestFlag;
	}
	public void setSignTestFlag(String signTestFlag) {
		this.signTestFlag = signTestFlag;
	}
	public Integer getTestOrder() {
		return testOrder;
	}
	public void setTestOrder(Integer testOrder) {
		this.testOrder = testOrder;
	}
	public String getOptionalTestInd() {
		return optionalTestInd;
	}
	public void setOptionalTestInd(String optionalTestInd) {
		this.optionalTestInd = optionalTestInd;
	}
	public String getTestTypeCode() {
		return testTypeCode;
	}
	public void setTestTypeCode(String testTypeCode) {
		this.testTypeCode = testTypeCode;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public boolean isQuickPassFailInd() {
		return quickPassFailInd;
	}
	public void setQuickPassFailInd(boolean quickPassFailInd) {
		this.quickPassFailInd = quickPassFailInd;
	}
	public Integer getMaxIncorrectNum() {
		return maxIncorrectNum;
	}
	public void setMaxIncorrectNum(Integer maxIncorrectNum) {
		this.maxIncorrectNum = maxIncorrectNum;
	}
	public String getTestStatusCode() {
		return testStatusCode;
	}
	public void setTestStatusCode(String testStatusCode) {
		this.testStatusCode = testStatusCode;
	}
	public String getDefaultLangFlag() {
		return defaultLangFlag;
	}
	public void setDefaultLangFlag(String defaultLangFlag) {
		this.defaultLangFlag = defaultLangFlag;
	}
	public boolean isCdlFlag() {
		return cdlFlag;
	}
	public void setCdlFlag(boolean cdlFlag) {
		this.cdlFlag = cdlFlag;
	}
	public String getTestQuestionCount() {
		return testQuestionCount;
	}
	public void setTestQuestionCount(String testQuestionCount) {
		this.testQuestionCount = testQuestionCount;
	}
	public String getEaseTestId() {
		return easeTestId;
	}
	public void setEaseTestId(String easeTestId) {
		this.easeTestId = easeTestId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
