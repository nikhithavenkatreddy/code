package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class WorkstationMap {

	private String  workstationIPAddress;
	private String  officeId;
	private String  workstationId;
	private String  lastModUsername;
	private Date    lastModUserTime;
	private String  status;
	private Date    reservedTime;
	
	public Date getReservedTime() {
		return reservedTime;
	}
	public void setReservedTime(Date reservedTime) {
		this.reservedTime = reservedTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getWorkstationIPAddress() {
		return workstationIPAddress;
	}
	public void setWorkstationIPAddress(String workstationIPAddress) {
		this.workstationIPAddress = workstationIPAddress;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getWorkstationId() {
		return workstationId;
	}
	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
