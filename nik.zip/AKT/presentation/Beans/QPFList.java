package gov.ca.dmv.AKT.presentation.Beans;

public class QPFList {

	private String testId;
	private String testName;
	private String quickPassFlag;
	private String quickFailFlag;
	
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getQuickPassFlag() {
		return quickPassFlag;
	}
	public void setQuickPassFlag(String quickPassFlag) {
		this.quickPassFlag = quickPassFlag;
	}
	public String getQuickFailFlag() {
		return quickFailFlag;
	}
	public void setQuickFailFlag(String quickFailFlag) {
		this.quickFailFlag = quickFailFlag;
	}
	
	
}
