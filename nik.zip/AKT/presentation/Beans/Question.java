package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class Question {

	private String questionId;
	private String questionStatus;
	private String lastModUsername;
	private Date   lastModUserTime;
	private String changeReviewStatusCode;
	
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getQuestionStatus() {
		return questionStatus;
	}
	public void setQuestionStatus(String questionStatus) {
		this.questionStatus = questionStatus;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getChangeReviewStatusCode() {
		return changeReviewStatusCode;
	}
	public void setChangeReviewStatusCode(String changeReviewStatusCode) {
		this.changeReviewStatusCode = changeReviewStatusCode;
	}
	
}
