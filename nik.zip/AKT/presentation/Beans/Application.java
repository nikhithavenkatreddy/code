package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class Application {

	private Integer       applicationId;
	private Integer       vaultId;
	private String        classLicenseCode;
	private String        endorsementCode;
	private String        officeId;
	private String        osFlag;
	private java.sql.Date dlExpirationDate;
	private Date          applicationTimestamp;
	private String        renewalFlag;
	private String        pauseCount;
	private String        applicationStatusCode;
	private String        forceFailFlag;
	private String        techId;
	private String        easeApplicationId;
	private String        signTestSatisfiedFlag;
	private String        applicationType;
	private String        lastModUsername;
	private Date          lastModUserTime;
	private String        audioVideoTestCode;
	
	public String getAudioVideoTestCode() {
		return audioVideoTestCode;
	}
	public void setAudioVideoTestCode(String audioVideoTestCode) {
		this.audioVideoTestCode = audioVideoTestCode;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getSignTestSatisfiedFlag() {
		return signTestSatisfiedFlag;
	}
	public void setSignTestSatisfiedFlag(String signTestSatisfiedFlag) {
		this.signTestSatisfiedFlag = signTestSatisfiedFlag;
	}
	public String getEaseApplicationId() {
		return easeApplicationId;
	}
	public void setEaseApplicationId(String easeApplicationId) {
		this.easeApplicationId = easeApplicationId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public Integer getVaultId() {
		return vaultId;
	}
	public void setVaultId(Integer vaultId) {
		this.vaultId = vaultId;
	}
	public String getClassLicenseCode() {
		return classLicenseCode;
	}
	public void setClassLicenseCode(String classLicenseCode) {
		this.classLicenseCode = classLicenseCode;
	}
	public String getEndorsementCode() {
		return endorsementCode;
	}
	public void setEndorsementCode(String endorsementCode) {
		this.endorsementCode = endorsementCode;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getOsFlag() {
		return osFlag;
	}
	public void setOsFlag(String osFlag) {
		this.osFlag = osFlag;
	}
	public java.sql.Date getDlExpirationDate() {
		return dlExpirationDate;
	}
	public void setDlExpirationDate(java.sql.Date dlExpirationDate) {
		this.dlExpirationDate = dlExpirationDate;
	}
	public Date getApplicationTimestamp() {
		return applicationTimestamp;
	}
	public void setApplicationTimestamp(Date applicationTimestamp) {
		this.applicationTimestamp = applicationTimestamp;
	}
	public String getRenewalFlag() {
		return renewalFlag;
	}
	public void setRenewalFlag(String renewalFlag) {
		this.renewalFlag = renewalFlag;
	}
	public String getPauseCount() {
		return pauseCount;
	}
	public void setPauseCount(String pauseCount) {
		this.pauseCount = pauseCount;
	}
	public String getApplicationStatusCode() {
		return applicationStatusCode;
	}
	public void setApplicationStatusCode(String applicationStatusCode) {
		this.applicationStatusCode = applicationStatusCode;
	}
	public String getForceFailFlag() {
		return forceFailFlag;
	}
	public void setForceFailFlag(String forceFailFlag) {
		this.forceFailFlag = forceFailFlag;
	}
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	
}
