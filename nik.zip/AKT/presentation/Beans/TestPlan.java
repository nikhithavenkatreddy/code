package gov.ca.dmv.AKT.presentation.Beans;

import gov.ca.dmv.AKT.constants.Constant;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class TestPlan implements Serializable{

	private String  	categoryId;
	private String      categoryName;
	private String  	testId;
	private Integer      categoryOrder;
	private Integer      categoryQuestionCount;
	private Boolean 	gradableFlag;
	private String       lastModUsername;
	private Date         lastModUserTime;
	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Integer getCategoryOrder() {
		return categoryOrder;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public void setCategoryOrder(Integer categoryOrder) {
		this.categoryOrder = categoryOrder;
	}
	public Integer getCategoryQuestionCount() {
		return categoryQuestionCount;
	}
	public void setCategoryQuestionCount(Integer categoryQuestionCount) {
		this.categoryQuestionCount = categoryQuestionCount;
	}
	public String getLastModUsername() {
		return lastModUsername;
	}
	public void setLastModUsername(String lastModUsername) {
		this.lastModUsername = lastModUsername;
	}
	public Date getLastModUserTime() {
		return lastModUserTime;
	}
	public void setLastModUserTime(Date lastModUserTime) {
		this.lastModUserTime = lastModUserTime;
	}
	public String getStringGradableFlag() {
		String stringGradable = Constant.SINGLE_SPACE;
		if (gradableFlag){
			stringGradable = "M"; 
		}
		return stringGradable;
	}
	
	public void setGradableFlag(String gradableFlag) {
		if(gradableFlag==null || gradableFlag.trim().length()==0){
			this.gradableFlag = false;
		}
		else{
			this.gradableFlag = true;
		}
	}
	public boolean isGradableFlag() {
		return gradableFlag;
	}
	public void setGradableFlag(boolean gradableFlag) {
		this.gradableFlag = gradableFlag;
	}
	
	
}
