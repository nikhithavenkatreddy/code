package gov.ca.dmv.AKT.presentation.Beans;

import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;

public class QuesAnsw {

	private QuestionLang    questionLang;
	private List<Answer>    answerList;
	private boolean         signFlag;
	private int             applicantAnswId;
	private HandbookRef     handbookRef;
	private boolean			queNotAnswered;
	
	public boolean isQueNotAnswered() {
		return queNotAnswered;
	}
	public void setQueNotAnswered(boolean queNotAnswered) {
		this.queNotAnswered = queNotAnswered;
	}
	public HandbookRef getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(HandbookRef handbookRef) {
		this.handbookRef = handbookRef;
	}
	public int getApplicantAnswId() {
		return applicantAnswId;
	}
	public void setApplicantAnswId(int applicantAnswId) {
		this.applicantAnswId = applicantAnswId;
	}
	public boolean isSignFlag() {
		return signFlag;
	}
	public void setSignFlag(boolean signFlag) {
		this.signFlag = signFlag;
	}
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}
	public List<Answer> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
	
}

