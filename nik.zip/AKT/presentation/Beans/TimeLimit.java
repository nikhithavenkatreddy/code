package gov.ca.dmv.AKT.presentation.Beans;

public class TimeLimit {
	private Integer timeLimitId;
	private String  timeLimitName;
	private Double timeLimitValue;
	private Double  timeLimitRangeMin;
	private Double  timeLimitRangeMax;
	

	public Double getTimeLimitRangeMin() {
		return timeLimitRangeMin;
	}
	public void setTimeLimitRangeMin(Double timeLimitRangeMin) {
		this.timeLimitRangeMin = timeLimitRangeMin;
	}
	public Double getTimeLimitRangeMax() {
		return timeLimitRangeMax;
	}
	public void setTimeLimitRangeMax(Double timeLimitRangeMax) {
		this.timeLimitRangeMax = timeLimitRangeMax;
	}
	public Integer getTimeLimitId() {
		return timeLimitId;
	}
	public void setTimeLimitId(Integer timeLimitId) {
		this.timeLimitId = timeLimitId;
	}
	public String getTimeLimitName() {
		return timeLimitName;
	}
	public void setTimeLimitName(String timeLimitName) {
		this.timeLimitName = timeLimitName;
	}
	public Double getTimeLimitValue() {
		return timeLimitValue;
	}
	public void setTimeLimitValue(Double timeLimitValue) {
		this.timeLimitValue = timeLimitValue;
	}
	
	
}
