package gov.ca.dmv.AKT.presentation.Beans;

import java.util.Date;

public class ExceptionApplicant {

	private Integer sysId;
	private String  lastName;
	private String  firstName;
	private String  dlNumber;
	private Integer appId;
	private String  examType;
	private String  lang;
	private String  result;
	private String  officeId;
	private String  resultStatusCode;
	private Date    resultSentTimestamp;
	
	public String getResultStatusCode() {
		return resultStatusCode;
	}
	public void setResultStatusCode(String resultStatusCode) {
		this.resultStatusCode = resultStatusCode;
	}
	public String getOfficeId() {
		return officeId;
	}
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public Date getResultSentTimestamp() {
		return resultSentTimestamp;
	}
	public void setResultSentTimestamp(Date resultSentTimestamp) {
		this.resultSentTimestamp = resultSentTimestamp;
	}
	public Integer getSysId() {
		return sysId;
	}
	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getExamType() {
		return examType;
	}
	public void setExamType(String examType) {
		this.examType = examType;
	}
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getDlNumber() {
		return dlNumber;
	}
	public void setDlNumber(String dlNumber) {
		this.dlNumber = dlNumber;
	}
	
}
