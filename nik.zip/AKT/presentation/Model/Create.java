package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.Category;

public class Create {

	private List<Lang>        langList;
	private List<Category>    categoryList;
	private List<HandbookRef> handbookRefList;
	private List<String>      questionIdList;
	private String            questionId;
	private int               questionGenId;
	private int               errorCode;
	
	public int getQuestionGenId() {
		return questionGenId;
	}
	public void setQuestionGenId(int questionGenId) {
		this.questionGenId = questionGenId;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public List<String> getQuestionIdList() {
		return questionIdList;
	}
	public void setQuestionIdList(List<String> questionIdList) {
		this.questionIdList = questionIdList;
	}
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public List<HandbookRef> getHandbookRefList() {
		return handbookRefList;
	}
	public void setHandbookRefList(List<HandbookRef> handbookRefList) {
		this.handbookRefList = handbookRefList;
	}
	
}
