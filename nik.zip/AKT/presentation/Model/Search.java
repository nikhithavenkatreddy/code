package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.List;

public class Search {

	private List<Lang>     langList;
	private List<Test>     testList;
	private List<Category> categoryList;
	
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	public List<Test> getTestList() {
		return testList;
	}
	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
}
