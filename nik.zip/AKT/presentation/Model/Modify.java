package gov.ca.dmv.AKT.presentation.Model;

public class Modify {

	private Create   create;
	private QuesAnsw quesAnsw;
	
	public Create getCreate() {
		return create;
	}
	public void setCreate(Create create) {
		this.create = create;
	}
	public QuesAnsw getQuesAnsw() {
		return quesAnsw;
	}
	public void setQuesAnsw(QuesAnsw quesAnsw) {
		this.quesAnsw = quesAnsw;
	}
	
}
