package gov.ca.dmv.AKT.presentation.Model;

public class ExamResult {

	private boolean pass;
	private int     examId;

	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}

	public boolean isPass() {
		return pass;
	}

	public void setPass(boolean pass) {
		this.pass = pass;
	}
	
}
