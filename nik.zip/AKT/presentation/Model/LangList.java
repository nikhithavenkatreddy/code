package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Lang;

import java.util.List;

public class LangList {

	private List<Lang> langList;
	private Lang       english;
	private Lang       spanish;
	
	public Lang getEnglish() {
		return english;
	}

	public void setEnglish(Lang english) {
		this.english = english;
	}

	public Lang getSpanish() {
		return spanish;
	}

	public void setSpanish(Lang spanish) {
		this.spanish = spanish;
	}

	public List<Lang> getLangList() {
		return langList;
	}

	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	
}
