package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.ExceptionApplicant;

import java.util.List;

public class ExceptionReport {
	
	private List<ExceptionApplicant> exceptionApplicantList;

	public List<ExceptionApplicant> getExceptionApplicantList() {
		return exceptionApplicantList;
	}

	public void setExceptionApplicantList(List<ExceptionApplicant> exceptionApplicantList) {
		this.exceptionApplicantList = exceptionApplicantList;
	}
	
}
