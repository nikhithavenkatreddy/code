package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

public class ReviewModel {

	private List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> quesAnswList;
	private int examId;
	
	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}

	public List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> getQuesAnswList() {
		return quesAnswList;
	}

	public void setQuesAnswList(
			List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> quesAnswList) {
		this.quesAnswList = quesAnswList;
	}
	
}
