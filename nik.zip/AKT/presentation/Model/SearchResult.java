package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;

import java.util.List;

public class SearchResult {

	private List<QuestionLang> questionLangList;
	private int                size;
	
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}

	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}
	
}
