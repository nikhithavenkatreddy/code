package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.TestPlan;

import java.util.List;

public class TestModel {

	private String testId;
	private String testName;
	private int    totalQuestions;
	private List<TestPlan> testPlanList; 
	
	public List<TestPlan> getTestPlanList() {
		return testPlanList;
	}
	public void setTestPlanList(List<TestPlan> testPlanList) {
		this.testPlanList = testPlanList;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public int getTotalQuestions() {
		return totalQuestions;
	}
	public void setTotalQuestions(int totalQuestions) {
		this.totalQuestions = totalQuestions;
	}
	
	
}
