package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Applicant;

import java.util.List;

public class ForceFailModel {

	List<Applicant> applicantList;

	public List<Applicant> getApplicantList() {
		return applicantList;
	}

	public void setApplicantList(List<Applicant> applicantList) {
		this.applicantList = applicantList;
	}
	
}
