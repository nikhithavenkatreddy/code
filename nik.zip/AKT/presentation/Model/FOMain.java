package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.constants.Constant;

import java.util.List;

public class FOMain {
	
	private List<String> options;
	private String       heading;
	
	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}
	
	public void setHeadingBasedOnGroup(String group) {
		setHeading(Constant.FOD_HEADER);
		if(group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			setHeading(Constant.DS_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			setHeading(Constant.OL_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
			setHeading(Constant.CHP_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.CPD_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CPD_USER_GROUP)) {
			setHeading(Constant.CPD_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.ISS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.ISS_USER_GROUP)) {
			setHeading(Constant.ISS_HEADER);
		}
	}
	
}
