package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.QPFList;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.List;

public class EligibleQPF {

	List<QPFList> qpfCollection;
	List<Test> testList;

	public List<Test> getTestList() {
		return testList;
	}

	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}

	public List<QPFList> getQpfCollection() {
		return qpfCollection;
	}

	public void setQpfCollection(List<QPFList> qpfCollection) {
		this.qpfCollection = qpfCollection;
	}
	
}
