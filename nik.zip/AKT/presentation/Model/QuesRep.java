package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

public class QuesRep {

	private List<QuesPassRate> quesPassRateList;

	public List<QuesPassRate> getQuesPassRateList() {
		return quesPassRateList;
	}

	public void setQuesPassRateList(List<QuesPassRate> quesPassRateList) {
		this.quesPassRateList = quesPassRateList;
	}
	
}
