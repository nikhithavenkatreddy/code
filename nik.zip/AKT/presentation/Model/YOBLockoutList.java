package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

public class YOBLockoutList {

	private List<SubYOBLockout> subYOBLockoutList;

	public List<SubYOBLockout> getSubYOBLockoutList() {
		return subYOBLockoutList;
	}

	public void setSubYOBLockoutList(List<SubYOBLockout> subYOBLockoutList) {
		this.subYOBLockoutList = subYOBLockoutList;
	}
	
}
