package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

public class YOBList {
	private List<String> years;

	public List<String> getYears() {
		return years;
	}

	public void setYears(List<String> years) {
		this.years = years;
	}
	
}
