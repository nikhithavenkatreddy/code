package gov.ca.dmv.AKT.presentation.Model;

public class MessageEndOfExam {

	int errorCode;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
