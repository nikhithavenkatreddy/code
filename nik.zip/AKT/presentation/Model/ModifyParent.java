package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.Question;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.List;

public class ModifyParent {

	private List<Category>    categoryList;
	private Question          question;
	private List<Test>        testList;
	
	public List<Test> getTestList() {
		return testList;
	}

	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}
	
	
}
