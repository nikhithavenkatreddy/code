package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.Vault;

import java.util.List;

public class PrintTestsModel {

	private List<Lang>         langList;
	private Vault              vault;
	
	public Vault getVault() {
		return vault;
	}
	public void setVault(Vault vault) {
		this.vault = vault;
	}
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	
}
