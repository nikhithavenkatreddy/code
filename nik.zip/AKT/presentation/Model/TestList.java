package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Beans.Lang;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.List;

public class TestList {

	private List<Test> testList;
	private List<Lang> langList;
	private String     heading;
	
	public String getHeading() {
		return heading;
	}
	public void setHeading(String heading) {
		this.heading = heading;
	}
	public List<Test> getTestList() {
		return testList;
	}
	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	public void setHeadingBasedOnGroup(String group) {
		setHeading(Constant.FOD_HEADER);
		if(group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			setHeading(Constant.DS_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			setHeading(Constant.OL_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
			setHeading(Constant.CHP_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.CPD_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CPD_USER_GROUP)) {
			setHeading(Constant.CPD_HEADER);
		}
		else if(group.equalsIgnoreCase(Constant.ISS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.ISS_USER_GROUP)) {
			setHeading(Constant.ISS_HEADER);
		}
	}
}
