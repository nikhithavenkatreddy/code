package gov.ca.dmv.AKT.presentation.Model;

import java.util.List;

public class PrintTestModel {

	private List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> quesAnswList;
	private String                                           testName;
	private int                                              randomNumber;
	private int                                              maxIncorrect;
	private String                                           langId;
	private int                                              errorCode;
	/**
	 * Added this one to identify the test status.
	 */
	private Integer    										 examId;
	private String                                           testId;
	private String                                           progLangCode;
	private String                                           instruction1;
	private String                                           instruction2;
	private String                                           instruction3;
	private String                                           instruction4;
	private String                                           instruction5;
	private String                                           instruction6;
	private String                                           instruction7;
	private String                                           instruction8;
	private String                                           instruction9;
	private String                                           instruction10;
	private String                                           instruction11;

	public String getInstruction8() {
		return instruction8;
	}

	public void setInstruction8(String instruction8) {
		this.instruction8 = instruction8;
	}

	public String getInstruction9() {
		return instruction9;
	}

	public void setInstruction9(String instruction9) {
		this.instruction9 = instruction9;
	}

	public String getInstruction10() {
		return instruction10;
	}

	public void setInstruction10(String instruction10) {
		this.instruction10 = instruction10;
	}

	public String getInstruction11() {
		return instruction11;
	}

	public void setInstruction11(String instruction11) {
		this.instruction11 = instruction11;
	}

	public String getInstruction1() {
		return instruction1;
	}

	public void setInstruction1(String instruction1) {
		this.instruction1 = instruction1;
	}

	public String getInstruction2() {
		return instruction2;
	}

	public void setInstruction2(String instruction2) {
		this.instruction2 = instruction2;
	}

	public String getInstruction3() {
		return instruction3;
	}

	public void setInstruction3(String instruction3) {
		this.instruction3 = instruction3;
	}

	public String getInstruction4() {
		return instruction4;
	}

	public void setInstruction4(String instruction4) {
		this.instruction4 = instruction4;
	}

	public String getInstruction5() {
		return instruction5;
	}

	public void setInstruction5(String instruction5) {
		this.instruction5 = instruction5;
	}

	public String getInstruction6() {
		return instruction6;
	}

	public void setInstruction6(String instruction6) {
		this.instruction6 = instruction6;
	}

	public String getInstruction7() {
		return instruction7;
	}

	public void setInstruction7(String instruction7) {
		this.instruction7 = instruction7;
	}

	public String getProgLangCode() {
		return progLangCode;
	}

	public void setProgLangCode(String progLangCode) {
		this.progLangCode = progLangCode;
	}

	public String getTestId() {
		return testId;
	}

	public void setTestId(String testId) {
		this.testId = testId;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getLangId() {
		return langId;
	}

	public void setLangId(String langId) {
		this.langId = langId;
	}

	public int getMaxIncorrect() {
		return maxIncorrect;
	}

	public void setMaxIncorrect(int maxIncorrect) {
		this.maxIncorrect = maxIncorrect;
	}

	public int getRandomNumber() {
		return randomNumber;
	}

	public void setRandomNumber(int randomNumber) {
		this.randomNumber = randomNumber;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> getQuesAnswList() {
		return quesAnswList;
	}

	public void setQuesAnswList(
			List<gov.ca.dmv.AKT.presentation.Beans.QuesAnsw> quesAnswList) {
		this.quesAnswList = quesAnswList;
	}

	public Integer getExamId() {
		return examId;
	}

	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	
}
