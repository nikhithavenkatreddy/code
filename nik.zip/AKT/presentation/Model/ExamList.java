package gov.ca.dmv.AKT.presentation.Model;


import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;

import java.util.List;

public class ExamList {
	
	private List<ExamTestLang> examTestLangList;
	private boolean            airbrakes;
	
	public boolean isAirbrakes() {
		return airbrakes;
	}

	public void setAirbrakes(boolean airbrakes) {
		this.airbrakes = airbrakes;
	}

	public List<ExamTestLang> getExamTestLangList() {
		return examTestLangList;
	}

	public void setExamTestLangList(List<ExamTestLang> examTestLangList) {
		this.examTestLangList = examTestLangList;
	}
	
}
