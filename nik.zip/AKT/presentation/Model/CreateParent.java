package gov.ca.dmv.AKT.presentation.Model;

import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.Test;

import java.util.List;

public class CreateParent {

	private List<Category>    categoryList;
	private List<Test>        testList;
	private int               errorCode;
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<Test> getTestList() {
		return testList;
	}

	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
}
