package gov.ca.dmv.AKT.presentation.Model;

import java.util.Date;
import java.util.List;

import gov.ca.dmv.AKT.presentation.Beans.Answer;
import gov.ca.dmv.AKT.presentation.Beans.Category;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.Beans.QuestionLang;
import gov.ca.dmv.AKT.presentation.Beans.Lang;

public class QuesAnsw {

	private QuestionLang    questionLang;
	private List<Answer>    answerList;
	private List<Category>  categoryList;
	private HandbookRef     handbookRef;
	private Lang            lang;
	private boolean         parentQuestionActive;     
	private int             questionPresentedOrder;
	private int             examId;
	private Date            questionPresentedTime;
	private boolean         signFlag;
	private boolean         pauseAllowed;
	private boolean         quitAllowed;
	private boolean         progressBarAllowed;
	private boolean         audioAllowed;
	private boolean         videoAllowed;
	private boolean         skipped;
	private boolean         skippedThreeTimes;
	private String          navUrl;
	
	public boolean isProgressBarAllowed() {
		return progressBarAllowed;
	}
	public void setProgressBarAllowed(boolean progressBarAllowed) {
		this.progressBarAllowed = progressBarAllowed;
	}
	public boolean isQuitAllowed() {
		return quitAllowed;
	}
	public void setQuitAllowed(boolean quitAllowed) {
		this.quitAllowed = quitAllowed;
	}
	public boolean isSkipped() {
		return skipped;
	}
	public void setSkipped(boolean skipped) {
		this.skipped = skipped;
	}
	public boolean isSkippedThreeTimes() {
		return skippedThreeTimes;
	}
	public void setSkippedThreeTimes(boolean skippedThreeTimes) {
		this.skippedThreeTimes = skippedThreeTimes;
	}
	public String getNavUrl() {
		return navUrl;
	}
	public void setNavUrl(String navUrl) {
		this.navUrl = navUrl;
	}
	public boolean isAudioAllowed() {
		return audioAllowed;
	}
	public void setAudioAllowed(boolean audioAllowed) {
		this.audioAllowed = audioAllowed;
	}
	public boolean isVideoAllowed() {
		return videoAllowed;
	}
	public void setVideoAllowed(boolean videoAllowed) {
		this.videoAllowed = videoAllowed;
	}
	public boolean isPauseAllowed() {
		return pauseAllowed;
	}
	public void setPauseAllowed(boolean pauseAllowed) {
		this.pauseAllowed = pauseAllowed;
	}
	public boolean isSignFlag() {
		return signFlag;
	}
	public void setSignFlag(boolean signFlag) {
		this.signFlag = signFlag;
	}
	public int getQuestionPresentedOrder() {
		return questionPresentedOrder;
	}
	public void setQuestionPresentedOrder(int questionPresentedOrder) {
		this.questionPresentedOrder = questionPresentedOrder;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public Date getQuestionPresentedTime() {
		return questionPresentedTime;
	}
	public void setQuestionPresentedTime(Date questionPresentedTime) {
		this.questionPresentedTime = questionPresentedTime;
	}
	public boolean isParentQuestionActive() {
		return parentQuestionActive;
	}
	public void setParentQuestionActive(boolean parentQuestionActive) {
		this.parentQuestionActive = parentQuestionActive;
	}
	public QuestionLang getQuestionLang() {
		return questionLang;
	}
	public void setQuestionLang(QuestionLang questionLang) {
		this.questionLang = questionLang;
	}
	public List<Answer> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	public HandbookRef getHandbookRef() {
		return handbookRef;
	}
	public void setHandbookRef(HandbookRef handbookRef) {
		this.handbookRef = handbookRef;
	}
	public Lang getLang() {
		return lang;
	}
	public void setLang(Lang lang) {
		this.lang = lang;
	}
		
}

