package gov.ca.dmv.AKT.presentation.Validators;

import java.util.ArrayList;
import java.util.List;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Command.ApplicantInformation;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class ApplicantInfoValidator implements Validator {

	public boolean supports(@SuppressWarnings("rawtypes") Class clazz) {
		return clazz.equals( ApplicantInformation.class );
	}

	public void validate(Object command, Errors errors) {
		ApplicantInformation cmd = (ApplicantInformation) command;
		String errorMsg = "*";
		if(cmd.getDl() == null || cmd.getDl().trim().length() < 1) {
			cmd.setDlError(errorMsg);
			errors.rejectValue("dl", "no error code", errorMsg);
		}
		if(cmd.getDob() == null || cmd.getDob().trim().length() != 10) {
			cmd.setDobError(errorMsg);
			errors.rejectValue("dob", "no error code", errorMsg);
		}
//		First Name not a required field - Defect #181 		
//		if(cmd.getFirstName() == null || cmd.getFirstName().trim().length() < 1) {
//			cmd.setFirstNameError(errorMsg);
//			errors.rejectValue("firstName", "no error code", errorMsg);
//		}
		if(cmd.getLastName() == null || cmd.getLastName().trim().length() < 1) {
			cmd.setLastNameError(errorMsg);
			errors.rejectValue("lastName", "no error code", errorMsg);
		}
		if(cmd.getTestList() == null || cmd.getTestList().size() < 1) {
			cmd.setTestListError(errorMsg);
			errors.rejectValue("testList", "no error code", errorMsg);
		}
	}

}
