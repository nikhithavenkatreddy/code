package gov.ca.dmv.AKT.presentation.Validators;

import gov.ca.dmv.AKT.presentation.Command.CreateParentQuestion;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class ModifyParentValidator implements Validator {
	
	public boolean supports( @SuppressWarnings("rawtypes") Class clazz )
    {
        return clazz.equals( CreateParentQuestion.class );
    }
	
	public void validate( Object command, Errors errors ) {
		CreateParentQuestion create = (CreateParentQuestion) command;
		String errorMsg = "Required fields are missing.";
		if(create.getQuestionId() == null || !StringUtils.hasText(create.getQuestionId())) {
			errors.rejectValue("questionId", errorMsg);
		}
		if(create.getCategoryId() == null || !StringUtils.hasText(create.getCategoryId())) {
			errors.rejectValue("categoryId", errorMsg);
		}
		if(create.getQuestionStatus() == null || !StringUtils.hasText(create.getQuestionStatus())) {
			errors.rejectValue("questionStatus", errorMsg);
		}
		if(create.getTestId() == null || !StringUtils.hasText(create.getTestId())) {
			errors.rejectValue("testId", errorMsg);
		}
	}

}
