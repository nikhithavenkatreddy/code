package gov.ca.dmv.AKT.presentation.Validators;

import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.presentation.Command.UpdateQuestion;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class ModifyValidator implements Validator {
	
	public boolean supports( @SuppressWarnings("rawtypes") Class clazz )
    {
        return clazz.equals( UpdateQuestion.class );
    }
	
	public void validate( Object command, Errors errors ) {
		UpdateQuestion create = (UpdateQuestion) command;
		String errorMsg = "Required fields are missing.";
		if( create.getAnswerId1() == null || !StringUtils.hasText( create.getAnswerId1().trim() ) ) {
			errors.rejectValue("answerId1", errorMsg);
		}
		else if( create.getAnswerId2() == null || !StringUtils.hasText( create.getAnswerId2().trim() ) ) {
			errors.rejectValue("answerId2", errorMsg);
		}
		else if( create.getAnswerO() == null || !StringUtils.hasText( create.getAnswerO().trim() ) ) {
			errors.rejectValue("answerO", errorMsg);
		}
		else if( create.getAnswerStatus1() == null || !StringUtils.hasText( create.getAnswerStatus1().trim() ) ) {
			errors.rejectValue("answerStatus1", errorMsg);
		}
		else if( create.getAnswerStatus2() == null || !StringUtils.hasText( create.getAnswerStatus2().trim() ) ) {
			errors.rejectValue("answerStatus2", errorMsg);
		}
		else if( (create.getAnswerId3() != null && StringUtils.hasText(create.getAnswerId3().trim())) || (create.getAnswerStatus3() != null && StringUtils.hasText(create.getAnswerStatus3().trim())) || (create.getAnswerText3() != null && StringUtils.hasText(create.getAnswerText3().trim()))) {
			if( !StringUtils.hasText( create.getAnswerId3().trim() ) ) {
				errors.rejectValue("answerId3", errorMsg);
			}
			else if( create.getAnswerStatus3() == null || !StringUtils.hasText( create.getAnswerStatus3().trim() ) ) {
				errors.rejectValue("answerStatus3", errorMsg);
			}
			else if( (create.getAnswerSignImage3() == null || !StringUtils.hasText(create.getAnswerSignImage3())) && !StringUtils.hasText( create.getAnswerText3().trim() ) ) {
				errors.rejectValue("answerText3", errorMsg);
			}
		}
		else if( (create.getAnswerId4() != null && StringUtils.hasText(create.getAnswerId4().trim())) || (create.getAnswerStatus4() != null && StringUtils.hasText(create.getAnswerStatus4().trim())) || (create.getAnswerText4() != null && StringUtils.hasText(create.getAnswerText4().trim()))) {
			if( !StringUtils.hasText( create.getAnswerId4().trim() ) ) {
				errors.rejectValue("answerId4", errorMsg);
			}
			else if( create.getAnswerStatus4() == null || !StringUtils.hasText( create.getAnswerStatus4().trim() ) ) {
				errors.rejectValue("answerStatus4", errorMsg);
			}
			else if( (create.getAnswerSignImage4() == null || !StringUtils.hasText(create.getAnswerSignImage4())) && !StringUtils.hasText( create.getAnswerText4().trim() ) ) {
				errors.rejectValue("answerText4", errorMsg);
			}
		}
		else if( (create.getAnswerSignImage1() == null || !StringUtils.hasText(create.getAnswerSignImage1())) && (create.getAnswerText1() == null || !StringUtils.hasText( create.getAnswerText1().trim() ) )) {
			errors.rejectValue("answerText1", errorMsg);
		}
		else if( (create.getAnswerSignImage2() == null || !StringUtils.hasText(create.getAnswerSignImage2())) && (create.getAnswerText2() == null || !StringUtils.hasText( create.getAnswerText2().trim() ) )) {
			errors.rejectValue("answerText2", errorMsg);
		}
		else if( create.getQuestionId() == null || !StringUtils.hasText( create.getQuestionId().trim() ) ) {
			errors.rejectValue("questionId", errorMsg);
		}
		else if( create.getQuestionStatus() == null || !StringUtils.hasText( create.getQuestionStatus().trim() ) ) {
			errors.rejectValue("questionStatus", errorMsg);
		}
		else {
			if( create.getQuestionStatus().equalsIgnoreCase(Constant.ACTIVE_PRES)) {
				if(create.getAnswerO().equalsIgnoreCase(String.valueOf(Constant.ONE))) {
					if(create.getAnswerStatus1().equalsIgnoreCase(Constant.INACTIVE_PRES)) {
						errors.rejectValue("answerStatus1", errorMsg);
					}
				}
				else if(create.getAnswerO().equalsIgnoreCase(String.valueOf(Constant.TWO))) {
					if(create.getAnswerStatus2().equalsIgnoreCase(Constant.INACTIVE_PRES)) {
						errors.rejectValue("answerStatus2", errorMsg);
					}
				}
				else if(create.getAnswerO().equalsIgnoreCase(String.valueOf(Constant.THREE))) {
					if(create.getAnswerStatus3().equalsIgnoreCase(Constant.INACTIVE_PRES)) {
						errors.rejectValue("answerStatus3", errorMsg);
					}
				}
				else if(create.getAnswerO().equalsIgnoreCase(String.valueOf(Constant.FOUR))) {
					if(create.getAnswerStatus4().equalsIgnoreCase(Constant.INACTIVE_PRES)) {
						errors.rejectValue("answerStatus4", errorMsg);
					}
				}
			}
		}
		if( create.getQuestionText() == null || !StringUtils.hasText( create.getQuestionText().trim() ) ) {
			errors.rejectValue("questionText", errorMsg);
		}
		
	}

}
