package gov.ca.dmv.AKT.constants;

public final class SearchRequestTypeConstant {

	public static final int    TEST_QUEUE_REQUEST = 1;
	public static final int    PRINT_TEST_QUEUE_REQUEST = 2;
	public static final int    PRINT_MISSED_QUES_REQUEST = 3;
	public static final int    PAUSE_REQUEST = 4;
	public static final int    TEST_STATUS = 51;
	public static final int    FAIL_TO_AUTHENTICATE_REQUEST = 5;
	public static final int    DISCONNECTED_REQUEST = 6;
	public static final int    TEST_RESULTS = 61;
	public static final int    TIMEOUT_REQUEST = 7;
	public static final int    QUIT_REQUEST = 8;
	public static final int    IN_PROGRESS_REQUEST = 9;
	public static final int    TEST_RESULTS_ALL_OFFICES = 10;
	public static final int    VIEW_ACITVE_SESSIONS =71;
	public static final int    EOD_REPORT =72;
	
}
