package gov.ca.dmv.AKT.constants;

public final class TimeLimitTypeConstant {
	
	public static final String  TIME_PER_QUESTION = "Time allowed per question";
	public static final String  WARNING_BEFORE_TIMEOUT = "Warning message prior to timeout";
	public static final String  ADDTNL_TIME_PER_QUESTION = "Additional Time per question (extension)";
	public static final String  TIME_BETWEEN_SESSIONS = "Time between sessions";
	public static final String  VIEW_MISSED_QUESTIONS = "Time to view missed questions";
	public static final String  KEEP_TERMINAL_RESERVED = "Length of time a terminal is reserved";
	public static final String  AUTHENTICATION_SCREEN = "Authentication Screen Timeout";
	public static final String  SEC_AUTHENTICATION_SCREEN = "Secondary Authentication Screen Timeout";
	public static final String  TEST_INSTRUCTIONS_SCREEN = "Test Instructions Timeout";
	public static final String  PERJURY_SCREEN = "Penalty of Perjury Screen Timeout";
	public static final String  SAMPLE_OR_START_SCREEN = "Sample Question or Start Test Confirmation Screen Timeout";
	public static final String  SAMPLE_QUESTION_SCREEN = "Sample Question Screen Timeout";
	public static final String  TESTS_AVAILABLE_SCREEN = "Available Tests Screen Timeout";
	public static final String  ADDTNL_TEST_SCREEN = "Additional Tests Screen Timeout";
	public static final String  ADDTNL_MESSAGES_SCREEN = "Additional Messages Screens Timeout";
	public static final String  TEST_RESULTS_SCREEN = "Test Results Screen Timeout";

	public static final String OL_TIME_LIMIT_REMINDER = "OL time limit reminder";                               
	public static final String CHP_TIME_LIMIT_REMINDER = "CHP time limit reminder";                              
	public static final String OL_TIME_LIMIT_REMINDER_DURATION = "OL time for time limit reminder to be on the screen";  
	public static final String CHP_TIME_LIMIT_REMINDER_DURATION = "CHP time for time limit reminder to be on the screen" ;
	public static final String OL_VIEW_MISSED_QUESTIONS = "OL time to view missed questions at end of test";      
	public static final String CHP_VIEW_MISSED_QUESTIONS = "CHP time to view missed questions at end of test";   

	
	public static final int DEFAULT_TIME_PER_QUESTION 			= 180;
	public static final int DEFAULT_WARNING_BEFORE_TIMEOUT 		= 60;
	public static final int DEFAULT_ADDTNL_TIME_PER_QUESTION	= 180;
	public static final int DEFAULT_TIME_BETWEEN_SESSIONS 		= 120;
	public static final int DEFAULT_VIEW_MISSED_QUESTIONS 		= 60;
	public static final int DEFAULT_KEEP_TERMINAL_RESERVED 		= 600;
	public static final int DEFAULT_AUTHENTICATION_SCREEN 		= 60;
	public static final int DEFAULT_SEC_AUTHENTICATION_SCREEN 	= 60;
	public static final int DEFAULT_TEST_INSTRUCTIONS_SCREEN 	= 120;
	public static final int DEFAULT_PERJURY_SCREEN 				= 60;
	public static final int DEFAULT_SAMPLE_OR_START_SCREEN 		= 60;
	public static final int DEFAULT_SAMPLE_QUESTION_SCREEN 		= 120;
	public static final int DEFAULT_TESTS_AVAILABLE_SCREEN 		= 60;
	public static final int DEFAULT_ADDTNL_TEST_SCREEN 			= 60;
	public static final int DEFAULT_ADDTNL_MESSAGES_SCREEN 		= 15;
	public static final int DEFAULT_TEST_RESULTS_SCREEN 		= 60;

	public static final int DEFAULT_OL_TIME_LIMIT_REMINDER = 900;                               
	public static final int DEFAULT_CHP_TIME_LIMIT_REMINDER = 900;                              
	public static final int DEFAULT_OL_TIME_LIMIT_REMINDER_DURATION = 60;  
	public static final int DEFAULT_CHP_TIME_LIMIT_REMINDER_DURATION = 60 ;
	public static final int DEFAULT_OL_VIEW_MISSED_QUESTIONS = 300;      
	public static final int DEFAULT_CHP_VIEW_MISSED_QUESTIONS = 300; 
	
	public static final int MILLISECONDS						= 1000;
	public static final int SECONDS								= 60;
	
}
