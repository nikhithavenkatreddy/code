package gov.ca.dmv.AKT.constants;

public class AudioVideoConstant {

	public static final String AUDIO_ONLY  = "A";
	public static final String VIDEO_ONLY  = "V";
	public static final String AUDIO_VIDEO = "B";
	
}
