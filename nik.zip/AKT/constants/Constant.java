package gov.ca.dmv.AKT.constants;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public final class Constant {

	
	public static final int    FIRST_ELEMENT = 0;
	public static final int    SINGLE_ELEMENT_LIST = 1;
	public static final int    ZERO = 0;
	public static final int    ONE = 1;
	public static final int    TWO = 2;
	public static final int    THREE = 3;
	public static final int    FOUR = 4;
	public static final int    EIGHT = 8;
	public static final int    NINE = 9;
	public static final String ACTIVE = "ACTV";
	public static final String INACTIVE = "INACT";
	public static final String PENDING = "P";
	public static final String APPROVED = "A";
	public static final String DENIED = "D";
	public static final String PENDING_INACTIVE = "I";
	public static final String ACTIVE_PRES = "Active";
	public static final String INACTIVE_PRES = "Inactive";
	public static final Date   defaultDate = getDefaultDate();
	public static final String SINGLE_SPACE = " ";
	public static final int    STARTING_POSITION = 0;
	public static final int    STARTING_YEAR = 1900;
	public static final double ACCEPTABLE_VARIATION = 0.25;
	public static final String LASTMODUSR_NME = "DEFUSER";
	public static final String PASS = "P";
	public static final String FAIL = "F";
	public static final String MANUAL_PASS = "D";
	public static final String MANUAL_FAIL = "T";
	public static final String PROVISIONAL = "P";
	public static final String EASE_PROVISIONAL = "PR";
	public static final String NEW = "N";
	public static final String ORIGINAL = "O";
	public static final String RENEWAL = "R";
	public static final String ALL = "A";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String FORCE_FAIL = "F";
	public static final String QUIT = "Q";
	public static final String DISCONNECTED = "D";
	public static final String YEAR_FORMAT = "yyyy";
	public static final String EASE_DATE_FORMAT = "MMddyyyy";
	public static final String EASE_TIME_FORMAT = "HHmmss";
	public static final String TIME_OUT = "T";
	public static final String TIMED_TEST_TIME_OUT = "U";
	public static final String NORMAL = "N";
	public static final String BATCH_FAIL = "B";
	public static final String CORRECT = "C";
	public static final String INCORRECT = "W";
	public static final String DISTRACTED = "D";
	public static final String NULL_STRING = "";
	public static final String DASHES = "---------";
	public static final String SINGLE_DASH = "-";
	public static final String PAUSE = "S";
	public static final String RESTART = "O";
	public static final String PAUSE_THRESHOLD = "PAUSE";
	public static final String USR_TRANSACTION = "java:comp/UserTransaction";
	public static final int    NEGATIVE_ONE = -1;
	public static final String NOT_FOUND = "NOT_FOUND";
	public static final String USER_ID = "IV-USER";
	public static final String REMOTE_IP = "IV-REMOTE-ADDRESS";
	public static final String GROUP_LIST = "IV-GROUPS";
	public static final String FIRST_NAME = "givenname";
	public static final String LAST_NAME = "sn";
	public static final String OFFICE_ID = "OfficeID";
	public static final String TECH_ID = "TechID";
	public static final String CREDENTIAL = "CREDENTIAL";
	public static final String HTML_SPACE = "%20";
	public static final String EASE_PASS = "A";
	public static final String HQ_ADMIN_GROUP = "AKT_R_HQ_ADMIN";
	public static final String HQ_USER_GROUP = "AKT_R_HQ_USER";
	public static final String FO_ADMIN_GROUP = "AKT_R_FO_ADMIN";
	public static final String FO_USER_GROUP = "AKT_R_FO_USER";
	public static final String DS_ADMIN_GROUP = "AKT_R_DS_ADMIN";
	public static final String DS_USER_GROUP = "AKT_R_DS_USER";
	public static final String OL_ADMIN_GROUP = "AKT_R_OL_ADMIN";
	public static final String OL_USER_GROUP = "AKT_R_OL_USER";
	public static final String CHP_ADMIN_GROUP = "AKT_R_CHP_ADMIN";
	public static final String CHP_USER_GROUP = "AKT_R_CHP_USER";
	public static final String CPD_ADMIN_GROUP = "AKT_R_CPD_ADMIN";
	public static final String CPD_USER_GROUP = "AKT_R_CPD_USER";
	public static final String ISS_ADMIN_GROUP = "AKT_R_ISS_ADMIN";
	public static final String ISS_USER_GROUP = "AKT_R_ISS_USER";
	public static final String APP_TYPE_FO = "FO";
	public static final String APP_TYPE_DS = "DS";
	public static final String APP_TYPE_OL = "OL";
	public static final String APP_TYPE_CHP = "CHP";
	public static final String APP_TYPE_ISS = "APP_TYPE_ISS";
	public static final String OFFICE_TYPE_FO = "FO";
	public static final String OFFICE_TYPE_DS = "DS";
	public static final String OFFICE_TYPE_OL = "OL";
	public static final String OFFICE_TYPE_CHP = "CHP";
	public static final String ADMIN = "ADMIN";
	public static final String USER = "USER";
	public static final String AIRBRAKES = "C3";
	public static final String EASE_PROCESSED = "P";
	public static final String EASE_IGNORE = "I";
	public static final String EASE_UNPROCESSED = "U";
	public static final String EASE_ORPHANED = "O";
	public static final String EASE_UNPROCESSED_MSG = "Unprocessed";
	public static final String EASE_ORPHANED_MSG = "Unrecognized App Id";
	public static final String DEFAULT_YOB = "1111";
	public static final String EXCEPTION = "General Exception";
	public static final String SKIPPED = "S";
	public static final String SCORE_DEFAULT = "0.00";
	public static final String EXAM_QUESTION_TABLE = "VAKT320U_EXAM_QUES";
	public static final String ANSWER_STATUS = "ANSW_STATUS";
	public static final String TERMINAL_AVAILABLE = "A";
	public static final String TERMINAL_RESERVED = "R";
	public static final String TERMINAL_TESTING = "T";
	public static final String SESSION_ACTIVE = "A";
	public static final String SESSION_RESERVED = "R";
	public static final String SESSION_TESTING = "T";	
	public static final String SESSION_TERMINATED = "X";
	public static final String TERMINAL_AVAILABLE_UI = "Available";
	public static final String TERMINAL_RESERVED_UI = "Unavailable";
	public static final String APPLICATION_ASSIGNED = "A";
	public static final String APPLICATION_TESTING = "T";
	public static final String PER = "%";
	public static final String VIEW_TEST_STATUS = "V";
	public static final String PRINT_TEST_STATUS = "P";
	public static final String REPRINT_TEST_STATUS = "R";
	public static final String VIEW_ANSWER_KEY_STATUS = "W";
	public static final String PRINT_ANSWER_KEY_STATUS = "A";
	public static final String REPRINT_ANSWER_KEY_STATUS = "Z";
	public static final String PRINT_UPDATE_SCORE_STATUS = "C";
	public static final String MANDATORY_NON_GRADABLE = "M";
	
	public static final String COMPLETION_REASON_CODE = "CMPLTN_RSN_CD";
	public static final String EXAM_TABLE = "VAKT240U_EXAM_A";
	public static final String TEST_TABLE = "VAKT030U_TEST_A";
	public static final String TEST_ID = "TEST_ID";
	public static final String QUESTION_LANG_TABLE = "VAKT130U_QUESTION_LANG_TBL_A";
	public static final String QUESTION_GEN_ID = "QUESTION_GEN_ID";
	
	public static final String BASE_NAME = "WEB-INF/resources/messages";
	public static final String SIGN_TEST_ID = "R9";
	public static final String AMBULANCE_TEST_ID = "F9";
	public static final String DEFAULT_LANG = "01";
	public static final String FOD_HEADER = "FOD";
	public static final String DS_HEADER = "DS";
	public static final String OL_HEADER = "OL";
	public static final String CHP_HEADER = "CHP";
	public static final String CPD_HEADER = "CPD Help Desk";
	public static final String ISS_HEADER = "LOD Issuance";
	public static final String PRINT = "Print";
	public static final String REPRINT = "Reprint";
	public static final String PASSWORD_HINT = "PW";
	public static final String USERID_HINT = "User ID";
	public static final String OL_50M_TEST_ID = "";
	public static final String GENERATE_TEST = "GENERATE TEST";
	public static final String FORCE_FAIL_ADD = "A";
	public static final String FORCE_FAIL_DELETE = "D";
	
	public static final String EXAM_NOT_STARTED = "Not Started";
	public static final String EXAM_PAUSED = "Paused Test";
	public static final String EXAM_TIMED_OUT = "Timed Out Test";
	public static final String EXAM_QUIT = "Quit Test";
	public static final String EXAM_DISCONNECTED = "Disconnected Test";
	public static final String EXAM_IN_PROGRESS = "In Progess";
	public static final String EXAM_COMPLETED = "Completed";
	public static final String EXAM_RESUMED = "Resumed";
	public static final String EXAM_FORCE_FAILED = "Force Failed";
	public static final String EXAM_ABSENT = "No Test";
	public static final String EXAM_TERMINATED = "Session Terminated";
	public static final String EXAM_TIMED_TEST_TIME_OUT = "Timed Test Timed Out";
	
	public static final String MANUALLY_ASSIGNED = "MANUALLY_ASSIGNED";
	
//	public static final String AUDIO_FILE_LOCATION = "/Audio/";
	public static final String AUDIO_FILE_LOCATION = "/AKTEAudio/";
	public static final String FORWARD_SLASH = "/";
	//public static final String INSTRUCTION_FILE_NAME = "C:/Video/Instructions_" ;
	public static final String INSTRUCTION_FILE_NAME = "C:/Video/English_FP_Video";
	public static final String INSTRUCTION_FILE_NAME_EN = "C:/Video/English_FP_Video";
	public static final String INSTRUCTION_FILE_NAME_ES = "C:/Video/Spanish_FP_Video";
	public static final String INSTRUCTION_FILE_EXT = ".mp4" ;
	public static final String GOOD_CACHE_STATUS = "Good";
	public static final String BAD_CACHE_STATUS = "Bad";
	public static final String CURED_CACHE_STATUS = "Cured";
	public static final String GOOD_DB_STATUS = "Good";
	public static final String BAD_DB_STATUS = "Bad";
	public static final String CALIFORNIA_STATE_CODE = "CA";
	public static final String HTTPS = "https://";
	
	public static final String LANG_ENGLISH = "01";
	public static final String LANG_SPANISH = "02";
	
	public static boolean isToday(Date date) {
		java.util.Calendar calendar = java.util.Calendar.getInstance();
		calendar.setTime(date);
		return isSameDay(calendar, Calendar.getInstance());
	}
	
	public static boolean isSameDay(Date date1, Date date2) {
		java.util.Calendar calendar1 = java.util.Calendar.getInstance();
		calendar1.setTime(date1);
		java.util.Calendar calendar2 = java.util.Calendar.getInstance();
		calendar2.setTime(date2);
		return isSameDay(calendar1, calendar2);
	}
	
	public static boolean isPastCurrentDay(Date date1) {
		java.util.Calendar calendar1 = java.util.Calendar.getInstance();
		calendar1.setTime(date1);
		java.util.Calendar calendar2 = java.util.Calendar.getInstance();
		if(calendar1.get(Calendar.YEAR) > calendar2.get(Calendar.YEAR)) {
			return true;
		}
		else if(calendar1.get(Calendar.MONTH) > calendar2.get(Calendar.MONTH)){
			return true;
		}
		else if(calendar1.get(Calendar.DAY_OF_MONTH) > calendar2.get(Calendar.DAY_OF_MONTH)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isSameDay(java.util.Calendar cal1, java.util.Calendar cal2) {
		return (cal1.get(Calendar.ERA)         == cal2.get(Calendar.ERA)  && 
				cal1.get(Calendar.YEAR)        == cal2.get(Calendar.YEAR) &&
				cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
	}
	
	public static boolean hasEndedLongEnough(Date date, int timeout) {
		Date currentTime = new Date();
		long differenceInMilliSec =	currentTime.getTime() - date.getTime();
		long differenceInMinutes = differenceInMilliSec / (60 * 1000);
		if(differenceInMinutes >= timeout)
			return true;
		else
			return false;
	}
	
	public static boolean hasEndedLongEnough2(Date date, int timeout) {
		Date currentTime = new Date();
		long differenceInMilliSec =	currentTime.getTime() - date.getTime();
		long differenceInMinutes = differenceInMilliSec / (60 * 1000);
		if(differenceInMinutes >= timeout)
			return true;
		else
			return false;
	}
	
	public static boolean hasEndedLongEnough3(Date date, int timeout) {
		Date currentTime = new Date();
		long differenceInMilliSec =	currentTime.getTime() - date.getTime();
		long differenceInMinutes = differenceInMilliSec / (60 * 1000);
		if(differenceInMinutes >= timeout)
			return true;
		else
			return false;
	}
	
	public static boolean hasBeen60Days(Date date) {
		Date currentTime = new Date();
		long differenceInMilliSec =	currentTime.getTime() - date.getTime();
		long differenceInMinutes = differenceInMilliSec / (60 * 1000);
		long differenceInDays = differenceInMinutes / (60 * 24);
		if(differenceInDays > 60)
			return true;
		else
			return false;
	}
	
	public static Date getDefaultDate() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date defDate = null;
		try {
			defDate = formatter.parse("1111-01-01 00:01:01");
		} catch (ParseException e) {
			System.out.println("Couldn't parse the date");
			e.printStackTrace();
		}
		return defDate;
	}
	
	public static boolean expiresIn30Days(Date date) {
		Date currentTime = new Date();
		long differenceInMilliSec =	date.getTime() - currentTime.getTime();
		long differenceInDays = differenceInMilliSec / (24 * 60 * 60 * 1000);
		if(differenceInDays <= 30)
			return true;
		else
			return false;
	}
	
	public static Date getTomorrowsDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
	    cal.set(Calendar.MINUTE, 0);
	    cal.set(Calendar.SECOND, 0);
	    cal.add(Calendar.DATE, 1);
	    java.util.Date tomorrow = cal.getTime();
	    return tomorrow;
	}
	
	public static Date getYesterdaysDate() {
		Calendar cal2 = Calendar.getInstance();
	    cal2.set(Calendar.HOUR_OF_DAY, 23);
	    cal2.set(Calendar.MINUTE, 59);
	    cal2.set(Calendar.SECOND, 59);
	    cal2.add(Calendar.DATE, -1);
	    java.util.Date yesterday = cal2.getTime();
	    return yesterday;
	}
}
