package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface ITestListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.Test> getTestList();
	public void setTestList(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList2);
	
}
