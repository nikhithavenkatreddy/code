package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.ISession;

public interface ISessionBooleanWL extends IErrorWL {

	public boolean isFlag();
	public void setFlag(boolean flag);
	public ISession getSession();
	public void setSession(ISession session);
	
}
