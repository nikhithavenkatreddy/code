package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.ISession;

public interface ISessionWL extends IErrorWL {

	public ISession getSession();
	public void setSession(ISession session2);
	
}
