package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface ITestLangWL extends IErrorWL {

	public gov.ca.dmv.AKT.integration.BeansImpl.TestLang getTestLang();
	public void setTestLang(gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang2);
	
}
