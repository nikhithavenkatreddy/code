package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.Audit;

public interface IAuditWL extends IErrorWL {

	public Audit getAudit();
	public void setAudit(Audit audit);
}
