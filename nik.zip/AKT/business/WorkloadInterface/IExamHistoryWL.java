package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IExamHistory;

public interface IExamHistoryWL extends IErrorWL {

	public IExamHistory getExamHistory();
	public void setExamHistory(IExamHistory examHistory2);
	
}
