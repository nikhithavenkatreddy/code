package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface IIntegerWL extends IErrorWL {

	public Integer getInteger();
	public void setInteger(Integer integer);
	
}
