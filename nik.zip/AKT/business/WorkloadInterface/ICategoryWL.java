/**
 * 
 */
package gov.ca.dmv.AKT.business.WorkloadInterface;

/**
 * @author mwaxs18
 *
 */
public interface ICategoryWL extends IErrorWL{
	public gov.ca.dmv.AKT.integration.BeansImpl.Category getCategory();
	public void setTest(gov.ca.dmv.AKT.integration.BeansImpl.Category category);
}
