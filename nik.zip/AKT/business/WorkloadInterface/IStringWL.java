package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface IStringWL extends IErrorWL {

	public String getString();
	public void setString(String string);
	
}
