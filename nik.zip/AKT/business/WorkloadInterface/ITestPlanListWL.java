package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface ITestPlanListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> getTestPlanList();
	public void setTestPlanList(List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList);
	
}
