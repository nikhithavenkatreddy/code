package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.IExam;

import java.util.List;

public interface IExamListWL extends IErrorWL {
	
	public List<IExam> getExamList();
	public void setExamList(List<IExam> examList2);
	
}
