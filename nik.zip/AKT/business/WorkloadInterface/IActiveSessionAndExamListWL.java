package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;

import java.util.List;

public interface IActiveSessionAndExamListWL extends IErrorWL {

	public List<ActiveSessionAndExam> getActiveSessionAndExamList();
	public void setActiveSessionAndExamList(List<ActiveSessionAndExam> activeSessionAndExamList);
	
}
