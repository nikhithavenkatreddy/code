package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface IStringListWL extends IErrorWL {

	public List<String> getStringList();
	public void setStringList(List<String> stringList);
	
}
