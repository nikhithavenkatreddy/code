package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;

import java.util.List;

public interface IHandbookRefListWL extends IErrorWL {

	public List<HandbookRef> getHandbookRefList();
	public void setHandbookRefList(List<HandbookRef> handbookRefList);
	
}
