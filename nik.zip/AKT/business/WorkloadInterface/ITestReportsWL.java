package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.TestQuesReport;
import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.util.List;

public interface ITestReportsWL extends IErrorWL {

	public List<TestQuesReport> getTestReports();
	public void setTestReports(List<TestQuesReport> testReports);
	public List<QuesPassRate> getQuesPassRateList();
	public void setQuesPassRateList(List<QuesPassRate> quesPassRateList);	
}
