package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IExamHistory;

import java.util.List;

public interface IExamHistoryListWL extends IErrorWL {

	public List<IExamHistory> getExamHistoryList();
	public void setExamHistoryList(List<IExamHistory> examHistoryList);
	
}
