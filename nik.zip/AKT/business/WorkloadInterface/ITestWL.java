package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface ITestWL extends IErrorWL {

	public gov.ca.dmv.AKT.integration.BeansImpl.Test getTest();
	public void setTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test2);
	
}
