package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;

import java.util.List;

public interface IExamQuestionListWL extends IErrorWL {

	public List<IExamQuestion> getExamQuestionList();
	public void setExamQuestionList(List<IExamQuestion> examQuestionList);
	public List<Integer> getExamQuestionListIds();
	
}
