package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.QPFList;

import java.util.List;

public interface IQPFListCollectionWL extends IErrorWL {

	public List<QPFList> getQpfCollection();
	public void setQpfCollection(List<QPFList> qpfCollection);
	
}
