package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface IExamAndVaultIdWL extends IErrorWL {
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.ExamAndVaultId> getExamAndVaultIdList();
	public void setExamAndVaultIdList(List<gov.ca.dmv.AKT.integration.BeansImpl.ExamAndVaultId> examAndVaultIdList);

}
