package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface IErrorWL {

	public int getErrorCode();
	public void setErrorCode(int errorCode);
	
}
