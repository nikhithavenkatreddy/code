package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface ITimeLimitListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> getTimeLimitList();
	public void setTimeLimitList(List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> testList);
	
}
