package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface IBooleanWL extends IErrorWL {

	public boolean isFlag();
	public void setFlag(boolean flag);
	
}
