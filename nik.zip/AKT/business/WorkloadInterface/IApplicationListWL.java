package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IApplication;

import java.util.List;

public interface IApplicationListWL extends IErrorWL {

	public List<IApplication> getApplicationList();
	public void setApplicationList(List<IApplication> applicationList);
}
