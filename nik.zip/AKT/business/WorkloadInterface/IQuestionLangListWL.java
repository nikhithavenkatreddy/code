package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;

import java.util.List;

public interface IQuestionLangListWL extends IErrorWL {

	public List<QuestionLang> getQuestionLangList();
	public void setQuestionLangList(List<QuestionLang> questionLangList);
	
}
