package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.IExam;

public interface IExamWL extends IErrorWL {

	public IExam getExam();
	public void setExam(IExam exam2);
	
}
