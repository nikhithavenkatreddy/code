package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface ICategoryListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.Category> getCategoryList();
	public void setCategoryList(List<gov.ca.dmv.AKT.integration.BeansImpl.Category> catList);
	
}
