package gov.ca.dmv.AKT.business.WorkloadInterface;

public interface ILangWL extends IErrorWL {

	public gov.ca.dmv.AKT.integration.BeansImpl.Lang getLang();
	public void setLang(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang2);
	
}
