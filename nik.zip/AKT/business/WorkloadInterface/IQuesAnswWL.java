package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;

public interface IQuesAnswWL extends IErrorWL {

	public QuesAnsw getQuesAnsw();
	public void setQuesAnsw(QuesAnsw quesAnsw);
	
}
