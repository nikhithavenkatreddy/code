package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface IResultListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults> getResultList();
	public void setResultList(List<gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults> resList);
	
}
