package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IVault;

public interface IVaultWL extends IErrorWL {

	public IVault getVault();
	public void setVault(IVault vault2);
	
}
