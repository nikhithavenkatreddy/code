package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.Applicant;

import java.util.List;

public interface IApplicantListWL extends IErrorWL{

	public List<Applicant> getApplicantList();
	public void setApplicantList(List<Applicant> applicantList);
	
}
