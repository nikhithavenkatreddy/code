package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.QuestionCategoryTestList;

public interface IQuestionCategoryTestListWL extends IErrorWL {

	public QuestionCategoryTestList getQuestionCategoryTestList();
	public void setQuestionCategoryTestList(QuestionCategoryTestList questionCategoryTestList);
	
}
