package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.ISession;

import java.util.List;

public interface ISessionListWL extends IErrorWL {

	public List<ISession> getSessionList();
	public void setSessionList(List<ISession> sessionList);
	
}
