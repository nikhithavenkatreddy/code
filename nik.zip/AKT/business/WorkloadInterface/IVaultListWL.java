package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.BeansImpl.Vault;

import java.util.List;

public interface IVaultListWL extends IErrorWL {

	public List<Vault> getVaultList();
	public void setVaultList(List<Vault> vaultList);
	
}
