package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;

public interface IEaseInboundMessageWL extends IErrorWL {

	public IEaseInboundMessage getEaseInboundMessage();
	public void setEaseInboundMessage(IEaseInboundMessage easeInboundMessage);
	
}
