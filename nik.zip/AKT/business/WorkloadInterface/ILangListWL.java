package gov.ca.dmv.AKT.business.WorkloadInterface;

import java.util.List;

public interface ILangListWL extends IErrorWL {

	public List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> getLangList();
	public void setLangList(List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList2);
	
}
