package gov.ca.dmv.AKT.business.WorkloadInterface;

import gov.ca.dmv.AKT.integration.Beans.IApplication;

public interface IApplicationWL extends IErrorWL {

	public IApplication getApplication();
	public void setApplication(IApplication application);
	
}
