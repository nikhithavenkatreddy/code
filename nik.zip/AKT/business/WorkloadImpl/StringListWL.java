package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IStringListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class StringListWL implements IStringListWL {

	private List<String> stringList;
	private int          errorCode = ErrorCode.NO_ERROR;
	
	public List<String> getStringList() {
		return stringList;
	}
	public void setStringList(List<String> stringList) {
		this.stringList = stringList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
