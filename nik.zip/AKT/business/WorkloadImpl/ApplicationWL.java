package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;

public class ApplicationWL implements IApplicationWL {

	private IApplication application;
	private int         errorCode = ErrorCode.NO_ERROR;
	
	public IApplication getApplication() {
		return application;
	}
	public void setApplication(IApplication application) {
		this.application = application;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
