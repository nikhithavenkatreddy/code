package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class CategoryListWL implements ICategoryListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.Category> categoryList;
	private int                                             errorCode = ErrorCode.NO_ERROR;
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<gov.ca.dmv.AKT.integration.BeansImpl.Category> catList) {
		this.categoryList = catList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
