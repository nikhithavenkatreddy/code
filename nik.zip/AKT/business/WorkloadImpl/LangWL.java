package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ILangWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

public class LangWL implements ILangWL {

	private gov.ca.dmv.AKT.integration.BeansImpl.Lang lang;
	private int                                   errorCode = ErrorCode.NO_ERROR;
	
	public gov.ca.dmv.AKT.integration.BeansImpl.Lang getLang() {
		return lang;
	}
	public void setLang(gov.ca.dmv.AKT.integration.BeansImpl.Lang lang2) {
		this.lang = lang2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
