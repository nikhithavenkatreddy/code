package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IEaseInboundMessageWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;

public class EaseInboundMessageWL implements IEaseInboundMessageWL {

	private IEaseInboundMessage easeInboundMessage;
	private int                errorCode = ErrorCode.NO_ERROR;
	
	public IEaseInboundMessage getEaseInboundMessage() {
		return easeInboundMessage;
	}
	public void setEaseInboundMessage(IEaseInboundMessage easeInboundMessage) {
		this.easeInboundMessage = easeInboundMessage;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
