package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

public class IntegerWL implements IIntegerWL {

	private Integer integer;
	private int     errorCode = ErrorCode.NO_ERROR;
	
	public Integer getInteger() {
		return integer;
	}
	public void setInteger(Integer integer) {
		this.integer = integer;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
