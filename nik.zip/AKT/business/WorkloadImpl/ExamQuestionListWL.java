package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamQuestionListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;

import java.util.ArrayList;
import java.util.List;

public class ExamQuestionListWL implements IExamQuestionListWL {

	private List<IExamQuestion> examQuestionList;
	private int                                                 errorCode = ErrorCode.NO_ERROR;
	
	public List<IExamQuestion> getExamQuestionList() {
		return examQuestionList;
	}
	public void setExamQuestionList(List<IExamQuestion> examQuestionList) {
		this.examQuestionList = examQuestionList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public List<Integer> getExamQuestionListIds() {
		List<Integer> ids = new ArrayList<Integer>();
		for(IExamQuestion eq: examQuestionList) {
			ids.add(eq.getQuestionGenId());
		}
		return ids;
	}
}
