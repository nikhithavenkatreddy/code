package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITestReportsWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.TestQuesReport;
import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.util.List;

public class TestReportsWL implements ITestReportsWL {

	private List<TestQuesReport> testReports;
	private List<QuesPassRate>   quesPassRateList;
	private int                  errorCode = ErrorCode.NO_ERROR;
	
	public List<TestQuesReport> getTestReports() {
		return testReports;
	}
	public void setTestReports(List<TestQuesReport> testReports) {
		this.testReports = testReports;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public List<QuesPassRate> getQuesPassRateList() {
		return quesPassRateList;
	}
	public void setQuesPassRateList(List<QuesPassRate> quesPassRateList) {
		this.quesPassRateList = quesPassRateList;
	}
	
}
