package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.ISession;

import java.util.List;

public class SessionListWL implements ISessionListWL {

	private List<ISession> sessionList;
	private int           errorCode = ErrorCode.NO_ERROR;
	
	public List<ISession> getSessionList() {
		return sessionList;
	}
	public void setSessionList(List<ISession> sessionList) {
		this.sessionList = sessionList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
