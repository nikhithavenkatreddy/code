package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class AuditListWL implements IAuditListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.Audit> auditList;
	private int                                         errorCode = ErrorCode.NO_ERROR;
	
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Audit> getAuditList() {
		return auditList;
	}
	public void setAuditList(List<gov.ca.dmv.AKT.integration.BeansImpl.Audit> auditList) {
		this.auditList = auditList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
