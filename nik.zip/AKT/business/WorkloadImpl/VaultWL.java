package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IVault;

public class VaultWL implements IVaultWL {

	private IVault vault;
	private int                                    errorCode = ErrorCode.NO_ERROR;
	
	public IVault getVault() {
		return vault;
	}
	public void setVault(IVault vault2) {
		this.vault = vault2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
