package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IResultListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class ResultListWL implements IResultListWL {
	private List<gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults> resultList;
	private int                                                errorCode = ErrorCode.NO_ERROR;
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults> getResultList() {
		return resultList;
	}
	public void setResultList(List<gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults> resList) {
		this.resultList = resList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
