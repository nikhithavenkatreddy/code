package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;

import java.util.List;

public class VaultListWL implements IVaultListWL {

	private List<Vault> vaultList;
	private int         errorCode = ErrorCode.NO_ERROR;
	
	public List<Vault> getVaultList() {
		return vaultList;
	}
	public void setVaultList(List<Vault> vaultList) {
		this.vaultList = vaultList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
