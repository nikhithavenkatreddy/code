package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITestListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class TestListWL implements ITestListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList;
	private int                                         errorCode = ErrorCode.NO_ERROR;
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Test> getTestList() {
		return testList;
	}
	public void setTestList(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList2) {
		this.testList = testList2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
