package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;

public class ExamWL implements IExamWL {

	private IExam exam;
	private int  errorCode = ErrorCode.NO_ERROR;
	
	public int getErrorCode() {
		return errorCode;
	}
	public IExam getExam() {
		return exam;
	}
	public void setExam(IExam exam) {
		this.exam = exam;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
