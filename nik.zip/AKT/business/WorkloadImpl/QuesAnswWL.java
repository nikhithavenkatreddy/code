package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IQuesAnswWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;

public class QuesAnswWL implements IQuesAnswWL {

	private QuesAnsw quesAnsw;
	private int      errorCode = ErrorCode.NO_ERROR;
	
	public QuesAnsw getQuesAnsw() {
		return quesAnsw;
	}
	public void setQuesAnsw(QuesAnsw quesAnsw) {
		this.quesAnsw = quesAnsw;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
