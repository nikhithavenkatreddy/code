/**
 * 
 */
package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;

/**
 * @author mwaxs18
 * 
 */
public class CategoryWL implements ICategoryWL {
	private gov.ca.dmv.AKT.integration.BeansImpl.Category category;
	private int errorCode = ErrorCode.NO_ERROR;

	@Override
	public int getErrorCode() {
		// TODO Auto-generated method stub
		return errorCode;
	}

	@Override
	public void setErrorCode(int errorCode) {
		// TODO Auto-generated method stub
		this.errorCode = errorCode;
	}

	@Override
	public Category getCategory() {
		// TODO Auto-generated method stub
		return category;
	}

	@Override
	public void setTest(Category category) {
		this.category = category;

	}

}
