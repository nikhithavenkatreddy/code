package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;

import java.util.List;

public class ExamHistoryListWL implements IExamHistoryListWL {

	private List<IExamHistory> examHistoryList;
	private int               errorCode = ErrorCode.NO_ERROR;
	
	public List<IExamHistory> getExamHistoryList() {
		return examHistoryList;
	}
	public void setExamHistoryList(List<IExamHistory> examHistoryList) {
		this.examHistoryList = examHistoryList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
