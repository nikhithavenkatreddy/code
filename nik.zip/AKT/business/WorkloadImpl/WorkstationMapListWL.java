package gov.ca.dmv.AKT.business.WorkloadImpl;

import java.util.List;

import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;

public class WorkstationMapListWL implements IWorkstationMapListWL {

	private List<WorkstationMap> workstationMapList;
	private int                  errorCode = ErrorCode.NO_ERROR;
	
	public List<WorkstationMap> getWorkstationMapList() {
		return workstationMapList;
	}
	public void setWorkstationMapList(List<WorkstationMap> workstationMapList) {
		this.workstationMapList = workstationMapList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
