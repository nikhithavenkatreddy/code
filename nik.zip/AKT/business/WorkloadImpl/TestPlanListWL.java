package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITestPlanListWL;

import java.util.List;

public class TestPlanListWL extends BaseWL implements ITestPlanListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList;

	public List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> getTestPlanList() {
		return testPlanList;
	}

	public void setTestPlanList(
			List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList) {
		this.testPlanList = testPlanList;
	}

}
