package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITimeLimitListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class TimeLimtiListWL implements ITimeLimitListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> timeLimitList;
	private int                                         errorCode = ErrorCode.NO_ERROR;
	

	public List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> getTimeLimitList() {
		return timeLimitList;
	}
	public void setTimeLimitList(List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> timeLimitList) {
		this.timeLimitList = timeLimitList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
