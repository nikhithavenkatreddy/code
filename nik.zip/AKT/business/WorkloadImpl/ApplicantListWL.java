package gov.ca.dmv.AKT.business.WorkloadImpl;

import java.util.List;

import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicantListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Applicant;

public class ApplicantListWL implements IApplicantListWL {

	private int             errorCode = ErrorCode.NO_ERROR;
	private List<Applicant> applicantList;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public List<Applicant> getApplicantList() {
		return applicantList;
	}
	public void setApplicantList(List<Applicant> applicantList) {
		this.applicantList = applicantList;
	}
	
}
