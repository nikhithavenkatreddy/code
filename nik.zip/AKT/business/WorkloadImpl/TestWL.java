package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

public class TestWL implements ITestWL {

	private gov.ca.dmv.AKT.integration.BeansImpl.Test test;
	private int                                   errorCode = ErrorCode.NO_ERROR;
	
	public gov.ca.dmv.AKT.integration.BeansImpl.Test getTest() {
		return test;
	}
	public void setTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test2) {
		this.test = test2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
