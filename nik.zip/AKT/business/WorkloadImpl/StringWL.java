package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

public class StringWL implements IStringWL {

	private String string;
	private int    errorCode = ErrorCode.NO_ERROR;
	
	public String getString() {
		return string;
	}
	public void setString(String string) {
		this.string = string;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
