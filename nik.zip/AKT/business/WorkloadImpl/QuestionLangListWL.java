package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionLangListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;

import java.util.List;

public class QuestionLangListWL implements IQuestionLangListWL {

	private List<QuestionLang> questionLangList;
	private int                errorCode = ErrorCode.NO_ERROR;
	
	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}
	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
