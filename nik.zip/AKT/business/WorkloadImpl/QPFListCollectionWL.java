package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IQPFListCollectionWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.QPFList;

import java.util.List;

public class QPFListCollectionWL implements IQPFListCollectionWL {

	private List<QPFList> qpfCollection;
	private int           errorCode = ErrorCode.NO_ERROR;
	
	public List<QPFList> getQpfCollection() {
		return qpfCollection;
	}
	public void setQpfCollection(List<QPFList> qpfCollection) {
		this.qpfCollection = qpfCollection;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
