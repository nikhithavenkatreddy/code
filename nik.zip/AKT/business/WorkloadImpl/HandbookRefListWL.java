package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IHandbookRefListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;

import java.util.List;

public class HandbookRefListWL implements IHandbookRefListWL {

	private List<HandbookRef> handbookRefList;
	private int               errorCode = ErrorCode.NO_ERROR;
	
	public List<HandbookRef> getHandbookRefList() {
		return handbookRefList;
	}
	public void setHandbookRefList(List<HandbookRef> handbookRefList) {
		this.handbookRefList = handbookRefList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
}
