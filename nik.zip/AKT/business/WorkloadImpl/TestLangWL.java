package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ITestLangWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

public class TestLangWL implements ITestLangWL {

	private gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang;
	private int                                       errorCode = ErrorCode.NO_ERROR;
	
	public gov.ca.dmv.AKT.integration.BeansImpl.TestLang getTestLang() {
		return testLang;
	}
	public void setTestLang(gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang2) {
		this.testLang = testLang2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
