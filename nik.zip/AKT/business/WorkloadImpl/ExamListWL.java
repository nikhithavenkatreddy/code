package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;

import java.util.List;

public class ExamListWL implements IExamListWL {

	private List<IExam> examList;
	private int                                         errorCode = ErrorCode.NO_ERROR;
	
	public int getErrorCode() {
		return errorCode;
	}
	public List<IExam> getExamList() {
		return examList;
	}
	public void setExamList(List<IExam> examList) {
		this.examList = examList;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
