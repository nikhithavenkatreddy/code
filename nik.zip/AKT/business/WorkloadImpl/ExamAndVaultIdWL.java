package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamAndVaultIdWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class ExamAndVaultIdWL implements IExamAndVaultIdWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.ExamAndVaultId> examAndVaultIdList;
	private int                  errorCode = ErrorCode.NO_ERROR;
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.ExamAndVaultId> getExamAndVaultIdList() {
		return examAndVaultIdList;
	}
	public void setExamAndVaultIdList(List<gov.ca.dmv.AKT.integration.BeansImpl.ExamAndVaultId> examAndVaultIdList) {
		this.examAndVaultIdList = examAndVaultIdList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
