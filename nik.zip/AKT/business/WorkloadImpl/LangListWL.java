package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ILangListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;

import java.util.List;

public class LangListWL implements ILangListWL {

	private List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList;
	private int                                         errorCode = ErrorCode.NO_ERROR;
	
	public List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList2) {
		this.langList = langList2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
