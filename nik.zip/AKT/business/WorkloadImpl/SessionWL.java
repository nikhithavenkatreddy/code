package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.ISession;

public class SessionWL implements ISessionWL {

	private ISession session;
	private int                                      errorCode = ErrorCode.NO_ERROR;
	
	public ISession getSession() {
		return session;
	}
	public void setSession(ISession session2) {
		this.session = session2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
