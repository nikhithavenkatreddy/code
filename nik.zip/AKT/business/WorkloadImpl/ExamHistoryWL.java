package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;

public class ExamHistoryWL implements IExamHistoryWL {

	private IExamHistory examHistory;
	private int                                          errorCode = ErrorCode.NO_ERROR;
	
	public IExamHistory getExamHistory() {
		return examHistory;
	}
	public void setExamHistory(IExamHistory examHistory2) {
		this.examHistory = examHistory2;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
