package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;

import java.util.List;

public class ActiveSessionAndExamListWL implements IActiveSessionAndExamListWL {

	private List<ActiveSessionAndExam> activeSessionAndExamList;
	private int                        errorCode = ErrorCode.NO_ERROR;
	
	public List<ActiveSessionAndExam> getActiveSessionAndExamList() {
		return activeSessionAndExamList;
	}
	public void setActiveSessionAndExamList(List<ActiveSessionAndExam> activeSessionAndExamList) {
		this.activeSessionAndExamList = activeSessionAndExamList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
