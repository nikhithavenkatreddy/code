package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionCategoryTestListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionCategoryTestList;

public class QuestionCategoryTestListWL implements IQuestionCategoryTestListWL {

	private QuestionCategoryTestList questionCategoryTestList;
	private int                      errorCode = ErrorCode.NO_ERROR;
	
	public QuestionCategoryTestList getQuestionCategoryTestList() {
		return questionCategoryTestList;
	}
	public void setQuestionCategoryTestList(QuestionCategoryTestList questionCategoryTestList) {
		this.questionCategoryTestList = questionCategoryTestList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
