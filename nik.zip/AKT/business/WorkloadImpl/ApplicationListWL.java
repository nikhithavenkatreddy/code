package gov.ca.dmv.AKT.business.WorkloadImpl;

import java.util.List;

import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationListWL;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;

public class ApplicationListWL implements IApplicationListWL {

	private List<IApplication> applicationList;
	private int               errorCode = ErrorCode.NO_ERROR;
	
	public List<IApplication> getApplicationList() {
		return applicationList;
	}
	public void setApplicationList(List<IApplication> applicationList) {
		this.applicationList = applicationList;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
