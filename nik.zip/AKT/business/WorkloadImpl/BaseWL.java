package gov.ca.dmv.AKT.business.WorkloadImpl;

import gov.ca.dmv.AKT.errors.ErrorCode;

public class BaseWL {

	private int errorCode = ErrorCode.NO_ERROR;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}	
}
