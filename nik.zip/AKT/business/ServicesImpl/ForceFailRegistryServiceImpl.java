package gov.ca.dmv.AKT.business.ServicesImpl;

import java.util.HashMap;
import java.util.Map;

import gov.ca.dmv.AKT.business.Services.ForceFailRegistryService;
import gov.ca.dmv.AKT.constants.Constant;

public class ForceFailRegistryServiceImpl extends BaseServiceImpl implements ForceFailRegistryService{

	private Map<Integer, String> forceFailRegistry;

	public ForceFailRegistryServiceImpl() {
		forceFailRegistry = new HashMap<Integer, String>(); 
	}
	
	public Map<Integer, String> getForceFailRegistry() {
		return forceFailRegistry;
	}

	public void setForceFailRegistry(Map<Integer, String> forceFailRegistry) {
		this.forceFailRegistry = forceFailRegistry;
	}
	
	public void addForceFailRequest(Integer examId) {
		forceFailRegistry.put(examId, Constant.FORCE_FAIL);
	}
	
    public void removeForceFailRequest(Integer examId) {
    	forceFailRegistry.remove(examId);
    }
    
    public String getForceFailRequest(Integer examId) {
    	return forceFailRegistry.get(examId);
    }
}
