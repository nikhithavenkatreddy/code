package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.ExamSessionData;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SuppressWarnings("serial")
public class ExamSessionDataImpl implements Serializable, ExamSessionData {

	
	private List<IExamQuestion> examQuestionList;
	private List<IExamQuestion> skippedExamQuestionList;
	private List<IExamAnswer>   examAnswerList;
	private List<QuestionLang>  questionLangList;
	private List<Answer>        answerList;
	private IExam               exam;
	private IApplication        application;
	private IVault              vault;
	private IDMVStaff 			dmvStaff;
    private Boolean 			additionalTestFlag;
    private ISession			session;
	private List<QuesAnsw>      quesAnswList;
	
	public Boolean getAdditionalTestFlag() {
		return additionalTestFlag;
	}

	public void setAdditionalTestFlag(Boolean additionalTestFlag) {
		this.additionalTestFlag = additionalTestFlag;
	}

	public IDMVStaff getDmvStaff() {
		return dmvStaff;
	}

	public void setDmvStaff(IDMVStaff dmvStaff) {
		this.dmvStaff = dmvStaff;
	}

	public List<IExamQuestion> getSkippedExamQuestionList() {
		return skippedExamQuestionList;
	}

	public int getSkippedQuestionsCount(){
		if(skippedExamQuestionList!=null){
			return skippedExamQuestionList.size();
		}
		else{
			return 0;
		}
	}
	
	public void setSkippedExamQuestionList(
			List<IExamQuestion> skippedExamQuestionList) {
		this.skippedExamQuestionList = skippedExamQuestionList;
	}

	public IVault getVault() {
		return vault;
	}

	public void setVault(IVault vault) {
		this.vault = vault;
	}

	/*
	 * This method is called to return the application that is saved in the session.
	 */
	public IApplication getApplication() {
		return application;
	}

	public void setApplication(IApplication application) {
		this.application = application;
	}

	public IExam getExam() {
		return exam;
	}

	public void setExam(IExam exam) {
		this.exam = exam;
	}

	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}

	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}

	public List<Answer> getAnswerList() {
		return answerList;
	}

	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}

	public List<IExamAnswer> getExamAnswerList() {
		return examAnswerList;
	}

	public void setExamAnswerList(List<IExamAnswer> examAnswerList) {
		this.examAnswerList = examAnswerList;
	}

	public List<IExamQuestion> getExamQuestionList() {
		return examQuestionList;
	}

	public void setExamQuestionList(List<IExamQuestion> examQuestionList) {
		this.examQuestionList = examQuestionList;
	}
	
	public List<IExamAnswer> getExamAnswerListByQuesGenId(int quesGenId) {
		List<IExamAnswer> quesExamAnswerList = new ArrayList<IExamAnswer>();
		
		for (IExamAnswer examAnswer : examAnswerList) {
			if (examAnswer.getQuestionGenId() == quesGenId) {
				quesExamAnswerList.add(examAnswer);
			}
		}
		
		return quesExamAnswerList;
	}
	
	public List<IExamQuestion> getMissedExamQuestionList() {
		List<IExamQuestion> missedExamQuestionList = new ArrayList<IExamQuestion>();
		
		for (IExamQuestion examQuestion: examQuestionList) {
			if (examQuestion.getAnswerStatus().equalsIgnoreCase(Constant.NO)) {
				missedExamQuestionList.add(examQuestion);
			}
		}
		return missedExamQuestionList;
	}
	
	private IExamQuestion getExamQuestion(Integer examId, Integer quesPresOrder) {
		IExamQuestion eq1 = null;
		if(examQuestionList != null && examQuestionList.size() > Constant.ZERO) {
			for(IExamQuestion eq2: examQuestionList) {
				if(eq2.getEqPrimaryKey().getExamId().equals(examId) && eq2.getEqPrimaryKey().getQuestionPresentedOrder().equals(quesPresOrder)) {
					eq1 = eq2;
					break;
				}
			}
		}
		return eq1;
	}
	
	private List<IExamAnswer> getExamAnswer(Integer examId, Integer quesGenId) {
		List<IExamAnswer> examAnsList = new ArrayList<IExamAnswer>();
		for(IExamAnswer ea: examAnswerList) {
			if(ea.getEaPrimaryKey().getExamId().equals(examId) && ea.getQuestionGenId().equals(quesGenId)) {
				examAnsList.add(ea);
			}
		}
		return examAnsList;
	}
	
	private QuestionLang getQuestionLang(Integer quesGenId) {
		QuestionLang ql1 = null;
		for(QuestionLang ql2: questionLangList) {
			if(ql2.getQuestionGenId().equals(quesGenId)) {
				ql1 = ql2;
				break;
			}
		}
		return ql1;
	}
	
	private List<Answer> getAnswers(List<IExamAnswer> examAnsList) {
		List<Answer> ansList = new ArrayList<Answer>();
		for(IExamAnswer examAns: examAnsList) {
			for(Answer ans: answerList) {
				if(examAns.getEaPrimaryKey().getAnswerId().equals(ans.getAnswerGenId())) {
					ansList.add(ans);
				}
			}
		}
		return ansList;
	}
	
	private IExamAnswer getExamAnswerByAnsGenId(Integer examId, Integer ansGenId) {
		IExamAnswer examAnswer = null;
		for(IExamAnswer ea: examAnswerList) {
			if(ea.getEaPrimaryKey().getExamId().equals(examId) && ea.getEaPrimaryKey().getAnswerId().equals(ansGenId)) {
				examAnswer = ea;
				break;
			}
		}
		return examAnswer;
	}
	
	private int getCorrectAnswerCount(Integer examId) {
		int count = 0;
		for(IExamQuestion eq: examQuestionList) {
			if(eq.getEqPrimaryKey().getExamId().equals(examId)) {
				if(eq.getAnswerStatus().equalsIgnoreCase(Constant.YES)) {
					count++;
				}
			}
		}
		return count;
	}
	
	private int getIncorrectAnswerCount(Integer examId) {
		int count = 0;
		for(IExamQuestion eq: examQuestionList) {
			if(eq.getEqPrimaryKey().getExamId().equals(examId)) {
				if(eq.getAnswerStatus().equalsIgnoreCase(Constant.NO)) {
					count++;
				}
			}
		}
		return count;
	}
	
	private int getQuestionAnsweredCount(Integer examId) {
		int count = 0;
		for(IExamQuestion eq: examQuestionList) {
			if(eq.getEqPrimaryKey().getExamId().equals(examId)) {
				if(eq.getAnswerStatus().equalsIgnoreCase(Constant.YES) || eq.getAnswerStatus().equalsIgnoreCase(Constant.NO)) {
					count++;
				}
			}
		}
		return count;
	}
		
	public int getAnswerCountForProgressBar(){
		return exam.getQuestionAnsweredCount();
	}
	
	public int getQuestionCountForProgressBar(){
		return exam.getExamQuestionNumber();
	}	
	public QuesAnsw getQuestionAnswers(Integer examId, Integer quesPresOrder) {
		QuesAnsw quesAnsw = new QuesAnsw();
		quesAnsw.setOrder(quesPresOrder);
		quesAnsw.setSkipped(false);
		quesAnsw.setSkippedThreeTimes(false);
		if(skippedExamQuestionList != null && skippedExamQuestionList.size() >= Constant.THREE) {
			quesAnsw.setSkippedThreeTimes(true);
		}
		int questionGenId = Constant.ZERO;
		if(quesPresOrder > exam.getExamQuestionNumber()) {
			quesAnsw.setSkipped(true);
			questionGenId = skippedExamQuestionList.get(Constant.ZERO).getQuestionGenId();
			quesAnsw.setOrder(skippedExamQuestionList.get(Constant.ZERO).getEqPrimaryKey().getQuestionPresentedOrder());
			skippedExamQuestionList.remove(skippedExamQuestionList.get(Constant.ZERO));
		}
		else {
			IExamQuestion eq = getExamQuestion(examId, quesPresOrder);
			questionGenId = getExamQuestion(examId, quesPresOrder).getQuestionGenId();
			if(eq.getAnswerStatus().trim().length() > Constant.ZERO && (eq.getAnswerStatus().trim().equalsIgnoreCase(Constant.YES) || eq.getAnswerStatus().trim().equalsIgnoreCase(Constant.NO) || eq.getAnswerStatus().trim().equalsIgnoreCase(Constant.SKIPPED))) {
				quesAnsw.setSkipped(true);
				questionGenId = skippedExamQuestionList.get(Constant.ZERO).getQuestionGenId();
				quesAnsw.setOrder(skippedExamQuestionList.get(Constant.ZERO).getEqPrimaryKey().getQuestionPresentedOrder());
				skippedExamQuestionList.remove(skippedExamQuestionList.get(Constant.ZERO));
			}
		}
		List<IExamAnswer> examAnswerList = getExamAnswer(examId, questionGenId);
		QuestionLang quesLang = getQuestionLang(questionGenId);
		List<Answer> ansList = getAnswers(examAnswerList);
		quesAnsw.setQuestionLang(quesLang);
		quesAnsw.setAnswerList(ansList);
		return quesAnsw;
	}
	
	public IExamQuestion getExamQuestionAfterGrading(SubmitAnswer submitAnswer) {
		IExamQuestion eq = getExamQuestion(submitAnswer.getExamId(), submitAnswer.getQuestionPresentedOrder());
		IExamAnswer ea = getExamAnswerByAnsGenId(submitAnswer.getExamId(), submitAnswer.getAnswerGenId());
//		int incorrectAnsCount = getIncorrectAnswerCount(submitAnswer.getExamId());
//		int questionAnsweredCount = getQuestionAnsweredCount(submitAnswer.getExamId());
//		int correctQuestionCount = getCorrectAnswerCount(submitAnswer.getExamId());
		int incorrectAnsCount = exam.getIncorrectAnswerCount();
		int questionAnsweredCount = exam.getQuestionAnsweredCount();
		int correctQuestionCount = exam.getCorrectQuestionCount();
		questionAnsweredCount++;
		Integer answerElapsedTime = (int)(new Date().getTime() - submitAnswer.getQuestionPresentedTime().getTime());
		String status = null;
		if(ea.getCorrectAnswerFlag().equalsIgnoreCase(Constant.YES)) {
			status = Constant.YES;
			correctQuestionCount++;
		}
		else {
			status = Constant.NO;
			incorrectAnsCount++;
		}
		eq.setAnswerChoice(String.valueOf(ea.getAnswerPresentedOrder()));
		eq.setAnswerStatus(status);
		eq.setAnswerElapsedTime(answerElapsedTime + eq.getAnswerElapsedTime());
		//Set last mod usr tme so that it can be used to determine disconnected exams.
		eq.setLastModUserTime(new Date());
		
		if(exam.getRemainingTime()>0){
			Integer exam_remaining_time = exam.getRemainingTime() - (answerElapsedTime/TimeLimitTypeConstant.MILLISECONDS);
			exam_remaining_time = (exam_remaining_time>0)?exam_remaining_time:0;
			exam.setRemainingTime(exam_remaining_time);
		}
		exam.setCorrectQuestionCount(correctQuestionCount);
		exam.setIncorrectAnswerCount(incorrectAnsCount);
		exam.setQuestionAnsweredCount(questionAnsweredCount);
		return eq;
	}
	
	public IExam getExamByExamId(Integer examId) {
		IExam exm = null;
		if(exam.getExamId().equals(examId)) {
			exm = exam;
		}
		return exm;
	}
	
	public IExam getExamAfterGrading(Integer examId, String status, String compReasonCode) {
		IExam exm = getExamByExamId(examId);
		exm.setCompletionReasonCode(compReasonCode);
		exm.setExamEndTime(new Date());
		exm.setPassFailIndicator(status);
		exm.setLastModUsername(Constant.LASTMODUSR_NME);
		exm.setLastModUserTime(new Date());
		return exm;
	}
	
	/*
	 * This method is called to get the exam record from the session data after setting the completion reason code to reflect pause.
	 */
	public IExam getExamAfterPause(Integer examId, Date questionPresentedTime) {		
		IExam exm = getExamByExamId(examId);
		exm.setCompletionReasonCode(Constant.PAUSE);
		exm.setLastModUsername(Constant.LASTMODUSR_NME);
		exm.setLastModUserTime(new Date());
		
		Integer answerElapsedTime = (int)(new Date().getTime() - questionPresentedTime.getTime());
		if(exm.getRemainingTime()>0){
			Integer exam_remaining_time = exm.getRemainingTime() - (answerElapsedTime/TimeLimitTypeConstant.MILLISECONDS);
			exam_remaining_time = (exam_remaining_time>0)?exam_remaining_time:0;
			exm.setRemainingTime(exam_remaining_time);
		}
		
		return exm;
	}
	
	public IExam getExamAfterTimeout(Integer examId, Date questionPresentedTime) {
		IExam exm = getExamByExamId(examId);
		exm.setCompletionReasonCode(Constant.TIME_OUT);
		exm.setExamEndTime(new Date());
		exm.setPassFailIndicator(Constant.FAIL);
		
		Integer answerElapsedTime = (int)(new Date().getTime() - questionPresentedTime.getTime());
		if(exam.getRemainingTime()>0){
			Integer exam_remaining_time = exam.getRemainingTime() - (answerElapsedTime/TimeLimitTypeConstant.MILLISECONDS);
			exam_remaining_time = (exam_remaining_time>0)?exam_remaining_time:0;
			exam.setRemainingTime(exam_remaining_time);
		}
				
		return exm;
	}
	
	public IExam getExamAfterQuit(Integer examId) {
		IExam exm = getExamByExamId(examId);
		exm.setCompletionReasonCode(Constant.QUIT);
		exm.setExamEndTime(new Date());
		exm.setPassFailIndicator(Constant.FAIL);
		return exm;
	}
	
	public IExam getExamAfterForceFail(Integer examId) {
		IExam exm = getExamByExamId(examId);
		exm.setCompletionReasonCode(Constant.FORCE_FAIL);
		exm.setExamEndTime(new Date());
		exm.setPassFailIndicator(Constant.FAIL);
		return exm;
	}
	
	public void setDisconnectedExam(Integer examId) {
		int incorrectAnsCount = getIncorrectAnswerCount(examId);
		int questionAnsweredCount = getQuestionAnsweredCount(examId);
		int correctQuestionCount = getCorrectAnswerCount(examId);
		exam.setCorrectQuestionCount(correctQuestionCount);
		exam.setIncorrectAnswerCount(incorrectAnsCount);
		exam.setQuestionAnsweredCount(questionAnsweredCount);
	}
	
	public QuesAnsw getQuestionAnswersForMissedQuestion(Integer examId, Integer quesPresOrder) {
		QuesAnsw quesAnsw = new QuesAnsw();
		quesAnsw.setOrder(quesPresOrder);
		int questionGenId = getExamQuestion(examId, quesPresOrder).getQuestionGenId();
		List<IExamAnswer> examAnswerList = getExamAnswer(examId, questionGenId);
		QuestionLang quesLang = getQuestionLang(questionGenId);
		List<Answer> ansList = getAnswers(examAnswerList);
		quesAnsw.setQuestionLang(quesLang);
		quesAnsw.setAnswerList(ansList);
		return quesAnsw;
	}
	
	/**
	 * This method is called to add the skipped question to the skipped question list
	 */
	public IExamQuestion skipQuestion(int examId, int order, Date questionPresentedTime) {		
		Integer answerElapsedTime = (int)(new Date().getTime() - questionPresentedTime.getTime());
		if(exam.getRemainingTime()>0){
			Integer exam_remaining_time = exam.getRemainingTime() - (answerElapsedTime/TimeLimitTypeConstant.MILLISECONDS);
			exam_remaining_time = (exam_remaining_time>0)?exam_remaining_time:0;
			exam.setRemainingTime(exam_remaining_time);
		}
		
		IExamQuestion eq = getExamQuestion(examId, order);
		eq.setAnswerStatus(Constant.SKIPPED);
		//Set last mod usr tme so that it can be used to determine disconnected exams.
		eq.setLastModUserTime(new Date());
		eq.setAnswerElapsedTime(answerElapsedTime);
		skippedExamQuestionList.add(eq);
		
		return eq;
	}

	public ISession getSession() {
		return session;
	}

	public void setSession(ISession session) {
		this.session = session;
	}

	@Override
	public List<QuesAnsw> getQuesAnswList() {		
		return this.quesAnswList;
	}

	/**
	 * @param quesAnswList the quesAnswList to set
	 */
	public void setQuesAnswList(List<QuesAnsw> quesAnswList) {
		this.quesAnswList = quesAnswList;
	}
}
