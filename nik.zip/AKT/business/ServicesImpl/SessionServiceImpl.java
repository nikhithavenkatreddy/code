package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.BooleanWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.EaseInboundMessageWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.IntegerWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.LangWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.SessionBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.SessionListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.SessionWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.StringWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.WorkstationMapListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IEaseInboundMessageWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ILangWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.Session;
import gov.ca.dmv.AKT.integration.BeansImpl.ThresholdDictionary;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.integration.Persistence.ExamPersistence;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;
import gov.ca.dmv.AKT.integration.Persistence.MiscPersistence;
import gov.ca.dmv.AKT.integration.Persistence.SessionPersistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SessionServiceImpl extends BaseServiceImpl implements SessionService {

	private MiscPersistence    miscPersistence;
	private SessionPersistence sessionPersistence;
	private ExamPersistence    examPersistence;
	private IPersistence       persistence;
	public IPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}

	public ExamPersistence getExamPersistence() {
		return examPersistence;
	}

	public void setExamPersistence(ExamPersistence examPersistence) {
		this.examPersistence = examPersistence;
	}

	public SessionPersistence getSessionPersistence() {
		return sessionPersistence;
	}

	public void setSessionPersistence(SessionPersistence sessionPersistence) {
		this.sessionPersistence = sessionPersistence;
	}

	public MiscPersistence getMiscPersistence() {
		return miscPersistence;
	}

	public void setMiscPersistence(MiscPersistence miscPersistence) {
		this.miscPersistence = miscPersistence;
	}
	
	/*
	 * This method is called to load language by language id code
	 */
	public ILangWL getLang(String langIdCode) {
		ILangWL langWL = new LangWL();
		langWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<Lang> langList = miscPersistence.loadByLanguageIdCode(langIdCode);
			if(langList != null && langList.size() > Constant.ZERO) {
				langWL.setLang(langList.get(Constant.FIRST_ELEMENT));
			}
			else {
				langWL.setErrorCode(ErrorCode.MISSING_LANG);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			langWL.setErrorCode(e.getErrorCode());
		}
		return langWL;
	}

	private Integer getTimeBetweenSessions(){
		Integer timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TIME_BETWEEN_SESSIONS);
		timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_TIME_BETWEEN_SESSIONS;
		return timeout/TimeLimitTypeConstant.SECONDS;		
	}
	
	/*
	 * This method is called to check if a new session is allowed to be created only if there are no 
	 * existing active sessions  
	 */
	@SuppressWarnings("unchecked")
	public ISessionBooleanWL isNewSessionPermitted(Integer applicationId, String ipAddress, String langCode, boolean resume, Boolean additionalTestFlag) {
		ISessionBooleanWL boolWL = new SessionBooleanWL();
		boolWL.setErrorCode(ErrorCode.NO_ERROR);
		boolWL.setFlag(true);
		List<ISession> sessList = null;
		List<ISession> sessList2 = null;
		try {
			ISession sess = new Session();
			sess.setWorkstationIPAddress(ipAddress);
			sess.setSessionStatusCode(Constant.SESSION_RESERVED);
			sess.setSessionEndTime(Constant.defaultDate);
			sessList2 = persistence.findByExample(sess);
			sess = null;
			if(sessList2!=null && sessList2.size()>0){
				for(ISession sess1 : sessList2){
					if(Constant.isToday((sess1.getSessionStartTime()))){
						sess = sess1;
					}
				}		
			}
			if(sess!=null) {
				if(!sess.getApplicationId().equals(applicationId)) {
					boolWL.setErrorCode(ErrorCode.UNAUTH_TERM_ACCESS);
				}
				else {
					boolWL.setErrorCode(ErrorCode.AUTH_TERM_ACCESS); //TODO remove this
					sess.setLanguageCode(langCode);
					Date currentDate = new Date();
					sess.setLastModUserTime(currentDate);
					sess.setLastModUsername(getUserId());
					sess.setSessionStatusCode(Constant.SESSION_ACTIVE);
					if(!resume)
						persistence.update(sess);
					boolWL.setSession(sess);
				}
			}
			else {
				sessList = sessionPersistence.load(applicationId);
				if(sessList != null && sessList.size() > Constant.ZERO) {
					ISession session = sessList.get(Constant.FIRST_ELEMENT);
					if(Constant.isSameDay(session.getSessionEndTime(), Constant.defaultDate) && !additionalTestFlag) {
						boolWL.setFlag(false);
						boolWL.setErrorCode(ErrorCode.OPEN_SESSION);
					}
					if(!Constant.hasEndedLongEnough2(session.getSessionEndTime(), getTimeBetweenSessions()) && !additionalTestFlag) {
						boolWL.setFlag(false);
						//boolWL.setFlag(true); TODO
						boolWL.setErrorCode(ErrorCode.NEED_STUDY);
					}
					if(session.getYobValidationFlag().equalsIgnoreCase(Constant.YES) && Constant.isSameDay(session.getYobOverrideTime(), Constant.defaultDate)) {
						boolWL.setFlag(false);
						boolWL.setErrorCode(ErrorCode.YOB_ENDED_SESSION);
					}
				}
			}
		}
		catch(AKTException e) {
			boolWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return boolWL;
	}

	/*
	 * This method is called to save the created session
	 */
	public ISessionWL createSession(ISession session3) {
		ISessionWL sessionWL = new SessionWL();
		sessionWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.save(session3);
			sessionWL.setSession(session3);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			sessionWL.setErrorCode(e.getErrorCode());
		}
		return sessionWL;
	}

	/*
	 * This method is called to end the session marking session end time
	 */
	public IErrorWL endSession(Integer sessionId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			sessionPersistence.update(sessionId, new Date());
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get the list of sessions for failed yob
	 */
	public ISessionListWL getFailedYOB(String officeId) {
		ISessionListWL sessWL = new SessionListWL();
		sessWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {officeId, Constant.YES, Constant.defaultDate};
		try {
			List<ISession> sessionList = sessionPersistence.loadFailedYOB(params);
			List<ISession> sessionList2 = new ArrayList<ISession>(); 
			if(sessionList != null && sessionList.size() > Constant.ZERO) {
				for(ISession sess: sessionList) {
					if(Constant.isToday(sess.getSessionStartTime())) {
						sessionList2.add(sess);
					}
				}
				sessWL.setSessionList(sessionList2);
			}
			else {
				sessWL.setErrorCode(ErrorCode.MISSING_SESSION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			sessWL.setErrorCode(e.getErrorCode());
		}
		return sessWL;
	}

	/*
	 * This method is called to override yob validation by updating session
	 */
	public IErrorWL overrideYOBValidation(Integer sessionId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			sessionPersistence.updateYOBOverrideTime(sessionId, new Date());
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get a list of active sessions by field office id and app type
	 */
	@SuppressWarnings("unchecked")
	public IActiveSessionAndExamListWL getActiveExams(String officeId, String appType) {
		IActiveSessionAndExamListWL actWL = new ActiveSessionAndExamListWL();
		actWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			ISession session = new Session();
			session.setOfficeId(officeId);
			session.setSessionEndTime(Constant.defaultDate);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList = persistence.findByExample(session);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Session>();
			if(sessionList != null && sessionList.size() > Constant.ZERO) {
				for(gov.ca.dmv.AKT.integration.BeansImpl.Session sess: sessionList) {
					if(Constant.isToday(sess.getSessionStartTime()) && (sess.getSessionStatusCode().trim().equals(Constant.SESSION_ACTIVE) || sess.getSessionStatusCode().trim().equals(Constant.SESSION_TESTING))) {
						sessionList2.add(sess);
					}
				}
				List<gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam> activeList = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam>();
				for(ISession sess2: sessionList2) {
					Object[] params2 = {sess2.getSessionId(), Constant.defaultDate, Constant.defaultDate, appType};
					List<IExam> examList = examPersistence.loadBySessionId(params2);
					if(examList != null && examList.size() > Constant.ZERO) {
						IExam exam = examList.get(Constant.FIRST_ELEMENT);
						gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam active = new gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam();
						active.setExam(exam);
						active.setSession(sess2);
						activeList.add(active);
					}
					else if(sess2.getSessionStatusCode().trim().equals(Constant.SESSION_ACTIVE)){
						gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam active = new gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam();						
						active.setSession(sess2);
						activeList.add(active);						
					}
					else {
						actWL.setErrorCode(ErrorCode.MISSING_EXAMS);
					}
				}
				actWL.setActiveSessionAndExamList(activeList);
			}
			else {
				actWL.setErrorCode(ErrorCode.MISSING_SESSION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			actWL.setErrorCode(e.getErrorCode());
		}
		return actWL;
	}

	/*
	 * This method is called to reset session end time and yob indicator
	 */
	public IErrorWL reset(Integer sessionId, String sessionStatus) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			sessionPersistence.reset(sessionId, Constant.defaultDate, Constant.defaultDate, Constant.NO, sessionStatus);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to reset session terminal
	 */
	public IErrorWL resetTerminal(Integer sessionId, String workstationIPAddress) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			sessionPersistence.resetTerminal(sessionId, workstationIPAddress);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get session by session id
	 */
	public ISessionWL getSessionBySessionId(Integer sessionId) {
		ISessionWL sessWL = new SessionWL();
		sessWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			ISession sess = new Session();
			sess = (ISession) persistence.findById(sess, sessionId);
			if(sess != null) {
				sessWL.setSession(sess);
			}
			else {
				sessWL.setErrorCode(ErrorCode.MISSING_SESSION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			sessWL.setErrorCode(e.getErrorCode());
		}
		return sessWL;
	}
	
	
	
	/*
	 * This method is called to get a list of exams
	 */
	public ISessionListWL getAllSessionsByOfficeId(String officeId, String appType) {
		ISessionListWL slWL = new SessionListWL();
		slWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {officeId, appType};
		List<ISession> sessionList = sessionPersistence.loadAllSessions(params);
		List<ISession> sessionList2 = new ArrayList<ISession>();
		if(sessionList != null && sessionList.size() > Constant.ZERO) {
			for(ISession session: sessionList) {
				if(Constant.isToday(session.getLastModUserTime())) {
					sessionList2.add(session);
				}
			}
			slWL.setSessionList(sessionList2);
		}
		else {
			slWL.setErrorCode(ErrorCode.MISSING_EXAMS);
		}
		return slWL;
	}	

	/*
	 * This method is called to end session after setting yob validation flag to fail
	 */
	public IErrorWL endSessionWithYOBValidationFail(Integer sessionId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			sessionPersistence.updateWithYOBFail(sessionId, new Date(), Constant.YES);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	private Integer getTimeUntilDisconnected(){
		Integer timeout1 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TIME_PER_QUESTION);
		timeout1 = timeout1!=null?timeout1:TimeLimitTypeConstant.DEFAULT_TIME_PER_QUESTION;
		
		Integer timeout2 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.WARNING_BEFORE_TIMEOUT);
		timeout2 = timeout2!=null?timeout2:TimeLimitTypeConstant.DEFAULT_WARNING_BEFORE_TIMEOUT;
		
		Integer timeout3 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.ADDTNL_TIME_PER_QUESTION);
		timeout3 = timeout3!=null?timeout3:TimeLimitTypeConstant.DEFAULT_ADDTNL_TIME_PER_QUESTION;
		
		return (timeout1 + timeout2 + timeout3)/TimeLimitTypeConstant.SECONDS;		
	}
	
	/*
	 * This method is called to get a list of exams that were lost due to power failure or system error.
	 */
	@SuppressWarnings("unchecked")
	public IActiveSessionAndExamListWL getExams(String officeId, String appType) {
		IActiveSessionAndExamListWL actWL = new ActiveSessionAndExamListWL();
		actWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			ISession session = new Session();
			session.setOfficeId(officeId);
			session.setSessionEndTime(Constant.defaultDate);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList = persistence.findByExample(session);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Session>();
			if(sessionList != null && sessionList.size() > Constant.ZERO) {
				for(gov.ca.dmv.AKT.integration.BeansImpl.Session sess: sessionList) {
					if(Constant.isToday(sess.getSessionStartTime())) {
						sessionList2.add(sess);
					}
				}
				List<ActiveSessionAndExam> activeList = new ArrayList<ActiveSessionAndExam>();
				for(ISession sess2: sessionList2) {
					Object[] params2 = {sess2.getSessionId(), Constant.defaultDate, Constant.defaultDate, appType};
					List<IExam> examList = examPersistence.loadBySessionId(params2);
					if(examList != null && examList.size() > Constant.ZERO) {
						IExam exam = examList.get(Constant.FIRST_ELEMENT);
						List<ExamQuestion> eqList = examPersistence.getExamQuesOrderedByModTime(exam.getExamId());
						if(eqList != null && eqList.size() > Constant.ZERO) {
							ExamQuestion eq = eqList.get(Constant.FIRST_ELEMENT);
							if( eq != null && (sess2.getSessionStatusCode().trim().equals(Constant.SESSION_TERMINATED) ||  Constant.hasEndedLongEnough(eq.getLastModUserTime(),getTimeUntilDisconnected()))){
								ActiveSessionAndExam active = new ActiveSessionAndExam();
								active.setExam(exam);
								active.setSession(sess2);
								activeList.add(active);
							}
						}
					}
				}
				actWL.setActiveSessionAndExamList(activeList);
			}
			else {				
				actWL.setActiveSessionAndExamList(new ArrayList<ActiveSessionAndExam>());
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			actWL.setErrorCode(e.getErrorCode());
		}
		return actWL;
	}

	/*
	 * This method is called to get a list of sessions that have not ended.
	 */
	//TODO is no result, return an empty list instead of error
	@SuppressWarnings("unchecked")
	public ISessionListWL getCurrentSessions(String officeId) {
		ISessionListWL currSessionWL = new SessionListWL();
		currSessionWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			ISession session = new Session();
			session.setOfficeId(officeId);
			session.setSessionEndTime(Constant.defaultDate);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList = persistence.findByExample(session);
			List<gov.ca.dmv.AKT.integration.Beans.ISession> sessionList2 = new ArrayList<gov.ca.dmv.AKT.integration.Beans.ISession>();
			if(sessionList != null && sessionList.size() > Constant.ZERO) {
				for(gov.ca.dmv.AKT.integration.Beans.ISession sess: sessionList) {
					if(Constant.isToday(sess.getSessionStartTime())) {
						sessionList2.add(sess);
					}
				}
				currSessionWL.setSessionList(sessionList2);
			}
			else {
				currSessionWL.setErrorCode(ErrorCode.MISSING_SESSION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			currSessionWL.setErrorCode(e.getErrorCode());
		}
		return currSessionWL;
	}
	
	/*
	 * This method is called to get the workstation id based on the workstation IP address.
	 */
	@SuppressWarnings("unchecked")
	public IStringWL getWorkstationId(String workstationIPAddress) {
		IStringWL strWL = new StringWL();
		strWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			WorkstationMap wm = new WorkstationMap();
			wm = (WorkstationMap) persistence.findById(wm, workstationIPAddress);
			//List<WorkstationMap> wmList = miscPersistence.loadByWorkstationIP(workstationIPAddress);
			if(wm != null) {
				strWL.setString(wm.getWorkstationId());
			}
			else {
				strWL.setErrorCode(ErrorCode.MISSING_FO);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			strWL.setErrorCode(e.getErrorCode());
		}
		return strWL;
	}

	/*
	 * This method is called to get the threshold value for the corresponding threshold name
	 */
	public IStringWL getThresholdValue(String threshold) {
		IStringWL strWL = new StringWL();
		strWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<ThresholdDictionary> tdList = miscPersistence.loadThreshold(threshold);
			if(tdList != null && tdList.size() > Constant.ZERO) {
				strWL.setString(tdList.get(Constant.FIRST_ELEMENT).getThresholdValue());
			}
			else {
				strWL.setErrorCode(ErrorCode.MISSING_THRESHOLD);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			strWL.setErrorCode(e.getErrorCode());
		}
		return strWL;
	}

	public IIntegerWL saveEaseReceivedString(String receivedStr) {
		IIntegerWL errWL = new IntegerWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		IEaseInboundMessage message = new gov.ca.dmv.AKT.integration.BeansImpl.EaseInboundMessage();
		Date currentDate = new Date();
		message.setEaseApplicationMessage(receivedStr);
		message.setEaseMessageIndicator(Constant.SINGLE_SPACE);
		message.setEaseMessageReceivedTimestamp(currentDate);
		message.setLastModUsername(getUserId());
		message.setLastModUserTime(currentDate);
		try {
			miscPersistence.saveEaseReceivedString(message);
			errWL.setInteger(message.getEaseMessageId());
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get the ease inbound message based on the received string
	 */
	public IEaseInboundMessageWL getEaseInboundMessage(Integer easeMsgId) {
		IEaseInboundMessageWL msgWL = new EaseInboundMessageWL();
		msgWL.setErrorCode(ErrorCode.NO_ERROR);
		List<IEaseInboundMessage> msgList = miscPersistence.loadEaseInboundMessage(easeMsgId);
		if(msgList != null && msgList.size() > Constant.ZERO) {
			msgWL.setEaseInboundMessage(msgList.get(Constant.FIRST_ELEMENT));
		}
		return msgWL;
	}

	/*
	 * This method is called to save the ease inbound message with updated received indicator
	 */
	public IErrorWL saveEaseInboundMessage(IEaseInboundMessage message) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			miscPersistence.saveEaseReceivedString(message);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get all workstations by office id.
	 */
	@SuppressWarnings("unchecked")
	public IWorkstationMapListWL getAllWorkstationsByOfficeId(String officeId) {
		IWorkstationMapListWL wmWL = new WorkstationMapListWL();
		wmWL.setErrorCode(ErrorCode.NO_ERROR);
		WorkstationMap wm = new WorkstationMap();
		wm.setOfficeId(officeId);
		try {
			List<WorkstationMap> wmList = (List<WorkstationMap>)persistence.findByExample(wm);
			wmWL.setWorkstationMapList(wmList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			wmWL.setErrorCode(e.getErrorCode());
		}
		return wmWL;
	}
	
	/*
	 * This method is called to get all workstations by ip address.
	 */
	@SuppressWarnings("unchecked")
	public IWorkstationMapListWL getWorkstationByIP(String ipAddr) {
		IWorkstationMapListWL wmWL = new WorkstationMapListWL();
		wmWL.setErrorCode(ErrorCode.NO_ERROR);
		WorkstationMap wm = new WorkstationMap();
		wm.setWorkstationIPAddress(ipAddr);
		try {
			List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
			wm	= (WorkstationMap)persistence.findById(wm, ipAddr); 
			wmList.add(wm);
			wmWL.setWorkstationMapList(wmList);
			if(wm==null){
				wmWL.setErrorCode(ErrorCode.MISSING_WORKSTATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			wmWL.setErrorCode(e.getErrorCode());
		}
		return wmWL;
	}
	
	/*
	 * This method is called to persist the updated workstation records
	 */
	public IErrorWL updateWorkstations(List<WorkstationMap> wmList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.updateList(wmList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to check whether the terminal based on the ip address is reserved or not.
	 */
	@SuppressWarnings("unchecked")
	public IBooleanWL isTerminalUsedInSession(String ipAddress, String officeId) {
		WorkstationMap wm = new WorkstationMap();
		wm.setWorkstationIPAddress(ipAddress);
		IBooleanWL boolWL = new BooleanWL();
		boolWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			wm = (WorkstationMap) persistence.findById(wm, ipAddress);
			if(wm != null) {
				ISession session = new Session();
				session.setOfficeId(officeId);
				session.setSessionEndTime(Constant.defaultDate);
				session.setWorkstationIPAddress(wm.getWorkstationIPAddress());
				List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList = persistence.findByExample(session);
				boolWL.setFlag(false);
				for(gov.ca.dmv.AKT.integration.BeansImpl.Session sess : sessionList) {
					if(Constant.isToday(sess.getSessionStartTime())){
						boolWL.setFlag(true);						
					}
				}
			}
			else {
				boolWL.setErrorCode(ErrorCode.MISSING_WORKSTATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			boolWL.setErrorCode(e.getErrorCode());
		}
		return boolWL;
	}
	
	/*
	 * This method returns a list of workstation map records based on workstation id and office id.
	 */
	@SuppressWarnings("unchecked")
	public IWorkstationMapListWL getWorkstationMapByStationIdAndOfficeId(String workstationId, String  officeId) {
		IWorkstationMapListWL wmWL = new WorkstationMapListWL();
		try {
			// This is to get the workstationId when we have workstationId with office id ex:- 295-10 we will get 10.
			if(workstationId.contains("-")) {
				String[] split = workstationId.split("-");
				workstationId = split[Constant.ONE];
			}
			WorkstationMap wm = new WorkstationMap();
			wm.setOfficeId(officeId);
			wm.setWorkstationId(workstationId);
			List<WorkstationMap> wmList = persistence.findByExample(wm);
			if(wmList != null && wmList.size() > Constant.ZERO) {
				wmWL.setWorkstationMapList(wmList);
			}
			else {
				wmWL.setErrorCode(ErrorCode.MISSING_WORKSTATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			wmWL.setErrorCode(e.getErrorCode());
		}
		return wmWL;
	}
}
