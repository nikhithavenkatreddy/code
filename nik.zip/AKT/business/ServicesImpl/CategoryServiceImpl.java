package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.CategoryService;
import gov.ca.dmv.AKT.business.WorkloadImpl.CategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoryServiceImpl extends BaseServiceImpl implements CategoryService {
	private IPersistence persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}
	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}
	private String getLikeString(String str) {
		return (Constant.PER + str.trim() + Constant.PER);
	}
	
	/*
	 * This method is called to get a list of categories.
	 */
		@Override
		public ICategoryListWL getCategory(String categoryId) {
			
			ICategoryListWL categoryListWL= new CategoryListWL();
	        categoryListWL.setErrorCode(ErrorCode.NO_ERROR);
	        List<Category> categoryList = new ArrayList<Category>();
	        Category categoryBO= new Category();
	        try{
	        	categoryBO = (Category)persistence.findById(categoryBO, categoryId);
	        	if (categoryBO == null) {
	        		categoryListWL.setErrorCode(ErrorCode.MISSING_CATEGORY);
	        	}
	        	else if( categoryBO != null ) {
                     categoryList.add(Constant.FIRST_ELEMENT,categoryBO);
                     categoryListWL.setCategoryList(categoryList);      	        		
	        	}
	        }
	        catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				categoryListWL.setErrorCode(e.getErrorCode());
			}
		 return  categoryListWL;
		}
	
	
	
		/*
		 * This method is called to create test 
		 */
	    @Override
		public IErrorWL saveCategory(Category category) {
			IErrorWL errorWL = new ErrorWL();
			errorWL.setErrorCode(ErrorCode.NO_ERROR);
			try {
				persistence.save(category);
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errorWL.setErrorCode(e.getErrorCode());
			}
			return errorWL;
		}
	        
	    
		/*
		 * This method is called to update a list of categories.
		 */
		@Override 
	     public IErrorWL updateCategory(Category category){
		    IErrorWL errorWL = new ErrorWL();
			errorWL.setErrorCode(ErrorCode.NO_ERROR);
		    try{
		      	persistence.update(category);	
		        }
		    catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errorWL.setErrorCode(e.getErrorCode());
				}
		    return   errorWL;
		  }
		
			
		
		/*
		* This method is called to search category by ids and/or name of categories.
		*/
		@SuppressWarnings("unchecked")
		@Override
		public ICategoryListWL searchCategory(Category category) {
			ICategoryListWL categoryListWL= new CategoryListWL();
			Map<String,Object> conditionMap = new HashMap<String,Object>(); 			
			conditionMap.put("categoryId",getLikeString(category.getCategoryId()) );
			conditionMap.put("categoryName", getLikeString(category.getCategoryName()));
			IErrorWL errorWL = new ErrorWL();
			errorWL.setErrorCode(ErrorCode.NO_ERROR);
			List<Category> categoryList = null;
			try{
				categoryList= (List<Category>) persistence.loadWithLikeConditionsIgnoreCaseAndOrderBy(Category.class, conditionMap,null);	       
				categoryListWL.setCategoryList(categoryList);
				if (categoryList.size()==Constant.ZERO) {
	        		categoryListWL.setErrorCode(ErrorCode.NO_MATCH_FOUND);
				}
			}
	        catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errorWL.setErrorCode(e.getErrorCode());
			}
			return  categoryListWL;
		}
}
