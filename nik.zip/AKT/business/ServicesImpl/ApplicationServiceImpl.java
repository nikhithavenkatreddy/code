package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.ApplicationService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicantListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicationListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.BooleanWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamHistoryWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.VaultListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.VaultWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Applicant;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;
import gov.ca.dmv.AKT.integration.BeansImpl.ApplicationSecondary;
import gov.ca.dmv.AKT.integration.BeansImpl.EaseApplication;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.BeansImpl.VaultSecondary;
import gov.ca.dmv.AKT.integration.BeansImpl.YOB;
import gov.ca.dmv.AKT.integration.Persistence.ApplicantPersistence;
import gov.ca.dmv.AKT.integration.Persistence.ApplicationPersistence;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;
import gov.ca.dmv.AKT.integration.Persistence.TestPersistence;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplicationServiceImpl extends BaseServiceImpl implements ApplicationService {

	private ApplicantPersistence         applicantPersistence;
	private ApplicationPersistence       applicationPersistence;
	private TestPersistence              testPersistence;
	private IPersistence                 persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}
	
	public TestPersistence getTestPersistence() {
		return testPersistence;
	}

	public void setTestPersistence(TestPersistence testPersistence) {
		this.testPersistence = testPersistence;
	}

	public ApplicationPersistence getApplicationPersistence() {
		return applicationPersistence;
	}

	public void setApplicationPersistence(ApplicationPersistence applicationPersistence) {
		this.applicationPersistence = applicationPersistence;
	}

	public ApplicantPersistence getApplicantPersistence() {
		return applicantPersistence;
	}

	public void setApplicantPersistence(ApplicantPersistence applicantPersistence) {
		this.applicantPersistence = applicantPersistence;
	}

	/*
	 * This method is called to validate YOB
	 */
	public IBooleanWL validateYOB(YOB yob) {
		IBooleanWL boolWL = new BooleanWL();
		String dobString = null;
		String laststName = null;
		IVault firstVault = examSessionData.getVault();
		if(firstVault.getVaultId().equals(yob.getVaultId())) {
			SimpleDateFormat format = new SimpleDateFormat(Constant.EASE_DATE_FORMAT);
			dobString = format.format(firstVault.getBirthDate());
			laststName = firstVault.getApplicationLastName();
			if(firstVault.getApplicationLastName().length() >= 3) {
				laststName = firstVault.getApplicationLastName().substring(Constant.ZERO, Constant.THREE);
			}
		}
		boolean validationSuccessful = false;
		if(yob.getDob().equalsIgnoreCase(dobString) && yob.getThreeCharLastName().equalsIgnoreCase(laststName)) {
			validationSuccessful = true;
		}
		boolWL.setFlag(validationSuccessful);
		return boolWL;
	}
	
	/*
	 * This method is called to get the application based on DL and Field Office Id
	 */
	public IApplicationWL getApplication(gov.ca.dmv.AKT.integration.BeansImpl.DLFO dlfo) {
		String dlNumber = dlfo.getDlNumber();
		IApplicationWL applicationWL = new ApplicationWL();
		applicationWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Vault> vaultList = null;
		try {
			vaultList = applicantPersistence.loadByDL(dlNumber);
		}
		catch(AKTException e) {
			applicationWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		IVault vault = null;
		if(vaultList != null && vaultList.size() > Constant.ZERO) {
			vault = vaultList.get(Constant.FIRST_ELEMENT);
		}
		applicationWL.setApplication(null);
		/*
		 * Check to see if the vault is an active record for today
		 */
		if((vault != null) && Constant.isToday(vault.getVaultTimestamp())) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Application> appList = null;
			try {
				appList = applicationPersistence.loadByVaultId(vault.getVaultId());
			}
			catch(AKTException e) {
				applicationWL.setErrorCode(e.getErrorCode());
				logger.error(e.getMessage());
				logger.error(e.getCause());
			}
			IApplication application = null;
			if(appList != null && appList.size() > Constant.ZERO) {
				application = appList.get(Constant.FIRST_ELEMENT);
			}
			/*
			 * Check to see if the field office in the application matches with the field office retrieved from
			 * identity management
			 */
			if(application.getOfficeId().equals(dlfo.getOfficeId())) {
				applicationWL.setApplication(application);
				examSessionData.setApplication(application);
				examSessionData.setVault(vault);
			}
		}
		return applicationWL;
	}
	
	private IErrorWL fail(IExamHistory examHistory1) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		int aktStatusIndicator = Constant.ZERO;
		if(!examHistory1.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
			aktStatusIndicator = Integer.parseInt(examHistory1.getAktStatusIndicator());
		}
		aktStatusIndicator++;
		examHistory1.setAktStatusIndicator(String.valueOf(aktStatusIndicator));
		Object[] params = {examHistory1.getApplicationId(), examHistory1.getEaseTestId()};
		try {
			applicationPersistence.update(params, examHistory1.getAktStatusIndicator(), new Date());
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to update the exam history for a failed exam
	 */
	@SuppressWarnings("unchecked")
	public IBooleanWL markFailed(IExamHistory examHistory) {
		IBooleanWL boolWL = new BooleanWL();
		try {
			List<IExamHistory> ehList = persistence.findByExample(examHistory);
			if(ehList != null && ehList.size() > Constant.ZERO) {
				IExamHistory examHistory1 = ehList.get(Constant.FIRST_ELEMENT);
				boolWL.setFlag(false);
				IErrorWL errWL = fail(examHistory1);
				if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
					int aktStatusIndicator = 0;
					if(!examHistory1.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
						aktStatusIndicator = Integer.parseInt(examHistory1.getAktStatusIndicator());
					}
					int easeStatusIndicator = 0;
					if(!examHistory1.getEaseStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
						easeStatusIndicator = Integer.parseInt(examHistory1.getEaseStatusIndicator()); 
					}
					if((aktStatusIndicator + easeStatusIndicator) < 3) {
						boolWL.setFlag(true);
					}
				}
				else {
					boolWL.setErrorCode(errWL.getErrorCode());
				}
			}
			else {
				boolWL.setErrorCode(ErrorCode.MISSING_EXAM_HISTORY);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			boolWL.setErrorCode(e.getErrorCode());
		}
		return boolWL;
	}

	/*
	 * This method is called by the batch process to update the exam history with akt status indicator for fail
	 */
	@SuppressWarnings("unchecked")
	public IErrorWL markFailedBatch(IExamHistory examHistory) {
		IErrorWL errWL = new ErrorWL();
		try {
			List<IExamHistory> ehList = persistence.findByExample(examHistory);
			if(ehList != null && ehList.size() > Constant.ZERO) {
				IExamHistory examHistory1 = ehList.get(Constant.FIRST_ELEMENT);
				if(examHistory1.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
					examHistory1.setAktStatusIndicator(String.valueOf(Constant.ZERO));
				}
				int aktStatusIndicator = Integer.parseInt(examHistory1.getAktStatusIndicator());
				aktStatusIndicator++;
				examHistory1.setAktStatusIndicator(String.valueOf(aktStatusIndicator));
				examHistory1.setAktUpdatedTimestamp(new Date());
				persistence.update(examHistory1);
			}
			else {
				errWL.setErrorCode(ErrorCode.MISSING_EXAM_HISTORY);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get vault by vault id
	 */
	public IVaultWL getVault(Integer vaultId) {
		IVaultWL vaultWL = new VaultWL();
		vaultWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			IVault vault = new Vault();
			vault = (IVault) persistence.findById(vault, vaultId);
			if(vault != null) {
				vaultWL.setVault(vault);
			}
			else {
				vaultWL.setErrorCode(ErrorCode.MISSING_VAULT);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			vaultWL.setErrorCode(e.getErrorCode());
		}
		return vaultWL;
	}
	
	/*
	 * This method is called to update the application and exam history table for force failing an exam.
	 */
	@SuppressWarnings("unchecked")
	public IErrorWL markForceFailed(IExamHistory examHistory) {
		IErrorWL errorWL = new ErrorWL();
		try {
			List<IExamHistory> ehList = persistence.findByExample(examHistory);
			if(ehList != null && ehList.size() > Constant.ZERO) {
				IExamHistory examHistory1 = ehList.get(Constant.FIRST_ELEMENT);
				if(examHistory1.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE))
					examHistory1.setAktStatusIndicator(String.valueOf(Constant.ZERO));
				IErrorWL errWL = fail(examHistory1);
				if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
					applicationPersistence.update(examHistory.getApplicationId(), Constant.YES);
				}
				else {
					errorWL.setErrorCode(errWL.getErrorCode());
				}
			}
			else {
				errorWL.setErrorCode(ErrorCode.MISSING_EXAM_HISTORY);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}

	/*
	 * This method is called to get exam history by application id and ease test id
	 */
	@SuppressWarnings("unchecked")
	public IExamHistoryWL getExamHistory(IExamHistory examHistory) {
		IExamHistoryWL ehWL = new ExamHistoryWL();
		try {
			List<IExamHistory> ehList = persistence.findByExample(examHistory);
			if(ehList != null && ehList.size() > Constant.ZERO) {
				ehWL.setExamHistory(ehList.get(Constant.FIRST_ELEMENT));
			}
			else {
				ehWL.setErrorCode(ErrorCode.MISSING_EXAM_HISTORY);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			ehWL.setErrorCode(e.getErrorCode());
		}
		return ehWL;
	}

	/*
	 * This method is called to get Test by testId.
	 */
	public ITestWL getTest(String testId) {
		ITestWL testWL = new TestWL();
		testWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<Test> testList = testPersistence.loadByTestId(testId);
			if(testList != null && testList.size() > Constant.ZERO) {
				testWL.setTest(testList.get(Constant.FIRST_ELEMENT));
			}
			else {
				testWL.setErrorCode(ErrorCode.MISSING_TEST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			testWL.setErrorCode(e.getErrorCode());
		}
		return testWL;
	}

	/*
	 * This method is called to persist the data received from EASE application in Vault, Application, Exam, 
	 * ExamHistory and Test tables.
	 */
	public IApplication create(EaseApplication easeApplication) {
		applicantPersistence.save(easeApplication.getVault());
		Object[] params = {easeApplication.getVault().getDlNumber().trim(), easeApplication.getVault().getVaultTimestamp()};
		List<gov.ca.dmv.AKT.integration.BeansImpl.Vault> vaultList = applicantPersistence.loadByDLAndVaultTstamp(params);
		IVault vault = vaultList.get(Constant.FIRST_ELEMENT);
		IApplication application = easeApplication.getApplication();
		application.setVaultId(vault.getVaultId());
		applicationPersistence.saveApplication(application);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Application> appList = applicationPersistence.loadByVaultId(vault.getVaultId());
		IApplication application2 = appList.get(Constant.FIRST_ELEMENT);
		return application2;
	}

	/*
	 * This method is called to update the akt and ease status indicators in the exam history table.
	 */
	public IErrorWL updateExamHistory(IExamHistory examHistory) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.update(examHistory);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get application by application id.
	 */
	public IApplicationWL getApplication(Integer applicationId) {
		IApplicationWL appWL = new ApplicationWL();
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			IApplication app = new Application();
			app = (IApplication)persistence.findById(app, applicationId);
			if(app != null) {
				appWL.setApplication(app);
			}
			else {
				appWL.setErrorCode(ErrorCode.MISSING_APPLICATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			appWL.setErrorCode(e.getErrorCode());
		}
		return appWL;
	}

	/*
	 * This method is called to increment the pause count for an application by application id.
	 */
	public IErrorWL incrementPauseCount(Integer applicationId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Application> appList = applicationPersistence.load(applicationId);
			if(appList != null && appList.size() > Constant.ZERO) {
				IApplication app = appList.get(Constant.FIRST_ELEMENT);
				int pauseCount = Constant.ZERO;
				if(!app.getPauseCount().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
					pauseCount = Integer.parseInt(app.getPauseCount());
				}
				pauseCount++;
				app.setPauseCount(String.valueOf(pauseCount));
				applicationPersistence.saveApplication(app);
			}
			else {
				errWL.setErrorCode(ErrorCode.MISSING_APPLICATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to increment the pause count for an application by application id.
	 */
	public IErrorWL incrementPauseCountFO(Integer applicationId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Application> appList = applicationPersistence.load(applicationId);
			if(appList != null && appList.size() > Constant.ZERO) {
				IApplication app = appList.get(Constant.FIRST_ELEMENT);
				int pauseCount = Constant.ZERO;
				if(!app.getPauseCount().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
					pauseCount = Integer.parseInt(app.getPauseCount());
				}
				if(pauseCount == Constant.ZERO){
					pauseCount++;
					app.setPauseCount(String.valueOf(pauseCount));
					applicationPersistence.saveApplication(app);
				}
				else{
					errWL.setErrorCode(ErrorCode.SINGLE_PAUSE_ALLOWED);
				}
			}
			else {
				errWL.setErrorCode(ErrorCode.MISSING_APPLICATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to update application with sign test satisfied
	 */
	public IErrorWL updateApplication(IApplication app) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			applicationPersistence.saveApplication(app);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to get Vault by DL
	 */
	@SuppressWarnings("unchecked")
	public IVaultWL getVaultByDL(String dl) {
		IVaultWL vaultWL = new VaultWL();
		vaultWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("dlNumber", dl);
			List<String> orders = new ArrayList<String>();
			orders.add("vaultTimestamp");
			
			List<IVault> vaultList = persistence.loadWithConditionsAndOrderBy(Vault.class, params, orders);
			if (vaultList == null || vaultList.isEmpty()) {
				List<IVault> vaultSecondaryList = persistence.loadWithConditionsAndOrderBy(VaultSecondary.class, params, orders);
				vaultList.addAll(vaultSecondaryList);
			}
			if(vaultList != null && vaultList.size() > Constant.ZERO) {
				vaultWL.setVault(vaultList.get(Constant.FIRST_ELEMENT));
			}
			else {
				vaultWL.setErrorCode(ErrorCode.MISSING_VAULT);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			vaultWL.setErrorCode(e.getErrorCode());
		}
		return vaultWL;
	}
	
	/*
	 * This method is called to get Vault by DL and LastName
	 */
	@SuppressWarnings("unchecked")
	public IVaultWL getVaultByDLOrLastName(String dl,String lastName) {
		IVaultWL vaultWL = new VaultWL();
		vaultWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("applicationLastName", Constant.PER+lastName.trim()+Constant.PER);
			params.put("dlNumber", dl.trim());
			List<String> orders = new ArrayList<String>();
			orders.add("vaultTimestamp");
			
			List<IVault> vaultList = persistence.loadWithLikeConditionsIgnoreCaseAndOrderBy(Vault.class, params, orders);
			if (vaultList == null || vaultList.isEmpty()) {
				List<IVault> vaultSecondaryList = persistence.loadWithConditionsAndOrderBy(VaultSecondary.class, params, orders);
				vaultList.addAll(vaultSecondaryList);
			}
			if(vaultList != null && vaultList.size() > Constant.ZERO) {
				vaultWL.setVault(vaultList.get(Constant.FIRST_ELEMENT));
			}
			else {
				vaultWL.setErrorCode(ErrorCode.MISSING_VAULT);
			}
		}
		catch(AKTException e ) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			vaultWL.setErrorCode(e.getErrorCode());
		}
		catch(NullPointerException ne ) {
			logger.error(ne.getMessage());
			logger.error(ne.getCause());
			vaultWL.setErrorCode(ErrorCode.NO_MATCH_FOUND);
		}
		return vaultWL;
	}

	/*
	 * This method is called to get application by vault id
	 */
	@SuppressWarnings("unchecked")
	public IApplicationWL getApplicationByVaultId(Integer vaultId) {
		IApplicationWL appWL = new ApplicationWL();
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			IApplication app = new Application();
			app.setVaultId(vaultId);
			List<IApplication> appList = persistence.findByExample(app);
			
			if (appList == null || appList.isEmpty()) {
				ApplicationSecondary appSec = new ApplicationSecondary();
				app.setVaultId(vaultId);
				List<IApplication> appSecList = persistence.findByExample(appSec);
				appList.addAll(appSecList);
			}
			if(appList != null && appList.size() > Constant.ZERO) {
				appWL.setApplication(appList.get(Constant.FIRST_ELEMENT));
			}
			else {
				appWL.setErrorCode(ErrorCode.MISSING_APPLICATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			appWL.setErrorCode(e.getErrorCode());
		}
		return appWL;
	}
	
	/*
	 * This method is called to get application by vault id and officeId
	 */
	@SuppressWarnings("unchecked")
	public IApplicationWL getApplicationByVaultIdAndOfficeId(Integer vaultId , String officeId) {
		IApplicationWL appWL = new ApplicationWL();
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			IApplication app = new Application();
			app.setOfficeId(officeId);
			app.setVaultId(vaultId);
			List<IApplication> appList = persistence.findByExample(app);
			
			if (appList == null || appList.isEmpty()) {
				ApplicationSecondary appSec = new ApplicationSecondary();
				appSec.setOfficeId(officeId);
				appSec.setVaultId(vaultId);
				List<IApplication> appSecList = persistence.findByExample(appSec);
				appList.addAll(appSecList);
			}
			if(appList != null && appList.size() > Constant.ZERO) {
				appWL.setApplication(appList.get(Constant.FIRST_ELEMENT));
			}
			else {
				appWL.setErrorCode(ErrorCode.MISSING_APPLICATION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			appWL.setErrorCode(e.getErrorCode());
		}
		return appWL;
	}

	public IExamHistoryListWL getExamHistoryByAppId(Integer applicationId) {	
		IExamHistoryListWL ehWL = new ExamHistoryListWL();
		ehWL.setErrorCode(ErrorCode.NO_ERROR);
		List<IExamHistory> examHistoryList = null;
		try {
			examHistoryList = applicationPersistence.loadExamHistoryByAppId(applicationId);
			ehWL.setExamHistoryList(examHistoryList);
		}
		catch(AKTException e) {
			ehWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return ehWL;
	}
	
	/*
	 * This is a helper method used to get the application type based on the group.
	 */
	private String getAppTypeBasedOnGroup(String group) {
		String appType = Constant.APP_TYPE_FO;
		if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			appType = Constant.APP_TYPE_DS;
		}
		else if(group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			appType = Constant.APP_TYPE_OL;
		}
		else if(group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
			appType = Constant.APP_TYPE_CHP;
		}
		return appType;
	}

	/*
	 * This method is called to retrieve today's applications by office id and group.
	 */
	public IApplicationListWL getTodaysApps(String officeId, String group) {
		IApplicationListWL appWL = new ApplicationListWL();
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			String appType = getAppTypeBasedOnGroup(group);
			List<IApplication> appList = applicationPersistence.loadTodaysApps(officeId, appType);
			appWL.setApplicationList(appList);
		}
		catch(AKTException e) {
			appWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return appWL;
	}

	/*
	 * This method is called to persist all updated application records.
	 */
	public IErrorWL updateApplications(List<Application> updatedAppList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.updateList(updatedAppList);
		}
		catch(AKTException e) {
			errWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return errWL;
	}
	
	/*
	 * This method is called to save vault record in the vault table.
	 */
	public IErrorWL saveVault(IVault vault) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.save(vault);
		}
		catch(AKTException e) {
			errWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return errWL;
	}
	
	/*
	 * This method is called to save application record in the application table.
	 */
	public IErrorWL saveApplication(IApplication application) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.save(application);
		}
		catch(AKTException e) {
			errWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return errWL;
	}

	/*
	 * This method is called to save a list of exam history records in the exam history table.
	 */
	public IErrorWL saveExamHistoryList(List<IExamHistory> ehList) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.saveList(ehList);
		}
		catch(AKTException e) {
			errWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return errWL;
	}

	/*
	 * This method is called to return a list of field office applications (no ds/ol apps) by office id and date range.
	 */
	public IApplicationListWL getAppsByOfficeIdAndDateRange(String officeId, Date fromDate, Date toDate, String appType) {
		IApplicationListWL appWL = new ApplicationListWL();
		try {
			List<IApplication> appList = applicationPersistence.loadAppsByOfficeIdAndDateRange(officeId, fromDate, toDate, appType);
			appWL.setApplicationList(appList);
		}
		catch(AKTException e) {
			appWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return appWL;
	}
	
	private String getLikeString(String str) {
		return (Constant.PER + str.trim() + Constant.PER);
	}
	
	/*
	 * This method is called to get a list of applicants based on the app type (across the office ids) and search criteria like date range (inclusive), dl number and last name (both partial search strings).
	 */
	public ApplicantListWL searchApplicantsByAppType(Date fromDate, Date toDate, String appType, String dl, String lastName) {
		lastName = lastName.trim() + Constant.PER;
		ApplicantListWL appWL = new ApplicantListWL();
		try {
			List<IVault> vaultList = applicantPersistence.loadByDLLastNameAndDateRange(dl, lastName, fromDate, toDate, true);
			HashMap<Integer, IVault> vaultMap = new HashMap<Integer, IVault>();
			for(IVault vault:vaultList) {
				vaultMap.put(vault.getVaultId(), vault);
			}
			List<IApplication> appList = applicationPersistence.loadAppsByAppTypeAndVaultList(true, appType, dl, lastName, fromDate, toDate);
			List<IVault> vaultListAll = applicantPersistence.loadByDLLastNameAndDateRange(dl, lastName, fromDate, toDate, false);
			for(IVault vault:vaultListAll) {
				vaultMap.put(vault.getVaultId(), vault);
			}
			List<IApplication> appListAll = applicationPersistence.loadAppsByAppTypeAndVaultList(false, appType, dl, lastName, fromDate, toDate);
			appList.addAll(appListAll);
			List<Applicant> applicantList = new ArrayList<Applicant>();
			for(IApplication application: appList) {
				Applicant applicant = new Applicant();
				applicant.setOfficeId(application.getOfficeId().trim());
				IVault vault = 	vaultMap.get(application.getVaultId());
				applicant.setDlNumber(vault.getDlNumber());
				applicant.setFirstName(vault.getApplicationFirstName());
				applicant.setLastName(vault.getApplicationLastName());
				applicant.setApplicationId(application.getApplicationId());
				applicantList.add(applicant);
			}
			appWL.setApplicantList(applicantList);
		} catch(AKTException e) {
			appWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return appWL;
	}
	
	/*
	 * This method is called to get a list of vaults
	 */
	public IVaultListWL getAllVaultsByOfficeId(String officeId, String appType) {
		IVaultListWL vlWL = new VaultListWL();
		vlWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {officeId, appType};
		List<Vault> vaultList = applicantPersistence.loadAllVaults(params);
		List<Vault> vaultList2 = new ArrayList<Vault>();
		if(vaultList != null && vaultList.size() > Constant.ZERO) {
			for(Vault vault: vaultList) {
				if(Constant.isToday(vault.getLastModUserTime())) {
					vaultList2.add(vault);
				}
			}
			vlWL.setVaultList(vaultList2);
		}
		else {
			vlWL.setErrorCode(ErrorCode.MISSING_EXAMS);
		}
		return vlWL;
	}	
	
}
