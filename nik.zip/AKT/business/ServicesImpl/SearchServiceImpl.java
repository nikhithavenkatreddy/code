package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.SearchService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicantListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicantListWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.SearchRequestTypeConstant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Applicant;
import gov.ca.dmv.AKT.integration.BeansImpl.Exam;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Search;
import gov.ca.dmv.AKT.integration.BeansImpl.Session;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.integration.Persistence.ApplicantPersistence;
import gov.ca.dmv.AKT.integration.Persistence.ApplicationPersistence;
import gov.ca.dmv.AKT.integration.Persistence.ExamPersistence;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class SearchServiceImpl extends BaseServiceImpl implements SearchService {
	
	private ApplicantPersistence   applicantPersistence;
	private ApplicationPersistence applicationPersistence;
	private ExamPersistence        examPersistence;
	private IPersistence           persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}

	public ExamPersistence getExamPersistence() {
		return examPersistence;
	}

	public void setExamPersistence(ExamPersistence examPersistence) {
		this.examPersistence = examPersistence;
	}

	public ApplicationPersistence getApplicationPersistence() {
		return applicationPersistence;
	}

	public void setApplicationPersistence(
			ApplicationPersistence applicationPersistence) {
		this.applicationPersistence = applicationPersistence;
	}

	public ApplicantPersistence getApplicantPersistence() {
		return applicantPersistence;
	}

	public void setApplicantPersistence(ApplicantPersistence applicantPersistence) {
		this.applicantPersistence = applicantPersistence;
	}
	
	private String getLikeString(String str) {
		return (Constant.PER + str.trim() + Constant.PER);
	}
		
	private boolean searchParamValidation(Search search, IApplicantListWL appWL){
		if(search.getDl()==null && search.getLastName()==null){
			appWL.setErrorCode(ErrorCode.MISSING_REQUIRED);
			return true;
		}
		String dl = search.getDl().toLowerCase();
		String lastName = search.getLastName();
		if (dl.length()==0 && lastName.length()<1){
			appWL.setErrorCode(ErrorCode.MISSING_REQUIRED);
			return true;
		}
		if (dl.length()==0){
			//All ok since name is given but dl is not
			return false;
		}
		boolean dlVal = (dl.length()!=8);
		dlVal = dlVal || (dl.charAt(0)<'a' || dl.charAt(0)>'z');
		for(int i=1; !dlVal && i<8;i++){
			dlVal = dlVal || (dl.charAt(i)<'0' || dl.charAt(i)>'9');
		}
		if(dlVal){
			appWL.setErrorCode(ErrorCode.INCORRECT_DL);
			return true;
		}
		return false;
	}

	/*
	 * This method is called to search by dl # or last name based on the request type 
	 */
	@SuppressWarnings("unchecked")
	public IApplicantListWL search(Search search) {
		IApplicantListWL appWL = new ApplicantListWL();
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		List<Applicant> applicantList = new ArrayList<Applicant>();
		List<Vault> vaultList = null;
		List<IApplication> appList = null;
		if(search.getRequestType()!=SearchRequestTypeConstant.TEST_RESULTS && searchParamValidation(search,appWL)){
			return appWL;
		}
		String dl = search.getDl();
		String lastName = getLikeString(search.getLastName());
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("applicationLastName", lastName.trim());
		params.put("dlNumber", dl.trim());
		List<String> orders = new ArrayList<String>();
		orders.add("vaultTimestamp");
		try {
			vaultList = persistence.loadWithLikeConditionsIgnoreCaseAndOrderBy(Vault.class, params, orders);
			String appType = examSeedData.getAppTypeBasedOnOfficeId(search.getOfficeId());
			appList = applicationPersistence.loadTodaysApps(search.getOfficeId(), appType);
			if(search.getRequestType() == SearchRequestTypeConstant.TEST_QUEUE_REQUEST) {
				testQueueReqHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PRINT_TEST_QUEUE_REQUEST) {
				printTestQueueHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PAUSE_REQUEST) {
				pauseHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.FAIL_TO_AUTHENTICATE_REQUEST) {
				failToAuthReqHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.DISCONNECTED_REQUEST) {
				disconnectedHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TIMEOUT_REQUEST) {
				timeoutHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.QUIT_REQUEST) {
				quitHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.PRINT_MISSED_QUES_REQUEST) {
				missedQuestionsHelper(applicantList, vaultList, appList, appWL);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TEST_RESULTS || search.getRequestType() == SearchRequestTypeConstant.TEST_RESULTS_ALL_OFFICES) {
				testResultsHelper(applicantList, vaultList, appList, appWL);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.IN_PROGRESS_REQUEST) {
				inProgressTestsHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.TEST_STATUS){
				testStatusHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.EOD_REPORT){
				testStatusHelper(applicantList, vaultList, appList);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.VIEW_ACITVE_SESSIONS) {
				populateApplicantListHelper(applicantList, vaultList, appList);
				if(applicantList.size() == 0) appWL.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
			}
			appWL.setApplicantList(applicantList);
			if(vaultList.size()==0 || appList.size()==0){
				appWL.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			appWL.setErrorCode(e.getErrorCode());
		}
		return appWL;
	}
	
	@SuppressWarnings("unchecked")
	private void testStatusHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {					
					Applicant applicant = new Applicant();
					applicant.setApplicationId(app.getApplicationId());
					applicant.setDlNumber(vault.getDlNumber());
					applicant.setFirstName(vault.getApplicationFirstName());
					applicant.setLastName(vault.getApplicationLastName());
					applicantList.add(applicant);					
				}
			}
		}
		
	}	
	
	
	@SuppressWarnings("unchecked")
	private void inProgressTestsHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					ISession session = new Session();
					session.setApplicationId(app.getApplicationId());
					session.setSessionEndTime(Constant.defaultDate);
					List<Session> sessionList = persistence.findByExample(session);
					if(sessionList != null && sessionList.size() > Constant.ZERO) {
						session = sessionList.get(Constant.FIRST_ELEMENT);
						Object[] params = {session.getSessionId(), Constant.defaultDate, Constant.defaultDate, app.getApplicationType()};
						List<IExam> examList = examPersistence.loadBySessionId(params);
						if(examList != null && examList.size() > Constant.ZERO) {
							for(IExam exam: examList) {
								Applicant applicant = new Applicant();
								applicant.setDlNumber(vault.getDlNumber());
								Test test = new Test();
								test = (Test) persistence.findById(test, exam.getTestId());
								applicant.setExamType(test.getTestName());
								applicant.setFirstName(vault.getApplicationFirstName());
								applicant.setLastName(vault.getApplicationLastName());
								WorkstationMap wm = new WorkstationMap();
								wm = (WorkstationMap) persistence.findById(wm, session.getWorkstationIPAddress());
								applicant.setWorkstationId(wm.getWorkstationId());
								applicant.setSessionId(session.getSessionId());
								applicant.setExamId(exam.getExamId());
								applicantList.add(applicant);
							}
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void quitHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					IExam exam = new Exam();
					exam.setApplicationId(app.getApplicationId());
					exam.setCompletionReasonCode(Constant.QUIT);
					List<Exam> examList = persistence.findByExample(exam);
					for(IExam ex: examList) {
						Applicant applicant = new Applicant();
						applicant.setDlNumber(vault.getDlNumber());
						Test test = new Test();
						test = (Test) persistence.findById(test, ex.getTestId());
						applicant.setExamType(test.getTestName());
						applicant.setFirstName(vault.getApplicationFirstName());
						applicant.setLastName(vault.getApplicationLastName());
						applicant.setExamId(ex.getExamId());
						applicantList.add(applicant);
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void timeoutHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					IExam exam = new Exam();
					exam.setApplicationId(app.getApplicationId());
					exam.setCompletionReasonCode(Constant.TIME_OUT);
					List<IExam> examList = persistence.findByExample(exam);
					for(IExam ex: examList) {
						Applicant applicant = new Applicant();
						applicant.setDlNumber(vault.getDlNumber());
						Test test = new Test();
						test = (Test) persistence.findById(test, ex.getTestId());
						applicant.setExamType(test.getTestName());
						applicant.setFirstName(vault.getApplicationFirstName());
						applicant.setLastName(vault.getApplicationLastName());
						applicant.setExamId(ex.getExamId());
						applicantList.add(applicant);
					}
				}
			}
		}
	}
	
	private Integer getTimeUntilDisconnected(){
		Integer timeout1 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TIME_PER_QUESTION);
		timeout1 = timeout1!=null?timeout1:TimeLimitTypeConstant.DEFAULT_TIME_PER_QUESTION;
		
		Integer timeout2 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.WARNING_BEFORE_TIMEOUT);
		timeout2 = timeout2!=null?timeout2:TimeLimitTypeConstant.DEFAULT_WARNING_BEFORE_TIMEOUT;
		
		Integer timeout3 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.ADDTNL_TIME_PER_QUESTION);
		timeout3 = timeout3!=null?timeout3:TimeLimitTypeConstant.DEFAULT_ADDTNL_TIME_PER_QUESTION;
		
		return (timeout1 + timeout2 + timeout3)/TimeLimitTypeConstant.SECONDS;		
	}

	@SuppressWarnings("unchecked")
	private void disconnectedHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					IExam exam = new Exam();
					exam.setApplicationId(app.getApplicationId());
					exam.setExamEndTime(Constant.defaultDate);
					List<IExam> examList = persistence.findByExample(exam);
					for(IExam ex: examList) {
						if(ex.getSessionId() != Constant.ZERO && !Constant.isSameDay(ex.getExamStartTime(), Constant.defaultDate) && Constant.hasEndedLongEnough(ex.getLastModUserTime(),getTimeUntilDisconnected())) {
							Applicant applicant = new Applicant();
							applicant.setExamId(ex.getExamId());
							applicant.setDlNumber(vault.getDlNumber());
							Test test = new Test();
							test = (Test) persistence.findById(test, ex.getTestId());
							applicant.setExamType(test.getTestName());
							applicant.setFirstName(vault.getApplicationFirstName());
							applicant.setLastName(vault.getApplicationLastName());
							applicantList.add(applicant);
						}
					}
					break;
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void pauseHelper(List<Applicant> applicantList,	List<Vault> vaultList, List<IApplication> appList) throws AKTException {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					IExam exam = new Exam();
					exam.setApplicationId(app.getApplicationId());
					exam.setCompletionReasonCode(Constant.PAUSE);
					List<IExam> examList = (List<IExam>) persistence.findByExample(exam);
					if(examList != null && examList.size() > Constant.ZERO) {
						for(IExam ex: examList) {
							Test test = new Test();
							test = (Test) persistence.findById(test, ex.getTestId());
							Applicant applicant = new Applicant();
							applicant.setDlNumber(vault.getDlNumber());
							applicant.setExamId(ex.getExamId());
							applicant.setExamType(test.getTestName());
							applicant.setFirstName(vault.getApplicationFirstName());
							applicant.setLastName(vault.getApplicationLastName());
							applicantList.add(applicant);
						}
					}
				}
			}
		}
	}

	private void missedQuestionsHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList, IApplicantListWL appWL) throws AKTException {
		boolean completed = false;
		boolean incorrectDL = true;
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					incorrectDL = false;
					Object[] params = {app.getApplicationId(), Constant.SINGLE_SPACE};
					List<IExam> completedExams = examPersistence.loadCompletedExams(params);
					if(completedExams != null && completedExams.size() > Constant.ZERO) {
						completed = true;
						for(IExam exam: completedExams) {
							if (exam.getSessionId() > 0) {
								Applicant appt = new Applicant();
								appt.setDlNumber(vault.getDlNumber());
								appt.setLastName(vault.getApplicationLastName());
								appt.setFirstName(vault.getApplicationFirstName());
								ISession sess = new Session();
								sess = (ISession) persistence.findById(sess, exam.getSessionId());								
								WorkstationMap wm = new WorkstationMap();
								wm = (WorkstationMap) persistence.findById(wm, sess.getWorkstationIPAddress());
								appt.setWorkstationId(wm.getWorkstationId());								
								//appt.setExamStartDate(formatDate(exam.getExamStartTime()));
								appt.setExamId(exam.getExamId());
								appt.setExamType(getTestName(exam.getTestId()));
								appt.setExamEndDateAndTime(exam.getExamEndTime());
								//appt.setResult(getStatusDesc(exam.getCompletionReasonCode(), exam.getPassFailIndicator()));
								//appt.setIncorrect(exam.getIncorrectAnswerCount());
								applicantList.add(appt);
							}
						}
					}
				}
			}
		}
		if(incorrectDL) {
			appWL.setErrorCode(ErrorCode.INCORRECT_DL);
		}
		else if(!completed) {
			appWL.setErrorCode(ErrorCode.INCOMPLETE_TEST);
		}
	}

	private void testResultsHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList, IApplicantListWL appWL) throws AKTException {
		boolean completed = false;
		boolean incorrectDL = true;
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					incorrectDL = false;
					Object[] params = {app.getApplicationId(), Constant.SINGLE_SPACE};
					List<IExam> completedExams = examPersistence.loadCompletedExams(params);
					if(completedExams != null && completedExams.size() > Constant.ZERO) {
						completed = true;
						for(IExam exam: completedExams) {
							Applicant appt = new Applicant();
							appt.setDlNumber(vault.getDlNumber());
							appt.setLastName(vault.getApplicationLastName());
							appt.setFirstName(vault.getApplicationFirstName());
							ISession sess = new Session();
							sess = (ISession) persistence.findById(sess, exam.getSessionId());
							if (sess != null) {
								WorkstationMap wm = new WorkstationMap();
								wm = (WorkstationMap) persistence.findById(wm, sess.getWorkstationIPAddress());
								appt.setWorkstationId(wm.getWorkstationId());
							}
							appt.setExamId(exam.getExamId());
							appt.setExamType(getTestName(exam.getTestId()));
							appt.setResult(exam.getPassFailIndicator());
							appt.setExamEndDateAndTime(exam.getExamEndTime());
							applicantList.add(appt);
						}
					}
				}
			}
		}
		if(incorrectDL){
			appWL.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
		}
		else if(!completed) {
			appWL.setErrorCode(ErrorCode.INCOMPLETE_TEST);
		}
	}
	
	private void printTestQueueHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					List<IExam> examList = examPersistence.loadExamsNotStartedByAppId(app.getApplicationId());
					if(examList != null && examList.size() > Constant.ZERO) {
						fillApplicantInfoHelper(applicantList, app, vault);
					}
				}
			}
		}
	}

	private void fillApplicantInfoHelper(List<Applicant> applicantList,	IApplication app, IVault vault) {
		Applicant apt = new Applicant();
		apt.setApplicationId(app.getApplicationId());
		apt.setDlNumber(vault.getDlNumber());
		apt.setFirstName(vault.getApplicationFirstName());
		apt.setLastName(vault.getApplicationLastName());
		applicantList.add(apt);
	}

	@SuppressWarnings("unchecked")
	private void testQueueReqHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) {
		String officeId="";
		if(appList!=null && appList.size()>0){
			officeId = appList.get(Constant.FIRST_ELEMENT).getOfficeId().trim();
		}		
		try {
			ISession session = new Session();
			session.setOfficeId(officeId);
			session.setSessionEndTime(Constant.defaultDate);
			List<gov.ca.dmv.AKT.integration.BeansImpl.Session> sessionList = persistence.findByExample(session);
			HashSet<Integer> currentSessions = new HashSet<Integer>();
			if(sessionList != null && sessionList.size() > Constant.ZERO) {
				for(gov.ca.dmv.AKT.integration.Beans.ISession sess: sessionList) {
					if(Constant.isToday(sess.getSessionStartTime())) {
						currentSessions.add(sess.getApplicationId());
					}
				}
				for(IApplication app: appList) {
					for(IVault vault: vaultList) {
						if(vault.getVaultId().equals(app.getVaultId())) {
							if(!currentSessions.contains(app.getApplicationId())){
								fillApplicantInfoHelper(applicantList, app, vault);
							}
						}
					}
				}
				
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}			
	}
	
	private void failToAuthReqHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					fillApplicantInfoHelper(applicantList, app, vault);					
				}
			}
		}
	}
	
	private void populateApplicantListHelper(List<Applicant> applicantList, List<Vault> vaultList, List<IApplication> appList) {
		for(IApplication app: appList) {
			for(IVault vault: vaultList) {
				if(vault.getVaultId().equals(app.getVaultId())) {
					fillApplicantInfoHelper(applicantList, app, vault);					
				}
			}
		}
	}
	
//	private String getStatusDesc(String status, String passFailInd) {
//		String statusDesc = null;
//		if(status.trim().equalsIgnoreCase(Constant.QUIT)) {
//			statusDesc = "QUIT";
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.BATCH_FAIL)) {
//			statusDesc = "EOD FAIL";
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.TIME_OUT)) {
//			statusDesc = "TIME OUT";
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.PAUSE)) {
//			statusDesc = "SUSPEND";
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.DISCONNECTED)) {
//			statusDesc = "DISCONNECT";
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.NORMAL)) {
//			if(passFailInd.trim().equalsIgnoreCase(Constant.PASS)) {
//				statusDesc = "PASS";
//			}
//			else if(passFailInd.trim().equalsIgnoreCase(Constant.FAIL)) {
//				statusDesc = "FAIL";
//			}
//		}
//		else if(status.trim().equalsIgnoreCase(Constant.FORCE_FAIL)) {
//			statusDesc = "FORCE FAIL";
//		}
//		return statusDesc;
//	}
	
//	private String formatDate(Date date) {
//		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
//		String formattedDate = formatter.format(date);
//		return formattedDate;
//	}
	
	private String getTestName(String testId) throws AKTException {
		Test test = new Test();
		test = (Test) persistence.findById(test, testId);
		return test.getTestName();
	}
}
