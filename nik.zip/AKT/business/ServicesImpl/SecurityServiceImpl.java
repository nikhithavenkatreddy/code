package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.SecurityService;
import gov.ca.dmv.AKT.business.WorkloadImpl.BooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.integration.webservice2.GetProfileRequestType;
import gov.ca.dmv.AKT.integration.webservice2.GetProfileResponseType;
import gov.ca.dmv.AKT.integration.webservice2.IDMService;
import gov.ca.dmv.AKT.integration.webservice2.IDMService_Service;
import gov.ca.dmv.AKT.presentation.Controller.FOUserController;

import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

public class SecurityServiceImpl extends BaseServiceImpl implements SecurityService {
	
	private static final Logger log = Logger.getLogger(SecurityServiceImpl.class);
	/*
	 * This method is called to authenticate and authorize the user.
	 */
	public IBooleanWL authenticate(String userId, String password, String userIdLoggedIn) {
		IBooleanWL boolWL = new BooleanWL();
		boolean authenticated = true;
		if(userId.equalsIgnoreCase(userIdLoggedIn)) {
			authenticated = false;
			log.warn("Warning==> Secondary Verifier is the same logon user:\'" + userId +"\'");
		}
		else {
			GetProfileRequestType profileIn = new GetProfileRequestType();
			profileIn.setPassword(password);
			profileIn.setUserId(userId);
			IDMService endPoint = new IDMService_Service().getIDMServiceSOAP();
			String endPointURL = this.getExamSeedData().getSecurityServerURL();
			((BindingProvider) endPoint).getRequestContext().put(
					BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPointURL);
					//"http://ISD-CONS-055:8088/mockIDMServiceSOAP");
			try {
				Thread.sleep(4000);
				GetProfileResponseType profileOut = endPoint.getProfile(profileIn);				
				System.out.println("office: " + profileOut.getOfficeId() + "_____ group: " + profileOut.getGroups());
				if (profileOut != null && profileOut.getOfficeId() != null && !profileOut.getOfficeId().equals("000")) {
					authenticated = true;
				} 
				else {
					authenticated = false;
					log.warn("Warning==> Secondary Verifier userId is not valid:\'" + userId + "\' office:\'" + profileOut.getOfficeId() +"\'");
				}
			}
			catch(Exception e) {
				System.out.println("ERROR: (see SystemErr.log for detail)");
				log.error("Error==> Secondary Verification for userid:\'" + userId + "\' error:" + e.getMessage());
				e.printStackTrace();
				authenticated = false;
			}
		}
		boolWL.setFlag(authenticated);
		return boolWL;
	}
}
