package gov.ca.dmv.AKT.business.ServicesImpl;

import org.apache.log4j.Logger;

import gov.ca.dmv.AKT.business.Services.BaseService;
import gov.ca.dmv.AKT.business.Services.ExamSeedData;
import gov.ca.dmv.AKT.business.Services.ExamSessionData;
import gov.ca.dmv.AKT.constants.Constant;

public class BaseServiceImpl implements BaseService {
	protected ExamSessionData examSessionData;
	protected ExamSeedData    examSeedData;
	protected static final Logger logger = Logger.getLogger(BaseServiceImpl.class);
	
	public ExamSessionData getExamSessionData() {
		return examSessionData;
	}

	public void setExamSessionData(ExamSessionData examSessionData) {
		this.examSessionData = examSessionData;
	}

	public ExamSeedData getExamSeedData() {
		return examSeedData;
	}

	public void setExamSeedData(ExamSeedData examSeedData) {
		this.examSeedData = examSeedData;
	}

	public String getUserId() {
		String userId = null;
		try {
			if (this.examSessionData != null && this.examSessionData.getDmvStaff() != null) {
				userId = this.examSessionData.getDmvStaff().getUserId();
			}
			else {
				userId = Constant.LASTMODUSR_NME;
			}
		}
		catch (Exception e) {
			userId = Constant.LASTMODUSR_NME;
		}
		return userId;
	}
}
