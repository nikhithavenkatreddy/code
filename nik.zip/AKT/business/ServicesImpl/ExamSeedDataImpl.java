package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.ExamSeedData;
import gov.ca.dmv.AKT.business.WorkloadImpl.WorkstationMapListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;
import gov.ca.dmv.AKT.constants.AudioVideoConstant;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.BeansImpl.Health;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.Office;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.Question;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLangQuickPF;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;
import gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;
import gov.ca.dmv.AKT.integration.BeansImpl.ThresholdDictionary;
import gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;
import gov.ca.dmv.AKT.integration.Persistence.MiscPersistence;
import gov.ca.dmv.AKT.integration.Persistence.QuestionPersistence;
import gov.ca.dmv.AKT.integration.Persistence.TestPersistence;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class ExamSeedDataImpl implements Serializable, ExamSeedData {

	private List<TestPlan>            testPlanList;
	private List<Question>            questionList;
	private List<QuestionLang>        questionLangList;
	private List<Answer>              answerList;
	private List<HandbookRef>         handbookRefList;
	private List<Test>                testList;
	private List<TestLang>            testLangList;
	private List<QuickPassFailEvent>  qpfList;
	private List<QuestionList>        questionListCollection;
	private List<Lang>                langList;
	private List<WorkstationMap>      workstationMapList;
	private List<ThresholdDictionary> thresholdDictionaryList;
	//Performance optimization
	private Map<String, List<QuestionLang>> questionLangMapByTestIdCatIdLangId;
	//
	private TestPersistence           testPersistence;
	private QuestionPersistence       questionPersistence;
	private MiscPersistence           miscPersistence;
	private IPersistence              persistence;
	private List<TimeLimit>			  timeLimitList;
	private List<Office>			  officeList;
	private String					  fileServerURL;
	private String					  audioFileL1ServerURL;
	private String 					  securityServerURL;
	private static final Logger       logger = Logger.getLogger(ExamSeedDataImpl.class);
	
	public Office getOfficeByTerminalIP(String terminalIP) {
		Office returnOffice = null;
		WorkstationMap wm = getWorkstationMapByIPAddress(terminalIP);
		for(Office office:officeList){
			if(wm.getOfficeId().trim().equals(office.getOfficeId())){
				returnOffice = office;
			}				
		}
		return returnOffice;
	}
	
	public synchronized void updateWorkstationMapByIpAddr(String ipAddr, String officeId, String locatingOfficeId) {
		for (WorkstationMap workstationMap : workstationMapList) {
			if (workstationMap.getWorkstationIPAddress().trim().equals(ipAddr.trim())) {
				workstationMap.setOfficeId(officeId);
				workstationMap.setLocatingOfficeId(locatingOfficeId);			
			}
		}
	}
	public List<Office> getOfficeList() {
		return officeList;
	}
	public void setOfficeList(List<Office> officeList) {
		this.officeList = officeList;
	}
	public List<ThresholdDictionary> getThresholdDictionaryList() {
		return thresholdDictionaryList;
	}
	public void setThresholdDictionaryList(List<ThresholdDictionary> thresholdDictionaryList) {
		this.thresholdDictionaryList = thresholdDictionaryList;
	}
	public List<WorkstationMap> getWorkstationMapList() {
		return workstationMapList;
	}
	public void setWorkstationMapList(List<WorkstationMap> workstationMapList) {
		this.workstationMapList = workstationMapList;
	}
	public MiscPersistence getMiscPersistence() {
		return miscPersistence;
	}
	public void setMiscPersistence(MiscPersistence miscPersistence) {
		this.miscPersistence = miscPersistence;
	}
	public QuestionPersistence getQuestionPersistence() {
		return questionPersistence;
	}
	public void setQuestionPersistence(QuestionPersistence questionPersistence) {
		this.questionPersistence = questionPersistence;
	}
	public IPersistence getPersistence() {
		return persistence;
	}
	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}
	public List<QuickPassFailEvent> getQpfList() {
		return qpfList;
	}
	public void setQpfList(List<QuickPassFailEvent> qpfList) {
		this.qpfList = qpfList;
	}
	public TestPersistence getTestPersistence() {
		return testPersistence;
	}
	public void setTestPersistence(TestPersistence testPersistence) {
		this.testPersistence = testPersistence;
	}
	public List<Lang> getLangList() {
		return langList;
	}
	public void setLangList(List<Lang> langList) {
		this.langList = langList;
	}
	public List<QuestionList> getQuestionListCollection() {
		return questionListCollection;
	}
	public void setQuestionListCollection(List<QuestionList> questionListCollection) {
		this.questionListCollection = questionListCollection;
	}
	public List<Test> getTestList() {
		return testList;
	}
	public void setTestList(List<Test> testList) {
		this.testList = testList;
	}
	public List<TestLang> getTestLangList() {
		return testLangList;
	}
	public void setTestLangList(List<TestLang> testLangList) {
		this.testLangList = testLangList;
	}
	public List<HandbookRef> getHandbookRefList() {
		return handbookRefList;
	}
	public void setHandbookRefList(List<HandbookRef> handbookRefList) {
		this.handbookRefList = handbookRefList;
	}
	public List<TestPlan> getTestPlanList() {
		return testPlanList;
	}
	public void setTestPlanList(List<TestPlan> testPlanList) {
		this.testPlanList = testPlanList;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	public List<QuestionLang> getQuestionLangList() {
		return questionLangList;
	}
	public void setQuestionLangList(List<QuestionLang> questionLangList) {
		this.questionLangList = questionLangList;
	}
	public List<Answer> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
	
	public List<TimeLimit> getTimeLimitList() {
		return timeLimitList;
	}
	public void setTimeLimitList(List<TimeLimit> timeLimitList) {
		this.timeLimitList = timeLimitList;
	}
	
	//Performance optimization
	public Map<String, List<QuestionLang>> getQuestionLangMapByTestIdCatIdLangId() {
		return questionLangMapByTestIdCatIdLangId;
	}
	public void setQuestionLangMapByTestIdCatIdLangId(Map<String, List<QuestionLang>> questionLangMapByTestIdCatIdLangId) {
		this.questionLangMapByTestIdCatIdLangId = questionLangMapByTestIdCatIdLangId;
	}
	//
	
	private void log(Exception e) {
		logger.error(e.getMessage());
		logger.error(e.getCause());
	}
	
	/*
	 * This method is called only to populate exam seed data one time at application start up.
	 */
	@SuppressWarnings("unchecked")
	public void init() {
		System.out.println("Scheduled Job!!!!");
		List<TestPlan> tpList = null;
		List<Question> qList = null;
		List<QuestionLang> qlList = null;
		List<Answer> ansList = null;
		List<HandbookRef> hbList = null;
		List<Test> tList = null;
		List<TestLang> tLangList = null;
		List<QuickPassFailEvent> qpfList = new ArrayList<QuickPassFailEvent>();
		List<QuestionList> qlColl = null;
		List<Lang> lngList = null;
		List<WorkstationMap> wmList = null;
		List<ThresholdDictionary> tdList = null;
		List<TimeLimit> timeLimList = null;
		List<Office> offList = null;
		try {
			tpList = testPersistence.loadAllTestPlans();
			setTestPlanList(tpList);
			qList = questionPersistence.loadAllActiveQuestions(Constant.ACTIVE);
			setQuestionList(qList);
			Object[] params = {Constant.ACTIVE, Constant.PENDING, Constant.PENDING_INACTIVE, Constant.DENIED};
			qlList = questionPersistence.loadAllActiveQuestionLang(params);
			setQuestionLangList(qlList);
			ansList = questionPersistence.loadAllActiveAnswers(Constant.ACTIVE);
			setAnswerList(ansList);
			hbList = questionPersistence.load();
			setHandbookRefList(hbList);
			Test t = new Test();
			tList = persistence.findByExample(t);
			setTestList(tList);
			TimeLimit timeLim = new TimeLimit();
			timeLimList = persistence.findByExample(timeLim);
			setTimeLimitList(timeLimList);
			Office off =  new Office();
			offList = persistence.findByExample(off);
			setOfficeList(offList);			
			tLangList = testPersistence.loadAllTestLang(Constant.ACTIVE);
			setTestLangList(tLangList);
			for(Test test: testList) {
				if(test.getQuickPassFailInd().trim().equalsIgnoreCase(Constant.YES)) {
					List<QuickPassFailEvent> qpfList2 = testPersistence.load(test.getTestId());
					if(qpfList2 != null && qpfList2.size() > Constant.ZERO) {
						qpfList.add(qpfList2.get(Constant.FIRST_ELEMENT));
					}
				}
			}
			setQpfList(qpfList);
			qlColl = questionPersistence.loadAllActiveQuesList(Constant.ACTIVE);
			setQuestionListCollection(qlColl);
			lngList = miscPersistence.load();
			setLangList(lngList);
			wmList = miscPersistence.loadAllWorkstationMap();
			setWorkstationMapList(wmList);
			tdList = miscPersistence.loadAllThreshold();
			setThresholdDictionaryList(tdList);
			//Performance Optimization
			initializeQuesLangMap();
			//
			Context ctx; 
			ctx = new InitialContext();
			//Save for future when/if we centralize the audio files to OTech and all field offices can handle the bandwidth.
			//fileServerURL = (String) ctx.lookup( "MEDIA_FILE_SERVER" );
			securityServerURL = (String) ctx.lookup( "SECURITY_SERVER" );
			
			
			//L1 server URL for audio  -- no value for current office.
			//audioFileL1ServerURL = off.getL1ServerIpAddr();
			
		}
		
		catch(AKTException e) {
			log(e);
		} 
		catch (NamingException e) { 
			e.printStackTrace();
		}
	}
	
	//Performance Optimization
	private void initializeQuesLangMap() {
		Map<String, List<QuestionLang>> qlMap = new HashMap<String, List<QuestionLang>>();
		for(TestPlan tp: testPlanList) {
			String testId = tp.getTpPrimaryKey().getTestId().trim();
			String catId = tp.getTpPrimaryKey().getCategoryId().trim(); 
			List<String> quesIds = getQuestionListIdsIfQuesExists(testId, catId);
			for(Lang lang: langList) {
				String langId = lang.getLangId();
				String key = testId + catId + langId;
				List<QuestionLang> quesLangList = getQuesLangByQuesIdLangId(quesIds, langId);
				qlMap.put(key, quesLangList);
			}
		}
		setQuestionLangMapByTestIdCatIdLangId(qlMap);
	}
	//
	
	private List<QuestionLang> getQuesLangByQuesIdLangId(List<String> quesIds, String langId) {
		List<QuestionLang> quesLangList = new ArrayList<QuestionLang> ();
		for(QuestionLang ql: questionLangList) {
			for(String quesId: quesIds) {
				if(ql.getQuestionId().trim().equalsIgnoreCase(quesId.trim()) && ql.getLangId().trim().equalsIgnoreCase(langId.trim())) {
					quesLangList.add(ql);
				}
			}
		}
		return quesLangList;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * This method is called for checking if the cache was loaded with seed data correctly and if there's a valid db connection.
	 * This information will be used for sending a nagios alert in case loading cache or connecting to the db failed.
	 */
	public Health getHealthReport() {
		Health health = new Health();
		if(testPlanList != null && questionList != null && questionLangList != null && answerList != null && handbookRefList != null &&
				testList != null && testLangList != null && qpfList != null && questionListCollection != null && langList != null &&
				workstationMapList != null && thresholdDictionaryList != null && questionLangMapByTestIdCatIdLangId != null &&
				testPlanList.size() > Constant.ZERO && questionList.size() > Constant.ZERO && questionLangList.size() > Constant.ZERO
				&& answerList.size() > Constant.ZERO && handbookRefList.size() > Constant.ZERO && testList.size() > Constant.ZERO &&
				testLangList.size() > Constant.ZERO && qpfList.size() > Constant.ZERO && questionListCollection.size() > Constant.ZERO
				&& langList.size() > Constant.ZERO && workstationMapList.size() > Constant.ZERO && thresholdDictionaryList.size() > Constant.ZERO
				&& questionLangMapByTestIdCatIdLangId.size() > Constant.ZERO) {
			health.setCacheStatus(Constant.GOOD_CACHE_STATUS);
		}
		else {
			init();
			if(testPlanList != null && questionList != null && questionLangList != null && answerList != null && handbookRefList != null &&
					testList != null && testLangList != null && qpfList != null && questionListCollection != null && langList != null &&
					workstationMapList != null && thresholdDictionaryList != null && questionLangMapByTestIdCatIdLangId != null &&
					testPlanList.size() > Constant.ZERO && questionList.size() > Constant.ZERO && questionLangList.size() > Constant.ZERO
					&& answerList.size() > Constant.ZERO && handbookRefList.size() > Constant.ZERO && testList.size() > Constant.ZERO &&
					testLangList.size() > Constant.ZERO && qpfList.size() > Constant.ZERO && questionListCollection.size() > Constant.ZERO
					&& langList.size() > Constant.ZERO && workstationMapList.size() > Constant.ZERO && thresholdDictionaryList.size() > Constant.ZERO
					&& questionLangMapByTestIdCatIdLangId.size() > Constant.ZERO) {
				health.setCacheStatus(Constant.CURED_CACHE_STATUS);
			}
			else {
				health.setCacheStatus(Constant.BAD_CACHE_STATUS);
			}
		}
		return health;
	}
	
	/*
	 * This method is called to get question lang record by question gen id.
	 */
	public QuestionLang getQuestionLangByQuesGenId(Integer quesGenId) {
		for(QuestionLang ql: questionLangList) {
			if(ql.getQuestionGenId().equals(quesGenId)) {
				return ql;
			}
		}
		return null;
	}
	
	public String getThresholdValue(String thresholdName) {
		for(ThresholdDictionary td: thresholdDictionaryList) {
			if(td.getThresholdName().trim().equalsIgnoreCase(thresholdName.trim())) {
				return td.getThresholdValue();
			}
		}
		return null;
	}
	
	public Integer getTimeLimitByName(String timeLimitName) {
		for(TimeLimit tl: timeLimitList) {
			if(tl.getTimeLimitName().trim().equals(timeLimitName)) {
				return new Integer(tl.getTimeLimitValue());
			}
		}
		return null;
	}
	
	public WorkstationMap getWorkstationMapByIPAddress(String ipAddress) {
		for(WorkstationMap wm: workstationMapList) {
			if(wm.getWorkstationIPAddress().trim().equalsIgnoreCase(ipAddress.trim())) {
				return wm;
			}
		}
		return null;
	}
	
	public String getOfficeTypeByIPAddress(String ipAddress){
		String officeType = null;
		WorkstationMap wm = getWorkstationMapByIPAddress(ipAddress);
		for(Office office:officeList){
			if(wm.getOfficeId().trim().equals(office.getOfficeId())){
				officeType = office.getOfficeTypeCode().trim();
			}				
		}
		return officeType;
	}
	
	public String getOfficeTypeByOfficeId(String officeId){
		String officeType = null;
		for(Office office:officeList){
			if(officeId.equals(office.getOfficeId())){
				officeType = office.getOfficeTypeCode().trim();
			}				
		}
		return officeType;
	}
	
	public List<String> getAllOfficeIDs(){
		List<String> officeIDList = new ArrayList<String>();
		for(Office office:officeList){
			officeIDList.add(office.getOfficeId());
		}
		return officeIDList;
	}
	
	public List<String> getAllOfficeIDsInSameBuilding(String officeId){
		Integer buildingId = null;
		List<String> officeIDList = new ArrayList<String>();
		for(Office office:officeList){
			if(office.getOfficeId().equals(officeId)){
				buildingId = office.getBuildingId();
				break;
			}
		}
		if(buildingId!=null){
			for(Office office:officeList){
				if(office.getBuildingId().equals(buildingId) && !office.getOfficeId().equals(officeId)){
					officeIDList.add(office.getOfficeId());
				}				
			}
		}
		return officeIDList;
	}
	
	public String getAppTypeBasedOnOfficeId(String officeId){
		String officeType = null;
		for(Office office:officeList){
			if(office.getOfficeId().equals(officeId)){
				officeType = office.getOfficeTypeCode().trim();
			}
		}
		return officeType;
	}
	
	public IWorkstationMapListWL getWorkstationMapListByOfficeId(String officeId) {
		List<WorkstationMap> wmList = new ArrayList<WorkstationMap>();
		IWorkstationMapListWL wmWL = new WorkstationMapListWL();
		wmWL.setErrorCode(ErrorCode.NO_ERROR);
		if(workstationMapList==null || workstationMapList.size()==0){
			wmWL.setErrorCode(ErrorCode.MISSING_WORKSTATION);
		}
		else{
			for(WorkstationMap wm1: workstationMapList) {
				if(wm1.getOfficeId().trim().equalsIgnoreCase(officeId.trim())) {
					
					WorkstationMap wm = new WorkstationMap();
					//TODO use a clone method
					wm.setLastModUsername(wm1.getLastModUsername());
					wm.setLastModUserTime(wm1.getLastModUserTime());					
					wm.setOfficeId(wm1.getOfficeId());
					wm.setWorkstationId(wm1.getWorkstationId());
					wm.setWorkstationIPAddress(wm1.getWorkstationIPAddress());
					wm.setLocatingOfficeId(wm1.getLocatingOfficeId());					
					wmList.add(wm);
				}
			}
			wmWL.setWorkstationMapList(wmList);
		}
		return wmWL;
	}
	
	/*
	 * This method is called to get test by test id.
	 */
	public Test getTestByTestId(String testId) {
		Test tst = null;
		for(Test test: testList) {
			if(test.getTestId().trim().equalsIgnoreCase(testId.trim())) {
				tst = test;
				break;
			}
		}
		return tst;
	}
	
	private QuickPassFailEvent getQuickPassFailEventByTestId(String testId) {
		QuickPassFailEvent qpf1 = new QuickPassFailEvent();
		for(Test test: testList) {
			if(test.getTestId().trim().equalsIgnoreCase(testId.trim())) {
				qpf1.setQuickPassFlag(test.getQuickPassInd());
				qpf1.setQuickFailFlag(test.getQuickFailInd());
				break;
			}
		}
		return qpf1;
	}
	
	private List<TestPlan> getTestPlansByTestId(String testId) {
		List<TestPlan> testPlans = new ArrayList<TestPlan>();
		for(TestPlan tp: testPlanList) {
			if(tp.getTpPrimaryKey().getTestId().trim().equalsIgnoreCase(testId.trim())) {
				testPlans.add(tp);
			}
		}
		return testPlans;
	}
	
	private List<String> getQuestionListIdsIfQuesExists(String testId, String categoryId) {
		List<String> quesIds = new ArrayList<String>();
		for(QuestionList ql: questionListCollection) {
			if(ql.getQlPrimaryKey().getCategoryId().trim().equalsIgnoreCase(categoryId.trim()) && ql.getQlPrimaryKey().getTestId().trim().equalsIgnoreCase(testId.trim())) {
				for(Question ques: questionList) {
					if(ques.getQuestionId().trim().equalsIgnoreCase(ql.getQlPrimaryKey().getQuestionId().trim()) && ques.getQuestionStatus().trim().equalsIgnoreCase(Constant.ACTIVE)) {
						quesIds.add(ql.getQlPrimaryKey().getQuestionId());
					}
				}
			}
		}
		return quesIds;
	}
	
	private List<QuestionLang> getQuesLangByQuesIdLangId(List<String> quesIds, String langId, String audioVideoTestCode) {
		List<QuestionLang> quesLangList = new ArrayList<QuestionLang> ();
		for(QuestionLang ql: questionLangList) {
			for(String quesId: quesIds) {
				if(ql.getQuestionId().trim().equalsIgnoreCase(quesId.trim()) && ql.getLangId().trim().equalsIgnoreCase(langId.trim())) {					
					boolean audioPresent = false;
					boolean videoPresent = false;
					boolean isValid = false;
					if(ql.getQuestionAudio() != null && ql.getQuestionAudio().trim().length() > 0){
						audioPresent = true;
					}
					if(ql.getQuestionVideo() != null && ql.getQuestionVideo().trim().length() > 0){
						videoPresent = true;
					}
					
					if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.AUDIO_ONLY)){
						isValid = audioPresent;
					}
					else if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.VIDEO_ONLY)){
						isValid =  videoPresent;
					}
					else if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.AUDIO_VIDEO)){
						isValid =  videoPresent && audioPresent;
					}
					else{
						isValid = true;
					}
					
					if(isValid){
						quesLangList.add(ql);
					}					
				}
			}
		}
		return quesLangList;
	}
	
	private List<QuestionLang> getActiveQuestionList(String categoryId, String langId, String testId, String audioVideoTestCode) {
		//List<String> quesIds = getQuestionListIdsIfQuesExists(testId, categoryId);		
		//List<QuestionLang> quesLangList = getQuesLangByQuesIdLangId(quesIds, langId, audioVideoTestCode);
		//return quesLangList;
		
		// For performance tuning, getting from the cache.
		List<QuestionLang> quesLangList = null;
		String key = testId + categoryId + langId;
		if (audioVideoTestCode.equals(Constant.SINGLE_SPACE)) {
			quesLangList = questionLangMapByTestIdCatIdLangId.get(key);
		}
		else {
			quesLangList = getOnlyQuestionWithAV(key, audioVideoTestCode);
		}
		return quesLangList;
	}
	
	private List<QuestionLang> getOnlyQuestionWithAV(String key, String audioVideoTestCode) {
		List<QuestionLang> quesLangWithAVList = new ArrayList<QuestionLang>();
		List<QuestionLang> quesLangList = null;
		
		quesLangList = questionLangMapByTestIdCatIdLangId.get(key);
		for(QuestionLang ql: quesLangList) {
			boolean audioPresent = false;
			boolean videoPresent = false;
			boolean isValid = false;
			if(ql.getQuestionAudio() != null && ql.getQuestionAudio().trim().length() > 0){
				audioPresent = true;
			}
			if(ql.getQuestionVideo() != null && ql.getQuestionVideo().trim().length() > 0){
				videoPresent = true;
			}
			
			if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.AUDIO_ONLY)){
				isValid = audioPresent;
			}
			else if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.VIDEO_ONLY)){
				isValid =  videoPresent;
			}
			else if (audioVideoTestCode.trim().equalsIgnoreCase(AudioVideoConstant.AUDIO_VIDEO)){
				isValid =  videoPresent && audioPresent;
			}
			else{
				isValid = true;
			}
			
			if(isValid){
				quesLangWithAVList.add(ql);
			}
		}
		return quesLangWithAVList;
	}

	private void shuffle(List<QuestionLang> qlList) {
		Collections.shuffle(qlList);
	}
	
	/*
	 * This method is called to get the corresponding answers based on the question gen id.
	 */
	public List<Answer> getAnswersByQuesGenId(Integer quesGenId) {
		List<Answer> ansList = new ArrayList<Answer>();
		for(Answer ans: answerList) {
			if(ans.getQuestionGenId().equals(quesGenId)) {
				ansList.add(ans);
			}
		}
		return ansList;
	}
	
	public Lang getLangByLangId(String langId) {
		for(Lang lang: langList) {
			if(lang.getLangId().trim().equalsIgnoreCase(langId.trim())) {
				return lang;
			}
		}
		return null;
	}
	
	/*
	 * This method is called to get test lang record by test id and lang id.
	 */
	public TestLang getTestLangByTestIdLangId(TestLang tl) {
		TestLang testLang = null;
		for(TestLang tl2: testLangList) {
			if(tl2.getLangId().trim().equalsIgnoreCase(tl.getLangId().trim()) && tl2.getTlPrimaryKey().getTestId().trim().equalsIgnoreCase(tl.getTlPrimaryKey().getTestId().trim())) {
				testLang = tl2;
				break;
			}
		}
		return testLang;
	}
	
	/*
	 * This method is called to get a list of test lang records by test id.
	 */
	public List<TestLang> getTestLangListByTestId(String testId) {
		List<TestLang> tlList = new ArrayList<TestLang>();
		for(TestLang tl: testLangList) {
			if(tl.getTlPrimaryKey().getTestId().trim().equalsIgnoreCase(testId.trim())) {
				tlList.add(tl);
			}
		}
		return tlList;
	}
	
	/*
	 * This method is called to get answer by answer gen id.
	 */
	private Answer getAnswerByAnswerGenId(Integer answerGenId) {
		for(Answer ans: answerList) {
			if(ans.getAnswerGenId().equals(answerGenId)) {
				return ans;
			}
		}
		return null;
	}
	
	/*
	 * This method is called to generate the test based on the test id and language
	 */
	public QuestionLangQuickPF generateTest(TestLang testLang, String audioVideoTestCode) {
		QuestionLangQuickPF quesLangQPF = new QuestionLangQuickPF();
		QuickPassFailEvent qpfEvent = getQuickPassFailEventByTestId(testLang.getTlPrimaryKey().getTestId().trim());
		quesLangQPF.setQuickPassFailEvent(qpfEvent);
		List<TestPlan> testPlanList = getTestPlansByTestId(testLang.getTlPrimaryKey().getTestId().trim());
		List<QuestionLang> qlListWithOrder = new ArrayList<QuestionLang>();
		List<QuestionLang> qlListWithoutOrder = new ArrayList<QuestionLang>();
		for(TestPlan testPlan: testPlanList) {			
			List<QuestionLang> qlList = getActiveQuestionList(testPlan.getTpPrimaryKey().getCategoryId().trim(), testLang.getLangId().trim(), testPlan.getTpPrimaryKey().getTestId().trim(),audioVideoTestCode);
			shuffle(qlList);
			int upper = testPlan.getCategoryQuestionCount().intValue();
			List<QuestionLang> qlListCounted;
			if (qlList.size() >= upper) {
				qlListCounted = qlList.subList(0, upper);
			}
			else {
				qlListCounted = qlList;
				logger.error("Error: not enough questions in the pool for testId/categoryId(" + upper + "): " + 
				              testPlan.getTpPrimaryKey().getCategoryId() + "\\" + testPlan.getTpPrimaryKey().getTestId());
			}
			for(QuestionLang quesLang: qlListCounted) {
				if(testPlan.getCategoryOrder() != Constant.ZERO)
					qlListWithOrder.add(quesLang);
				else
					qlListWithoutOrder.add(quesLang);
			}
		}
		shuffle(qlListWithOrder);
		shuffle(qlListWithoutOrder);
		qlListWithOrder.addAll(qlListWithoutOrder);
		quesLangQPF.setQuestionLangList(qlListWithOrder);
		return quesLangQPF;
	}
	
	/*
	 * This method is called to get handbookref record by handbookref and lang id.
	 */
	public HandbookRef getHandbookRefByHandbookRefAndLangId(String handbookRef, String langId) {
		for(HandbookRef hb: handbookRefList) {
			if(hb.getHrPrimaryKey().getHandbookRef().trim().equals(handbookRef.trim()) && hb.getHrPrimaryKey().getLangId().trim().equals(langId.trim())) {
				return hb;
			}
		}
		return null;
	}
	
	/*
	 * This method is called to generate the questions missed by an applicant.
	 */
	public QuesAnsw generateMissedQuestions(List<IExamAnswer> examAnsList) {
		QuesAnsw quesAnsw = new QuesAnsw();
		QuestionLang quesLang = getQuestionLangByQuesGenId(examAnsList.get(Constant.FIRST_ELEMENT).getQuestionGenId());
		List<Answer> ansList = new ArrayList<Answer>();
		for(IExamAnswer ea: examAnsList) {
			Answer ans = getAnswerByAnswerGenId(ea.getEaPrimaryKey().getAnswerId());
			ansList.add(ans);
		}
		quesAnsw.setQuestionLang(quesLang);
		quesAnsw.setAnswerList(ansList);
		HandbookRef hb = getHandbookRefByHandbookRefAndLangId(quesLang.getHandbookRef(), quesLang.getLangId());
		quesAnsw.setHandbookRef(hb);
		return quesAnsw;
	}
	
	/*
	 * This method is called to get a list of test based on the group of the technician.
	 */
	public List<Test> getTestsBasedOnGroup(String group) {
		List<Test> testList1 = new ArrayList<Test>();
		String testOrigin = Constant.OFFICE_TYPE_FO;
		if(group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			testOrigin = Constant.OFFICE_TYPE_OL;
		}
		if(group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_USER_GROUP)){
			testOrigin = Constant.OFFICE_TYPE_CHP;
		}
		for(Test test: testList) {
			if(test.getTestOrigin().trim().equals(testOrigin)) {
				testList1.add(test);
			}
		}
		return testList1;
	}
	
	public List<Test> getNonCDLTests(String group) {
		List<Test> testList1 = new ArrayList<Test>();
		String testOrigin = Constant.OFFICE_TYPE_FO;
		if(group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			testOrigin = Constant.OFFICE_TYPE_OL;
		}
		if(group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_USER_GROUP)){
			testOrigin = Constant.OFFICE_TYPE_CHP;
		}
		for(Test test: testList) {
			if(!test.getCdlFlag().equalsIgnoreCase(Constant.YES) && test.getTestOrigin().trim().equals(testOrigin)) {
				testList1.add(test);
			}
		}
		return testList1;
	}
	
	public HandbookRef getHandbookRefByHandbookRef(String hb, String langId) {
		for(HandbookRef hb1: handbookRefList) {
			if(hb1.getHrPrimaryKey().getHandbookRef().trim().equalsIgnoreCase(hb.trim()) && hb1.getHrPrimaryKey().getLangId().trim().equalsIgnoreCase(langId.trim())) {
				return hb1;
			}
		}
		return null;
	}
	

	public String getSecurityServerURL() {
		return this.securityServerURL;
	}
	
//	public String getAudioFileServerURL() {
//		return fileServerURL + Constant.AUDIO_FILE_LOCATION;
//	}
	// add new signature to implementation (office_id) to get the office L1 server.  Fix media server URL
	public String getAudioFileL1ServerURL(String officeId) {
		
		audioFileL1ServerURL = null;
		for(Office office:officeList){
			if(officeId.trim().equals(office.getOfficeId())){
				audioFileL1ServerURL = office.getL1ServerIpAddr().trim();
			}				
		}
		return audioFileL1ServerURL + Constant.AUDIO_FILE_LOCATION;
	}
}
