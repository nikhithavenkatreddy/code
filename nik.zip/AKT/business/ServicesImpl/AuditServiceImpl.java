package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.AuditService;
import gov.ca.dmv.AKT.business.WorkloadImpl.AuditListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.AuditWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AuditServiceImpl extends BaseServiceImpl implements AuditService {
	
	private IPersistence persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}

	/*
	 * This method is responsible for inserting the audit data in the audit table.
	 */
	public IErrorWL saveAudit(String tableName, String fieldName, String oldValue, String newValue, String key, String techId) {
		IErrorWL errorWL = new ErrorWL();
		Audit audit = new Audit();
		audit.setFieldName(fieldName);
		audit.setLastModUsername(techId);
		audit.setLastModUserTime(new Date());
		audit.setOldValue(oldValue);
		audit.setNewValue(newValue);
		audit.setTableName(tableName);
		audit.setKey(key);
		try {
			persistence.save(audit);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	public IAuditListWL getAuditListForExamIds(List<Integer> examIds) {
		IAuditListWL auditListWL = new AuditListWL();
		
		try {
			List<String> examStrIds = convertIntToStrList(examIds);
 			List<Audit> auditList = persistence.loadAuditsByIds(examStrIds);
			auditListWL.setAuditList(auditList);
		}
		catch(AKTException e) {
			auditListWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return auditListWL;
	}

	private List<String> convertIntToStrList(List<Integer> examIds) {
		List<String> examStrList = new ArrayList<String>();
		
		for (Integer id: examIds) {
			examStrList.add(id.toString());
		}
		return examStrList;
	}
	
	@SuppressWarnings("unchecked")
	public IAuditWL getAuditByKeyAndTable(String key, String tableName) {
		IAuditWL auditWL = new AuditWL();
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("key", key);
			params.put("tableName", tableName);
			List<String> orders = new ArrayList<String>();
			orders.add("lastModUserTime");
			List<Audit> auditList = persistence.loadWithConditionsAndOrderBy(Audit.class, params, orders);
			if(auditList != null && auditList.size() > Constant.ZERO) {
				auditWL.setAudit(auditList.get(Constant.FIRST_ELEMENT));
			}
			else {
				auditWL.setErrorCode(ErrorCode.MISSING_AUDIT);
			}
		}
		catch(AKTException e) {
			auditWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return auditWL;
	}
}
