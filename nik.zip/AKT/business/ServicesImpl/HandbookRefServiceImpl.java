package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.HandbookRefService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.HandbookRefListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IHandbookRefListWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.HRPrimaryKey;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class HandbookRefServiceImpl implements HandbookRefService{
	private IPersistence persistence;
	private static final Logger logger = Logger.getLogger(CategoryServiceImpl.class);

	public IPersistence getPersistence() {
		return persistence;
	}
	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}
	private String getLikeString(String str) {
		return (Constant.PER + str.trim() + Constant.PER);
	}
	
	
	
	/**
	 * this method is to get the handbook
	 */
	@Override
	public IHandbookRefListWL getHandbook(HRPrimaryKey hrPrimaryKey) {
		IHandbookRefListWL handbookRefListWL= new HandbookRefListWL();
		handbookRefListWL.setErrorCode(ErrorCode.NO_ERROR);        
		List<HandbookRef> handbookList = new ArrayList<HandbookRef>();
        HandbookRef handbookRefBO= new HandbookRef();
        try{
        	handbookRefBO= (HandbookRef )persistence.findById(handbookRefBO, hrPrimaryKey);
        	if (handbookRefBO== null) {
        		handbookRefListWL.setErrorCode(ErrorCode.MISSING_HANDBOOKREF);
        	}
        	else if( handbookRefBO != null ) {
        		handbookList.add(Constant.FIRST_ELEMENT,handbookRefBO);
        		handbookRefListWL.setHandbookRefList(handbookList);     	        		
        	}
        }
        catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			handbookRefListWL.setErrorCode(e.getErrorCode());
		}
	 return  handbookRefListWL;
	}
	
	
	/**
	 * this method is used to new handbook
	 */
	@Override
	public IErrorWL saveHandbook(HandbookRef handbookBO) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.save(handbookBO);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	
	/**
	 * This method is used update a HandbookSection
	 */
	@Override
	public IHandbookRefListWL  updateHandbook(HandbookRef handbookBO) {
		IHandbookRefListWL handbookRefListWL= new HandbookRefListWL();
		handbookRefListWL.setErrorCode(ErrorCode.NO_ERROR);
	    try{
	      	persistence.update(handbookBO);	
	        }
	    catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			handbookRefListWL.setErrorCode(e.getErrorCode());
			}
	    return   handbookRefListWL;
	}
	
	
	
	/**
	 * This method is used to search handbook by handbookRef and/or langId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public IHandbookRefListWL searchHandbook(HandbookRef handbookBO,HRPrimaryKey hrPrimaryKey) {	
		IHandbookRefListWL HandbookRefListWL= new HandbookRefListWL();
		Map<String,Object> conditionMap = new HashMap<String,Object>(); 			
		conditionMap.put("hrPrimaryKey.langId", getLikeString(handbookBO.getHrPrimaryKey().getLangId()));
		conditionMap.put("handbookSectionName", getLikeString(handbookBO.getHandbookSectionName()));
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		List<HandbookRef> handbookBoList = null;
		try{
			handbookBoList= (List<HandbookRef>) persistence.loadWithLikeConditionsIgnoreCaseAndOrderBy(HandbookRef.class, conditionMap,null);	       
			HandbookRefListWL.setHandbookRefList(handbookBoList);
			if (handbookBoList.size()==Constant.ZERO) {
				HandbookRefListWL.setErrorCode(ErrorCode.NO_MATCH_FOUND);
			}
		}
        catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return  HandbookRefListWL;
	}

	
    
}
