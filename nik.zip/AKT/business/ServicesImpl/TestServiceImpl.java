package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.TestService;
import gov.ca.dmv.AKT.business.WorkloadImpl.CategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.IntegerWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.QuesAnswWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.QuestionCategoryTestListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.QuestionLangListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.StringListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestLangWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestPlanListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TimeLimtiListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuesAnswWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionCategoryTestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionLangListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestLangWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestPlanListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITimeLimitListWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.Question;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionCategoryTestList;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionList;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestCategory2;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;
import gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit;
import gov.ca.dmv.AKT.integration.Persistence.CategoryPersistence;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;
import gov.ca.dmv.AKT.integration.Persistence.QuestionPersistence;
import gov.ca.dmv.AKT.integration.Persistence.SearchPersistence;
import gov.ca.dmv.AKT.integration.Persistence.TestPersistence;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestServiceImpl extends BaseServiceImpl implements TestService{

	private TestPersistence     testPersistence;
	private SearchPersistence   searchPersistence;
	private QuestionPersistence questionPersistence;
	private CategoryPersistence categoryPersistence;
	private IPersistence        persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}
	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}
	public SearchPersistence getSearchPersistence() {
		return searchPersistence;
	}
	public void setSearchPersistence(SearchPersistence searchPersistence) {
		this.searchPersistence = searchPersistence;
	}
	public CategoryPersistence getCategoryPersistence() {
		return categoryPersistence;
	}
	public void setCategoryPersistence(CategoryPersistence categoryPersistence) {
		this.categoryPersistence = categoryPersistence;
	}
	public QuestionPersistence getQuestionPersistence() {
		return questionPersistence;
	}
	public void setQuestionPersistence(QuestionPersistence questionPersistence) {
		this.questionPersistence = questionPersistence;
	}
	public TestPersistence getTestPersistence() {
		return testPersistence;
	}
	public void setTestPersistence(TestPersistence testPersistence) {
		this.testPersistence = testPersistence;
	}
	
	/*
	 * This method is called to get the list of all categories
	 */
	@SuppressWarnings("unchecked")
	public ICategoryListWL getCategoriesList() {
		ICategoryListWL catWL = new CategoryListWL();
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			List<String> orders = new ArrayList<String>();
			orders.add("categoryName");
			List<gov.ca.dmv.AKT.integration.BeansImpl.Category> catList = persistence.loadWithConditionsAndOrderBy(Category.class, params, orders);
			if(catList != null && catList.size() > Constant.ZERO) {
				catWL.setCategoryList(catList);
			}
			else {
				catWL.setErrorCode(ErrorCode.NULL_CATEGORY_LIST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			catWL.setErrorCode(e.getErrorCode());
		}
		return catWL;
	}
	
	/*
	 * This method is called to get the list of test plan for a test
	 */
	public ITestPlanListWL getTestPlanListByTestId(String testId) {
		ITestPlanListWL testPlanWL = new TestPlanListWL();
		testPlanWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			Object[] params = {testId};
			List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList = categoryPersistence.loadByTestId(params);
			if(testPlanList != null && testPlanList.size() > Constant.ZERO) {
				testPlanWL.setTestPlanList(testPlanList);
			}
			else {
				testPlanWL.setErrorCode(ErrorCode.NULL_CATEGORY_LIST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			testPlanWL.setErrorCode(e.getErrorCode());
		}
		return testPlanWL;
	}
	
	/*
	 * This method is called to get the list of all tests
	 */
	@SuppressWarnings("unchecked")
	public ITestListWL getTestsList() {
		ITestListWL tlWL = new TestListWL();
		try {
			Test test = new Test();
			List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = persistence.findByExample(test);
			if(testList != null && testList.size() > Constant.ZERO) {
				tlWL.setTestList(testList);
			}
			else {
				tlWL.setErrorCode(ErrorCode.NULL_TEST_LIST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			tlWL.setErrorCode(e.getErrorCode());
		}
		return tlWL;
	}

	private String getLikeString(String str) {
		return (Constant.PER + str.trim() + Constant.PER);
	}
	
	/*
	 * This method is called to get the list of all tests by Id and Name
	 */
	@SuppressWarnings("unchecked")
	public ITestListWL getTestListByIdAndName(Test test) {
		ITestListWL tlWL = new TestListWL();
		if(test.getTestId()==null && test.getTestName() == null){
			tlWL.setErrorCode(ErrorCode.MISSING_REQUIRED);
		}
		else{
			try {
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("testId",getLikeString(test.getTestId()));
				params.put("testName",getLikeString(test.getTestName()));
				List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = persistence.loadWithLikeConditionsIgnoreCaseAndOrderBy(Test.class, params, null);
				if(testList != null && testList.size() > Constant.ZERO) {
					tlWL.setTestList(testList);
				}
				else {
					tlWL.setErrorCode(ErrorCode.NULL_TEST_LIST);
				}
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				tlWL.setErrorCode(e.getErrorCode());
			}
		}
		return tlWL;
	}
	/*
	 * This method is called to save the question and answers created from the create question module
	 */
	@SuppressWarnings("unchecked")
	public IErrorWL saveQuestion(QuesAnsw quesAnsw) {
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang questionLang = quesAnsw.getQuestionLang();
		List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList = quesAnsw.getAnswerList();
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			QuestionLang ql = new QuestionLang();
			ql.setQuestionLangId(questionLang.getQuestionLangId());
			ql.setQuestionLangStatus(Constant.ACTIVE);
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = persistence.findByExample(ql);
			if(quesLangList != null && quesLangList.size() > Constant.ZERO && !quesLangList.get(Constant.FIRST_ELEMENT).getChangeReviewStatusCode().trim().equalsIgnoreCase(Constant.DENIED)) {
				errWL.setErrorCode(ErrorCode.DUPLICATE_LANG_QUESTION);
			}
			else {
				questionLang.setChangeReviewStatusCode(Constant.PENDING);
				persistence.save(questionLang);
				Object[] params2 = {questionLang.getQuestionLangId(), questionLang.getLastModUserTime()};
				List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList2 = questionPersistence.loadByQuestionLangIdAndLastModUserTime(params2);
				if(quesLangList2 != null && quesLangList2.size() > Constant.ZERO) {
					gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang questionLang2 = quesLangList2.get(Constant.FIRST_ELEMENT);
					for(gov.ca.dmv.AKT.integration.BeansImpl.Answer ans: answerList) {
						ans.setQuestionGenId(questionLang2.getQuestionGenId());
						persistence.save(ans);
					}
				}
				else {
					errWL.setErrorCode(ErrorCode.NULL_QUESTION_LANG);
				}
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
//	public ReturnMessage saveQuestionList(QuesLangQuesList q) {
//		for(gov.ca.dmv.AKT.business.Beans.QuestionList ql: q.getQuestionListCollection()) {
//			boolean questionListExists = categoryBO.doesQuestionListExist(ql.getQuestionId());
//			List<gov.ca.dmv.AKT.business.Beans.QuestionList> qlSet = 
//					new ArrayList<gov.ca.dmv.AKT.business.Beans.QuestionList>();
//			qlSet.add(ql);
//			if(!questionListExists)
//				categoryBO.saveQuestionList(qlSet);
//			else {
//				categoryBO.inactivateQuestionList(ql);
//				categoryBO.saveQuestionList(qlSet);
//			}
//		}
//		QuestionLangWL qlWL = questionBO.getQuestionLang(q.getQuestionLang().getQuestionGenId());
//		QuestionLang questionLang = qlWL.getQuestionLang();
//		questionBO.inactivateQuestionLang(questionLang.getQuestionGenId());
//		questionBO.saveQuestionLang(q.getQuestionLang());
//		QuestionLangWL quesLangWL = questionBO.getQuestionLang(q.getQuestionLang());
//		QuestionLang questLang = quesLangWL.getQuestionLang();
//		ReturnMessage rm = new ReturnMessage();
//		rm.setAutoGenId(questLang.getQuestionGenId());
//		rm.setError(false);
//		rm.setErrorMsg(null);
//		return rm;
//	}
	/*
	 * This method is called to get question lang and answers by question lang auto gen id
	 */
//	public IQuesAnswWL getQuesAnsw(Integer autoGenId) {
//		IQuesAnswWL qaWL = new QuesAnswWL();
//		qaWL.setErrorCode(ErrorCode.NO_ERROR);
//		QuesAnsw quesAnsw = new QuesAnsw();
//		try {
//			List<gov.ca.dmv.AKT.integration.Beans.QuestionLang> qlList = questionPersistence.loadByAutoGenId(autoGenId);
//			if(qlList != null && qlList.size() > Constant.ZERO) {
//				gov.ca.dmv.AKT.integration.Beans.QuestionLang questionLang = qlList.get(Constant.FIRST_ELEMENT);
//				List<gov.ca.dmv.AKT.integration.Beans.Answer> answerList = questionPersistence.loadAnsw(autoGenId);
//				Object[] params = {questionLang.getHandbookRef().trim(), questionLang.getLangId().trim()};
//				List<gov.ca.dmv.AKT.integration.Beans.HandbookRef> hbList = questionPersistence.loadByHandbookRef(params);
//				if(hbList != null && hbList.size() > Constant.ZERO) {
//					gov.ca.dmv.AKT.integration.Beans.HandbookRef handbookRef = hbList.get(Constant.FIRST_ELEMENT);
//					quesAnsw.setAnswerList(answerList);
//					quesAnsw.setHandbookRef(handbookRef);
//					quesAnsw.setQuestionLang(questionLang);
//					quesAnsw.setError(false);
//					List<gov.ca.dmv.AKT.integration.Beans.Question> quesList = questionPersistence.load(questionLang.getQuestionId().trim());
//					if(quesList != null && quesList.size() > Constant.ZERO) {
//						gov.ca.dmv.AKT.integration.Beans.Question question = quesList.get(Constant.FIRST_ELEMENT);
//						quesAnsw.setErrorMsg(question.getQuestionStatus());
//						qaWL.setQuesAnsw(quesAnsw);
//					}
//					else {
//						qaWL.setErrorCode(ErrorCode.NULL_QUESTION);
//					}
//				}
//				else {
//					qaWL.setErrorCode(ErrorCode.MISSING_HANDBOOKREF);
//				}
//			}
//			else {
//				quesAnsw.setError(true);
//			}
//		}
//		catch(AKTException e) {
//			logger.error(e.getMessage());
//			logger.error(e.getCause());
//			qaWL.setErrorCode(e.getErrorCode());
//		}
//		return qaWL;
//	}
	/*
	 * This method is used to get question lang and answers by question gen id.
	 */
	@SuppressWarnings("unchecked")
	public IQuesAnswWL getQuesAnswByAutoGenId(Integer autoGenId) {
		IQuesAnswWL qaWL = new QuesAnswWL();
		qaWL.setErrorCode(ErrorCode.NO_ERROR);
		QuesAnsw quesAnsw = new QuesAnsw();
		try {
			QuestionLang quesLang = new QuestionLang();
			QuestionLang questionLang = (QuestionLang) persistence.findById(quesLang, autoGenId);
			if(questionLang != null) {
				Answer ans = new Answer();
				ans.setQuestionGenId(autoGenId);
				List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList = persistence.findByExample(ans);
				if(answerList != null && answerList.size() > Constant.ZERO) {
					quesAnsw.setAnswerList(answerList);
					quesAnsw.setQuestionLang(questionLang);
				}
				else {
					qaWL.setErrorCode(ErrorCode.MISSING_ANSWERS);
				}
			}
			else
			{
				qaWL.setErrorCode(ErrorCode.MISSING_QUES_LANG);
			}
			qaWL.setQuesAnsw(quesAnsw);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qaWL.setErrorCode(e.getErrorCode());
		}
		return qaWL;
	}
//	public void saveAnswer(List<Answer> answerListA) {
//		questionBO.saveAnswer(answerListA);
//	}
	/*
	 * This method is called to retrieve question lang by question lang id
	 */
	public IQuestionLangListWL findQuest(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang) {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		qlWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = questionPersistence.loadQuesLang(quesLang.getQuestionLangId());
			if(quesLangList != null && quesLangList.size() > Constant.ZERO) {
				qlWL.setQuestionLangList(quesLangList);
			}
//			else {
//				qlWL.setErrorCode(ErrorCode.MISSING_QUES_LANG);
//			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}
	
	/*
	 * This method is called to retrieve question lang by question lang id
	 */
	public IQuestionLangListWL findQuestByPartialText(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ql) {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		qlWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			Object[] params = {ql.getLangId(), Constant.PER + ql.getQuestionText() + Constant.PER};
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = 
					      questionPersistence.loadQuesLangByPartialText(params);
			if(quesLangList != null && quesLangList.size() > Constant.ZERO) {
				qlWL.setQuestionLangList(quesLangList);
			}
//			else {
//				qlWL.setErrorCode(ErrorCode.MISSING_QUES_LANG);
//			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}
	
	/*
	 * This method is called to get question langs based on category
	 */
	public IQuestionLangListWL getQuestionList(gov.ca.dmv.AKT.integration.BeansImpl.Category cat) {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		qlWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = searchPersistence.load(cat.getCategoryId());
			if(quesLangList != null && quesLangList.size() > Constant.ZERO) {
				qlWL.setQuestionLangList(quesLangList);
			}
			else {
				qlWL.setErrorCode(ErrorCode.MISSING_QUESTIONS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}
	/*
	 * This method is called to get question langs based on test
	 */
	public IQuestionLangListWL getQuestionList(gov.ca.dmv.AKT.integration.BeansImpl.Test test) {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		qlWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = searchPersistence.loadForTest(test.getTestId());
			if(quesLangList != null && quesLangList.size() > Constant.ZERO) {
				qlWL.setQuestionLangList(quesLangList);
			}
			else {
				qlWL.setErrorCode(ErrorCode.MISSING_QUESTIONS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}
	/*
	 * This method is called to get question langs based on test and category
	 */
	public IQuestionLangListWL getQuestionList(TestCategory2 testCategory) {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		qlWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {testCategory.getCategoryId(), testCategory.getTestId()};
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> quesLangList = searchPersistence.loadByTestAndCategory(params);
			if(quesLangList != null && quesLangList.size() > Constant.ZERO) {
				qlWL.setQuestionLangList(quesLangList);
			}
			else {
				qlWL.setErrorCode(ErrorCode.MISSING_QUESTIONS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}
	/*
	 * Called by the create parent question module to save the parent question, associated categories and tests
	 */
	public IErrorWL saveParentQuestion(QuestionCategoryTestList questionCategoryList) {
		Question question = questionCategoryList.getQuestion();
		Category cat = questionCategoryList.getCategoryList().get(Constant.FIRST_ELEMENT);
		Test test = questionCategoryList.getTestList().get(Constant.FIRST_ELEMENT);
		IErrorWL errorWL = new ErrorWL();
		try {
			Question ques = new Question();
			ques = (Question) persistence.findById(ques, question.getQuestionId());
			if(ques != null) {
				errorWL.setErrorCode(ErrorCode.DUPLICATE_PARENT_QUESTION);
			}
			else {
				persistence.save(question);
				QuestionList questionList = new QuestionList();
				questionList.getQlPrimaryKey().setCategoryId(cat.getCategoryId().trim());
				questionList.setLastModUsername(question.getLastModUsername().trim());
				questionList.setLastModUserTime(question.getLastModUserTime());
				questionList.getQlPrimaryKey().setQuestionId(question.getQuestionId().trim());
				questionList.setQuestionStatus(Constant.ACTIVE);
				questionList.getQlPrimaryKey().setTestId(test.getTestId().trim());
				persistence.save(questionList);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	/*
	 * This method is called to get the parent question, its categories and tests by question id
	 */
	public IQuestionCategoryTestListWL getParentQuestion(gov.ca.dmv.AKT.integration.BeansImpl.Question question) {
		IQuestionCategoryTestListWL qctlWL = new QuestionCategoryTestListWL();
		QuestionCategoryTestList questionCategoryTestList = new QuestionCategoryTestList();
		Object[] params = {question.getQuestionId().trim(), Constant.ACTIVE};
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Category> catList = categoryPersistence.loadByQuestionId(params);
			if(catList != null && catList.size() > Constant.ZERO) {
				questionCategoryTestList.setCategoryList(catList);
				Object[] params2 = {question.getQuestionId(), Constant.ACTIVE};
				List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = testPersistence.loadByQuestionId(params2);
				if(testList != null && testList.size() > Constant.ZERO) {
					questionCategoryTestList.setTestList(testList);
					Question ques = new Question();
					ques = (Question) persistence.findById(ques, question.getQuestionId());
					if(ques != null) {
						questionCategoryTestList.setQuestion(ques);
						qctlWL.setQuestionCategoryTestList(questionCategoryTestList);
					}
					else {
						qctlWL.setErrorCode(ErrorCode.NULL_QUESTION);
					}
				}
				else {
					qctlWL.setErrorCode(ErrorCode.NULL_TEST_LIST2);
				}
			}
			else {
				qctlWL.setErrorCode(ErrorCode.NULL_CATEGORY_LIST2);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qctlWL.setErrorCode(e.getErrorCode());
		}
		return qctlWL;
	}
	/*
	 * This method is called to update the parent question with new categories and tests
	 */
	public IErrorWL updateParentQuestion(QuestionCategoryTestList questionCategoryTestList) {
		IErrorWL errrWL = new ErrorWL();
		Question question = questionCategoryTestList.getQuestion();
		Category cat = questionCategoryTestList.getCategoryList().get(Constant.FIRST_ELEMENT);
		Test test = questionCategoryTestList.getTestList().get(Constant.FIRST_ELEMENT);
		try {
			Question quest = new Question();
			quest = (Question) persistence.findById(quest, question.getQuestionId());
			quest.setLastModUsername(question.getLastModUsername());
			quest.setLastModUserTime(question.getLastModUserTime());
			quest.setQuestionStatus(question.getQuestionStatus());
			persistence.update(quest);
			Object[] params = {question.getQuestionId(), Constant.ACTIVE};
			List<QuestionList> qlColl = categoryPersistence.load(params);
			if(qlColl != null && qlColl.size() > Constant.ZERO) {
				for(QuestionList questionList: qlColl) {
					if(!questionList.getQlPrimaryKey().getCategoryId().equalsIgnoreCase(cat.getCategoryId()) || !questionList.getQlPrimaryKey().getTestId().equalsIgnoreCase(test.getTestId())) {
						questionList.setLastModUserTime(new Date());
						questionList.setQuestionStatus(Constant.INACTIVE);
						persistence.update(questionList);
						gov.ca.dmv.AKT.integration.BeansImpl.QuestionList questionList2 = new gov.ca.dmv.AKT.integration.BeansImpl.QuestionList();
						questionList2.getQlPrimaryKey().setCategoryId(cat.getCategoryId().trim());
						questionList2.setLastModUsername(question.getLastModUsername().trim());
						questionList2.setLastModUserTime(question.getLastModUserTime());
						questionList2.getQlPrimaryKey().setQuestionId(question.getQuestionId().trim());
						questionList2.setQuestionStatus(Constant.ACTIVE);
						questionList2.getQlPrimaryKey().setTestId(test.getTestId());
						persistence.saveOrUpdate(questionList2);
					}
				}
			}
			else {
				errrWL.setErrorCode(ErrorCode.NULL_QUESTIONLIST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errrWL.setErrorCode(e.getErrorCode());
		}
		return errrWL;
	}
	/*
	 * This method is called to update any changes made to question lang and its answer choices.
	 */
	@SuppressWarnings("unchecked")
	public IIntegerWL updateQuestion(QuesAnsw quesAnsw) {
		IIntegerWL intWL = new IntegerWL();
		try {
			Date currDate = new Date();
			QuestionLang modQuesLang = quesAnsw.getQuestionLang();
			modQuesLang.setLastModUsername(getUserId());
			modQuesLang.setLastModUserTime(currDate);
			modQuesLang.setChangeReviewStatusCode(Constant.PENDING);
			intWL.setInteger(modQuesLang.getQuestionGenId());
			List<Answer> modAnsList = quesAnsw.getAnswerList();
			QuestionLang oldQuesLang = new QuestionLang();
			oldQuesLang = (QuestionLang) persistence.findById(oldQuesLang, modQuesLang.getQuestionGenId());
			if(oldQuesLang.getChangeReviewStatusCode().equalsIgnoreCase(Constant.PENDING) || oldQuesLang.getChangeReviewStatusCode().equalsIgnoreCase(Constant.PENDING_INACTIVE)) {
				persistence.update(modQuesLang);
				persistence.saveOrUpdateList(modAnsList);
			}
			else {
				modQuesLang.setQuestionGenId(null);
				persistence.save(modQuesLang);
				intWL.setInteger(modQuesLang.getQuestionGenId());
				for(Answer ans: modAnsList) {
					ans.setAnswerGenId(null);
					ans.setQuestionGenId(modQuesLang.getQuestionGenId());
					ans.setLastModUsername(getUserId());
					ans.setLastModUserTime(currDate);
				}
				persistence.saveList(modAnsList);
				if(oldQuesLang.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.ACTIVE) && modQuesLang.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.INACTIVE)) {
					createAuditForApproveDenyRevw(oldQuesLang.getQuestionGenId(), modQuesLang.getQuestionGenId());
				}
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			intWL.setErrorCode(e.getErrorCode());
		}
		return intWL;
	}
	
	private void createAuditForApproveDenyRevw(Integer oldQuesGenId, Integer newQuesGenId) throws AKTException {
		Audit audit = new Audit();
		audit.setFieldName(Constant.QUESTION_GEN_ID);
		audit.setLastModUsername(getUserId());
		audit.setLastModUserTime(new Date());
		audit.setOldValue(String.valueOf(oldQuesGenId));
		audit.setNewValue(String.valueOf(newQuesGenId));
		audit.setTableName(Constant.QUESTION_LANG_TABLE);
		audit.setKey(String.valueOf(newQuesGenId));
		persistence.save(audit);
	}
	
	//This method is called to inactivate the parent question//$$
//	public void inactivateQuestion(Question question) {
//		questionBO.inactivateQuestion(question.getQuestionId());
//	}
	
	//This method is called to activate the parent question//$$
//	public void activateQuestion(Question question) {
//		questionBO.activateQuestion(question.getQuestionId());
//	}

	//This method is called to shuffle a collection//$
//	private void shuffle(List<QuestionLang> qlList) {
//		Collections.shuffle(qlList);
//	}
	
	/*
	 * This method is called to generate the test based on the test id and language
	 */
//	public QuestionLangQuickPFWL generateTest(TestLang testLang) {
//		QuestionLangQuickPF quesLangQPF = new QuestionLangQuickPF();
//		QuestionLangQuickPFWL qlqpfWL = new QuestionLangQuickPFWL();
//		qlqpfWL.setSignTestFlag(false);
//		qlqpfWL.setErrorCode(ErrorCode.NO_ERROR);
//		QuickPassFailEventWL qpfWL = testBO.getQuickPassFailEvent(testLang.getTestId().trim());
//		if(qpfWL.getErrorCode() == ErrorCode.NO_ERROR || qpfWL.getErrorCode() == ErrorCode.MISSING_QPF) {
//			QuickPassFailEvent qpfEvent = qpfWL.getQuickPassFailEvent();
//			quesLangQPF.setQuickPassFailEvent(qpfEvent);
//			/*
//			TestWL testWL = testBO.loadTest(testLang.getTestId());
//			Test test = testWL.getTest();
//			
//			if(test.getRequiredSignTest().trim().equalsIgnoreCase(Constant.YES)) {
//				if(!testLang.isSignTestSatisfied()) {
//					Test signTest = testBO.loadSignTest();
//					testLang.setTestId(signTest.getTestId());
//					qlqpfWL.setSignTestFlag(true);
//				}
//			}*/
//			/*
//			if(!testLang.getTestLangId().equalsIgnoreCase(test.getDefaultLangFlag())) {
//				Test signTest = testBO.loadSignTest();
//				testLang.setTestId(signTest.getTestId());
//			}*/
//			TestPlanListWL tpWL = testBO.getTestPlans(testLang.getTestId());
//			if(tpWL.getErrorCode() == ErrorCode.NO_ERROR) {
//				List<TestPlan> testPlanList = tpWL.getTestPlanList();
//				List<QuestionLang> qlListWithOrder = new ArrayList<QuestionLang>();
//				List<QuestionLang> qlListWithoutOrder = new ArrayList<QuestionLang>();
//				for(TestPlan testPlan: testPlanList) {
//					TestCategoryLang categoryLang = new TestCategoryLang();
//					categoryLang.setCategoryId(testPlan.getCategoryId());
//					categoryLang.setLangId(testLang.getLangId());
//					categoryLang.setTestId(testPlan.getTestId());
//					QuestionLangListWL qlWL = searchBO.getActiveQuestionList(categoryLang);
//					if(qlWL.getErrorCode() == ErrorCode.NO_ERROR) {
//						List<QuestionLang> qlList = qlWL.getQuestionLangList();
//						shuffle(qlList);
//						int upper = testPlan.getCategoryQuestionCount().intValue();
//						List<QuestionLang> qlListCounted = qlList.subList(0, upper);
//						for(QuestionLang quesLang: qlListCounted) {
//							if(testPlan.getCategoryOrder() != Constant.ZERO)
//								qlListWithOrder.add(quesLang);
//							else
//								qlListWithoutOrder.add(quesLang);
//						}
//					}
//					else {
//						qlqpfWL.setErrorCode(qlWL.getErrorCode());
//					}
//				}
//				shuffle(qlListWithOrder);
//				shuffle(qlListWithoutOrder);
//				qlListWithOrder.addAll(qlListWithoutOrder);
//				quesLangQPF.setQuestionLangList(qlListWithOrder);
//				qlqpfWL.setQuestionLangQuickPF(quesLangQPF);
//			}
//			else {
//				qlqpfWL.setErrorCode(tpWL.getErrorCode());
//			}
//		}
//		else {
//			qlqpfWL.setErrorCode(qpfWL.getErrorCode());
//		}
//		return qlqpfWL;
//	}
	/*
	 * This method's called to get the name of the tests in corresponding languages by test id and language id
	 */
	public ITestLangWL getTestLang(gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang) {
		ITestLangWL tlWL = new TestLangWL();
		tlWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.TestLang> testLangList = null;
		Object[] params = {testLang.getTlPrimaryKey().getTestId(), testLang.getLangId()};
		try {
			testLangList = testPersistence.load(params);
			if(testLangList != null && testLangList.size() > Constant.ZERO) {
				tlWL.setTestLang(testLangList.get(Constant.FIRST_ELEMENT));
			}
			else {
				tlWL.setErrorCode(ErrorCode.INCORRECT_TEST_LANG);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			tlWL.setErrorCode(e.getErrorCode());
		}
		return tlWL;
	}
	
	/*
	 * This method is going to get a list of eligible quick pass fail test.
	 */
	public ITestListWL getEligibleQPFTestList() {
		ITestListWL qpfTestListWL = new TestListWL();
		qpfTestListWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {Constant.YES, Constant.INACTIVE};
		try {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = testPersistence.loadQPFList(params);
						
			if(testList != null && testList.size() > Constant.ZERO) {
				qpfTestListWL.setTestList(testList);
			}
			else {
				qpfTestListWL.setErrorCode(ErrorCode.MISSING_QPF_TESTS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qpfTestListWL.setErrorCode(e.getErrorCode());
		}
		return qpfTestListWL;
	}
	
	/*
	 * This method is called to get question lang and answer records by question lang id and answer ids.
	 */
//	public QuesAnswWL getQuestText(QuesAnswId quesAnswId) {
//		QuestionLangWL questionWL = questionBO.getQuestionLang(quesAnswId.getQuestionGenId());
//		QuesAnswWL qaWL = new QuesAnswWL();
//		qaWL.setErrorCode(ErrorCode.NO_ERROR);
//		if(questionWL.getErrorCode() == ErrorCode.NO_ERROR) {
//			QuestionLang quesLang = questionWL.getQuestionLang();
//			List<Answer> answerList = new ArrayList<Answer>();
//			for(int answerId: quesAnswId.getAnswerIdList()) {
//				AnswerWL ansWL = questionBO.getAnswer(answerId);
//				if(ansWL.getErrorCode() == ErrorCode.NO_ERROR) {
//					Answer answer = ansWL.getAnswer();
//					answer.setSignImage(answer.getSignImage().trim());
//					answerList.add(answer);
//				}
//				else {
//					qaWL.setErrorCode(ansWL.getErrorCode());
//				}
//			}
//			QuesAnsw quesAnsw = new QuesAnsw();
//			quesAnsw.setAnswerList(answerList);
//			quesAnsw.setQuestionLang(quesLang);
//			qaWL.setQuesAnsw(quesAnsw);
//		}
//		else {
//			qaWL.setErrorCode(questionWL.getErrorCode());
//		}
//		return qaWL;
//	}
	
	/*
	 * This method is called to get the list of all parent question ids.
	 */
	public IStringListWL getAllQuestionIds() {
		IStringListWL strWL = new StringListWL();
		strWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<String> strList = questionPersistence.loadAllQuestionIds();
			if(strList != null && strList.size() > Constant.ZERO) {
				strWL.setStringList(strList);
			}
			else {
				strWL.setErrorCode(ErrorCode.NULL_QUESTION_IDS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			strWL.setErrorCode(e.getErrorCode());
		}
		return strWL;
	}
	
	/*
	 * This method is called to get test by test id
	 */
	public ITestWL getTest(String testId) {
		ITestWL testWL = new TestWL();
		testWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = null;
		try {
			testList = testPersistence.loadByTestId(testId);
			if(testList != null && testList.size() > Constant.ZERO) {
				testWL.setTest(testList.get(Constant.FIRST_ELEMENT));
			}
			else {
				testWL.setErrorCode(ErrorCode.MISSING_TEST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			testWL.setErrorCode(e.getErrorCode());
		}
		return testWL;
	}
	/*
	 * This method is called to submit the quick pass fail choices made by the HQ user to set the tests with 
	 * quick pass fail flag on/off
	 */
	public IErrorWL updateQPFList(List<gov.ca.dmv.AKT.integration.BeansImpl.QPFList> qpfList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		long num = System.currentTimeMillis();
		for(gov.ca.dmv.AKT.integration.BeansImpl.QPFList qpf: qpfList) {
			num = num + 1;
			gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent qpf2 = new gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent();
			qpf2.setLastModUsername(getUserId());
			qpf2.setLastModUserTime(new Date());
			qpf2.setQuickPassFlag(qpf.getQuickPassFlag());
			qpf2.setQuickFailFlag(qpf.getQuickFailFlag());
			qpf2.setTestId(qpf.getTestId());
			qpf2.setTimestamp(new Date(num));
			try {
				testPersistence.saveQPFEvent(qpf2);
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errWL.setErrorCode(e.getErrorCode());
			}
		}
		return errWL;
	}
	
	/*
	 * This method is called to submit the quick pass fail choices made by the HQ user to set the tests with 
	 * quick pass fail flag on/off
	 */
	public IErrorWL updateQPFTestList(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		for(gov.ca.dmv.AKT.integration.BeansImpl.Test qpf: testList) {
			qpf.setLastModUsername(getUserId());
			qpf.setLastModUserTime(new Date());			
			
			try {
				testPersistence.save(qpf);
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errWL.setErrorCode(e.getErrorCode());
			}
		}
		return errWL;
	}
	
	/*
	 * This method is called to generate the questions answered incorrectly by the applicant
	 */
	@SuppressWarnings("unchecked")
	public IQuesAnswWL generateMissedQuestions(List<IExamAnswer> examAnsList) {
		IQuesAnswWL qaWL = new QuesAnswWL();
		qaWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			QuestionLang questLang = new QuestionLang();
			QuestionLang quesLang = (QuestionLang) persistence.findById(questLang, examAnsList.get(Constant.FIRST_ELEMENT).getQuestionGenId());
			if(quesLang != null) {
				List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> ansList = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.Answer>();
				for(IExamAnswer examAnswer: examAnsList) {
					List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> ansList2 = questionPersistence.loadByAnsGenId(examAnswer.getEaPrimaryKey().getAnswerId());
					if(ansList2 != null && ansList2.size() > Constant.ZERO) {
						ansList.add(ansList2.get(Constant.FIRST_ELEMENT));
					}
					else {
						qaWL.setErrorCode(ErrorCode.MISSING_ANSWERS);
					}
				}
				if(qaWL.getErrorCode() == ErrorCode.NO_ERROR) {
					QuesAnsw quesAnsw = new QuesAnsw();
					quesAnsw.setQuestionLang(quesLang);
					quesAnsw.setAnswerList(ansList);
					Object[] params = {quesLang.getHandbookRef(), quesLang.getLangId()};
					List<gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef> hbList = questionPersistence.loadByHandbookRef(params);
					if(hbList != null && hbList.size() > Constant.ZERO) {
						quesAnsw.setHandbookRef(hbList.get(Constant.FIRST_ELEMENT));
						qaWL.setQuesAnsw(quesAnsw);
					}
					else {
						qaWL.setErrorCode(ErrorCode.MISSING_HANDBOOKREF);
					}
				}
			}
			else {
				qaWL.setErrorCode(ErrorCode.MISSING_QUES_LANG);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qaWL.setErrorCode(e.getErrorCode());
		}
		return qaWL;
	}
	
	/*
	 * This method is called to update test with max incorrect number
	 */
	public IErrorWL updateTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = testPersistence.loadByTestId(test.getTestId());
		if(testList != null && testList.size() > Constant.ZERO) {
			gov.ca.dmv.AKT.integration.BeansImpl.Test test2 = testList.get(Constant.FIRST_ELEMENT);
			test2.setMaxIncorrectNum(test.getMaxIncorrectNum());
			test2.setTestQuestionCount(test.getTestQuestionCount());
			try {
				persistence.update(test2);
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errorWL.setErrorCode(e.getErrorCode());
			}
		}
		else {
			errorWL.setErrorCode(ErrorCode.MISSING_TEST);
		}
		return errorWL;
	}
	
	
	/*
	 * This method is called to update test while modifying test type 
	 */
	public IErrorWL updateTestTypeTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = testPersistence.loadByTestId(test.getTestId());
		if(testList != null && testList.size() > Constant.ZERO) {
			gov.ca.dmv.AKT.integration.BeansImpl.Test test2 = testList.get(Constant.FIRST_ELEMENT);
			test2.setTestName(test.getTestName());
			test2.setTestOrigin(test.getTestOrigin());			
			test2.setMaxIncorrectNum(test.getMaxIncorrectNum());
			test2.setTimeLimit(test.getTimeLimit());
			test2.setTestQuestionCount(test.getTestQuestionCount());
			test2.setLastModUsername(test.getLastModUsername());
			test2.setLastModUserTime(test.getLastModUserTime());
			try {
				persistence.update(test2);
			}
			catch(AKTException e) {
				logger.error(e.getMessage());
				logger.error(e.getCause());
				errorWL.setErrorCode(e.getErrorCode());
			}
		}
		else {
			errorWL.setErrorCode(ErrorCode.MISSING_TEST);
		}
		return errorWL;
	}
	
	/*
	 * This method is called to create test 
	 */
	public IErrorWL saveTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.save(test);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	/*
	 * This method is called to modify a testPlan 
	 */
	public IErrorWL modifyTestPlanList(List<TestPlan> testPlanList) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			if(testPlanList != null && testPlanList.size() > Constant.ZERO) {
				Object[] params = {testPlanList.get(Constant.FIRST_ELEMENT).getTpPrimaryKey().getTestId()};
				List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanListRemove = categoryPersistence.loadByTestId(params);
				if(testPlanListRemove != null && testPlanListRemove.size() > Constant.ZERO) {
					persistence.deleteList(testPlanListRemove);
				}
				if (testPlanList.get(Constant.FIRST_ELEMENT).getTpPrimaryKey().getCategoryId() != null) {
					persistence.saveList(testPlanList);				
				}
			}			
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	/*
	 * This method is called to modify a testPlan 
	 */
	public IErrorWL updateTestLangList(List<TestLang> testLangList) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
				persistence.saveOrUpdateList(testLangList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	/*
	 * This method is called to save a testPlan 
	 */
	public IErrorWL saveTestPlanList(List<TestPlan> testPlanList) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.saveList(testPlanList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	/*
	 * This method is called to save a testLang 
	 */
	public IErrorWL saveTestLangList(List<TestLang> testLangList) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.saveList(testLangList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errorWL.setErrorCode(e.getErrorCode());
		}
		return errorWL;
	}
	
	/*
	 * This method is called to update test plan with Category Question Count.
	 */
	public IErrorWL updateTestPlanList(String testId, List<TestPlan> testPlanList) {
		IErrorWL errorWL = new ErrorWL();
		errorWL.setErrorCode(ErrorCode.NO_ERROR);
		Map<String, TestPlan> testPlanMap = new HashMap<String, TestPlan>();
		for(TestPlan testPlan: testPlanList) {
			testPlanMap.put(testPlan.getTpPrimaryKey().getTestId().trim() + 
					        testPlan.getTpPrimaryKey().getCategoryId().trim(), testPlan);
		}
		
		Object[] params = {testId};
		List<TestPlan> curTPList = categoryPersistence.loadByTestId(params);
		if(curTPList != null && curTPList.size() > Constant.ZERO) {
			TestPlan testPlanNew = null;
			for(TestPlan testPlan: curTPList) {				
				testPlanNew = testPlanMap.get(testPlan.getTpPrimaryKey().getTestId().trim() + 
						        testPlan.getTpPrimaryKey().getCategoryId().trim());
				testPlan.setCategoryQuestionCount(testPlanNew.getCategoryQuestionCount());
				
				try {
					persistence.update(testPlan);
				}
				catch(AKTException e) {
					logger.error(e.getMessage());
					logger.error(e.getCause());
					errorWL.setErrorCode(e.getErrorCode());
				}
			}			
		}
		else {
			errorWL.setErrorCode(ErrorCode.MISSING_TEST);
		}
		return errorWL;
	}

	/*
	 * This method is called to get a list of language specific questions that are awaiting review and inactivate
	 * the questions that have not been reviewed in 60 days.
	 */
	@SuppressWarnings("unchecked")
	public IQuestionLangListWL getPendingReviewQues() {
		IQuestionLangListWL qlWL = new QuestionLangListWL();
		try {
			QuestionLang ql = new QuestionLang();
			ql.setChangeReviewStatusCode(Constant.PENDING);
			List<QuestionLang> qlList = persistence.findByExample(ql);
			List<QuestionLang> qlList2 = new ArrayList<QuestionLang>();
			if(qlList != null && qlList.size() > Constant.ZERO) {
				for(QuestionLang ql2: qlList) {
					if(Constant.hasBeen60Days(ql2.getLastModUserTime())) {
						ql2.setChangeReviewStatusCode(Constant.PENDING_INACTIVE);
						ql2.setLastModUsername(getUserId());
						ql2.setLastModUserTime(new Date());
						persistence.update(ql2);
					}
					else {
						qlList2.add(ql2);
					}
				}
			}
			qlWL.setQuestionLangList(qlList2);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qlWL.setErrorCode(e.getErrorCode());
		}
		return qlWL;
	}

	/*
	 * This method is called to get active question lang, answers by question lang id.
	 */
	@SuppressWarnings("unchecked")
	public IQuesAnswWL getActiveQuesAnswByQuesLangId(String questionLangId) {
		IQuesAnswWL qaWL = new QuesAnswWL();
		try {
			QuesAnsw qa = new QuesAnsw();
			Object[] params = {questionLangId, Constant.ACTIVE, Constant.PENDING, Constant.PENDING_INACTIVE};
			List<QuestionLang> qlList = questionPersistence.loadActiveQuestionLangByQuesLangId(params);
			if(qlList != null && qlList.size() > Constant.ZERO) {
				QuestionLang ql = qlList.get(Constant.FIRST_ELEMENT);
				Answer ans = new Answer();
				ans.setQuestionGenId(ql.getQuestionGenId());
				List<Answer> ansList = persistence.findByExample(ans);
				if(ansList != null && ansList.size() > Constant.ZERO) {
					qa.setQuestionLang(ql);
					qa.setAnswerList(ansList);
					qaWL.setQuesAnsw(qa);
				}
			}
		}
		catch(AKTException e) {
			System.out.println("We have an error!!");
			System.out.println(e.getCause());
			logger.error(e.getMessage());
			logger.error(e.getCause());
			qaWL.setErrorCode(e.getErrorCode());
		}
		return qaWL;
	}

	/*
	 * This method is called to update the language specific question record.
	 */
	public IErrorWL updateQuesLang(QuestionLang ql) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.update(ql);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to update a list of answers.
	 */
	public IErrorWL updateAnsList(List<Answer> oldAnsList) {
		IErrorWL errWL = new ErrorWL();
		try {
			persistence.updateList(oldAnsList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to update a list of time limits.
	 */
	public IErrorWL updateTimeLimitList(List<TimeLimit> timeLimitList){
		IErrorWL errWL = new ErrorWL();		
		try {
			persistence.updateList(timeLimitList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to update a list of time limits.
	 */
	public ITimeLimitListWL getTimeLimitList(){
		ITimeLimitListWL tlListWL = new TimeLimtiListWL();		
		try {
			List<TimeLimit> tlList = persistence.findByExample(new TimeLimit());
			tlListWL.setTimeLimitList(tlList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			tlListWL.setErrorCode(e.getErrorCode());
		}
		return tlListWL;
	}
	
}