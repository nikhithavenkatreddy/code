package gov.ca.dmv.AKT.business.ServicesImpl;

import gov.ca.dmv.AKT.business.Services.ExamService;
import gov.ca.dmv.AKT.business.Services.ExamSessionData;
import gov.ca.dmv.AKT.business.WorkloadImpl.BooleanWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamQuestionListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ExamWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ResultListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.TestReportsWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamQuestionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IResultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestReportsWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.AKTException;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Dates;
import gov.ca.dmv.AKT.integration.BeansImpl.EaseTest;
import gov.ca.dmv.AKT.integration.BeansImpl.Exam;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamSecondary;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.Persistence.ExamPersistence;
import gov.ca.dmv.AKT.integration.Persistence.IPersistence;
import gov.ca.dmv.AKT.integration.Persistence.TestPersistence;
import gov.ca.dmv.AKT.presentation.Beans.QuesPassRate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class ExamServiceImpl extends BaseServiceImpl implements ExamService {

	private ExamPersistence examPersistence;
	private TestPersistence testPersistence;
	private IPersistence    persistence;
	
	public IPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(IPersistence persistence) {
		this.persistence = persistence;
	}

	public TestPersistence getTestPersistence() {
		return testPersistence;
	}

	public void setTestPersistence(TestPersistence testPersistence) {
		this.testPersistence = testPersistence;
	}

	public ExamPersistence getExamPersistence() {
		return examPersistence;
	}

	public void setExamPersistence(ExamPersistence examPersistence) {
		this.examPersistence = examPersistence;
	}

	public ExamSessionData getExamSessionData() {
		return examSessionData;
	}

	public void setExamSessionData(ExamSessionData examSessionData) {
		this.examSessionData = examSessionData;
	}

	/*
	 * This method is called to get a list of exams by application id and no end time
	 */
	@SuppressWarnings("unchecked")
	public IExamListWL loadExams(Integer applicationId) {
		IExamListWL examListWL = new ExamListWL();
		List<IExam> examList = null;
		try {
			IExam exam = new Exam();
			exam.setApplicationId(applicationId);
			exam.setExamEndTime(Constant.defaultDate);
			examList = persistence.findByExample(exam);
			if(examList != null && examList.size() > Constant.ZERO) {
				examListWL.setExamList(examList);
			}
			else {
				examListWL.setErrorCode(ErrorCode.NULL_EXAM_LIST);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			examListWL.setErrorCode(e.getErrorCode());
		}
		return examListWL;
	}

	/*
	 * This method is called to get exam by exam id
	 */
	@SuppressWarnings("unchecked")
	public IExamWL getExamByExamId(Integer examId) {
		IExamWL examWL = new ExamWL();
		try {
			gov.ca.dmv.AKT.integration.BeansImpl.Exam exam = new gov.ca.dmv.AKT.integration.BeansImpl.Exam();
			exam = (gov.ca.dmv.AKT.integration.BeansImpl.Exam)persistence.findById(exam, examId);
			if(exam != null) {
				examWL.setExam(exam);
			}
			else {
				examWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			examWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return examWL;
	}

	/*
	 * This method is called to get a list of exams by application id, no end time and session id not equal to the current session id
	 */
	public IExamListWL getExamByAppIdAndDifferentSessionId(IExam exam) {
		IExamListWL examListWL = new ExamListWL();
		examListWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {exam.getApplicationId(), Constant.defaultDate, exam.getSessionId()};
		List<IExam> examList = null;
		try {
			examList = examPersistence.loadByAppIdAndDifferentSessionId(params);
			if(examList != null && examList.size() > Constant.ZERO) {
				examListWL.setExamList(examList);
			}
			else {
				examListWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			examListWL.setErrorCode(e.getErrorCode());
		}
		return examListWL;
	}

	/*
	 * This method is called to fail an exam for inactivity (time-out)
	 */
	public IErrorWL failExam(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.save(exam);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method's called to clone the exam and create a stub exam
	 */
	public IErrorWL cloneStubExam(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		IExam exam1 = new gov.ca.dmv.AKT.integration.BeansImpl.Exam();
		exam1.setApplicationId(exam.getApplicationId());
		exam1.setTestId(exam.getTestId());
		exam1.setCdlFlag(exam.getCdlFlag());
		exam1.setQuickPassFailFlag(exam.getQuickPassFailFlag());
		exam1.setOfficeId(exam.getOfficeId());
		exam1.setPassFailIndicator(Constant.SINGLE_SPACE);
		exam1.setExamStartTime(Constant.defaultDate);
		exam1.setExamEndTime(Constant.defaultDate);
		exam1.setCompletionReasonCode(Constant.SINGLE_SPACE);
		exam1.setIncorrectAnswerCount(Constant.ZERO);
		exam1.setQuestionAnsweredCount(Constant.ZERO);
		exam1.setCorrectQuestionCount(Constant.ZERO);
		exam1.setEaseTimestamp(Constant.defaultDate);
		exam1.setLastModUsername(getUserId());
		exam1.setLastModUserTime(new Date());
		exam1.setLangId(Constant.SINGLE_SPACE);
		exam1.setMaxIncorrectNumber(exam.getMaxIncorrectNumber());
		exam1.setExamQuestionNumber(exam.getExamQuestionNumber());
		exam1.setEaseTestId(exam.getEaseTestId());
		exam1.setExamOrder(exam.getExamOrder());
		exam1.setSessionId(Constant.ZERO);
		exam1.setTestTypeCode(exam.getTestTypeCode());
		exam1.setOptionalTestInd(exam.getOptionalTestInd());
		exam1.setSignTestFlag(exam.getSignTestFlag());
		exam1.setSecondaryVerificationId(Constant.SINGLE_SPACE);
		exam1.setRemainingTime(examSeedData.getTestByTestId(exam.getTestId()).getTimeLimit()*TimeLimitTypeConstant.SECONDS);
		try {
			examPersistence.save(exam1);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	public IErrorWL submitAnswer(IExamQuestion examQuestion) {
		IErrorWL erWL = new ErrorWL();
		erWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.save(examQuestion);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			erWL.setErrorCode(e.getErrorCode());
		}
		return erWL;
	}

	/*
	 * This method is called to get all the incomplete exams
	 */
	public IExamListWL getIncompleteExams(String officeId, String appType) {
		IExamListWL exWL = new ExamListWL();
		exWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {Constant.defaultDate, Constant.defaultDate, officeId, appType};
		try {
			List<IExam> examList = examPersistence.loadByStartDateAndNoEndDateAndAppType(params);
			if(examList != null && examList.size() > Constant.ZERO) {
				exWL.setExamList(examList);
			}
			else {
				exWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			exWL.setErrorCode(e.getErrorCode());
		}
		return exWL;
	}

	/*
	 * This method is called by the batch process to fail incomplete exams
	 */
	public IErrorWL failExamBatch(Integer examId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.update(examId, new Date(), Constant.BATCH_FAIL, Constant.FAIL);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to remove any stub exam based on application id, test id and no start time
	 */
	public IErrorWL removeStub(IExam exam) {
		IErrorWL errorWL = new ErrorWL();
		Object[] params = {exam.getApplicationId(), exam.getTestId(), Constant.defaultDate};
		try {
			examPersistence.deleteStub(params);
			errorWL.setErrorCode(ErrorCode.NO_ERROR);
		}
		catch(AKTException e) {
			errorWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return errorWL;
	}

	/*
	 * This method is called to save the exam question
	 */
//	public ErrorWL saveExamQues(ExamQuestion examQuestion) {
//		return examBO.save(examQuestion);
//	}

	/*
	 * This method is called to save the exam answer
	 */
//	public ErrorWL saveExamAnsw(ExamAnswer examAnswer) {
//		return examBO.save(examAnswer);
//	}

	/*
	 * This method's called to get exam by test id, FO and different exam id.
	 */
	public IExam getExamByTestIdAndDiffExamId(IExam exam) {
		IExam exam1 = null;
		Object[] params = {exam.getExamId(), exam.getTestId(), exam.getOfficeId(), Constant.defaultDate, Constant.defaultDate};
		try {
			List<IExam> examList = examPersistence.loadByTestIdAndDiffExamId(params);
			if(examList != null && examList.size() > Constant.ZERO) {
				exam1 = examList.get(Constant.FIRST_ELEMENT);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return exam1;
	}

	/*
	 * This method's called to get exam questions by exam id.
	 */
	public IExamQuestionListWL getExamQues(Integer examId) {
		IExamQuestionListWL eqWL = new ExamQuestionListWL();
		try {
			List<IExamQuestion> eqList = examPersistence.getExamQues(examId);
			if(eqList != null && eqList.size() > Constant.ZERO) {
				eqWL.setExamQuestionList(eqList);
			}
			else {
				eqWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			eqWL.setErrorCode(e.getErrorCode());
		}
		return eqWL;
	}

	/*
	 * This method is called to force fail an exam.
	 */
//	public ErrorWL forceFailExam(Integer examId) {
//		return examBO.forceFailExam(examId);
//		//return examBO.save(exam);
//	}

	/*
	 * This method is called to update exam with ease transaction time.
	 */
//	public ErrorWL updateExamWithEaseTransactionTime(Exam exam) {
//		return examBO.updateExamWithEaseTransactionTime(exam);
//	}

	/*
	 * This method is called to create exam and exam history for required exams' data received from EASE.
	 */
	public boolean createRequiredExams(EaseTest easeTest) {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = testPersistence.loadByEaseTestId(easeTest.getEaseTestId().trim());
		gov.ca.dmv.AKT.integration.BeansImpl.Test test = testList.get(Constant.FIRST_ELEMENT);
		Date currentDate = new Date();
		IExam exam = new gov.ca.dmv.AKT.integration.BeansImpl.Exam();
		exam.setApplicationId(easeTest.getApplicationId());
		if(test.getCdlFlag().trim().equalsIgnoreCase(Constant.YES))
			exam.setCdlFlag(Constant.YES);
		else
			exam.setCdlFlag(Constant.NO);
		exam.setEaseTestId(test.getEaseTestId().trim());
		exam.setExamQuestionNumber(Integer.parseInt(test.getTestQuestionCount().trim()));
		exam.setLastModUserTime(currentDate);
		exam.setMaxIncorrectNumber(test.getMaxIncorrectNum());
		exam.setOfficeId(easeTest.getOfficeId());
		if(test.getQuickPassFailInd().trim().equalsIgnoreCase(Constant.YES))
			exam.setQuickPassFailFlag(Constant.YES);
		else
			exam.setQuickPassFailFlag(Constant.NO);
		exam.setTestId(test.getTestId().trim());
		exam.setOptionalTestInd(test.getOptionalTestInd().trim());
		exam.setTestTypeCode(test.getTestTypeCode().trim());
		//Default Values
		exam.setCompletionReasonCode(Constant.SINGLE_SPACE);
		exam.setCorrectQuestionCount(Constant.ZERO);
		exam.setEaseTimestamp(Constant.defaultDate);
		exam.setExamEndTime(Constant.defaultDate);
		exam.setExamOrder(Constant.ONE);
		exam.setExamStartTime(Constant.defaultDate);
		exam.setIncorrectAnswerCount(Constant.ZERO);
		exam.setLastModUsername(getUserId());
		exam.setPassFailIndicator(Constant.SINGLE_SPACE);
		exam.setQuestionAnsweredCount(Constant.ZERO);
		exam.setSessionId(Constant.ZERO);
		exam.setLangId(Constant.SINGLE_SPACE);
		exam.setSignTestFlag(Constant.NO);
		exam.setSecondaryVerificationId(Constant.SINGLE_SPACE);
		exam.setRemainingTime(Constant.ZERO);
		//
		examPersistence.save(exam);
		Object[] params = {exam.getApplicationId(), exam.getTestId(), Constant.defaultDate, Constant.SINGLE_SPACE};
		List<IExam> examList = examPersistence.loadByAppIdAndTestId(params);
		IExam exam2 = examList.get(Constant.FIRST_ELEMENT);
		
		IExamHistory examHistory = new gov.ca.dmv.AKT.integration.BeansImpl.ExamHistory();
		examHistory.setApplicationId(easeTest.getApplicationId());
		examHistory.setEaseReceivedTimestamp(currentDate);
		examHistory.setEaseStatusIndicator(easeTest.getEaseStatusIndicator().trim());
		examHistory.setEaseTestId(easeTest.getEaseTestId().trim());
		examHistory.setLastModUserTime(currentDate);
		examHistory.setPastExamId(exam2.getExamId());
		//Default Values
		examHistory.setAktStatusIndicator(Constant.SINGLE_SPACE);
		examHistory.setAktUpdatedTimestamp(currentDate);
		examHistory.setLastModusername(getUserId());
		//
		examPersistence.save(examHistory);
		
		//Check if sign test is required and if yes, then create a stub exam for the sign test
		/*
		if(test.getRequiredSignTest().equalsIgnoreCase(Constant.YES) && easeTest.getSignTestSatisfiedFlag().equalsIgnoreCase(Constant.NO)) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList2 = testPersistence.loadSignTest(Constant.YES);
			gov.ca.dmv.AKT.integration.BeansImpl.Test signTest = testList2.get(Constant.FIRST_ELEMENT);
			IExam exam1 = new gov.ca.dmv.AKT.integration.BeansImpl.Exam();
			exam1.setApplicationId(easeTest.getApplicationId());
			if(signTest.getCdlFlag().trim().equalsIgnoreCase(Constant.YES))
				exam1.setCdlFlag(Constant.YES);
			else
				exam1.setCdlFlag(Constant.NO);
			exam1.setEaseTestId(signTest.getEaseTestId().trim());
			exam1.setExamQuestionNumber(Integer.parseInt(signTest.getTestQuestionCount().trim()));
			exam1.setLastModUserTime(currentDate);
			exam1.setMaxIncorrectNumber(signTest.getMaxIncorrectNum());
			exam1.setOfficeId(easeTest.getOfficeId().trim());
			if(signTest.getQuickPassFailInd().trim().equalsIgnoreCase(Constant.YES))
				exam1.setQuickPassFailFlag(Constant.YES);
			else
				exam1.setQuickPassFailFlag(Constant.NO);
			exam1.setTestId(signTest.getTestId().trim());
			exam1.setOptionalTestInd(signTest.getOptionalTestInd().trim());
			exam1.setTestTypeCode(signTest.getTestTypeCode().trim());
			//Default Values
			exam1.setCompletionReasonCode(Constant.SINGLE_SPACE);
			exam1.setCorrectQuestionCount(Constant.ZERO);
			exam1.setEaseTimestamp(Constant.defaultDate);
			exam1.setExamEndTime(Constant.defaultDate);
			exam1.setExamOrder(Constant.ONE);
			exam1.setExamStartTime(Constant.defaultDate);
			exam1.setIncorrectAnswerCount(Constant.ZERO);
			exam1.setLastModUsername(getUserId());
			exam1.setPassFailIndicator(Constant.SINGLE_SPACE);
			exam1.setQuestionAnsweredCount(Constant.ZERO);
			exam1.setSessionId(Constant.ZERO);
			exam1.setLangId(Constant.SINGLE_SPACE);
			exam1.setSignTestFlag(Constant.YES);
			exam1.setSecondaryVerificationId(Constant.SINGLE_SPACE);
			exam1.setRemainingTime(Constant.ZERO);
			//
			examPersistence.save(exam1);
			Object[] params2 = {exam.getApplicationId(), exam.getTestId(), Constant.defaultDate, Constant.SINGLE_SPACE};
			List<IExam> examList2 = examPersistence.loadByAppIdAndTestId(params2);
			IExam exam3 = examList2.get(Constant.FIRST_ELEMENT);
			
			IExamHistory examHistory1 = new gov.ca.dmv.AKT.integration.BeansImpl.ExamHistory();
			examHistory1.setApplicationId(easeTest.getApplicationId());
			examHistory1.setEaseReceivedTimestamp(currentDate);
			examHistory1.setEaseStatusIndicator(easeTest.getSignTestHistory().trim());
			examHistory1.setEaseTestId(signTest.getEaseTestId().trim());
			examHistory1.setLastModUserTime(currentDate);
			examHistory1.setPastExamId(exam3.getExamId());
			//Default Values
			examHistory1.setAktStatusIndicator(Constant.SINGLE_SPACE);
			examHistory1.setAktUpdatedTimestamp(currentDate);
			examHistory1.setLastModusername(getUserId());
			//
			examPersistence.save(examHistory1);
			return true;
		}
		else {
			return false;
		}  */
		
		return true;
	}

	/*
	 * This method is called to save exam in exam table
	 */
	public IErrorWL saveExam(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.save(exam);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to save a list of exam records in the exam table.
	 */
	public IErrorWL saveExamList(List<IExam> exams) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.saveList(exams);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}
	
	/*
	 * This method is called to update exam in exam table
	 */
	public IErrorWL updateExam(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.update(exam);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to get the question gen id based on the exam id and question order.
	 */
//	public QuesAnswIdWL getQuesAnswId(ExamWithQuestionOrder examQuesOrder) {
//		IntegerWL intWL = examBO.getQuestGenId(examQuesOrder);
//		QuesAnswIdWL quesAnsWL = new QuesAnswIdWL();
//		quesAnsWL.setErrorCode(ErrorCode.NO_ERROR);
//		if(intWL.getErrorCode() == ErrorCode.NO_ERROR) {
//			int questionGenId = intWL.getInteger();
//			//int questionGenId = ((ExamQuestion)examSessionData.getExamQuestion(examQuesOrder.getExam().getExamId(), examQuesOrder.getQuestionPresentedOrder())).getQuestionGenId();
//			examQuesOrder.setQuestionGenId(questionGenId);
//			IntegerListWL intListWL = examBO.getAnswerIdList(examQuesOrder);
//			if(intListWL.getErrorCode() == ErrorCode.NO_ERROR) {
//				List<Integer> answerGenIdList = intListWL.getIntegerList(); 
//				QuesAnswId quesAnswId = new QuesAnswId();
//				quesAnswId.setAnswerIdList(answerGenIdList);
//				quesAnswId.setQuestionGenId(questionGenId);
//				quesAnsWL.setQuesAnswId(quesAnswId);
//			}
//			else {
//				quesAnsWL.setErrorCode(intListWL.getErrorCode());
//			}
//		}
//		else {
//			quesAnsWL.setErrorCode(intWL.getErrorCode());
//		}
//		return quesAnsWL;
//	}
	
	/*
	 * This method is called to fail an exam
	 */
//	public ErrorWL failExamNormal(Integer examId) {
//		return examBO.failExamNormal(examId);
//	}
	
	/*
	 * This method is called to fail an exam after the applicant quits the exam
	 */
	public IErrorWL failExamQuit(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.save(exam);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

//	/*
//	 * This method is called to pause an exam by exam id
//	 */
//	public IErrorWL pauseExam(gov.ca.dmv.AKT.integration.Beans.ExamAndVaultId examVault) {
//		IErrorWL erWL = new ErrorWL();
//		erWL.setErrorCode(ErrorCode.NO_ERROR);
//		try {
//			gov.ca.dmv.AKT.integration.Beans.Exam exam = examVault.getExam();
//			examPersistence.save(exam);
//			Date currentDate = new Date();
//			gov.ca.dmv.AKT.integration.Beans.PauseRestartEvent prEvent = new gov.ca.dmv.AKT.integration.Beans.PauseRestartEvent();
//			prEvent.setActionEventCode(Constant.PAUSE);
//			prEvent.setApplicationId(exam.getApplicationId());
//			prEvent.setApplicationPauseTime(currentDate);
//			prEvent.setApplicationResumeTime(Constant.defaultDate);
//			prEvent.setLastModUsername(getUserId());
//			prEvent.setLastModUserTime(currentDate);
//			prEvent.setOfficeId(exam.getOfficeId());
//			prEvent.setTechUnpauseTime(Constant.defaultDate);
//			prEvent.setVaultId(examVault.getVaultId());
//			prEvent.getPrPrimaryKey().setExamId(exam.getExamId());
//			prEvent.getPrPrimaryKey().setTimestamp(currentDate);
//			examPersistence.save(prEvent);
//		}
//		catch(AKTException e) {
//			logger.error(e.getMessage());
//			logger.error(e.getCause());
//			erWL.setErrorCode(e.getErrorCode());
//		}
//		return erWL;
//	}

	/*
	 * This method is called to get the list of paused exams for a list of application ids.
	 */
	public IExamListWL getPausedExams(List<Integer> appIds) {
		IExamListWL exWL = new ExamListWL();
		try {
			List<IExam> examList = examPersistence.loadPausedExamsByAppIds(appIds);
			exWL.setExamList(examList);
		}
		catch(AKTException e) {
			exWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return exWL;
	}
	
	/*
	 * This method is called to get the list of non-completed exams for a list of application ids.
	 */
	public IExamListWL getAllExams(List<Integer> appIds) {
		IExamListWL exWL = new ExamListWL();
		try {
			List<IExam> examList = examPersistence.loadAllExamsByAppIds(appIds);
			exWL.setExamList(examList);
		}
		catch(AKTException e) {
			exWL.setErrorCode(e.getErrorCode());
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return exWL;
	}

	/*
	 * This method is called to get the stub exam created for taking sign test
	 */
	public IExamWL getSignExam(Integer applicationId) {
		IExamWL examWL = new ExamWL();
		IExam exam = null;
		try {
			exam = new Exam();
			exam.setApplicationId(applicationId);
			exam.setSignTestFlag(Constant.YES);
			exam.setExamStartTime(Constant.defaultDate);
			List<IExam> examList = persistence.findByExample(exam);
			if(examList != null && examList.size() > Constant.ZERO) {
				exam = examList.get(Constant.FIRST_ELEMENT);
				examWL.setExam(exam);
			}
			else {
				examWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			examWL.setErrorCode(e.getErrorCode());
		}
		return examWL;
	}

	/*
	 * This method is called to get a list of timed out exams
	 */
	@SuppressWarnings("unchecked")
	public IExamListWL getTimedOutExams(Integer appId) {
		IExamListWL elWL = new ExamListWL();
		IExam exam = new Exam();
		exam.setApplicationId(appId);
		exam.setCompletionReasonCode(Constant.TIME_OUT);
		try {
			List<IExam> examList = persistence.findByExample(exam);
			if(examList != null && examList.size() > Constant.ZERO) {
				elWL.setExamList(examList);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			elWL.setErrorCode(e.getErrorCode());
		}
		return elWL;
	}
	
	/*
	 * This method is called to get a list of quit exams
	 */
	public IExamListWL getQuitExams(String officeId, String appType) {
		IExamListWL elWL = new ExamListWL();
		elWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {officeId, Constant.QUIT, appType};
		List<IExam> examList = examPersistence.loadQuitExams(params);
		List<IExam> examList2 = new ArrayList<IExam>();
		if(examList != null && examList.size() > Constant.ZERO) {
			for(IExam exam: examList) {
				if(Constant.isToday(exam.getLastModUserTime())) {
					examList2.add(exam);
				}
			}
			elWL.setExamList(examList2);
		}
		else {
			elWL.setErrorCode(ErrorCode.MISSING_EXAMS);
		}		
		return elWL;
	}
	
	/*
	 * This method is called to get a list of exams
	 */
	public IExamListWL getAllExamsByOfficeId(String officeId, String appType) {
		IExamListWL elWL = new ExamListWL();
		elWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {officeId, appType};
		List<IExam> examList = examPersistence.loadAllExams(params);
		List<IExam> examList2 = new ArrayList<IExam>();
		if(examList != null && examList.size() > Constant.ZERO) {
			for(IExam exam: examList) {
				if(Constant.isToday(exam.getLastModUserTime())) {
					examList2.add(exam);
				}
			}
			elWL.setExamList(examList2);
		}
		else {
			elWL.setErrorCode(ErrorCode.MISSING_EXAMS);
		}
		return elWL;
	}	
	
	/*
	 * This method is called to get a list of missed exam questions based on exam id that were incorrectly answered by the applicant.
	 */
	public IExamQuestionListWL getMissedExamQues(int examId) {
		IExamQuestionListWL eqListWL = new ExamQuestionListWL();
		eqListWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {examId, Constant.NO};
		try {
			List<IExamQuestion> eqList = examPersistence.getMissedExamQues(params);
			if(eqList != null && eqList.size() > Constant.ZERO) {
				eqListWL.setExamQuestionList(eqList);
			}
			else {
				eqListWL.setErrorCode(ErrorCode.NO_MISSING_QUESTIONS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			
		}
		return eqListWL;
	}
	
	/*
	 * This method is called to get a list of missed exam questions based on exam id that were incorrectly answered by the applicant.
	 */
	public IExamQuestionListWL getFinishedExamQues(int examId) {
		IExamQuestionListWL eqListWL = new ExamQuestionListWL();
		eqListWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {examId, Constant.NO};
		try {
			List<IExamQuestion> eqList = examPersistence.getMissedExamQues(params);
			if(eqList != null && eqList.size() > Constant.ZERO) {
				eqListWL.setExamQuestionList(eqList);
			}
			else {
				eqListWL.setErrorCode(ErrorCode.MISSING_EXAM_QUESTION);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			
		}
		return eqListWL;
	}

	/*
	 * This method is called to get a list of exam answers by exam id and question gen id.
	 */
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenId(IExamQuestion examQues) {
		Object[] params = {examQues.getEqPrimaryKey().getExamId(), examQues.getQuestionGenId()};
		List<IExamAnswer> eaList = null;
		try {
			eaList = examPersistence.getExamAnsw(params);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return eaList;
	}


	/*
	 * This method is called to get a list of exam answers by exam id and question gen id order by answer_pres_Order.
	 */
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenIdOrderByAnswPresOrd(IExamQuestion examQues) {
		Object[] params = {examQues.getEqPrimaryKey().getExamId(), examQues.getQuestionGenId()};
		List<IExamAnswer> eaList = null;
		try {
			eaList = examPersistence.getExamAnswOrderByAnswPresOrd(params);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return eaList;
	}
	
	private List<IExamAnswer> getExamAnswByExamIdAndQuesGenIds(Integer examId, List<Integer> questionGenIds) {
		List<IExamAnswer> eaList = null;
		try {
			eaList = examPersistence.getExamAnswByExamIdAndQuesGenIds(examId, questionGenIds);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		return eaList;
	}
	
	public Map<Integer, List<IExamAnswer>> getQuesGenIdMapWithAnswOrderByAnswPresOrd(Integer examId, List<Integer> questionGenIds) {
		List<IExamAnswer> examAnswerList = getExamAnswByExamIdAndQuesGenIds(examId, questionGenIds);
		Map<Integer, List<IExamAnswer>> quesGenIdWithExamAnsOrder = new HashMap<Integer, List<IExamAnswer>>();
		for(IExamAnswer examAns : examAnswerList){
			List<IExamAnswer> examAnsList = quesGenIdWithExamAnsOrder.get(examAns.getQuestionGenId());
			if(examAnsList != null && !examAnsList.isEmpty()) {
				examAnsList.add(examAns);
			} else {
				examAnsList = new ArrayList<IExamAnswer>();
				examAnsList.add(examAns);
				quesGenIdWithExamAnsOrder.put(examAns.getQuestionGenId(), examAnsList);
			}
		}
		for(Integer currentKey : quesGenIdWithExamAnsOrder.keySet()){
			Collections.sort(quesGenIdWithExamAnsOrder.get(currentKey),  new Comparator<IExamAnswer>() {
		        @Override
		        public int compare(final IExamAnswer ea1, final IExamAnswer ea2) {
		        	return ea1.getAnswerPresentedOrder() > ea2.getAnswerPresentedOrder() ? 1:-1;
		        }
		    } );
		}
		return quesGenIdWithExamAnsOrder;
	}
	
	public List<Answer> getAnswerInDisplayOrder(List<IExamAnswer> examAnswerOrder, List<Answer> answerListUnordered) {
		Map<Integer, Answer> answerMap = new TreeMap<Integer, Answer>();
		for(IExamAnswer examAns : examAnswerOrder) {
			Answer answer = new Answer();
			for(Answer ans : answerListUnordered) {
				if(examAns.getEaPrimaryKey().getAnswerId().intValue() ==  ans.getAnswerGenId().intValue()) {
					answer = ans;
					break;
				}
			}
			answerMap.put(examAns.getAnswerPresentedOrder(), answer);
		}
		return new ArrayList<Answer>(answerMap.values());
	}
	
	/*
	 * This method is called to get a list of completed exams by application id
	 */
	public IExamListWL getCompletedExamsByAppId(Integer applicationId) {
		IExamListWL elWL = new ExamListWL();
		elWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {applicationId, Constant.SINGLE_SPACE};
		try {
			List<IExam> examList = examPersistence.loadCompletedExams(params);
			if(examList != null && examList.size() > Constant.ZERO) {
				elWL.setExamList(examList);
			}
			else {
				elWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			elWL.setErrorCode(e.getErrorCode());
		}
		return elWL;
	}

	/**
	 * This method is called to get the questions with the pass fail rate corresponding to each test 
	 */
	@SuppressWarnings("rawtypes")
	public ITestReportsWL getQuesPassRateList(Date fromDate, Date toDate) {		
		ITestReportsWL trWL = new TestReportsWL();
		trWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			List<QuesPassRate> quesPassRateList = new ArrayList<QuesPassRate>();
			List results = examPersistence.getQuesPassRateList(fromDate,toDate);
			
			List<Test> testList = persistence.loadAll(Test.class);
			Map<String, String> testNameMap = new HashMap<String, String>();
			for (Test test : testList) {
				testNameMap.put(test.getTestId(), test.getTestName());
			}
			
			for (Iterator it = results.iterator(); it.hasNext(); ) {
				Object[] myResult = (Object[]) it.next();
				QuesPassRate quesPassRate = new QuesPassRate();
				quesPassRate.setTestName((String)myResult[0]);
				quesPassRate.setQuestion((String)myResult[1]);
				quesPassRate.setLanguage((String)myResult[2]); 
				quesPassRate.setPassRate((Double)myResult[3]); 
				quesPassRate.setFailRate((Double)myResult[4]);
				
				if (quesPassRate.getFailRate() != null) {
					if (quesPassRate.getLanguage().equals("01")) {
						quesPassRate.setLanguage("English");
					}
					else if (quesPassRate.getLanguage().equals("02")) {
						quesPassRate.setLanguage("Spanish");
					}
					for (Entry<String, String> test : testNameMap.entrySet()){
						if (test.getKey().equals(quesPassRate.getTestName())){
						quesPassRate.setTestName(test.getValue());}
					}
					quesPassRate.setPassRate(roundToDecimals(quesPassRate.getPassRate(), 2));
					quesPassRate.setFailRate(roundToDecimals(quesPassRate.getFailRate(), 2));
					
					quesPassRateList.add(quesPassRate);
				}
			}
			trWL.setQuesPassRateList(quesPassRateList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage(), e);
			logger.error(e.getCause());
			trWL.setErrorCode(e.getErrorCode());
		}
		return trWL;
	}
	
	private static double roundToDecimals(double d, int c)  
	{   
		return new BigDecimal(d).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

	/*
	 * This method is called to get the list of outstanding exams between certain dates to generate report
	 */
	public IExamListWL getOutstandingExams(Dates dates) {
		IExamListWL elWL = new ExamListWL();
		elWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {Constant.TIME_OUT, Constant.BATCH_FAIL, dates.getFromDate(), dates.getToDate(), dates.getOfficeId()};
		try {
			List<IExam> examList = examPersistence.loadOutstandingExams(params);
			if(Constant.isToday(dates.getToDate())) {
				Object[] params2 = {Constant.defaultDate, Constant.defaultDate, dates.getOfficeId()};
				List<IExam> examList2 = examPersistence.loadByStartDateAndNoEndDate(params2);
				if(examList != null && examList.size() > Constant.ZERO && examList2 != null && examList2.size() > Constant.ZERO) {
					examList.addAll(examList2);
				}
			}
			elWL.setExamList(examList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			elWL.setErrorCode(e.getErrorCode());
		}
		return elWL;
	}

	/*
	 * This method is called to generate reports for records that did not get updated at EASE end
	 */
	public IResultListWL getEASEExceptionRecords(String officeId) {
		IResultListWL rlWL = new ResultListWL();
		rlWL.setErrorCode(ErrorCode.NO_ERROR);
		Object[] params = {Constant.EASE_PROCESSED, Constant.EASE_IGNORE, officeId};
		try {
			List<AKTSResults> resList = examPersistence.loadEASEExceptionRecords(params);
			if(resList != null && resList.size() > Constant.ZERO) {
				rlWL.setResultList(resList);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			rlWL.setErrorCode(e.getErrorCode());
		}
		return rlWL;
	}

	/*
	 * This method is called to update the exception report record with the status code to indicate it has been manually updated in the EASE DB
	 */
	public IErrorWL updateExceptionRep(Integer sysId) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			examPersistence.updateExceptionRep(sysId);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to insert a list of exam question records.
	 */
	public IErrorWL saveExamQuesList(List<IExamQuestion> examQuestionList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.saveList(examQuestionList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to insert a list of exam answer records.
	 */
	public IErrorWL saveExamAnswList(List<IExamAnswer> examAnswerList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		try {
			persistence.saveList(examAnswerList);
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			errWL.setErrorCode(e.getErrorCode());
		}
		return errWL;
	}

	/*
	 * This method is called to check whether there are any exams yet to be taken based on the application id.
	 */
	@SuppressWarnings("unchecked")
	public IBooleanWL hasExamsToTake(Integer applicationId) {
		IBooleanWL boolWL = new BooleanWL();
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("applicationId", applicationId);
			params.put("examStartTime", Constant.defaultDate);
			params.put("examEndTime", Constant.defaultDate);
			params.put("passFailIndicator", Constant.SINGLE_SPACE);
			List<IExam> examList = persistence.loadWithConditionsAndOrderBy(Exam.class, params, null);
			boolWL.setFlag(false);
			if(examList != null && examList.size() > Constant.ZERO) {
				boolWL.setFlag(true);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			boolWL.setErrorCode(e.getErrorCode());
		}
		return boolWL;
	}
	
	/*
	 * This method is called to get the exams yet to be taken based on the application id.
	 */
	@SuppressWarnings("unchecked")
	public IExamListWL getExamsToTake(Integer applicationId) {
		IExamListWL examWL = new ExamListWL();
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("applicationId", applicationId);
			params.put("examStartTime", Constant.defaultDate);
			params.put("examEndTime", Constant.defaultDate);
			//params.put("passFailIndicator", Constant.SINGLE_SPACE);
			List<IExam> examList = persistence.loadWithConditionsAndOrderBy(Exam.class, params, null);
			if(examList != null && examList.size() > Constant.ZERO) {
				examWL.setExamList(examList);
			}
			else {
				examWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			examWL.setErrorCode(e.getErrorCode());
		}
		return examWL;
	}

	/*
	 * This method is called to a list of exams by application id from present and past.
	 */
	@SuppressWarnings("unchecked")
	public IExamListWL getAllExamsByAppId(Integer applicationId) {
		IExamListWL exWL = new ExamListWL();
		List<IExam> examList = new ArrayList<IExam>();
		try {
			IExam exam = new Exam();
			exam.setApplicationId(applicationId);
			exam.setScoreToNull();
			List<IExam> examListToday = persistence.findByExample(exam);
			if(examListToday != null && examListToday.size() > Constant.ZERO) {
				examList.addAll(examListToday);
			}
			
			IExam examAll = new ExamSecondary();
			examAll.setApplicationId(applicationId);
			List<IExam> examListAll = persistence.findByExample(examAll);
			if(examListAll != null && examListAll.size() > Constant.ZERO) {
				examList.addAll(examListAll);
			}
			
			if(examList.size() > Constant.ZERO) {
				exWL.setExamList(examList);
			}
			else {
				exWL.setErrorCode(ErrorCode.MISSING_EXAMS);
			}
			
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			exWL.setErrorCode(e.getErrorCode());
		}
		return exWL;
	}

	@Override
	public IExamHistoryListWL getExamHistoryByExamId(Integer examId) {
		IExamHistoryListWL exhstWL = new ExamHistoryListWL();
		exhstWL.setErrorCode(ErrorCode.NO_ERROR);
		List<IExamHistory> exhst = null;
		try {
			exhst = examPersistence.loadByExamHistId(examId);
			if(exhst != null && exhst.size() > Constant.ZERO) {
				exhstWL.setExamHistoryList(exhst);
			}
			else {
				exhstWL.setErrorCode(ErrorCode.MISSING_EXAM_HISTORY);
			}
		}
		catch(AKTException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
			exhstWL.setErrorCode(e.getErrorCode());
		}
		return exhstWL;
	}
}		

