package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.FOBusDelegate;
import gov.ca.dmv.AKT.business.Services.ApplicationService;
import gov.ca.dmv.AKT.business.Services.ExamService;
import gov.ca.dmv.AKT.business.Services.SearchService;
import gov.ca.dmv.AKT.business.Services.SecurityService;
import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.Services.TestService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicantListWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicantListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamQuestionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;
import gov.ca.dmv.AKT.constants.AudioVideoConstant;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.SearchRequestTypeConstant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.BeansImpl.Exam;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamHistory;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.Search;
import gov.ca.dmv.AKT.integration.BeansImpl.Session;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.Vault;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSPublisher;
import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;
import gov.ca.dmv.AKT.presentation.Beans.Volume;
import gov.ca.dmv.AKT.presentation.Controller.FOUserController;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.DTO.ReportDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.WorkstationMapDTO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class FOBusDelegateImpl extends BaseBusDelegateImpl implements FOBusDelegate {
	
	private SessionService      sessionService;
	private ApplicationService  applicationService;
	private SearchService       searchService;
	private ExamService         examService;
	private TestService         testService;
	private SecurityService     securityService;
	private JMSPublisher        jmsPublisher;
	
	public JMSPublisher getJmsPublisher() {
		return jmsPublisher;
	}

	public void setJmsPublisher(JMSPublisher jmsPublisher) {
		this.jmsPublisher = jmsPublisher;
	}

	public SecurityService getSecurityService() {
		return securityService;
	}

	public void setSecurityService(SecurityService securityService) {
		this.securityService = securityService;
	}

	public TestService getTestService() {
		return testService;
	}

	public void setTestService(TestService testService) {
		this.testService = testService;
	}

	public ExamService getExamService() {
		return examService;
	}

	public void setExamService(ExamService examService) {
		this.examService = examService;
	}

	public SearchService getSearchService() {
		return searchService;
	}

	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}

	/*
	 * This method is called to update the unused workstations with the available status.
	 */
	private IErrorWL updateSessionsOnUnusedTerminals(List<ISession> sessList) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		for(ISession sess: sessList) {
			if(sess.getSessionStatusCode().trim().equalsIgnoreCase(Constant.SESSION_RESERVED)) {
				Boolean hasEndedInTenMin = Constant.hasEndedLongEnough3(sess.getSessionStartTime(),getReservedTimeout());
				if(hasEndedInTenMin) {
					errWL = sessionService.endSession(sess.getSessionId());
					if(errWL.getErrorCode() != ErrorCode.NO_ERROR){
						break;
					}
				}
			}
		}
		return errWL;
	}
	
	private Integer getReservedTimeout(){
		Integer timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.KEEP_TERMINAL_RESERVED);
		timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_KEEP_TERMINAL_RESERVED;
		return timeout/TimeLimitTypeConstant.SECONDS;		
	}
	
	/*
	 * This method is called to get status of all the workstations.
	 */
	//TODO since WorkstationMapDTO is output only, return it.
	private void getTerminalStatus(WorkstationMapDTO wmDTO,IWorkstationMapListWL wmWL) { 
		wmDTO.setErrorCode(wmWL.getErrorCode());
		if(wmWL.getErrorCode() == ErrorCode.NO_ERROR ){
			List<gov.ca.dmv.AKT.presentation.Beans.WorkstationMap> wmList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.WorkstationMap>();
			String officeId = "";
			if( !wmWL.getWorkstationMapList().isEmpty() ) {
				officeId = wmWL.getWorkstationMapList().get(Constant.FIRST_ELEMENT).getOfficeId();
			}
			ISessionListWL sessWL = sessionService.getCurrentSessions(officeId);
			if(sessWL.getErrorCode() == ErrorCode.NO_ERROR){
				HashMap<String,ISession> runningSessionStations = new HashMap<String,ISession>();
				for(ISession sess: sessWL.getSessionList()){
					runningSessionStations.put(sess.getWorkstationIPAddress().trim(),sess);
					if(sess.getSessionStatusCode().trim().equalsIgnoreCase(Constant.SESSION_RESERVED) && Constant.hasEndedLongEnough3(sess.getSessionStartTime(),getReservedTimeout())) {
						IErrorWL errWL = sessionService.endSession(sess.getSessionId());
						if(errWL.getErrorCode() != ErrorCode.NO_ERROR){
							wmDTO.setErrorCode(errWL.getErrorCode());
							break;
						}	
						runningSessionStations.remove(sess.getWorkstationIPAddress().trim());						
					}						
				}
				for (WorkstationMap wm: wmWL.getWorkstationMapList()){
					gov.ca.dmv.AKT.presentation.Beans.WorkstationMap wm2 = wmDTO.getWorkstationMapAfterPreTierConversion(wm);
					if(runningSessionStations.containsKey(wm.getWorkstationIPAddress().trim())){
						ISession session = runningSessionStations.get(wm.getWorkstationIPAddress().trim());
						if(session.getSessionStatusCode().equals(Constant.SESSION_RESERVED)) {
							wm2.setStatus(Constant.TERMINAL_RESERVED);
							examSessionData.setSession(session);
						}
						else
							wm2.setStatus(Constant.TERMINAL_TESTING);
					}
					else{
						wm2.setStatus(Constant.TERMINAL_AVAILABLE);
					}
					wmList.add(wm2);
				}										
			}
			else if(sessWL.getErrorCode() == ErrorCode.MISSING_SESSION){ //TODO remove once empty list is impelemeted for no result
				for (WorkstationMap wm: wmWL.getWorkstationMapList()){	
					gov.ca.dmv.AKT.presentation.Beans.WorkstationMap wm2 = wmDTO.getWorkstationMapAfterPreTierConversion(wm);
					wm2.setStatus(Constant.TERMINAL_AVAILABLE);
					wmList.add(wm2);
				}			
			}
			else{				
				wmDTO.setErrorCode(sessWL.getErrorCode());
			}
			wmDTO.setWorkstationMapList(wmList);
		}	
	}
	
	
	/*
	 * This method is called to get status of the workstation by ip address.
	 */ 
	public void getTerminalStatusByIP(WorkstationMapDTO wmDTO) {
		String ipAddr = wmDTO.getWorkstationMapList().get(Constant.FIRST_ELEMENT).getWorkstationIPAddress();
		IWorkstationMapListWL wmWL = sessionService.getWorkstationByIP(ipAddr); //TODO use seeded data
		getTerminalStatus(wmDTO,wmWL);
	}
	
	/*
	 * This method is called to get status of all the workstations by office id.
	 */ 
	public void getTerminalStatusByOfficeId(WorkstationMapDTO wmDTO) {
		String officeId = wmDTO.getWorkstationMapList().get(Constant.FIRST_ELEMENT).getOfficeId();
		IWorkstationMapListWL wmWL = examSeedData.getWorkstationMapListByOfficeId(officeId);	
		getTerminalStatus(wmDTO,wmWL);
		wmDTO.setOfficeIDList(examSeedData.getAllOfficeIDsInSameBuilding(officeId));
	}
	
	/*
	 * This method is called to transfer the terminal to another office.
	 */ 
	public void transferTerminal(WorkstationMapDTO wmDTO) {
		gov.ca.dmv.AKT.presentation.Beans.WorkstationMap workstation = wmDTO.getWorkstationMapList().get(Constant.FIRST_ELEMENT);
		String sourceOfficeId = workstation.getOfficeId();
		String targetOfficeId = wmDTO.getOfficeIDList().get(Constant.FIRST_ELEMENT);
		
		WorkstationMap workstationLocatingBO = examSeedData.getWorkstationMapByIPAddress(workstation.getWorkstationIPAddress().trim());	
		
		
		if(workstation.getOfficeId().trim().equals(workstationLocatingBO.getOfficeId().trim())){
			
			IBooleanWL boolWL = sessionService.isTerminalUsedInSession(workstation.getWorkstationIPAddress().trim(),sourceOfficeId);
			wmDTO.setErrorCode(boolWL.getErrorCode());
			if(wmDTO.getErrorCode() == ErrorCode.NO_ERROR) {				
				if(!boolWL.isFlag() ){
					
					WorkstationMap workstationBO = new WorkstationMap();
					workstationBO.setWorkstationIPAddress(workstation.getWorkstationIPAddress().trim());
					workstationBO.setLastModUserTime(new Date());
					workstationBO.setLastModUsername(getUserId());
					workstationBO.setOfficeId(String.valueOf(targetOfficeId).trim());
					workstationBO.setWorkstationId(workstationLocatingBO.getWorkstationId());					
									
					if(workstationLocatingBO.getLocatingOfficeId()!=null && workstationLocatingBO.getLocatingOfficeId().trim().length()>0){
						if(workstationLocatingBO.getLocatingOfficeId().trim().equals(String.valueOf(targetOfficeId).trim())){
							workstationBO.setLocatingOfficeId(Constant.SINGLE_SPACE);
						}
						else{
							workstationBO.setLocatingOfficeId(workstationLocatingBO.getLocatingOfficeId().trim());
						}
					}
					else{						
						workstationBO.setLocatingOfficeId(workstationLocatingBO.getOfficeId());
					}
					
					List<WorkstationMap> wmList= new ArrayList<WorkstationMap>();
					wmList.add(workstationBO);
					IErrorWL errWL = sessionService.updateWorkstations(wmList);
					
					if (errWL.getErrorCode() == ErrorCode.NO_ERROR) {
						publishUpdateWorkstationMapRequest(workstationBO);
					}
					wmDTO.setErrorCode(errWL.getErrorCode());
				}
				else{
					wmDTO.setErrorCode(ErrorCode.MISSING_WORKSTATION); //TODO change the error cde to unavailable
				}
			}
		}
		else{
			wmDTO.setErrorCode(ErrorCode.MISSING_WORKSTATION);
		}
	}
	
	/*
	 * This method is called to send a "Update Workstation Map" request through JMS
	 */
	public void publishUpdateWorkstationMapRequest(WorkstationMap workstationMap) {
		String ipAddr = workstationMap.getWorkstationIPAddress();
		String locatingOfficeId = workstationMap.getLocatingOfficeId();
		String officeId = workstationMap.getOfficeId();
		String message = padRight(ipAddr, 15) + officeId + locatingOfficeId;
		jmsPublisher.setMessage(message);
		jmsPublisher.sendMesage();
	}
	
	private static String padRight(String s, int n) {
		return String.format("%1$-" + n + "s", s);
	}
	
	/*
	 * This method is called to get list of all the offices.
	 */ 
	public void getAllOffices(WorkstationMapDTO wmDTO) {
		List<String> officeIDList = examSeedData.getAllOfficeIDs();	
		wmDTO.setOfficeIDList(officeIDList);
	}
	
	/*
	 * This method is called to get the test queue data (list of applicants ready to take a test)
	 */
	public void getTestQueueData(ApplicantDTO appDTO) {
		String officeId  = appDTO.getApplicantList().get(Constant.FIRST_ELEMENT).getOfficeId();
		String group = appDTO.getGroup();
		IApplicationListWL appWL = applicationService.getTodaysApps(officeId.trim(), group);
		appDTO.setErrorCode(appWL.getErrorCode());
		List<Applicant> applicantList = new ArrayList<Applicant>();
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<IApplication> appList = appWL.getApplicationList();
			ISessionListWL sessWL = sessionService.getCurrentSessions(officeId);
			if(sessWL.getErrorCode() == ErrorCode.NO_ERROR){
				HashSet<Integer> notInQueue = new HashSet<Integer>();
				for(ISession sess: sessWL.getSessionList()){
					notInQueue.add(sess.getApplicationId());
					if(sess.getSessionStatusCode().trim().equalsIgnoreCase(Constant.SESSION_RESERVED) && Constant.hasEndedLongEnough3(sess.getSessionStartTime(),getReservedTimeout())) {
						IErrorWL errWL = sessionService.endSession(sess.getSessionId());
						if(errWL.getErrorCode() != ErrorCode.NO_ERROR){
							appDTO.setErrorCode(errWL.getErrorCode());
							break;
						}	
						notInQueue.remove(sess.getApplicationId());			
					}						
				}			
				
				for(IApplication app: appList) {
					if(!notInQueue.contains(app.getApplicationId())){
						IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
						appDTO.setErrorCode(vaultWL.getErrorCode());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							Applicant apt = new Applicant();
							apt.setDlNumber(vault.getDlNumber());
							apt.setLastName(vault.getApplicationLastName());
							apt.setFirstName(vault.getApplicationFirstName());
							apt.setApplicationId(app.getApplicationId());
							applicantList.add(apt);
						}
					}
				}
			}
			else if(sessWL.getErrorCode() == ErrorCode.MISSING_SESSION){
				for(IApplication app: appList) {
					IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
					appDTO.setErrorCode(vaultWL.getErrorCode());
					if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IVault vault = vaultWL.getVault();
						Applicant apt = new Applicant();
						apt.setDlNumber(vault.getDlNumber());
						apt.setLastName(vault.getApplicationLastName());
						apt.setFirstName(vault.getApplicationFirstName());
						apt.setApplicationId(app.getApplicationId());
						applicantList.add(apt);
					}
				}
			}
			else{				
				appDTO.setErrorCode(sessWL.getErrorCode());
			}
		}
		appDTO.setApplicantList(applicantList);
	}

	/*
	 * This method is called to assign a terminal to the applicant by creating a session
	 */
	public void assignTerminal(ApplicantDTO applicantDTO) {
		int appId = applicantDTO.getApplicantList().get(Constant.FIRST_ELEMENT).getApplicationId();
		String wid = applicantDTO.getApplicantList().get(Constant.FIRST_ELEMENT).getWorkstationId();
		String officeId = applicantDTO.getApplicantList().get(Constant.FIRST_ELEMENT).getOfficeId();
		
		IApplicationWL appWL = applicationService.getApplication(appId);
		applicantDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IApplication app = appWL.getApplication();
			Date date = new Date();
			ISession session = new Session();
			session.setApplicationId(appId);
			session.setLanguageCode(Constant.SINGLE_SPACE);
			session.setLastModUsername(getUserId());
			session.setLastModUserTime(date);
			session.setOfficeId(officeId);
			session.setSessionEndTime(Constant.defaultDate);
			session.setSessionStartTime(date);
			session.setVaultId(app.getVaultId());
			IWorkstationMapListWL wmWL = sessionService.getWorkstationMapByStationIdAndOfficeId(wid, officeId); //TODO use seeded data
			applicantDTO.setErrorCode(wmWL.getErrorCode());
			if(wmWL.getErrorCode() == ErrorCode.NO_ERROR) {
				session.setWorkstationIPAddress(wmWL.getWorkstationMapList().get(Constant.FIRST_ELEMENT).getWorkstationIPAddress());
				session.setYobOverrideTime(Constant.defaultDate);
				session.setYobValidationFlag(Constant.NO);
				session.setSessionStatusCode(Constant.SESSION_RESERVED);
				
				IBooleanWL boolWL = sessionService.isTerminalUsedInSession(session.getWorkstationIPAddress(),officeId);
				applicantDTO.setErrorCode(boolWL.getErrorCode());
				if(boolWL.getErrorCode() == ErrorCode.NO_ERROR){
					if(!boolWL.isFlag()){
						ISessionWL sessWL = sessionService.createSession(session);
						applicantDTO.setErrorCode(sessWL.getErrorCode());
						if (sessWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IErrorWL errorWL = auditService.saveAudit(Constant.MANUALLY_ASSIGNED, Constant.SINGLE_SPACE, Constant.SINGLE_SPACE, 
									Constant.SINGLE_SPACE, String.valueOf(app.getApplicationId()), getUserId());
							applicantDTO.setErrorCode(errorWL.getErrorCode());
						} 						
					}
					else{
						applicantDTO.setErrorCode(ErrorCode.MISSING_WORKSTATION); //TODO change to unavailable
					}
				}
			}			
		}
	}

	/*
	 * This method is called to validate that workstation and group match with each other
	 */	
	public boolean isGroupValid(String officeId, String group){
		boolean validGroup = false;
		String offcieType = "";
		if (group.equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			offcieType = Constant.OFFICE_TYPE_DS;
		}
		else if (group.equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			offcieType = Constant.OFFICE_TYPE_OL;	
		}
		else if (group.equalsIgnoreCase(Constant.FO_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.FO_USER_GROUP)){
			offcieType = Constant.OFFICE_TYPE_FO;
		}
		else if (group.equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.equalsIgnoreCase(Constant.CHP_USER_GROUP)){
			offcieType = Constant.OFFICE_TYPE_CHP;
		}
		String officeTypeBasedOnOfficeId = examSeedData.getOfficeTypeByOfficeId(officeId);
		if(officeTypeBasedOnOfficeId.trim().equals(offcieType.trim())){
			validGroup = true;
		}
		return validGroup;
	}
	/*
	 * This method is called to search by DL# or Last name based on the request type
	 */
	public void search(ApplicantDTO appDTO) {
		Search search = appDTO.getSearchListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		IApplicantListWL appWL = searchService.search(search);
		appDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Applicant> appList = appWL.getApplicantList();
			List<Applicant> appList2 = new ArrayList<Applicant>();
			if(search.getRequestType() == SearchRequestTypeConstant.TEST_STATUS){
				searchAllExams(appWL, appList2, search.getOfficeId(),getAppTypeBasedOnGroup(search.getGroup()));
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.VIEW_ACITVE_SESSIONS){
				searchActiveSessions(appWL, appList2, search.getOfficeId(),getAppTypeBasedOnGroup(search.getGroup()),appDTO);
			}
			else if(search.getRequestType() == SearchRequestTypeConstant.EOD_REPORT){
				searchEndOfDayReport(appWL, appList2, search.getOfficeId(),getAppTypeBasedOnGroup(search.getGroup()),appDTO);
			}
			else{
				for(gov.ca.dmv.AKT.integration.BeansImpl.Applicant app: appList) {
					Applicant app2 = new Applicant();
					app2.setApplicationId(app.getApplicationId());
					app2.setDlNumber(app.getDlNumber());
					app2.setExamId(app.getExamId());
					app2.setExamType(app.getExamType());
					app2.setFirstName(app.getFirstName());
					app2.setIpAddress(app.getIpAddress());
					app2.setLastName(app.getLastName());
					app2.setOfficeId(app.getOfficeId());
					app2.setResult(app.getResult());
					app2.setSessionId(app.getSessionId());
					app2.setWorkstationId(app.getWorkstationId());
					app2.setExamStartDate(app.getExamStartDate());
					app2.setIncorrect(app.getIncorrect());
					if(app.getExamEndDateAndTime() != null) {
						app2.setExamEndDate(new SimpleDateFormat("yyyy-MM-dd").format(app.getExamEndDateAndTime()));
						app2.setExamEndTime(new SimpleDateFormat("hh:mm:ss").format(app.getExamEndDateAndTime()));
					}
					appList2.add(app2);
				}
			}
			appDTO.setApplicantList(appList2);
		}
		else 
			appDTO.setErrorCode(appWL.getErrorCode());
	}
	
	public void searchEndOfDayReport(IApplicantListWL appWL, List<Applicant> appList2, String officeId, String appType, ApplicantDTO appDTO){
		appDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExamListWL elWL = examService.getIncompleteExams(officeId, appType);
		if(elWL.getErrorCode() == ErrorCode.NO_ERROR || elWL.getErrorCode() == ErrorCode.MISSING_EXAMS) {
			if(elWL.getErrorCode() != ErrorCode.MISSING_EXAMS) {
				List<IExam> incompleteExamList = elWL.getExamList();
				for(IExam exam: incompleteExamList) {
					IApplicationWL applWL = applicationService.getApplication(exam.getApplicationId());
					if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IApplication app = applWL.getApplication();
						IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							ITestWL testWL = testService.getTest(exam.getTestId());
							if(testWL.getErrorCode() == ErrorCode.NO_ERROR) {
								Test test = testWL.getTest();
								Applicant applicant = new Applicant();
								applicant.setDlNumber(vault.getDlNumber());
								applicant.setExamId(exam.getExamId());
								applicant.setExamType(test.getTestName());
								applicant.setFirstName(vault.getApplicationFirstName());
								applicant.setLastName(vault.getApplicationLastName());
								
								String result;
								if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PAUSE))
									result = "Paused";
								else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.TIME_OUT))
									result = "Timed Out";
								else
									result = "Incomplete";
								
								if (exam.getSessionId() > 0) {
									ISessionWL sessionWL = sessionService.getSessionBySessionId(exam.getSessionId());
									if(sessionWL.getErrorCode() == ErrorCode.NO_ERROR) {
										ISession session =  sessionWL.getSession();
										IStringWL strWL = sessionService.getWorkstationId(session.getWorkstationIPAddress());
										applicant.setWorkstationId(strWL.getString());
									}
								}
								else {
									result = "Manually Test";
								}
								applicant.setResult(result);
								if(appDTO.getSearchList().get(Constant.ZERO).getLastName().equals("")) {
									if(appDTO.getSearchList().get(Constant.ZERO).getDl().equals(applicant.getDlNumber())) 
										appList2.add(applicant);}
								else  
									if(applicant.getLastName().toLowerCase().contains(appDTO.getSearchList().get(Constant.ZERO).getLastName().toLowerCase()))
										appList2.add(applicant);
								else
									appDTO.setErrorCode(testWL.getErrorCode());
							}
							else {
								appDTO.setErrorCode(testWL.getErrorCode());
							}
						}
						else {
							appDTO.setErrorCode(vaultWL.getErrorCode());
						}
					}
					else {
						appDTO.setErrorCode(appWL.getErrorCode());
					}
				}
				appDTO.setApplicantList(appList2);
			}
		}
		else {
			appDTO.setErrorCode(elWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get a list of all ActiveSessions
	 */
	public void searchActiveSessions(IApplicantListWL appWL, List<Applicant> appList2, String officeId, String appType, ApplicantDTO applicantDTO) {
		boolean hasDl = false;
		IActiveSessionAndExamListWL  asessEL= sessionService.getActiveExams(officeId, appType);
		if(!applicantDTO.getSearchList().get(Constant.ZERO).getDl().equals(Constant.NULL_STRING)) {
			hasDl = true;
		}
		if(asessEL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ActiveSessionAndExam> activeList = asessEL.getActiveSessionAndExamList();
			List<Applicant> applicantList = new ArrayList<Applicant>();
			if (activeList != null)
			{
				for(ActiveSessionAndExam active: activeList) {
					IExam exam = active.getExam();
					ISession session = active.getSession();
					IStringWL strWL = sessionService.getWorkstationId(session.getWorkstationIPAddress());
					if(strWL.getErrorCode() == ErrorCode.NO_ERROR) {
						String workstationId = strWL.getString(); 
						IVaultWL vaultWL = applicationService.getVault(session.getVaultId());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							/*
							 * In the bellow if we split the condition into two parts using or
							 * 1. Will be true when it has the same DL number which the user entered 
							 * 2. This will be true when the last name field is in the vault Application Last Name and the last name field is not empty and user didn't enter the DL Number.
							 */
							if ( applicantDTO.getSearchList().get(Constant.ZERO).getDl().equals(vault.getDlNumber()) || 
									(vault.getApplicationLastName().trim().toLowerCase().contains(applicantDTO.getSearchList().get(Constant.ZERO).getLastName().trim().toLowerCase()) && 
											!applicantDTO.getSearchList().get(Constant.ZERO).getLastName().trim().equals(Constant.NULL_STRING) && 
											!hasDl)) {
								if(exam!=null){
									ITestWL testWL = applicationService.getTest(exam.getTestId().trim());
									if(testWL.getErrorCode() == ErrorCode.NO_ERROR){
										
											gov.ca.dmv.AKT.integration.BeansImpl.Test test = testWL.getTest();		
											Applicant applicant = new Applicant();
											applicant.setDlNumber(vault.getDlNumber());
											applicant.setExamType(test.getTestName());
											applicant.setFirstName(vault.getApplicationFirstName());
											applicant.setLastName(vault.getApplicationLastName());
											applicant.setWorkstationId(workstationId);
											applicant.setSessionId(session.getSessionId());
											applicant.setExamId(exam.getExamId());
											applicantList.add(applicant);
											appList2.add(applicant);
									}
									else {
										applicantDTO.setErrorCode(testWL.getErrorCode());
									}
								}
								else{
									Applicant applicant = new Applicant();
									applicant.setDlNumber(vault.getDlNumber());
									applicant.setExamType(Constant.EXAM_ABSENT);
									applicant.setFirstName(vault.getApplicationFirstName());
									applicant.setLastName(vault.getApplicationLastName());
									applicant.setWorkstationId(workstationId);
									applicant.setSessionId(session.getSessionId());
									applicant.setExamId(Constant.ZERO);
									applicantList.add(applicant);
									appList2.add(applicant);
								}
							}
						}
						else {
							applicantDTO.setErrorCode(vaultWL.getErrorCode());
						}
					}
					else {
						applicantDTO.setErrorCode(strWL.getErrorCode());
					}
				}
				applicantDTO.setApplicantList(appList2);
			}
		}
		else if(asessEL.getErrorCode() != ErrorCode.MISSING_SESSION &&
				asessEL.getErrorCode() != ErrorCode.MISSING_EXAMS){
			applicantDTO.setErrorCode(asessEL.getErrorCode());
		}
	}
	/*
	 * This method is called to get a list of all exams
	 */
	public void searchAllExams(IApplicantListWL appWL, List<Applicant> appList2, String officeId, String appType) {
		appWL.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Applicant> appList = appWL.getApplicantList();
		
		if(appList.size()>0){
			HashMap<Integer,gov.ca.dmv.AKT.integration.BeansImpl.Applicant> applMap = new HashMap<Integer,gov.ca.dmv.AKT.integration.BeansImpl.Applicant>();
			for(gov.ca.dmv.AKT.integration.BeansImpl.Applicant app: appList){
				applMap.put(app.getApplicationId(),app);
			}	
			
			IExamListWL examListWL = examService.getAllExamsByOfficeId(officeId,appType);
			if(examListWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<IExam> examList = new ArrayList<IExam>();
				for(IExam exam: examListWL.getExamList()){
					if(applMap.containsKey(exam.getApplicationId())){
						examList.add(exam);
					}
				}			
				
				ISessionListWL sessionListWL = sessionService.getAllSessionsByOfficeId(officeId, appType);
				if(sessionListWL.getErrorCode() == ErrorCode.NO_ERROR){
					HashMap<Integer,ISession> sessMap = new HashMap<Integer,ISession>();
					for(ISession sess: sessionListWL.getSessionList()){
						if(applMap.containsKey(sess.getApplicationId())){
							sessMap.put(sess.getSessionId(),sess);
						}
					}
					sessMap.put(0,null);
					
					IActiveSessionAndExamListWL aseWL = sessionService.getExams(officeId, appType);
					if(aseWL.getErrorCode() == ErrorCode.NO_ERROR){
						HashSet<Integer> disconnectedSess = new HashSet<Integer>();
						for(ActiveSessionAndExam discon: aseWL.getActiveSessionAndExamList()){
							if(applMap.containsKey(discon.getSession().getApplicationId())){
								disconnectedSess.add(discon.getExam().getExamId());
							}
						}

						for(IExam exam: examList){
							gov.ca.dmv.AKT.integration.BeansImpl.Applicant app2 = applMap.get(exam.getApplicationId());
							Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
							ISession sess = sessMap.get(exam.getSessionId());
							
							Applicant applicant = new Applicant();
							applicant.setDlNumber(app2.getDlNumber());
							applicant.setExamType(test.getTestName());
							applicant.setFirstName(app2.getFirstName());
							applicant.setLastName(app2.getLastName());
							applicant.setExamId(exam.getExamId());
							
							setTerminalAndStatus(applicant,exam,sess,disconnectedSess.contains(exam.getExamId()));							
							appList2.add(applicant);
						}
					}
					else{
						appWL.setErrorCode(aseWL.getErrorCode());
					}
				}
				else{
					appWL.setErrorCode(sessionListWL.getErrorCode());
				}					
			}
			else{
				appWL.setErrorCode(examListWL.getErrorCode());
			}
		}
	}
	
	
	/*
	 * This method is called to get the print test queue.
	 */
	public void getPrintTestQueue(ApplicantDTO appDTO) {
		String officeId = appDTO.getApplicantList().get(Constant.FIRST_ELEMENT).getOfficeId();
		String group = appDTO.getGroup();
		IApplicationListWL appWL = applicationService.getTodaysApps(officeId, group);
		List<Applicant> appList = new ArrayList<Applicant>();
		appDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<IApplication> applicationList = appWL.getApplicationList();
			for(IApplication app: applicationList) {
				IBooleanWL boolWL = examService.hasExamsToTake(app.getApplicationId());
				appDTO.setErrorCode(boolWL.getErrorCode());
				if(boolWL.getErrorCode() == ErrorCode.NO_ERROR) {
					if(boolWL.isFlag()) {
						IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
						appDTO.setErrorCode(vaultWL.getErrorCode());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							Applicant appl = new Applicant();
							appl.setDlNumber(vault.getDlNumber());
							appl.setFirstName(vault.getApplicationFirstName());
							appl.setLastName(vault.getApplicationLastName());
							appl.setApplicationId(app.getApplicationId());
							appList.add(appl);
						}
					}
				}
			}
		}
		appDTO.setApplicantList(appList);
	}

	/*
	 * This method is called to get the list of available tests for print based on the DL #. 
	 */
	public void getAvailableTestsForPrint(ExamDTO examDTO) {
		String dl = examDTO.getVault().getDlNumber();
		IVaultWL vaultWL = applicationService.getVaultByDL(dl);
		examDTO.setErrorCode(vaultWL.getErrorCode());
		if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IVault vault = vaultWL.getVault();
			examDTO.setVaultAfterPreTierConversion(vault);
			IApplicationWL appWL = applicationService.getApplicationByVaultId(vault.getVaultId());
			examDTO.setErrorCode(appWL.getErrorCode());
			if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IApplication app = appWL.getApplication();
				IExamListWL examWL = examService.getExamsToTake(app.getApplicationId());
				examDTO.setErrorCode(examWL.getErrorCode());
				if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
					List<IExam> examList = examWL.getExamList();
					List<ExamTestLang> examTestLangList = new ArrayList<ExamTestLang>();
					for(IExam exam: examList) {
						Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
						ExamTestLang examTestLang = new ExamTestLang();
						examTestLang.setExamId(exam.getExamId());
						examTestLang.setTestLangName(test.getTestName());
						examTestLang.setPrintChecked(false);
						examTestLang.setDisabled(false);
						examTestLang.setPrintReprintValue(Constant.PRINT);
						if(examDTO.getPrintStatus().equalsIgnoreCase(Constant.PRINT_TEST_STATUS)) {
							List<Lang> langList = new ArrayList<Lang>();
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
								List<TestLang> tlList = examSeedData.getTestLangListByTestId(exam.getTestId());
								for(TestLang tl: tlList) {
									if(!(tl.getTlPrimaryKey().getTestId().trim().equalsIgnoreCase(Constant.SIGN_TEST_ID) && tl.getLangId().trim().equalsIgnoreCase(Constant.DEFAULT_LANG))) {
										Lang lang = examSeedData.getLangByLangId(tl.getLangId());
										langList.add(lang);
									}
								}
							}
							else {
								Lang lang = examSeedData.getLangByLangId(exam.getLangId().trim());
								langList.add(lang);
								if(!exam.getCompletionReasonCode().equalsIgnoreCase(Constant.VIEW_TEST_STATUS))
									examTestLang.setPrintReprintValue(Constant.REPRINT);
							}
							examDTO.setLangListAfterPreTierConversion(langList);
							examTestLang.setLangList(examDTO.getLangList());
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS) || exam.getCompletionReasonCode().equalsIgnoreCase(Constant.REPRINT_ANSWER_KEY_STATUS) || exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								examTestLang.setDisabled(true);
							}
						}
						else if(examDTO.getPrintStatus().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS)) {
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.SINGLE_SPACE) || exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								examTestLang.setDisabled(true);
							}
							else {
								examTestLang.setLangId(exam.getLangId());
								examTestLang.setLanguage(examSeedData.getLangByLangId(exam.getLangId()).getLangName());
							}
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS) || exam.getCompletionReasonCode().equalsIgnoreCase(Constant.REPRINT_ANSWER_KEY_STATUS) || exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								examTestLang.setPrintReprintValue(Constant.REPRINT);
							}
						}						
						examTestLangList.add(examTestLang);
					}
					examDTO.setExamTestLangList(examTestLangList);
				}
			}
		}
	}
	
	/*
	 * This method is called to get a list of tests available for updating the score based on the DL#.
	 */
	public void getTestsToUpdateScore(ExamDTO examDTO) {
		String dl = examDTO.getVault().getDlNumber();
		IVaultWL vaultWL = applicationService.getVaultByDL(dl);
		examDTO.setErrorCode(vaultWL.getErrorCode());
		if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IVault vault = vaultWL.getVault();
			examDTO.setVaultAfterPreTierConversion(vault);
			IApplicationWL appWL = applicationService.getApplicationByVaultId(vault.getVaultId());
			examDTO.setErrorCode(appWL.getErrorCode());
			if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IApplication app = appWL.getApplication();
				IExamListWL examWL = examService.getExamsToTake(app.getApplicationId());
				examDTO.setErrorCode(examWL.getErrorCode());
				if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
					List<IExam> examList = examWL.getExamList();
					List<ExamTestLang> examTestLangList = new ArrayList<ExamTestLang>();
					for(IExam exam: examList) {
						Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
						ExamTestLang examTestLang = new ExamTestLang();
						examTestLang.setExamId(exam.getExamId());
						examTestLang.setTestLangName(test.getTestName());
						examTestLang.setSecondaryVerification(exam.getSecondaryVerificationId());
						examTestLang.setScore(null);
						// set the maximum number to limit the "number failed" on the updateScoreBody.jsp
//						examTestLang.setExamQuesNbr(exam.getExamQuestionNumber());
						if(!exam.getIncorrectAnswerCount().equals(Constant.ZERO)) {
							examTestLang.setScore(exam.getIncorrectAnswerCount());
						}
						examTestLang.setCompleted(false);
						if(!exam.getPassFailIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
							examTestLang.setCompleted(true);
							examTestLang.setScore(exam.getIncorrectAnswerCount());
							examTestLang.setResult("Fail");
							if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.PASS)) {
								examTestLang.setResult("Pass");
							}
						}
						examTestLang.setDisabled(false);
						if(!exam.getPassFailIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE) || (!exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS) && !exam.getCompletionReasonCode().equalsIgnoreCase(Constant.REPRINT_ANSWER_KEY_STATUS))) {
							examTestLang.setDisabled(true);
						}
						examTestLang.setCdl(false);
						if(exam.getCdlFlag().equalsIgnoreCase(Constant.YES)) {
							examTestLang.setCdl(true);
						}
						examTestLang.setPassword(Constant.PASSWORD_HINT);
						examTestLang.setUsername(Constant.USERID_HINT);
						examTestLangList.add(examTestLang);
					}
					examDTO.setExamTestLangList(examTestLangList);
				}
			}
		}
	}
	
	/*
	 * This method is called to update the scores of the manually printed tests.
	 */
	public void updateScore(ExamDTO examDTO, String group, FOUserController foCallback) {
		List<ExamTestLang> updatedList = examDTO.getExamTestLangList();
		List<IExam> examList = new ArrayList<IExam>();
		
		// Process each Exam object
		
		for(ExamTestLang etl: updatedList) {
			
			// verify exam id is valid
			IExamWL exWL = examService.getExamByExamId(etl.getExamId());
			examDTO.setErrorCode(exWL.getErrorCode());
			if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
				
				// Copy Presentation Exam to Integration Exam
				IExam exam = exWL.getExam();
				String auditOldStatus = exam.getCompletionReasonCode();
				exam.setCompletionReasonCode(Constant.PRINT_UPDATE_SCORE_STATUS);
				exam.setIncorrectAnswerCount(etl.getScore());
				exam.setLastModUsername(getUserId());
				exam.setLastModUserTime(new Date());
				exam.setPassFailIndicator(Constant.PASS);
				exam.setExamEndTime(new Date());
				
				if(etl.getScore() > exam.getMaxIncorrectNumber()) {
					exam.setPassFailIndicator(Constant.FAIL);
				}
				if(exam.getCdlFlag().equalsIgnoreCase(Constant.YES)) {
					if (etl.getUsername() == null || etl.getUsername().isEmpty()) {
						examDTO.setErrorCode(ErrorCode.MISSING_CREDENTIALS);
						//return;
						break;
					}
					else {
						IBooleanWL boolWL = securityService.authenticate(etl.getUsername(), etl.getPassword(), examDTO.getUserId());
						examDTO.setErrorCode(boolWL.getErrorCode());
						if(boolWL.getErrorCode() == ErrorCode.NO_ERROR) {
							if(boolWL.isFlag()) {
								exam.setSecondaryVerificationId(etl.getUsername());
								updateDatabaseAndEase(examDTO, examList, exam, auditOldStatus, foCallback, group);
//								IErrorWL errWL = examService.updateExam(exam);
//								examDTO.setErrorCode(errWL.getErrorCode());
////								if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
////									examList.add(exam);
////								}
//								examList.add(exam);
//								IErrorWL errWL = examService.updateExam(exam);
//								examDTO.setErrorCode(errWL.getErrorCode());
//								if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
//									IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, auditOldStatus, Constant.PRINT_UPDATE_SCORE_STATUS, String.valueOf(exam.getExamId()), examDTO.getUserId());
//									if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
//										if(examDTO.getApplicationType() == null && exam.getPassFailIndicator().equalsIgnoreCase(Constant.FAIL)) {
//											IErrorWL erWL = updateExamHistAndCloneStub(exam);
//											examDTO.setErrorCode(erWL.getErrorCode());
//										}
//										examList.add(exam);
//									}
//								}
							}
							else {
								examDTO.setErrorCode(ErrorCode.INCORRECT_CREDENTIALS);
								//return;
								break;
							}
						}
					}					
				}
				else {
					updateDatabaseAndEase(examDTO, examList, exam, auditOldStatus, foCallback, group);
//					IErrorWL errWL = examService.updateExam(exam);
//					examDTO.setErrorCode(errWL.getErrorCode());
//					if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
//						IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, auditOldStatus, Constant.PRINT_UPDATE_SCORE_STATUS, String.valueOf(exam.getExamId()), examDTO.getUserId());
//						if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
//							if(examDTO.getApplicationType() == null && exam.getPassFailIndicator().equalsIgnoreCase(Constant.FAIL)) {
//								IErrorWL erWL = updateExamHistAndCloneStub(exam);
//								examDTO.setErrorCode(erWL.getErrorCode());
//							}
//							examList.add(exam);
//						}
//					}
				}
			}
		}
		examDTO.setExamListAfterPreTierConversion(examList);
	}
	
	/*
	 * Helper function to update the database and send jms message back to EASE
	 */
	private void updateDatabaseAndEase(ExamDTO examDTO, List<IExam> examList, IExam exam, String auditOldStatus,FOUserController foCallback, String group) {
		IErrorWL errWL = examService.updateExam(exam);
		examDTO.setErrorCode(errWL.getErrorCode());
		if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, auditOldStatus, Constant.PRINT_UPDATE_SCORE_STATUS, String.valueOf(exam.getExamId()), examDTO.getUserId());
			if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
				if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.FAIL)) {
					IErrorWL erWL = updateExamHistAndCloneStub(exam);
					examDTO.setErrorCode(erWL.getErrorCode());
				}
				examList.add(exam);
				foCallback.sendExamInfoToEase(examDTO, copyIntObjToPresObj(exam), group);
			}
		}
	}
	
	/*
	 * Need this "copy" function because the two Exam objects (Integration and Presentation).  
	 * Calling a callback function that requires a presentation Exam object
	 */
	private gov.ca.dmv.AKT.presentation.Beans.Exam copyIntObjToPresObj(gov.ca.dmv.AKT.integration.BeansImpl.IExam exam) {
		gov.ca.dmv.AKT.presentation.Beans.Exam exam2 = new gov.ca.dmv.AKT.presentation.Beans.Exam();
		exam2.setApplicationId(exam.getApplicationId());
		exam2.setCdlFlag(exam.getCdlFlag());
		exam2.setCompletionReasonCode(exam.getCompletionReasonCode());
		exam2.setCorrectQuestionCount(exam.getCorrectQuestionCount());
		exam2.setEaseTestId(exam.getEaseTestId());
		exam2.setEaseTimestamp(exam.getEaseTimestamp());
		exam2.setExamEndTime(exam.getExamEndTime());
		exam2.setExamId(exam.getExamId());
		exam2.setExamOrder(exam.getExamOrder());
		exam2.setExamQuestionNumber(exam.getExamQuestionNumber());
		exam2.setExamStartTime(exam.getExamStartTime());
		exam2.setIncorrectAnswerCount(exam.getIncorrectAnswerCount());
		exam2.setLastModUsername(exam.getLastModUsername());
		exam2.setLastModUserTime(exam.getLastModUserTime());
		exam2.setMaxIncorrectNumber(exam.getMaxIncorrectNumber());
		exam2.setOfficeId(exam.getOfficeId());
		exam2.setPassFailIndicator(exam.getPassFailIndicator());
		exam2.setQuestionAnsweredCount(exam.getQuestionAnsweredCount());
		exam2.setSessionId(exam.getSessionId());
		exam2.setTestId(exam.getTestId());
		exam2.setQuickPassFailFlag(exam.getQuickPassFailFlag());
		exam2.setTestTypeCode(exam.getTestTypeCode());
		exam2.setLangId(exam.getLangId());
		exam2.setOptionalTestInd(exam.getOptionalTestInd());
		exam2.setSignTestFlag(exam.getSignTestFlag());
		exam2.setSecondaryVerificationId(exam.getSecondaryVerificationId());
		return exam2;
	}
	
	private IErrorWL updateExamHistAndCloneStub(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		IApplicationWL appWL = applicationService.getApplication(exam.getApplicationId());
		errWL.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IApplication application = appWL.getApplication();
			IExamHistory examHistory = new ExamHistory();
			examHistory.setApplicationId(exam.getApplicationId());
			examHistory.setEaseTestId(exam.getEaseTestId());
			IExamHistoryWL ehWL = applicationService.getExamHistory(examHistory);
			errWL.setErrorCode(ehWL.getErrorCode());
			if(ehWL.getErrorCode() == ErrorCode.NO_ERROR) {
				examHistory = ehWL.getExamHistory();
				int aktStatusIndicator = Constant.ZERO;
				int easeStatusIndicator = Constant.ZERO;
				if(!examHistory.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE))
					aktStatusIndicator = Integer.parseInt(examHistory.getAktStatusIndicator());
				if(!examHistory.getEaseStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE))
					easeStatusIndicator = Integer.parseInt(examHistory.getEaseStatusIndicator());
				aktStatusIndicator++;
				examHistory.setAktStatusIndicator(String.valueOf(aktStatusIndicator));
				examHistory.setLastModusername(getUserId());
				examHistory.setLastModUserTime(new Date());
				examHistory.setAktUpdatedTimestamp(new Date());
				IErrorWL erWL = applicationService.updateExamHistory(examHistory);
				errWL.setErrorCode(erWL.getErrorCode());
				if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
					if(aktStatusIndicator + easeStatusIndicator < 3 && 
					   !application.getApplicationStatusCode().equalsIgnoreCase(Constant.PROVISIONAL) && 
					   !application.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_CHP)){
						
						IErrorWL eWL = examService.cloneStubExam(exam);
						errWL.setErrorCode(eWL.getErrorCode());
					}
					// We don't remove any finished test according to requirements.  
//					else if(!application.getApplicationStatusCode().equalsIgnoreCase(Constant.PROVISIONAL)){
//						IExamListWL examsWL = examService.loadExams(application.getApplicationId());
//						errWL.setErrorCode(examsWL.getErrorCode());
//						if(examsWL.getErrorCode() == ErrorCode.NO_ERROR) {
//							//TODO Adheesh. To be revisited later. This is the code that deletes exams when failed 3 times from printed tests.
//							for(IExam exam1: examsWL.getExamList()) {
//								IErrorWL errrWL = examService.removeStub(exam1);
//								errWL.setErrorCode(errrWL.getErrorCode());
//								if(errrWL.getErrorCode() != ErrorCode.NO_ERROR) {
//									break;
//								}
//							}
//						}
//					}
				}
			}
		}
		return errWL;
	}

	
	
	/*
	 * This method is called to get the list of finished tests for print based on the DL #. 
	 */
	public void getFinishedTestsForPrint(ExamDTO examDTO, String appType) {
		String dl = examDTO.getVault().getDlNumber();
		String lastName = examDTO.getVault().getApplicationLastName();
		IVaultWL vaultWL = applicationService.getVaultByDLOrLastName(dl,lastName);
		examDTO.setErrorCode(vaultWL.getErrorCode());
		if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IVault vault = vaultWL.getVault();
			examDTO.setVaultAfterPreTierConversion(vault);
			IApplicationWL appWL = applicationService.getApplicationByVaultIdAndOfficeId(vault.getVaultId(),examDTO.getOfficeId());
			examDTO.setErrorCode(appWL.getErrorCode());
			if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IApplication app = appWL.getApplication();
				if (app.getApplicationType() == null) {
					return;
				}
				IExamListWL examWL = examService.getCompletedExamsByAppId(app.getApplicationId());
				examDTO.setErrorCode(examWL.getErrorCode());
				if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
					List<IExam> examList = examWL.getExamList();
					List<ExamTestLang> examTestLangList = new ArrayList<ExamTestLang>();
					for(IExam exam: examList) {
						Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
						ExamTestLang examTestLang = new ExamTestLang();
						examTestLang.setExamId(exam.getExamId());
						examTestLang.setExamEndTime(exam.getExamEndTime());
						examTestLang.setTestLangName(test.getTestName());
						examTestLang.setTestId(test.getTestId().trim());
						examTestLang.setPrintChecked(false);
						examTestLang.setDisabled(false);
						examTestLang.setPrintReprintValue(Constant.PRINT);
						examTestLang.setLangId(exam.getLangId());
						examTestLang.setLanguage(examSeedData.getLangByLangId(exam.getLangId()).getLangName());						
						
						examTestLangList.add(examTestLang);
					}
					examDTO.setExamTestLangList(examTestLangList);
				}
			}
		}
	}
	
	/*
	 * This method is called to get the answer key based on the exam id.
	 */
	public void getAnswerKey(ExamDTO examDTO) {
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		String langId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLangId();
		IExamQuestionListWL eqWL = examService.getExamQues(examId);
		examDTO.setErrorCode(eqWL.getErrorCode());
		List<gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw> quesAnswList = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw>();
		if(eqWL.getErrorCode() == ErrorCode.NO_ERROR) {
			for(IExamQuestion eq: eqWL.getExamQuestionList()) {
				List<IExamAnswer> examAnsOrderedList = examService.getExamAnswByExamIdAndQuesGenIdOrderByAnswPresOrd(eq);
				gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw quesAnsw = new gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw();
				List<Answer> answerListOrdered = new ArrayList<Answer>();
				for (IExamAnswer ea : examAnsOrderedList) {
					QuestionLang quesLang = examSeedData.getQuestionLangByQuesGenId(eq.getQuestionGenId());
					quesAnsw.setQuestionLang(quesLang);
					quesAnsw.setHandbookRef(examSeedData.getHandbookRefByHandbookRefAndLangId(quesLang.getHandbookRef(), quesLang.getLangId()));
					//reset the order of the answers based on the examAnsOrderedList
					List<Answer> answerListUnordered = examSeedData.getAnswersByQuesGenId(eq.getQuestionGenId());
					for (Answer an : answerListUnordered) {
						if (an.getAnswerGenId().intValue() == ea.getEaPrimaryKey().getAnswerId().intValue()) {
							answerListOrdered.add(an);
							break;
						}
					}
				}
				quesAnsw.setAnswerList(answerListOrdered);
				quesAnswList.add(quesAnsw);
			}
			
			IExamWL examWL = examService.getExamByExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
			examDTO.setErrorCode(examWL.getErrorCode());
			if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExam exam = examWL.getExam();
				examDTO.setTestId(exam.getTestId().trim());
				String oldStatus = exam.getCompletionReasonCode().trim();
				String newStatus = Constant.VIEW_ANSWER_KEY_STATUS;
				if(oldStatus.equalsIgnoreCase(Constant.PRINT_TEST_STATUS) || oldStatus.equalsIgnoreCase(Constant.REPRINT_TEST_STATUS)) {
					exam.setCompletionReasonCode(newStatus);
					exam.setLastModUsername(getUserId());
					exam.setLastModUserTime(new Date());
					IErrorWL erWL = examService.updateExam(exam);
					examDTO.setErrorCode(erWL.getErrorCode());
					if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IErrorWL errWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, oldStatus, newStatus, String.valueOf(exam.getExamId()), examDTO.getUserId());
						examDTO.setErrorCode(errWL.getErrorCode());
					}
				}
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					TestLang tl = new TestLang();
					tl.getTlPrimaryKey().setTestId(exam.getTestId());
					tl.setLangId(langId);
					tl = examSeedData.getTestLangByTestIdLangId(tl);
					examDTO.setTestName(tl.getTestLangName());
					examDTO.setMaxIncorrect(exam.getMaxIncorrectNumber());
				}
			}
		}
		examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
	}

	/*
	 * This method is called to get all the tests needed (based on the group) for displaying the enter applicant information page.
	 */
	public void getAppInfo(TestDTO testDTO) {
		testDTO.setErrorCode(ErrorCode.NO_ERROR);
		String group = testDTO.getGroup();
		testDTO.setTestListAfterPreTierConversion(examSeedData.getTestsBasedOnGroup(group));
	}

	/*
	 * This method is called to persist the DS/OL applicant information in the vault, application, exam and exam history tables.
	 */
	public void submitAppInfo(ApplicantDTO appDTO, List<gov.ca.dmv.AKT.presentation.Beans.ExamHistory> examHistList) {
		Applicant appt = appDTO.getApplicantList().get(Constant.FIRST_ELEMENT);
		String group = appDTO.getGroup();
		String officeId = appDTO.getOfficeId();
		String techId = appDTO.getTechId();
		Date date = new Date();
		IVault vault = createVaultForAppInfo(appt, date);
		IErrorWL errWL = applicationService.saveVault(vault);
		appDTO.setErrorCode(errWL.getErrorCode());
		if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IApplication app = createAppForAppInfo(group, officeId, techId, date, vault, appt);
			IErrorWL errorWL = applicationService.saveApplication(app);
			appDTO.setErrorCode(errorWL.getErrorCode());
			if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
				createExamsForAppInfo(appt, officeId, date, app);
				List<IExam> examList = createExamsForAppInfo(appt, officeId,	date, app);
				IErrorWL eWL = examService.saveExamList(examList);
				appDTO.setErrorCode(eWL.getErrorCode());
				if(eWL.getErrorCode() == ErrorCode.NO_ERROR) {
					List<IExamHistory> ehList = createExamHistoryListForAppInfo(examList, date, examHistList);
					IErrorWL erWL = applicationService.saveExamHistoryList(ehList);
					appDTO.setErrorCode(erWL.getErrorCode());
				}
			}
		}
	}

	/*
	 * This is a helper method for saving exam history records from the DS/OL applicant information.
	 */
	private List<IExamHistory> createExamHistoryListForAppInfo(List<IExam> examList, Date date, List<gov.ca.dmv.AKT.presentation.Beans.ExamHistory> examHistList) {
		HashMap<String,String> numberFails= new HashMap<String,String>();
		for(gov.ca.dmv.AKT.presentation.Beans.ExamHistory examhist: examHistList){
			numberFails.put(examhist.getEaseTestId().trim(), examhist.getEaseStatusIndicator().trim());
		}
		List<IExamHistory> ehList = new ArrayList<IExamHistory>();
		for(IExam exam: examList) {
			IExamHistory eh = new ExamHistory();
			eh.setAktStatusIndicator(String.valueOf(Constant.ZERO));
			eh.setAktUpdatedTimestamp(date);
			eh.setApplicationId(exam.getApplicationId());
			eh.setEaseReceivedTimestamp(date);
			eh.setEaseStatusIndicator(numberFails.get(exam.getEaseTestId().trim()));
			eh.setEaseTestId(exam.getEaseTestId());
			eh.setLastModusername(getUserId());
			eh.setLastModUserTime(date);
			eh.setPastExamId(exam.getExamId());
			ehList.add(eh);
		}
		return ehList;
	}

	/*
	 * This is a helper method for saving exam records from the DS/OL applicant information. 
	 */
	private List<IExam> createExamsForAppInfo(Applicant appt, String officeId,	Date date, IApplication app) {
		List<IExam> examList = new ArrayList<IExam>();
		for(String testId: appt.getTestList()) {
			Test test = examSeedData.getTestByTestId(testId.trim());
			Exam exam = new Exam();
			exam.setApplicationId(app.getApplicationId());
			exam.setCdlFlag(test.getCdlFlag());
			exam.setCompletionReasonCode(Constant.SINGLE_SPACE);
			exam.setCorrectQuestionCount(Constant.ZERO);
			exam.setEaseTestId(testId.trim());
			exam.setEaseTimestamp(date);
			exam.setExamEndTime(Constant.defaultDate);
			exam.setExamOrder(test.getTestOrder());
			exam.setExamQuestionNumber(Integer.parseInt(test.getTestQuestionCount().trim()));
			exam.setExamStartTime(Constant.defaultDate);
			exam.setIncorrectAnswerCount(Constant.ZERO);
			exam.setLangId(Constant.SINGLE_SPACE);
			exam.setLastModUsername(getUserId());
			exam.setLastModUserTime(date);
			exam.setMaxIncorrectNumber(test.getMaxIncorrectNum());
			exam.setOfficeId(officeId);
			exam.setOptionalTestInd(test.getOptionalTestInd());
			exam.setPassFailIndicator(Constant.SINGLE_SPACE);
			exam.setQuestionAnsweredCount(Constant.ZERO);
			exam.setQuickPassFailFlag(test.getQuickPassFailInd());
			exam.setSessionId(Constant.ZERO);
			exam.setSignTestFlag(test.getSignTestFlag());
			exam.setTestId(testId.trim());
			exam.setTestTypeCode(test.getTestTypeCode());
			exam.setSecondaryVerificationId(Constant.SINGLE_SPACE);
			exam.setRemainingTime(test.getTimeLimit()*TimeLimitTypeConstant.SECONDS);
			examList.add(exam);
		}
		return examList;
	}

	/*
	 * This is a helper method for saving application record from the DS/OL applicant information. 
	 */
	private IApplication createAppForAppInfo(String group, String officeId, String techId, Date date, IVault vault, Applicant appt) {
		IApplication app = new Application();
		app.setApplicationStatusCode(Constant.SINGLE_SPACE);
		app.setApplicationTimestamp(date);
		app.setApplicationType(getAppTypeBasedOnGroup(group));
		app.setClassLicenseCode(Constant.SINGLE_SPACE);
		java.sql.Date dlExpDate = new java.sql.Date(Constant.defaultDate.getTime()); 
		app.setDlExpirationDate(dlExpDate);
		app.setEaseApplicationId(Constant.SINGLE_SPACE);
		app.setEndorsementCode(Constant.SINGLE_SPACE);
		app.setForceFailFlag(Constant.NO);
		app.setLastModUsername(getUserId());
		app.setLastModUserTime(date);
		app.setOfficeId(officeId);
		app.setOsFlag(Constant.NO);
		app.setPauseCount(String.valueOf(Constant.ZERO));
		app.setRenewalFlag(Constant.NO);
		app.setSignTestSatisfiedFlag(Constant.NO);
		app.setTechId(techId);
		app.setVaultId(vault.getVaultId());
		app.setAudioVideoTestCode(Constant.SINGLE_SPACE);
		if(appt.isAudio()) {
			app.setAudioVideoTestCode(AudioVideoConstant.AUDIO_ONLY);
			if(appt.isVideo()) {
				app.setAudioVideoTestCode(AudioVideoConstant.AUDIO_VIDEO);
			}
		}
		else if(appt.isVideo()) {
			app.setAudioVideoTestCode(AudioVideoConstant.VIDEO_ONLY);
		}
		return app;
	}

	/*
	 * This is a helper method for saving vault record from the DS/OL applicant information. 
	 */
	private IVault createVaultForAppInfo(Applicant appt, Date date) {
		IVault vault = new Vault();
		vault.setApplicationFirstName(appt.getFirstName());
		vault.setApplicationLastName(appt.getLastName());
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date birthDate = null;
		try {
			birthDate = formatter.parse(appt.getDob());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		java.sql.Date birthDateSQL = new java.sql.Date(birthDate.getTime());
		vault.setBirthDate(birthDateSQL);
		vault.setDlNumber(appt.getDlNumber());
		vault.setState(appt.getState());
		vault.setLastModUsername(getUserId());
		vault.setLastModUserTime(date);
		vault.setVaultTimestamp(date);
		return vault;
	}
	
	/*
	 * This is a helper method used to get the application type based on the group.
	 */
	private String getAppTypeBasedOnGroup(String group) {
		String appType = Constant.APP_TYPE_FO;
		if(group.trim().equalsIgnoreCase(Constant.DS_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.DS_USER_GROUP)) {
			appType = Constant.APP_TYPE_DS;
		}
		else if(group.trim().equalsIgnoreCase(Constant.OL_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.OL_USER_GROUP)) {
			appType = Constant.APP_TYPE_OL;
		}
		else if(group.trim().equalsIgnoreCase(Constant.CHP_ADMIN_GROUP) || group.trim().equalsIgnoreCase(Constant.CHP_USER_GROUP)) {
			appType = Constant.APP_TYPE_CHP;
		}
		return appType;
	}

	/*
	 * This method is called to change the status of completion reason code field for the exam being printed.
	 */
	public void changeCompletionReasonCode(ExamDTO examDTO) {
		List<gov.ca.dmv.AKT.presentation.Beans.Exam> examList = examDTO.getExamList();
		for(gov.ca.dmv.AKT.presentation.Beans.Exam ex: examList) {
			Integer examId = ex.getExamId();
			IExamWL examWL = examService.getExamByExamId(examId);
			examDTO.setErrorCode(examWL.getErrorCode());
			if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExam exam = examWL.getExam();
				String auditOldStatus = null;
				String auditNewStatus = null;
				if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.VIEW_TEST_STATUS)) {
					auditOldStatus = Constant.VIEW_TEST_STATUS;
					auditNewStatus = Constant.PRINT_TEST_STATUS;
				}
				else if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.PRINT_TEST_STATUS)) {
					auditOldStatus = Constant.PRINT_TEST_STATUS;
					auditNewStatus = Constant.REPRINT_TEST_STATUS;
				}
				else if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.REPRINT_TEST_STATUS)) {
					auditOldStatus = Constant.REPRINT_TEST_STATUS;
					auditNewStatus = Constant.REPRINT_TEST_STATUS;
				}
				else if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.VIEW_ANSWER_KEY_STATUS)) {
					auditOldStatus = Constant.VIEW_ANSWER_KEY_STATUS;
					auditNewStatus = Constant.PRINT_ANSWER_KEY_STATUS;
				}
				else if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS)) {
					auditOldStatus = Constant.PRINT_ANSWER_KEY_STATUS;
					auditNewStatus = Constant.REPRINT_ANSWER_KEY_STATUS;
				}
				else if(exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.REPRINT_ANSWER_KEY_STATUS)) {
					auditOldStatus = Constant.REPRINT_ANSWER_KEY_STATUS;
					auditNewStatus = Constant.REPRINT_ANSWER_KEY_STATUS;
				}
				Date date = new Date();
				exam.setCompletionReasonCode(auditNewStatus);
				exam.setLastModUsername(getUserId());
				exam.setLastModUserTime(date);
				IErrorWL eWL = examService.updateExam(exam);
				examDTO.setErrorCode(eWL.getErrorCode());
				if(eWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, auditOldStatus, auditNewStatus, String.valueOf(exam.getExamId()), examDTO.getUserId());
					examDTO.setErrorCode(errorWL.getErrorCode());
				}
			}
		}
	}
	
	/*
	 * This method is called to generate the field office volume report based on the selected date range.
	 */
	public void getHistoricalReport(ReportDTO repDTO) {
		String group = repDTO.getGroup();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat formatter2 = new SimpleDateFormat("MM/dd/yyyy/HH/mm/ss");
		Date fromDate = null;
		Date toDate = null;
		String dl = repDTO.getDl();
		String lastName = repDTO.getLastName();
		try {
			fromDate = formatter.parse(repDTO.getFromDate());
			toDate = formatter2.parse(repDTO.getToDate());
		}
		catch(ParseException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		ApplicantListWL appWL = applicationService.searchApplicantsByAppType(fromDate, toDate, getAppTypeBasedOnGroup(group),dl,lastName);
		repDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.Applicant> appList = appWL.getApplicantList();
			generateHistoricalReport(repDTO, appList);
		}
	}
	
	private void generateHistoricalReport(ReportDTO repDTO, List<gov.ca.dmv.AKT.integration.BeansImpl.Applicant> appList) {
		List<Applicant> applicantList = new ArrayList<Applicant>();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String examEndDate=null;
		for(gov.ca.dmv.AKT.integration.BeansImpl.Applicant app: appList) {
			IExamListWL examWL = examService.getAllExamsByAppId(app.getApplicationId());
			repDTO.setErrorCode(examWL.getErrorCode());
			if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<IExam> examList = examWL.getExamList();
				for(IExam exam: examList) {
					Applicant applicant = new Applicant();
					applicant.setOfficeId(app.getOfficeId().trim());
					applicant.setDlNumber(app.getDlNumber());
					applicant.setFirstName(app.getFirstName());
					applicant.setLastName(app.getLastName());
					applicant.setExamType(examSeedData.getTestByTestId(exam.getTestId()).getTestName());
					examEndDate = (formatter.format(exam.getExamEndTime()).equals("01/01/1111")) ? null :formatter.format(exam.getExamEndTime());
					applicant.setExamEndDate(examEndDate);
					//applicant.setIncorrect();
					applicant.setIncorrect(exam.getIncorrectAnswerCount());
					applicant.setResult(null);
					if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.PASS)) {
						applicant.setResult("Pass");	
					}
					else if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.FAIL)) {
						applicant.setResult("Fail");
					}
					setStatusDesc(exam, applicant, repDTO);
					applicantList.add(applicant);
				}
			}
		}
		repDTO.setApplicantList(applicantList);
	}
	
	private void setStatusDesc(IExam exam, Applicant app, ReportDTO repDTO) {
		if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
			app.setExamStatus("Not Started");
			if(!Constant.isSameDay(exam.getExamStartTime(), Constant.defaultDate)) {
				app.setExamStatus("In Progress");
			}
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.TIME_OUT)) {
			app.setExamStatus("Timed Out");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.TIMED_TEST_TIME_OUT)) {
			app.setExamStatus("Timed Test Time Out");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PAUSE)) {
			app.setExamStatus("Paused");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.QUIT)) {
			app.setExamStatus("Quit");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.FORCE_FAIL)) {
			app.setExamStatus("Force Failed");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.BATCH_FAIL)) {
			app.setExamStatus("EOD");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.RESTART)) {
			IAuditWL auditWL = auditService.getAuditByKeyAndTable(String.valueOf(exam.getExamId()), Constant.EXAM_TABLE);
			repDTO.setErrorCode(auditWL.getErrorCode());
			if(auditWL.getErrorCode() == ErrorCode.NO_ERROR) {
				Audit audit = auditWL.getAudit();
				if(audit.getNewValue().equalsIgnoreCase(Constant.RESTART)) {
					if(audit.getOldValue().equalsIgnoreCase(Constant.TIME_OUT)) {
						app.setExamStatus("Resumed (Time Out)");
					}
					else if(audit.getOldValue().equalsIgnoreCase(Constant.QUIT)) {
						app.setExamStatus("Resumed (Quit)");
					}
					else if(audit.getOldValue().equalsIgnoreCase(Constant.PAUSE)) {
						app.setExamStatus("Resumed (Pause)");
					}
					else if(audit.getOldValue().equalsIgnoreCase(Constant.DISCONNECTED)) {
						app.setExamStatus("Resumed (Disconnected)");
					}
				}
			}
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_TEST_STATUS) || 
				exam.getCompletionReasonCode().equalsIgnoreCase(Constant.REPRINT_TEST_STATUS)) {
			app.setExamStatus("Print (Test)");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_ANSWER_KEY_STATUS) || 
				exam.getCompletionReasonCode().equalsIgnoreCase(Constant.REPRINT_ANSWER_KEY_STATUS)) {
			app.setExamStatus("Print (Answer Key)");
		}
		else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS)) {
			app.setExamStatus("Print (Score Updated)");
		}
	}

	/*
	 * This method is called to generate the field office volume report based on the selected date range.
	 */
	public void getVolumeReport(ReportDTO repDTO) {
		String officeId = repDTO.getOfficeId();
		String group = repDTO.getGroup();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat formatter2 = new SimpleDateFormat("MM/dd/yyyy/HH/mm/ss");
		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = formatter.parse(repDTO.getFromDate());
			toDate = formatter2.parse(repDTO.getToDate());
		}
		catch(ParseException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}
		IApplicationListWL appWL = applicationService.getAppsByOfficeIdAndDateRange(officeId, fromDate, toDate, getAppTypeBasedOnGroup(group));
		repDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<IApplication> appList = appWL.getApplicationList();
			List<Volume> volList = calculateVolumes(repDTO, appList);
			repDTO.setVolumeList(volList);
		}
	}

	private List<Volume> calculateVolumes(ReportDTO repDTO, List<IApplication> appList) {
		List<Volume> volumeList = new ArrayList<Volume>();
		for(IApplication app: appList) {
			IExamListWL exWL = examService.getCompletedExamsByAppId(app.getApplicationId());
			if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<IExam> examList = exWL.getExamList();
				for(IExam exam: examList) {
					Volume vol = getVolume(exam.getTestId(), exam.getLangId(), volumeList);
					int fail = vol.getFailCount();
					int pass = vol.getPassCount();
					int avgTime = vol.getAvgTime();
					int total = vol.getTotalCount();
					total++;
					vol.setTotalCount(total);
					if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.PASS)) {
						pass++;
						vol.setPassCount(pass);
					}
					else {
						fail++;
						vol.setFailCount(fail);
					}
					if(!(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS) || (exam.getCompletionReasonCode().equalsIgnoreCase(Constant.BATCH_FAIL) && Constant.isSameDay(exam.getExamStartTime(),Constant.getDefaultDate())))) {
						long diffInSec = (exam.getExamEndTime().getTime() - exam.getExamStartTime().getTime())/1000;
						avgTime = (int)(avgTime + diffInSec)/total;
						vol.setAvgTime(avgTime);
					}
				}
			}
			else {
				if(exWL.getErrorCode() != ErrorCode.MISSING_EXAMS)
					repDTO.setErrorCode(exWL.getErrorCode());
			}
		}
		return volumeList;
	}
	
	private Volume getVolume(String testId, String langId, List<Volume> volumeList) {
		Volume vol = null;
		for(Volume volume: volumeList) {
			if(volume.getTestId().equalsIgnoreCase(testId)) {
				vol = volume;
			}
		}
		if(vol == null) {
			vol = new Volume();
			vol.setTestId(testId);
			vol.setTestName(examSeedData.getTestByTestId(testId).getTestName());
			vol.setAvgTime(Constant.ZERO);
			vol.setFailCount(Constant.ZERO);
			vol.setPassCount(Constant.ZERO);
			vol.setLanguage(examSeedData.getLangByLangId(langId).getLangName());
			vol.setTotalCount(Constant.ZERO);
			volumeList.add(vol);
		}
		return vol;
	}

	/*
	 * This method is called to audit the printed test that was generated through the 'Generate Test' feature.
	 */
	public void auditTestGenerated(ExamDTO examDTO) {
		String testId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getTestId();
		String langId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLangId();
		String userId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLastModUsername();
		String startAt = examDTO.getPrintStatus();
		String endAt = examDTO.getResult();
		IErrorWL errorWL = auditService.saveAudit(Constant.GENERATE_TEST, langId, startAt, endAt, testId, userId);
		examDTO.setErrorCode(errorWL.getErrorCode());
	}
	
	public boolean isApplicantManuallyAssignedByExamId(int examId) {
		boolean returnValue = false;
		if (examId > 0) {
			IExamWL examWL = examService.getExamByExamId(examId);	
			if (examWL.getErrorCode() == ErrorCode.NO_ERROR) {
				long applicantId = examWL.getExam().getApplicationId();
				IAuditWL auditWL = auditService.getAuditByKeyAndTable(String.valueOf(applicantId), Constant.MANUALLY_ASSIGNED);
				if (auditWL.getErrorCode() == ErrorCode.NO_ERROR) {
					returnValue = true;
				}
			}
		}
		return returnValue;		
	}
	
	public boolean isApplicantManuallyAssignedByAppId(int applicantId) {
		boolean returnValue = false;
		if (applicantId > 0) {
			IAuditWL auditWL = auditService.getAuditByKeyAndTable(String.valueOf(applicantId), Constant.MANUALLY_ASSIGNED);
			if (auditWL.getErrorCode() == ErrorCode.NO_ERROR) {
				returnValue = true;
			}
		}
		return returnValue;		
	}
	
	/*
	 * This method is called to get a list of all exams
	 */
	public void getAllExams(ApplicantDTO appDTO) {
		appDTO.setErrorCode(ErrorCode.NO_ERROR);
		String officeId = appDTO.getOfficeId();
		IExamListWL examListWL = examService.getAllExamsByOfficeId(officeId, appDTO.getApplicationType());
		
		if(examListWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IApplicationListWL appListWL = applicationService.getTodaysApps(officeId.trim(), appDTO.getGroup());
			if(appListWL.getErrorCode() == ErrorCode.NO_ERROR) {
				HashMap<Integer,IApplication> appMap = new HashMap<Integer,IApplication>();
				for(IApplication app: appListWL.getApplicationList()){
					appMap.put(app.getApplicationId(),app);
				}
				
				IVaultListWL vaultListWL = applicationService.getAllVaultsByOfficeId(officeId, appDTO.getApplicationType());
				if (vaultListWL.getErrorCode() == ErrorCode.NO_ERROR) {
					HashMap<Integer,Vault> vaultMap = new HashMap<Integer,Vault>();
					for(Vault vault: vaultListWL.getVaultList()){
						vaultMap.put(vault.getVaultId(), vault);
					}

					ISessionListWL sessionListWL = sessionService.getAllSessionsByOfficeId(officeId, appDTO.getApplicationType());
					if(sessionListWL.getErrorCode() == ErrorCode.NO_ERROR ||
					   sessionListWL.getErrorCode() == ErrorCode.MISSING_EXAMS ){
						HashMap<Integer,ISession> sessMap = new HashMap<Integer,ISession>();
						if (sessionListWL.getSessionList() != null) {
							for(ISession sess: sessionListWL.getSessionList()){
								sessMap.put(sess.getSessionId(),sess);
							}
						}
						sessMap.put(0,null);
						IActiveSessionAndExamListWL aseWL = sessionService.getExams(officeId,  appDTO.getApplicationType());
						if(aseWL.getErrorCode() == ErrorCode.NO_ERROR){
							HashSet<Integer> disconnectedSess = new HashSet<Integer>();
							for(ActiveSessionAndExam discon: aseWL.getActiveSessionAndExamList()){
								disconnectedSess.add(discon.getExam().getExamId());
							}
							
							List<IExam> examList = examListWL.getExamList();
							List<Applicant> applicantList = new ArrayList<Applicant>();						
							for(IExam exam: examList) {
								Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
								IApplication appl = appMap.get(exam.getApplicationId());
								Vault vault = vaultMap.get(appl.getVaultId());
								ISession sess = sessMap.get(exam.getSessionId());
								
								Applicant applicant = new Applicant();
								applicant.setDlNumber(vault.getDlNumber());
								applicant.setExamType(test.getTestName());
								applicant.setFirstName(vault.getApplicationFirstName());
								applicant.setLastName(vault.getApplicationLastName());
								applicant.setExamId(exam.getExamId());
								
								setTerminalAndStatus(applicant,exam,sess,disconnectedSess.contains(exam.getExamId()));
								
								applicantList.add(applicant);
							}
							appDTO.setApplicantList(applicantList);
						
						}
						else{
							appDTO.setErrorCode(aseWL.getErrorCode());
						}
					}
					else{
						appDTO.setErrorCode(sessionListWL.getErrorCode());
					}
				}
				else{
					appDTO.setErrorCode(vaultListWL.getErrorCode());
				}					
			}
			else {
				appDTO.setErrorCode(appListWL.getErrorCode());
			}
		}
		else if(examListWL.getErrorCode() != ErrorCode.MISSING_EXAMS){
			appDTO.setErrorCode(examListWL.getErrorCode());
		}
	}
	
	private void setTerminalAndStatus(Applicant applicant, IExam exam, ISession sess, boolean disconnected){
		if(exam.getSessionId()==0){
			applicant.setWorkstationId(" ");
			applicant.setExamStatus(Constant.EXAM_NOT_STARTED);
		}
		else{
			WorkstationMap wm = examSeedData.getWorkstationMapByIPAddress(sess.getWorkstationIPAddress().trim());
			String workstationId = null;
			if(wm.getLocatingOfficeId().equals(Constant.NULL_STRING)) {
				workstationId = wm.getWorkstationId();
			} else {
				workstationId = wm.getLocatingOfficeId() + Constant.SINGLE_DASH + wm.getWorkstationId();
			}
			applicant.setWorkstationId(workstationId);
			if(exam.getCompletionReasonCode().trim().equals(Constant.QUIT)){
				applicant.setExamStatus(Constant.EXAM_QUIT);
			}
			else if(exam.getCompletionReasonCode().trim().equals(Constant.TIME_OUT)){
				applicant.setExamStatus(Constant.EXAM_TIMED_OUT);
			}
			else if(exam.getCompletionReasonCode().trim().equals(Constant.PAUSE)){
				applicant.setExamStatus(Constant.EXAM_PAUSED);
			}	
			else if(exam.getCompletionReasonCode().trim().equals(Constant.FORCE_FAIL)){
				applicant.setExamStatus(Constant.EXAM_FORCE_FAILED);
			}	
			else if(exam.getCompletionReasonCode().trim().equals(Constant.TIMED_TEST_TIME_OUT)){
				applicant.setExamStatus(Constant.EXAM_TIMED_TEST_TIME_OUT);
			}	
			else if(exam.getCompletionReasonCode().trim().equals(Constant.RESTART) && Constant.isToday(sess.getSessionEndTime())){
				applicant.setExamStatus(Constant.EXAM_RESUMED);
			}
			else if(disconnected){
				applicant.setExamStatus(Constant.EXAM_DISCONNECTED);
				if(sess.getSessionStatusCode().trim().equals(Constant.SESSION_TERMINATED)){
					applicant.setExamStatus(Constant.EXAM_TERMINATED);
				}
			}	
			else if(Constant.isToday(sess.getSessionStartTime()) && !Constant.isToday(sess.getSessionEndTime()) && !Constant.isToday(exam.getExamEndTime())){
				applicant.setExamStatus(Constant.EXAM_IN_PROGRESS);
			}
			else if(Constant.isToday(exam.getExamEndTime()) && exam.getPassFailIndicator().trim().length()>0){
				applicant.setExamStatus(Constant.EXAM_COMPLETED);			
			}			
		}		
	}
}
