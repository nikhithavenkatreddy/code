package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.BaseBusDelegate;
import gov.ca.dmv.AKT.business.Services.AuditService;
import gov.ca.dmv.AKT.business.Services.ExamSeedData;
import gov.ca.dmv.AKT.business.Services.ExamSessionData;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class BaseBusDelegateImpl implements BaseBusDelegate {
	protected AuditService    auditService;
	protected ExamSessionData examSessionData;
	protected ExamSeedData    examSeedData;
	protected static final Logger logger = Logger.getLogger(FOBusDelegateImpl.class);
	
	public ExamSeedData getExamSeedData() {
		return examSeedData;
	}

	public void setExamSeedData(ExamSeedData examSeedData) {
		this.examSeedData = examSeedData;
	}

	public ExamSessionData getExamSessionData() {
		return examSessionData;
	}

	public void setExamSessionData(ExamSessionData examSessionData) {
		this.examSessionData = examSessionData;
	}

	public AuditService getAuditService() {
		return auditService;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
	
	public IErrorWL saveAudit(String tableName, String fieldName, String oldValue, String newValue, String key, String techId) {
		IErrorWL erroWL = auditService.saveAudit(tableName, fieldName, oldValue, newValue, key, techId);
		return erroWL;
	}
	
	public IDMVStaff getDMVStaff(HttpSession session) {
		IDMVStaff staff = (IDMVStaff) session.getAttribute(Constant.CREDENTIAL);
		if (staff != null && this.examSessionData != null) {
			if (this.examSessionData.getDmvStaff() == null) {
				this.examSessionData.setDmvStaff(staff);
			}
		}	
		return staff;
	}
	
	public String getUserId() {
		String userId = null;
		if (this.examSessionData != null && this.examSessionData.getDmvStaff() != null) {
			userId = this.examSessionData.getDmvStaff().getUserId();
		}
		else {
			userId = Constant.LASTMODUSR_NME;
		}
		return userId;
	}
}
