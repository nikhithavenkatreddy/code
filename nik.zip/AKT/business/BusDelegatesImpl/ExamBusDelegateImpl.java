package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.ExamBusDelegate;
import gov.ca.dmv.AKT.business.Services.ApplicationService;
import gov.ca.dmv.AKT.business.Services.ExamService;
import gov.ca.dmv.AKT.business.Services.ForceFailRegistryService;
import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.Services.TestService;
import gov.ca.dmv.AKT.business.WorkloadImpl.ErrorWL;
import gov.ca.dmv.AKT.business.WorkloadImpl.StringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamQuestionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuesAnswWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IResultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestReportsWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.constants.AudioVideoConstant;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.AKTSResults;
import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.BeansImpl.Exam;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamHistory;
import gov.ca.dmv.AKT.integration.BeansImpl.ExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLangQuickPF;
import gov.ca.dmv.AKT.integration.BeansImpl.QuickPassFailEvent;
import gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSPublisher;
import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.Beans.EndOfDayReport;
import gov.ca.dmv.AKT.presentation.Beans.ExamTestLang;
import gov.ca.dmv.AKT.presentation.Beans.ExceptionApplicant;
import gov.ca.dmv.AKT.presentation.Beans.HandbookRef;
import gov.ca.dmv.AKT.presentation.DTO.AnswerDTO;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesPassRateDTO;
import gov.ca.dmv.AKT.presentation.DTO.ReportDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class ExamBusDelegateImpl extends BaseBusDelegateImpl implements ExamBusDelegate {
	
	private ExamService              examService;
	private TestService              testService;
	private ApplicationService       applicationService;
	private SessionService           sessionService;
	private ForceFailRegistryService forceFailRegistryService;
	private JMSPublisher             jmsPublisher;
	
	public JMSPublisher getJmsPublisher() {
		return jmsPublisher;
	}

	public void setJmsPublisher(JMSPublisher jmsPublisher) {
		this.jmsPublisher = jmsPublisher;
	}

	public ForceFailRegistryService getForceFailRegistryService() {
		return forceFailRegistryService;
	}

	public void setForceFailRegistryService(ForceFailRegistryService forceFailRegistryService) {
		this.forceFailRegistryService = forceFailRegistryService;
	}

	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public TestService getTestService() {
		return testService;
	}

	public void setTestService(TestService testService) {
		this.testService = testService;
	}

	public ExamService getExamService() {
		return examService;
	}

	public void setExamService(ExamService examService) {
		this.examService = examService;
	}

	/* This method is recursively called until the generateTest method in the exam seed data service
	 * returns a collection of questions different from the collection of questions
	 * obtained from the previous CDL exam by an acceptable margin
	 */
	private QuestionLangQuickPF generateTestHelper(IExam exam, String audioVideoTestCode) {
		TestLang testLang = new TestLang();
		testLang.setLangId(exam.getLangId());
		testLang.getTlPrimaryKey().setTestId(exam.getTestId());
		testLang.setSignTestSatisfied(true);
		QuestionLangQuickPF quesLangQPF = examSeedData.generateTest(testLang,audioVideoTestCode);
		quesLangQPF.setFirstCDL(false);
		List<QuestionLang> qlList = quesLangQPF.getQuestionLangList();
		IExam exam1 = examService.getExamByTestIdAndDiffExamId(exam);
		if(exam1 != null) {
			quesLangQPF.setFirstCDL(false);
			IExamQuestionListWL eqWL = examService.getExamQues(exam1.getExamId());
			List<IExamQuestion> examQuestionList = eqWL.getExamQuestionList();
			if (examQuestionList != null) {
				int matchedCount = Constant.ZERO;
				for(IExamQuestion examQues: examQuestionList)
				{
					for(QuestionLang quesLang: qlList)
					{
						if(examQues.getQuestionId().equalsIgnoreCase(quesLang.getQuestionId()))
						{
							matchedCount++;
							continue;
						}
					}
				}
				int examsize = qlList.size();
				double variation = (double)(examsize - matchedCount)/(double)examsize;
				if(variation < Constant.ACCEPTABLE_VARIATION)
					generateTestHelper(exam,audioVideoTestCode);
			}
			else {
				logger.error("Missing exam question list for the comercial exam with exam_id: " + exam1.getExamId() + "!-####");
			}
		}
		else {
			quesLangQPF.setFirstCDL(true);
		}
		return quesLangQPF;
	}
	
	/*
	 * This method is called to send a force fail request (add/delete) using JMS
	 */
	public void publishForceFailRequest(ExamDTO examDTO) {
		Integer examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		String message = examDTO.getForceFailAction() + examId;
		jmsPublisher.setMessage(message);
		jmsPublisher.sendMesage();
	}
	
	
	/*
	 * This method is called to generate the exam based on the exam id.
	 */ 
	public void generateExam(ExamDTO examDTO, boolean forPrint) {
		IExamWL examWL = examService.getExamByExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		examDTO.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IApplication app = examSessionData.getApplication();
			if(forPrint){
				//if the method is called to print the exam, exam generation will have an application that does not require Audio/Video
				app = new Application();
				app.setAudioVideoTestCode(Constant.SINGLE_SPACE);
			}
			List<QuesAnsw> quesAnswList = null;
			IExam exam = examWL.getExam();
			Test test = examSeedData.getTestByTestId(exam.getTestId());
			examDTO.setTestName(test.getTestName());
			examDTO.setMaxIncorrect(exam.getMaxIncorrectNumber());
			examDTO.setTestId(exam.getTestId().trim());
			if(examDTO.isPrint() && (exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.PRINT_TEST_STATUS) || exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.VIEW_TEST_STATUS) || exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.REPRINT_TEST_STATUS))) {
				generateReprintExam(examDTO, exam);
			}
			else {
				List<Answer> sessionAnswerList = null;
				exam.setLangId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLangId());
				List<QuestionLang> qlList = null;
				QuickPassFailEvent qpfEvent = null;
				TestLang testLang = new TestLang();
				String langId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLangId();
				Lang lang = examSeedData.getLangByLangId(langId);
				examDTO.setProgLangCode(lang.getProgLangCode());
				testLang.setLangId(langId);
				testLang.getTlPrimaryKey().setTestId(exam.getTestId());
				if(test.getEnglishOnlyFlag().equalsIgnoreCase(Constant.YES)) {
					testLang.setLangId(test.getDefaultLangFlag().trim());
					exam.setLangId(test.getDefaultLangFlag().trim());
				}
				else{
					testLang = examSeedData.getTestLangByTestIdLangId(testLang); 
					if(testLang == null) {
						testLang = new TestLang();
						testLang.getTlPrimaryKey().setTestId(exam.getTestId());
						testLang.setLangId(Constant.DEFAULT_LANG.trim());
						testLang = examSeedData.getTestLangByTestIdLangId(testLang);
						if(testLang == null) {
							examDTO.setErrorCode(ErrorCode.INCORRECT_LANG);
						}
						else{
							exam.setLangId(Constant.DEFAULT_LANG.trim());
						}
					}
				}
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR){
					if(!examDTO.isPrint()) {
						sessionAnswerList = new ArrayList<Answer>();
					}
					else {
						testLang = examSeedData.getTestLangByTestIdLangId(testLang);
						examDTO.setTestName(testLang.getTestLangName());
						quesAnswList = new ArrayList<QuesAnsw>();
					}
					if(exam.getCdlFlag().equalsIgnoreCase(Constant.YES)) {
						QuestionLangQuickPF qlQPF = generateTestHelper(exam,app.getAudioVideoTestCode());
						if(qlQPF.isFirstCDL()) {
							qlQPF = examSeedData.generateTest(testLang,app.getAudioVideoTestCode() );
							qlList = qlQPF.getQuestionLangList();
							qpfEvent = qlQPF.getQuickPassFailEvent();
						}
						else {
							qlList = qlQPF.getQuestionLangList();
							qpfEvent = qlQPF.getQuickPassFailEvent();
						}
						if(!examDTO.isPrint()) {
							qlList = qlQPF.getQuestionLangList();
							examSessionData.setQuestionLangList(qlList);
							examSessionData.setSkippedExamQuestionList(new ArrayList<IExamQuestion>());
						}
					}
					else {
						QuestionLangQuickPF qlQPF = examSeedData.generateTest(testLang,app.getAudioVideoTestCode());
						qlList = qlQPF.getQuestionLangList();
						if(!examDTO.isPrint()) {
							examSessionData.setQuestionLangList(qlList);
							examSessionData.setSkippedExamQuestionList(new ArrayList<IExamQuestion>());
						}
						qpfEvent = qlQPF.getQuickPassFailEvent();
					}
					int questionPresentedOrder = 0;
					List<IExamQuestion> examQuestionList = new ArrayList<IExamQuestion>();
					List<IExamAnswer> examAnswerList = new ArrayList<IExamAnswer>();
					createExamQuesAndAnsw(exam, qlList, questionPresentedOrder, sessionAnswerList, examQuestionList, examAnswerList, quesAnswList, examDTO);
					IErrorWL errWL = examService.saveExamQuesList(examQuestionList);
					examDTO.setErrorCode(errWL.getErrorCode());
					if(errWL.getErrorCode() == ErrorCode.NO_ERROR) { 
						IErrorWL errrWL = examService.saveExamAnswList(examAnswerList);
						examDTO.setErrorCode(errrWL.getErrorCode());
						if(errrWL.getErrorCode() == ErrorCode.NO_ERROR) {
							updateExamForGenExam(examDTO, sessionAnswerList, exam,	qpfEvent, examQuestionList, examAnswerList, quesAnswList);
							IErrorWL erWL = examService.updateExam(exam);
							examDTO.setErrorCode(erWL.getErrorCode());
							if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
								if(examDTO.isPrint()) {
									IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.SINGLE_SPACE, 
																			  Constant.VIEW_TEST_STATUS, String.valueOf(exam.getExamId()), examDTO.getUserId());
									examDTO.setErrorCode(errorWL.getErrorCode());
								}							
								IErrorWL errorWL = sessionService.reset(exam.getSessionId(),Constant.SESSION_TESTING);
								if(errorWL.getErrorCode() != ErrorCode.NO_ERROR) {
									examDTO.setErrorCode(errorWL.getErrorCode());
								}
							}
						}
					}
				}
			}
		}
		else {
			examDTO.setErrorCode(examWL.getErrorCode());
		}
	}
	
	/*
	 * This is a helper method used in generateExam(ExamDTO examDTO) method to generate exam for reprint scenario.
	 */
	private void generateReprintExam(ExamDTO examDTO, IExam exam) {
		//String oldStatus = exam.getCompletionReasonCode().trim();
		String langId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getLangId();
		Lang lang = examSeedData.getLangByLangId(langId);
		examDTO.setProgLangCode(lang.getProgLangCode());
		IExamQuestionListWL eqWL = examService.getExamQues(exam.getExamId());
		examDTO.setErrorCode(eqWL.getErrorCode());
		if(eqWL.getErrorCode() == ErrorCode.NO_ERROR) {
			Map<Integer, List<IExamAnswer>> quesGenIdWithExamAnsOrder = examService.getQuesGenIdMapWithAnswOrderByAnswPresOrd(exam.getExamId(), eqWL.getExamQuestionListIds());
			List<IExamQuestion> eqList = eqWL.getExamQuestionList();
			List<QuesAnsw> quesAnswList = new ArrayList<QuesAnsw>();
			for(IExamQuestion eq: eqList) {
				QuestionLang ql = examSeedData.getQuestionLangByQuesGenId(eq.getQuestionGenId());
				List<Answer> answerListUnordered = examSeedData.getAnswersByQuesGenId(eq.getQuestionGenId());
				List<Answer> answerListOrdered = examService.getAnswerInDisplayOrder(quesGenIdWithExamAnsOrder.get(eq.getQuestionGenId()), answerListUnordered);
				QuesAnsw qa = new QuesAnsw();
				qa.setAnswerList(answerListOrdered);
				qa.setQuestionLang(ql);
				quesAnswList.add(qa);
			}
			examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
//			Date date = new Date();
//			if(!exam.getCompletionReasonCode().trim().equalsIgnoreCase(Constant.REPRINT_TEST_STATUS)) {
//				exam.setCompletionReasonCode(Constant.REPRINT_TEST_STATUS);
//				exam.setLastModUsername(getUserId());
//				exam.setLastModUserTime(date);
//				IErrorWL eWL = examService.updateExam(exam);
//				examDTO.setErrorCode(eWL.getErrorCode());
//			}
//			if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
//				IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, oldStatus, Constant.REPRINT_TEST_STATUS, String.valueOf(exam.getExamId()), examDTO.getTechId());
//				examDTO.setErrorCode(errorWL.getErrorCode());
//			}
		}
	}

	/*
	 * This is a helper method for the generateExam(ExamDTO examDTO) method used for updating exam.
	 */
	private void updateExamForGenExam(ExamDTO examDTO,	List<Answer> sessionAnswerList, IExam exam, QuickPassFailEvent qpfEvent, List<IExamQuestion> examQuestionList, List<IExamAnswer> examAnswerList, List<QuesAnsw> quesAnswList) {
		if(qpfEvent != null && 
		   (qpfEvent.getQuickPassFlag().equals(Constant.YES) || qpfEvent.getQuickFailFlag().equals(Constant.YES))) {
			exam.setQuickPassFailFlag(Constant.YES);
		}
		Date currentDate = new Date();
		exam.setLastModUserTime(currentDate);
		exam.setLastModUsername(getUserId());
		if(!examDTO.isPrint()) {
			exam.setSessionId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getSessionId());
			exam.setExamStartTime(currentDate);
			exam.setCompletionReasonCode(Constant.SINGLE_SPACE);
			examSessionData.setExamQuestionList(examQuestionList);
			examSessionData.setExamAnswerList(examAnswerList);
			examSessionData.setAnswerList(sessionAnswerList);
			examSessionData.setExam(exam);
		}
		else {
			exam.setCompletionReasonCode(Constant.VIEW_TEST_STATUS);
			examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
		}
	}

	/*
	 * This is a helper method for the generateExam(ExamDTO examDTO) method used for creating exam questions and exam answers.
	 */
	private void createExamQuesAndAnsw(IExam exam, List<QuestionLang> qlList, int questionPresentedOrder, List<Answer> sessionAnswerList, List<IExamQuestion> examQuestionList, List<IExamAnswer> examAnswerList, List<QuesAnsw> quesAnswList, ExamDTO examDTO) {
		for(QuestionLang quesLang: qlList) {
			questionPresentedOrder++;
			List<Answer> answerList = examSeedData.getAnswersByQuesGenId(quesLang.getQuestionGenId());
			Collections.shuffle(answerList);
			if(examDTO.isPrint()) {
				QuesAnsw qa = new QuesAnsw();
				qa.setAnswerList(answerList);
				qa.setQuestionLang(quesLang);
				quesAnswList.add(qa);
			}
			else {
				sessionAnswerList.addAll(answerList);
			}
			Date currentDate = new Date();
			ExamQuestion examQuestion = new ExamQuestion();
			examQuestion.getEqPrimaryKey().setExamId(exam.getExamId());
			examQuestion.getEqPrimaryKey().setQuestionPresentedOrder(questionPresentedOrder);
			examQuestion.setQuestionGenId(quesLang.getQuestionGenId());
			examQuestion.setQuestionId(quesLang.getQuestionId());
			examQuestion.setQuestionLangId(quesLang.getQuestionLangId());
			examQuestion.setAnswerChoice(Constant.SINGLE_SPACE);			
			examQuestion.setAnswerStatus(Constant.SINGLE_SPACE);
			examQuestion.setAnswerElapsedTime(Constant.ZERO);
			examQuestion.setLastModUserTime(currentDate);
			examQuestion.setLastModUsername(exam.getLastModUsername());
			examQuestionList.add(examQuestion);
			int answerPresentedOrder = 0;
			for(Answer answer: answerList) {
				answerPresentedOrder++;
				ExamAnswer examAnswer = new ExamAnswer();
				examAnswer.getEaPrimaryKey().setExamId(exam.getExamId());
				examAnswer.getEaPrimaryKey().setAnswerId(answer.getAnswerGenId());
				examAnswer.setQuestionGenId(quesLang.getQuestionGenId());
				if(answer.getCorrectAnswerInd().equalsIgnoreCase(Constant.CORRECT))
					examAnswer.setCorrectAnswerFlag(Constant.YES);
				else
					examAnswer.setCorrectAnswerFlag(Constant.NO);
				examAnswer.setAnswerPresentedOrder(answerPresentedOrder);
				examAnswer.setLastModUserTime(currentDate);
				examAnswer.setLastModUsername(getUserId());	
				examAnswerList.add(examAnswer);
			}
		}
	}

	/*
	 * This method is called to generate the exam selected for printing
	 */
	public void generatePrintExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		gov.ca.dmv.AKT.integration.BeansImpl.Test test = examSeedData.getTestByTestId(exam.getTestId());
		examDTO.setMaxIncorrect(test.getMaxIncorrectNum());
		gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang1 = new gov.ca.dmv.AKT.integration.BeansImpl.TestLang();
		testLang1.setLangId(exam.getLangId());
		testLang1.getTlPrimaryKey().setTestId(exam.getTestId());
		testLang1 = examSeedData.getTestLangByTestIdLangId(testLang1);
		if(testLang1 != null) {
			examDTO.setTestName(testLang1.getTestLangName());
			examDTO.setTestId(exam.getTestId());
			examDTO.setProgLangCode(examSeedData.getLangByLangId(exam.getLangId()).getProgLangCode());
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList = null;
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw> quesAnswList = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw>();
			gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang = new gov.ca.dmv.AKT.integration.BeansImpl.TestLang();
			testLang.setLangId(exam.getLangId());
			testLang.getTlPrimaryKey().setTestId(exam.getTestId());
			QuestionLangQuickPF qlQPF = examSeedData.generateTest(testLang,Constant.SINGLE_SPACE);
			qlList = qlQPF.getQuestionLangList();
			for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang: qlList) {
				QuesAnsw quesAnsw = new QuesAnsw();
				quesAnsw.setQuestionLang(quesLang);
				List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList = examSeedData.getAnswersByQuesGenId(quesLang.getQuestionGenId());
				Collections.shuffle(answerList);
				quesAnsw.setAnswerList(answerList);
				quesAnswList.add(quesAnsw);
			}
			examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
		}
		else {
			examDTO.setErrorCode(ErrorCode.INCORRECT_LANG);
		}
	}
	
	/*
	 * This method is called to get the list of exams that need to be presented to the applicant
	 */
	public void getExams(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		examDTO.setAirbrakes(false);
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		IExamListWL examWL = examService.getExamByAppIdAndDifferentSessionId(exam);
		IApplication app = examSessionData.getApplication();
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<IExam> examList = examWL.getExamList(); 
			List<ExamTestLang> examTestLangList = new ArrayList<ExamTestLang>();
			boolean langEnglFlag = examDTO.getLangIdCode().equals(Constant.DEFAULT_LANG);			
			for(IExam exam1: examList) {
				Test test = examSeedData.getTestByTestId(exam1.getTestId());
				if(test.getTestId().trim().equalsIgnoreCase(Constant.AIRBRAKES)) {
					examDTO.setAirbrakes(true);
				}
				ExamTestLang examTestLang = new ExamTestLang();
				TestLang testLang = new TestLang();
				testLang.setLangId(examDTO.getLangIdCode());
				testLang.getTlPrimaryKey().setTestId(String.valueOf(exam1.getTestId()));
				testLang = examSeedData.getTestLangByTestIdLangId(testLang);
				examTestLang.setExamId(exam1.getExamId());
				if(testLang == null) {
					examTestLang.setTestLangName(test.getTestName());
					examTestLang.setTestId(test.getTestId());
				} else {
					examTestLang.setTestLangName(testLang.getTestLangName());
					examTestLang.setTestId(testLang.getTlPrimaryKey().getTestId());
				}
				List<String> manuallyPrinted = Arrays.asList(
						Constant.VIEW_TEST_STATUS, Constant.PRINT_TEST_STATUS, Constant.REPRINT_TEST_STATUS, 
						Constant.VIEW_ANSWER_KEY_STATUS, Constant.PRINT_ANSWER_KEY_STATUS, Constant.REPRINT_ANSWER_KEY_STATUS );
				if (exam1.getTestId().equals(Constant.SIGN_TEST_ID) && langEnglFlag && app.getAudioVideoTestCode().equals(Constant.SINGLE_SPACE) ) {
					// Don't display sign test if English is selected or it is audio or video test.
				} else if(manuallyPrinted.contains(exam1.getCompletionReasonCode())) {
					// The test has been printed so we can't show it.
				} else {
					examTestLangList.add(examTestLang);
				}
			}
			examDTO.setExamTestLangList(examTestLangList);
		}
		else {
			examDTO.setErrorCode(examWL.getErrorCode());
		}
	}

	public IExam getExamById(int examId) {
		IExam exam = examSessionData.getExamByExamId(examId);
//		examService.getExamByExamId(examId);
		return exam;
	}
	/*
	 * This method's called to show the question corresponding to the exam id and question presented order.
	 */
	public void showQuestion(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		IApplication app = examSessionData.getApplication();
		exam = examSessionData.getExamByExamId(exam.getExamId());	
		examDTO.setTimedTest(false);
		examDTO.setPausedAllowed(true);
		examDTO.setQuitAllowed(true);
		examDTO.setProgressBarAllowed(true);
		
		if(exam.getQuickPassFailFlag().trim().equals(Constant.YES)){
			Test test = examSeedData.getTestByTestId(exam.getTestId());
			if (test.getQuickPassInd().equals(Constant.YES) || test.getQuickFailInd().equals(Constant.YES)) {
				examDTO.setProgressBarAllowed(false);
			}
		}		
		int allowedPauseCount = Integer.parseInt(examSeedData.getThresholdValue(Constant.PAUSE_THRESHOLD).trim());
		if(!app.getPauseCount().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
			int pauseCount = Integer.parseInt(app.getPauseCount());
			if(pauseCount >= allowedPauseCount) {
				examDTO.setPausedAllowed(false);
			}
		}
		String officeType = examSeedData.getOfficeTypeByIPAddress(examDTO.getWorkstationId().trim());
		if(officeType!=null && officeType.trim().equals(Constant.OFFICE_TYPE_DS) || officeType!=null && officeType.trim().equals(Constant.OFFICE_TYPE_OL)){
			examDTO.setPausedAllowed(false);
		}
		
		if(exam.getRemainingTime()>0) {
			examDTO.setTimedTest(true);	
			examDTO.setQuitAllowed(false);
			setTimedTestRemainderTime(examDTO, exam.getRemainingTime(), officeType);
		}
		
		int order = examDTO.getQuestionPresentedOrder();
		QuesAnsw quesAnsw = examSessionData.getQuestionAnswers(exam.getExamId(), order);
		
		examDTO.setAnsweredQuestions(examSessionData.getAnswerCountForProgressBar());
		examDTO.setTotalQuestions(examSessionData.getQuestionCountForProgressBar());
		
		examDTO.setQuestionPresentedOrder(quesAnsw.getOrder());
		examDTO.setSkipped(quesAnsw.isSkipped());
		examDTO.setSkippedThreeTimes(quesAnsw.isSkippedThreeTimes());
		examDTO.setQuesAnswAfterPreTierConversion(quesAnsw);
		
		examDTO.setAudioAllowed(false);
		examDTO.setVideoAllowed(false);
		if(app.getAudioVideoTestCode().equalsIgnoreCase(AudioVideoConstant.AUDIO_ONLY)) {
			examDTO.setAudioAllowed(true);
		}
		else if(app.getAudioVideoTestCode().equalsIgnoreCase(AudioVideoConstant.VIDEO_ONLY)) {
			examDTO.setVideoAllowed(true);
		}
		else if(app.getAudioVideoTestCode().equalsIgnoreCase(AudioVideoConstant.AUDIO_VIDEO)) {
			examDTO.setAudioAllowed(true);
			examDTO.setVideoAllowed(true);
		}		
		examDTO.setQuesAnswAfterPreTierConversion(quesAnsw);

//		if(examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio() != null && examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio().trim().length() > 0){
//			examDTO.getQuesAnsw().getQuestionLang().setQuestionAudio(examSeedData.getAudioFileServerURL() + Constant.FORWARD_SLASH + examDTO.getLangIdCode() + Constant.FORWARD_SLASH + examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio());
//		}
//		for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: examDTO.getQuesAnsw().getAnswerList()) {
//			if( ans.getAnswerAudio() != null &&  ans.getAnswerAudio().trim().length() > 0){
//				ans.setAnswerAudio(examSeedData.getAudioFileServerURL() + Constant.FORWARD_SLASH +  ans.getAnswerAudio());
//			}
//		}
		
		// code to fix the audio media URL
		String oisURL = examSeedData.getAudioFileL1ServerURL(app.getOfficeId());
		if(examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio() != null && examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio().trim().length() > 0){
			examDTO.getQuesAnsw().getQuestionLang().setQuestionAudio(Constant.HTTPS + oisURL + examDTO.getQuesAnsw().getQuestionLang().getQuestionAudio());
		}
		for(gov.ca.dmv.AKT.presentation.Beans.Answer ans: examDTO.getQuesAnsw().getAnswerList()) {
			if( ans.getAnswerAudio() != null &&  ans.getAnswerAudio().trim().length() > 0){
				ans.setAnswerAudio(Constant.HTTPS + oisURL +  ans.getAnswerAudio());
			}
		}
	}
	
	private void setTimedTestRemainderTime(ExamDTO examDTO, Integer remainingTime, String officeType) {
		long timeLeftForGradingTest = remainingTime;
		
		
		Integer timeForReminder = 0;
		if(officeType.trim().equals(Constant.OFFICE_TYPE_OL)){
			timeForReminder = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.OL_TIME_LIMIT_REMINDER);
			timeForReminder = timeForReminder!=null?timeForReminder:TimeLimitTypeConstant.DEFAULT_OL_TIME_LIMIT_REMINDER;
		}
		if(officeType.trim().equals(Constant.OFFICE_TYPE_CHP)){
			timeForReminder = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.CHP_TIME_LIMIT_REMINDER);
			timeForReminder = timeForReminder!=null?timeForReminder:TimeLimitTypeConstant.DEFAULT_CHP_TIME_LIMIT_REMINDER;
		}
		
		
		Integer timeForReminderDuration = 0;
		if(officeType.trim().equals(Constant.OFFICE_TYPE_OL)){
			timeForReminderDuration = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.OL_TIME_LIMIT_REMINDER_DURATION);
			timeForReminderDuration = timeForReminderDuration!=null?timeForReminderDuration:TimeLimitTypeConstant.DEFAULT_OL_TIME_LIMIT_REMINDER_DURATION;
		}
		if(officeType.trim().equals(Constant.OFFICE_TYPE_CHP)){
			timeForReminderDuration = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.CHP_TIME_LIMIT_REMINDER_DURATION);
			timeForReminderDuration = timeForReminderDuration!=null?timeForReminderDuration:TimeLimitTypeConstant.DEFAULT_CHP_TIME_LIMIT_REMINDER_DURATION;
		}
			
		long timeLeftForReminder = timeLeftForGradingTest - timeForReminder ;
		
		if(timeLeftForReminder > Constant.ZERO) {
			examDTO.setTimeLeftForReminder(timeLeftForReminder*TimeLimitTypeConstant.MILLISECONDS);
			examDTO.setTimeDurationFor15MinRemainder(timeForReminderDuration*TimeLimitTypeConstant.MILLISECONDS);			
		}
		examDTO.setTimeLeftForGradingTest(timeLeftForGradingTest*TimeLimitTypeConstant.MILLISECONDS);
	}

	/*
	 * This method is called to fail an exam due to inactivity
	 */
	public void failExam(ExamDTO examDTO) {
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		String forceFail = forceFailRegistryService.getForceFailRequest(exam.getExamId());
		if(forceFail != null && forceFail.equalsIgnoreCase(Constant.FORCE_FAIL)) {
			examDTO.setErrorCode(ErrorCode.FORCE_FAILED);
		} else {
			IErrorWL errWL = sessionService.endSession(exam.getSessionId());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExam exm = examSessionData.getExamAfterTimeout(exam.getExamId(),examDTO.getQuestionPresentedTime());
				IErrorWL errorWL = examService.failExam(exm);
				if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IExamHistory examHistory = new ExamHistory();
					examHistory.setApplicationId(exm.getApplicationId());
					examHistory.setEaseTestId(exm.getEaseTestId());
					IBooleanWL boolWL = applicationService.markFailed(examHistory);
					IApplication app = examSessionData.getApplication();
					examDTO.setApplicationType(app.getApplicationType());
					if(boolWL.getErrorCode() == ErrorCode.NO_ERROR) {
						if(boolWL.isFlag() && !app.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_CHP)) {
							examService.cloneStubExam(exm);
						}
						IErrorWL erroWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.SINGLE_SPACE, 
									                                 Constant.TIME_OUT, String.valueOf(exam.getExamId()), getUserId());
						examDTO.setErrorCode(erroWL.getErrorCode());
					} else {
						examDTO.setErrorCode(boolWL.getErrorCode());
					}
				} else {
					examDTO.setErrorCode(errorWL.getErrorCode());
				}			
			}
			else {
				examDTO.setErrorCode(errWL.getErrorCode());
			}
		}
	}

	/*
	 * This method is called to grade the answer submitted by the applicant
	 */
	public void gradeAnswer(AnswerDTO answerDTO) {
		SubmitAnswer submitAnswer = answerDTO.getSubmitAnswerAfterBusTierConversion();
		answerDTO.setAppTypeES(false);
		IApplication app = examSessionData.getApplication();
		if(app.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_FO)) {
			answerDTO.setAppTypeES(true);
		}
		String forceFail = forceFailRegistryService.getForceFailRequest(submitAnswer.getExamId());
		if(forceFail != null && forceFail.equalsIgnoreCase(Constant.FORCE_FAIL)) {
			answerDTO.setErrorCode(ErrorCode.FORCE_FAILED);
			forceFailRegistryService.removeForceFailRequest(submitAnswer.getExamId());
			/*IExam exam = examSessionData.getExamAfterForceFail(submitAnswer.getExamId());
			IErrorWL errWL = examService.updateExam(exam);
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				forceFailRegistryService.removeForceFailRequest(submitAnswer.getExamId());
			}
			else {
				answerDTO.setErrorCode(errWL.getErrorCode());
			}*/
		}
		else {
			IExamQuestion eq = examSessionData.getExamQuestionAfterGrading(submitAnswer);
			//Check to see if the answer is incorrect, so that the missed question can be presented to the applicant.
			answerDTO.setIncorrectAnswer(false);
			if(eq.getAnswerStatus().trim().equalsIgnoreCase(Constant.NO)) {
				answerDTO.setIncorrectAnswer(true);
				setMissedQuestion(answerDTO, submitAnswer);
			}
			IErrorWL errWL = examService.submitAnswer(eq);
			answerDTO.setErrorCode(errWL.getErrorCode());
		}
	}
	
	private void setMissedQuestion(AnswerDTO answerDTO, SubmitAnswer submitAnswer) {
		QuesAnsw quesAnsw = examSessionData.getQuestionAnswersForMissedQuestion(submitAnswer.getExamId(), submitAnswer.getQuestionPresentedOrder());
		gov.ca.dmv.AKT.presentation.Beans.QuestionLang ql = new gov.ca.dmv.AKT.presentation.Beans.QuestionLang();
		ql.setQuestionText(quesAnsw.getQuestionLang().getQuestionText());
		ql.setSignImage(quesAnsw.getQuestionLang().getSignImage());
		answerDTO.setQuestionLang(ql);
		List<gov.ca.dmv.AKT.presentation.Beans.Answer> answerList = new ArrayList<gov.ca.dmv.AKT.presentation.Beans.Answer>();
		for(gov.ca.dmv.AKT.integration.BeansImpl.Answer ans: quesAnsw.getAnswerList()) {
			gov.ca.dmv.AKT.presentation.Beans.Answer answer = new gov.ca.dmv.AKT.presentation.Beans.Answer();
			answer.setAnswerText(ans.getAnswerText());
			answer.setAnswerStatus(Constant.DISTRACTED);
			answer.setSignImage(ans.getSignImage());
			if(ans.getCorrectAnswerInd().trim().equalsIgnoreCase(Constant.CORRECT))
				answer.setAnswerStatus(Constant.CORRECT);
			else if(ans.getAnswerGenId().equals(submitAnswer.getAnswerGenId()))
				answer.setAnswerStatus(Constant.INCORRECT);
			answerList.add(answer);
		}
		HandbookRef hb = new HandbookRef();
		if(examSeedData.getHandbookRefByHandbookRef(quesAnsw.getQuestionLang().getHandbookRef(), quesAnsw.getQuestionLang().getLangId()) != null)
			hb.setHandbookSectionName(examSeedData.getHandbookRefByHandbookRef(quesAnsw.getQuestionLang().getHandbookRef(), quesAnsw.getQuestionLang().getLangId()).getHandbookSectionName());
		answerDTO.setHandbookRef(hb);
		answerDTO.setAnswerList(answerList);
	}

	/*
	 * This method is used for updating the exam history and creating a stub exam in case of a failed exam. 
	 * This method is called by the gradeExam() method and the quitExam() method.
	 */
	private IErrorWL updateExamHistAndCloneStub(IExam exam) {
		IErrorWL errWL = new ErrorWL();
		errWL.setErrorCode(ErrorCode.NO_ERROR);
		IApplication application = examSessionData.getApplication();
		IExamHistory examHistory = new ExamHistory();
		examHistory.setApplicationId(exam.getApplicationId());
		examHistory.setEaseTestId(exam.getEaseTestId());
		IExamHistoryWL ehWL = applicationService.getExamHistory(examHistory);
		if(ehWL.getErrorCode() == ErrorCode.NO_ERROR) {
			examHistory = ehWL.getExamHistory();
			int aktStatusIndicator = Constant.ZERO;
			int easeStatusIndicator = Constant.ZERO;
			if(!examHistory.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE))
				aktStatusIndicator = Integer.parseInt(examHistory.getAktStatusIndicator());
			if(!examHistory.getEaseStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE))
				easeStatusIndicator = Integer.parseInt(examHistory.getEaseStatusIndicator());
			aktStatusIndicator++;
			examHistory.setAktStatusIndicator(String.valueOf(aktStatusIndicator));
			examHistory.setLastModusername(getUserId());
			examHistory.setLastModUserTime(new Date());
			examHistory.setAktUpdatedTimestamp(new Date());
			IErrorWL erWL = applicationService.updateExamHistory(examHistory);
			if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
				if(aktStatusIndicator + easeStatusIndicator < 3 && 
				   !application.getApplicationStatusCode().equalsIgnoreCase(Constant.PROVISIONAL) && 
				   !application.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_CHP)) {
					IErrorWL eWL = examService.cloneStubExam(exam);
					if(eWL.getErrorCode() != ErrorCode.NO_ERROR) {
						errWL.setErrorCode(eWL.getErrorCode());
					}
				}
				else if(!application.getApplicationStatusCode().equalsIgnoreCase(Constant.PROVISIONAL)){
					//TODO Commented by Adheesh G. It was deleting all the pending tests after the quit.
					/*IExamListWL examsWL = examService.loadExams(application.getApplicationId());
					if(examsWL.getErrorCode() == ErrorCode.NO_ERROR) {
						
						for(IExam exam1: examsWL.getExamList()) {
							IErrorWL errrWL = examService.removeStub(exam1);
							if(errrWL.getErrorCode() != ErrorCode.NO_ERROR) {
								errWL.setErrorCode(errrWL.getErrorCode());
								break;
							}
						}
					}
					else {
						errWL.setErrorCode(examsWL.getErrorCode());
					}*/
				}
			}
			else {
				errWL.setErrorCode(erWL.getErrorCode());
			}
		}
		else {
			errWL.setErrorCode(ehWL.getErrorCode());
		}
		return errWL;
	}
	
	private IStringWL gradeExamHelper(IExam exam, boolean olTimedOut) {
		String result = null;
		IStringWL strWL = new StringWL();
		// To check if this is the last question in the Exam or olTime test timeout
		if(exam.getQuestionAnsweredCount() >= exam.getExamQuestionNumber() || olTimedOut) {
			if(hasReachedQuickPassThreshold(exam)) {
				result = Constant.PASS;
				exam = examSessionData.getExamAfterGrading(exam.getExamId(), Constant.PASS, Constant.NORMAL);
				IErrorWL errWL = examService.updateExam(exam);
				if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
					strWL.setErrorCode(ErrorCode.PASS_FAIL_ERROR);
				}
			}
			else {
				result = Constant.FAIL;
				exam = examSessionData.getExamAfterGrading(exam.getExamId(), Constant.FAIL, Constant.NORMAL);
				if(olTimedOut) {
					exam = examSessionData.getExamAfterGrading(exam.getExamId(), Constant.FAIL, Constant.TIMED_TEST_TIME_OUT);
				}
				IErrorWL errWL = examService.updateExam(exam);
				if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
					strWL.setErrorCode(ErrorCode.PASS_FAIL_ERROR);
				}
			}
		}
		else if(exam.getQuickPassFailFlag().equalsIgnoreCase(Constant.YES) && isQuickPassFailFlagOnTest(exam) &&
				   exam.getRemainingTime()==0 && !olTimedOut) {
					result = gradeQuickPassFailExam(exam);
					if(result != null && result.equals(Constant.PASS)) {
						exam = examSessionData.getExamAfterGrading(exam.getExamId(), Constant.PASS, Constant.NORMAL);
						IErrorWL errWL = examService.updateExam(exam);
						if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
							strWL.setErrorCode(ErrorCode.PASS_FAIL_ERROR);
						}
					}
					else if(result != null && result.equals(Constant.FAIL)) {
						exam = examSessionData.getExamAfterGrading(exam.getExamId(), Constant.FAIL, Constant.NORMAL);
						IErrorWL errWL = examService.updateExam(exam);
						if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
							strWL.setErrorCode(ErrorCode.PASS_FAIL_ERROR);
						}
					}
				}
		strWL.setString(result);
		return strWL;
	}
	
	private boolean isQuickPassFailFlagOnTest(IExam exam) {
		Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
		if(test.getQuickPassInd().equalsIgnoreCase(Constant.YES) || test.getQuickFailInd().equalsIgnoreCase(Constant.YES)) {
			return true;
		}
		else {
			return false;
		}		
	}

	private String gradeQuickPassFailExam(IExam exam) {
		Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
		if(test.getQuickPassInd().equalsIgnoreCase(Constant.YES)) {
			if(hasReachedQuickPassThreshold(exam)) {
				return Constant.PASS;
			}
		}
		if(test.getQuickFailInd().equalsIgnoreCase(Constant.YES)) {
			if(hasReachedQuickFailThreshold(exam)) {
				return Constant.FAIL;
			}
		}
		return null;
	}
	
	private boolean hasReachedQuickPassThreshold(IExam exam) {
		if(exam.getCorrectQuestionCount() >= (exam.getExamQuestionNumber() - exam.getMaxIncorrectNumber())) {
			return true;
		}
		return false;
	}
	
	private boolean hasReachedQuickFailThreshold(IExam exam) {
		if(exam.getIncorrectAnswerCount() > exam.getMaxIncorrectNumber()) {
			return true;
		}
		return false;
	}
	
	/*
	 * This method is called to grade the exam
	 */
	public void gradeExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		Integer examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExam exam = examSessionData.getExamByExamId(examId);
		examDTO.setTimedTest(false);
		examDTO.setOfficeId(exam.getOfficeId());
		if(exam.getRemainingTime()>0){
			examDTO.setTimedTest(true);
		}
		IStringWL strWL = gradeExamHelper(exam, examDTO.isTimedTestTimedOut());
		examDTO.setErrorCode(strWL.getErrorCode());
		if(strWL.getErrorCode() == ErrorCode.NO_ERROR) {
			String result = strWL.getString();
			if(result != null && result.equalsIgnoreCase(Constant.FAIL)) {
				IErrorWL errWL = updateExamHistAndCloneStub(exam);
				examDTO.setErrorCode(errWL.getErrorCode());
				if(examDTO.getErrorCode() == ErrorCode.NO_ERROR) {
					examDTO.setProvisional(examSessionData.getApplication().getApplicationStatusCode().trim().equalsIgnoreCase(Constant.PROVISIONAL));
					examDTO.setResult(result);
				}
			}
			else {
				examDTO.setResult(result);
				if(result != null && result.equalsIgnoreCase(Constant.PASS))
				{
					if(exam.getSignTestFlag().equalsIgnoreCase(Constant.YES)) {
						examDTO.setSignExam(true);
						IApplication app = examSessionData.getApplication();
						app.setSignTestSatisfiedFlag(Constant.YES);
						IErrorWL errWL = applicationService.updateApplication(app);
						examDTO.setErrorCode(errWL.getErrorCode());
						if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IExamListWL examsWL = examService.loadExams(app.getApplicationId());
							if (examsWL.getErrorCode() != ErrorCode.NULL_EXAM_LIST){
								examDTO.setErrorCode(examsWL.getErrorCode());
							}
//							examDTO.setErrorCode(examsWL.getErrorCode());
							if(examsWL.getErrorCode() == ErrorCode.NO_ERROR) {
								for(IExam exam1: examsWL.getExamList()) {
									Test test = examSeedData.getTestByTestId(exam1.getTestId());
									if(test.getRequiredSignTest().equalsIgnoreCase(Constant.YES)) {
										examDTO.setReqSignExamId(exam1.getExamId());
										break;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	//This method is called by the batch process to fail any incomplete exams//
	public void failIncompleteExams(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExamListWL elWL = examService.getIncompleteExams(examDTO.getOfficeId(), examDTO.getApplicationType());
		if(elWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<IExam> incompleteExamList = elWL.getExamList(); 
			examDTO.setExamListAfterPreTierConversion(incompleteExamList);
			for(IExam exam: incompleteExamList) {
				IErrorWL errWL = examService.failExamBatch(exam.getExamId());
				if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
					String oldStatus = exam.getCompletionReasonCode().trim();
					String newStatus = Constant.BATCH_FAIL;
					if (oldStatus.equals(Constant.PAUSE)) {
						IErrorWL erWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, oldStatus, newStatus, 
															   String.valueOf(exam.getExamId()), examDTO.getUserId());
						examDTO.setErrorCode(erWL.getErrorCode());
					}
				}
				if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IErrorWL errorWL = sessionService.endSession(exam.getSessionId());
					if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IExamHistory examHistory = new ExamHistory();
						examHistory.setApplicationId(exam.getApplicationId());
						examHistory.setEaseTestId(exam.getEaseTestId());
						IErrorWL erWL = applicationService.markFailedBatch(examHistory);
						examDTO.setErrorCode(erWL.getErrorCode());
//						if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
//							IErrorWL eWL = examService.removePausedExam(exam.getExamId());
//							if(eWL.getErrorCode() != ErrorCode.NO_ERROR) {
//								examDTO.setErrorCode(eWL.getErrorCode());
//								break;
//							}
//						}
//						else {
//							examDTO.setErrorCode(erWL.getErrorCode());
//							break;
//						}
					}
					else {
						examDTO.setErrorCode(errorWL.getErrorCode());
						break;
					}
				}
				else {
					examDTO.setErrorCode(errWL.getErrorCode());
					break;
				}
			}
		}
		else {
			examDTO.setErrorCode(elWL.getErrorCode());
		}
	}
	
	private void loadSessionData(Integer examId) {
		IExamQuestionListWL eWL = examService.getExamQues(examId);
		IExamWL examWL = examService.getExamByExamId(examId);
		List<IExamQuestion> eqList = eWL.getExamQuestionList();
		List<IExamAnswer>   eaList = new ArrayList<IExamAnswer>();
		List<QuestionLang> qlList = new ArrayList<QuestionLang>();
		List<Answer>      ansList = new ArrayList<Answer>();
		IExam exam = examWL.getExam();
		List<IExamQuestion> skippedExamQuestions = new ArrayList<IExamQuestion>();
		for(IExamQuestion eq: eqList) {
			if(eq.getAnswerStatus().trim().length() > Constant.ZERO && eq.getAnswerStatus().trim().equalsIgnoreCase(Constant.SKIPPED)) {
				skippedExamQuestions.add(eq);
			}
			List<IExamAnswer> eaList2 = examService.getExamAnswByExamIdAndQuesGenId(eq);
			eaList.addAll(eaList2);
			IQuesAnswWL qaWL = testService.getQuesAnswByAutoGenId(eq.getQuestionGenId());
			QuesAnsw qa = qaWL.getQuesAnsw();
			qlList.add(qa.getQuestionLang());
			ansList.addAll(qa.getAnswerList());
		}
		examSessionData.setAnswerList(ansList);
		examSessionData.setExam(exam);
		examSessionData.setExamAnswerList(eaList);
		examSessionData.setExamQuestionList(eqList);
		examSessionData.setQuestionLangList(qlList);
		examSessionData.setDisconnectedExam(examId);
		examSessionData.setSkippedExamQuestionList(skippedExamQuestions);
	}

	/*
	 * This method is called to resume the exam by updating resume time in pause restart event 
	 */
	public void resumeExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		loadSessionData(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		IExam examSession = examSessionData.getExam();
		if (examSessionData.getSession() != null) {
			examSession.setSessionId(examSessionData.getSession().getSessionId());
		}
		IExam exam = new Exam();
		exam.setExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		int answeredCount = examSession.getQuestionAnsweredCount();
		exam.setQuestionAnsweredCount(answeredCount);
		List<IExam> examList = new ArrayList<IExam>();
		examList.add(exam);
		examDTO.setExamListAfterPreTierConversion(examList);
		IErrorWL erWL = sessionService.reset(examSession.getSessionId(),Constant.SESSION_TESTING);
		if(erWL.getErrorCode() != ErrorCode.NO_ERROR) {
			examDTO.setErrorCode(erWL.getErrorCode());
		}			
	}
	
	/*
	 * If examSessionData is present, return the count of skipped questions
	 */
	public int getSkippedQuestionsCount(){
		if(examSessionData != null){
			return examSessionData.getSkippedQuestionsCount();
		}
		else{
			return 0;
		}
	}
	
	/*
	 * This method is called to unpause an exam by the technician (change the completion reason code in the exam record).
	 */
	public void unpauseExam(ExamDTO examDTO) {
		IExamWL exWL = examService.getExamByExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		String userId = examDTO.getUserId();
		examDTO.setErrorCode(exWL.getErrorCode());
		if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = exWL.getExam();
			exam.setCompletionReasonCode(Constant.RESTART);
			exam.setLastModUserTime(new Date());
			exam.setLastModUsername(getUserId());
			IErrorWL errWL = examService.updateExam(exam);
			examDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.PAUSE, Constant.RESTART, 
						                                  String.valueOf(exam.getExamId()), userId);
				examDTO.setErrorCode(errorWL.getErrorCode());
			}
		}
	}

	/*
	 * This method is called to force fail an exam.
	 */
	public void forceFailExam(ExamDTO examDTO) {
		/*
		 * examService.forceFailExam() is the same as examService.failExam() mentioned in the sequence diagram.
		 */
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		forceFailRegistryService.addForceFailRequest(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		IExamWL examWL = examService.getExamByExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		examDTO.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			IExamHistory examHistory = new ExamHistory();
			examHistory.setApplicationId(exam.getApplicationId());
			examHistory.setEaseTestId(exam.getEaseTestId());
			/*
			 * applicationService.markForceFailed() is the same as applicationService.markFailed() in the seq diagram.
			 */
			IErrorWL erWL = applicationService.markForceFailed(examHistory);
			examDTO.setErrorCode(erWL.getErrorCode());
			if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExamHistoryWL ehWL = applicationService.getExamHistory(examHistory);
				examDTO.setErrorCode(ehWL.getErrorCode());
				if(ehWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IExamHistory examHistory2 = ehWL.getExamHistory();
					IErrorWL errWL = sessionService.endSession(exam.getSessionId());
					examDTO.setErrorCode(errWL.getErrorCode());
					if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IApplicationWL appWL = applicationService.getApplication(exam.getApplicationId());
						examDTO.setErrorCode(appWL.getErrorCode());
						if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IApplication app = appWL.getApplication();
							IErrorWL errorWL = null;
							if(Integer.parseInt(examHistory2.getAktStatusIndicator()) + 
							   Integer.parseInt(examHistory2.getEaseStatusIndicator()) < 3) {
								// For CHP, customer need to wait at least 5 day to take the same test again.
								if (!app.getApplicationType().equalsIgnoreCase(Constant.APP_TYPE_CHP)) {
									errorWL = examService.cloneStubExam(exam);
									examDTO.setErrorCode(errorWL.getErrorCode());
									if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
										updateForceFailExam(examDTO, exam);
									}
								} else {
									updateForceFailExam(examDTO, exam);
								}
							} else {
								updateForceFailExam(examDTO, exam);
							}
						}
					}
				}
			}
		}
	}
	
	private void updateForceFailExam(ExamDTO examDTO, IExam exam) {
		exam.setCompletionReasonCode(Constant.FORCE_FAIL);
		exam.setExamEndTime(new Date());
		exam.setPassFailIndicator(Constant.FAIL);
		IErrorWL errorWL = examService.saveExam(exam);
		if(errorWL.getErrorCode() != ErrorCode.NO_ERROR) {
			examDTO.setErrorCode(errorWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get the list of test that can be printed by F.O. Technician.
	 */
	public void getTestList(TestDTO testDTO) {
		testDTO.setErrorCode(ErrorCode.NO_ERROR);
		List<gov.ca.dmv.AKT.integration.BeansImpl.Lang> langList = examSeedData.getLangList();
		String group = testDTO.getGroup();
		List<Test> testList = examSeedData.getNonCDLTests(group);
		testDTO.setTestListAfterPreTierConversion(testList);
		testDTO.setLangListAfterPreTierConversion(langList);
	}

	/*
	 * This method is called to get a list of eligible quick pass fail.
	 */
	public void getEligibleQPFTestList(TestDTO testDTO) {
		testDTO.setErrorCode(ErrorCode.NO_ERROR);
		ITestListWL qpfTestListWL = testService.getEligibleQPFTestList();
		if(qpfTestListWL.getErrorCode() == ErrorCode.NO_ERROR) {
			testDTO.setTestListAfterPreTierConversion(qpfTestListWL.getTestList());
		}
		else {
			testDTO.setErrorCode(qpfTestListWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get the display message at the end of an exam.
	 */
	public void getEndExamMsg(ExamDTO examDTO) {
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		getExams(examDTO);
		if(examDTO.getExamTestLangList() == null || examDTO.getExamTestLangList().size() == Constant.ZERO) {
			IErrorWL errWL = sessionService.endSession(exam.getSessionId());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IApplication application = examSessionData.getApplication();
							IExam exam1 = examSessionData.getExamByExamId(exam.getExamId());
							if(exam1.getPassFailIndicator().equalsIgnoreCase(Constant.PASS))
								examDTO.setErrorCode(ErrorCode.PASS_EXAM);
							else if(application.getOsFlag().equalsIgnoreCase(Constant.YES))
								examDTO.setErrorCode(ErrorCode.OUT_OF_STATE);
							else if(Constant.expiresIn30Days(application.getDlExpirationDate())) 
								examDTO.setErrorCode(ErrorCode.DL_EXPIRES_WITHIN_30_DAYS);
							else
								examDTO.setErrorCode(ErrorCode.NONE);
			}
			else {
				examDTO.setErrorCode(errWL.getErrorCode());
			}
		}
	}

	/*
	 * This method is called to fail an exam and end the session
	 */
	public void quitExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);
		String forceFail = forceFailRegistryService.getForceFailRequest(exam.getExamId());
		if(forceFail != null && forceFail.equalsIgnoreCase(Constant.FORCE_FAIL)) {
			examDTO.setErrorCode(ErrorCode.FORCE_FAILED);
		} else {
			IExam exm = examSessionData.getExamAfterQuit(exam.getExamId());
			examDTO.setTimedTest(false);
			if(exm.getRemainingTime()>0){
				examDTO.setTimedTest(true);
			}
			IErrorWL errWL = examService.failExamQuit(exm);
			examDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IErrorWL errorWL = sessionService.endSession(exm.getSessionId());
				examDTO.setErrorCode(errorWL.getErrorCode());
				if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
					updateExamHistAndCloneStub(exm);
					IErrorWL erroWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.SINGLE_SPACE, 
															 Constant.QUIT, String.valueOf(exam.getExamId()), getUserId());
					examDTO.setErrorCode(erroWL.getErrorCode());
				}
			}
		}
	}

	
	/*
	 * This method is called to pause an exam from FO
	 */
	public void pauseExamFO(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExamWL examWL = examService.getExamByExamId(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());
		examDTO.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			IErrorWL erWL = applicationService.incrementPauseCountFO(exam.getApplicationId());
			examDTO.setErrorCode(erWL.getErrorCode());
			if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {				
				forceFailRegistryService.addForceFailRequest(examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId());			
				exam.setCompletionReasonCode(Constant.PAUSE);
				exam.setLastModUsername(getUserId());
				exam.setLastModUserTime(new Date());
				IErrorWL errrWL = examService.saveExam(exam);
				examDTO.setErrorCode(errrWL.getErrorCode());
				if(errrWL.getErrorCode() == ErrorCode.NO_ERROR) {					
					IErrorWL eWL = sessionService.endSession(exam.getSessionId());
					examDTO.setErrorCode(eWL.getErrorCode());
					if(eWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IErrorWL erroWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.SINGLE_SPACE, 
																 Constant.PAUSE, String.valueOf(exam.getExamId()), getUserId());
						examDTO.setErrorCode(erroWL.getErrorCode());
					}
				}
			}			
		}
	}
	
	/*
	 * This method is called to pause an exam
	 */
	public void pauseExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExam exam = examDTO.getExamListAfterBusTierConversion().get(Constant.ZERO);
//		ExamAndVaultId examVault = new ExamAndVaultId();
//		examVault.setExam();
//		examVault.setVaultId(examDTO.getVault().getVaultId());
		String forceFail = forceFailRegistryService.getForceFailRequest(exam.getExamId());
		if(forceFail != null && forceFail.equalsIgnoreCase(Constant.FORCE_FAIL)) {
			examDTO.setErrorCode(ErrorCode.FORCE_FAILED);
		} else {
			Date questionPresentedTime = examDTO.getQuestionPresentedTime();
			IErrorWL errWL = examService.updateExam(examSessionData.getExamAfterPause(exam.getExamId(),questionPresentedTime));
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IErrorWL erWL = applicationService.incrementPauseCount(exam.getApplicationId());
				if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IErrorWL eWL = sessionService.endSession(exam.getSessionId());
					examDTO.setErrorCode(eWL.getErrorCode());
					if(eWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IErrorWL erroWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.SINGLE_SPACE, 
																 Constant.PAUSE, String.valueOf(exam.getExamId()), getUserId());
						examDTO.setErrorCode(erroWL.getErrorCode());
					}
				}
				else {
					examDTO.setErrorCode(erWL.getErrorCode());
				}
			}
			else {
				examDTO.setErrorCode(errWL.getErrorCode());
			}
		}
	}
	
	private List<Integer> prepareAppIds(List<IApplication> appList) {
		List<Integer> idList = new ArrayList<Integer>();
		if(appList != null && appList.size() > Constant.ZERO) {
			for(IApplication app: appList) {
				idList.add(app.getApplicationId());
			}
		}
		return idList;
	}
	
	private Integer getVaultIdFromAppList(List<Application> appList, Integer appId) {
		for(IApplication app: appList) {
			if(app.getApplicationId().equals(appId)) {
				return app.getVaultId();
			}
		}
		return null;
	}

	/*
	 * This method is called to submit the quick pass fail choices made by the HQ user to set the tests with 
	 * quick pass fail flag on/off
	 */
	public void submitQPFChoices(TestDTO testDTO) {
		testDTO.setErrorCode(ErrorCode.NO_ERROR);
		IErrorWL errWL = testService.updateQPFTestList(testDTO.getTestListAfterBusTierConversion());
		if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
			testDTO.setErrorCode(errWL.getErrorCode());
		}
	}

	private void adjustRemainingTimeForDisconnectedSession(IExam exam,ExamDTO examDTO){
		Integer examTimeRemaining = exam.getRemainingTime();
		Test test = examSeedData.getTestByTestId(exam.getTestId().trim());
		Integer examCalculatedTime = test.getTimeLimit()*TimeLimitTypeConstant.SECONDS*TimeLimitTypeConstant.MILLISECONDS;
		IExamQuestionListWL eqWL = examService.getExamQues(exam.getExamId()); 
		if(eqWL.getErrorCode()==ErrorCode.NO_ERROR){
			List<IExamQuestion> examQuestionList = eqWL.getExamQuestionList();
			for(IExamQuestion examQues: examQuestionList)
			{
				Integer answerElapsedTime = examQues.getAnswerElapsedTime();
				examCalculatedTime -=  answerElapsedTime;
				if(examCalculatedTime<0){
					examCalculatedTime = 0;
					break;
				}
			}
			examCalculatedTime = examCalculatedTime/TimeLimitTypeConstant.MILLISECONDS;
			examTimeRemaining = examTimeRemaining<examCalculatedTime?examTimeRemaining:examCalculatedTime;
			exam.setRemainingTime(examTimeRemaining);
		}
		else{
			examDTO.setErrorCode(eqWL.getErrorCode());
		}
		
	}
	/*
	 * This method is called to resume a disconnected exam
	 */
	public void resumeExam2(ExamDTO examDTO) {
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExamWL examWL = examService.getExamByExamId(examId);
		IExam exam = null;
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			exam = examWL.getExam(); 
			IErrorWL erWL = sessionService.endSession(exam.getSessionId());
			if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
				
					if(exam.getRemainingTime()>0){
						adjustRemainingTimeForDisconnectedSession(exam,examDTO);
					}
					if(examDTO.getErrorCode() == ErrorCode.NO_ERROR){
							exam.setCompletionReasonCode(Constant.RESTART);
							exam.setLastModUserTime(new Date());
							exam.setLastModUsername(getUserId());
							IErrorWL errorWL = examService.updateExam(exam);
							examDTO.setErrorCode(errorWL.getErrorCode());
							if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
								IErrorWL errrWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.DISCONNECTED, 
										                                 Constant.RESTART, String.valueOf(exam.getExamId()), examDTO.getUserId());
								examDTO.setErrorCode(errrWL.getErrorCode());
							}
					}
			}
			else {
				examDTO.setErrorCode(erWL.getErrorCode());
			}
		}
		else {
			examDTO.setErrorCode(examWL.getErrorCode());
		}
	}

	/*
	 * This method is called to resume timed out exam
	 */
	public void resumeTimedOutExam(ExamDTO examDTO) {
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExamWL examWL = examService.getExamByExamId(examId);
		examDTO.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			exam.setCompletionReasonCode(Constant.RESTART);
			exam.setPassFailIndicator(Constant.SINGLE_SPACE);
			exam.setExamEndTime(Constant.defaultDate);
			exam.setLastModUsername(getUserId());
			Date currDate = new Date();
			exam.setLastModUserTime(currDate);
			IErrorWL errWL = examService.updateExam(exam);
			examDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExamHistory examHistory = new ExamHistory();
				examHistory.setApplicationId(exam.getApplicationId());
				examHistory.setEaseTestId(exam.getEaseTestId());
				IExamHistoryWL examHistWL = applicationService.getExamHistory(examHistory);
				examDTO.setErrorCode(examHistWL.getErrorCode());
				if(examHistWL.getErrorCode() == ErrorCode.NO_ERROR) {
					examHistory = examHistWL.getExamHistory();
					int aktStatusInd = Integer.parseInt(examHistory.getAktStatusIndicator());
					if (aktStatusInd > 0) {
						aktStatusInd = aktStatusInd - 1;
					}
					examHistory.setAktStatusIndicator(String.valueOf(aktStatusInd));
					examHistory.setAktUpdatedTimestamp(currDate);
					examHistory.setLastModUserTime(currDate);
					examHistory.setLastModusername(getUserId());
					IErrorWL errorWL = applicationService.updateExamHistory(examHistory);
					examDTO.setErrorCode(errorWL.getErrorCode());
					if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IErrorWL errrWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.TIME_OUT, 
								                                 Constant.RESTART, String.valueOf(exam.getExamId()), examDTO.getUserId());
						examDTO.setErrorCode(errrWL.getErrorCode());
					}
				}
			}
		}
	}
	
	/*
	 * This method is called to resume quit exam.
	 */
	public void resumeQuitExam(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExamWL examWL = examService.getExamByExamId(examId);
		examDTO.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			exam.setCompletionReasonCode(Constant.RESTART);
			exam.setPassFailIndicator(Constant.SINGLE_SPACE);
			exam.setExamEndTime(Constant.defaultDate);
			exam.setLastModUsername(getUserId());
			exam.setLastModUserTime(new Date());
			IErrorWL errWL = examService.saveExam(exam);
			examDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExamHistory examHistory = new ExamHistory();
				examHistory.setPastExamId(exam.getExamId());
				examHistory.setApplicationId(exam.getApplicationId());
				examHistory.setEaseTestId(exam.getEaseTestId());
				IExamHistoryWL examHistWL = applicationService.getExamHistory(examHistory);
				examDTO.setErrorCode(examHistWL.getErrorCode());
				if(examHistWL.getErrorCode() == ErrorCode.NO_ERROR) {
					examHistory = examHistWL.getExamHistory();
					int aktStatusInd = Integer.parseInt(examHistory.getAktStatusIndicator());
					if (aktStatusInd > 0) {
						aktStatusInd = aktStatusInd - 1;
					}
					examHistory.setAktStatusIndicator(String.valueOf(aktStatusInd));
					examHistory.setAktUpdatedTimestamp(new Date());
					IErrorWL errorWL = applicationService.updateExamHistory(examHistory);
					examDTO.setErrorCode(errorWL.getErrorCode());
					if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IErrorWL errrWL = auditService.saveAudit(Constant.EXAM_TABLE, Constant.COMPLETION_REASON_CODE, Constant.QUIT, Constant.RESTART, 
																 String.valueOf(exam.getExamId()), examDTO.getUserId());
						examDTO.setErrorCode(errrWL.getErrorCode());
					}
				}
			}
		}
	}
	
	/*
	 * This method is called to mark an active session as terminated.
	 */
	public void terminateActiveSession(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		int sessionId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getSessionId();
		if(examId!=0){
			IExamWL examWL = examService.getExamByExamId(examId);
			examDTO.setErrorCode(examWL.getErrorCode());
			if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IExam exam = examWL.getExam();
				if(exam.getSessionId()== sessionId){
					IErrorWL erWL = sessionService.reset(sessionId,Constant.SESSION_TERMINATED);
					if(erWL.getErrorCode() != ErrorCode.NO_ERROR) {
						examDTO.setErrorCode(erWL.getErrorCode());
					}		
				}
				else{
					examDTO.setErrorCode(ErrorCode.MISSING_SESSION);
				}
			}
		}
		else{
			IErrorWL erWL = sessionService.endSession(sessionId);
			if(erWL.getErrorCode() != ErrorCode.NO_ERROR) {
				examDTO.setErrorCode(erWL.getErrorCode());
			}	
		}
	}
	
	/*
	 * This method is called to mark all active session as terminated.
	 */
	public void terminateAllActiveSession(ApplicantDTO applicantDTO) {
		applicantDTO.setErrorCode(ErrorCode.NO_ERROR);
		IActiveSessionAndExamListWL actWL = sessionService.getActiveExams(applicantDTO.getOfficeId(), applicantDTO.getApplicationType());
		if(actWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ActiveSessionAndExam> activeList = actWL.getActiveSessionAndExamList();
			List<Applicant> applicantList = new ArrayList<Applicant>();
			if (activeList != null){
				for(ActiveSessionAndExam active: activeList) {
					IExam exam = active.getExam();
					ISession session = active.getSession();
					if(exam!=null){
						IErrorWL erWL = sessionService.reset(session.getSessionId(),Constant.SESSION_TERMINATED);
						if(erWL.getErrorCode() != ErrorCode.NO_ERROR) {
							applicantDTO.setErrorCode(erWL.getErrorCode());
						}
					}
					else{
						IErrorWL erWL = sessionService.endSession(session.getSessionId());
						if(erWL.getErrorCode() != ErrorCode.NO_ERROR) {
							applicantDTO.setErrorCode(erWL.getErrorCode());
						}	
					}
				}
			}
		}
	}
	
	/*
	 * This method is called to generate the questions answered incorrectly by the applicant
	 */
	public void generateMissedQuestions(ExamDTO examDTO) {
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExamWL examWL = examService.getExamByExamId(examId);
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			examDTO.setLangIdCode(exam.getLangId());
			Lang lang = examSeedData.getLangByLangId(exam.getLangId());
			examDTO.setProgLangCode(lang.getProgLangCode());
			IExamQuestionListWL eqWL = examService.getMissedExamQues(examId);
			if(eqWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<IExamQuestion> examQuesList = eqWL.getExamQuestionList();
				List<QuesAnsw> quesAnswList = new ArrayList<QuesAnsw>();
				for(IExamQuestion examQues: examQuesList) {
					List<IExamAnswer> examAnsList = examService.getExamAnswByExamIdAndQuesGenId(examQues);
					QuesAnsw quesAnsw = examSeedData.generateMissedQuestions(examAnsList); 
					for(IExamAnswer examAns: examAnsList) {
						if(examAns.getAnswerPresentedOrder() == Integer.parseInt(examQues.getAnswerChoice())) {
							quesAnsw.setApplicantAnswId(examAns.getEaPrimaryKey().getAnswerId());
						}
					}
					quesAnswList.add(quesAnsw);
				}
				examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
			}
			else {
				examDTO.setErrorCode(eqWL.getErrorCode());
			}
		}
		else {
			examDTO.setErrorCode(examWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to generate the questions answered incorrectly by the applicant
	 */
	public void getMissedQuestionsFromSessionData(ExamDTO examDTO) {
		List<IExamQuestion> examQuesList = examSessionData.getMissedExamQuestionList();
		String officeType = examSeedData.getOfficeTypeByIPAddress(examDTO.getWorkstationId().trim());
		
		List<QuesAnsw> quesAnswList = new ArrayList<QuesAnsw>();
		for(IExamQuestion examQues: examQuesList) {
			List<IExamAnswer> examAnsList = examSessionData.getExamAnswerListByQuesGenId(examQues.getQuestionGenId());
			QuesAnsw quesAnsw = examSeedData.generateMissedQuestions(examAnsList); 
			for(IExamAnswer examAns: examAnsList) {
				if(examAns.getAnswerPresentedOrder() == Integer.parseInt(examQues.getAnswerChoice())) {
					quesAnsw.setApplicantAnswId(examAns.getEaPrimaryKey().getAnswerId());
				}
			}
			for(Answer answ: quesAnsw.getAnswerList()){
				if(answ.getCorrectAnswerInd().trim().equalsIgnoreCase(Constant.CORRECT) && !officeType.trim().equals(Constant.OFFICE_TYPE_CHP)){
					answ.setAnswerStatus(Constant.CORRECT);
				}
				else if(answ.getAnswerGenId()==quesAnsw.getApplicantAnswId()){
					answ.setAnswerStatus(Constant.INCORRECT);
				}
				else
					answ.setAnswerStatus(Constant.SINGLE_SPACE);
			}
			quesAnswList.add(quesAnsw);
		}
		examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);	
				
		Integer timeLimit = 0;
		examDTO.setHandbookRefAllowed(true);
		if(officeType.trim().equals(Constant.OFFICE_TYPE_OL)){
			timeLimit = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.OL_VIEW_MISSED_QUESTIONS);
			timeLimit = timeLimit!=null?timeLimit:TimeLimitTypeConstant.DEFAULT_OL_VIEW_MISSED_QUESTIONS;
		}
		if(officeType.trim().equals(Constant.OFFICE_TYPE_CHP)){
			examDTO.setHandbookRefAllowed(false);
			timeLimit = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.CHP_VIEW_MISSED_QUESTIONS);
			timeLimit = timeLimit!=null?timeLimit:TimeLimitTypeConstant.DEFAULT_CHP_VIEW_MISSED_QUESTIONS;
		}
		examDTO.setTimeToReviewMissedQuestions(timeLimit*TimeLimitTypeConstant.MILLISECONDS);
	}
	
	/*
	 * This method is called to generate the finished tests by the applicant
	 */
	public void generateFinishedTests(ExamDTO examDTO) {
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExamWL examWL = examService.getExamByExamId(examId);
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			examDTO.setLangIdCode(exam.getLangId());
			Lang lang = examSeedData.getLangByLangId(exam.getLangId());
			examDTO.setProgLangCode(lang.getProgLangCode());
			String testName = examSeedData.getTestByTestId(exam.getTestId()).getTestName();
			examDTO.setTestName(testName);
			IExamQuestionListWL eqWL = examService.getExamQues(examId);
			if(eqWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<IExamQuestion> examQuesList = eqWL.getExamQuestionList();
				List<QuesAnsw> quesAnswList = new ArrayList<QuesAnsw>();
				for(IExamQuestion examQues: examQuesList) {
					List<IExamAnswer> examAnsList = examService.getExamAnswByExamIdAndQuesGenId(examQues);
					QuesAnsw quesAnsw = examSeedData.generateMissedQuestions(examAnsList); 
					/*this will set the questions not answered to true*/
					
					if(examQues.getAnswerStatus().equals(Constant.SINGLE_SPACE) || examQues.getAnswerStatus().equals(Constant.SKIPPED)){
						quesAnsw.setQueNotAnswered(true);	
					}
					for(IExamAnswer examAns: examAnsList) {
						if (!examQues.getAnswerChoice().equals(" ")) {
							if(examAns.getAnswerPresentedOrder() == Integer.parseInt(examQues.getAnswerChoice())) {
								quesAnsw.setApplicantAnswId(examAns.getEaPrimaryKey().getAnswerId());
							}
						}
					}
					quesAnswList.add(quesAnsw);
				}
				examDTO.setQuesAnswListAfterPreTierConversion(quesAnswList);
			}
			else {
				examDTO.setErrorCode(eqWL.getErrorCode());
			}
		}
		else {
			examDTO.setErrorCode(examWL.getErrorCode());
		}
	}

	/*
	 * This method is called to update exam with ease time stamp
	 */
	public void updateExamWithEaseTstamp(ExamDTO examDTO2) {
		examDTO2.setErrorCode(ErrorCode.NO_ERROR);
		int examId = examDTO2.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		IExamWL examWL = examService.getExamByExamId(examId);
		examDTO2.setErrorCode(examWL.getErrorCode());
		if(examWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = examWL.getExam();
			exam.setEaseTimestamp(new Date());
			//examSessionData.setExam(exam);
			IErrorWL errWL = examService.updateExam(exam);
			examDTO2.setErrorCode(errWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get incomplete exams that will be failed by the technician at the end of the day
	 */
	public void getIncompleteExams(ApplicantDTO applicantDTO) {
		applicantDTO.setErrorCode(ErrorCode.NO_ERROR);
		IExamListWL elWL = examService.getIncompleteExams(applicantDTO.getOfficeId(), applicantDTO.getApplicationType());
		if(elWL.getErrorCode() == ErrorCode.NO_ERROR || elWL.getErrorCode() == ErrorCode.MISSING_EXAMS) {
			if(elWL.getErrorCode() != ErrorCode.MISSING_EXAMS) {
				List<IExam> incompleteExamList = elWL.getExamList();
				List<Applicant> appList = new ArrayList<Applicant>();
				for(IExam exam: incompleteExamList) {
					IApplicationWL appWL = applicationService.getApplication(exam.getApplicationId());
					if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
						IApplication app = appWL.getApplication();
						IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							ITestWL testWL = testService.getTest(exam.getTestId());
							if(testWL.getErrorCode() == ErrorCode.NO_ERROR) {
								Test test = testWL.getTest();
								Applicant applicant = new Applicant();
								applicant.setDlNumber(vault.getDlNumber());
								applicant.setExamId(exam.getExamId());
								applicant.setExamType(test.getTestName());
								applicant.setFirstName(vault.getApplicationFirstName());
								applicant.setLastName(vault.getApplicationLastName());
								
								String result;
								if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PAUSE))
									result = "Paused";
								else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.TIME_OUT))
									result = "Timed Out";
								else
									result = "Incomplete";
								
								if (exam.getSessionId() > 0) {
									ISessionWL sessionWL = sessionService.getSessionBySessionId(exam.getSessionId());
									if(sessionWL.getErrorCode() == ErrorCode.NO_ERROR) {
										ISession session =  sessionWL.getSession();
										IStringWL strWL = sessionService.getWorkstationId(session.getWorkstationIPAddress());
										applicant.setWorkstationId(strWL.getString());
									}
								} 
								else {
									//defect #136-verbiage update, result type "manually test" changed to "manual test".
									//result = "Manually Test";
									result = "Manual Test";
								}
														
								applicant.setResult(result);
								appList.add(applicant);																
							}
							else {
								applicantDTO.setErrorCode(testWL.getErrorCode());
							}
						}
						else {
							applicantDTO.setErrorCode(vaultWL.getErrorCode());
						}
					}
					else {
						applicantDTO.setErrorCode(appWL.getErrorCode());
					}
				}
				applicantDTO.setApplicantList(appList);
			}
		}
		else {
			applicantDTO.setErrorCode(elWL.getErrorCode());
		}
	}

	/**
	 * This method is called to get data for generating the question pass fail rate report that will display the missed questions in
	 * the descending order.
	 */
	public void getQuesPassRateList(QuesPassRateDTO quesDTO) {
		quesDTO.setErrorCode(ErrorCode.NO_ERROR);
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = formatter.parse(quesDTO.getFromDate());
			toDate = formatter.parse(quesDTO.getToDate());
		}
		catch(ParseException e) {
			logger.error(e.getMessage());
			logger.error(e.getCause());
		}

		ITestReportsWL trWL = examService.getQuesPassRateList(fromDate,toDate);
		if(trWL.getErrorCode() == ErrorCode.NO_ERROR) {
			
			quesDTO.setQuesReports(trWL.getQuesPassRateList());
		}
		else {
			quesDTO.setErrorCode(trWL.getErrorCode());
		}
	}

	/**
	 * Generate End Of Day Report.
	 * @param reportDTO
	 */
	public void getEndOfDayReport(ReportDTO reportDTO) {
		
		// Getting number of pass and fails
		List<Integer> examIds = new ArrayList<Integer>();
		EndOfDayReport endOfDayReport = new EndOfDayReport();
		
		reportDTO.setErrorCode(ErrorCode.NO_ERROR);
		String officeId = reportDTO.getOfficeId();
		String group = reportDTO.getGroup();
		IApplicationListWL appWL = applicationService.getTodaysApps(officeId, group);
		reportDTO.setErrorCode(appWL.getErrorCode());
		if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<Integer> appIds = prepareAppIds(appWL.getApplicationList());
			int nonPrintedPassCnt = 0;
			int nonPrintedFailCnt = 0;
			int printedPassCnt = 0;
			int printedFailCnt = 0;
			
			if (appIds.size() > 0) {
				IExamListWL exWL = examService.getAllExams(appIds); 
				reportDTO.setErrorCode(exWL.getErrorCode());
				if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
					List<IExam> examList = exWL.getExamList();
					for(IExam exam: examList) {
						if (exam.getPassFailIndicator().equals(Constant.PASS)) {
							if (exam.getCompletionReasonCode().equals(Constant.NORMAL)) {
								nonPrintedPassCnt++;
							}
							else if (exam.getCompletionReasonCode().equals(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								printedPassCnt++;
							}							
						}
						else if (exam.getPassFailIndicator().equals(Constant.FAIL)) {
							if (exam.getCompletionReasonCode().equals(Constant.NORMAL) || 
								exam.getCompletionReasonCode().equals(Constant.BATCH_FAIL) ||
								exam.getCompletionReasonCode().equals(Constant.QUIT) || 
								exam.getCompletionReasonCode().equals(Constant.TIME_OUT)) {
								nonPrintedFailCnt++;
							}
							else if (exam.getCompletionReasonCode().equals(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								printedFailCnt++;
							}							
						}
						examIds.add(exam.getExamId());						
					}										
				}
			}
			endOfDayReport.setNonPrintedPassCnt(nonPrintedPassCnt);
			endOfDayReport.setNonPrintedFailCnt(nonPrintedFailCnt);
			endOfDayReport.setPrintedPassCnt(printedPassCnt);
			endOfDayReport.setPrintedFailCnt(printedFailCnt);	
		}	
		
		// Getting the number of paused, quit, timeout and disconnected tests.
		int pausedTestsCnt = 0;
		int quitTestsCnt = 0;
		int timeoutTestsCnt = 0;
		int disconnectedTestsCnt = 0;
		if (examIds.size() > 0) {
			IAuditListWL auditListWL = auditService.getAuditListForExamIds(examIds);
			if(auditListWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<Audit> auditList = auditListWL.getAuditList();
				
				
				for (Audit audit: auditList) {
					if (audit.getNewValue().equals(Constant.PAUSE)) {
						pausedTestsCnt++;
					}
					else if (audit.getNewValue().equals(Constant.QUIT)) {
						quitTestsCnt++;
					}
					else if (audit.getOldValue().equals(Constant.TIME_OUT)) {
						timeoutTestsCnt++;
					}
					else if (audit.getNewValue().equals(Constant.DISCONNECTED)) {
						disconnectedTestsCnt++;
					}
				}				
			}	
		}
		endOfDayReport.setPausedTestsCnt(pausedTestsCnt);
		endOfDayReport.setQuitTestsCnt(quitTestsCnt);
		endOfDayReport.setTimeoutTestsCnt(timeoutTestsCnt);
		endOfDayReport.setDisconnectedTestsCnt(disconnectedTestsCnt);
		endOfDayReport.setOfficeId(reportDTO.getOfficeId());
		
		reportDTO.setEndOfDayReport(endOfDayReport);
	}
	
	/*
	 * This method is called to generate reports for records that did not get updated at EASE end
	 */
	public void generateExceptionRep(ApplicantDTO appDTO) {
		appDTO.setErrorCode(ErrorCode.NO_ERROR);
		IResultListWL resultsWL = examService.getEASEExceptionRecords(appDTO.getOfficeId());
		if(resultsWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ExceptionApplicant> appList = new ArrayList<ExceptionApplicant>();
			if(resultsWL.getErrorCode() == ErrorCode.NO_ERROR) {
				List<AKTSResults> resultList = resultsWL.getResultList();
				if(resultList != null && resultList.size() > Constant.ZERO) {
					for(AKTSResults result: resultList) {
						ExceptionApplicant app = new ExceptionApplicant();
						app.setAppId(result.getAppId());
						app.setDlNumber(result.getDlNumber());
						app.setExamType(result.getEaseTestId());
						IVaultWL vaultWL = applicationService.getVaultByDL(result.getDlNumber());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							app.setFirstName(vault.getApplicationFirstName());
							app.setLastName(vault.getApplicationLastName());
							app.setOfficeId(result.getOfficeId());
							app.setResult(result.getPassFailInd());
							app.setResultSentTimestamp(result.getResultSentTimestamp());
							app.setLang(result.getLangId());
							if(result.getResultStatusCode().trim().equalsIgnoreCase(Constant.EASE_UNPROCESSED)) {
								app.setResultStatusCode(Constant.EASE_UNPROCESSED_MSG);
							}
							else {
								app.setResultStatusCode(Constant.EASE_ORPHANED_MSG);
							}
							app.setSysId(result.getSysId());
							appList.add(app);
						}
						else {
							appDTO.setErrorCode(vaultWL.getErrorCode());
							break;
						}
					}
				}
				appDTO.setExceptionApplicantList(appList);
			}
			else {
				appDTO.setErrorCode(resultsWL.getErrorCode());
			}
		}
		else {
			appDTO.setErrorCode(resultsWL.getErrorCode());
		}
	}

	/*
	 * This method is called to update the exception report record with the status code to indicate it has been manually updated in the EASE DB
	 */
	public void updateExceptionRep(ApplicantDTO appDTO) {
		appDTO.setErrorCode(ErrorCode.NO_ERROR);
		IErrorWL errorWL = examService.updateExceptionRep(appDTO.getSysId());
		if(errorWL.getErrorCode() != ErrorCode.NO_ERROR) {
			appDTO.setErrorCode(errorWL.getErrorCode());
		}
	}
	
	/**
	 * Get Applicant Audio Video Indicator From Session Data
	 */
	public String getApplicantAudioVideoInd() {
		return examSessionData.getApplication().getAudioVideoTestCode();
	}
	
	/*
	 * This method is called to skip a question by setting the skipped flag in 
	 * the respective exam question record and adding it to the skipped exam questions list in examSessionData.
	 */
	public void skipQuestion(ExamDTO examDTO) {
		examDTO.setErrorCode(ErrorCode.NO_ERROR);
		int order = examDTO.getQuestionPresentedOrder();
		int examId = examDTO.getExamList().get(Constant.FIRST_ELEMENT).getExamId();
		Date questionPresentedTime = examDTO.getQuestionPresentedTime();
		/*
		 * We have to check if the applicant was force failed before allowing the question to be skipped.
		 */
		String forceFail = forceFailRegistryService.getForceFailRequest(examId);
		if(forceFail != null && forceFail.equalsIgnoreCase(Constant.FORCE_FAIL)) {
			examDTO.setErrorCode(ErrorCode.FORCE_FAILED);
			/*IExam exam1 = examSessionData.getExamAfterForceFail(examId);
			IErrorWL errWL = examService.saveExam(exam1);
			if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
				examDTO.setErrorCode(errWL.getErrorCode());
			}*/
		}
		else {
			IExamQuestion eq = examSessionData.skipQuestion(examId, order,questionPresentedTime);
			IErrorWL errWL = examService.submitAnswer(eq);
			examDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
				IErrorWL errorWL = auditService.saveAudit(Constant.EXAM_QUESTION_TABLE, Constant.ANSWER_STATUS, Constant.SINGLE_SPACE, 
														  Constant.SKIPPED, eq.getEqPrimaryKey().getExamId() + "-" + 
				                                          eq.getEqPrimaryKey().getQuestionPresentedOrder(), getUserId());
				examDTO.setErrorCode(errorWL.getErrorCode());
			}
		}
	}
	
	/*
	* This method is called to find the timeout value for the screen
	*/	
	public Integer getScreenTimeout(String screen){
		Integer timeout = 0;
		if(screen.trim().toLowerCase().equals("perjury")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.PERJURY_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_PERJURY_SCREEN;
		}		
		else if(screen.trim().toLowerCase().equals("samplequestion")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.SAMPLE_QUESTION_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_SAMPLE_QUESTION_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("testlist")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TESTS_AVAILABLE_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_TESTS_AVAILABLE_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("review")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.VIEW_MISSED_QUESTIONS);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_VIEW_MISSED_QUESTIONS;
		}
		else if(screen.trim().toLowerCase().equals("examresult")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TEST_RESULTS_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_TEST_RESULTS_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("additionaltests")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.ADDTNL_TEST_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_ADDTNL_TEST_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("perquestion")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TIME_PER_QUESTION);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_TIME_PER_QUESTION;
		}
		else if(screen.trim().toLowerCase().equals("warning")){
			Integer timeout1 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.WARNING_BEFORE_TIMEOUT);
			timeout1 = timeout1!=null?timeout1:TimeLimitTypeConstant.DEFAULT_WARNING_BEFORE_TIMEOUT;
			
			Integer timeout2 = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TIME_PER_QUESTION);
			timeout2 = timeout2!=null?timeout2:TimeLimitTypeConstant.DEFAULT_TIME_PER_QUESTION;
			
			timeout = timeout1 + timeout2;
		}
		else if(screen.trim().toLowerCase().equals("qextn")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.ADDTNL_TIME_PER_QUESTION);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_ADDTNL_TIME_PER_QUESTION;
		}
		
		
		return timeout*TimeLimitTypeConstant.MILLISECONDS;		
	}
	
	public boolean getExamTakenCount(Integer examId) {
		boolean examCountFlag;
		IExam exam = examSessionData.getExamByExamId(examId);
		IExamHistory examHistory = new ExamHistory();
		examHistory.setApplicationId(exam.getApplicationId());
		examHistory.setEaseTestId(exam.getEaseTestId());
		IExamHistoryWL ehWL = applicationService.getExamHistory(examHistory);
		if(ehWL.getErrorCode() == ErrorCode.NO_ERROR) {
			String aktStatusIndicator = ehWL.getExamHistory().getAktStatusIndicator();
			String easeStatusIndicator = ehWL.getExamHistory().getEaseStatusIndicator();
			Integer examCount = (Integer.parseInt(easeStatusIndicator) + 
					             Integer.parseInt(aktStatusIndicator.equals(Constant.SINGLE_SPACE)?"0":aktStatusIndicator));
			if(examCount > Constant.TWO)
				examCountFlag = true;
			else
				examCountFlag = false;
			
		}
		else {
			examCountFlag = false;
		}
		return examCountFlag;
	}			
}
