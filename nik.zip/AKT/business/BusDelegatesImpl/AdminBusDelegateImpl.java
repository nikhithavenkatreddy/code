package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.AdminBusDelegate;
import gov.ca.dmv.AKT.business.Services.CategoryService;
import gov.ca.dmv.AKT.business.Services.HandbookRefService;
import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.Services.TestService;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IHandbookRefListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuesAnswWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionCategoryTestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionLangListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestPlanListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITimeLimitListWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Audit;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;
import gov.ca.dmv.AKT.integration.BeansImpl.HRPrimaryKey;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionCategoryTestList;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.presentation.Beans.TestPlan;
import gov.ca.dmv.AKT.presentation.Beans.TimeLimit;
import gov.ca.dmv.AKT.presentation.DTO.CategoryDTO;
import gov.ca.dmv.AKT.presentation.DTO.CategoryQuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.HandbookRefDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesAnswDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionIdDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestPlanDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestQuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.TimeLimitDTO;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminBusDelegateImpl extends BaseBusDelegateImpl implements AdminBusDelegate {

	private TestService    testService;
	private SessionService sessionService;
	private CategoryService categoryService;
	private HandbookRefService handbookRefService;
	
	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}

	public TestService getTestService() {
		return testService;
	}

	public void setTestService(TestService testService) {
		this.testService = testService;
	}
	
	public CategoryService getCategoryService() {
		return categoryService;
	}

	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	public HandbookRefService getHandbookRefService() {
		return handbookRefService;
	}

	public void setHandbookRefService(HandbookRefService handbookRefService) {
		this.handbookRefService = handbookRefService;
	}

	/*
	 * This method is called to get the list of all handbook references
	 */
	public void getHandbookRefList(HandbookRefDTO handbookRefDTO) {
		handbookRefDTO.setHandbookRefListAfterPreTierConversion(examSeedData.getHandbookRefList());
	}
	
	/*
	 * Called by the create parent question module to load the list of all categories
	 */
	public void getCategoryList(CategoryDTO categoryDTO) {
		ICategoryListWL catWL = testService.getCategoriesList();
		categoryDTO.setErrorCode(catWL.getErrorCode());
		List<gov.ca.dmv.AKT.integration.BeansImpl.Category> categoryList = null;
		if(catWL.getErrorCode() == ErrorCode.NO_ERROR) {
			categoryList = catWL.getCategoryList();
			if(categoryList != null) {
				categoryDTO.setCategoryListAfterPreTierConversion(categoryList);
			}
		}
	}
	
	/*
	 * This method is called to get the list of all languages
	 */
	public void getLangList(LangDTO langDTO) {	
		langDTO.setLangListAfterPreTierConversion(examSeedData.getLangList());
	}
	
	/*
	 * This method is called to get the list of all tests
	 */
	public void getTestList(TestDTO testDTO) {
		List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList = null; 
		ITestListWL testWL = testService.getTestsList();
		testDTO.setErrorCode(testWL.getErrorCode());
		if(testWL.getErrorCode() == ErrorCode.NO_ERROR) {
			testList = testWL.getTestList();
			if(testList != null && testList.size() > Constant.ZERO) {
				testDTO.setTestListAfterPreTierConversion(testList);
			}
		}
	}
	
	/*
	 * This method is called to get the list of all time Limits
	 */
	public void getTimeLimitList(TimeLimitDTO timeLimitDTO) {
		timeLimitDTO.setErrorCode(ErrorCode.NO_ERROR);
		ITimeLimitListWL tlListWL = testService.getTimeLimitList();
		timeLimitDTO.setErrorCode(tlListWL.getErrorCode());
		if(tlListWL.getErrorCode() == ErrorCode.NO_ERROR){
			timeLimitDTO.setTimeLimitListAfterPreTierConversion(tlListWL.getTimeLimitList());
		}		
	}
	
	/*
	 * This method is called to update the time Limits
	 */
	public void updateTimeLimits(TimeLimitDTO timeLimitDTO) {
		timeLimitDTO.setErrorCode(ErrorCode.NO_ERROR);
		List<TimeLimit> timeLimitListDTO = timeLimitDTO.getTimeLimitList();				
		ITimeLimitListWL tlListWL = testService.getTimeLimitList();
		
		timeLimitDTO.setErrorCode(tlListWL.getErrorCode());
		if(tlListWL.getErrorCode() == ErrorCode.NO_ERROR){
			List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> timeLimitList = tlListWL.getTimeLimitList();			
			List<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit> timeLimitListSave = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit>();
			
			for(gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit timeLimitData:timeLimitList){
				for(TimeLimit timeLimit1: timeLimitListDTO){
					Integer timeLimitVal = (int) (timeLimit1.getTimeLimitValue()*TimeLimitTypeConstant.SECONDS);
					if(timeLimit1.getTimeLimitId().equals(timeLimitData.getTimeLimitId()) && !timeLimitData.getTimeLimitValue().equals(timeLimitVal)){
						if(timeLimitVal<timeLimitData.getTimeLimitRangeMin() || timeLimitVal>timeLimitData.getTimeLimitRangeMax()){
							timeLimitDTO.setErrorCode(ErrorCode.INPUT_OUT_OF_RANGE);
							break;
						}
						gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit timeLimit = new gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit();
						timeLimit.setTimeLimitId(timeLimitData.getTimeLimitId());						
						timeLimit.setTimeLimitName(timeLimitData.getTimeLimitName());
						timeLimit.setTimeLimitDescription(timeLimitData.getTimeLimitDescription());
						timeLimit.setTimeLimitValue(timeLimitVal);
						timeLimit.setTimeLimitRangeMin(timeLimitData.getTimeLimitRangeMin());
						timeLimit.setTimeLimitRangeMax(timeLimitData.getTimeLimitRangeMax());
						timeLimit.setLastModUsername(timeLimitDTO.getLastModUsername());
						timeLimit.setLastModUserTime(timeLimitDTO.getLastModUserTime());						
						timeLimitListSave.add(timeLimit);							
					}
				}
			}
			if(timeLimitDTO.getErrorCode() == ErrorCode.NO_ERROR){
				IErrorWL errWL = testService.updateTimeLimitList(timeLimitListSave);
				timeLimitDTO.setErrorCode(errWL.getErrorCode());		
			}
		}
	}
	
	/*
	 * This method is called to get the question lang and answers by auto gen id
	 */
	public void getQuesAnsw(QuesAnswDTO quesAnswDTO) {
		IQuesAnswWL qaWL = testService.getQuesAnswByAutoGenId(quesAnswDTO.getQuestionLang().getQuestionGenId());
		quesAnswDTO.setErrorCode(qaWL.getErrorCode());
		if(qaWL.getErrorCode() == ErrorCode.NO_ERROR) {
			QuesAnsw quesAnsw = qaWL.getQuesAnsw();		
			QuestionLang quesLang = quesAnsw.getQuestionLang();
			List<Answer> ansList = quesAnsw.getAnswerList();
			HandbookRef hb = examSeedData.getHandbookRefByHandbookRefAndLangId(quesLang.getHandbookRef(), quesLang.getLangId());
			quesAnswDTO.setAnswerListAfterPreTierConversion(ansList);
			quesAnswDTO.setQuestionLangAfterPreTierConversion(quesLang);
			quesAnswDTO.setHandbookRefAfterPreTierConversion(hb);
			Lang lang = examSeedData.getLangByLangId(quesLang.getLangId());
			quesAnswDTO.setLangAfterPreTierConversion(lang);
		}
	}
	
	/*
	 * This method is called to load the question lang and answers by question gen id
	 */
	public void getQuesAnswByAutoGenId(QuesAnswDTO quesAnswDTO) {
		IQuesAnswWL qaWL = testService.getQuesAnswByAutoGenId(quesAnswDTO.getQuestionLang().getQuestionGenId());
		if(qaWL.getErrorCode() == ErrorCode.NO_ERROR) {
			QuesAnsw quesAnsw = qaWL.getQuesAnsw();
			quesAnswDTO.setAnswerListAfterPreTierConversion(quesAnsw.getAnswerList());
			quesAnswDTO.setQuestionLangAfterPreTierConversion(quesAnsw.getQuestionLang());
		}
		else {
			quesAnswDTO.setErrorCode(qaWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to save the question and answers created from the create language specific question module.
	 */
	public void saveQuestion(QuesAnswDTO quesAnswDTO) {
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang questionLang = quesAnswDTO.getQuestionLangAfterBusTierConversion();
		List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList = quesAnswDTO.getAnswerListAfterBusTierConversion();
		QuesAnsw quesAnsw = new QuesAnsw();
		quesAnsw.setAnswerList(answerList);
		quesAnsw.setQuestionLang(questionLang);
		IErrorWL errWL = testService.saveQuestion(quesAnsw);
		quesAnswDTO.setErrorCode(errWL.getErrorCode());
		if(errWL.getErrorCode() == ErrorCode.NO_ERROR)
			quesAnswDTO.setQuestionGenId(questionLang.getQuestionGenId());
	}
	
	/*
	 * This method is called to save modifications made to a question
	 */
	public void updateQuestion(QuesAnswDTO quesAnswDTO) {
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang quesLang = quesAnswDTO.getQuestionLangAfterBusTierConversion();
		List<gov.ca.dmv.AKT.integration.BeansImpl.Answer> answerList = quesAnswDTO.getAnswerListAfterBusTierConversion();
		QuesAnsw quesAnsw = new QuesAnsw();
		quesAnsw.setAnswerList(answerList);
		quesAnsw.setQuestionLang(quesLang);
		IIntegerWL intWL = testService.updateQuestion(quesAnsw);
		quesAnswDTO.setErrorCode(intWL.getErrorCode());
		if(intWL.getErrorCode() == ErrorCode.NO_ERROR) {
			quesAnswDTO.setQuestionGenId(intWL.getInteger());
		}
	}
	
	/*
	 * This method is called to retrieve question langs by question lang id
	 */
	public void findQuestions(QuestionLangDTO questionLangDTO) {
		questionLangDTO.setErrorCode(ErrorCode.NO_ERROR);
		gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ql = new gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang();
		gov.ca.dmv.AKT.presentation.Beans.QuestionLang ql2 = null;
		if(questionLangDTO.getQuestionLangList().size() == Constant.SINGLE_ELEMENT_LIST)
			ql2 = questionLangDTO.getQuestionLangList().get(Constant.FIRST_ELEMENT);
		ql.setQuestionLangId(ql2.getQuestionLangId());
		ql.setQuestionText(ql2.getQuestionText());
		ql.setLangId(ql2.getLangId());
		
		IQuestionLangListWL qlWL = testService.findQuest(ql);
		if (ql.getQuestionLangId() != null && ql.getQuestionLangId().length() > Constant.ZERO) {
			qlWL = testService.findQuest(ql);
		}
		else {
			qlWL = testService.findQuestByPartialText(ql);
		}
		if(qlWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList = qlWL.getQuestionLangList();
			questionLangDTO.setQuestionLangListAfterPreTierConversion(qlList);
		}
		else {
			questionLangDTO.setErrorCode(qlWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get the list of questions based on category
	 */
	public void findQuestions(CategoryQuestionLangDTO categoryQuesDTO) {
		categoryQuesDTO.setErrorCode(ErrorCode.NO_ERROR);
		gov.ca.dmv.AKT.integration.BeansImpl.Category cat = new gov.ca.dmv.AKT.integration.BeansImpl.Category();
		gov.ca.dmv.AKT.presentation.Beans.Category cat2 = categoryQuesDTO.getCategory();
		cat.setCategoryId(cat2.getCategoryId());
		IQuestionLangListWL qlListWL = testService.getQuestionList(cat);
		if(qlListWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList = qlListWL.getQuestionLangList();
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang>();
			for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ques: qlList) {
				if(ques.getLangId().equalsIgnoreCase(categoryQuesDTO.getLangId())) {
					qlList2.add(ques);
				}
			}
			categoryQuesDTO.setQuestionLangListAfterPreTierConversion(qlList2);
		}
		else {
			categoryQuesDTO.setErrorCode(qlListWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get the list of questions based on test
	 */
	public void findQuestions(TestQuestionDTO tqlDTO) {
		tqlDTO.setErrorCode(ErrorCode.NO_ERROR);
		gov.ca.dmv.AKT.integration.BeansImpl.Test test = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
		test.setTestId(tqlDTO.getTest().getTestId());
		IQuestionLangListWL qlWL = testService.getQuestionList(test);
		if(qlWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList = qlWL.getQuestionLangList();
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang>();
			for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ques: qlList) {
				if(ques.getLangId().equalsIgnoreCase(tqlDTO.getLangId())) {
					qlList2.add(ques);
				}
			}
			tqlDTO.setQuestionLangListAfterPreTierConversion(qlList2);
		}
		else {
			tqlDTO.setErrorCode(qlWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get the list of questions based on test and category
	 */
	public void findQuestions2(TestQuestionDTO tqlDTO) {
		tqlDTO.setErrorCode(ErrorCode.NO_ERROR);
		gov.ca.dmv.AKT.integration.BeansImpl.TestCategory2 testCategory = new gov.ca.dmv.AKT.integration.BeansImpl.TestCategory2();
		testCategory.setCategoryId(tqlDTO.getCategory().getCategoryId());
		testCategory.setTestId(tqlDTO.getTest().getTestId());
		IQuestionLangListWL qlWL = testService.getQuestionList(testCategory);
		if(qlWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList = qlWL.getQuestionLangList();
			List<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang> qlList2 = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang>();
			for(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ques: qlList) {
				if(ques.getLangId().equalsIgnoreCase(tqlDTO.getLangId())) {
					qlList2.add(ques);
				}
			}
			tqlDTO.setQuestionLangListAfterPreTierConversion(qlList2);
		}
		else {
			tqlDTO.setErrorCode(qlWL.getErrorCode());
		}
	}

	/*
	 * This method is used to save the parent question, its associated categories and tests.
	 */
	public void saveParentQuestion(QuestionDTO questionDTO) {
		QuestionCategoryTestList questionCategoryTestList = new QuestionCategoryTestList();
		questionCategoryTestList.setCategoryList(questionDTO.getCategoryListAfterBusTierConversion());
		questionCategoryTestList.setQuestion(questionDTO.getQuestionAfterBusTierConversion());
		questionCategoryTestList.setTestList(questionDTO.getTestListAfterBusTierConversion());
		IErrorWL errorWL = testService.saveParentQuestion(questionCategoryTestList);
		questionDTO.setErrorCode(errorWL.getErrorCode());
	}

	/*
	 * This method is called to get the parent question, its categories and tests by question id
	 */
	public void getParentQuestion(QuestionDTO questionDTO) {
		gov.ca.dmv.AKT.integration.BeansImpl.Question question = questionDTO.getQuestionAfterBusTierConversion();
		IQuestionCategoryTestListWL qctlWL = testService.getParentQuestion(question);
		questionDTO.setErrorCode(qctlWL.getErrorCode());
		if(qctlWL.getErrorCode() == ErrorCode.NO_ERROR) {
			QuestionCategoryTestList questionCategoryTestList = qctlWL.getQuestionCategoryTestList();
			questionDTO.setQuestionAfterPreTierConversion(questionCategoryTestList.getQuestion());
			questionDTO.setCategoryListAfterPreTierConversion(questionCategoryTestList.getCategoryList());
			questionDTO.setTestListAfterPreTierConversion(questionCategoryTestList.getTestList());
		}
	}

	/*
	 * This method is called to update the parent question with new categories and tests
	 */
	public void updateParentQuestion(QuestionDTO questionDTO) {
		QuestionCategoryTestList questionCategoryTestList = new QuestionCategoryTestList();
		questionCategoryTestList.setCategoryList(questionDTO.getCategoryListAfterBusTierConversion());
		questionCategoryTestList.setQuestion(questionDTO.getQuestionAfterBusTierConversion());
		questionCategoryTestList.setTestList(questionDTO.getTestListAfterBusTierConversion());
		IErrorWL errorWL = testService.updateParentQuestion(questionCategoryTestList);
		questionDTO.setErrorCode(errorWL.getErrorCode());
	}

	//This method is called to inactivate question in all languages//$$
//	public void inactivateQuestion(QuestionDTO questionDTO) {
//		Question question = questionDTO.getQuestionAfterBusTierConversion();
//		testService.inactivateQuestion(question);
//	}
	
	//This method is called to activate question in all languages//$$
//	public void activateQuestion(QuestionDTO questionDTO) {
//		Question question = questionDTO.getQuestionAfterBusTierConversion();
//		testService.activateQuestion(question);
//	}

	/*
	 * This method is called to get the list of all question ids
	 */
	public void getAllQuestionId(QuestionIdDTO questionIdDTO) {
		IStringListWL strWL = testService.getAllQuestionIds();
		questionIdDTO.setErrorCode(strWL.getErrorCode());
		if(strWL.getErrorCode() == ErrorCode.NO_ERROR) {
			questionIdDTO.setQuestionIdList(strWL.getStringList());
		}
	}

	/*
	 * This method is called to get test by test id
	 */
	public void getTest(TestPlanDTO testPlanDTO) {
		String testId = testPlanDTO.getTest().getTestId();
		ITestWL testWL = testService.getTest(testId);
		if(testWL.getErrorCode() == ErrorCode.NO_ERROR) {
			gov.ca.dmv.AKT.integration.BeansImpl.Test test = testWL.getTest();
			testPlanDTO.setTestAfterPreTierConversion(test);
		}
		else {
			testPlanDTO.setErrorCode(testWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get test plan list by test id
	 */
	public void getTestPlanList(TestPlanDTO testPlanDTO) {
		String testId = testPlanDTO.getTest().getTestId();
		ITestPlanListWL tpListWL = testService.getTestPlanListByTestId(testId);
		if(tpListWL.getErrorCode() == ErrorCode.NO_ERROR) {
			testPlanDTO.setTestPlanListAfterPreTierConversion(tpListWL.getTestPlanList());
			Map<String, String> categoryMap = buildCategoryNameMap();
			for (TestPlan testPlan : testPlanDTO.getTestPlanList()) {
				testPlan.setCategoryName(categoryMap.get(testPlan.getCategoryId()));
			}			
		}
		else {
			testPlanDTO.setErrorCode(tpListWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get test plan list such that there is one entry for each category.
	 */
	public void getAllCategoriesTestPlanList(TestPlanDTO testPlanDTO) {
		List<TestPlan> testPlanList = new ArrayList<TestPlan>();
		ICategoryListWL categoryListWL = testService.getCategoriesList();
		if(categoryListWL.getErrorCode() == ErrorCode.NO_ERROR) {			
			for (Category category : categoryListWL.getCategoryList()) {				
				TestPlan tPlan = new TestPlan();
				tPlan.setCategoryId(category.getCategoryId());
				tPlan.setCategoryName(category.getCategoryName());
				tPlan.setCategoryQuestionCount(Constant.ZERO);
				tPlan.setCategoryOrder(Constant.NEGATIVE_ONE);
				tPlan.setGradableFlag(false);
				testPlanList.add(tPlan);					
			}
			testPlanDTO.setTestPlanList(testPlanList);
		}
		else {
			testPlanDTO.setErrorCode(categoryListWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to fill test plan list with categories that were not the part of received request
	 */
	public void fillTestPlanList(TestPlanDTO testPlanDTO, List<TestPlan> completeTestPlanList) {
		List<TestPlan> testPlanList = new ArrayList<TestPlan>();
		HashMap<String,TestPlan> existingCategories = new HashMap<String,TestPlan>();	
		if( testPlanDTO.getTestPlanList()!=null){
			testPlanList = testPlanDTO.getTestPlanList();
			for(TestPlan tPlan: testPlanList){
				existingCategories.put(tPlan.getCategoryId().trim(),tPlan);
			}
		}
		
		if(completeTestPlanList!=null){
			for (TestPlan testPlan : completeTestPlanList) {
				if(!existingCategories.containsKey(testPlan.getCategoryId().trim())){
					TestPlan tPlan = new TestPlan();
					tPlan.setCategoryId(testPlan.getCategoryId());
					tPlan.setCategoryName(testPlan.getCategoryName());
					tPlan.setCategoryQuestionCount(Constant.ZERO);
					tPlan.setCategoryOrder(Constant.NEGATIVE_ONE);
					tPlan.setGradableFlag(false);
					testPlanList.add(tPlan);	
				}
				else{
					existingCategories.get(testPlan.getCategoryId().trim()).setCategoryName(testPlan.getCategoryName());
				}
			}
		}
		testPlanDTO.setTestPlanList(testPlanList);
	}
	
	/*
	 * This method loads a Test Type
	 */	
	public void loadTestType(TestPlanDTO testPlanDTO){
		String testId = testPlanDTO.getTest().getTestId().trim();
		ITestWL testWL = testService.getTest(testId);
		testPlanDTO.setErrorCode(testWL.getErrorCode());
		if(testWL.getErrorCode() == ErrorCode.NO_ERROR){
			testPlanDTO.setTestAfterPreTierConversion(testWL.getTest());
			
			TestPlanDTO testPlanDTO1 = new TestPlanDTO();
			getAllCategoriesTestPlanList(testPlanDTO1);
			testPlanDTO.setErrorCode(testPlanDTO1.getErrorCode());
			if(testPlanDTO1.getErrorCode()==ErrorCode.NO_ERROR){
				
				ITestPlanListWL tpListWL = testService.getTestPlanListByTestId(testId);
				if(tpListWL.getErrorCode()==ErrorCode.NO_ERROR){
					testPlanDTO.setTestPlanListAfterPreTierConversion(tpListWL.getTestPlanList());
					fillTestPlanList(testPlanDTO,testPlanDTO1.getTestPlanList());
				}
				else if(tpListWL.getErrorCode()==ErrorCode.NULL_CATEGORY_LIST){
					testPlanDTO.setTestPlanList(testPlanDTO1.getTestPlanList());
				}
				else{
					testPlanDTO.setErrorCode(tpListWL.getErrorCode());					
				}
			}
		}			
	}
	
	/*
	 * This method updates a Test Type
	 */		
	public void updateTestType(TestPlanDTO testPlanDTO){
		testPlanDTO.setErrorCode(ErrorCode.NO_ERROR);
		String testId = testPlanDTO.getTest().getTestId().trim().toUpperCase();
		Test test = testPlanDTO.getTestAfterBusTierConversion();
		test.setTestId(testId);
		test.setLastModUserTime(new Date());
		test.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
		IErrorWL errWL = testService.updateTestTypeTest(test);
		testPlanDTO.setErrorCode(errWL.getErrorCode());
		if(errWL.getErrorCode()==ErrorCode.NO_ERROR){	
			if(errWL.getErrorCode()==ErrorCode.NO_ERROR){
				List<gov.ca.dmv.AKT.integration.BeansImpl.TestLang> testLangList  = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.TestLang>();
				gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang = new gov.ca.dmv.AKT.integration.BeansImpl.TestLang();
				testLang.getTlPrimaryKey().setTestId(testId);
				testLang.setLangId(Constant.DEFAULT_LANG);
				testLang.setTestLangName(test.getTestName());
				testLang.setTestLangStatus(Constant.ACTIVE);
				testLang.getTlPrimaryKey().setTestLangId(test.getTestId() + Constant.DEFAULT_LANG);
				testLang.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
				testLang.setLastModUserTime(new Date());
				testLangList.add(testLang);
				IErrorWL errorWL1 = testService.updateTestLangList(testLangList);	
				if(errorWL1.getErrorCode()==ErrorCode.NO_ERROR){
					List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList = null;
					if (testPlanDTO.getTestPlanList() != null && !testPlanDTO.getTestPlanList().isEmpty()) {
						for(TestPlan testPlan:testPlanDTO.getTestPlanList() ){
							testPlan.setTestId(testId);
							testPlan.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
							testPlan.setLastModUserTime(new Date());
							if(testPlan.isGradableFlag()){
								testPlan.setCategoryOrder(Constant.ONE);						
							}
							else{
								testPlan.setCategoryOrder(Constant.ZERO);		
							}
						}			
						testPlanList = testPlanDTO.getTestPlanListAfterBusTierConversion();
					}
					else {
						testPlanList = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan>();
						gov.ca.dmv.AKT.integration.BeansImpl.TestPlan tempTP = new gov.ca.dmv.AKT.integration.BeansImpl.TestPlan();
						tempTP.getTpPrimaryKey().setTestId(testId);
						testPlanList.add(tempTP);
					}
					IErrorWL errorWL = testService.modifyTestPlanList(testPlanList);
					testPlanDTO.setErrorCode(errorWL.getErrorCode());					
				}
			}
		}
	}
	
	/*
	 * This method saves a new Test Type
	 */	
	public void saveTestType(TestPlanDTO testPlanDTO){
		String testId = testPlanDTO.getTest().getTestId().trim().toUpperCase();
		ITestWL testWL = testService.getTest(testId);
		if(testWL.getErrorCode()==ErrorCode.MISSING_TEST){
			testPlanDTO.setErrorCode(ErrorCode.NO_ERROR);
			Test test = testPlanDTO.getDefaultTestAfterBusTierConversion();
			test.setTestId(testId);
			test.setTestName(testPlanDTO.getTest().getTestName());
			test.setTestOrigin(testPlanDTO.getTest().getTestOrigin());
			test.setMaxIncorrectNum(testPlanDTO.getTest().getMaxIncorrectNum());
			test.setTimeLimit(testPlanDTO.getTest().getTimeLimit());
			test.setTestQuestionCount(testPlanDTO.getTest().getTestQuestionCount());
			test.setLastModUserTime(new Date());
			test.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
			IErrorWL errWL = testService.saveTest(test);
			testPlanDTO.setErrorCode(errWL.getErrorCode());
			if(errWL.getErrorCode()==ErrorCode.NO_ERROR){
				List<gov.ca.dmv.AKT.integration.BeansImpl.TestLang> testLangList  = new ArrayList<gov.ca.dmv.AKT.integration.BeansImpl.TestLang>();
				gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang = new gov.ca.dmv.AKT.integration.BeansImpl.TestLang();
				testLang.getTlPrimaryKey().setTestId(testId);
				testLang.setLangId(Constant.DEFAULT_LANG);
				testLang.setTestLangName(test.getTestName());
				testLang.setTestLangStatus(Constant.ACTIVE);
				testLang.getTlPrimaryKey().setTestLangId(test.getTestId() + Constant.DEFAULT_LANG);
				testLang.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
				testLang.setLastModUserTime(new Date());
				testLangList.add(testLang);
				IErrorWL errorWL = testService.saveTestLangList(testLangList);	
				if(errorWL.getErrorCode()==ErrorCode.NO_ERROR && testPlanDTO.getTestPlanList()!=null){
					for(TestPlan testPlan:testPlanDTO.getTestPlanList() ){
						testPlan.setTestId(testId);
						testPlan.setLastModUsername(testPlanDTO.getTest().getLastModUsername());
						testPlan.setLastModUserTime(new Date());
						if(testPlan.isGradableFlag()){
							testPlan.setCategoryOrder(Constant.ONE);						
						}
						else{
							testPlan.setCategoryOrder(Constant.ZERO);		
						}
					}
					
					List<gov.ca.dmv.AKT.integration.BeansImpl.TestPlan> testPlanList = testPlanDTO.getTestPlanListAfterBusTierConversion();
					IErrorWL errorWL1 = testService.saveTestPlanList(testPlanList);
					testPlanDTO.setErrorCode(errorWL1.getErrorCode());
				}
				else{
					testPlanDTO.setErrorCode(errorWL.getErrorCode());
				}
			}
			else{
				testPlanDTO.setErrorCode(errWL.getErrorCode());
			}
			
		}
		else if(testWL.getErrorCode()==ErrorCode.NO_ERROR){
			testPlanDTO.setErrorCode(ErrorCode.DUPLICATE_TEST_ID);
		}
		else{
			testPlanDTO.setErrorCode(testWL.getErrorCode());
		}
	}
	

	
	/*
	 * This method searches for a test by name and id
	 */	
	public void searchTestType(TestDTO testDTO){
		Test test = testDTO.getTestListAfterBusTierConversion().get(Constant.FIRST_ELEMENT);		
		ITestListWL tlWL = testService.getTestListByIdAndName(test);
		testDTO.setErrorCode(tlWL.getErrorCode());
		if(tlWL.getErrorCode() == ErrorCode.NO_ERROR){
			testDTO.setTestListAfterPreTierConversion(tlWL.getTestList());
		}
	}
	
	private Map<String, String> buildCategoryNameMap() {
		Map<String, String> categoryMap = new HashMap<String, String>();
		ICategoryListWL categoryListWL = testService.getCategoriesList();
		
		for (Category category : categoryListWL.getCategoryList()) {
			categoryMap.put(category.getCategoryId(), category.getCategoryName());
		}
		return categoryMap;
	}

	/*
	 * This method is called to update test with max error count
	 */
	public void updateTest(TestPlanDTO testPlanDTO) {
		testPlanDTO.setErrorCode(ErrorCode.NO_ERROR);
		gov.ca.dmv.AKT.integration.BeansImpl.Test test = new gov.ca.dmv.AKT.integration.BeansImpl.Test();
		test.setTestId(testPlanDTO.getTest().getTestId());
		test.setMaxIncorrectNum(testPlanDTO.getTest().getMaxIncorrectNum());
		test.setTestQuestionCount(testPlanDTO.getTest().getTestQuestionCount());
		IErrorWL errWL = testService.updateTest(test);
		if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
			testPlanDTO.setErrorCode(errWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to update test plans for a test.
	 */
	public void updateTestPlanByTestId(TestPlanDTO testPlanDTO) {
		testPlanDTO.setErrorCode(ErrorCode.NO_ERROR);
		IErrorWL errWL = testService.updateTestPlanList(testPlanDTO.getTest().getTestId(), 
				           testPlanDTO.getTestPlanListAfterBusTierConversion());
		if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
			testPlanDTO.setErrorCode(errWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get the language specific questions and answers that are pending on review.
	 */
	public void getPendingReviewQuesAns(QuestionLangDTO quesLangDTO) {
		IQuestionLangListWL qlWL = testService.getPendingReviewQues();
		quesLangDTO.setErrorCode(qlWL.getErrorCode());
		quesLangDTO.setQuestionLangListAfterPreTierConversion(qlWL.getQuestionLangList());
	}

	/*
	 * This method is called to approve or deny a question and its answers that were reviewed.
	 */
	public void approveDenyQuestion(QuestionLangDTO quesLangDTO) {
		Integer quesGenId = quesLangDTO.getQuestionLangList().get(Constant.FIRST_ELEMENT).getQuestionGenId();
		String reviewStatus = quesLangDTO.getQuestionLangList().get(Constant.FIRST_ELEMENT).getChangeReviewStatusCode();
		IQuesAnswWL qaWL = testService.getQuesAnswByAutoGenId(quesGenId);
		quesLangDTO.setErrorCode(qaWL.getErrorCode());
		if(qaWL.getErrorCode() == ErrorCode.NO_ERROR) {
			QuesAnsw currQuesAnsw = qaWL.getQuesAnsw();
			QuestionLang ql = currQuesAnsw.getQuestionLang();
			Date currDate = new Date();
			ql.setLastModUsername(getUserId());
			ql.setLastModUserTime(currDate);
			if(reviewStatus.trim().equalsIgnoreCase(Constant.APPROVED)) {
				if(ql.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.ACTIVE)) {
					IQuesAnswWL qaWL2 = testService.getActiveQuesAnswByQuesLangId(ql.getQuestionLangId());
					quesLangDTO.setErrorCode(qaWL2.getErrorCode());
					if(qaWL2.getErrorCode() == ErrorCode.NO_ERROR) {
						QuesAnsw oldQuesAnsw = qaWL2.getQuesAnsw();
						if(oldQuesAnsw != null) {
							QuestionLang oldQL = oldQuesAnsw.getQuestionLang();
							oldQL.setQuestionLangStatus(Constant.INACTIVE);
							oldQL.setLastModUsername(getUserId());
							oldQL.setLastModUserTime(currDate);
							IErrorWL errrWL = testService.updateQuesLang(oldQL);
							quesLangDTO.setErrorCode(errrWL.getErrorCode());
							if(errrWL.getErrorCode() == ErrorCode.NO_ERROR) {
								List<Answer> oldAnsList = oldQuesAnsw.getAnswerList();
								for(Answer oldAns: oldAnsList) {
									oldAns.setAnswerStatus(Constant.INACTIVE);
									oldAns.setLastModUsername(getUserId());
									oldAns.setLastModUserTime(currDate);
								}
								IErrorWL erWL = testService.updateAnsList(oldAnsList);
								quesLangDTO.setErrorCode(erWL.getErrorCode());
							}
						}
					}
				}
				else if(ql.getQuestionLangStatus().trim().equalsIgnoreCase(Constant.INACTIVE)) {
					IAuditWL audWL = auditService.getAuditByKeyAndTable(String.valueOf(ql.getQuestionGenId()), Constant.QUESTION_LANG_TABLE);
					if(audWL.getErrorCode() != ErrorCode.MISSING_AUDIT)
						quesLangDTO.setErrorCode(audWL.getErrorCode());
					if(audWL.getErrorCode() == ErrorCode.NO_ERROR) {
						Audit audit = audWL.getAudit();
						Integer oldQuesGenId = Integer.parseInt(audit.getOldValue());
						IQuesAnswWL quesWL = testService.getQuesAnswByAutoGenId(oldQuesGenId);
						quesLangDTO.setErrorCode(quesWL.getErrorCode());
						if(quesWL.getErrorCode() == ErrorCode.NO_ERROR) {
							QuestionLang oldQL = quesWL.getQuesAnsw().getQuestionLang();
							oldQL.setQuestionLangStatus(Constant.INACTIVE);
							oldQL.setLastModUsername(getUserId());
							oldQL.setLastModUserTime(currDate);
							IErrorWL errorWL = testService.updateQuesLang(oldQL);
							quesLangDTO.setErrorCode(errorWL.getErrorCode());
						}
					}
				}
				ql.setChangeReviewStatusCode(Constant.APPROVED);
				IErrorWL errWL = testService.updateQuesLang(ql);
				quesLangDTO.setErrorCode(errWL.getErrorCode());
			}
			else if(reviewStatus.trim().equalsIgnoreCase(Constant.DENIED)) {
				ql.setChangeReviewStatusCode(Constant.DENIED);
				IErrorWL errorWL = testService.updateQuesLang(ql);
				quesLangDTO.setErrorCode(errorWL.getErrorCode());
			}
		}
	}

	/*
	 * This method is called to save a new category.
	 */
	@Override
	public void saveCategoryType(CategoryDTO categoryDTO) {
		gov.ca.dmv.AKT.presentation.Beans.Category category = categoryDTO.getCategoryList().get(Constant.FIRST_ELEMENT);
		
		Category categoryBO = new Category();
		String Id=category.getCategoryId();
		ICategoryListWL categoryListWL = categoryService.getCategory(Id);
		if (categoryListWL.getErrorCode() == ErrorCode.MISSING_CATEGORY) {
			categoryDTO.setErrorCode(ErrorCode.NO_ERROR);
			categoryBO.setCategoryId(category.getCategoryId());
			categoryBO.setCategoryDesc(category.getCategoryDesc());
			categoryBO.setCategoryName(category.getCategoryName());
			categoryBO.setLastModUsername(getUserId());
			categoryBO.setLastModUserTime(new Date());
			IErrorWL errWL = categoryService.saveCategory(categoryBO);
			categoryDTO.setErrorCode(errWL.getErrorCode());
		}
		else if(categoryDTO.getErrorCode() == ErrorCode.NO_ERROR) {
			categoryDTO.setErrorCode(ErrorCode.DUPLICATE_CATEGORY_ID);
		} 
		else {
			categoryDTO.setErrorCode(categoryListWL.getErrorCode());
		}
	}

	public CategoryDTO loadCategory(CategoryDTO categoryDTO) {
		gov.ca.dmv.AKT.presentation.Beans.Category category = new gov.ca.dmv.AKT.presentation.Beans.Category();
		category=(categoryDTO.getCategoryList().get(Constant.FIRST_ELEMENT));
		String Id=category.getCategoryId();
		ICategoryListWL categoryListWL=categoryService.getCategory(Id);
		if(categoryListWL.getErrorCode()==ErrorCode.NO_ERROR){
			List<Category> categorylistBO=categoryListWL.getCategoryList();
			categoryDTO.setCategoryListAfterPreTierConversion(categorylistBO);       
			categoryDTO.setErrorCode(categoryListWL.getErrorCode());
		}
		else{
			categoryDTO.setErrorCode(categoryListWL.getErrorCode());
		}
	return categoryDTO;
	}

	@Override
	public CategoryDTO updateCategory(CategoryDTO categoryDTO) {
		
		gov.ca.dmv.AKT.presentation.Beans.Category category = new gov.ca.dmv.AKT.presentation.Beans.Category();
		category=(categoryDTO.getCategoryList().get(Constant.FIRST_ELEMENT));
		Category categoryBO= new Category();
		categoryBO.setCategoryId(category.getCategoryId());
		categoryBO.setCategoryDesc(category.getCategoryDesc());
		categoryBO.setCategoryName(category.getCategoryName());
		categoryBO.setLastModUsername(getUserId());
		categoryBO.setLastModUserTime(new Date());
		
		IErrorWL errorWL=categoryService.updateCategory(categoryBO);
		if(errorWL.getErrorCode()==ErrorCode.NO_ERROR){
			String Id=categoryBO.getCategoryId();
			ICategoryListWL categoryListWL=categoryService.getCategory(Id);
			List<Category> categorylistBO=categoryListWL.getCategoryList();
			categoryDTO.setCategoryListAfterPreTierConversion(categorylistBO);
			categoryDTO.setErrorCode(errorWL.getErrorCode());
		}
		else{
			categoryDTO.setErrorCode(errorWL.getErrorCode());
		}
	return categoryDTO;
	}

	@Override
	public CategoryDTO searchCategory(CategoryDTO categoryDTO) {
		
		gov.ca.dmv.AKT.presentation.Beans.Category category = new gov.ca.dmv.AKT.presentation.Beans.Category();
		CategoryDTO categoryDTO1= new CategoryDTO();
		category=(categoryDTO.getCategoryList().get(Constant.FIRST_ELEMENT));
		Category categoryBO= new Category();
		categoryBO.setCategoryId(category.getCategoryId());
		categoryBO.setCategoryName(category.getCategoryName());
		ICategoryListWL cateorylistWL=categoryService.searchCategory(categoryBO);
		if(cateorylistWL.getErrorCode()==ErrorCode.NO_ERROR){
			List<Category> categorylistBO=(cateorylistWL.getCategoryList());
			categoryDTO1.setCategoryListAfterPreTierConversion(categorylistBO);
	    }
		else if(cateorylistWL.getErrorCode()!= ErrorCode.NO_ERROR){
		   categoryDTO1.setErrorCode(cateorylistWL.getErrorCode());
			
		}
		return categoryDTO1;
	}
  
	
	
	
	/**
	 * This method is used to save a new Handbook section 
	 */
	@Override
	public HandbookRefDTO saveHanbookSection(HandbookRefDTO handbookDTO) {
		List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList= new ArrayList<gov.ca.dmv.AKT.presentation.Beans.HandbookRef>();
		HandbookRef handbookBO= new HandbookRef();
		HRPrimaryKey hrPrimaryKey = new HRPrimaryKey();
		handbookRefList  =	handbookDTO.getHandbookRefList();
		gov.ca.dmv.AKT.presentation.Beans.HandbookRef handbook= handbookRefList.get(Constant.FIRST_ELEMENT);
		hrPrimaryKey.setLangId(handbook.getLangId());
		hrPrimaryKey.setHandbookRef(handbook.getHandbookRef());
		IHandbookRefListWL handbookList = handbookRefService.getHandbook(hrPrimaryKey);
		if (handbookList .getErrorCode() == ErrorCode.MISSING_HANDBOOKREF) {
			handbookDTO.setErrorCode(ErrorCode.NO_ERROR);
			hrPrimaryKey.setLangId(handbook.getLangId());
			hrPrimaryKey.setHandbookRef(handbook.getHandbookRef());
			handbookBO.setHandbookSectionDesc(handbook.getHandbookSectionDesc());
			handbookBO.setHandbookSectionName(handbook.getHandbookSectionName());
			handbookBO.setHrPrimaryKey(hrPrimaryKey);
			handbookBO.setLastModUsername(Constant.LASTMODUSR_NME);
			handbookBO.setLastModUserTime(new Date());
			IErrorWL errWL=handbookRefService.saveHandbook(handbookBO);
			handbookDTO.setErrorCode(errWL.getErrorCode());
		}
		else if(handbookDTO.getErrorCode()==ErrorCode.NO_ERROR){
			handbookDTO.setErrorCode(ErrorCode.DUPLICATE_HANDBOOKREF);
		}
		else{
			handbookDTO.setErrorCode(handbookList.getErrorCode());
		}
		return handbookDTO;
	}
	/**
	 * This method is used load handbook for view
	 */
	@Override
	public HandbookRefDTO loadHandbok(HandbookRefDTO handbookDTO) {
	
		gov.ca.dmv.AKT.presentation.Beans.HandbookRef handbook = new gov.ca.dmv.AKT.presentation.Beans.HandbookRef();
		handbook=(handbookDTO.getHandbookRefList().get(Constant.FIRST_ELEMENT));
		HRPrimaryKey hrPrimaryKey = new HRPrimaryKey();
		hrPrimaryKey.setLangId(handbook.getLangId());
		hrPrimaryKey.setHandbookRef(handbook.getHandbookRef());
		IHandbookRefListWL handbookListWL = handbookRefService.getHandbook(hrPrimaryKey);
		if(handbookListWL.getErrorCode()==ErrorCode.NO_ERROR){
			List<HandbookRef> handbookListBO=handbookListWL.getHandbookRefList();
			handbookDTO.setHandbookRefListAfterPreTierConversion(handbookListBO);      
			handbookDTO.setErrorCode(handbookListWL.getErrorCode());
		}
		else{
			handbookDTO.setErrorCode(handbookListWL.getErrorCode());

		}
	return handbookDTO;
	}
	
	/**
	 * This method is update a handbook name or/and desc
	 */
	@Override
	public void updateHanbookSection(HandbookRefDTO handbookDTO) {
		List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList= new ArrayList<gov.ca.dmv.AKT.presentation.Beans.HandbookRef>();
		HandbookRef handbookBO= new HandbookRef();
		HRPrimaryKey hrPrimaryKey = new HRPrimaryKey();
		handbookRefList  =	handbookDTO.getHandbookRefList();
		gov.ca.dmv.AKT.presentation.Beans.HandbookRef handbook= handbookRefList.get(Constant.FIRST_ELEMENT);
		hrPrimaryKey.setLangId(handbook.getLangId());
		hrPrimaryKey.setHandbookRef(handbook.getHandbookRef());
		handbookBO.setHandbookSectionDesc(handbook.getHandbookSectionDesc());
		handbookBO.setHandbookSectionName(handbook.getHandbookSectionName());
		handbookBO.setHrPrimaryKey(hrPrimaryKey);
		handbookBO.setLastModUsername(Constant.LASTMODUSR_NME);
		handbookBO.setLastModUserTime(new Date());
		IHandbookRefListWL handbookListWL=handbookRefService.updateHandbook(handbookBO);
		if(handbookListWL.getErrorCode()==ErrorCode.NO_ERROR){  
			handbookDTO.setErrorCode(handbookListWL.getErrorCode());
		}
		else{
			handbookDTO.setErrorCode(handbookListWL.getErrorCode());

		}
		
	}

	/**
	 * This method is used to search a handbook by handbookRef and/or langId
	 */
	@Override
	public HandbookRefDTO searchHandbookRefList(HandbookRefDTO handbookRefDTO) {
		List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList= new ArrayList<gov.ca.dmv.AKT.presentation.Beans.HandbookRef>();
		HandbookRef handbookBO= new HandbookRef();
		HRPrimaryKey hrPrimaryKey = new HRPrimaryKey();
		handbookRefList  =	handbookRefDTO.getHandbookRefList();
		gov.ca.dmv.AKT.presentation.Beans.HandbookRef handbook= handbookRefList.get(Constant.FIRST_ELEMENT);
		hrPrimaryKey.setLangId(handbook.getLangId());
		hrPrimaryKey.setHandbookRef(handbook.getHandbookRef());
		handbookBO.setHrPrimaryKey(hrPrimaryKey);
		handbookBO.setHandbookSectionName(handbook.getHandbookSectionName());
		IHandbookRefListWL handbookListWL = handbookRefService.searchHandbook(handbookBO,hrPrimaryKey);
			if(handbookListWL.getErrorCode()==ErrorCode.NO_ERROR){  
				handbookRefDTO.setErrorCode(handbookListWL.getErrorCode());
				handbookRefDTO.setHandbookRefListAfterPreTierConversion(handbookListWL.getHandbookRefList());
				setLangNameInHandbookRef(handbookRefDTO.getHandbookRefList());
			}
			else{
				handbookRefDTO.setErrorCode(handbookListWL.getErrorCode());
			}
		return handbookRefDTO;
	}
	/**
	 * 
	 * @param handbookRefList
	 * This method is used to set the LangName to the handBook objects in a list.
	 */
	private void setLangNameInHandbookRef(List<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> handbookRefList) {
		List<Lang> lang=	this.examSeedData.getLangList();
		for(gov.ca.dmv.AKT.presentation.Beans.HandbookRef handbookListObj: handbookRefList){
			for(Lang langObjBO: lang){
				if(handbookListObj.getLangId().equals(langObjBO.getLangId())){
					handbookListObj.setLangName(langObjBO.getLangName());
				}
			}	
		}		
	}
}