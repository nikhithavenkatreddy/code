package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.EaseAppBusDelegate;
import gov.ca.dmv.AKT.business.Services.ApplicationService;
import gov.ca.dmv.AKT.business.Services.ExamService;
import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IEaseInboundMessageWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.EaseTest;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.JMS.Beans.EASEObjectSent;
import gov.ca.dmv.AKT.integration.JMS.Services.JMSSender;
import gov.ca.dmv.AKT.presentation.Beans.Application;
import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;

import java.text.SimpleDateFormat;
import java.util.List;

public class EaseAppBusDelegateImpl extends BaseBusDelegateImpl implements EaseAppBusDelegate {

	private ApplicationService applicationService;
	private ExamService        examService;
	private SessionService     sessionService;
	private JMSSender          jmsSender;
	
	public JMSSender getJmsSender() {
		return jmsSender;
	}

	public void setJmsSender(JMSSender jmsSender) {
		this.jmsSender = jmsSender;
	}
	
	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}

	public ExamService getExamService() {
		return examService;
	}

	public void setExamService(ExamService examService) {
		this.examService = examService;
	}

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	/*
	 * This method is called to persist the data received from EASE application in Vault, Application, Exam, 
	 * ExamHistory and Test tables.
	 */
	public void createApp(EaseAppDTO easeAppDTO) {
		IVault vault = easeAppDTO.getVaultAfterBusTierConversion();
		vault.setState(Constant.CALIFORNIA_STATE_CODE);
		IApplication application = easeAppDTO.getApplicationAfterBusTierConversion();
		List<EaseTest> easeTestListRequired = easeAppDTO.getEaseTestListRequiredAfterBusTierConversion();
		List<EaseTest> easeTestListOptional = easeAppDTO.getEaseTestListOptionalAfterBusTierConversion();
		gov.ca.dmv.AKT.integration.BeansImpl.EaseApplication easeApplication = new gov.ca.dmv.AKT.integration.BeansImpl.EaseApplication();
		easeApplication.setApplication(application);
		easeApplication.setVault(vault);
		easeApplication.setEaseTestListRequired(easeTestListRequired);
		easeApplication.setEaseTestListOptional(easeTestListOptional);
		IApplication application1 = applicationService.create(easeApplication);
		boolean stubRequired = false;
		for(EaseTest easeTest: easeTestListRequired) {
			easeTest.setApplicationId(application1.getApplicationId());
			easeTest.setOfficeId(application1.getOfficeId());
			easeTest.setSignTestSatisfiedFlag(Constant.YES);
			if(application1.getSignTestSatisfiedFlag().equalsIgnoreCase(Constant.NO) && !stubRequired) {
				easeTest.setSignTestSatisfiedFlag(Constant.NO);
				easeTest.setSignTestHistory(easeAppDTO.getSignTestHistory());
			}
			if(examService.createRequiredExams(easeTest)) {
				stubRequired = true;
			}
		}
		for(EaseTest easeTest: easeTestListOptional) {
			easeTest.setApplicationId(application1.getApplicationId());
			easeTest.setOfficeId(application1.getOfficeId());
			easeTest.setSignTestSatisfiedFlag(Constant.YES);
			if(application1.getSignTestSatisfiedFlag().equalsIgnoreCase(Constant.NO) && !stubRequired) {
				easeTest.setSignTestSatisfiedFlag(Constant.NO);
				easeTest.setSignTestHistory(easeAppDTO.getSignTestHistory());
			}
			if(examService.createRequiredExams(easeTest)) {
				stubRequired = true;
			}
		}
	}
	
	/*
	 * This method is called to send the result to EASE
	 */
	public void sendResult(EaseAppDTO easeAppDTO) {
		easeAppDTO.setErrorCode(ErrorCode.NO_ERROR);
		int examId = easeAppDTO.getExam().getExamId();
		IExamWL exWL = examService.getExamByExamId(examId);
		easeAppDTO.setErrorCode(exWL.getErrorCode());
		if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IExam exam = exWL.getExam();
			IApplicationWL appWL = applicationService.getApplication(exam.getApplicationId());
			easeAppDTO.setErrorCode(appWL.getErrorCode());
			if(appWL.getErrorCode() == ErrorCode.NO_ERROR) {				
				IApplication app = appWL.getApplication();
				//Based on design, for AppType = CHP, DS or OL, do not send test result to EASE.  
				
				// Fixed Defect 87.  easeAppDTO was causing null exception.  Moved from before 'IF' statement
				Application application =  new Application();
				application.setApplicationStatusCode(app.getApplicationStatusCode());
				easeAppDTO.setApplication(application);
				if (app != null && !(Constant.APP_TYPE_DS.equals(app.getApplicationType()) 
						|| Constant.APP_TYPE_OL.equals(app.getApplicationType())
						|| Constant.APP_TYPE_CHP.equals(app.getApplicationType()))) {
//					Application application =  new Application();
//					application.setApplicationStatusCode(app.getApplicationStatusCode());
//					easeAppDTO.setApplication(application);
					IVaultWL vaultWL = applicationService.getVault(app.getVaultId());
					easeAppDTO.setErrorCode(vaultWL.getErrorCode());
					if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR ) {
						easeAppDTO.setMessageSent(false);
						if(app.getEaseApplicationId() != null && app.getEaseApplicationId().trim().length()>Constant.ZERO && !exam.getTestId().trim().equals(Constant.AMBULANCE_TEST_ID)){
							IVault vault = vaultWL.getVault();
							EASEObjectSent easeObject = new EASEObjectSent();
							easeObject.setApplicationId(app.getEaseApplicationId().trim());
							easeObject.setDlNumber(vault.getDlNumber().trim());
							easeObject.setOfficeId(exam.getOfficeId().trim());
							SimpleDateFormat formatter = new SimpleDateFormat(Constant.EASE_DATE_FORMAT);
							SimpleDateFormat formatter2 = new SimpleDateFormat(Constant.EASE_TIME_FORMAT);
							String testDate = formatter.format(exam.getExamEndTime());
							String testTime = formatter2.format(exam.getExamEndTime());
							easeObject.setTestDate(testDate);
							gov.ca.dmv.AKT.integration.BeansImpl.Lang lang = examSeedData.getLangByLangId(exam.getLangId());
							easeObject.setTestLang(lang.getProgLangCode().trim());
							easeObject.setTestResult(exam.getPassFailIndicator());
							if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.PASS))
								easeObject.setTestResult(Constant.EASE_PASS);
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PRINT_UPDATE_SCORE_STATUS)) {
								if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.PASS)) {
									easeObject.setTestResult(Constant.MANUAL_PASS);
								}
								else {
									easeObject.setTestResult(Constant.MANUAL_FAIL);
								}
							}	
							easeObject.setTestTime(testTime);
							easeObject.setTestType(exam.getEaseTestId().trim());
							easeObject.setTechId(app.getTechId());
							jmsSender.setEaseObjectSent(easeObject);
							jmsSender.sendMesage();
							easeAppDTO.setExamAfterPreTierConversion(exam);
							easeAppDTO.setMessageSent(true);
						}
					}
				}
			}
		}
	}
	
	/*
	 * This method is called to save the string received from EASE
	 */
	public void saveReceivedString(EaseAppDTO easeAppDTO) {
		easeAppDTO.setErrorCode(ErrorCode.NO_ERROR);
		String receivedStr = easeAppDTO.getReceivedString();
		IIntegerWL errWL = sessionService.saveEaseReceivedString(receivedStr);
		if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
			easeAppDTO.setEaseMsgId(errWL.getInteger());
		}
		else {
			easeAppDTO.setErrorCode(errWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to update the status of ease received message indicator
	 */
	public void updateEaseReceivedIndicator(EaseAppDTO easeAppDTO) {
		easeAppDTO.setErrorCode(ErrorCode.NO_ERROR);
		Integer easeMsgId = easeAppDTO.getEaseMsgId();
		IEaseInboundMessageWL messageWL = sessionService.getEaseInboundMessage(easeMsgId);
		if(messageWL.getErrorCode() == ErrorCode.NO_ERROR) {
			IEaseInboundMessage message = messageWL.getEaseInboundMessage();
			message.setEaseMessageIndicator(easeAppDTO.getEaseReceivedMessageInd().trim());
			IErrorWL errWL = sessionService.saveEaseInboundMessage(message);
			if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
				easeAppDTO.setErrorCode(errWL.getErrorCode());
			}
		}
		else {
			easeAppDTO.setErrorCode(messageWL.getErrorCode());
		}
	}
}
