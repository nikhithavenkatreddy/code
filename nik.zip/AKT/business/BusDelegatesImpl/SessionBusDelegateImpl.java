package gov.ca.dmv.AKT.business.BusDelegatesImpl;

import gov.ca.dmv.AKT.business.BusDelegates.SessionBusDelegate;
import gov.ca.dmv.AKT.business.Services.ApplicationService;
import gov.ca.dmv.AKT.business.Services.ExamService;
import gov.ca.dmv.AKT.business.Services.SessionService;
import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ILangWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.constants.Constant;
import gov.ca.dmv.AKT.constants.TimeLimitTypeConstant;
import gov.ca.dmv.AKT.errors.ErrorCode;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.ActiveSessionAndExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Health;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.Office;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.presentation.Beans.Applicant;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.FailedYOBDTO;
import gov.ca.dmv.AKT.presentation.DTO.HealthCheckDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.SessionDTO;
import gov.ca.dmv.AKT.presentation.DTO.YOBDTO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class SessionBusDelegateImpl extends BaseBusDelegateImpl implements SessionBusDelegate {

	private SessionService                                sessionService;
	private ApplicationService                            applicationService;
	private ExamService                                   examService;
	
	public ExamService getExamService() {
		return examService;
	}

	public void setExamService(ExamService examService) {
		this.examService = examService;
	}

	public SessionService getSessionService() {
		return sessionService;
	}

	public void setSessionService(SessionService sessionService) {
		this.sessionService = sessionService;
	}
	
	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public Office getOfficeByTerminalIP(String terminalIP) {
		return examSeedData.getOfficeByTerminalIP(terminalIP);
	}
	
	/*
	 * This method is called to get the list of all languages
	 */
	public void getLangList(LangDTO langDTO) {	
		langDTO.setErrorCode(ErrorCode.NO_ERROR);
		List<Lang> langList = examSeedData.getLangList();
		prepareLanguageSet(langList, langDTO);
	}
	
	private void prepareLanguageSet(List<Lang> langList, LangDTO langDTO) {
		List<Lang> langList2 = new ArrayList<Lang>();
		int m = 0;
		int n = 0;
		int setNo = langDTO.getSetNo();
		if(setNo == Constant.ONE) {
			n = 10;
		}
		else if(setNo == Constant.TWO) {
			m = 10;
			n = 21;
		}
		else {
			m = 21;
			//n = 32;
			n = 32;
		}
		for(int i=m; i<n; i++) {
			if(i == Constant.ZERO) {
				langDTO.setEnglishAfterPreTierConversion(langList.get(i));
			}
			else if(i == Constant.ONE) {
				langDTO.setSpanishAfterPreTierConversion(langList.get(i));
			}
			else {
				langList2.add(langList.get(i));
			}
		}
		langDTO.setLangListAfterPreTierConversion(langList2);
	}

	/*
	 * This method is called to validate YOB
	 */
	public void validateYOB(YOBDTO yobDTO) {
		yobDTO.setErrorCode(ErrorCode.NO_ERROR);
		IBooleanWL boolWL = applicationService.validateYOB(yobDTO.getYobAfterBusTierConversion());
		if(boolWL.getErrorCode() == ErrorCode.NO_ERROR) {
			boolean validationSuccessful = boolWL.isFlag(); 
			yobDTO.setValidationSuccessful(validationSuccessful);
		}
		else {
			yobDTO.setErrorCode(boolWL.getErrorCode());
		}
	}

	/*
	 * This method is called to create the session after scanning DL from the barcode.
	 */
	public void createSession(SessionDTO sessionDTO) {
		Boolean flagValue = false;
		Boolean additionalTestFlag = false;
		ISession session = sessionDTO.getSessionAfterBusTierConversion();
		sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
		WorkstationMap wm = examSeedData.getWorkstationMapByIPAddress(session.getWorkstationIPAddress());
 		String officeId = wm.getOfficeId().trim();
		String dlNumber = sessionDTO.getDlNumber();
		flagValue = sessionDTO.getSession().getAdditionalTestFlag();
		if(flagValue==null)
			additionalTestFlag = false;
		else
			additionalTestFlag = true;
		gov.ca.dmv.AKT.integration.BeansImpl.DLFO dlfo = new gov.ca.dmv.AKT.integration.BeansImpl.DLFO();
		dlfo.setDlNumber(dlNumber);
		dlfo.setOfficeId(officeId);
		IApplicationWL applicationWL = applicationService.getApplication(dlfo);
		if(applicationWL.getErrorCode() == ErrorCode.NO_ERROR) 
		{
			IApplication application = applicationWL.getApplication();
			if(application == null) {
				sessionDTO.setErrorCode(ErrorCode.NULL_APPLICATION);
			}
			else 
			{
				IExamListWL exWL = examService.loadExams(application.getApplicationId());
				if(exWL.getErrorCode() == ErrorCode.NO_ERROR) {
					if(application.getApplicationStatusCode().trim().equalsIgnoreCase(Constant.PROVISIONAL)) {
						boolean hasUntakenexam = false; // checking to see the user has any untaken test so that he will not get PROVISIONAL error message.
						for(IExam exam: exWL.getExamList()) {
							if(exam.getPassFailIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE)) {
								// English language with sign test is not consider as a additional exam.
								if(!(sessionDTO.getSession().getLanguageCode().equalsIgnoreCase(Constant.LANG_ENGLISH) && exam.getTestId().equalsIgnoreCase(Constant.SIGN_TEST_ID))) {
									hasUntakenexam = true;
								}
							}
						}
						if(!hasUntakenexam) {
							IExamHistoryListWL examHisWL = applicationService.getExamHistoryByAppId(application.getApplicationId());
							if(examHisWL.getErrorCode() == ErrorCode.NO_ERROR) {
								List<IExamHistory> examHisList = examHisWL.getExamHistoryList();
								if(examHisList != null && examHisList.size() > Constant.ZERO) {
									for(IExamHistory eh: examHisList) {
										if(!eh.getAktStatusIndicator().equalsIgnoreCase(Constant.SINGLE_SPACE) && !eh.getAktStatusIndicator().equalsIgnoreCase(String.valueOf(Constant.ZERO))) {
											sessionDTO.setErrorCode(ErrorCode.PROVISIONAL);
										}
									}
								}
							}
							else {
								sessionDTO.setErrorCode(examHisWL.getErrorCode());
							}
						}
					}
					boolean paused = false;
					boolean resume = false;
					boolean isAllManuallyPrintedTest = true;
					if(exWL.getErrorCode() != ErrorCode.NULL_EXAM_LIST) {
						List<IExam> examList = exWL.getExamList();
						List<String> manuallyPrinted = Arrays.asList(
								Constant.VIEW_TEST_STATUS, Constant.PRINT_TEST_STATUS, Constant.REPRINT_TEST_STATUS, 
								Constant.VIEW_ANSWER_KEY_STATUS, Constant.PRINT_ANSWER_KEY_STATUS, Constant.REPRINT_ANSWER_KEY_STATUS );
						
						for(IExam exam: examList) {
							if (!manuallyPrinted.contains(exam.getCompletionReasonCode())) {
								isAllManuallyPrintedTest = false;
							}
							if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.PAUSE)) {
								paused = true;
								break;
							} else if(exam.getCompletionReasonCode().equalsIgnoreCase(Constant.RESTART)){
								resume = true;
								ISessionBooleanWL boolWL = sessionService.isNewSessionPermitted(application.getApplicationId(), 
										session.getWorkstationIPAddress(), session.getLanguageCode(),resume, additionalTestFlag);
								if(boolWL.getErrorCode() == ErrorCode.NO_ERROR || boolWL.getErrorCode() == ErrorCode.AUTH_TERM_ACCESS) {
									boolean isNewSessionPermitted = boolWL.isFlag();
									if(!isNewSessionPermitted && !additionalTestFlag) {
										sessionDTO.setErrorCode(ErrorCode.NULL_SESSION);
									} else {
										IErrorWL errWL = examService.removeStub(exam);
										if(errWL.getErrorCode() == ErrorCode.NO_ERROR) {
											if (examSessionData.getSession() != null) {
												exam.setSessionId(examSessionData.getSession().getSessionId());
											}
											IErrorWL erWL = sessionService.reset(exam.getSessionId(),Constant.SESSION_ACTIVE);
											if(erWL.getErrorCode() == ErrorCode.NO_ERROR) {
												IErrorWL errorWL = sessionService.resetTerminal(exam.getSessionId(), session.getWorkstationIPAddress());
												if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
													ISession session1 = new gov.ca.dmv.AKT.integration.BeansImpl.Session();
													session1.setApplicationId(application.getApplicationId());
													session1.setSessionId(exam.getSessionId());
													session1.setVaultId(application.getVaultId());
													sessionDTO.setSessionAfterPreTierConversion(session1);
													sessionDTO.setResumeExamId(exam.getExamId());
												} else{
													sessionDTO.setErrorCode(errorWL.getErrorCode());
												}
											} else {
												sessionDTO.setErrorCode(erWL.getErrorCode());
											}
										} else {
											sessionDTO.setErrorCode(errWL.getErrorCode());
										}
									}
								} else {
									sessionDTO.setErrorCode(boolWL.getErrorCode());
								}
							}
						}
						if (isAllManuallyPrintedTest) {
							sessionDTO.setErrorCode(ErrorCode.NULL_EXAM_LIST);
						}
					}
					if(paused) {
						sessionDTO.setErrorCode(ErrorCode.PAUSE_ERROR);
					}
					else if(!resume && sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
						ISessionBooleanWL boolWL = sessionService.isNewSessionPermitted(application.getApplicationId(), 
								session.getWorkstationIPAddress(), session.getLanguageCode(),resume , additionalTestFlag);
						if(boolWL.getErrorCode() == ErrorCode.NO_ERROR || boolWL.getErrorCode() == ErrorCode.AUTH_TERM_ACCESS) {
							boolean isNewSessionPermitted = boolWL.isFlag();
							if(!isNewSessionPermitted && !additionalTestFlag) {
								sessionDTO.setErrorCode(ErrorCode.NULL_SESSION);
							}
							else {
								ISession createdSession = null;
								if(boolWL.getErrorCode() != ErrorCode.AUTH_TERM_ACCESS) {
									Date currentDate = new Date();
									ISession session3 = new gov.ca.dmv.AKT.integration.BeansImpl.Session();
									session3.setApplicationId(application.getApplicationId());
									session3.setLanguageCode(session.getLanguageCode());
									session3.setLastModUserTime(currentDate);
									session3.setOfficeId(officeId);
									session3.setSessionStartTime(currentDate);
									session3.setVaultId(application.getVaultId());
									session3.setSessionStatusCode(Constant.SESSION_ACTIVE);
									session3.setWorkstationIPAddress(session.getWorkstationIPAddress());
									session3.setYobValidationFlag(Constant.NO);
									session3.setSessionEndTime(Constant.defaultDate);
									session3.setYobOverrideTime(Constant.defaultDate);
									session3.setLastModUsername(getUserId());
									ISessionWL sessionWL = sessionService.createSession(session3);
									sessionDTO.setErrorCode(sessionWL.getErrorCode());
									if(sessionWL.getErrorCode() == ErrorCode.NO_ERROR) {
										createdSession = sessionWL.getSession();
									}
								}
								else {
									createdSession = boolWL.getSession();
								}
								if(sessionDTO.getErrorCode() == ErrorCode.NO_ERROR) {
									sessionDTO.setSessionAfterPreTierConversion(createdSession);
								}
							}
						}
						else {
							sessionDTO.setErrorCode(boolWL.getErrorCode());
						}
					}			
				} else {
					sessionDTO.setErrorCode(exWL.getErrorCode());
				}
			}
		}
		else {
			sessionDTO.setErrorCode(applicationWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get the list of failed YOB validations*
	 */
	public void getFailedYOBList(FailedYOBDTO failedYOBDTO, String appType) {
		failedYOBDTO.setErrorCode(ErrorCode.NO_ERROR);
		ISessionListWL sessionWL = sessionService.getFailedYOB(failedYOBDTO.getOfficeId());
		if(sessionWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ISession> sessionList = sessionWL.getSessionList();
			List<Applicant> applicantList = new ArrayList<Applicant>();
			for(ISession session: sessionList) {
				IVaultWL vaultWL = applicationService.getVault(session.getVaultId());
				IApplicationWL applicationWL = applicationService.getApplication(session.getApplicationId());
				if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
					IVault vault = vaultWL.getVault();
					if (applicationWL.getApplication().getApplicationType().equals(appType)) {
						Applicant applicant = new Applicant();
						applicant.setApplicationId(session.getApplicationId());
						applicant.setDlNumber(vault.getDlNumber());
						applicant.setFirstName(vault.getApplicationFirstName());
						applicant.setLastName(vault.getApplicationLastName());
						applicant.setSessionId(session.getSessionId());
						applicantList.add(applicant);
					}
				}
				else {
					failedYOBDTO.setErrorCode(vaultWL.getErrorCode());
					break;
				}
			}
			failedYOBDTO.setApplicantList(applicantList);
		}
		else {
			if(sessionWL.getErrorCode() != ErrorCode.MISSING_SESSION)
				failedYOBDTO.setErrorCode(sessionWL.getErrorCode());
		}
	}
	
	/*
	 * This method is called to get the list of failed to authenticate applicant.
	 */
	public void getFailedToAuthApplicantList(ApplicantDTO appDTO) {
		if(appDTO.getErrorCode() == ErrorCode.NO_ERROR){
		ISessionListWL sessionWL = sessionService.getFailedYOB(appDTO.getOfficeId());
		List<Applicant> notAuthApplicantList = new ArrayList<Applicant>();
		if(sessionWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ISession> sessionList = sessionWL.getSessionList();
			for(ISession session: sessionList) {
				for (Applicant applicant : appDTO.getApplicantList()) {
					if (applicant.getApplicationId().equals(session.getApplicationId())) {
						applicant.setSessionId(session.getSessionId());
						notAuthApplicantList.add(applicant);
					}
				}				
			}
			appDTO.setApplicantList(notAuthApplicantList);
		}
		else {
			if(sessionWL.getErrorCode() != ErrorCode.MISSING_SESSION) {
				appDTO.setErrorCode(sessionWL.getErrorCode());				
			}
			appDTO.setApplicantList(notAuthApplicantList);
		} }
		else
			appDTO.setErrorCode(ErrorCode.RECORD_NOT_FOUND);
		
	}

	/*
	 * This method is called override the yob validation by updating the session
	 */
	public void overrideYOBValidation(SessionDTO sessionDTO) {
		sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
		IErrorWL errWL = sessionService.overrideYOBValidation(sessionDTO.getSession().getSessionId());
		if(errWL.getErrorCode() != ErrorCode.NO_ERROR) {
			sessionDTO.setErrorCode(errWL.getErrorCode());
		}
	}

	/*
	 * This method is called to get a list of exams with active session
	 */
	public void getActiveExams(ApplicantDTO applicantDTO) {
		applicantDTO.setErrorCode(ErrorCode.NO_ERROR);
		IActiveSessionAndExamListWL actWL = sessionService.getActiveExams(applicantDTO.getOfficeId(), applicantDTO.getApplicationType());
		if(actWL.getErrorCode() == ErrorCode.NO_ERROR) {
			List<ActiveSessionAndExam> activeList = actWL.getActiveSessionAndExamList();
			List<Applicant> applicantList = new ArrayList<Applicant>();
			if (activeList != null)
			{
				for(ActiveSessionAndExam active: activeList) {
					IExam exam = active.getExam();
					ISession session = active.getSession();
					IStringWL strWL = sessionService.getWorkstationId(session.getWorkstationIPAddress());
					if(strWL.getErrorCode() == ErrorCode.NO_ERROR) {
						String workstationId = strWL.getString();
						IVaultWL vaultWL = applicationService.getVault(session.getVaultId());
						if(vaultWL.getErrorCode() == ErrorCode.NO_ERROR) {
							IVault vault = vaultWL.getVault();
							if(exam!=null){						
								ITestWL testWL = applicationService.getTest(exam.getTestId().trim());
								if(testWL.getErrorCode() == ErrorCode.NO_ERROR) {
										gov.ca.dmv.AKT.integration.BeansImpl.Test test = testWL.getTest();		
										Applicant applicant = new Applicant();
										applicant.setDlNumber(vault.getDlNumber());
										applicant.setExamType(test.getTestName());
										applicant.setFirstName(vault.getApplicationFirstName());
										applicant.setLastName(vault.getApplicationLastName());
										applicant.setWorkstationId(workstationId);
										applicant.setSessionId(session.getSessionId());
										applicant.setExamId(exam.getExamId());
										applicantList.add(applicant);
								}
								else {
									applicantDTO.setErrorCode(testWL.getErrorCode());
								}
							}
							else{
								Applicant applicant = new Applicant();
								applicant.setDlNumber(vault.getDlNumber());
								applicant.setExamType(Constant.EXAM_ABSENT);
								applicant.setFirstName(vault.getApplicationFirstName());
								applicant.setLastName(vault.getApplicationLastName());
								applicant.setWorkstationId(workstationId);
								applicant.setSessionId(session.getSessionId());
								applicant.setExamId(Constant.ZERO);
								applicantList.add(applicant);
							}
						}
						else {
							applicantDTO.setErrorCode(vaultWL.getErrorCode());
						}
					}
					else {
						applicantDTO.setErrorCode(strWL.getErrorCode());
					}
				}
				applicantDTO.setApplicantList(applicantList);
			}
		}
		else if(actWL.getErrorCode() != ErrorCode.MISSING_SESSION &&
				actWL.getErrorCode() != ErrorCode.MISSING_EXAMS){
			applicantDTO.setErrorCode(actWL.getErrorCode());
		}
	}

	/*
	 * This method is called to terminate a session
	 */
	public void terminateSession(SessionDTO sessionDTO) {
		sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
		IErrorWL errWL = sessionService.endSession(sessionDTO.getSession().getSessionId());
		sessionDTO.setErrorCode(errWL.getErrorCode());
	}

	/*
	 * This method is called to end the session after setting the yob validation flag to fail
	 */
	public void endSession(SessionDTO sessionDTO) {
		IErrorWL errorWL = sessionService.endSessionWithYOBValidationFail(sessionDTO.getSession().getSessionId());
		if(errorWL.getErrorCode() == ErrorCode.NO_ERROR) {
			sessionDTO.setErrorCode(ErrorCode.NO_ERROR);
		}
		else {
			sessionDTO.setErrorCode(errorWL.getErrorCode());
		}
	}

	/*
	* This method is called to find the timeout value for the screen
	*/
	public Integer getScreenTimeout(String screen){
		Integer timeout = 0;
		if(screen.trim().toLowerCase().equals("testrules")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.TEST_INSTRUCTIONS_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_TEST_INSTRUCTIONS_SCREEN;
		}		
		else if(screen.trim().toLowerCase().equals("samplequestionconfirm")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.SAMPLE_OR_START_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_SAMPLE_OR_START_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("getdlinfo") || screen.trim().toLowerCase().equals("validateyob")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.SEC_AUTHENTICATION_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_SEC_AUTHENTICATION_SCREEN;
		}
		else if(screen.trim().toLowerCase().equals("addtnl_messages_screen")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.ADDTNL_MESSAGES_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_ADDTNL_MESSAGES_SCREEN;
		}	
		else if(screen.trim().toLowerCase().equals("perjury")){
			timeout = examSeedData.getTimeLimitByName(TimeLimitTypeConstant.PERJURY_SCREEN);
			timeout = timeout!=null?timeout:TimeLimitTypeConstant.DEFAULT_PERJURY_SCREEN;
		}	
		
		return timeout*TimeLimitTypeConstant.MILLISECONDS;		
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * This method is called for checking if the cache was loaded with seed data correctly and if there's a valid db connection.
	 * This information will be used for sending a nagios alert in case loading cache or connecting to the db failed.
	 */
	public void getHealthReport(HealthCheckDTO healthDTO) {
		healthDTO.setDbStatus(Constant.BAD_DB_STATUS);
		ILangWL langWL = sessionService.getLang("01");
		if(langWL.getErrorCode() == ErrorCode.NO_ERROR) {
			if(langWL.getLang() != null) {
				healthDTO.setDbStatus(Constant.GOOD_DB_STATUS);
			}
		}
		Health health = examSeedData.getHealthReport();
		healthDTO.setCacheStatus(health.getCacheStatus());
	}
}
