package gov.ca.dmv.AKT.business.BusDelegates;

import java.util.List;

import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.presentation.Beans.ExamHistory;
import gov.ca.dmv.AKT.presentation.Controller.FOUserController;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.DTO.ReportDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.WorkstationMapDTO;

/**
 * @author MWRZA
 * FOBusDelegate handles all the requests concerning field office features.
 */
public interface FOBusDelegate extends BaseBusDelegate {
	/**
	 * Check to see if the Applicant is Manually Assigned Before by applicant id.
	 * @param applicantId
	 * @return
	 */
	public boolean isApplicantManuallyAssignedByAppId(int applicantId);
	/**
	 * Check to see if the Applicant is Manually Assigned Before by exam id.
	 * @param examId
	 * @return
	 */
	public boolean isApplicantManuallyAssignedByExamId(int examId);
	/**
	 * @param wmDTO contains the office id.
	 * This method is called to get all the workstations by office id.
	 */
	public void getTerminalStatusByOfficeId(WorkstationMapDTO wmDTO);
	/**
	 * This method is called to get all the workstations by ip address;
	 * @param wmDTO
	 */
	public void getTerminalStatusByIP(WorkstationMapDTO wmDTO);
	/**
	 * Publish Update Workstation Map Request
	 * @param workstationMap
	 */
	public void publishUpdateWorkstationMapRequest(WorkstationMap workstationMap);
	/**
	 * This method is called to transfer the terminal to another office
	 * @param wmDTO
	 */
	public void transferTerminal(WorkstationMapDTO wmDTO);
	/**
	 * This method is called to get all the office IDs;
	 * @param wmDTO
	 */
	public void getAllOffices(WorkstationMapDTO wmDTO);
	/**
	 * 
	 * @param applicantDTO contains the office id.
	 * This method is called to get the test queue data (list of applicants ready to take a test).
	 */
	public void getTestQueueData(ApplicantDTO applicantDTO);
	/**
	 * 
	 * @param applicantDTO contains the application id.
	 * This method is called to assign a terminal to the applicant by setting the status code in the application record.
	 */
	public void assignTerminal(ApplicantDTO applicantDTO);
	/**
	 * 
	 * @param workstationid contains the workstation ip.
	 * @param group
	 * This method is verify that the workstation belongs to the correct office.
	 */
	public boolean isGroupValid(String officeId, String group);
	/**
	 * 
	 * @param appDTO contains the search class within it that in turn contains the search parameters.
	 * This method is called to search by DL# or Last name based on the request type.
	 */
	public void search(ApplicantDTO appDTO);
	/**
	 * 
	 * @param appDTO contains the search class within it that in turn contains the search parameters.
	 * This method is called to get status of all exams.
	 */
	public void   getAllExams(ApplicantDTO appDTO);
	/**
	 * 
	 * @param appDTO contains the office id.
	 * This method is called to get the print test queue.
	 */
	public void getPrintTestQueue(ApplicantDTO appDTO);
	/**
	 * 
	 * @param examDTO contains the DL #.
	 * This method is called to get the list of tests available for print based on the DL #.
	 */
	public void getAvailableTestsForPrint(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO contains the DL #.
	 * @param appType application type.
	 * This method is called to get the list of finished tests available for print based on the DL #.
	 */
	public void getFinishedTestsForPrint(ExamDTO examDTO, String appType);
	/**
	 * 
	 * @param examDTO contains the exam id.
	 * This method is called to get the answer key based on the exam id.
	 */
	public void getAnswerKey(ExamDTO examDTO);
	/**
	 * 
	 * @param testDTO contains the group.
	 * This method is called to get all the tests needed (based on the group) for displaying the enter applicant information page.
	 */
	public void getAppInfo(TestDTO testDTO);
	/**
	 * 
	 * @param appDTO (Contains the DS/OL applicant's information).
	 * This method is called to persist the DS/OL applicant's information in the vault, application, exam and exam history tables.
	 * @param examHistList 
	 */
	public void submitAppInfo(ApplicantDTO appDTO, List<ExamHistory> examHistList);
	/**
	 * 
	 * @param examDTO (Contains exam id).
	 * This method is called to change the status of completion reason code field for the exam being printed.
	 */
	public void changeCompletionReasonCode(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO contains the DL #.
	 * This method is called to get the list of tests available for updating the score based on the DL #.
	 */
	public void getTestsToUpdateScore(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains the score and exam id).
	 * This method is called to update the scores of the manually printed tests.
	 */
	public void updateScore(ExamDTO examDTO, String group, FOUserController foUserController);
	/**
	 * 
	 * @param repDTO (Contains the from date and to date, officeId).
	 * This method is called to generate field office volume report based on the selected date range and office id. 
	 */
	public void getVolumeReport(ReportDTO repDTO);
	/**
	 * 
	 * @param repDTO (Contains the from date and to date, officeId and group).
	 * This method is called to generate historical report based on the selected date range, office id and group.
	 */
	public void getHistoricalReport(ReportDTO repDTO);
	/**
	 * 
	 * @param examDTO (Contains test id, lang id and user id).
	 * This method is called to audit the printed test that was generated through the 'Generate Test' feature.
	 */
	public void auditTestGenerated(ExamDTO examDTO);
}
