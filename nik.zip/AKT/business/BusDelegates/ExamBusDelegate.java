package gov.ca.dmv.AKT.business.BusDelegates;

import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.presentation.DTO.AnswerDTO;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.ExamDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesPassRateDTO;
import gov.ca.dmv.AKT.presentation.DTO.ReportDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
/**
 * 
 * @author MWRZA
 * ExamBusDelegate is responsible for handling all requests related to exam, pause restart event, and quick pass fail.
 */
public interface ExamBusDelegate extends BaseBusDelegate {
	/**
	 * 
	 * @param examDTO (Contains the exam id).
	 * @param forPrint
	 * This method is called to generate the exam based on the exam id.
	 */
	public void   generateExam(ExamDTO examDTO, boolean forPrint);
	public void   getExams(ExamDTO examDTO);
	public void   showQuestion(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains the exam id and session id).
	 * This method is called to fail a timed out exam.
	 */
	public void   failExam(ExamDTO examDTO);
	public void   gradeAnswer(AnswerDTO answerDTO);
	/**
	 * 
	 * @param examDTO (Contains examId).
	 * This method is called to grade the exam.
	 */
	public void   gradeExam(ExamDTO examDTO);
	public void   failIncompleteExams(ExamDTO examDTO);
	public void   resumeExam(ExamDTO examDTO);
	public void   forceFailExam(ExamDTO examDTO);
	/**
	 * 
	 * @param testDTO.
	 * This method is called to get the list of test that can be printed by F.O. Technician.
	 */
	public void   getTestList(TestDTO testDTO);
	public void   getEligibleQPFTestList(TestDTO testDTO);
	public void   getEndExamMsg(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains exam id and session id).
	 * This method is called to fail a quit exam and end the session.
	 */
	public void   quitExam(ExamDTO examDTO);
	public void   generatePrintExam(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains vault id, session id, application id and exam id).
	 * This method is called from FO module to pause an exam.
	 */
	public void   pauseExamFO(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains vault id, session id, application id and exam id).
	 * This method is called to pause an exam.
	 */
	public void   pauseExam(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains the exam id and tech id).
	 * This method is called to unpause an exam by the technician (change the completion reason code in the exam record).
	 */
	public void   unpauseExam(ExamDTO examDTO);
	public void   submitQPFChoices(TestDTO testDTO);
	/**
	 * 
	 * @param examDTO (Contains the exam id).
	 * This method is called to resume a disconnected exam.
	 */
	public void   resumeExam2(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains the exam id).
	 * This method is called to resumed a timed out exam based on the exam id.
	 */
	public void   resumeTimedOutExam(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (contains exam id).
	 * This method is called to generate the questions answered incorrectly by an applicant.
	 */
	public void   generateMissedQuestions(ExamDTO examDTO);
	/**
	 * Get Missed Questions and Answers From Session Data.
	 * @param examDTO
	 */
	public void   getMissedQuestionsFromSessionData(ExamDTO examDTO);
	public void   updateExamWithEaseTstamp(ExamDTO examDTO2);
	public void   getIncompleteExams(ApplicantDTO applicantDTO);
	/**
	 * 
	 * @param examDTO (Contains exam id and user id).
	 * This method is called to resume quit exam.
	 */
	public void   resumeQuitExam(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains exam id and user id).
	 * This method is called to mark an active session as terminated.
	 */	
	public void terminateActiveSession(ExamDTO examDTO);
	/**
	 * 
	 * @param examDTO (Contains office id and app type).
	 * This method is called to mark all active sessions as terminated.
	 */	
	public void terminateAllActiveSession(ApplicantDTO applicantDTO); 
	//public void   getQuesPassRate(QuesPassRateDTO quesDTO);
	
	/**
	 * This method is called to return a list of records for question pass/fail rate report.
	 * @return
	 */
	public void getQuesPassRateList(QuesPassRateDTO quesDTO);
	/**
	 * 
	 * @param appDTO (Contains the office Id).
	 * This method is called to generate reports for records that did not get updated at the EASE end.
	 */
	public void   generateExceptionRep(ApplicantDTO appDTO);
	public void   updateExceptionRep(ApplicantDTO appDTO);
	public void   generateFinishedTests(ExamDTO examDTO);
	public void   getEndOfDayReport(ReportDTO reportDTO);
	/**
	 * Get Applicant Audio Video Indicator From Session Data
	 */
	public String getApplicantAudioVideoInd();
	
	/**
	 * This method is called to skip the current question.
	 * @param examDTO
	 */
	public void skipQuestion(ExamDTO examDTO);
	
	/**
	 * 
	 * @param examDTO
	 * This method is called to send a force fail request (add/delete) using JMS
	 */
	public void publishForceFailRequest(ExamDTO examDTO);
	/**
	 * 
	 * This method is called to find the number of  skipped questions
	 */
	public int getSkippedQuestionsCount();
	/**
	 * 
	 * @param String
	 * This method is called to find the timeout value for the screen
	 */
	public Integer getScreenTimeout(String screen);
	
	/**
	 * 
	 * @param Integer
	 * This method is called to find the Exam Taken Count value
	 */
	public boolean getExamTakenCount(Integer examId);
	
	public IExam getExamById(int examId);
}
