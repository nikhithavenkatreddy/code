package gov.ca.dmv.AKT.business.BusDelegates;

import gov.ca.dmv.AKT.integration.BeansImpl.Office;
import gov.ca.dmv.AKT.presentation.DTO.ApplicantDTO;
import gov.ca.dmv.AKT.presentation.DTO.FailedYOBDTO;
import gov.ca.dmv.AKT.presentation.DTO.HealthCheckDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.SessionDTO;
import gov.ca.dmv.AKT.presentation.DTO.YOBDTO;

public interface SessionBusDelegate extends BaseBusDelegate {
	
	/**
	 * Get Office By Terminal IP address.
	 * @param terminalIP
	 * @return
	 */
	public Office getOfficeByTerminalIP(String terminalIP);
	/**
	 * 
	 * @param langDTO.
	 * This method is called to get a list of languages.
	 */
	public void getLangList(LangDTO langDTO);
	/**
	 * 
	 * @param yobDTO (Contains the d.o.b and the first 3 characters of applicant's first name).
	 * This method is called to (secondary) validate the applicant's d.o.b and first name.
	 */
	public void validateYOB(YOBDTO yobDTO);
	public void createSession(SessionDTO sessionDTO);
	public void getFailedYOBList(FailedYOBDTO failedYOBDTO, String appType);
	public void overrideYOBValidation(SessionDTO sessionDTO);
	/**
	 * Get Failed To AuthApplicant List.
	 * @param appDTO
	 */
	public void getFailedToAuthApplicantList(ApplicantDTO appDTO);
	/**
	 * 
	 * @param activeSessionDTO (Contains the office id and app type).
	 * This method is called to get a list of tests in progress based on office id and app type.
	 */
	public void getActiveExams(ApplicantDTO activeSessionDTO);
	public void terminateSession(SessionDTO sessionDTO);
	public void endSession(SessionDTO sessionDTO);
	/**
	 * 
	 * @param String
	 * This method is called to find the timeout value for the screen
	 */
	public Integer getScreenTimeout(String screen);
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * This method is called for checking if the cache was loaded with seed data correctly and if there's a valid db connection.
	 * This information will be used for sending a nagios alert in case loading cache or connecting to the db failed.
	 */
	public void getHealthReport(HealthCheckDTO healthDTO);
}
