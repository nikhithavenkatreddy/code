package gov.ca.dmv.AKT.business.BusDelegates;

import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import javax.servlet.http.HttpSession;

public interface BaseBusDelegate {

	/**
	 * Save Audit Record
	 * @param tableName represents the table for which we are maintaining the historical data.
	 * @param fieldName represents the column in the table for which we are maintaining the historical data.
	 * @param oldValue represents the old value in the column we are maintaining the history for.
	 * @param newValue represents the new value in the column we are maintaining the history for.
	 * @param key represents the value in a column that uniquely identifies the record for maintaining the historical data.
	 * @param techId represents the technician id who is responsible for changing the values.
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 */
	IErrorWL saveAudit(String tableName, String fieldName, String oldValue, String newValue, String key, String techId);
	
	/**
	 * Load DMV Staff To Session Data
	 * @param dmvStaff
	 */
	IDMVStaff getDMVStaff(HttpSession session);
	
	/**
	 * Get user id of the DMV staff.
	 * @return
	 */
	String getUserId();
}
