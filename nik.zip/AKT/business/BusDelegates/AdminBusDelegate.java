package gov.ca.dmv.AKT.business.BusDelegates;

import gov.ca.dmv.AKT.presentation.Beans.TestPlan;
import gov.ca.dmv.AKT.presentation.DTO.CategoryDTO;
import gov.ca.dmv.AKT.presentation.DTO.CategoryQuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.HandbookRefDTO;
import gov.ca.dmv.AKT.presentation.DTO.LangDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuesAnswDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionIdDTO;
import gov.ca.dmv.AKT.presentation.DTO.QuestionLangDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestPlanDTO;
import gov.ca.dmv.AKT.presentation.DTO.TestQuestionDTO;
import gov.ca.dmv.AKT.presentation.DTO.TimeLimitDTO;

import java.util.List;

public interface AdminBusDelegate extends BaseBusDelegate {

	/**
	 * 
	 * @param categoryDTO
	 * This method is called to get the list of all categories.
	 */
	public void          getCategoryList(CategoryDTO categoryDTO);
	/**
	 * 
	 * @param handbookRefDTO
	 * This method is called to get a list of all handbook references.
	 */
	public void          getHandbookRefList(HandbookRefDTO handbookRefDTO);
	/**
	 * 
	 * @param testDTO
	 * This method is called to get a list of all tests.
	 */
	public void          getTestList(TestDTO testDTO);
	/**
	 * 
	 * @param quesAnswDTO (Contains the question gen id).
	 * This method is called to get the language specific question and answers based on the question gen id.
	 */
	public void          getQuesAnsw(QuesAnswDTO quesAnswDTO);
	/**
	 * 
	 * @param quesAnswDTO (Contains the question gen id).
	 * This method is called to present the modify question page with question and its answers that are to be modified.
	 */
	public void          getQuesAnswByAutoGenId(QuesAnswDTO quesAnswDTO);
	/**
	 * 
	 * @param quesAnswDTO (Contains language specific question and its answers).
	 * This method is called to save the newly created language specific question and answers.
	 */
	public void          saveQuestion(QuesAnswDTO quesAnswDTO);
	/**
	 * 
	 * @param quesAnswDTO (Contains language specific question and its answers).
	 * This method is called to update the question lang and its answer records that were modified through the modify lang.
	 * specific question screen.
	 */
	public void          updateQuestion(QuesAnswDTO quesAnswDTO);
	/**
	 * 
	 * @param langDTO
	 * This method is called to get a list of all languages.
	 */
	public void          getLangList(LangDTO langDTO);
	public void          findQuestions(QuestionLangDTO questionLangDTO);
	public void          findQuestions(CategoryQuestionLangDTO categoryQuesDTO);
	public void          findQuestions(TestQuestionDTO tcqlDTO);
	/**
	 * 
	 * @param questionDTO (Contains the new parent question, category and test).
	 * This method is called to persist the newly created parent question and its associated categories and tests.
	 */
	public void          saveParentQuestion(QuestionDTO questionDTO);
	/**
	 * 
	 * @param questionDTO (Contains the parent question id).
	 * This method is called to get the parent question by question id.
	 */
	public void          getParentQuestion(QuestionDTO questionDTO);
	/**
	 * 
	 * @param questionDTO (Contains the question id and its associated category id and test id).
	 * This method is called to update the modified parent question and its associated category and test.
	 */
	public void          updateParentQuestion(QuestionDTO questionDTO);
	/**
	 * 
	 * @param questionIdDTO
	 * This method is called to get the list of all active parent question ids.
	 */
	public void          getAllQuestionId(QuestionIdDTO questionIdDTO);
	public void          findQuestions2(TestQuestionDTO tqlDTO);
	public void          getTest(TestPlanDTO testPlanDTO);
	/**
	 * 
	 * @param timeLimitDTO
	 * This method is called to get the list of all the time limits.
	 */
	public void 		 getTimeLimitList(TimeLimitDTO timeLimitDTO);
	/**
	 * 
	 * @param timeLimitDTO
	 * This method is called to updates the time limits.
	 */
	public void 		 updateTimeLimits(TimeLimitDTO timeLimitDTO);
	public void 		 updateTest(TestPlanDTO testPlanDTO);
	public void          updateTestPlanByTestId(TestPlanDTO testPlanDTO);
	/**
	 * Get Test Plan List.
	 * @param testPlanDTO
	 */
	public void getTestPlanList(TestPlanDTO testPlanDTO);
	/**
	 * @param testPlanDTO
	 * This method is called to get test plan list such that there is one entry for each category.
	 */
	public void getAllCategoriesTestPlanList(TestPlanDTO testPlanDTO);
	/**
	 * @param testPlanDTO
	 * @param sessionTestPlanList
	 * This method is called to fill test plan list with categories that were not the part of received request
	 */
	public void fillTestPlanList(TestPlanDTO testPlanDTO, List<TestPlan> sessionTestPlanList);
	/**
	 * @param testPlanDTO
	 * This method loads a Test Type
	 */	
	public void loadTestType(TestPlanDTO testPlanDTO);
	/**
	 * @param testPlanDTO
	 * This method updates a Test Type
	 */		
	public void updateTestType(TestPlanDTO testPlanDTO);
	/**
	 * @param testPlanDTO
	 * This method saves a new Test Type
	 */	
	public void saveTestType(TestPlanDTO testPlanDTO);
	/**
	 * @param testPlanDTO
	 * This method searches for a test by name and id
	 */	
	public void searchTestType(TestDTO testDTO);
	/**
	 * 
	 * @param quesLangDTO
	 * This method is called to get the language specific questions and answers that are pending on review.
	 */
	public void          getPendingReviewQuesAns(QuestionLangDTO quesLangDTO);
	/**
	 * 
	 * @param quesLangDTO (Contains the question gen id and the decision if the question was approved or denied).
	 * This method is called to approve or deny a question and answers that were reviewed. 
	 */
	public void          approveDenyQuestion(QuestionLangDTO quesLangDTO);
	
	
	/**
	 * @param category
	 * This method saves a new Category Type
	 */	
	public void saveCategoryType(CategoryDTO categoryDTO);
	
	/**
	 * @param category
	 * * @return CategoryDTO
	 * This method load a  Category Type for view
	 */	
	
	public CategoryDTO loadCategory(CategoryDTO categoryDTO);

	/**
	 * @param category
	 * This method updates a  Category Type 
	 */	
    public CategoryDTO updateCategory(CategoryDTO categoryDTO);
    
    /**
     * @param category
     * This method search a  Category Type by id or/and name
     */	
    public CategoryDTO  searchCategory(CategoryDTO categoryDTO);
    
    /**
     * 
     * @param hanbookDTO
     * @return
     * This method saves a new Handbook Section
     */
    public HandbookRefDTO saveHanbookSection(HandbookRefDTO handbookDTO);

 /**
  * 
  * @param handbookDTO
  * @return
  * This method load a  HandbookSection Type for view
  */
    public HandbookRefDTO loadHandbok(HandbookRefDTO handbookDTO);
    
    /**
     * 
     * @param handbookDTO
     * this method is used to update a HandbookSection
     * @return
     */   
    public void updateHanbookSection(HandbookRefDTO handbookDTO);
    
    /**
     * 
     * @param handbookRefDTO
     * This method is used to search a handbook section by id or/and language
     * @return
     */
    public HandbookRefDTO  searchHandbookRefList(HandbookRefDTO handbookRefDTO);
}

