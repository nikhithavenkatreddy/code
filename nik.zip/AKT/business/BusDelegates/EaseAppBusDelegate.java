package gov.ca.dmv.AKT.business.BusDelegates;

import gov.ca.dmv.AKT.presentation.DTO.EaseAppDTO;

public interface EaseAppBusDelegate {
	
	public void createApp(EaseAppDTO easeAppDTO);
	public void sendResult(EaseAppDTO easeAppDTO);
	public void saveReceivedString(EaseAppDTO easeAppDTO);
	public void updateEaseReceivedIndicator(EaseAppDTO easeAppDTO);
}
