package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuesAnswWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionCategoryTestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IQuestionLangListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestLangWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestPlanListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITimeLimitListWL;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.QPFList;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionCategoryTestList;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestCategory2;
import gov.ca.dmv.AKT.integration.BeansImpl.TestPlan;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.TimeLimit;

import java.util.List;

public interface TestService extends BaseService {
	/**
	 * Find Question By Partial Text.
	 * @param partialText
	 * @return
	 */
	public IQuestionLangListWL   findQuestByPartialText(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ql);
	public ICategoryListWL       getCategoriesList();
	/**
	 * Get Test Plan List By Test Id.
	 * @param testId
	 * @return
	 */
	public ITestPlanListWL 		 getTestPlanListByTestId(String testId);
	/**
	 * 
	 * @return ITestListWL (Contains a list of tests and error code in case of exceptions in the process).
	 * This method is called to get a list of all tests.
	 */
	public ITestListWL           getTestsList();
	/**
	 * @param test (Contains test Id and Name)	 
	 * @return ITestListWL (Contains a list of tests and error code in case of exceptions in the process).
	 * This method is called to get the list of all tests by Id and Name
	 */
	public ITestListWL getTestListByIdAndName(Test test);
	/**
	 * 
	 * @param quesAnsw
	 * @return
	 * This method is called to save language specific question and the answers.
	 */
	public IErrorWL              saveQuestion(gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw quesAnsw);
	/**
	 * 
	 * @param quesAnsw.
	 * @return
	 * This method is called to update the modified language specific question and its answers records.
	 */
	public IIntegerWL            updateQuestion(gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw quesAnsw);
	/**
	 * 
	 * @param autoGenId
	 * @return IQuesAnswWL (Contains language specific question, answers and error code in case of exceptions in the process).
	 * This method is called to get language specific question and answers based on question gen id.
	 */
	public IQuesAnswWL           getQuesAnswByAutoGenId(Integer autoGenId);
	//public void                 saveAnswer(List<Answer> answerList);
	public IQuestionLangListWL   findQuest(gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang ql);
	public IQuestionLangListWL   getQuestionList(gov.ca.dmv.AKT.integration.BeansImpl.Category cat);
	public IQuestionLangListWL   getQuestionList(gov.ca.dmv.AKT.integration.BeansImpl.Test test);
	/**
	 * 
	 * @param questionCategoryList (Contains the parent question, its associated category and test).
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to save the newly created parent question with its associated category and test.
	 */
	public IErrorWL              saveParentQuestion(QuestionCategoryTestList questionCategoryList);
	/**
	 * 
	 * @param question.
	 * @return IQuestionCategoryTestListWL (Contains the parent question and its associated category and test).
	 * This method is called get the parent question, its associated category and test by question id.
	 */
	public IQuestionCategoryTestListWL getParentQuestion(gov.ca.dmv.AKT.integration.BeansImpl.Question question);
	/**
	 * 
	 * @param questionCategoryList (Contains the parent question and its associated category and test).
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update the modified parent question and its associated category and test.
	 */
	public IErrorWL               updateParentQuestion(QuestionCategoryTestList questionCategoryList);
	public ITestLangWL            getTestLang(gov.ca.dmv.AKT.integration.BeansImpl.TestLang testLang);
	/**
	 * 
	 * @return IStringListWL (Contains a list of string objects and error code in case of exceptions in the process).
	 * This method is called to get a list of active parent question ids.
	 */
	public ITestListWL 			  getEligibleQPFTestList();
	//public QuesAnswWL            getQuestText(QuesAnswId quesAnswId);
	public IStringListWL          getAllQuestionIds();
	public IQuestionLangListWL    getQuestionList(TestCategory2 testCategory);
	public ITestWL                getTest(String testId);
	public IErrorWL               updateQPFList(List<QPFList> qpfList);
	public IErrorWL               updateQPFTestList(List<gov.ca.dmv.AKT.integration.BeansImpl.Test> testList);
	public IQuesAnswWL            generateMissedQuestions(List<IExamAnswer> examAnsList);
	public IErrorWL               updateTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test);
	/**
	 * @param test
	 * @return IErrorWL (Contains error code in case of exceptions in the process).	  
	 * This method is called to update test while modifying test type 
	 */
	public IErrorWL updateTestTypeTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test);
	public IErrorWL updateTestLangList(List<TestLang> testLangList);
	public IErrorWL               updateTestPlanList(String testId, List<TestPlan> testPlanList);
	/**
	 * @param test
	 * @return IErrorWL (Contains error code in case of exceptions in the process).	  
	 * This method is called to create test 
	 */
	public IErrorWL saveTest(gov.ca.dmv.AKT.integration.BeansImpl.Test test);
	/**
	 * @param testPlanList
	 * @return IErrorWL (Contains error code in case of exceptions in the process).	 
	 * This method is called to modify a testPlan 
	 */
	public IErrorWL modifyTestPlanList(List<TestPlan> testPlanList);
	/**
	 * @param testPlanList
	 * @return IErrorWL (Contains error code in case of exceptions in the process).	 
	 * This method is called to save a testPlanList 
	 */
	public IErrorWL saveTestPlanList(List<TestPlan> testPlanList);
	/**
	 * @param testLangList
	 * @return IErrorWL (Contains error code in case of exceptions in the process).	 
	 * This method is called to save a testLangList 
	 */
	public IErrorWL saveTestLangList(List<TestLang> testLangList);
	/**
	 * 
	 * @return IQuestionLangListWL (Contains a list of lang specific questions and error code in case of exceptions in the process).
	 * This method is called to get a list of language specific questions that are awaiting review and inactivate the questions that
	 * have not been reviewed in 60 days.
	 */
	public IQuestionLangListWL    getPendingReviewQues();
	/**
	 * 
	 * @param questionLangId.
	 * @return IQuesAnswWL (Contains question lang, answers and error code in case of exceptions in the process).
	 * This method is called to get active question lang, answers by question lang id. 
	 */
	public IQuesAnswWL getActiveQuesAnswByQuesLangId(String questionLangId);
	/**
	 * 
	 * @param ql
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update the language specific question record.
	 */
	public IErrorWL    updateQuesLang(QuestionLang ql);
	/**
	 * 
	 * @param oldAnsList
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update a list of answers.
	 */
	public IErrorWL    updateAnsList(List<Answer> oldAnsList);
	/**
	 * 
	 * @param timeLimitList
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update a list of time limits.
	 */
	public IErrorWL updateTimeLimitList(List<TimeLimit> timeLimitList);
	/**
	 * 
	 * @return ITimeLimitListWL (Contains a list of time limits).
	 * This method is called to get a list time limits
	 */
	public ITimeLimitListWL getTimeLimitList();
}
