package gov.ca.dmv.AKT.business.Services;

import java.util.List;

import gov.ca.dmv.AKT.integration.Beans.IEaseInboundMessage;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;
import gov.ca.dmv.AKT.business.WorkloadInterface.IActiveSessionAndExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IEaseInboundMessageWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IIntegerWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ILangListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ILangWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ISessionWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IStringWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;

/**
 * 
 * @author MWRZA
 * SessionService handles all requests concerning session, workstation map, language and ease inbound message.
 * 
 */

public interface SessionService extends BaseService {
    public ILangWL                     getLang(String langIdCode);
    /**
     * 
     * @param applicationId.
     * @param ipAddress.
     * @param langCode.
     * @param resume.
     * @return ISessionBooleanWL (Contains session, boolean value and error code in case of exception in the process).
     * This method is called to check if a new session is allowed to be created only if there are no 
	 * existing active sessions or if the terminal is not reserved for another applicant. If the terminal is reserved,
	 * it checks if an old test is to be resumed. If yes, the session used to reserve the terminal is left untouched, but,
	 * if this is a new test, then the session used to reserve the terminal is made active and will be used for test taking.
     */
	public ISessionBooleanWL           isNewSessionPermitted(Integer applicationId, String ipAddress, String langCode, boolean resume, Boolean additionalTest);
	/**
	 * 
	 * @param session3 (The session record that needs to be inserted).
	 * @return ISessionWL (Contains the session record that was saved and error code in case of exceptions in the process).
	 * This method is called to insert the session record and return it after insertion.
	 */
	public ISessionWL                  createSession(ISession session3);
	/**
	 * 
	 * @param sessionId.
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to end the session marking session end time.
	 */
	public IErrorWL                    endSession(Integer sessionId);
	public ISessionListWL              getFailedYOB(String officeId);
	public IErrorWL                    overrideYOBValidation(Integer sessionId);
	public IActiveSessionAndExamListWL getActiveExams(String officeId, String appType);
	public IErrorWL                    reset(Integer sessionId, String sessionStatus);
	public IErrorWL resetTerminal(Integer sessionId, String workstationIPAddress);
	/**
	 * 
	 * @param sessionId.
	 * @return ISessionWL (Contains the session record and error code in case of exception in the process).
	 * This method is called to get session by session id.
	 */
	public ISessionWL                  getSessionBySessionId(Integer sessionId);
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return ISessionListWL (Contains a list of sessions and error code in case of exception in the process).
	 * This method is called to get a list of all sessions based on the office id and app type.
	 */	
	public ISessionListWL getAllSessionsByOfficeId(String officeId, String appType);
	public IErrorWL                    endSessionWithYOBValidationFail(Integer sessionId);
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return IActiveSessionAndExamListWL (Contains the session record and list of exam records).
	 * This method is called to get a list of exams that were incomplete due to power failure or system error.
	 */
	public IActiveSessionAndExamListWL getExams(String officeId, String appType);
	public ISessionListWL getCurrentSessions(String officeId);
	/**
	 * 
	 * @param workstationIPAddress.
	 * @return IStringWL (Contains the workstation id and error code in case of exceptions in the process).
	 * This method is called to get workstation id by workstation IP address.
	 */
	public IStringWL                   getWorkstationId(String workstationIPAddress);
	public IStringWL                   getThresholdValue(String threshold);
	public IIntegerWL                  saveEaseReceivedString(String receivedStr);
	public IEaseInboundMessageWL       getEaseInboundMessage(Integer easeMsgId);
	public IErrorWL                    saveEaseInboundMessage(IEaseInboundMessage message);
	/**
	 * 
	 * @param officeId.
	 * @return IWorkstationMapListWL (List of workstation records).
	 * This method is called to get all workstations by office id.
	 */
	public IWorkstationMapListWL       getAllWorkstationsByOfficeId(String officeId);
	/**
	 * 
	 * @param wmList (List of workstation map records that needs to be updated).
	 * @return IErrorWL (Contains the error code in case of any exceptions in the process).
	 * This method is called to persist the updated workstation records.
	 */
	public IErrorWL                    updateWorkstations(List<WorkstationMap> wmList);

	/**
	 * 
	 * @param ipAddress.
	 * @param officeId.
	 * @return IBooleanWL (Contains the boolean value indicating whether the terminal is used by a session or not).
	 * This method is called to check whether the terminal based on the ip address is used by a session or not.
	 */	
	public IBooleanWL isTerminalUsedInSession(String ipAddress, String officeId);
	/**
	 * 
	 * @param workstationId.
	 * @param officeId.
	 * @return IWorkstationMapListWL (Contains a list of workstation map records and error code in cases of an exception in the process).
	 * This method returns a list of workstation map records based on workstation id and office id.
	 */
	public IWorkstationMapListWL getWorkstationMapByStationIdAndOfficeId(String workstationId, String  officeId);
	
	/**
	 * Get Workstation By IP address.
	 * @param ipAddr
	 * @return
	 */
	public IWorkstationMapListWL getWorkstationByIP(String ipAddr);
}
