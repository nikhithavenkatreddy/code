package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IWorkstationMapListWL;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;
import gov.ca.dmv.AKT.integration.BeansImpl.Health;
import gov.ca.dmv.AKT.integration.BeansImpl.Lang;
import gov.ca.dmv.AKT.integration.BeansImpl.Office;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLangQuickPF;
import gov.ca.dmv.AKT.integration.BeansImpl.Test;
import gov.ca.dmv.AKT.integration.BeansImpl.TestLang;
import gov.ca.dmv.AKT.integration.BeansImpl.WorkstationMap;

import java.util.List;
/**
 * 
 * @author MWRZA
 *
 * ExamSeedData is responsible for holding all seed data.
 * 
 * getTestByTestId(String testId): This method is called to get test by test id.
 * getTestLangByTestIdLangId(TestLang tl): This method is called to get test lang record by test id and lang id.
 * generateTest(TestLang testLang): This method is called to generate test based on the test id and lang id.
 * getAnswersByQuesGenId(Integer quesGenId): This method is called to get the corresponding answers based on the question gen id.
 */
public interface ExamSeedData {

	public void init();
	public String getThresholdValue(String thresholdName);
	public WorkstationMap getWorkstationMapByIPAddress(String ipAddress);
	
	/**
	 * Update Workstation Map By Ip Address.
	 * @param ipAddr
	 * @param officeId
	 * @param locatingOfficeId
	 */
	public void updateWorkstationMapByIpAddr(String ipAddr, String officeId, String locatingOfficeId);
	/**
	 * Get Office By Terminal IP address.
	 * @param terminalIP
	 * @return
	 */
	public Office getOfficeByTerminalIP(String terminalIP);
	/**
	 * 
	 * @param ipAddress.
	 * @return String.
	 * This method is called to get the office type by ipAddress.
	 */	
	public String getOfficeTypeByIPAddress(String ipAddress);
	
	/**
	 * Get Office Type By Office Id.
	 * @param officeId
	 * @return
	 */
	public String getOfficeTypeByOfficeId(String officeId);
	
	/**
	 * 
	 * @return List<String>
	 * This method is called to get all the office IDs.
	 */	
	public List<String> getAllOfficeIDs();
	/**
	 * @param officeId
	 * @return List<String>
	 * This method is called to get all the office IDs.
	 */	
	public List<String> getAllOfficeIDsInSameBuilding(String officeId);
	/**
	 * 
	 * @param officeId.
	 * @return String.
	 * This method is called to get the office type by officeId.
	 */	
	public String getAppTypeBasedOnOfficeId(String officeId);
	/**
	 * 
	 * @param testId.
	 * @return Test.
	 * This method is called to get the test record by test id.
	 */
	public Test getTestByTestId(String testId);
	/**
	 * 
	 * @param quesGenId.
	 * @return List<Answer>.
	 * This method is called to return answer records based on the question gen id.
	 */
	public List<Answer> getAnswersByQuesGenId(Integer quesGenId);
	/**
	 * 
	 * @param langId.
	 * @return Lang.
	 * This method is called to get the lang record by lang id.
	 */
	public Lang getLangByLangId(String langId);
	/**
	 * 
	 * @param timeLimitName.
	 * @return timeLimit.
	 * This method is called to get the timeLimitValue based on timeLimitName.
	 */	
	public Integer getTimeLimitByName(String timeLimitName);
	/**
	 * 
	 * @param tl (Contains test id and lang id).
	 * @return TestLang.
	 * This method is called to return the test lang record by test id and lang id.
	 */
	public TestLang getTestLangByTestIdLangId(TestLang tl);
	/**
	 * 
	 * @param testLang (Contains the test id and lang id).
	 * @param audioVideoTestCode (used to get the right pool of questions) 
	 * @return QuestionLangQuickPF (Contains question lang list and quick pass fail indicator).
	 * This method is called to generate the test based on the test id and language.
	 */
	public QuestionLangQuickPF generateTest(TestLang testLang,String audioVideoTestCode);
	/**
	 * 
	 * @return List<Lang>.
	 * This method is called to get a list of all languages.
	 */
	public List<Lang> getLangList();
	/**
	 * 
	 * @param quesGenId is the question gen id.
	 * @return QuestionLang.
	 * This method returns the question lang record based on the question gen id.
	 */
	public QuestionLang getQuestionLangByQuesGenId(Integer quesGenId);
	/**
	 * 
	 * @param examAnsList.
	 * @return QuesAnsw (Question and answers along with the handbook section).
	 * This method is called to return the question and answers corresponding to the set of exam answers.
	 */
	public QuesAnsw generateMissedQuestions(List<IExamAnswer> examAnsList);
	/**
	 * 
	 * @param handbookRef.
	 * @param langId.
	 * @return HandbookRef.
	 * This method is called to get the handbook ref record based on the handbook ref id and lang id.
	 */
	public HandbookRef getHandbookRefByHandbookRefAndLangId(String handbookRef, String langId);
	/**
	 * 
	 * @param testId.
	 * @return List<TestLang>.
	 * This method is called to get a list of test lang records based on the test id.
	 */
	public List<TestLang> getTestLangListByTestId(String testId);
	/**
	 * 
	 * @param group the technician belongs to.
	 * @return List<Test>.
	 * This method is called to return a list of tests based on the group of the technician.
	 */
	public List<Test> getTestsBasedOnGroup(String group);
	/**
	 * 
	 * @return List<Test>.
	 * This method is called to return a list of non cdl tests.
	 */
	public List<Test> getNonCDLTests(String group);
	/**
	 * 
	 * @return List<HandbookRef>.
	 * This method is called to get the list of all handbook references.
	 */
	public List<HandbookRef> getHandbookRefList();
	
	public HandbookRef getHandbookRefByHandbookRef(String hb, String langId);
	public IWorkstationMapListWL getWorkstationMapListByOfficeId(String officeId);
	
	/**
	 * @return String
	 * This method is called to get the url of audio file server
	 */
	//public String getAudioFileServerURL();
	// add new signature to interface method to pass office_id -- code to fix media server url
	public String getAudioFileL1ServerURL(String string);
	//public Health getHealthReport();
	
	/**
	 * Get security server URL.
	 * @return
	 */
	public String getSecurityServerURL();
	
	/**
	 * This method is called for checking if the cache was loaded with seed data correctly and if there's a valid db connection.
	 * This information will be used for sending a nagios alert in case loading cache or connecting to the db failed.
	 * @param request
	 * @param response
	 * @return
	 */
	public Health getHealthReport();
}
