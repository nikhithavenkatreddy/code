package gov.ca.dmv.AKT.business.Services;

public interface ForceFailRegistryService extends BaseService {

	public void addForceFailRequest(Integer examId);
	public void removeForceFailRequest(Integer examId);
	public String getForceFailRequest(Integer examId);
	
}
