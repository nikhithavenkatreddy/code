package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.Beans.ISession;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;
import gov.ca.dmv.AKT.integration.BeansImpl.QuesAnsw;
import gov.ca.dmv.AKT.integration.BeansImpl.QuestionLang;
import gov.ca.dmv.AKT.integration.BeansImpl.SubmitAnswer;
import gov.ca.dmv.AKT.security.bean.IDMVStaff;

import java.util.Date;
import java.util.List;

public interface ExamSessionData {

	IDMVStaff getDmvStaff();
	void setDmvStaff(IDMVStaff dmvStaff);

	List<IExamQuestion> getMissedExamQuestionList();
	List<IExamQuestion> getExamQuestionList();
	List<IExamAnswer> getExamAnswerList();
	List<IExamAnswer> getExamAnswerListByQuesGenId(int quesGenId);
	
	int getAnswerCountForProgressBar();
	int getQuestionCountForProgressBar();
	QuesAnsw getQuestionAnswers(Integer examId, Integer quesPresOrder);
	IExamQuestion getExamQuestionAfterGrading(SubmitAnswer submitAnswer);
	IExam getExamByExamId(Integer examId);
	/**
	 * 
	 * @param examId.
	 * @param status (pass/fail).
	 * @param compReasonCode.
	 * @return Exam.
	 * This method is called to grade the exam.
	 */
	IExam getExamAfterGrading(Integer examId, String status, String compReasonCode);
	/**
	 * 
	 * @param examId.
	 * @return Exam.
	 * This method is called to get the exam record from the session data after setting the completion reason code to reflect pause.
	 */
	IExam getExamAfterPause(Integer examId, Date questionPresentedTime);
	IExam getExamAfterTimeout(Integer examId, Date questionPresentedTime);
	IExam getExamAfterQuit(Integer examId);
	IExam getExamAfterForceFail(Integer examId);
	void setDisconnectedExam(Integer examId);
	void setSkippedExamQuestionList(List<IExamQuestion> skippedExamQuestionList);
	/**
	 * 
	 * @return Application.
	 * This method is called to return application that is retained in the session.
	 */
	IApplication getApplication();
	IVault getVault();
	void setQuestionLangList(List<QuestionLang> questionLangList);
	void setAnswerList(List<Answer> answerList);
	void setExamAnswerList(List<IExamAnswer> examAnswerList);
	void setExamQuestionList(List<IExamQuestion> examQuestionList);
	void setExam(IExam exam);
	IExam getExam();
	void setApplication(IApplication application);
	void setVault(IVault vault);
	
	QuesAnsw getQuestionAnswersForMissedQuestion(Integer examId, Integer quesPresOrder);
	IExamQuestion skipQuestion(int examId, int order, Date questionPresentedTime);
	int getSkippedQuestionsCount();
	
	Boolean getAdditionalTestFlag();
	void setAdditionalTestFlag(Boolean additionalTestFlag);
	
	ISession getSession();
	void setSession(ISession session);
	List<QuesAnsw> getQuesAnswList();
    void setQuesAnswList(List<QuesAnsw> quesAnswList);
}
