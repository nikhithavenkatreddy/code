package gov.ca.dmv.AKT.business.Services;


public interface BaseService {

	/**
	 * Get user id of the DMV staff.
	 * @return
	 */
	String getUserId();
}
