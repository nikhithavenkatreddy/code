package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadImpl.ApplicantListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicationWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IVaultWL;
import gov.ca.dmv.AKT.integration.Beans.IApplication;
import gov.ca.dmv.AKT.integration.Beans.IExamHistory;
import gov.ca.dmv.AKT.integration.Beans.IVault;
import gov.ca.dmv.AKT.integration.BeansImpl.Application;
import gov.ca.dmv.AKT.integration.BeansImpl.EaseApplication;
import gov.ca.dmv.AKT.integration.BeansImpl.YOB;

import java.util.Date;
import java.util.List;

/**
 * 
 * @author MWRZA
 * Application service is responsible for handling all services concerning, application, vault, EASE application and exam history.
 * 
 */
public interface ApplicationService extends BaseService {
	/**
	 * 
	 * @param yob (Contains applicants dob and first 3 characters of the first name).
	 * @return IBooleanWL (Contains boolean value and error code in case of exceptions in the process).
	 * This method is called to validate the applicants dob and first name.
	 */
	public IBooleanWL                                   validateYOB(YOB yob);
	public IApplicationWL                               getApplication(gov.ca.dmv.AKT.integration.BeansImpl.DLFO dlfo);
	/**
	 * 
	 * @param examHistory.
	 * @return (Contains boolean value to indicate if there are enough attempts left to retake the failed exam).
	 * This method is called to update the exam history for a failed exam.
	 */
	public IBooleanWL                                   markFailed(IExamHistory examHistory);
	public IErrorWL                                     markFailedBatch(IExamHistory examHistory);
	/**
	 * 
	 * @param vaultId
	 * @return IVaultWL (contains the vault record).
	 * This method is called to get vault based on the vault id.
	 */
	public IVaultWL                                     getVault(Integer vaultId);
	/**
	 * 
	 * @param examHistory.
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update the exam history for a failed exam.
	 */
	public IErrorWL                                     markForceFailed(IExamHistory examHistory);
	/**
	 * 
	 * @param examHistory (Contains application id and ease test id).
	 * @return IExamHistoryWL (Contains exam history record and error code in case of any exception in the process).
	 * This method is called to get exam history by application id and ease test id.
	 */
	public IExamHistoryWL                               getExamHistory(IExamHistory examHistory);
	public ITestWL                                      getTest(String testId);
	public IApplication create(EaseApplication easeApplication);
	/**
	 * 
	 * @param examHistory.
	 * @return IErrorWL (Contains error code in case of exceptions in the process).
	 * This method is called to update the exam history record.
	 */
	public IErrorWL                                     updateExamHistory(IExamHistory examHistory);
	/**
	 * 
	 * @param applicationId.
	 * @return IApplicationWL (Contains Application and error code in case of exceptions in the process).
	 * This method is called to get application by application id.
	 */
	public IApplicationWL                               getApplication(Integer applicationId);
	/**
	 * 
	 * @param applicationId.
	 * @return IErrorWL (Contains error code in case of exception in the process).
	 * This method is called to increment the pause count for the application in the application table.
	 */
	public IErrorWL                                     incrementPauseCount(Integer applicationId);
	/**
	 * 
	 * @param applicationId.
	 * @return IErrorWL (Contains error code in case of exception in the process).
	 * This method is called by FO module to increment the pause count for the application in the application table. Maximum pauses allowed: 1
	 */
	public IErrorWL 									incrementPauseCountFO(Integer applicationId);
	public IErrorWL                                     updateApplication(IApplication app);
	/**
	 * 
	 * @param dl is the DL #.
	 * @return IVaultWL (Contains the vault record).
	 * This method is called to get vault by DL #.
	 */
	public IVaultWL                                     getVaultByDL(String dl);
	/**
	 * 
	 * @param dl is the DL #.
	 * @param lastName is the ApplicantLastName.
	 * @return IVaultWL (Contains the vault record).
	 * This method is called to get vault by DL # or LastName.
	 */
	public IVaultWL                                     getVaultByDLOrLastName(String dl,String lastName);
	/**
	 * 
	 * @param vaultId.
	 * @return IApplicationWL (Contains the application record).
	 * This method is called to get application by vault id.
	 */
	public IApplicationWL                               getApplicationByVaultId(Integer vaultId);
	public IApplicationWL                               getApplicationByVaultIdAndOfficeId(Integer vaultId,String officeId);
	public IExamHistoryListWL                           getExamHistoryByAppId(Integer applicationId);
	/**
	 * 
	 * @param officeId
	 * @param group
	 * @return IApplicationListWL (List of applications and error code in case of exception in the process).
	 * This method is called to retrieve today's applications by office id and group.
	 */
	public IApplicationListWL                           getTodaysApps(String officeId, String group);
	/**
	 * 
	 * @param updatedAppList (Contains a list of applications that needs to be updated).
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to persist all updated application records.
	 */
	public IErrorWL                                     updateApplications(List<Application> updatedAppList);
	/**
	 * 
	 * @param vault.
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to save vault record in the vault table. 
	 */
	public IErrorWL                                     saveVault(IVault vault);
	/**
	 * 
	 * @param application.
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to save application record in the application table.
	 */
	public IErrorWL                                     saveApplication(IApplication application);
	/**
	 * 
	 * @param ehList (Contains a list of exam history records that needs to be inserted into the exam history table).
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to save a list of exam history records in the exam history table.
	 */
	public IErrorWL                                     saveExamHistoryList(List<IExamHistory> ehList);
	/**
	 * 
	 * @param officeId.
	 * @param fromDate.
	 * @param toDate.
	 * @param appType.
	 * @return (List of applications and error code in case of exception in the process).
	 * This method is called to return a list of field office applications (no ds/ol apps) by office id, appType and date range.
	 */
	public IApplicationListWL                           getAppsByOfficeIdAndDateRange(String officeId, Date fromDate, Date toDate, String appType);
	/**
	 * 
	 * @param fromDate.
	 * @param toDate.
	 * @param appType.
	 * @return (List of applications and error code in case of exception in the process).
	 * This method is called to get a list of applicants based on the app type (across the office ids) and search criteria like date range (inclusive), dl number and last name (both partial search strings).	 
	 */
	public ApplicantListWL                           searchApplicantsByAppType(Date fromDate, Date toDate, String appType, String dl, String lastName);
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return IVaultListWL (Contains a list of vaults and error code in case of exception in the process).
	 * This method is called to get a list of all vaults based on the office id and app type.
	 */	
	public IVaultListWL                                 getAllVaultsByOfficeId(String officeId, String appType);
}
