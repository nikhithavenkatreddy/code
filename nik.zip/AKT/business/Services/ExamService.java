package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamHistoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamQuestionListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IExamWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IResultListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.ITestReportsWL;
import gov.ca.dmv.AKT.integration.Beans.IExamAnswer;
import gov.ca.dmv.AKT.integration.Beans.IExamQuestion;
import gov.ca.dmv.AKT.integration.BeansImpl.Answer;
import gov.ca.dmv.AKT.integration.BeansImpl.Dates;
import gov.ca.dmv.AKT.integration.BeansImpl.EaseTest;
import gov.ca.dmv.AKT.integration.BeansImpl.IExam;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author MWRZA
 * ExamService handles all services related to exams.
 * 
 */
public interface ExamService extends BaseService {
	/**
	 * 
	 * @param applicationId.
	 * @return IExamListWL (Contains a list of exams and error code in case of exception in the process).
	 * This method is called to get a list of exams by application id and no end time.
	 */
	public IExamListWL                            loadExams(Integer applicationId);
	/**
	 * 
	 * @param examId
	 * @return IExamWL (Contains the exam record).
	 * This method is called to get exam by exam id.
	 */
	public IExamWL                                getExamByExamId(Integer examId);
	public IExamListWL                            getExamByAppIdAndDifferentSessionId(IExam exam);
	public IErrorWL                               failExam(IExam exam);
	public IErrorWL                               cloneStubExam(IExam exam);
	public IErrorWL                               submitAnswer(IExamQuestion examQuestion);
	public IExamListWL                            getIncompleteExams(String officeId, String appType);
	public IErrorWL                               failExamBatch(Integer examId);
	public IErrorWL                               removeStub(IExam exam);
	/**
	 * 
	 * @param exam.
	 * @return exam.
	 * This method's called to get exam by test id, FO and different exam id.
	 */
	public IExam  getExamByTestIdAndDiffExamId(IExam exam);
	/**
	 * 
	 * @param examId.
	 * @return IExamQuestionListWL (A list of exam question records).
	 * This method's called to get exam questions by exam id.
	 */
	public IExamQuestionListWL                    getExamQues(Integer examId);
	//public ErrorWL                               forceFailExam(Integer examId);
	//public ErrorWL                               updateExamWithEaseTransactionTime(Exam exam);
	public boolean                                createRequiredExams(EaseTest easeTest);
	/**
	 * 
	 * @param exam
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to insert exam record.
	 */
	public IErrorWL                               saveExam(IExam exam);
	/**
	 * 
	 * @param appIds (Contains a list of application ids).
	 * @return IExamListWL (Contains a list of exam records and error code in case of exception in the process).
	 * This method is called to get the list of paused exams for a list of application ids.
	 */
	public IExamListWL                            getPausedExams(List<Integer> appIds);
	/**
	 * This method is called to get the list of exams for a list of application ids.
	 * @param appIds
	 * @return
	 */
	public IExamListWL 							  getAllExams(List<Integer> appIds);
	/**
	 * 
	 * @param applicationId.
	 * @return Exam record.
	 * This method is called to get the stub exam created for taking sign test.
	 */
	public IExamWL                                getSignExam(Integer applicationId);
	/**
	 * 
	 * @param appId.
	 * @return IExamListWL (Contains a list of exams and error code in case of exception in the process).
	 * This method is called to get a list of timed out exams based on the application Id.
	 */
	public IExamListWL                            getTimedOutExams(Integer appId);
	/**
	 * 
	 * @param examId
	 * @return IExamQuestionListWL (Contains a list of exam question records with error codes in cases of an exception).
	 * This method is called to get a list of exam question records based on the exam id that were incorrectly answered by the applicant.
	 */
	public IExamQuestionListWL                    getMissedExamQues(int examId);
	/**
	 * 
	 * @param examQues.
	 * @return List<IExamAnswer>.
	 * This method is called to get a list of exam answer records based on exam id and question gen id in the corresponding exam question record.
	 */
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenId(IExamQuestion examQues);
	/**
	 * 
	 * @param applicationId.
	 * @return IExamListWL (Contains a list of exams and error code in case of exception in the process).
	 * This method is called to get finished exams based on app id.
	 */
	public IExamListWL                            getCompletedExamsByAppId(Integer applicationId);
	public IErrorWL                               failExamQuit(IExam exam);
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return IExamListWL (Contains a list of exams and error code in case of exception in the process).
	 * This method is called to get a list of quit exams based on the office id and app type.
	 */
	public IExamListWL                            getQuitExams(String officeId, String appType);
		
	/**
	 * 
	 * @param officeId.
	 * @param appType.
	 * @return IExamListWL (Contains a list of exams and error code in case of exception in the process).
	 * This method is called to get a list of all exams based on the office id and app type.
	 */	
	public IExamListWL 								getAllExamsByOfficeId(String officeId, String appType);
	//public ITestReportsWL                         getQuesPassRate();
	
	/**
	 * This method is called to return a list of records for question pass/fail rate report.
	 * @return
	 */
	public ITestReportsWL 						  getQuesPassRateList(Date fromDate, Date toDate);
	public IExamListWL                            getOutstandingExams(Dates dates);
	/**
	 * 
	 * @param officeId.
	 * @return IResultListWL (List of records that were not processed by EASE and error code in case of exceptions in the process).
	 * This method is called to generate reports for records that did not get updated at the EASE end.
	 */
	public IResultListWL                          getEASEExceptionRecords(String officeId);
	public IErrorWL                               updateExceptionRep(Integer sysId);
	/**
	 * 
	 * @param examQuestionList (A list of exam question records that needs to be inserted into its table).
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to insert a list of exam question records.
	 */
	public IErrorWL                               saveExamQuesList(List<IExamQuestion> examQuestionList);
	/**
	 * 
	 * @param examAnswerList (A list of exam answer records that needs to be inserted into its table).
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to insert a list of exam answer records.
	 */
	public IErrorWL                               saveExamAnswList(List<IExamAnswer> examAnswerList);
	/**
	 * 
	 * @param applicationId.
	 * @return IBooleanWL (Contains boolean value indicating whether the applicant has any exams yet to take).
	 * This method is called to check whether there are exams to take based on application id.
	 */
	public IBooleanWL                             hasExamsToTake(Integer applicationId);
	/**
	 * 
	 * @param applicationId.
	 * @return IExamListWL (Contains a list of exams and error code in case of exceptions in the process).
	 * This method is called to get the exams yet to be taken based on the application id.
	 */
	public IExamListWL                            getExamsToTake(Integer applicationId);
	/**
	 * 
	 * @param exam
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to update exam record.
	 */
	public IErrorWL                               updateExam(IExam exam);
	/**
	 * 
	 * @param exams.
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 * This method is called to save a list of exams in the exam table.
	 */
	public IErrorWL                               saveExamList(List<IExam> exams);
	/**
	 * 
	 * @param applicationId.
	 * @return IExamListWL (Contains a list of exams and error code in case of exceptions in the process).
	 * This method is called to get a list of exams based on the application id from present and past.
	 */
	public IExamListWL                            getAllExamsByAppId(Integer applicationId);
	/**
	 * 
	 * @param examId.
	 * @return IExam (Contains a exams record).
	 * This method is called to get a exam record based on the exam id.
	 */
	public IExamHistoryListWL getExamHistoryByExamId(Integer examId);
	public List<IExamAnswer> getExamAnswByExamIdAndQuesGenIdOrderByAnswPresOrd(
			IExamQuestion eq);
	public Map<Integer, List<IExamAnswer>> getQuesGenIdMapWithAnswOrderByAnswPresOrd(Integer examId, List<Integer> questionGenIds);
	public List<Answer> getAnswerInDisplayOrder(List<IExamAnswer> examAnswerOrder, List<Answer> answerListUnordered);
}
