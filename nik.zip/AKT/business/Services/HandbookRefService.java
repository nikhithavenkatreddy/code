package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IHandbookRefListWL;
import gov.ca.dmv.AKT.integration.BeansImpl.HRPrimaryKey;
import gov.ca.dmv.AKT.integration.BeansImpl.HandbookRef;

public interface HandbookRefService {

	/**
	 * 
	 * @param handbookRef
	 * This method is used to get a handbook.
	 * @return
	 */
	public IHandbookRefListWL getHandbook( HRPrimaryKey hrPrimaryKey);
	/**
	 * 
	 * @param handbookBO
	 * This method saves the new handbook 
	 * @return 
	 */
	public IErrorWL saveHandbook(HandbookRef handbookBO);
	/**
	 * 
	 * @param handbookBO
	 * this method is used update a handbook section
	 * @return
	 */
	public IHandbookRefListWL updateHandbook(HandbookRef handbookBO);
	
	/**
	 * 
	 * @param handbookBO
	 * This method is used to search by handbookName and/or langId
	 * @return
	 */
	public IHandbookRefListWL searchHandbook(HandbookRef handbookBO,HRPrimaryKey hrPrimaryKey);
}
