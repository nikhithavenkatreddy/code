package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.ICategoryListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;
import gov.ca.dmv.AKT.integration.BeansImpl.Category;


public interface CategoryService extends BaseService {
	/**
	 * 
	 * @param categoryId
	 * @return ICategoryListWL (Contains List of categories).
	 * This method is used to get a list of categoryId.
	 */
	
	public ICategoryListWL getCategory(String categoryId);
	
	
	/**
	 * 
	 * @param category
	 * @return
	 * This method is used to save category.
	 */
	public IErrorWL saveCategory(gov.ca.dmv.AKT.integration.BeansImpl.Category category);
	
	/**
	 * 
	 * @param category
	 * @return ICategoryListWL (Contains List of categories).
	 * This method is used to update a list of categoryId.
	 */
	
	  public IErrorWL updateCategory(Category category);
	
	  /**
		 * 
		 * @param category
		 * @return ICategoryListWL (Contains List of categories).
		 * This method is used to search a category  by id and/or name.
		 */
		
	 public ICategoryListWL searchCategory(Category category);
		
}
