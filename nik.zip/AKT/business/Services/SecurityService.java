package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IBooleanWL;

public interface SecurityService extends BaseService {

	/**
	 * 
	 * @param userId.
	 * @param password.
	 * @param userIdLoggedIn.
	 * @return IBooleanWL (Contains boolean value and error code in case of an exception in the process).
	 * This method is called to authenticate and authorize the user.
	 */
	public IBooleanWL authenticate(String userId, String password, String userIdLoggedIn);
}
