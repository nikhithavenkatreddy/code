package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditListWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IAuditWL;
import gov.ca.dmv.AKT.business.WorkloadInterface.IErrorWL;

import java.util.List;

/**
 * 
 * @author MWRZA
 * AuditService handles all services pertaining to auditing historical information.
 */
public interface AuditService extends BaseService {
	/**
	 * 
	 * @param tableName represents the table for which we are maintaining the historical data.
	 * @param fieldName represents the column in the table for which we are maintaining the historical data.
	 * @param oldValue represents the old value in the column we are maintaining the history for.
	 * @param newValue represents the new value in the column we are maintaining the history for.
	 * @param key represents the value in a column that uniquely identifies the record for maintaining the historical data.
	 * @param techId represents the technician id who is responsible for changing the values.
	 * @return IErrorWL (Contains the error code in case of exceptions in the process).
	 */
	public IErrorWL saveAudit(String tableName, String fieldName, String oldValue, String newValue, String key, String techId);
	
	/**
	 * Get Audit List For passed in Exam Ids.
	 * @param examIds
	 * @return
	 */
	public IAuditListWL getAuditListForExamIds(List<Integer> examIds);
	/**
	 * 
	 * @param key represents the value in a column that uniquely identifies the record for maintaining the historical data.
	 * @param tableName represents the name of the table/view that holds the 'key' mentioned above.
	 * @return IAuditWL (Contains the audit record and error code in case of exceptions in the process).
	 * This method is called to get the latest audit record based on the key and the table name.
	 */
	public IAuditWL getAuditByKeyAndTable(String key, String tableName);
}
