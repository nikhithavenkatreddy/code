package gov.ca.dmv.AKT.business.Services;

import gov.ca.dmv.AKT.business.WorkloadInterface.IApplicantListWL;
import gov.ca.dmv.AKT.integration.BeansImpl.Search;

/**
 * 
 * @author MWRZA
 *
 * The Search Service handles all requests from FOD to search for applicants by DL # and last name.
 */
public interface SearchService extends BaseService {

	/**
	 * 
	 * @param search contains the search parameters such as DL #, Last name and what feature is calling for this service.
	 * @return IApplicantListWL(list of applicant information based on the search parameters).
	 * This method is called to search by DL # or last name based on the request type.
	 */
	public IApplicantListWL search(Search search);

}
