package gov.ca.dmv.AKT.comparators;

import gov.ca.dmv.AKT.constants.Constant;

import java.util.Comparator;

public class TestComparator implements Comparator<gov.ca.dmv.AKT.presentation.Beans.Test> {
	public int compare(gov.ca.dmv.AKT.presentation.Beans.Test t1, gov.ca.dmv.AKT.presentation.Beans.Test t2) 
	{   
		if(t1.getTestName().equalsIgnoreCase(Constant.DASHES))
			return Constant.NEGATIVE_ONE;
		else if(t2.getTestName().equalsIgnoreCase(Constant.DASHES))
			return Constant.ONE;
		return t1.getTestName().compareToIgnoreCase(t2.getTestName());     
	} 
}
