package gov.ca.dmv.AKT.comparators;

import java.util.Comparator;

public class HandbookComparator implements Comparator<gov.ca.dmv.AKT.presentation.Beans.HandbookRef> {
	public int compare(gov.ca.dmv.AKT.presentation.Beans.HandbookRef h1, gov.ca.dmv.AKT.presentation.Beans.HandbookRef h2) 
	{         
		return h1.getHandbookSectionName().compareToIgnoreCase(h2.getHandbookSectionName());     
	}
}
