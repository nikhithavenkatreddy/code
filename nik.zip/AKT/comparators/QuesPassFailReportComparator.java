package gov.ca.dmv.AKT.comparators;

import java.util.Comparator;

public class QuesPassFailReportComparator implements Comparator<gov.ca.dmv.AKT.presentation.Beans.QuesPassRate> {
	public int compare(gov.ca.dmv.AKT.presentation.Beans.QuesPassRate q1, gov.ca.dmv.AKT.presentation.Beans.QuesPassRate q2) 
	{         
		if(q2.getFailRate() > q1.getFailRate()) 
			return 1;
		else if(q1.getFailRate() > q2.getFailRate())
			return -1;
		return 0;
	}
}
