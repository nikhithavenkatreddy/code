package gov.ca.dmv.AKT.comparators;

import gov.ca.dmv.AKT.constants.Constant;

import java.util.Comparator;

public class ApplicantComparator implements Comparator<gov.ca.dmv.AKT.presentation.Beans.Applicant> {
	public int compare(gov.ca.dmv.AKT.presentation.Beans.Applicant app1, gov.ca.dmv.AKT.presentation.Beans.Applicant app2) 
	{   
		return app1.getDlNumber().compareToIgnoreCase(app2.getDlNumber());     
	} 
}
