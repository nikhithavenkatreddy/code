package gov.ca.dmv.AKT.comparators;

import gov.ca.dmv.AKT.constants.Constant;

import java.util.Comparator;

public class CategoryComparator implements Comparator<gov.ca.dmv.AKT.presentation.Beans.Category> {
	public int compare(gov.ca.dmv.AKT.presentation.Beans.Category c1, gov.ca.dmv.AKT.presentation.Beans.Category c2) 
	{         
		if(c1.getCategoryName().equalsIgnoreCase(Constant.DASHES))
			return Constant.NEGATIVE_ONE;
		else if(c2.getCategoryName().equalsIgnoreCase(Constant.DASHES))
			return Constant.ONE;
		return c1.getCategoryName().compareToIgnoreCase(c2.getCategoryName());     
	} 
}
