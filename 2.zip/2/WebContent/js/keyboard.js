function displayKeyboard() {
	$('#key1').keyboard({
		restrictInput: true,
	    autoAccept: true,
		layout: 'custom',
		usePreview: false,
		
		customLayout: {
		        'default': [
		        'q w e r t y u i o p',
				'a s d f g h j k l',
				'z x c v b n m',
				'{accept} {bksp} {clear}']
	        },
		display: {
		        'accept' : 'ENTER','clear' : 'CLEAR','bksp' : 'BACKSPACE'
		}
	});
	
	$('#key4').keyboard({
		restrictInput: true,
	    autoAccept: true,
		layout: 'custom',
		usePreview: false,
		
		customLayout: {
		        'default': [
		        '1 2 3 4 5 6 7 8 9 0 ',
				'/ {accept} {bksp} {clear}']
	        },
		display: {
		        'accept' : 'ENTER','clear' : 'CLEAR','bksp' : 'BACKSPACE'
		}
	});
}



function displayDLKeyboard() {

	$('#dl1').keyboard({
		
	    autoAccept: true,
		layout: 'custom',
		usePreview: false,
		
		customLayout: {
	        'default': [
	        '1 2 3 4 5 6 7 8 9 0',
	        'Q W E R T Y U I O P',
			'A S D F G H J K L {empty}',
			'Z X C V B N M {empty} {bksp}',
			'{clear} {empty} {empty} {empty} {empty} {empty}  {empty} {empty} {accept} ']
        },
		display: {
		        'accept' : 'ENTER','clear' : 'CLEAR','bksp' : 'BACKSPACE'
		}
	});
	

}