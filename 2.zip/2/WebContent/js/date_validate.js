function isDate(txtDate)
{
  var currVal = txtDate;
  var today=new Date();
  if(currVal == '')
    return false;
  
  //Declare Regex  
  var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; 
  var dtArray = currVal.match(rxDatePattern); // is format OK?

  if (dtArray == null)
     return false;
 
  //Checks for mm/dd/yyyy format.
  dtMonth = dtArray[1];
  dtDay= dtArray[3];
  dtYear = dtArray[5];
  var myDate= new Date(dtYear,dtMonth,dtDay);
  if (dtMonth < 1 || dtMonth > 12 || dtMonth.length!=2)
      return false;
  else if (dtDay < 1 || dtDay> 31 || dtDay.length!=2)
      return false;
  else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31)
      return false;
  //checks for entered date is not a future date
  else if(myDate>today)
	  return false;
  else if (dtMonth == 2)
  {
     var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
     if (dtDay> 29 || (dtDay ==29 && !isleap))
          return false;
  }
  return true;
}

function isDL(input){
	var field = document.getElementById(input).value.toLowerCase();						
	if(field.length!=8){
		return false;
	}
	if(field.charAt(0)<'a' || field.charAt(0)>'z'){
		return false;
	}
	for(var i=1; i<8; i++){
		if(field.charAt(i)<'0' || field.charAt(i)>'9'){
			return false;
		}
	}		
	return true;
}


function isEmpty(input,len) {
	var field = document.getElementById(input).value.length;
	if(field<len){
		return true;
	}
	else{
		return false;
	}
}

function approveSearch(dl,lname){
	if(isEmpty(dl,1)){
		if(isEmpty(lname,1)){
			return "Provide either DL Number or Last Name";
		}
		if(isEmpty(lname,1)){
			return "Provide at least 1 characters of Last Name";
		}
		return "0";
	}
	if(isDL(dl)){
		return "0";
	}
	else{
		return "Not a valid DL";
	}
}

function validateDL(dl){
	if(isEmpty(dl,1)){
		return "Provide correct DL Number";
	}
	else if(isDL(dl)){
		return "0";
	}
	else{
		return "Not a valid DL";
	}
}
