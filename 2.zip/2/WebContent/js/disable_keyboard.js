/**
 * Since EDL44 uses the same terminals as the test taking stations, keyboards are installed for inputing information on the EDL44 application.
 * AKTE test taking module is designed to work with a touch screen virtual keyboard that does not have the function keys a regular keyboard has.
 * Keyboard input needs to be disabled to prevent test takers from using shortcut keys such as Alt+LeftArrow to fall back while taking a test. 
 */
document.onkeydown = function (e) {
    e.preventDefault();		
};
