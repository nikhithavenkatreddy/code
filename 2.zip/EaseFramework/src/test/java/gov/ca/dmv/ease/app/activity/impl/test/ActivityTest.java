/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl.test;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.action.impl.ActionsRegistry;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.BusinessActivity;
import gov.ca.dmv.ease.app.activity.impl.EndActivity;
import gov.ca.dmv.ease.app.activity.impl.TransitionsMap;
import gov.ca.dmv.ease.app.config.IProcessLoader;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessRegistry;
import gov.ca.dmv.ease.app.config.impl.TransactionTypeRegistry;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.bo.fixture.impl.UserContextFixtureFactory;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.stubs.SynchronousResponseStub;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.IErrorCollectorEntry;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollectorEntry;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.validator.IValidationRule;

import java.util.ArrayList;
import java.util.List;

import org.easymock.classextension.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Description: This class tests Activity.
 * File: ActicityTest.java
 * Module:  gov.ca.dmv.ease.app.activity.impl.test
 * Created: Feb 23, 2010
 * @author MWYXG1
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:41:57 $
 * Last Changed By: $Author: mwhys $
 */
public class ActivityTest extends Activity {
	/** The ActivityTest.java */
	private static final long serialVersionUID = 2875950865545400773L;
	/** The fixture. */
	private Activity fixture;
	/** The Process Context. */
	private MockProcessContext mockProcessContext;
	/** The Session Context. */
	private SessionContext sessionContext;
	/** The MockBypassActivity. */
	private MockBypassActivity activity;

	/**
	 * Creates the process context.
	 */
	private void createProcessContext() {
		mockProcessContext = new MockProcessContext();
		activity = new MockBypassActivity();
		mockProcessContext.setNextActivity(activity);
		mockProcessContext.startIn(sessionContext);
	}

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		fixture = new EndActivity();
		sessionContext = new SessionContext();
		sessionContext.setUserContext(UserContextFixtureFactory
				.createUserContext());
		createProcessContext();
	}

	/**
	 *  Reset fixtures after each test.
	 */
	@After
	public void tearDown() {
		fixture = null;
		sessionContext = null;
	}

	/**
	 * Test create save point.
	 */
	@Test
	public void testCreateSavePoint() {
		createSavePoint(mockProcessContext);
	}

	/**
	 * Test delete save point.
	 */
	@Test
	public void testDeleteSavePoint() {
		SessionContext sessionContext = new SessionContext();
		IUserContext userContext = UserContext.getDefaultInstanceForDb();
		sessionContext.setUserContext(userContext);
		deleteSavePoint(sessionContext);
	}

	/**
	 * Test execute.
	 */
	@Test
	public void testExecute() {
		fixture.execute(mockProcessContext);
		Assert.assertNotNull(mockProcessContext.getRootContext()
				.getCurrentProcessContext());
	}

	/**
	 * Test getActionRegistry.
	 */
	@Test
	public void testGetActionRegistry() {
		MockBypassActivity activity = new MockBypassActivity();
		ActionsRegistry registry = new ActionsRegistry();
		activity.setActionsRegistry(registry);
		Assert.assertNotNull(activity.getActionsRegistry());
	}

	/**
	 * Test getPostConditionValidationRules.
	 */
	@Test
	public void testGetPostConditionValidationRules() {
		MockBypassActivity activity = new MockBypassActivity();
		List <IValidationRule> postConditionValidationRules = new ArrayList <IValidationRule>();
		activity.setPostConditionValidationRules(postConditionValidationRules);
		Assert.assertNotNull(activity.getPostConditionValidationRules());
	}

	/**
	 * Test getPreConditionValidationRules.
	 */
	@Test
	public void testGetPreConditionValidationRules() {
		MockBypassActivity activity = new MockBypassActivity();
		List <IValidationRule> preConditionValidationRules = new ArrayList <IValidationRule>();
		activity.setPreConditionValidationRules(preConditionValidationRules);
		Assert.assertNotNull(activity.getPreConditionValidationRules());
	}

	/**
	 * Test getProcessRegistry.
	 */
	@Test
	public void testGetProcessRegistry() {
		MockBypassActivity activity = new MockBypassActivity();
		IProcessRegistry processRegistry = new ProcessRegistry();
		activity.setProcessRegistry(processRegistry);
		Assert.assertNotNull(activity.getProcessRegistry());
	}

	/**
	 * Test getTransactionTypeRegistry.
	 */
	@Test
	public void testGetTransactionTypeRegistry() {
		MockBypassActivity activity = new MockBypassActivity();
		ITransactionTypeRegistry transactionTypeRegistry = new TransactionTypeRegistry();
		activity.setTransactionTypeRegistry(transactionTypeRegistry);
		Assert.assertNotNull(activity.getTransactionTypeRegistry());
	}

	/**
	 * Test isNotByPassValidations.
	 */
	@Test
	public void test01IsNotByPassValidations() {
		Action action = new Action();
		mockProcessContext.setSelectedAction(action);
		Assert.assertTrue(activity
				.callSuperClassIsNotByPassValidations(mockProcessContext));
	}

	/**
	 * Test isNotByPassValidations.
	 */
	@Test
	public void test02IsNotByPassValidations() {
		Action action = new Action();
		action.setByPassValidations(true);
		mockProcessContext.setSelectedAction(action);
		Assert.assertFalse(activity
				.callSuperClassIsNotByPassValidations(mockProcessContext));
	}

	/**
	 * Test isNotEmptyOrCancelOrRestart.
	 */
	@Test
	public void test01IsNotEmptyOrCancelOrRestart() {
		ActionsRegistry registry = new ActionsRegistry();
		activity.setActionsRegistry(registry);
		Action enterAction = new Action();
		enterAction.setKey("ENTER");
		registry.addAction(enterAction);
		Action restartAction = new Action();
		restartAction.setKey("RESTART");
		registry.addAction(restartAction);
		Action cancelAction = new Action();
		cancelAction.setKey("CANCEL");
		registry.addAction(cancelAction);
		mockProcessContext.setSelectedAction(enterAction);
		Assert.assertTrue(activity
				.callSuperClassIsNotEmptyOrCancelOrRestart(mockProcessContext));
	}

	/**
	 * Test isNotEmptyOrCancelOrRestart with no selected action.
	 */
	@Test
	public void test02IsNotEmptyOrCancelOrRestart() {
		ActionsRegistry registry = new ActionsRegistry();
		activity.setActionsRegistry(registry);
		Action enterAction = new Action();
		enterAction.setKey("ENTER");
		registry.addAction(enterAction);
		Action restartAction = new Action();
		restartAction.setKey("RESTART");
		registry.addAction(restartAction);
		Action cancelAction = new Action();
		cancelAction.setKey("CANCEL");
		registry.addAction(cancelAction);
		mockProcessContext.setSelectedAction(null);
		Assert.assertFalse(activity
				.callSuperClassIsNotEmptyOrCancelOrRestart(mockProcessContext));
	}

	/**
	 * Test isSyncPoint.
	 */
	@Test
	public void testIsSynchPoint() {
		activity.setSyncPoint(true);
		Assert.assertTrue(activity.isSyncPoint());
	}

	/**
	 * Test isSyncPoint.
	 */
	@Test
	public void testNotDoneYet() {
		activity.callSuperClassIsNotDoneYet("TEST MESSAGE");
	}

	/**
	 * Test populateErrorMessages.
	 */
	@Test
	public void test01PopulateErrorMessages() {
		ErrorCollector errorCollector = new ErrorCollector();
		List <IErrorCollectorEntry> errorCollectorEntries = new ArrayList <IErrorCollectorEntry>();
		Exception exception = new Exception("TEST");
		ErrorCollectorEntry errorCollectorEntry = new ErrorCollectorEntry(
				exception);
		errorCollectorEntries.add(errorCollectorEntry);
		errorCollector.addEntries(errorCollectorEntries);
		activity.callSuperClassPopulateErrorMessages(mockProcessContext,
				errorCollector);
		Assert.assertEquals(1, mockProcessContext.getValidationMessages()
				.size());
		Assert.assertNotNull(mockProcessContext.getValidationMessages().get(
				"TEST"));
	}

	/**
	 * Test populateErrorMessages.
	 */
	@Test
	public void test02PopulateErrorMessages() {
		SynchronousResponseStub stub = new SynchronousResponseStub();
		ErrorCollector errorCollector = new ErrorCollector();
		stub.setErrorCollector(errorCollector);
		List <IErrorCollectorEntry> errorCollectorEntries = new ArrayList <IErrorCollectorEntry>();
		Exception exception = new Exception("TEST");
		ErrorCollectorEntry errorCollectorEntry = new ErrorCollectorEntry(
				exception);
		errorCollectorEntries.add(errorCollectorEntry);
		errorCollector.addEntries(errorCollectorEntries);
		activity.callSuperClassPopulateErrorMessages(mockProcessContext, stub);
		Assert.assertEquals(1, mockProcessContext.getValidationMessages()
				.size());
		Assert.assertNotNull(mockProcessContext.getValidationMessages().get(
				"TEST"));
	}

	/**
	 * Test preCondition.
	 */
	@Test
	public void test01PreCondition() {
		Action action = new Action();
		action.setByPassValidations(false);
		mockProcessContext.setSelectedAction(action);
		List <IValidationRule> preConditionValidationRules = new ArrayList <IValidationRule>();
		activity.setPreConditionValidationRules(preConditionValidationRules);
		IValidationRule mockRule = EasyMock.createMock(IValidationRule.class);
		mockRule.validate(EasyMock.isA(MockProcessContext.class), EasyMock
				.isA(IErrorCollector.class));
		EasyMock.expectLastCall();
		preConditionValidationRules.add(mockRule);
		EasyMock.replay(mockRule);
		activity.callSuperClassPreCondition(mockProcessContext);
		EasyMock.verify(mockRule);
	}

	/**
	 * Test postCondition.
	 */
	@Test
	public void test01PostCondition() {
		Action action = new Action();
		action.setByPassValidations(false);
		mockProcessContext.setSelectedAction(action);
		List <IValidationRule> postConditionValidationRules = new ArrayList <IValidationRule>();
		activity.setPostConditionValidationRules(postConditionValidationRules);
		IValidationRule mockRule = EasyMock.createMock(IValidationRule.class);
		mockRule.validate(EasyMock.isA(MockProcessContext.class), EasyMock
				.isA(IErrorCollector.class));
		EasyMock.expectLastCall();
		postConditionValidationRules.add(mockRule);
		EasyMock.replay(mockRule);
		activity.callSuperClassPostCondition(mockProcessContext);
		EasyMock.verify(mockRule);
	}

	/**
	 * Test postCondition.
	 */
	@Test
	public void testIsRestartOrCancelAction() {
		MockBypassActivity mockNextActivity = EasyMock
				.createMock(MockBypassActivity.class);
		mockNextActivity.execute(EasyMock.isA(MockProcessContext.class));
		EasyMock.expectLastCall();
		EasyMock.replay(mockNextActivity);
		mockProcessContext.setNextActivity(mockNextActivity);
		addTransition("cancel", mockProcessContext.getNextActivity());
		addAction("cancel");
		activity.setTransitionKey("cancel");
		ActionsRegistry registry = new ActionsRegistry();
		activity.setActionsRegistry(registry);
		Action restartAction = new Action();
		restartAction.setKey("RESTART");
		registry.addAction(restartAction);
		mockProcessContext.setSelectedAction(restartAction);
		activity.execute(mockProcessContext);
		EasyMock.verify(mockNextActivity);
	}

	/**
	 * Adds the action.
	 *
	 * @param key the key
	 */
	private void addAction(String key) {
		ActionsRegistry actionsRegistry = fixture.getActionsRegistry();
		if (actionsRegistry == null) {
			actionsRegistry = new ActionsRegistry();
			actionsRegistry.setActions(new ArrayList <Action>());
			fixture.setActionsRegistry(actionsRegistry);
		}
		Action action = new Action();
		action.setByPassValidations(true);
		action.setCnaBypassAction(true);
		action.setEnabled(true);
		action.setKey(key);
		action.setName(key);
		actionsRegistry.getActions().add(action);
	}

	/**
	 * Adds the transition.
	 *
	 * @param transitionKey the transition key
	 * @param to the to
	 */
	private void addTransition(String transitionKey, Activity to) {
		addTransition(activity, transitionKey, to);
	}

	/**
	 * Adds the transition.
	 *
	 * @param from the from
	 * @param transitionKey the transition key
	 * @param to the to
	 */
	private void addTransition(BusinessActivity from, String transitionKey,
			Activity to) {
		TransitionsMap transitions = from.getTransitions();
		if (transitions == null) {
			from.setTransitions(new TransitionsMap());
		}
		String key = transitionKey;
		if (key == null) {
			key = IProcessLoader.DEFAULT_TRANSITION_KEY;
		}
		from.getTransitions().addTransitions(key, to);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext context) {
		// TODO Auto-generated method stub
	}
}
/**
 *  Modification History:
 *
 *  $Log: ActivityTest.java,v $
 *  Revision 1.2  2012/12/13 00:41:57  mwhys
 *  Updated testDeleteSavePoint.
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2012/05/08 16:16:20  mwhys
 *  Updated tests for createSavePoint() and deleteSavePoint().
 *
 *  Revision 1.8  2011/04/12 17:52:19  mwhxb3
 *  Added testIsRestartOrCancelAction.
 *
 *  Revision 1.7  2011/04/11 22:21:40  mwhxb3
 *  Added unit tests.
 *
 *  Revision 1.6  2011/04/11 18:37:39  mwhxb3
 *   1: Added tests  testXXIsNotEmptyOrCancelOrRestart
 *   2: Added test testIsSynchPoint
 *
 *  Revision 1.5  2011/04/11 17:48:33  mwhxb3
 *   1: Added test testGetPostConditionValidationRules
 *   2: Added test testGetPreConditionValidationRules
 *
 *  Revision 1.4  2011/04/11 17:44:04  mwhxb3
 *   1: Converted to JUnit 4 style.
 *   2: Added test for getActionRegistry
 *   3: Clean Up.
 *
 *  Revision 1.3  2011/01/17 15:46:01  mwpxp2
 *  Renamed processContextHelper to mockProcessContext; made fixtures private; cleaned up
 *
 *  Revision 1.2  2011/01/15 07:05:00  mwpxp2
 *  Adjusted mock activity imports
 *
 *  Revision 1.1  2010/12/15 23:46:40  mwsec2
 *  class name spelling corrected
 *
 *  Revision 1.3  2010/04/13 23:14:39  mwpxp2
 *  Adjusted imports for class renames
 *
 *  Revision 1.2  2010/03/11 22:23:15  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.1  2010/02/26 23:43:52  mwyxg1
 *  Add new
 *
 */
