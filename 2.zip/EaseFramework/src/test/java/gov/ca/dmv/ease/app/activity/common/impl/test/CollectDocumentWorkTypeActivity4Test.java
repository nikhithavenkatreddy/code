package gov.ca.dmv.ease.app.activity.common.impl.test;

import static org.easymock.EasyMock.expect;
import static org.easymock.classextension.EasyMock.createMock;
import static org.easymock.classextension.EasyMock.replay;
import static org.easymock.classextension.EasyMock.verify;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import gov.ca.dmv.ease.app.activity.common.impl.CollectDocumentWorkTypeActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessRegistry;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessStateInvalidException;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.app.process.impl.TransactionType;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Description: I am unit test for CollectDocumentWorkTypeActivity
 * 
 * File: CollectDocumentWorkTypeActivity4Test.java
 * Module:  gov.ca.dmv.ease.app.activity.common.impl.test
 * Created: Jan 14, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/01/29 00:45:12 $
 * Last Changed By: $Author: mwpxr5 $
 */
public class CollectDocumentWorkTypeActivity4Test {
	/** The Fixture */
	private CollectDocumentWorkTypeActivity fixture;

	/**
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		fixture = new CollectDocumentWorkTypeActivity();
	}

	/**
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		fixture = null;
	}

	/**
	 * @throws Exception
	 */
	@Test
	public void testCollectDocumentWorkTypeActivity_1() throws Exception {
		assertNotNull(fixture);
		assertEquals(null, fixture.getTransitionKey());
		assertEquals(null, fixture.getTransitions());
		assertEquals(null, fixture.getActionsRegistry());
		assertEquals(null, fixture.getActivityName());
		assertEquals(null, fixture.getPostConditionValidationRules());
		assertEquals(null, fixture.getPreConditionValidationRules());
		assertEquals(null, fixture.getProcessRegistry());
		assertEquals(null, fixture.getTransactionTypeRegistry());
		assertEquals(false, fixture.isSyncPoint());
	}

	/**
	 * Test executeAuthorized for DL_MENU_BUSINESS_PROCESS
	 */
	@Test(expected = ProcessStateInvalidException.class)
	public void testExecuteAuthorized_1() {
		ProcessContext context = new ChildContext();
		context.setWorkType("DL");
		IProcessRegistry aRegistry = new ProcessRegistry();
		fixture.setProcessRegistry(aRegistry);
		BusinessProcess mockBusinessProcess = createMock(BusinessProcess.class);
		//  busProcess.setId(IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		TransactionType transType = new TransactionType();
		transType
				.setBusinessProcessName(IProcessRegistry.DL_MENU_BUSINESS_PROCESS);
		List <TransactionType> transTypes = new ArrayList <TransactionType>();
		//	busProcess.setTransactionTypes(transTypes);
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.DL_MENU_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getTransactionTypes()).andReturn(transTypes)
				.anyTimes();
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.DL_MENU_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getProcessContext()).andReturn(context);
		replay(mockBusinessProcess);
		aRegistry.addProcess(mockBusinessProcess);
		fixture.executeAuthorized(context);
		verify(mockBusinessProcess);
	}

	/**
	 * Test executeAuthorized for DCS_MENU_BUSINESS_PROCESS
	 */
	@Test(expected = ProcessStateInvalidException.class)
	public void testExecuteAuthorized_2() {
		ProcessContext context = new ChildContext();
		context.setWorkType("IN");
		IProcessRegistry aRegistry = new ProcessRegistry();
		fixture.setProcessRegistry(aRegistry);
		BusinessProcess mockBusinessProcess = createMock(BusinessProcess.class);
		//  busProcess.setId(IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		TransactionType transType = new TransactionType();
		transType
				.setBusinessProcessName(IProcessRegistry.DCS_MENU_BUSINESS_PROCESS);
		List <TransactionType> transTypes = new ArrayList <TransactionType>();
		//	busProcess.setTransactionTypes(transTypes);
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.DCS_MENU_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getTransactionTypes()).andReturn(transTypes)
				.anyTimes();
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.DCS_MENU_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getProcessContext()).andReturn(context);
		replay(mockBusinessProcess);
		aRegistry.addProcess(mockBusinessProcess);
		fixture.executeAuthorized(context);
		verify(mockBusinessProcess);
	}

	/**
	 * Test executeAuthorized for COURT_INQUIRY_BUSINESS_PROCESS
	 */
	@Test(expected = ProcessStateInvalidException.class)
	public void testExecuteAuthorized_3() {
		ProcessContext context = new ChildContext();
		context.setWorkType("CI");
		IProcessRegistry aRegistry = new ProcessRegistry();
		fixture.setProcessRegistry(aRegistry);
		BusinessProcess mockBusinessProcess = createMock(BusinessProcess.class);
		//  busProcess.setId(IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		TransactionType transType = new TransactionType();
		transType
				.setBusinessProcessName(IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		List <TransactionType> transTypes = new ArrayList <TransactionType>();
		//	busProcess.setTransactionTypes(transTypes);
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getTransactionTypes()).andReturn(transTypes)
				.anyTimes();
		expect(mockBusinessProcess.getId()).andReturn(
				IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
		expect(mockBusinessProcess.getProcessContext()).andReturn(context);
		replay(mockBusinessProcess);
		aRegistry.addProcess(mockBusinessProcess);
		fixture.executeAuthorized(context);
		verify(mockBusinessProcess);
	}

	/**
	 * Test executeAuthorized with ApplicationException
	 */
	@Test(expected = ApplicationException.class)
	public void testExecuteAuthorizedError() {
		IProcessRegistry aRegistry = new ProcessRegistry();
		BusinessProcess businessProcess = new BusinessProcess();
		aRegistry.addProcess(businessProcess);
		fixture.setProcessRegistry(aRegistry);
		ProcessContext context = new ChildContext();
		fixture.executeAuthorized(context);
	}
}
/**
 *  Modification History:
 *
 *  $Log: CollectDocumentWorkTypeActivity4Test.java,v $
 *  Revision 1.2  2013/01/29 00:45:12  mwpxr5
 *  PMD coverage update
 *
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/09/07 22:05:56  mwkfh
 *  fixed tests
 *
 *  Revision 1.1  2011/01/15 02:31:21  mwpxp2
 *  Initial stub - fails
 *
 */
