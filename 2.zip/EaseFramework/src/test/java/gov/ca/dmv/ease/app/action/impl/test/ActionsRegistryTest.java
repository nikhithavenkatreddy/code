/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.action.impl.test;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.action.impl.ActionsRegistry;
import gov.ca.dmv.ease.tus.persist.util.impl.Serializer;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

/**
 * Description: Test class for ActionsRegistry
 * File: ActionsRegistryTest.java
 * Module:  gov.ca.dmv.ease.app.action.impl.test
 * Created: Aug 27, 2010
 * 
 * @author mwhys (?)
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ActionsRegistryTest extends TestCase {
	private Action action1 = null;
	private ActionsRegistry actionsRegistry = null;

	@Override
	@Before
	public void setUp() throws Exception {
		actionsRegistry = new ActionsRegistry();
		action1 = new Action();
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.ActionsRegistry#equals(java.lang.Object)}.
	 */
	@Test
	public void testEqualsObject() {
		ActionsRegistry existingRegistry = actionsRegistry;
		ActionsRegistry newActionsRegistry = new ActionsRegistry();
		newActionsRegistry.setActions(new ArrayList <Action>());
		assertEquals(actionsRegistry, existingRegistry);
		assertFalse(actionsRegistry.equals(newActionsRegistry));
		actionsRegistry.setActions(new ArrayList <Action>());
		actionsRegistry.getActions().add(action1);
		assertFalse(actionsRegistry.equals(newActionsRegistry));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.ActionsRegistry#getAction(java.lang.String)}.
	 */
	@Test
	public void testGetAction() {
		List <Action> aList = new ArrayList <Action>();
		action1.setKey("enter");
		aList.add(action1);
		actionsRegistry.setActions(aList);
		assertEquals(action1, actionsRegistry.getAction("enter"));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.ActionsRegistry#getActions()}.
	 */
	@Test
	public void testGetActions() {
		List <Action> aList = new ArrayList <Action>();
		actionsRegistry.setActions(aList);
		assertEquals(aList, actionsRegistry.getActions());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.ActionsRegistry#hashCode()}.
	 */
	@Test
	public void testHashCode() {
		int hash = actionsRegistry.hashCode();
		actionsRegistry.addAction(new Action());
		assertNotSame(hash, actionsRegistry.hashCode());
	}

	/**
	 * Test to see if the ActionsRegistry can be serialized.
	 */
	@Test
	public void testIsSerializable() {
		//populate action1 object
		action1.setByPassValidations(true);
		action1.setCnaBypassAction(true);
		action1.setEnabled(true);
		action1.setKey("ENTER");
		action1.setName("Enter");
		List <Action> actionList = new ArrayList <Action>();
		actionList.add(action1);
		actionsRegistry.setActions(actionList);
		Serializer serializer = new Serializer();
		serializer.setMaxTreeDepth(10);
		assertTrue(serializer.isSerializable(actionsRegistry, true));
		Blob blob = serializer.getBlobFromObject(actionsRegistry);
		assertNotNull(blob);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.ActionsRegistry#setActions(java.util.List)}.
	 */
	@Test
	public void testSetActions() {
		List <Action> aList = new ArrayList <Action>();
		actionsRegistry.setActions(aList);
		assertEquals(aList, actionsRegistry.getActions());
	}
}
/**
 *  Modification History:
 *
 *  $Log: ActionsRegistryTest.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2011/06/13 18:31:20  mwyxg1
 *  clean up
 *
 *  Revision 1.4  2011/01/15 02:01:10  mwpxp2
 *  Added tests to increase coverage
 *
 *  Revision 1.3  2010/12/24 19:34:54  mwsec2
 *  added test methods
 *
 *  Revision 1.2  2010/09/02 18:19:05  mwkfh
 *  updated serializer calls
 *
 *  Revision 1.1  2010/08/27 23:01:49  mwhys
 *  Added a test to see if the ActionsRegistry can be serialized.
 *
 */
