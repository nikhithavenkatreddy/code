/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * 
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.common.impl.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import gov.ca.dmv.ease.app.activity.common.impl.CollectDocumentWorkTypeActivity;
import gov.ca.dmv.ease.app.activity.impl.test.MockProcessContext;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessRegistry;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.bo.fixture.impl.UserContextFixtureFactory;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Description: Tests CollectDocumentWorkTypeActivity class 
 * File: CollectDocumentWorkTypeActivityTest.java 
 * Module: gov.ca.dmv.ease.app.activity.common.impl.test 
 * Created: Oct 07, 2009
 * @author MWYXG1
 * @version $Revision: 1.3 $ 
 * Last Changed: $Date: 2012/10/18 18:49:18 $ 
 * Last Changed By: $Author: mwkfh $
 */
public class CollectDocumentWorkTypeActivityTest {
	/** The fixture. */
	private CollectDocumentWorkTypeActivity fixture;
	/** The process context. */
	private MockProcessContext processContextHelper;
	/** The process registry. */
	private IProcessRegistry processRegistry;

	/**
	 * Gets the application context bean.
	 * 
	 * @return the bean
	 */
	//	private Object getBean(String beanName) {
	//		ClassPathXmlApplicationContext aContext = new ClassPathXmlApplicationContext(
	//				"classpath*:applicationContext-Cancel-processRegistryTest.xml");
	//		return aContext.getBean(beanName);
	//	}
	/**
	 * Sets up the fixtures.
	 */
	@Before
	public void setUp() throws Exception {
		processContextHelper = new MockProcessContext();
		SessionContext sessionContext = new SessionContext();
		sessionContext.setUserContext(UserContextFixtureFactory
				.createUserContext());
		processContextHelper.startIn(sessionContext);
		fixture = new CollectDocumentWorkTypeActivity();
		processRegistry = new ProcessRegistry(); //(IProcessRegistry) getBean("processRegistry");
		fixture.setProcessRegistry(processRegistry);
	}

	/**
	 * tears down the fixtures
	 */
	@After
	public void tearDown() throws Exception {
		processContextHelper = null;
		fixture = null;
		processRegistry = null;
	}

	/**
	 * Test print activity.
	 */
	@Test
	public void testPrintActivityDlProcessId() {
		processContextHelper.setWorkType("DL");
		try {
			fixture.executeAuthorized(processContextHelper);
		}
		catch (Exception e) {
			assertTrue(e instanceof ApplicationException);
			assertEquals("Invalid TTC", e.getMessage());
		}
	}

	/**
	 * Test print activity.
	 */
	@Test
	public void testPrintActivityEmptyContext() {
		processContextHelper = new MockProcessContext();
		processContextHelper.startIn(new SessionContext());
		try {
			fixture.executeAuthorized(processContextHelper);
		}
		catch (Exception e) {
			assertTrue(e instanceof ApplicationException);
			assertEquals("Invalid TTC", e.getMessage());
		}
	}

	/**
	 * Test print activity.
	 */
	@Test
	public void testPrintActivityInProcessId() {
		processContextHelper.setWorkType("IN");
		try {
			fixture.executeAuthorized(processContextHelper);
		}
		catch (Exception e) {
			assertTrue(e instanceof ApplicationException);
			assertEquals("Invalid TTC", e.getMessage());
		}
	}

	/**
	 * Test print activity.
	 */
	@Test
	public void testPrintActivityNullProcessId() {
		try {
			//TODO - executeAuthorized must not be public
			fixture.executeAuthorized(processContextHelper);
		}
		catch (Exception e) {
			//FIXME - the catch is too broad
			//FIXME - avoid class checking for exceptions - use explicit catch instead
			assertTrue(e instanceof ApplicationException);
			assertEquals("Invalid TTC", e.getMessage());
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: CollectDocumentWorkTypeActivityTest.java,v $
 * Revision 1.3  2012/10/18 18:49:18  mwkfh
 * Removed classpath settings
 *
 * Revision 1.2  2012/10/18 18:13:22  mwkfh
 * changed getApplicationContext to getBean
 *
 * Revision 1.1  2012/10/01 02:57:31  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.11  2012/08/30 20:57:44  mwkfh
 * Fixed tests
 *
 * Revision 1.10  2011/01/15 07:04:03  mwpxp2
 * Adjusted mock activity imports
 *
 * Revision 1.9  2010/12/15 23:45:02  mwsec2
 * renamed mock classes, to avoid confusion with test classes
 *
 * Revision 1.8  2010/09/23 18:58:46  mwhys
 * Removed setProcessRegistry method.
 *
 * Revision 1.7  2010/04/13 23:14:29  mwpxp2
 * Adjusted imports for class renames
 *
 * Revision 1.6  2010/04/13 22:03:13  mwpxp2
 * Bulk cleanup; added todos and fixmes
 *
 * Revision 1.5  2010/04/08 01:29:09  mwcsj3
 * Changed executeAction to executeAuthorized
 *
 * Revision 1.3  2010/04/01 00:11:44  mwakg
 * Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 * Revision 1.2  2010/03/11 22:23:15  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.2  2010/03/09 00:37:37  mwyxg1
 * Multiple Transition for Activities, fix unit tests errors
 *
 * Revision 1.1.2.1  2010/02/26 18:08:06  mwyxg1
 * process multi process transition, resolve compilation errors
 *
 * Revision 1.1  2009/11/30 23:44:34  mwhxa2
 * Test Cases for CollectDocumentWorkTypeActivity
 *
 * Revision 1.6  2009/10/14 02:28:44  mwsxd10
 * Test case updated.
 *
 * Revision 1.5  2009/10/13 01:12:27  mwrrv2
 * fixed formatting issues.
 *
 * Revision 1.4  2009/10/12 22:04:52  mwsxd10
 * Test Case updated.
 * Revision 1.3 2009/10/12
 * 20:07:56 mwsxd10 Test Case updated.
 * 
 * Revision 1.2 2009/10/09 02:07:19 mwsxd10 Test Case for the respective
 * activity class.
 * 
 * Revision 1.1 2009/10/07 18:42:40 mwyxg1 Add new file
 * 
 */
