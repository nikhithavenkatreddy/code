/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.action.impl.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.action.impl.Action;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Description: Test class for gov.ca.dmv.ease.app.action.impl.Action
 * File: ActionTest.java
 * Module:  gov.ca.dmv.ease.app.action.impl.test
 * Created: Dec 27, 2010
 * 
 * @author MWSEC2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ActionTest implements IActionNamesConstants {
	private static final long serialVersionUID = 1L;
	/** The fixture */
	private Action fixture;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		fixture = new Action();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		fixture = null;
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#equals(java.lang.Object)}.
	 */
	@Test
	public void testEqualsObject() {
		assertTrue(fixture.equals(fixture));
		assertFalse(fixture.equals(null));
		assertFalse(fixture.equals("some"));
		fixture.setKey("enter");
		Action another = new Action();
		assertFalse(fixture.equals(another));
		another.setKey("cancel");
		assertFalse(fixture.equals(another));
		fixture.setName("some name");
		another.setName("some name");
		assertFalse(fixture.equals(another));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#getKey()}.
	 */
	@Test
	public void testGetKey() {
		String key = "enter";
		fixture.setKey(key);
		assertSame(key, fixture.getKey());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#getName()}.
	 */
	@Test
	public void testGetName() {
		String name = "ENTER";
		fixture.setName(name);
		assertSame(name, fixture.getName());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#hashCode()}.
	 */
	@Test
	public void testHashCode() {
		int hash = fixture.hashCode();
		assertEquals(hash, fixture.hashCode());
		fixture.setKey("some key");
		assertNotSame(hash, fixture.hashCode());
		fixture.setName("some name");
		assertNotSame(hash, fixture.hashCode());
		int hash2 = new Action().hashCode();
		assertNotSame(hash2, fixture.hashCode());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isAddMore()}.
	 */
	@Test
	public void testIsAddMore() {
		fixture.setKey(IActionNamesConstants.ADD_MORE);
		assertTrue(fixture.isAddMore());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isAnotherForm()}.
	 */
	@Test
	public void testIsAnotherForm() {
		fixture.setKey(IActionNamesConstants.ANOTHER_FORM);
		assertTrue(fixture.isAnotherForm());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isAnotherTry()}.
	 */
	@Test
	public void testIsAnotherTry() {
		fixture.setKey(IActionNamesConstants.ANOTHER_TRY);
		assertTrue(fixture.isAnotherTry());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isBrowse()}.
	 */
	@Test
	public void testIsBrowse() {
		fixture.setKey(IActionNamesConstants.BROWSE_ACTION);
		assertTrue(fixture.isBrowse());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isBrowseBwd()}.
	 */
	@Test
	public void testIsBrowseBwd() {
		fixture.setKey(IActionNamesConstants.BROWSE_BWD_ACTION);
		assertTrue(fixture.isBrowseBwd());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isBrowseFwd()}.
	 */
	@Test
	public void testIsBrowseFwd() {
		fixture.setKey(IActionNamesConstants.BROWSE_FWD_ACTION);
		assertTrue(fixture.isBrowseFwd());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isByPassValidations()}.
	 */
	@Test
	public void testIsByPassValidations() {
		fixture.setByPassValidations(true);
		assertTrue(fixture.isByPassValidations());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isCancel()}.
	 */
	@Test
	public void testIsCancel() {
		fixture.setKey(IActionNamesConstants.CANCEL_ACTION);
		assertTrue(fixture.isCancel());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isCnaBypassAction()}.
	 */
	@Test
	public void testIsCnaBypassAction() {
		fixture.setCnaBypassAction(true);
		assertTrue(fixture.isCnaBypassAction());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isCorrections()}.
	 */
	@Test
	public void testIsCorrections() {
		fixture.setKey(IActionNamesConstants.CORRECTIONS_ACTION);
		assertTrue(fixture.isCorrections());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isCounselorinq()}.
	 */
	@Test
	public void testIsCounselorinq() {
		fixture.setKey(IActionNamesConstants.COUNSELOR_INQUIRY);
		assertTrue(fixture.isCounselorinq());
	}

	@Test
	public void testIsDafUpdate() {
		fixture.setKey(DAF_UPDATE_ACTION);
		assertTrue(fixture.isDafUpdate());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isDisplay()}.
	 */
	@Test
	public void testIsDisplay() {
		fixture.setKey(IActionNamesConstants.DISPLAY_ACTION);
		assertTrue(fixture.isDisplay());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isEnabled()}.
	 */
	@Test
	public void testIsEnabled() {
		fixture.setEnabled(true);
		assertTrue(fixture.isEnabled());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isEnter()}.
	 */
	@Test
	public void testIsEnter() {
		fixture.setKey(IActionNamesConstants.ENTER_ACTION);
		assertTrue(fixture.isEnter());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isFallback()}.
	 */
	@Test
	public void testIsFallback() {
		fixture.setKey(IActionNamesConstants.FALLBACK);
		assertTrue(fixture.isFallback());
	}

	@Test
	public void testIsModifyAppInfo() {
		fixture.setKey(MODIFY_APP_INFO);
		assertTrue(fixture.isModifyAppInfo());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isNoMoreTries()}.
	 */
	@Test
	public void testIsNoMoreTries() {
		fixture.setKey(IActionNamesConstants.NO_MORE_TRIES);
		assertTrue(fixture.isNoMoreTries());
	}

	@Test
	public void testIsPrintTestResults() {
		fixture.setKey(PRINT_TEST_RESULTS);
		assertTrue(fixture.isPrintTestResults());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isPurge()}.
	 */
	@Test
	public void testIsPurge() {
		fixture.setKey(IActionNamesConstants.PURGE_ACTION);
		assertTrue(fixture.isPurge());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isReceiptOnly()}.
	 */
	@Test
	public void testIsReceiptOnly() {
		fixture.setKey(IActionNamesConstants.RECEIPT_ONLY);
		assertTrue(fixture.isReceiptOnly());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isReset()}.
	 */
	@Test
	public void testIsReset() {
		fixture.setKey(IActionNamesConstants.RESET);
		assertTrue(fixture.isReset());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isRestart()}.
	 */
	@Test
	public void testIsRestart() {
		fixture.setKey(IActionNamesConstants.RESTART_ACTION);
		assertTrue(fixture.isRestart());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#isServeAll()}.
	 */
	@Test
	public void testIsServeAll() {
		fixture.setKey(IActionNamesConstants.SERVE_ALL);
		assertTrue(fixture.isServeAll());
	}

	@Test
	public void testIsUpdatePending() {
		fixture.setKey(UPDATE_PENDING_ACTION);
		assertTrue(fixture.isUpdatePending());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#setByPassValidations(boolean)}.
	 */
	@Test
	public void testSetByPassValidations() {
		fixture.setByPassValidations(true);
		assertTrue(fixture.isByPassValidations());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#setCnaBypassAction(boolean)}.
	 */
	@Test
	public void testSetCnaBypassAction() {
		fixture.setCnaBypassAction(true);
		assertTrue(fixture.isCnaBypassAction());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#setEnabled(boolean)}.
	 */
	@Test
	public void testSetEnabled() {
		fixture.setEnabled(true);
		assertTrue(fixture.isEnabled());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#setKey(java.lang.String)}.
	 */
	@Test
	public void testSetKey() {
		String key = "enter";
		fixture.setKey(key);
		assertSame(key, fixture.getKey());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#setName(java.lang.String)}.
	 */
	@Test
	public void testSetName() {
		String name = "ENTER";
		fixture.setName(name);
		assertSame(name, fixture.getName());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.app.action.impl.Action#toString()}.
	 */
	@Test
	public void testToString() {
		fixture.setKey("TEST_KEY");
		fixture.setName("TEST_NAME");
		assertTrue(fixture.toString().indexOf("TEST_KEY") > -1);
		assertTrue(fixture.toString().indexOf("TEST_NAME") > -1);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ActionTest.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2011/06/08 23:22:49  mwyxg1
 *  PMD sev 2 fix
 *
 *  Revision 1.2  2011/01/15 02:01:10  mwpxp2
 *  Added tests to increase coverage
 *
 *  Revision 1.1  2010/12/27 21:45:23  mwsec2
 *  initial check in of test class
 *
 */
