/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.common.impl.test;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.activity.common.impl.IsReprintRequiredDecision;
import gov.ca.dmv.ease.app.activity.impl.DecisionActivity;
import gov.ca.dmv.ease.app.activity.impl.EndActivity;
import gov.ca.dmv.ease.app.activity.impl.TransitionsMap;
import gov.ca.dmv.ease.app.activity.impl.test.MockInteractionActivity;
import gov.ca.dmv.ease.app.activity.impl.test.MockProcessContext;
import gov.ca.dmv.ease.app.config.IProcessLoader;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.bo.fixture.impl.UserContextFixtureFactory;
import junit.framework.TestCase;

import org.junit.Test;

/**
 * Description: This is the test class for IsReprintRequiredDecision activity.
 * File: IsReprintRequiredDecisionTest.java
 * Module:  gov.ca.dmv.ease.app.activity.common.impl.test
 * Created: Oct 8, 2009 
 * @author MWSYK1 
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class IsReprintRequiredDecisionTest extends TestCase {
	/** The fixture. */
	private DecisionActivity fixture;
	/** The Process Context. */
	private MockProcessContext processContextHelper;
	/** The Session Context. */
	private SessionContext sessionContext;

	/**
	 * Creates the process context.
	 */
	private void createProcessContext() {
		processContextHelper = new MockProcessContext();
		MockInteractionActivity activity = new MockInteractionActivity();
		String key = IProcessLoader.DEFAULT_TRANSITION_KEY;
		activity.setTransitionKey(key);
		TransitionsMap transitions = new TransitionsMap();
		transitions.addTransitions(key, new EndActivity());
		activity.setTransitions(transitions);
		Action selectedAction = new Action();
		selectedAction.setKey("yes");
		selectedAction.setName("Reprint");
		processContextHelper.setSelectedAction(selectedAction);
		processContextHelper.setNextActivity(activity);
		processContextHelper.startIn(sessionContext);
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	@Override
	public void setUp() {
		fixture = new IsReprintRequiredDecision();
		String key = "no";
		fixture.setTransitionKey(key);
		TransitionsMap transitions = new TransitionsMap();
		transitions.addTransitions(key, new EndActivity());
		key = "yes";
		transitions.addTransitions(key, new EndActivity());
		fixture.setTransitions(transitions);
		sessionContext = new SessionContext();
		sessionContext.setUserContext(UserContextFixtureFactory
				.createUserContext());
		createProcessContext();
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	public void tearDown() throws Exception {
	}

	/**
	 * Test evaluate.
	 */
	@Test
	public void testEvaluate() {
		MockInteractionActivity activity = new MockInteractionActivity();
		fixture.execute(processContextHelper);
		assertSame(activity.getClass(), processContextHelper.getNextActivity()
				.getClass());
	}
}
/**
 * Modification History:
 * 
 * $Log: IsReprintRequiredDecisionTest.java,v $
 * Revision 1.1  2012/10/01 02:57:31  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.9  2011/01/15 07:04:03  mwpxp2
 * Adjusted mock activity imports
 *
 * Revision 1.8  2010/12/15 23:45:13  mwsec2
 * renamed mock classes, to avoid confusion with test classes
 *
 * Revision 1.7  2010/05/04 00:56:11  mwpxp2
 * Imports adjusted for interface move to non-impl package
 *
 * Revision 1.6  2010/04/14 15:38:59  mwakg
 * Made activities authorizedExecute protected
 *
 * Revision 1.5  2010/04/13 23:14:29  mwpxp2
 * Adjusted imports for class renames
 *
 * Revision 1.4  2010/04/13 22:05:08  mwpxp2
 * Bulk cleanup; fixed javadoc
 *
 * Revision 1.3  2010/04/13 18:11:00  mwcsj3
 * Updated createProcessContext method, set selectedAction to processContext
 *
 * Revision 1.2  2010/03/11 22:23:15  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.3  2010/03/10 00:27:10  mwcsj3
 * Referenced DEFAULT_TRANSITION_KEY from IProcessLoader interface
 *
 * Revision 1.1.2.2  2010/03/01 23:08:18  mwyxg1
 * update test cases
 *
 * Revision 1.1.2.1  2010/02/26 18:02:46  mwyxg1
 * process multi process transition, resolve compilation errors
 *
 * Revision 1.1  2009/11/30 23:35:20  mwhxa2
 * Test Cases for IsReprintRequiredDecision
 *
 * Revision 1.2  2009/10/13 01:14:21  mwrrv2
 * fixed formatting issues.
 *
 * Revision 1.2  2009/10/13 00:56:50  mwrrv2
 * Cleaned to do. fixed formatting issues.
 *  
 */
