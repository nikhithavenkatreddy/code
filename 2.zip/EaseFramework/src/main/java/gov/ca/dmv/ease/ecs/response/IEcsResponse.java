/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.ecs.constants.IEcsConstants;
import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am interface for response objects.
 * File: IReponse.java
 * Module: gov.ca.dmv.ease.service
 * Created: Mar 17, 2009
 *
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEcsResponse extends IResponse, IEcsConstants {
	/**
	 * Gets the business object named.
	 *
	 * @param aPropertyName a property name
	 *
	 * @return the business object named
	 */
	BusinessObject getBusinessObjectNamed(String aPropertyName);

	/**
	 * Gets the object count in the
	 *
	 * @return the object count
	 */
	int getObjectCount();

	/**
	 * Gets the object value named.
	 *
	 * @param aPropertyName a property name
	 *
	 * @return the object value named
	 */
	Object getObjectValueNamed(String aPropertyName);

	/**
	 * Gets the original request id.
	 *
	 * @return the original request id
	 */
	String getOriginalRequestId();

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	String getRequestId();

	String getResponseClassName();

	/**
	 * Gets the response id.
	 *
	 * @return the response id
	 */
	String getResponseId();

	/**
	 * Checks for children.
	 *
	 * @return true, if successful
	 */
	boolean hasChidren();

	/**
	 * Checks for error.
	 *
	 * @return true, if successful
	 */
	boolean hasError();

	/**
	 * Checks if is asynchronous promise.
	 *
	 * @return true, if is asynchronous promise
	 */
	boolean isAsynchronousPromise();

	/**
	 * Checks if is asynchronous response.
	 *
	 * @return true, if is asynchronous response
	 */
	boolean isAsynchronousResponse();

	/**
	 * Checks if is fire and forget response.
	 *
	 * @return true, if is fire and forget response
	 */
	boolean isFireAndForgetResponse();

	/**
	 * Checks if is persisted token.
	 *
	 * @return true, if is persisted token
	 */
	boolean isPersistedToken();

	/**
	 * Checks if is synchronous response.
	 *
	 * @return true, if is synchronous response
	 */
	boolean isSynchronousRespone();

	/**
	 * Validates.
	 */
	void validate();
}
/**
 * Modification History:
 *
 * $Log: IEcsResponse.java,v $
 * Revision 1.1  2012/10/01 02:57:23  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.4  2009/10/14 20:09:46  mwhxb3
 * changes due to renaming IDcsConstants to IEcsConstants.
 *
 * Revision 1.3  2009/10/14 16:45:37  mwhxb3
 * updated comments
 *
 * Revision 1.2  2009/10/06 21:53:43  mwhxb3
 * refactoring from dcs to ecs
 *
 * Revision 1.1.4.1  2009/10/06 20:28:48  mwhxb3
 * refactoring from dcs to ecs
 *
 * Revision 1.4  2009/10/03 21:23:43  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.3  2009/08/27 02:34:02  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.2  2009/07/30 01:27:50  mwpxp2
 * Imports cleanup
 *
 * Revision 1.1  2009/07/27 18:29:35  mwpxp2
 * Renamed to distinguish from IResponse in bo
 *
 * Revision 1.3  2009/07/14 23:58:50  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.2  2009-07-13 02:10:05  ppalacz
 * Import cleanup
 *
 *
 * Revision 1.1  2009-04-26 07:32:41  mwpxp2
 * Initial
 *
 */
