package gov.ca.dmv.ease.tus.logging.po.impl;

import java.util.Calendar;
import java.util.Date;

/**
 * Description: Persistence object of System Management log.
 * File: SystemManagementLog.java
 * Module:  gov.ca.dmv.ease.tus.logging.po.impl
 * Created: Aug 12, 2009
 * 
 * @author MWAXB1
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SysMgmtLog extends AbstractLog {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5023599034633481708L;
	/** The Replace me constant. */
	private static final String REPLACE_ME = " ";
	/** The office id */
	private String officeId = REPLACE_ME;
	/** The tech id */
	private String techId = REPLACE_ME;
	/** The office id */
	private String dlOrIdNumber = REPLACE_ME;
	/** The transaction date */
	private Date transactionDate = new Date(); 
	/** The partition id */
	private int partitionId = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
	
	/**
	 * Instantiates a new sys mgmt log.
	 */
	public SysMgmtLog() {
		super();				
	}

	/**
	 * Instantiates a new sys mgmt log.
	 * 
	 * @param logEntry the log entry
	 * @param methodClassName the method class name
	 * @param threadId the thread id
	 * @param timeStamp the time stamp
	 * @param userId the user id
	 */
	public SysMgmtLog(String logEntry, String methodClassName, String threadId,
			Date timeStamp, String userId) {
		super(logEntry, methodClassName, threadId, timeStamp, userId);
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}

	public String getDlOrIdNumber() {
		return dlOrIdNumber;
	}

	public void setDlOrIdNumber(String dlOrIdNumber) {
		this.dlOrIdNumber = dlOrIdNumber;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getPartitionId() {
		return partitionId;
	}

	public void setPartitionId(int partitionId) {
		this.partitionId = partitionId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SysMgmtLog.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/02/15 21:19:29  mwxxw
 *  Add additional fields: officeId, techId, dlNumber and partitionId.
 *
 *  Revision 1.2  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/13 16:53:29  mwrsk
 *  Logging business objects moved to impl package
 *
 *  Revision 1.12  2009/10/03 21:32:45  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/09/22 23:39:58  mwrsk
 *  Updated Primary Key sequence names
 *
 *  Revision 1.10  2009/09/16 02:18:00  mwrsk
 *  Updated to use sequence
 *
 *  Revision 1.9  2009/09/15 00:51:01  mwrsk
 *  Updated table annotations and code cleanup
 *
 *  Revision 1.8  2009/09/15 00:49:13  mwrsk
 *  updated table annotations
 *
 *  Revision 1.7  2009/09/10 20:48:06  mwpxp2
 *  Added javadoc; bulk cleanup
 *
 *  Revision 1.6  2009/09/10 16:39:34  mwsxd10
 *  Default constructer added.
 *
 *  Revision 1.5  2009/08/31 21:25:21  mwsxd10
 *  Log objects updated. (UserContext is removed)
 *
 *  Revision 1.4  2009/08/31 21:24:34  mwsxd10
 *  Log objects updated. (UserContext is removed)
 *
 *  Revision 1.3  2009/08/27 06:29:20  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.2  2009/08/21 01:39:43  mwsxd10
 *  Hibernate Annotations changed for maintaining inheritance.
 *
 *  Revision 1.1  2009/08/21 00:43:32  mwsxd10
 *  Class for logging information of System Management.
 *
 */
