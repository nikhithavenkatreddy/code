/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageCreationException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;

/**
 * Description: Message creator for image capture server message.
 * File: $ ImageServerMessageCreator.java $
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Oct 14, 2010
 * @author MWPXR4  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $ MWPXR4 $
 */
public class IcsMessageCreator implements MessageCreator {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(IcsMessageCreator.class);

	/**
	 * This method fetches the matching L1 Server Information for an input User Context.
	 * 
	 * @param userContext the User Context Information
	 * 
	 * @return <code>Location</code> containing the L1 Server Information
	 */
	private static Location fetchofficeL1ServerInfo(IUserContext userContext) {
		Location officeL1ServerInfo = new Location();
		try {
			officeL1ServerInfo.setIpAddress(userContext.getIpAddress());
			officeL1ServerInfo.setOfficeId(userContext.getOfficeId());
			IPersistenceServiceRequest request = getPersistenceServiceRequestFactory()
					.createRetrieveBusinessObjectRequest(userContext,
							officeL1ServerInfo);
			RetrieveBusinessObjectResponse response = (RetrieveBusinessObjectResponse) request
					.execute();
			if ((response.hasErrors()) || (response.getResults().size() == 0)) {
				throw new EaseValidationException(
						"NO MATCHING L1 Server INFORMATION FOUND");
			}
			else {
				officeL1ServerInfo = (Location) response.getResults().get(0);
			}
		}
		catch (Exception e) {
			throw new EaseException(e);
		}
		return officeL1ServerInfo;
	}

	/**
	 * Create PersistenceServiceRequestFactory bean from Application context.
	 * 
	 * @return
	 */
	private static PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return PersistenceServiceRequestFactory.getInstance();
	}

	/** Request for which this Message creator is used for **/
	private IEcsRequest request = null;

	/**
	 * Constructor - Instantiates a new creator.
	 * @param aRequest a request
	 */
	public IcsMessageCreator(IEcsRequest aRequest) {
		request = aRequest;
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String msgCreatedByConverter = convertor.createMessage(request);
		if (EaseUtil.isNullOrBlank(request.getUserContext().getOfficeId())) {
			throw new EcsMessageCreationException("Officeid is null");
		}
		//TODO - this is wrong place for assigning correlation ID - should be ecs request factory
		Location l1ServerCode = fetchofficeL1ServerInfo(request
				.getUserContext());
		//String corrID = "DMV"+request.getUserContext().getOfficeId()+"D01";
		String aCorrelationId = "DMV" + l1ServerCode.getL1ServerCode().trim()
				+ l1ServerCode.getL1ServerSuffix().trim();
		LOGGER.info(" correlation id: " + aCorrelationId + " in: " + this);
		TextMessage textMessage = session
				.createTextMessage(msgCreatedByConverter);
		textMessage.setJMSCorrelationID(aCorrelationId);
		return textMessage;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: IcsMessageCreator.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.9.8.1  2011/09/28 02:23:14  mwpxp2
 *  Fixed access to PersistenceServiceRequestFactory instance
 *
 *  Revision 1.9  2011/06/03 23:37:40  mwxxw
 *  Set ipAddress as condition for L1 server query.
 *
 *  Revision 1.8  2011/05/15 01:33:29  mwxxw
 *  Fix the finger print issue in ST.
 *
 *  Revision 1.7  2011/05/12 21:57:37  mwtjc1
 *  ipaddress check is added in fetchofficeL1ServerInfo method
 *
 *  Revision 1.6  2010/12/18 02:42:07  mwpxr4
 *  added trim
 *
 *  Revision 1.5  2010/12/12 17:25:07  mwpxp2
 *  Added logging of correlationId; added fixme for setting of correlation id
 *
 *  Revision 1.4  2010/12/02 00:14:57  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.3  2010/11/13 03:24:19  mwvxm6
 *  Updates to implement  new Office Id mapping for L1 Server processing
 *
 *  Revision 1.2  2010/10/14 21:10:30  mwpxr4
 *  spring based message creator for ICS finger print and photo requests
 *
 *  Revision 1.1  2010/10/14 20:17:57  mwpxr4
 *  spring based message creator for ICS finger print and photo requests
 *
 */
