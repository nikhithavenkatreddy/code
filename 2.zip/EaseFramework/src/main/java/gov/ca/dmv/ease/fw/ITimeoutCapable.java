package gov.ca.dmv.ease.fw;

import java.io.Serializable;

/**
 * Description: Interface to support  timeout-related behavior based on absolute timestamp
 *
 * File: ITimeoutCapable.java
 * Module:  gov.ca.dmv.ease.service
 * Created: Mar 19, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ITimeoutCapable extends Serializable {
	/**
	 * Undefined expiration value
	 */
	long UNDEF_EXPIRATION = -1;

	/**
	 * Gets the absolute expiration timestamp.represented as long msec time
	 *
	 * @return the expiration timestamp
	 */
	long getAbsoluteExpirationTimestamp();

	/**
	 * Checks if timed out - that is, if the current time is later than the absolute expiration.
	 *
	 * @return true, if successful
	 */
	boolean hasTimedOut();
}
/**
 *  Modification History:
 *
 *  $Log: ITimeoutCapable.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/07/27 18:38:11  mwpxp2
 *  Copied from ECS
 *
 */
