/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.ecs.IEcsService;
import gov.ca.dmv.ease.ecs.adaptor.IJmsAdaptor;
import gov.ca.dmv.ease.ecs.adaptor.impl.SpringBasedJmsAdaptor;
import gov.ca.dmv.ease.ecs.bridge.request.impl.AbstractEcsBridgeRequest;
import gov.ca.dmv.ease.ecs.constants.IEcsConstants;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsUnrecognizedRequestException;
import gov.ca.dmv.ease.ecs.ics.request.impl.AbstractEcsImageCaptureSystemRequest;
import gov.ca.dmv.ease.ecs.persist.impl.Payload;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.AbstractEcsLogRequest;
import gov.ca.dmv.ease.ecs.request.impl.AsynchronousEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.CashPersistedTokenRequest;
import gov.ca.dmv.ease.ecs.request.impl.CashPromiseRequest;
import gov.ca.dmv.ease.ecs.request.impl.CompositeRequest;
import gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.SynchronousEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponse;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponsePromise;
import gov.ca.dmv.ease.ecs.response.impl.CompositeResponse;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.ecs.response.impl.SynchronousResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.service.IResponsePromise;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

import java.util.List;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Concrete entry point for ECS - default implementation of IEcsService.
 * File: EcsService.java
 * Module:  gov.ca.dmv.ease.ecs.impl
 * Created: 26/04/2009
 * @author mwpxp2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/24 23:03:58 $
 * Last Changed By: $Author: mwhys $
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/24 23:03:58 $
 * Last Changed By: $Author: mwhys $
 */
public class EcsService implements IEcsService {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8805494300868671784L;
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(EcsService.class);
	/** The SINGLETON. */
	private static EcsService SINGLETON;
	/** The JMS Adaptor */
	private transient IJmsAdaptor jmsAdaptor;
	
	/**
	 * Gets the single instance of EcsService.
	 *
	 * @return single instance of EcsService
	 */
	public static EcsService getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new EcsService();
		}
		return SINGLETON;
	}
	
	/**
	 * Instantiates a new ECS service.
	 */
	protected EcsService() {
		super();
	}
	
	/**
	 * Combines all the payloads retrieved from persistence for a cash promise.
	 *
	 * @param persistedPayloads the persisted payloads
	 * @return the complete payload
	 */
	protected String getCompletePayloadForProcessing(
			List <IBusinessObject> persistedPayloads) {
		StringBuilder completePayload = new StringBuilder("");
		String completePayloadString = null;
		if (EaseUtil.isNotNull(persistedPayloads)
				&& !persistedPayloads.isEmpty()) {
			LOGGER.info(" Persistence returned payloads ");
			if (isResponseReceived(persistedPayloads)) {
				TreeMap <Integer, String> payloadSeqMap = new TreeMap <Integer, String>();
				for (IBusinessObject payload : persistedPayloads) {
					payloadSeqMap.put(((Payload) payload).getSeqNum(),
							((Payload) payload).getPayload());
				}
				for (Integer in : payloadSeqMap.keySet()) {
					completePayload.append(payloadSeqMap.get(in));
				}
				LOGGER.info(" Complete payload response is " + completePayload);
			}
		}
		if (!EaseUtil.isNullOrBlank(completePayload)) {
			completePayloadString = completePayload.toString();
		}
		return completePayloadString;
	}
	
	/**
	 * Get IJmsAdaptor bean from Application context.
	 *
	 * @return the jms adaptor
	 */
	protected IJmsAdaptor getJmsAdaptor() {
		if (jmsAdaptor != null) {
			return jmsAdaptor;
		}
		//TODO - despringify
		else if (EaseApplicationContext.getApplicationContext() == null) {
			return new SpringBasedJmsAdaptor();
		}
		else {
			//TODO despringify
			return (SpringBasedJmsAdaptor) EaseApplicationContext
					.getApplicationContext().getBean("springBasedJmsAdaptor");
		}
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IEcsService#getPersistenceService()
	 */
	public IPersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return PersistenceServiceRequestFactory.getInstance();
	}
	
	/**
	 * Checks if is response received.
	 *
	 * @param persistedPayloads the persisted payloads
	 * @return true, if is response received
	 */
	protected boolean isResponseReceived(
			List <IBusinessObject> persistedPayloads) {
		// Segment "F" indicated the final segment,
		// whose sequence number indicates the total number of segments
		boolean isResponseReceived = false;
		if (persistedPayloads != null && !persistedPayloads.isEmpty()) {
			LOGGER.info(" Total number of segments received so far: "
					+ persistedPayloads.size());
			for (IBusinessObject payload : persistedPayloads) {
				Payload aPayload = (Payload) payload;
				String segmentIndicator = aPayload.getSegmentIndicator();
				LOGGER.info(" Segment indicator from persistence "
						+ segmentIndicator);
				if (IEcsConstants.SEGMENT_INDICATOR_ONLY
						.equalsIgnoreCase(segmentIndicator)) {
					isResponseReceived = true;
				}
				else if (IEcsConstants.SEGMENT_INDICATOR_FINAL
						.equalsIgnoreCase(segmentIndicator)) {
					LOGGER.info(" Final segment received. (Seq number: "
							+ aPayload.getSeqNum() + ")");
					if (aPayload.getSeqNum()
							.compareTo(persistedPayloads.size()) == 0) {
						isResponseReceived = true;
					}
				}
			}
		}
		return isResponseReceived;
	}
	
	/**
	 * Process asynchronous promise.
	 *
	 * @param promise the promise
	 * @return the i ecs response
	 */
	protected IEcsResponse processAsynchronousPromise(
			AsynchronousResponsePromise promise) {
		IEcsResponse ecsResponse = getJmsAdaptor().processPromise(promise);
		return ecsResponse;
	}
	
	/**
	 * Process asynchronous request.
	 *
	 * @param request the request
	 * @return the asynchronous response promise
	 * @throws EcsServiceException the ecs service exception
	 */
	protected AsynchronousResponsePromise processAsynchronousRequest(
			AsynchronousEcsRequest request) throws EcsServiceException {
		AsynchronousResponsePromise returnAsynchronousResponsePromise = (AsynchronousResponsePromise) getJmsAdaptor()
				.processAsynchronous(request);
		return returnAsynchronousResponsePromise;
	}
	
	/**
	 * Process cash persisted token request.
	 *
	 * @param aCashPersistedTokenRequest the a cash persisted token request
	 * @return the synchronous response
	 */
	protected SynchronousResponse processCashPersistedTokenRequest(
			CashPersistedTokenRequest aCashPersistedTokenRequest) {
		//		aCashPersistedTokenRequest.validate();
		//		SynchronousResponse aResponse = (SynchronousResponse) getPersistenceService()
		//				.retrieveResponse(
		//						aCashPersistedTokenRequest.getPersistedResponseId(),
		//						SynchronousResponse.class.getName());
		//		//aResponse.validate();
		//		return aResponse;
		return null;
	}
	
	/**
	 * Process cash promise request.
	 *
	 * @param cashPromiseRequest the cash promise request
	 * @return the asynchronous response
	 */
	protected AsynchronousResponse processCashPromiseRequest(
			CashPromiseRequest cashPromiseRequest) {
		IResponsePromise promise = cashPromiseRequest.getPromise();
		AsynchronousResponse ecsResponse = null;
		LOGGER.info("Processing cash promise request for correlation id "
				+ promise.getCorrelationId());
		Payload response = new Payload();
		response.setCorrelationId(promise.getCorrelationId());
		List <IBusinessObject> persistedPayloads = retrievePersistedInformation(
				cashPromiseRequest, response);
		String completePayloadString = getCompletePayloadForProcessing(persistedPayloads);
		if (!EaseUtil.isNullOrBlank(completePayloadString)) {
			ecsResponse = (AsynchronousResponse) cashPromiseRequest
					.getMessageConverter()
					.createResponse(completePayloadString);
			/*LOGGER.info(" deleting payloads");
			deletePersistedInformation(cashPromiseRequest, persistedPayloads);
			Promise promise = new Promise(cashPromiseRequest.getPromise()
					.getCorrelationId());
			//			promise.setCorrelationId(cashPromiseRequest.getPromise()
			//					.getCorrelationId());
			LOGGER.info(" calling persistence for promise ");
			List <IBusinessObject> persistedPromises = retrievePersistedInformation(
					cashPromiseRequest, promise);
			LOGGER.info(" deleting cash promise ");
			deletePersistedInformation(cashPromiseRequest, persistedPromises);
			LOGGER.info(" Exiting processRequest for cash promise request");*/
		}
		return ecsResponse;
	}
	
	/**
	 * Process composite request.
	 *
	 * @param request the request
	 * @return the composite response
	 */
	public CompositeResponse processCompositeRequest(CompositeRequest request) {
		CompositeResponse aCompositeResponse = new CompositeResponse();
		for (IEcsRequest aRequest : request.getRequests()) {
			IEcsResponse aResponse = processRequest(aRequest);
			aCompositeResponse.add(aResponse);
		}
		return aCompositeResponse;
	}
	
	/**
	 * Process fire and forget request.
	 *
	 * @param request the request
	 * @return the fire and forget receipt
	 * @throws EcsServiceException the ecs service exception
	 */
	protected FireAndForgetReceipt processFireAndForgetRequest(
			FireAndForgetEcsRequest request) throws EcsServiceException {
		FireAndForgetReceipt returnFireAndForgetReceipt = (FireAndForgetReceipt) getJmsAdaptor()
				.processFireAndForget(request);
		return returnFireAndForgetReceipt;
	}
	
	/**
	 * Generic Ecs process request method.
	 *
	 * @param request the request
	 * @return the i ecs response
	 */
	public IEcsResponse processRequest(IEcsRequest request) {
		if (request instanceof AsynchronousEcsRequest) {
			return processAsynchronousRequest((AsynchronousEcsRequest) request);
		}
		// FIXME the condition below looks suspicious; CashPromiseRequest instead is used for getting asynchronous response.
		// The following condition must be inspected not being executed within logs and removed in not required.
		else if (request instanceof AsynchronousResponsePromise) {
			return processAsynchronousPromise((AsynchronousResponsePromise) request);
		}
		else if (request instanceof CashPersistedTokenRequest) {
			return processCashPersistedTokenRequest((CashPersistedTokenRequest) request);
		}
		else if (request instanceof CashPromiseRequest) {
			return processCashPromiseRequest((CashPromiseRequest) request);
		}
		else if (request instanceof CompositeRequest) {
			return processCompositeRequest((CompositeRequest) request);
		}
		else if (request instanceof FireAndForgetEcsRequest) {
			FireAndForgetEcsRequest fireAndForgetEcsRequest = (FireAndForgetEcsRequest) request;
			IErrorCollector errorCollector = new ErrorCollector();
			FireAndForgetReceipt returnFireAndForgetReceipt = null;
			if (!(fireAndForgetEcsRequest instanceof AbstractEcsBridgeRequest)
					&& !(fireAndForgetEcsRequest instanceof AbstractEcsLogRequest)
					&& !(fireAndForgetEcsRequest instanceof AbstractEcsImageCaptureSystemRequest)) {
				errorCollector = fireAndForgetEcsRequest.validate();
			}
			if (errorCollector.hasErrors()) {
				returnFireAndForgetReceipt = new FireAndForgetReceipt(
						errorCollector);
			}
			else {
				returnFireAndForgetReceipt = processFireAndForgetRequest(fireAndForgetEcsRequest);
			}
			return returnFireAndForgetReceipt;
		}
		else if (request instanceof SynchronousEcsRequest) {
			return processSynchronousRequest((SynchronousEcsRequest) request);
		}
		throw new EcsUnrecognizedRequestException(request.toString());
	}
	
	/**
	 * Processes the request.
	 *
	 * @param aRequest the a request
	 * @return null the null response
	 * @throws EcsServiceException the ecs service exception
	 */
	protected SynchronousResponse processSynchronousRequest(
			SynchronousEcsRequest aRequest) throws EcsServiceException {
		SynchronousResponse returnSynchronousResponse = (SynchronousResponse) getJmsAdaptor()
				.processSynchronous(aRequest);
		return returnSynchronousResponse;
	}
	
	/**
	 * Retrieves business objects for a given cash promise from persistence.
	 *
	 * @param cashPromiseRequest the cash promise request
	 * @param businessObject the business object
	 * @return business objects
	 */
	protected List <IBusinessObject> retrievePersistedInformation(
			CashPromiseRequest cashPromiseRequest,
			IBusinessObject businessObject) {
		IPersistenceServiceRequest retrieveBusinessObjectRequest = getPersistenceServiceRequestFactory()
				.createRetrieveBusinessObjectRequest(
						cashPromiseRequest.getUserContext(), businessObject);
		RetrieveBusinessObjectResponse retrieveBusinessObjectResponse = (RetrieveBusinessObjectResponse) retrieveBusinessObjectRequest
				.execute();
		if (retrieveBusinessObjectResponse.hasErrors()) {
			LOGGER
					.info(" Persistence call has returned errors for cash promise "
							+ retrieveBusinessObjectResponse
									.getErrorCollector().toString());
			throw new EcsServiceException(retrieveBusinessObjectResponse
					.getErrorCollector().toString());
		}
		List <IBusinessObject> persistedPayloads = retrieveBusinessObjectResponse
				.getResults();
		return persistedPayloads;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IEcsService#setJmsAdaptor(gov.ca.dmv.ease.ecs.adaptor.impl.SpringBasedJmsAdaptor)
	 */
	public void setJmsAdaptor(SpringBasedJmsAdaptor mockAdaptor) {
		jmsAdaptor = mockAdaptor;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsService.java,v $
 *  Revision 1.2  2012/10/24 23:03:58  mwhys
 *  Deleted unused method deletePersistedInformation().
 *
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.31  2012/08/30 15:49:13  mwkfh
 *  updated setJmsAdaptor and removed Persist mock method
 *
 *  Revision 1.30  2012/08/16 21:43:21  mwkzn
 *  Fixed PMD Issues.
 *
 *  Revision 1.29  2011/12/06 17:37:47  mwpxp2
 *  Added missing javadoc; sorted
 *
 *  Revision 1.28  2011/10/19 19:06:38  mwpxp2
 *  Made a number of private methods protected - for the sake of unit testing and for the mock
 *
 *  Revision 1.27  2011/10/12 20:56:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.26.8.4  2011/09/28 02:47:51  mwpxp2
 *  Added de-springification todos
 *
 *  Revision 1.26.8.3  2011/09/26 23:46:12  mwhys
 *  Updated getJmsAdaptor() to get spring bean.
 *
 *  Revision 1.26.8.2  2011/09/26 05:24:33  mwpxp2
 *  Added createMock~ - to be revisited
 *
 *  Revision 1.26.8.1  2011/09/25 16:27:44  mwpxp2
 *  Made singleton; de-springified
 *
 *  Revision 1.26  2011/07/16 22:29:10  mwhys
 *  Reverted the logic that waits for 30 seconds and updated getCompletePayloadForProcessing() with new logic.
 *  The sequence number in segment "F" signifies the total number of segments and the code awaits for
 *  all the segments or till the promise expires, which ever is earlier.
 *
 *  Revision 1.25  2011/07/16 19:52:03  mwhys
 *  Updated getCompletePayloadForProcessing().
 *
 *  Revision 1.24  2011/07/16 04:41:32  mwhys
 *  Updated processCashPromiseRequest(). Added a call to isExpectedTimeElapsedForProcessingCashPromiseRequest()
 *  to wait for 30 seconds before inquiring the database for response payloads.
 *
 *  Revision 1.23  2011/07/16 02:34:44  mwhys
 *  Updated processCashPromiseRequest() not to delete the CDLIS persisted information.
 *
 *  Revision 1.22  2011/07/16 00:55:09  mwxxw
 *  Add more logic to handle DL_NO_UPDATE role for some fire and forget request.
 *
 *  Revision 1.21  2011/04/28 00:12:04  mwhxb3
 *  Added fixed Me after discussing with Piotr.
 *
 *  Revision 1.20  2010/12/12 17:52:14  mwpxp2
 *  Replaced creation of Promise with multiple public setters with a single constructor
 *
 *  Revision 1.19  2010/12/02 00:14:59  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.18  2010/11/09 03:31:32  mwpxp2
 *  Added EcsUnrecognizedRequestException at the end of public process/1 rather than returning a null; cleanup
 *
 *  Revision 1.17  2010/10/21 22:20:17  mwpxr4
 *  Renamed methods appropriately.
 *
 *  Revision 1.16  2010/10/21 21:27:10  mwpxr4
 *  Changed the type of response.
 *
 *  Revision 1.15  2010/10/15 22:55:10  mwpxr4
 *  Recheckin of EcsService.
 *
 *  Revision 1.13  2010/10/05 16:29:52  mwyxg1
 *  Temporary fix for the AspectJ overload method prolblem
 *
 *  Revision 1.12  2010/09/22 20:30:56  mwpxr4
 *  Organized imports.
 *
 *  Revision 1.11  2010/09/21 21:36:39  mwpxr4
 *  Removed duplicate method deleting multiple business objects.
 *
 *  Revision 1.10  2010/09/21 18:49:02  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.9  2010/09/14 18:29:10  mwkfh
 *  made EcsService non-static
 *
 *  Revision 1.8.4.13  2010/09/18 23:05:43  mwpxr4
 *  Methods with concrete classes made private.
 *
 *  Revision 1.8.4.12  2010/09/17 21:41:49  mwpxr4
 *  Added new constants.
 *
 *  Revision 1.8.4.11  2010/09/17 18:02:34  mwpxr4
 *  Updated Segment Flag check for last segment.
 *
 *  Revision 1.8.4.10  2010/09/17 17:29:19  mwpxr4
 *  *** empty log message ***
 *
 *  Revision 1.8.4.9  2010/09/17 17:20:17  mwpxr4
 *  Added logic to check segment indicator by which we can if all the responses have been received for a given request.
 *
 *  Revision 1.8.4.8  2010/09/16 17:37:03  mwpxr4
 *  Updated code to call the logic to process the payload only if it is present.
 *
 *  Revision 1.8.4.7  2010/09/14 23:24:56  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.8.4.6  2010/09/14 22:12:50  mwpxr4
 *  EcsService merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.8.4.5  2010/09/14 18:18:32  mwpxr4
 *  Removed unused imports.
 *
 *  Revision 1.8.4.4  2010/09/14 18:17:34  mwpxr4
 *  Added to code to delete cash promise after payload is processed.
 *
 *  Revision 1.8.4.3  2010/09/14 17:59:33  mwpxr4
 *  created private methods for retrieving, combining and deleting payloads.
 *
 *  Revision 1.8.4.2  2010/09/14 17:36:58  mwpxr4
 *  Added code to delete the processed payloads for a promise.
 *
 *  Revision 1.8.4.1  2010/09/14 16:11:30  mwpxr4
 *  Removed Simple Persistence dependency for Asynchronous type of ECS communication.
 *
 *  Revision 1.8  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.7  2010/08/31 17:57:02  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.6  2010/04/22 19:16:34  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/04/07 19:23:25  mwvkm
 *  Changed the asynchronous request approach for ecs and fixed the design issue with the framework.
 *
 *  Revision 1.4  2010/04/01 17:03:26  mwakg
 *  Moved life cycle management for ECS related classes into spring
 *
 *  Revision 1.3  2010/03/30 02:22:10  mwvkm
 *  PersistenceService is setting in SpringJmsAdaptor for Asynchronous ECS
 *
 *  Revision 1.2  2010/03/22 23:26:08  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/14 19:56:38  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.7  2009/10/13 20:14:45  mwhxb3
 *  updated comments.
 *
 *  Revision 1.6  2009/10/07 19:54:45  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.5  2009/10/07 14:38:23  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.4  2009/10/07 03:32:51  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:56:04  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:51:37  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:54  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:41  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.12  2009/10/03 21:23:45  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/10/01 18:34:54  mwpzs3
 *  commenting out validation on cashPersistedToken which is not yet implemented
 *
 *  Revision 1.10  2009/09/15 02:23:48  mwpzs3
 *  Update jms1.1 for ASYNC
 *
 *  Revision 1.9  2009/08/27 05:54:46  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.8  2009/08/10 22:43:39  mwpxp2
 *  Added logging
 *
 *  Revision 1.7  2009/07/30 01:26:59  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.6  2009/07/28 22:34:32  mwpxp2
 *  Fixed processRequest for asynch to return AsynchronousResponsePromise
 *
 *  Revision 1.5  2009/07/27 18:47:57  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.4  2009/07/27 18:28:34  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.3  2009/07/14 23:58:53  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:02  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.18  2009-05-18 20:28:16  ppalacz
 *  Javadoc update
 *
 *  Revision 1.17  2009-05-18 19:54:05  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.16  2009-05-18 16:20:55  ppalacz
 *  Javadoc update
 *
 *  Revision 1.15  2009-05-17 19:10:55  ppalacz
 *  Synch
 *
 *  Revision 1.14  2009-05-17 05:21:45  ppalacz
 *  Added support for composite requests
 *
 *  Revision 1.13  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.12  2009-05-13 20:31:17  ppalacz
 *  Fixed impl of processing of cash persistent token request
 *
 *  Revision 1.11  2009-05-12 22:18:13  ppalacz
 *  Added getPersistenceService/0
 *
 *  Revision 1.10  2009-05-11 19:43:32  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.9  2009-05-11 19:10:36  ppalacz
 *  Corrected misspelling
 *
 *  Revision 1.8  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.7  2009-05-11 17:44:34  mwpxp2
 *  Adjusted for obsoleted dispatcher and jms adaptor mods
 *
 *  Revision 1.6  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.5  2009-05-11 07:31:48  mwpxp2
 *  Synch
 *
 *  Revision 1.4  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.3  2009-05-09 07:35:39  mwpxp2
 *  Adjusted imports
 *
 */
