package gov.ca.dmv.ease.tus.logging.po.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.Date;

/**
 * Description: Super class of all persistable logging object
 * File: AbstractLog.java
 * Module:  gov.ca.dmv.ease.tus.logging.po.impl
 * Created: Aug 12, 2009
 * 
 * @author MWAXB1
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/11/07 00:23:04 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class AbstractLog extends BusinessObject {
	/** The Replace me constant. */
	private static final String REPLACE_ME = "log";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7317819793484400495L;
	/** The log entry. */
	private String logEntry = REPLACE_ME;
	/** The method class name. */
	private String methodClassName = REPLACE_ME;
	/** The principal id. */
	private String principalId = REPLACE_ME;
	/** The thread id. */
	private String threadId = REPLACE_ME;
	/** The time stamp. */
	private Date timeStamp = new Date();

	/**
	 * Instantiates a new abstract log.
	 */
	public AbstractLog() {
	}

	/**
	 * Instantiates a new abstract log.
	 * 
	 * @param logEntry the log entry
	 * @param methodClassName the method class name
	 * @param threadId the thread id
	 * @param timeStamp the time stamp
	 * @param principalId the principal id
	 */
	public AbstractLog(String logEntry, String methodClassName,
			String threadId, Date timeStamp, String principalId) {
		super();
		this.logEntry = logEntry;
		this.methodClassName = methodClassName;
		this.threadId = threadId;
		this.timeStamp = timeStamp;
		this.principalId = principalId;
	}

	/**
	 * Gets the log entry.
	 * 
	 * @return the log entry
	 */
	public String getLogEntry() {
		return logEntry;
	}

	/**
	 * Gets the method class name.
	 * 
	 * @return the method class name
	 */
	public String getMethodClassName() {
		return methodClassName;
	}

	/**
	 * Gets the principal id.
	 * 
	 * @return the principal id
	 */
	public String getPrincipalId() {
		return principalId;
	}

	/**
	 * Gets the thread id.
	 * 
	 * @return the thread id
	 */
	public String getThreadId() {
		return threadId;
	}

	/**
	 * Gets the time stamp.
	 * 
	 * @return the time stamp
	 */
	public Date getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the log entry.
	 * 
	 * @param logEntry the new log entry
	 */
	public void setLogEntry(String logEntry) {
		this.logEntry = logEntry;
	}

	/**
	 * Sets the method class name.
	 * 
	 * @param methodClassName the new method class name
	 */
	public void setMethodClassName(String methodClassName) {
		this.methodClassName = methodClassName;
	}

	/**
	 * Sets the principal id.
	 * 
	 * @param principalId the new principal id
	 */
	public void setPrincipalId(String principalId) {
		this.principalId = principalId;
	}

	/**
	 * Sets the thread id.
	 * 
	 * @param threadId the new thread id
	 */
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}

	/**
	 * Sets the time stamp.
	 * 
	 * @param timeStamp the new time stamp
	 */
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(1024);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append(this.getPrincipalId()).append(" ");
		aBuilder.append(this.getTimeStamp());
		aBuilder.append("]\n");
		return aBuilder.toString();
	}
}
/**
 * Modification History:
 * 
 * $Log: AbstractLog.java,v $
 * Revision 1.2  2013/11/07 00:23:04  mwsec2
 * toString method added
 *
 * Revision 1.1  2012/10/01 02:57:26  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.4  2010/03/22 23:38:03  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/02/23 23:28:08  mwvxm6
 * Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 * Revision 1.2  2009/12/18 04:35:37  mwkkc
 * Cleanup - Getting rid of the word FIX ME and REPLACE ME
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.3  2009/10/13 21:21:15  mwrsk
 * Make REPLACE_ME static final
 *
 * Revision 1.2  2009/10/13 21:14:14  mwrsk
 * Add constant for "Replace me"
 *
 * Revision 1.1  2009/10/13 16:53:29  mwrsk
 * Logging business objects moved to impl package
 *
 * Revision 1.14  2009/10/07 18:02:36  mwrsk
 * Now extends from BusinessObject
 *
 * Revision 1.13  2009/10/03 21:32:45  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.12  2009/10/01 20:58:29  mwrsk
 * updated annotations
 *
 * Revision 1.11  2009/09/16 02:17:59  mwrsk
 * Updated to use sequence
 *
 * Revision 1.10  2009/09/15 02:05:47  mwrsk
 * Update column ORM
 *
 * Revision 1.9  2009/09/15 00:48:40  mwrsk
 * Now extends from BusinessObject
 *
 * Revision 1.8  2009/09/10 20:46:40  mwpxp2
 * Fixed class comment; bulk cleanup
 *
 * Revision 1.7  2009/08/31 21:25:21  mwsxd10
 * Log objects updated. (UserContext is removed)
 *
 * Revision 1.6  2009/08/31 21:24:33  mwsxd10
 * Log objects updated. (UserContext is removed)
 *
 * Revision 1.5  2009/08/27 16:46:53  mwakg
 * Fixed compilation issue
 *
 * Revision 1.4  2009/08/27 16:04:41  mwvkk1
 * added userContext
 *
 * Revision 1.3  2009/08/27 06:29:20  mwpxp2
 * Fixed imports for fw migration to compile; bulk cleanup
 *
 * Revision 1.2  2009/08/21 01:39:43  mwsxd10
 * Hibernate Annotations changed for maintaining inheritance.
 *
 * Revision 1.1  2009/08/21 00:44:06  mwsxd10
 * Abstract Class for logging information.
 *
 */
