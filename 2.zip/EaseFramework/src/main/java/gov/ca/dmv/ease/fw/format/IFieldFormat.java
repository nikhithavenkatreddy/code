/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

import java.io.Serializable;

/**
 * Description: I describe a message field format - to be used for validating messages
 * File: IFieldFormat.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IFieldFormat extends ISampleProvider, IValidationProvider,
		Serializable {
	
	/**
	 * Parses the payload.
	 * 
	 * @param aMessagePayload 
	 * @param aBuilder 
	 */
	void parsePayload(String aMessagePayload, StringBuilder aBuilder);
	
	/** The UNDE f_ pos. */
	int UNDEF_POS = -1;

	/**
	 * Gets the end pos.
	 * 
	 * @return the end pos
	 */
	int getEndPos();

	/**
	 * Gets the field name.
	 * 
	 * @return the field name
	 */
	String getFieldName();

	/**
	 * Gets the length.
	 * 
	 * @return the length
	 */
	int getLength();

	/**
	 * Gets the start pos.
	 * 
	 * @return the start pos
	 */
	int getStartPos();

	/**
	 * Gets the type.
	 * 
	 * @return the type
	 */
	FieldValueType getType();
}
/**
 *  Modification History:
 *
 *  $Log: IFieldFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2010/12/16 03:18:29  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.8  2010/12/01 02:37:20  mwpxp2
 *  REmoved IPayloadSampleProducer as super
 *
 *  Revision 1.7  2010/12/01 01:36:14  mwpxp2
 *  Added IPayloadSampleProducer as super interface
 *
 *  Revision 1.6  2010/12/01 01:22:24  mwpxp2
 *  Added super interfaces
 *
 *  Revision 1.5  2010/11/25 01:32:24  mwpxp2
 *  Removed validateChar/2
 *
 *  Revision 1.4  2010/11/25 00:52:31  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.3  2010/11/24 20:39:04  mwpxp2
 *  Added getFieldName/0
 *
 *  Revision 1.2  2010/11/20 23:07:33  mwpxp2
 *  Added getEndPos/0
 *
 *  Revision 1.1  2010/11/20 21:20:17  mwpxp2
 *  Initial
 *
 */
