/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.action;

import java.io.Serializable;

/**
 * Description: I define names of actions 
 * File: IActionNamesConstants.java
 * Module: gov.ca.dmv.ease.app.action 
 * Created: Sep 17, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.1 $ 
 * Last Changed: $Date: 2012/10/01 02:57:27 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IActionNamesConstants extends Serializable {
	/** The ADDITIONAL record. */
	String ADDITIONAL_RECORD = "additional_record";
	/** The ANOTHER_INSURANCE_COMPANY_ACTION. */
	String ANOTHER_INSURANCE_COMPANY_ACTION = "another_co";
	/** The ANOTHER_TRY. */
	String ANOTHER_TRY = "another_try";
	/** The BROWSE action. */
	String BROWSE_ACTION = "browse";
	/** The BROWSE Backward action. */
	String BROWSE_BWD_ACTION = "browse_bwd";
	/** The BROWSE forward action. */
	String BROWSE_FWD_ACTION = "browse_fwd";
	/** The CANCEL action. */
	String CANCEL_ACTION = "cancel";
	/** The CNA_BYPASS action. */
	String CNA_BYPASS = "cnabypass";
	/** The RECEIPT only. */
	String RECEIPT_ONLY = "receiptonly";
	/** The COLLECT_DATA_ action. */
	String COLLECT_DATA_ACTION = "collect_data";
	/** The COLLECT_DATA_ action. */
	String CORRECTIONS_ACTION = "corrections";
	/** The CUSTOME r_ cop y_ action. */
	String CUSTOMER_COPY_ACTION = "customer_copy";
	/** The COLLECT_DATA action. */
	String DAF_UPDATE_ACTION = "daf_update";
	/** The PRINT_TEST_RESULTS action. */
	String PRINT_TEST_RESULTS = "print_test_results";
	/** The DATBASE status action. */
	String DATBASE_STATUS_ACTION = "data_base_status";
	/** The DISPLAY action. */
	String DISPLAY_ACTION = "display";
	/** The DISPLAY NEXT action. */
	String DISPLAY_NEXT_ACTION = "display_next";
	/** The ENTER action. */
	String ENTER_ACTION = "enter";
	/** The FALLBACK action. */
	String FALLBACK = "fallback";
	/** The NAME_BD_CHANGE_ action. */
	String NAME_BD_CHANGE = "name_bd_change";
	/** The NO_MORE_TRIES action. */
	String NO_MORE_TRIES = "no_more_tries";
	/** The MORE_TRIES action. */
	String MORE_TRIES = "more_tries";
	/** The FTA_FTP_LIST action. */
	String FTA_FTP_LIST = "fta_ftp";
	/** The PAY. */
	String PAY = "pay";
	/** The PURGE action. */
	String PURGE_ACTION = "purge";
	/** The RESTART action. */
	String RESTART_ACTION = "restart";
	/** The RESTART with validation action. */
	String RESTART_WITH_VALIDATION_ACTION = "restart_with_validation";
	/** The BROWSE without validation action. */
	String BROWSE_WITHOUT_VALIDATION_ACTION = "browse_without_validation";
	/** The RETAIN_ data_ action. */
	String RETAIN_DATA_ACTION = "retain_data";
	/** The UPDATE all action. */
	String UPDATE_ALL_ACTION = "update_all";
	/** The UPDATE only action. */
	String UPDATE_ONLY_ACTION = "update_only";
	/** The UPDATE pending action. */
	String UPDATE_PENDING_ACTION = "update_pending";
	/** The Counselor_Inquiry_action. **/
	String COUNSELOR_INQUIRY = "counselorinq";
	/** The Serve_All_Action*. */
	String SERVE_ALL = "serve_all";
	/** The RESET. */
	String RESET = "reset";
	/** The ANOTHER form. */
	String ANOTHER_FORM = "another_form";
	/** The ADD_MORE. */
	String ADD_MORE = "additionalosinfo";
	/** The MODIFY_APP_INFO. */
	String MODIFY_APP_INFO = "modify_app_info";
	/** The NEW_REQUEST_ action. */
	String NEW_REQUEST_ACTION = "new_request";
	/** The ALT_PRINT action. */
	String ALT_PRINT = "alt_print";
	
	/** The FEE DETAIL. */
	String FEE_DETAIL = "fee_detail";
}
/**
 * Modification History:
 * 
 * $Log: IActionNamesConstants.java,v $
 * Revision 1.1  2012/10/01 02:57:27  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.19  2011/08/18 22:48:07  mwrrv3
 * Added constant for fee detail. Defect# 6651.
 *
 * Revision 1.18  2011/06/01 23:01:29  mwrrv3
 * Added constant for alternate printer.
 *
 * Revision 1.17  2011/05/12 22:37:12  mwyxg1
 * add NEW_REQUEST_ACTION
 *
 * Revision 1.16  2011/01/03 19:20:40  mwrrv3
 * Added constant for MODIFY_APP_INFO.
 * Revision 1.15 2010/12/24 21:19:22 mwtjc1
 * BROWSE_WITHOUT_VALIDATION_ACTION added
 * 
 * Revision 1.14 2010/12/11 00:01:47 mwsec2 added a 2nd Restart action/button
 * that does not bypass validations
 * 
 * Revision 1.13 2010/12/07 00:55:45 mwhys Added ADD_MORE.
 * 
 * Revision 1.12 2010/12/03 17:31:44 mwhys Added constant ANOTHER_FORM.
 * 
 * Revision 1.11 2010/11/11 01:08:07 mwrrv2 Updated.
 * 
 * Revision 1.10 2010/11/09 18:42:28 mwrrv2 Added More Tries.
 * 
 * Revision 1.9 2010/11/08 16:41:14 mwskh1 added print_test_results
 * 
 * Revision 1.8 2010/11/02 23:45:40 mwtjc1 ReceiptOnly added
 * 
 * Revision 1.7 2010/10/29 16:13:11 mwtjc1 RESET added
 * 
 * Revision 1.6 2010/10/20 20:58:18 mwrxn3 Added SERVE_ALL action
 * 
 * Revision 1.5 2010/10/12 20:55:46 mwrxn3 Added Counselor_Inq action
 * 
 * Revision 1.4 2010/09/28 00:09:26 mwyxg1 add DISPLAY_NEXT_ACTION, replace find
 * next action
 * 
 * Revision 1.3 2010/09/28 00:06:07 mwyxg1 add DISPLAY_NEXT_ACTION
 * 
 * Revision 1.2 2010/09/27 23:43:50 mwyxg1 add FIND_NEXT_ACTION
 * 
 * Revision 1.1 2010/09/17 20:43:32 mwpxp2 Initial - refactored out from
 * IActionsRegistry
 * 
 */
