/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.config.impl;

import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.exception.impl.TransactionTypeNotFoundException;
import gov.ca.dmv.ease.app.process.impl.TransactionType;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Description: Implementation for Transaction Type Registry
 * File: TransactionTypeRegistry.java
 * Module:  gov.ca.dmv.ease.app.config
 * Created: Aug 31, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class TransactionTypeRegistry implements ITransactionTypeRegistry,
		Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5452040629979163048L;
	/** The registry map. */
	public transient Map <String, TransactionType> registryMap;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.config.ITransactionTypeRegistry#addTransactionType(gov.ca.dmv.ease.app.process.impl.TransactionType)
	 */
	public void addTransactionType(TransactionType trans) {
		getRegistryMap().put(trans.getTcode(), trans);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.config.ITransactionTypeRegistry#getTransactionType(java.lang.String)
	 */
	public TransactionType getTransactionType(String tcode) {
		if (!getRegistryMap().containsKey(tcode)) {
			throw new TransactionTypeNotFoundException();
		}
		return getRegistryMap().get(tcode);
	}

	/**
	 * Gets the registry map.
	 * 
	 * @return the registry map
	 */
	private Map <String, TransactionType> getRegistryMap() {
		if (registryMap == null) {
			setRegistryMap(new HashMap <String, TransactionType>());
		}
		return registryMap;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.config.ITransactionTypeRegistry#removeTransactionType(java.lang.String)
	 */
	public void removeTransactionType(String key) {
		getRegistryMap().remove(key);
	}

	/**
	 * Sets the registry map.
	 * 
	 * @param aMap the a map
	 */
	private void setRegistryMap(Map <String, TransactionType> aMap) {
		registryMap = aMap;
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransactionTypeRegistry.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2011/06/10 20:29:19  mwyxg1
 *  clean up
 *
 *  Revision 1.4  2011/06/09 17:04:19  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/09/14 18:14:20  mwhys
 *  Changed registryMap back to transient as it contains the list of security roles, which should not be serialized.
 *
 *  Revision 1.2  2010/09/14 00:39:00  mwkfh
 *  made registryMap non-transient
 *
 *  Revision 1.1  2010/09/03 16:43:36  mwsec2
 *  initial check in
 *
 */
