/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: Constants for EASE authentication.
 * File: IAuthAndAuthConstants.java
 * Module:  gov.ca.dmv.ease.fw.constants
 * Created: Oct 14, 2010 
 * @author MWKFH  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2015/07/24 22:21:14 $
 * Last Changed By: $Author: mwnxg5 $
 */
public interface IAuthAndAuthConstants {
	/** The suffix for the ALL role. */
	static final String ROLE_ALL_SUFFIX = "ALL";
	/** The ROLE_DL_ALL. */
	static final String ROLE_DL_ALL = "DL_ALL";
	/** The ROLE_DL_ISSUANCE. */
	String ROLE_DL_CASHIER = "DL_CASHIER";
	/** The ROLE_DL_ISSUANCE. */
	String ROLE_DL_CORRECTIONS = "DL_CORRECTIONS";
	/** The ROLE_DL_ISSUANCE. */
	String ROLE_DL_COUNSELOR = "DL_COUNSELOR";
	/** The ROLE_DL_ISSUANCE. */
	String ROLE_DL_CAMERA = "DL_CAMERA";
	/** The suffix for the DL_NO_UPDATE role. */
	static final String ROLE_DL_NO_UPDATE = "DL_NO_UPDATE";
	/** The ROLE_DL_ISSUANCE. */
	String ROLE_DL_ISSUANCE = "DL_ISSUANCE";
	/** The ROLE_ISSUANCE. */
	String ROLE_ISSUANCE = "ISSUANCE";
	/** The suffix for the EASE_R_DL_ISSUANCE_LP role. */
	static final String ROLE_DL_APU = "DL_APU";
	/** The suffix for the EASE_R_INV_HQ_SERVICES role. */
	static final String ROLE_INV_HQ_SERVICES = "INV_HQ_SERVICES";
	/** The suffix for the EASE_R_ISS_HQ_SERVICES role. */
	static final String ROLE_ISS_HQ_SERVICES = "ISS_HQ_SERVICES";
	/** The suffix for the ALL role. */
	static final String TAG_ROLE_NAME = "role-name";
	/** The suffix for the ALL role. */
	static final String TAG_SECURITY_ROLE = "security-role";
	/** error messages. */
	static final String APPROVAL_AUTHORITY_APPROVER_INVALID = "APPROVAL AUTHORITY NOT A VALID APPROVER";
	/** The Constant APPROVAL_AUTHORITY_PASSWORD_INVALID. */
	static final String APPROVAL_AUTHORITY_PASSWORD_INVALID = "APPROVAL AUTHORITY LOGIN OR PASSWORD IS INVALID";
	/** The Constant APPROVAL_AUTHORITY_PASSWORD_REQUIRED. */
	static final String APPROVAL_AUTHORITY_PASSWORD_REQUIRED = "APPROVAL AUTHORITY LOGIN AND PASSWORD ARE REQUIRED";
}
/**
 *  Modification History:
 *
 *  $Log: IAuthAndAuthConstants.java,v $
 *  Revision 1.3  2015/07/24 22:21:14  mwnxg5
 *  New Issuance Offices
 *
 *  Revision 1.2  2015/06/12 22:25:54  mwnxg5
 *  INV ISSU for EASE
 *
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/06/22 23:53:25  mwxxw
 *  Add new constant: ROLE_ISSUANCE.
 *
 *  Revision 1.7  2012/06/15 17:26:04  mwxxw
 *  Remove constant for DL_ISSUANCE_LP.
 *
 *  Revision 1.6  2012/01/11 00:02:59  mwxxw
 *  Add new role for EASE: DL_APU.
 *
 *  Revision 1.5  2011/10/26 17:07:46  mwhys
 *  Added ROLE_DL_ISSUANCE.
 *
 *  Revision 1.4  2011/10/25 00:17:15  mwxxw
 *  Add new constants: ROLE_DL_ISSUANCE_LP.
 *
 *  Revision 1.3  2011/09/07 01:09:20  mwxxw
 *  Add new constants: ROLE_DL_ALL.
 *
 *  Revision 1.2  2011/07/15 16:43:22  mwxxw
 *  Add new constants: ROLE_DL_NO_UPDATE.
 *
 *  Revision 1.1  2010/10/15 00:35:27  mwkfh
 *  new constants for AuthAndAuthService
 *
 */
