package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;
import gov.ca.dmv.ease.tus.auth.response.IAuthAndAuthServiceResponse;

public abstract class AuthAndAuthServiceResponse extends AbstractResponse
		implements IAuthAndAuthServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4248155268875993513L;

	/**
	 * Throws ITM exception if errors are found
	 */
	protected void throwExceptionIfErrorFound() {
		if (hasErrors()) {
			throw new EaseException("Auth and Auth Response has errors");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuthAndAuthServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
