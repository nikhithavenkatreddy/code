/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.ecs.ITimeoutCapable;

/**
 * Description: Abstract class for responses to asynchronous requests.
 * File: AsynchronousResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AsynchronousResponse extends AbstractAsynchronousResponse
		implements ITimeoutCapable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7173850473799672919L;

	/**
	 * Instantiates a new asynchronous response.
	 */
	public AsynchronousResponse() {
		super();
	}
}
/**
 *  Modification History:
 *
 *  $Log: AsynchronousResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/14 18:05:56  mwhxb3
 *  updated comments
 *
 *  Revision 1.1  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.6  2009-05-18 21:00:27  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.5  2009-05-13 02:21:54  ppalacz
 *  Removed isAsynchronousResponse
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.2  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
