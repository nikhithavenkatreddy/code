/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response for retrieving DL inventory item
 *  //TODO - remove unused constructors, starting with the default
 * File: RetrieveDlInventoryItemResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Aug 24, 2009
 * 
 * @author MWRSK
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveInventoryItemAndUpdateAsIssuedResponse extends
		PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2144576667130215651L;
	/** The an inventory item. */
	private IInventoryItemRetrievable inventoryItem;

	/**
	 * Instantiates a new retrieve dl inventory item response.
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new retrieve inventory item and update as issued response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(
			IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(
			IErrorCollector collector, int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * Instantiates a new retrieve dl inventory item response.
	 * 
	 * @param aInventoryItem the  inventory item
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(
			IInventoryItemRetrievable aInventoryItem) {
		super();
		inventoryItem = aInventoryItem;
	}

	/**
	 * @param anItemCount
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedResponse(int anItemCount) {
		super(anItemCount);
	}

	/**
	 * Gets the inventory item.
	 * 
	 * @return the inventory item
	 */
	public IInventoryItemRetrievable getInventoryItem() {
		super.throwExceptionIfErrorFound();
		return inventoryItem;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: RetrieveInventoryItemAndUpdateAsIssuedResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/13 00:58:06  mwpxp2
 *  Added constructors from super; added todo
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/13 23:18:04  mwrsk
 *  Moved PersistenceServiceResponse to impl package
 *
 *  Revision 1.7  2009/10/03 21:32:41  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/11 00:12:39  mwrsk
 *  added throwExceptionIfErrorFound();
 *
 *  Revision 1.5  2009/09/03 23:42:34  mwrsk
 *  Code cleanup
 *
 *  Revision 1.4  2009/09/03 23:39:01  mwrsk
 *  Code cleanup
 *
 *  Revision 1.3  2009/08/27 06:29:18  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.2  2009/08/26 23:57:23  mwrsk
 *  Added a new constructor which takes exception as an argument
 *
 *  Revision 1.1  2009/08/26 21:00:51  mwrsk
 *  Renamed the response class to match the request
 *
 *  Revision 1.1  2009/08/25 01:56:33  mwrsk
 *  Added new API for retrieving DL Inventory Item
 *
*/
