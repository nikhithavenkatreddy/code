/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs;

import gov.ca.dmv.ease.ecs.constants.IEcsConstants;

import java.io.Serializable;

/**
 * Description: Interface to support  timeout-related behavior based on absolute timestamp.
 * File: ITimeoutCapable.java
 * Module: gov.ca.dmv.ease.service
 * Created: Mar 19, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ITimeoutCapable extends IEcsConstants, Serializable {
	/**
	 * Undefined expiration value.
	 */
	long UNDEF_EXPIRATION = ECS_UNDEF_INT;

	/**
	 * Gets the absolute expiration timestamp.represented as long msec time.
	 *
	 * @return the expiration timestamp
	 */
	long getAbsoluteExpirationTimestamp();

	/**
	 * Checks if timed out - that is, if the current time is later than the absolute expiration.
	 *
	 * @return true, if successful
	 */
	boolean hasTimedOut();
}
/**
 *  Modification History:
 *
 *  $Log: ITimeoutCapable.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/14 20:15:14  mwhxb3
 *  refactored the constant DCS_UNDEF_INT to ECS_UNDEF_INT
 *
 *  Revision 1.5  2009/10/14 20:09:46  mwhxb3
 *  changes due to renaming IDcsConstants to IEcsConstants.
 *
 *  Revision 1.4  2009/10/13 17:59:54  mwhxb3
 *  updated comments.
 *
 *  Revision 1.3  2009/07/27 18:36:01  mwpxp2
 *  Adjusted  for renames
 *
 *  Revision 1.2  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.5  2009-05-18 18:32:48  ppalacz
 *  Javadoc update
 *
 *  Revision 1.4  2009-05-18 15:49:17  ppalacz
 *  Javadoc update
 *
 *  Revision 1.3  2009-05-11 19:43:31  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.2  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.1  2009-05-09 07:27:58  mwpxp2
 *  Moved in
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
