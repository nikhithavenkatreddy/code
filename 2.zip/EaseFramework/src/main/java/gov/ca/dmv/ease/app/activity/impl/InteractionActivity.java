/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.activity.ICnaCapable;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessExecutionException;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I represent activity that involves interaction with user
 * File: InteractionActivity.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created:  2009 
 * @author mwsmg6  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class InteractionActivity extends TransientActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(InteractionActivity.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5109757846979319541L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext processContext) {
		if (!processContext.getMessageCollector().hasValidationErrors()) {
			LOGGER.trace("record()");
			processContext.record(this);
		}
	}

	/**
	 * Return list of Actions supported by an Interaction Activity, the available actions are created dynamically.
	 * 
	 * @param processContext the process context
	 * 
	 * @return List of Actions
	 */
	public List <Action> getAvailableActions(ProcessContext processContext) {
		// set flag if interaction activity is cnaEnbled
		boolean isActivityCnaCapable = (processContext.getCurrentActivity() instanceof ICnaCapable);
		List <Action> availableActions = new ArrayList <Action>();
		for (String key : getTransitions().getTransitionKeys()) {
			Action action = getActionsRegistry().getAction(key);
			if (action != null) {
				// If the current interaction activity supports CNA and its action is a "cna" than set the action enable flag 
				// to the return value of the isCnaActionAllowed().
				if (isActivityCnaCapable && action.isCnaBypassAction()) {
					action.setEnabled(((ICnaCapable) processContext
							.getCurrentActivity())
							.isCnaActionAllowed(processContext));
				}
				availableActions.add(action);
			}
		}
		return availableActions;
	}

	/**
	 * Resume, the paused Interaction activity is resumed. Post Conditions are
	 * validated and if there are no errors, the next activity is executed. If 
	 * there are any validation errors the process context is rolled back
	 * 
	 * @param processContext the process context
	 */
	public void resume(ProcessContext processContext) {
		LOGGER.info(processContext.getProcessId() + " is resuming :: " + activityName);
		try {
			Action selectedAction = processContext.getSelectedAction();
			processContext.getRootContext().setRollbackProcessContext(
					processContext);
			setRollbackSubprocessActivity(processContext);
			//Bypass the validations for actions like cancel etc
			if (!selectedAction.isByPassValidations()) {
				postCondition(processContext);
			}
			// if there are already validation errors, we skip execution
			if (!processContext.hasValidationErrors()) {
				processContext.registerSyncPoint(this);
				if (isSavePoint()) {
					createSavePoint(processContext);
				}
				setTransitionKey(selectedAction.getKey());
				LOGGER.debug("Next Activity :: " + getNextActivity().getActivityName());
				getNextActivity().execute(processContext);
			}
			// If there were pre-execute errors, or if errors were collected during execution,
			// we rollback process execution state
			if (processContext.hasValidationErrors()) {
				processContext.rollback(this);
			}
		}
		catch (Exception e) { // catch any unchecked exception that may have occurred
			LOGGER.info(getClass().getSimpleName()
					+ "::resume(ProcessContext) exception", e);
			LOGGER.info(e.getStackTrace());
			// rollback process execution state
			processContext.rollback(this);
			// re-throw to the top-level error handler 
			throw new ProcessExecutionException(e);
		}
	}

	/**
	 * @param processContext
	 */
	private void setRollbackSubprocessActivity(ProcessContext processContext) {
		if (processContext instanceof ChildContext) { 
			ChildContext childContext = (ChildContext) processContext;
			if (!childContext.isMenuProcess()) {
				SubprocessActivity subprocessActivity = (SubprocessActivity) childContext
						.getParentProcessContext().getCurrentActivity();
				processContext.getRootContext().setRollbackSubprocessActivity(
						subprocessActivity);
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: InteractionActivity.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/04/30 16:48:57  mwsec2
 *  adjusted logging levels
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.50  2012/09/12 00:31:20  mwhys
 *  Set setRollbackSubprocessActivity in session context. (Defect 7189)
 *
 *  Revision 1.49  2012/06/01 21:20:52  mwhys
 *  setRollbackProcessContext in resume(). (Session Management)
 *
 *  Revision 1.48  2012/05/08 00:09:32  mwhys
 *  Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 *  Revision 1.47.12.1  2012/02/21 21:15:02  mwsec2
 *  save point support added
 *
 *  Revision 1.47  2011/06/14 13:34:58  mwkkc
 *  Clean up
 *
 *  Revision 1.46  2011/06/10 19:39:08  mwpxp2
 *  Added explicit catch clause for ConcurrentModificationException
 *
 *  Revision 1.45  2011/06/02 22:02:50  mwpxp2
 *  Uses hasValidationErrors on process context; added explicit error logging for the catch clause in resume
 *
 *  Revision 1.44  2011/06/02 20:10:02  mwsyk1
 *  Reverted to version 1.41
 *
 *  Revision 1.41  2010/09/30 18:44:30  mwyxg1
 *  change resume method
 *
 *  Revision 1.40  2010/09/30 03:00:04  mwkkc
 *  Commented out the exception which caused the null pointer exception at end of business process when aspect were enabled.
 *
 *  Revision 1.39  2010/08/27 17:51:50  mwyxg1
 *  change back to ProcessExecutionException
 *
 *  Revision 1.38  2010/08/27 16:06:42  mwyxg1
 *  remove actionable activity
 *
 *  Revision 1.37  2010/08/27 15:43:15  mwyxg1
 *  fix compilation error
 *
 *  Revision 1.36  2010/08/26 23:41:30  mwsec2
 *  Error propagation / rollback fixes
 *
 *  Revision 1.35  2010/08/20 18:29:42  mwpxp2
 *  Added fixmes;bulk formatted
 *
 *  Revision 1.34  2010/08/19 18:52:41  mwsec2
 *  try/catch added to resume method
 *
 *  Revision 1.33  2010/08/03 21:20:06  mwsec2
 *  syncPoint enhancements
 *
 *  Revision 1.32  2010/07/30 22:44:56  mwakg
 *  Activities now register syncpoint activity and the processContext
 *
 *  Revision 1.31  2010/07/30 20:15:53  mwakg
 *  Merged from Fallback_branch
 *
 *  Revision 1.30  2010/07/29 14:51:19  mwakg
 *  Added support for Cna. Merged code from Mike Seatris
 *
 *  Revision 1.29  2010/05/18 16:23:31  mwakg
 *  Bypassing the validation if user selects cancel actionmvall15
 *
 *  Revision 1.28  2010/05/09 18:11:19  mwakg
 *  Moved postCondition to sub classes
 *
 *  Revision 1.27  2010/05/04 20:44:10  mwakg
 *  Changed the logic of using postCondition in InteractionActivity
 *
 *  Revision 1.26  2010/05/04 18:12:45  mwakg
 *  Fixed fix me
 *
 *  Revision 1.25  2010/05/02 23:12:44  mwcsj3
 *  Added a condition to check errors before proceeding in resume method
 *
 *  Revision 1.24  2010/04/29 17:55:01  mwcsj3
 *  Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 *  Revision 1.23  2010/04/27 20:58:19  mwcsj3
 *  Added postValidate method call in resume method
 *
 *  Revision 1.22  2010/04/22 22:27:25  mwcsj3
 *  Fixed FIX ME
 *
 *  Revision 1.21  2010/04/22 19:08:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.20  2010/04/14 15:38:59  mwakg
 *  Made activities authorizedExecute protected
 *
 *  Revision 1.19  2010/04/13 23:24:19  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.18  2010/04/09 01:08:33  mwcsj3
 *  Removed collectData() method
 *
 *  Revision 1.17  2010/04/08 23:46:27  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.16  2010/04/08 01:27:13  mwcsj3
 *  Changed executeAction to executeAuthorized
 *
 *  Revision 1.15  2010/04/07 22:19:16  mwcsj3
 *  Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 *  Revision 1.14  2010/04/05 00:31:46  mwakg
 *  Fixed injection issue
 *
 *  Revision 1.13  2010/04/04 23:08:18  mwakg
 *  Cleaned InteractionActivity class
 *
 *  Revision 1.11  2010/04/04 22:46:29  mwakg
 *  Fixed injection and getting actionsRegistry from superclass
 *
 *  Revision 1.10  2010/03/29 20:33:52  mwcsj3
 *  Commented actionsRegistry injection into InteractionActivity
 *
 *  Revision 1.9  2010/03/27 01:36:15  mwakg
 *  Injected actionsRegistry into InteractionActivity
 *
 *  Revision 1.8  2010/03/25 17:35:16  mwbxp5
 *  Deprecated collectData, Please use preValidate() instead:
 *
 *  Revision 1.7  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.6  2010/03/21 00:08:06  mwakg
 *  Getting actions from ActionsRegistry
 *
 *  Revision 1.5  2010/03/18 17:00:37  mwakg
 *  Removed instances of action classes and using generic Action class
 *
 *  Revision 1.4  2010/03/17 22:59:27  mwyxg1
 *  Add Cda Buttons.
 *
 *  Revision 1.3  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.2.2.6  2010/03/10 00:25:47  mwcsj3
 *  Changed the method call from resume() --> executeAuthorized() in executeAction() method
 *
 *  Revision 1.2.2.5  2010/03/03 18:14:28  mwcsj3
 *  Modified executeAction() method to accommodate multiple transitions functionality
 *
 *  Revision 1.2.2.4  2010/02/26 23:58:49  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.2.2.3  2010/02/26 19:40:05  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.2.2.2  2010/02/26 17:37:50  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.2.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.2  2010/02/11 19:57:28  mwpxp2
 *  Javadoc cleanup; todos added
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/07 19:16:21  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:57:17  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.37  2009/10/03 20:01:55  mwpxp2
 *  Added class comment, javadoc
 *
 *  Revision 1.36  2009/09/22 23:58:35  mwsmg6
 *  cleanup
 *
 *  Revision 1.35  2009/09/16 00:10:43  mwyxg1
 *  Remove code in resume
 *
 *  Revision 1.34  2009/09/15 18:19:54  mwsxv5
 *  Updated resume method to fix Restart problem
 *
 *  Revision 1.33  2009/09/03 04:12:19  mwjjl7
 *  refactor for action handling specification
 *
 *  Revision 1.32  2009/09/03 00:54:39  mwsmg6
 *  refactoring ations
 *
 *  Revision 1.31  2009/09/02 21:18:53  mwyxg1
 *  Added PRINT ALL Button
 *
 *  Revision 1.30  2009/09/02 20:51:31  mwsmg6
 *  refactoring prepareResponse
 *
 *  Revision 1.29  2009/09/02 20:44:14  mwsmg6
 *  refactoring prepareResponse
 *
 *  Revision 1.28  2009/09/02 18:59:33  mwsmg6
 *  refactoring prepareResponse
 *
 *  Revision 1.27  2009/09/02 18:44:00  mwsmg6
 *  refactoring prepareResponse
 *
 *  Revision 1.26  2009/09/02 16:44:07  mwyxg1
 *  Added DATA BASE STATUS Button, used for dcs inquiry.
 *
 *  Revision 1.25  2009/09/02 16:23:19  mwyxg1
 *  Added Another Inquiry Button, used for court inquiry.
 *
 *  Revision 1.24  2009/08/28 04:31:36  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.23  2009/08/28 04:08:16  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.22  2009/08/27 20:58:19  mwsmg6
 *  corrected method name
 *
 *  Revision 1.21  2009/08/27 18:45:24  mwsmg6
 *  removed dead code
 *
 *  Revision 1.20  2009/08/27 08:25:00  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.19  2009/08/26 01:54:32  mwakg
 *  Sending action as null if there is no action text
 *
 *  Revision 1.18  2009/08/25 22:20:55  mwakg
 *  added other actions
 *
 *  Revision 1.17  2009/08/20 16:54:33  mwsmg6
 *  enhanced logging of various activities
 *
 *  Revision 1.16  2009/08/20 16:12:42  mwsmg6
 *  provided more detailed logging of activities
 *
 *  Revision 1.15  2009/08/19 22:43:29  mwsmg6
 *  corrected class hierarchy and resulting inherited methods
 *
 *  Revision 1.14  2009/08/18 18:44:13  mwakg
 *  Fixed compilation issue
 *
 *  Revision 1.13  2009/08/16 21:51:33  mwakg
 *  Setting the next activity to current executing activity if there are any validation errors
 *
 *  Revision 1.12  2009/08/11 23:26:59  mwjjl7
 *  refactor for botton handling
 *
 *  Revision 1.11  2009/08/11 21:27:55  mwpxm2
 *  Added continue button.
 *
 *  Revision 1.10  2009/08/11 17:49:04  mwpxm2
 *  Changed isContinueAllowed to true by default.
 *
 *  Revision 1.9  2009/08/11 16:45:38  mwjjl7
 *  add base available logic
 *
 *  Revision 1.8  2009/08/10 23:30:09  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
