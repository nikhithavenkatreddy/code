/**
 *
 */
package gov.ca.dmv.ease.fw.error.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.IErrorCollectorEntry;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am concrete implementation of IErrorCollector
 * File: ErrorCollector.java
 * Module:  gov.ca.dmv.ease.fw.error.impl
 * Created: Jul 30, 2009
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ErrorCollector implements IErrorCollector {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2871551714970281033L;

	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/** The entries. */
	private List <IErrorCollectorEntry> entries;

	/**
	 * Instantiates a new error collector.
	 */
	public ErrorCollector() {
		super();
	}

	/**
	 * Instantiates a new error collector.
	 *
	 * @param e
	 */
	public ErrorCollector(Exception e) {
		super();
		register(e);
	}

	/**
	 * Adds new entries to the current entries.
	 *
	 * @param aList the new entries
	 */
	public void addEntries(List <IErrorCollectorEntry> aList) {
		if (EaseUtil.isNotNull(aList)) {
			getEntries().addAll(aList);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#addEntriesFrom(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void addEntriesFrom(IErrorCollector anotherCollector) {
		if (anotherCollector != null) {
			addEntries(anotherCollector.getEntries());
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ErrorCollector other = (ErrorCollector) obj;
		if (entries == null) {
			if (other.getEntries() != null) {
				return false;
			}
		}
		else if (!entries.equals(other.getEntries())) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#getEntries()
	 */
	public List <IErrorCollectorEntry> getEntries() {
		if (entries == null) {
			setEntries(new ArrayList <IErrorCollectorEntry>());
		}
		return entries;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasEaseExceptionOfClass(java.lang.Class)
	 */
	public boolean hasEaseExceptionOfClass(
			Class <? extends EaseException> anExceptionClass) {
		if (hasErrors()) {
			for (IErrorCollectorEntry anEntry : getEntries()) {
				if (anEntry.hasEaseExceptionOfClass(anExceptionClass)) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}

	public boolean hasEntryWithMessageIncluding(String aMessage) {
		if (isEmpty()) {
			return false;
		}
		else {
			for (IErrorCollectorEntry anEntry : getEntries()) {
				if (anEntry.hasMessageIncluding(aMessage)) {
					return true;
				}
			}
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#hasErrors()
	 */
	public boolean hasErrors() {
		return !isEmpty();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionMessage(java.lang.String)
	 */
	public boolean hasExceptionMessage(String aMessage) {
		if (hasErrors()) {
			for (IErrorCollectorEntry anEntry : getEntries()) {
				if (anEntry.hasExceptionMessage(aMessage)) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionMessageContaining(java.lang.String)
	 */
	public boolean hasExceptionMessageContaining(String aMessage) {
		if (hasErrors()) {
			for (IErrorCollectorEntry anEntry : getEntries()) {
				if (anEntry.hasExceptionMessageContaining(aMessage)) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionOfClass(java.lang.Class)
	 */
	public boolean hasExceptionOfClass(
			Class <? extends Exception> anExceptionClass) {
		if (hasErrors()) {
			for (IErrorCollectorEntry anEntry : getEntries()) {
				if (anEntry.hasExceptionOfClass(anExceptionClass)) {
					return true;
				}
			}
			return false;
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entries == null) ? 0 : entries.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#isEmpty()
	 */
	public boolean isEmpty() {
		return entries == null || entries.isEmpty();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#register(java.lang.Throwable)
	 */
	public void register(Throwable e) {
		getEntries().add(new ErrorCollectorEntry(e));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#register(java.lang.Throwable, java.lang.String[])
	 */
	public void register(Throwable e, String[] messageParameters) {
		getEntries().add(new ErrorCollectorEntry(e, messageParameters));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollector#register(java.lang.Throwable, java.lang.String[], java.lang.String)
	 */
	public void register(Throwable e, String[] messageParameters,
			String errorFieldToFocus) {
		getEntries()
				.add(
						new ErrorCollectorEntry(e, messageParameters,
								errorFieldToFocus));
	}

	/**
	 * Sets the entries.
	 *
	 * @param aList the new entries
	 */
	protected void setEntries(List <IErrorCollectorEntry> aList) {
		entries = aList;
	}

	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(2048);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append("...").append(e.getMessage()).append("...").append(
					"]");
			return aBuilder.toString();
		}
	}

	/**
	 * To string on.
	 *
	 * @param aBuilder the a builder
	 * @param anIndent the an indent
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("entries", entries, anIndent, aBuilder);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ErrorCollector.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.18  2011/02/04 01:20:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.17  2011/01/21 03:10:22  mwpxp2
 *  Compilation fix; cleanup
 *
 *  Revision 1.16  2011/01/21 02:57:20  mwpxp2
 *  Added hasEntryWithMessageIncluding/1
 *
 *  Revision 1.15  2011/01/20 03:47:11  mwpxp2
 *  Added addEntriesFrom another collector
 *
 *  Revision 1.14  2010/12/12 08:26:21  mwpxp2
 *  Modified toString/0 formatting
 *
 *  Revision 1.13  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.12  2010/12/02 00:14:58  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.11  2010/10/12 23:33:01  mwkfh
 *  updated addEntries to not add to null entries
 *
 *  Revision 1.10  2010/10/12 21:10:19  mwkfh
 *  added addEntries(List)
 *
 *  Revision 1.9  2010/10/12 18:32:28  mwpxp2
 *  Implemented IErrorCollectorQuery
 *
 *  Revision 1.8  2010/09/29 20:27:39  mwtjc1
 *  Object[] parameters is replaced with String[] messageParameters
 *
 *  Revision 1.7  2010/09/28 18:06:12  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.6  2010/09/01 19:03:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/08/27 23:03:38  mwhys
 *  Added equals(Object) method.
 *
 *  Revision 1.4  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.3  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.22.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/01 18:58:04  mwpxp2
 *  Added convenience constructor on exception with registration
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/23 17:10:45  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.1  2009/10/03 20:17:07  mwpxp2
 *  Moved to fw.error.impl ; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/26 22:57:12  mwpxp2
 *  Modified to register Throwable
 *
 *  Revision 1.3  2009/08/26 22:33:06  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.2  2009/08/03 22:57:58  mwpxp2
 *  Unit tested
 *
 *  Revision 1.1  2009/07/30 21:40:05  mwpxp2
 *  Initial
 *
 */
