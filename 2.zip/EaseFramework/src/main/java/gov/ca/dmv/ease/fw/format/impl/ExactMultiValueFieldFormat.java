/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;
import gov.ca.dmv.ease.fw.format.reader.IFormatReaderConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am message format that allows only specific concrete string values
 * File: ExactMultiValueFieldFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ExactMultiValueFieldFormat extends FieldFormat {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8502417056206457001L;

	/**
	 * As array.
	 * 
	 * @param aValueList 
	 * 
	 * @return the string[]
	 */
	private static String[] asArray(List <String> aValueList) {
		if (aValueList == null) {
			return new String[] {};
		}
		int aSize = aValueList.size();
		if (aSize == 0) {
			return new String[] {};
		}
		String[] anArr = new String[aSize];
		for (int i = 0; i < aSize; i++) {
			anArr[i] = aValueList.get(i);
		}
		return anArr;
	}

	/**
	 * Gets the max length from.
	 * 
	 * @param valueList 
	 * 
	 * @return the max length from
	 */
	private static int getMaxLengthFrom(List <String> valueList) {
		return getMaxLengthFrom(asArray(valueList));
	}

	/**
	 * Gets the max length from.
	 * 
	 * @param valueArr 
	 * 
	 * @return the max length from
	 */
	protected static int getMaxLengthFrom(String[] valueArr) {
		int max = 0;
		int len = 0;
		for (String element : valueArr) {
			len = element.length();
			max = Math.max(max, len);
		}
		return max;
	}

	/**
	 * Prints the on.
	 * 
	 * @param aStringArr 
	 * @param aBuilder 
	 */
	private static void printOn(String[] aStringArr, StringBuilder aBuilder) {
		aBuilder.append(IFormatReaderConstants.OPTIONS_START);
		if (aStringArr != null) {
			boolean first = true;
			for (String element : aStringArr) {
				if (first) {
					first = false;
				}
				else {
					aBuilder.append(IFormatReaderConstants.OR);
				}
				aBuilder.append('\"').append(element).append('\"');
			}
		}
		aBuilder.append(IFormatReaderConstants.OPTIONS_END);
	}

	/** The allowed values. */
	private String[] allowedValues;

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param start 
	 * @param arrayList 
	 * @param name 
	 */
	public ExactMultiValueFieldFormat(int start, ArrayList <String> arrayList,
			String aName) {
		super(UNDEF_POS, getMaxLengthFrom(arrayList));
		setAllowedValuesFrom(arrayList);
		setFieldName(aName);
	}

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param startPos 
	 * @param len 
	 * @param aValueArr 
	 */
	public ExactMultiValueFieldFormat(int startPos, int len,
			String... aValueArr) {
		super(startPos, len);
		setAllowedValues(aValueArr);
	}

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param startPos 
	 * @param aValueList 
	 */
	public ExactMultiValueFieldFormat(int startPos, List <String> aValueList) {
		super(startPos, getMaxLengthFrom(aValueList));
		setAllowedValuesFrom(aValueList);
	}

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param startPos 
	 * @param aValueList 
	 * @param aName 
	 */
	public ExactMultiValueFieldFormat(int startPos, List <String> aValueList,
			String aName) {
		super(startPos, getMaxLengthFrom(aValueList));
		setAllowedValuesFrom(aValueList);
		setFieldName(aName);
	}

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param startPos 
	 * @param aValueArr 
	 */
	public ExactMultiValueFieldFormat(int startPos, String... aValueArr) {
		super(startPos, getMaxLengthFrom(aValueArr));
		setAllowedValues(aValueArr);
	}

	public ExactMultiValueFieldFormat(List <String> allowedSet) {
		super(UNDEF_POS, getMaxLengthFrom(allowedSet));
		setAllowedValuesFrom(allowedSet);
	}

	/**
	 * Instantiates a new exact multi value field format.
	 * 
	 * @param allowedSet 
	 */
	public ExactMultiValueFieldFormat(String[] allowedSet) {
		super(UNDEF_POS, getMaxLengthFrom(allowedSet));
		setAllowedValues(allowedSet);
	}

	/**
	 * 
	 * 
	 * @return the allowedValues
	 */
	public String[] getAllowedValues() {
		return allowedValues;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.impl.FieldFormat#getLength()
	 */
	@Override
	public int getLength() {
		if (getAllowedValues() == null) {
			return 0;
		}
		else {
			return getMaxLengthFrom(allowedValues);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample(int)
	 */
	public String getRandomCorrectSample(int nextRandom) {
		if (getAllowedValues() != null) {
			int aSize = getAllowedValues().length;
			if (aSize != 0) {
				int index = nextRandom % aSize;
				return getAllowedValues()[index];
			}
		}
		throw new EaseValidationException(
				"No valid allowed values provided in " + this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample(int)
	 */
	public String getRandomIncorrectSample(int nextRandom) {
		return PRODUCER
				.createStringNotEqualTo(getRandomCorrectSample(nextRandom));
	}

	/**
	 * Checks if is valid value.
	 * 
	 * @param aValue 
	 * 
	 * @return true, if is valid value
	 */
	private boolean isValidValue(String aValue) {
		if (allowedValues == null || allowedValues.length == 0) {
			return false;
		}
		for (String allowedValue : allowedValues) {
			if (allowedValue.equals(aValue)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * 
	 * @param anArr 
	 */
	protected void setAllowedValues(String[] anArr) {
		allowedValues = anArr;
	}

	/**
	 * Sets the allowed values from.
	 * 
	 * @param valueList the new allowed values from
	 */
	private void setAllowedValuesFrom(List <String> valueList) {
		setAllowedValues(asArray(valueList));
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append(getStartPos()).append(',');
		aBuilder.append(getLength()).append(',');
		printOn(getAllowedValues(), aBuilder);
		if (getFieldName() != null) {
			aBuilder.append(", \"").append(getFieldName()).append('\"');
		}
		aBuilder.append(']');
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.impl.FieldFormat#validate(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validate(String aField, IErrorCollector aCollector) {
		if (!isValidValue(aField)) {
			aCollector.register(new FormatValidationException(
					"Not an allowed value: \"" + aField + "\""));
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ExactMultiValueFieldFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2010/12/16 03:18:28  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.10  2010/12/14 02:46:02  mwpxp2
 *  Cleanup
 *
 *  Revision 1.9  2010/12/01 02:48:14  mwpxp2
 *  Added constructor for field name
 *
 *  Revision 1.8  2010/12/01 01:51:34  mwpxp2
 *  Adjusted refs to sample producer
 *
 *  Revision 1.7  2010/12/01 01:38:50  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.6  2010/12/01 01:37:12  mwpxp2
 *  Adjusted refs to IFormatReaderConstants
 *
 *  Revision 1.5  2010/12/01 01:22:50  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.4  2010/11/29 07:43:21  mwpxp2
 *  Modified toString/0
 *
 *  Revision 1.3  2010/11/25 02:01:26  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2010/11/25 00:52:58  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.1  2010/11/24 20:39:43  mwpxp2
 *  Initial
 *
 */
