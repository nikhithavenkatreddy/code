/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.context.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.activity.IActivity;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.InclusionSubprocessActivity;
import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessLoader;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessage;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am implementation of process context and I keep track of
 * change events, current service request, next activity and selected action.
 * TODO - activity instance vars are typed as IAactivity, but arguments in setters are types as Activity
 * 
 * File: ProcessContext.java 
 * Module: gov.ca.dmv.ease.app.process 
 * Created: Jul 25, 2009
 * @author MWCSJ3
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ 
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class ProcessContext extends IntrospectiveContext implements
		IProcessContext, ITreePrintable, Serializable {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(ProcessContext.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8958077438989910565L;
	
	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}
	
	/** Managers password. */
	private String authorizingPassword;
	/** The manager user id. */
	private String authorizingUserId;
	/** The current activity. */
	protected IActivity currentActivity;
	/** The current interaction activity. */
	private IActivity currentInteractionActivity;
	/** fee waiver authorizing password.*/
	private String feeWaiverAuthorizingPassword;
	/** fee waiver authorizing user.*/
	private String feeWaiverAuthorizingUserId;
	/** Holds the Instance of Message Object *. */
	private ErrorMessageCollector messageCollector = new ErrorMessageCollector(); //TODO remove eager instantiation
	/** The next activity. */
	private IActivity nextActivity;
	/** The previous interaction activity. */
	private IActivity previousInteractionActivity;
	/** The print job id. */
	private String printJobId;
	/** The process id. */
	private String processId;
	/** fee process net authorizing password. */
	private String processNetAuthorizingPassword;
	/** fee process net authorizing user. */
	private String processNetAuthorizingUserId;
	/** Process Registry. */
	private transient IProcessRegistry processRegistry;
	/** Holds the selected action *. */
	private Action selectedAction = null;
	/** The transaction type registry. */
	private transient ITransactionTypeRegistry transactionTypeRegistry;
	/** The Work Type selection menu whether the DL / VR etc... */
	private String workType;
	/** The is alternative printer requested. */
	private boolean isAlternativePrinterRequested;
	/** The requested time. */
	private Date requestedTime;
	
	/**
	 * Is ExecutionSyncPointContext Exist.
	 */
	public boolean doesExecutionSyncPointContextExist() {
		return getExecutionSyncPointContext() != null;
	}
	
	/**
	 * @return the requestedTime
	 */
	public Date getRequestedTime() {
		return requestedTime;
	}
	
	/**
	 * @param requestedTime the requestedTime to set
	 */
	public void setRequestedTime(Date requestedTime) {
		this.requestedTime = requestedTime;
	}
	
	/**
	 * @return the isAlternativePrinterRequested
	 */
	public boolean isAlternativePrinterRequested() {
		return isAlternativePrinterRequested;
	}
	
	/**
	 * @param isAlternativePrinterRequested the isAlternativePrinterRequested to set
	 */
	public void setAlternativePrinterRequested(
			boolean isAlternativePrinterRequested) {
		this.isAlternativePrinterRequested = isAlternativePrinterRequested;
	}
	
	/**
	 * Gets the parent.
	 * 
	 * @return the parent
	 */
	public boolean canHaveParentContext() {
		return false;
	}
	
	/**
	 * Clears all execution sync points from the session.
	 */
	public void clearExecutionSyncPoints() {
		getRootContext().getExecutionSyncPoints().clear();
	}
	
	/**
	 * Contains error.
	 *
	 * @param errorCode the error code
	 * @return true, if successful
	 */
	public boolean containsError(String errorCode) {
		if (messageCollector != null) {
			return messageCollector.containsError(errorCode);
		}
		else {
			return false;
		}
	}
	
	/**
	 * End.
	 */
	public abstract void end();
	
	/**
	 * Gets the authorizingPassword.
	 *
	 * @return the authorizingPassword
	 */
	public String getAuthorizingPassword() {
		return authorizingPassword;
	}
	
	/**
	 * Gets the authorizingUserId.
	 *
	 * @return the authorizingUserId
	 */
	public String getAuthorizingUserId() {
		return authorizingUserId;
	}
	
	/**
	 * Gets the current activity.
	 * 
	 * @return the current activity
	 */
	public Activity getCurrentActivity() {
		return (Activity) currentActivity; //FIXME why the cast?
	}
	
	/**
	 * Gets the current interaction activity.
	 * 
	 * @return the currentInteractionActivity
	 */
	public InteractionActivity getCurrentInteractionActivity() {
		return (InteractionActivity) currentInteractionActivity; //FIXME why the cast?
	}
	
	/**
	 * Gets the execution sync point.
	 *
	 * @return the executionSyncPoint
	 */
	private ExecutionSyncPoint getExecutionSyncPoint() {
		Stack <ExecutionSyncPoint> stack = getRootContext()
				.getExecutionSyncPoints();
		ExecutionSyncPoint syncPoint = null;
		if (!stack.isEmpty()) {
			syncPoint = stack.peek();
			if (syncPoint.getExecutionSyncPointActivity().equals(
					getCurrentActivity())) {
				stack.pop();
				if (!stack.isEmpty()) {
					syncPoint = stack.peek();
				}
			}
		}
		return syncPoint;
	}
	
	/**
	 * Gets the execution sync point activity.
	 *
	 * @return the executionSyncPoint
	 */
	public Activity getExecutionSyncPointActivity() {
		ExecutionSyncPoint syncPoint = getExecutionSyncPoint();
		Activity activity = null;
		if (syncPoint != null) {
			activity = syncPoint.getExecutionSyncPointActivity();
		}
		return activity;
	}
	
	/**
	 * Gets the execution sync point context.
	 *
	 * @return the executionSyncPointContext
	 */
	public ProcessContext getExecutionSyncPointContext() {
		ExecutionSyncPoint syncPoint = getExecutionSyncPoint();
		ProcessContext context = null;
		if (syncPoint != null) {
			context = syncPoint.getExecutionSyncPointContext();
		}
		return context;
	}
	
	/**
	 * Gets the fee waiver authorizing password.
	 *
	 * @return the feeWaiverAuthorizingPassword
	 */
	public String getFeeWaiverAuthorizingPassword() {
		return feeWaiverAuthorizingPassword;
	}
	
	/**
	 * Gets the fee waiver authorizing user id.
	 *
	 * @return the feeWaiverAuthorizingUserId
	 */
	public String getFeeWaiverAuthorizingUserId() {
		return feeWaiverAuthorizingUserId;
	}
	
	/**
	 * Gets the Validation Messages as Message Object <code>MessageObject</code>
	 * .
	 * 
	 * @return the validationMessageObject
	 */
	public ErrorMessageCollector getMessageCollector() {
		if (messageCollector == null) {
			messageCollector = new ErrorMessageCollector();
		}
		return messageCollector;
	}
	
	/**
	 * Gets the next activity to be executed by the business process.
	 * 
	 * @return Next activity to execute
	 */
	public Activity getNextActivity() {
		return (Activity) nextActivity; //FIXME why the cast?
	}
	
	/**
	 * Gets the previous interaction activity.
	 * 
	 * @return the previousInteractionActivity
	 */
	public Activity getPreviousInteractionActivity() {
		return (Activity) previousInteractionActivity; //FIXME why the cast?
	}
	
	/**
	 * Gets the printJobId.
	 *
	 * @return the printJobId
	 */
	public String getPrintJobId() {
		return printJobId;
	}
	
	/**
	 * Gets the current business process ID for this context.
	 * 
	 * @return Business Process ID
	 */
	public String getProcessId() {
		return processId;
	}
	
	/**
	 * Gets the process net authorizing password.
	 *
	 * @return the processNetAuthorizingPassword
	 */
	public String getProcessNetAuthorizingPassword() {
		return processNetAuthorizingPassword;
	}
	
	/**
	 * Gets the process net authorizing user id.
	 *
	 * @return the processNetAuthorizingUserId
	 */
	public String getProcessNetAuthorizingUserId() {
		return processNetAuthorizingUserId;
	}
	
	/**
	 * Gets the process registry.
	 * 
	 * @return the processRegistry
	 */
	public IProcessRegistry getProcessRegistry() {
		return processRegistry;
	}
	
	/**
	 * Gets the root context.
	 * 
	 * @return the root context
	 */
	public abstract SessionContext getRootContext();
	
	/**
	 * Gets the selected action.
	 * 
	 * @return the selectedAction
	 */
	public Action getSelectedAction() {
		return selectedAction;
	}
	
	/**
	 * Gets the TransactionType registry.
	 *
	 * @return the transaction type registry
	 */
	public ITransactionTypeRegistry getTransactionTypeRegistry() {
		return transactionTypeRegistry;
	}
	
	/**
	 * Gets the user context object in the process context.
	 * 
	 * @return user context object
	 */
	public IUserContext getUserContext() {
		IUserContext userContext = getRootContext().getUserContext();
		return userContext;
	}
	
	/**
	 * Gets the validation messages.
	 * 
	 * @return the validation messages
	 */
	public Map <String, ErrorMessage> getValidationMessages() {
		if (messageCollector == null) {
			return new HashMap <String, ErrorMessage>();
		}
		else {
			return messageCollector.getValidationMessages();
		}
	}
	
	/**
	 * Gets the work type menu option.
	 * 
	 * @return the workTypeMenu
	 */
	public String getWorkType() {
		return workType;
	}
	
	/**
	 * Checks for validation errors.
	 * 
	 * @return true, if successful
	 */
	public boolean hasValidationErrors() {
		if (messageCollector == null) {
			return false;
		}
		else {
			return messageCollector.hasValidationErrors();
		}
		//return getMessageCollector().hasValidationErrors();
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IProcessContext#isSameProcess(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public boolean isSameProcess(ProcessContext other) {
		return getClass().equals(other.getClass());
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.bo.logging.syslog.ILoggable#outputAppLog(java.lang.
	 * StringBuffer)
	 */
	/**
	 * Output app log.
	 * 
	 * @param aStringBuffer the a string buffer
	 */
	public void outputAppLog(StringBuffer aStringBuffer) {
		Map <String, ErrorMessage> errors = getMessageCollector()
				.getValidationMessages();
		for (String errorKey : errors.keySet()) {
			String errorMessage = errors.get(errorKey).getErrorText();
			aStringBuffer.append(errorMessage + ";");
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bo.logging.audit.IAuditable#outputAuditLog(java.lang.
	 * StringBuffer)
	 */
	public void outputAuditLog(StringBuilder aBuilder) {
		aBuilder.append("ProcessContext(");
		aBuilder.append("processId:");
		aBuilder.append(processId);
		aBuilder.append(";selectedAction:");
		if (selectedAction != null) {
			aBuilder.append(selectedAction.getName());
		}
		aBuilder.append(";nextActivity:");
		if (nextActivity != null) {
			aBuilder.append(((Activity) nextActivity).getActivityName()
					+ ") -- ");
		}
		else {
			aBuilder.append("None" + ") -- ");
		}
		((UserContext) getUserContext()).outputAuditLog(aBuilder);
	}
	
	/**
	 * Record.
	 * 
	 * @param activity the activity
	 */
	public void record(InteractionActivity activity) {
		LOGGER
				.trace("Previous Interaction Activity and Current Interaction Activity");
		setPreviousInteractionActivity(getCurrentInteractionActivity());
		setCurrentInteractionActivity(activity);
	}
	
	/**
	 * Register sync point.
	 *
	 * @param activity the activity
	 */
	public void registerSyncPoint(Activity activity) {
		if (activity.isSyncPoint()) {
			setExecutionSyncPoint(activity);
		}
	}
	
	/**
	 * Reset error message collector.
	 *
	 * @return the error message collector
	 */
	public ErrorMessageCollector resetErrorMessageCollector() {
		ErrorMessageCollector old = messageCollector;
		messageCollector = null;
		return old;
	}
	
	/**
	 * Used during session management to restore the current process context
	 * with the saved session data.
	 */
	public void restore() {
		ProcessContext restoredProcessContext = this;
		String businessProcessId = restoredProcessContext.getProcessId();
		ProcessLoader processLoader = EaseApplicationContext.getProcessLoader();
		BusinessProcess businessProcess = processLoader.getProcessRegistry()
				.getProcess(businessProcessId);
		String currentActivityName = null;
		String currentInteractionActivityName = null;
		String nextActivityName = null;
		String previousInteractionActivityName = null;
		if (isNotNull(currentActivity)) {
			currentActivityName = ((Activity) currentActivity)
					.getActivityName();
		}
		if (isNotNull(currentInteractionActivity)) {
			currentInteractionActivityName = ((Activity) currentInteractionActivity)
					.getActivityName();
		}
		if (isNotNull(nextActivity)) {
			nextActivityName = ((Activity) nextActivity).getActivityName();
		}
		if (isNotNull(previousInteractionActivity)) {
			previousInteractionActivityName = ((Activity) previousInteractionActivity)
					.getActivityName();
		}
		ProcessContext newProcessContext = businessProcess.getProcessContext();
		// Current Activity
		Activity originalCurrentActivity = processLoader.getActivityReference(
				businessProcessId, currentActivityName);
		restoredProcessContext.setCurrentActivity(originalCurrentActivity);
		// Current Interaction Activity
		if (isNotNull(originalCurrentActivity)
				&& originalCurrentActivity instanceof InteractionActivity) {
			restoredProcessContext
					.setCurrentInteractionActivity((InteractionActivity) originalCurrentActivity);
		}
		else if (isNotNull(currentInteractionActivityName)) {
			Activity originalCurrentInteractionActivity = processLoader
					.getActivityReference(businessProcessId,
							currentInteractionActivityName);
			restoredProcessContext
					.setCurrentInteractionActivity((InteractionActivity) originalCurrentInteractionActivity);
		}
		// Next Activity
		Activity originalNextActivity = processLoader.getActivityReference(
				businessProcessId, nextActivityName);
		restoredProcessContext.setNextActivity(originalNextActivity);
		// Previous Interaction Activity
		Activity originalPreviousInteractionActivity = processLoader
				.getActivityReference(businessProcessId,
						previousInteractionActivityName);
		restoredProcessContext
				.setPreviousInteractionActivity(originalPreviousInteractionActivity);
		restoredProcessContext.setProcessRegistry(newProcessContext
				.getProcessRegistry());
		restoredProcessContext.setTransactionTypeRegistry(newProcessContext
				.getTransactionTypeRegistry());
	}
	
	/**
	 * This method is called to resume the interaction activity that is stopped
	 * to accept user information/inputs or to resume a InclusionSubprocessActivity.
	 *
	 * @param aProcessContext ProcessContext from which this context is resumed
	 */
	// TODO break this into two separate methods 
	public void resume(ProcessContext aProcessContext) {
		Activity currentActivity = getCurrentActivity();
		LOGGER.trace("Resuming activity : " + currentActivity.getActivityName());
		if (currentActivity instanceof InclusionSubprocessActivity) {
			((InclusionSubprocessActivity) currentActivity).resume(this,
					aProcessContext);
		}
		else {
			getCurrentInteractionActivity().resume(this);
		}
	}
	
	/**
	 * This method is used to rollback the business process to previous interaction activity.
	 * 
	 * @param activity the activity of the business process to which it has to rolled back
	 */
	public void rollback(InteractionActivity activity) {
		setCurrentActivity(activity);
		setCurrentInteractionActivity(activity);
		getRootContext().setCurrentProcessContext(this);
		String activityName = null;
		if (activity != null) {
			activityName = activity.getActivityName();
		}
		LOGGER.info("Executed rollback to :: " + activityName + " in "
				+ getProcessId());
	}
	
	/**
	 * Sets the authorizingPassword.
	 *
	 * @param authorizingPassword the authorizingPassword to set
	 */
	public void setAuthorizingPassword(String authorizingPassword) {
		this.authorizingPassword = authorizingPassword;
	}
	
	/**
	 * Sets the authorizingUserId.
	 *
	 * @param authorizingUserId the authorizingUserId to set
	 */
	public void setAuthorizingUserId(String authorizingUserId) {
		this.authorizingUserId = authorizingUserId;
	}
	
	/**
	 * Sets the current activity.
	 *
	 * @param anActivity the new current activity
	 */
	public void setCurrentActivity(Activity anActivity) {
		currentActivity = anActivity;
		if (anActivity != null) {
			LOGGER.trace(anActivity.getActivityName());
		}
	}
	
	/**
	 * Sets the current interaction activity.
	 *
	 * @param anActivity the new current interaction activity
	 */
	public void setCurrentInteractionActivity(InteractionActivity anActivity) {
		currentInteractionActivity = anActivity;
		if (anActivity != null) {
			LOGGER.trace(anActivity.getActivityName());
		}
	}
	
	/**
	 * Sets the execution sync point.
	 *
	 * @param executionSyncPointActivity the new execution sync point
	 */
	private void setExecutionSyncPoint(Activity executionSyncPointActivity) {
		Stack <ExecutionSyncPoint> stack = getRootContext()
				.getExecutionSyncPoints();
		Activity topFallbackActivity = null;
		if (!stack.isEmpty()) {
			topFallbackActivity = stack.peek().getExecutionSyncPointActivity();
		}
		if (!executionSyncPointActivity.equals(topFallbackActivity)) {
			ExecutionSyncPoint syncPoint = new ExecutionSyncPoint(
					executionSyncPointActivity, this);
			stack.push(syncPoint);
		}
		LOGGER.debug("Execution sync point stack: " + stack);
	}
	
	/**
	 * Sets the fee waiver authorizing password.
	 *
	 * @param feeWaiverAuthorizingPassword the feeWaiverAuthorizingPassword to set
	 */
	public void setFeeWaiverAuthorizingPassword(
			String feeWaiverAuthorizingPassword) {
		this.feeWaiverAuthorizingPassword = feeWaiverAuthorizingPassword;
	}
	
	/**
	 * Sets the fee waiver authorizing user id.
	 *
	 * @param feeWaiverAuthorizingUserId the feeWaiverAuthorizingUserId to set
	 */
	public void setFeeWaiverAuthorizingUserId(String feeWaiverAuthorizingUserId) {
		this.feeWaiverAuthorizingUserId = feeWaiverAuthorizingUserId;
	}
	
	/**
	 * Sets the next activity for the process.
	 *
	 * @param anActivity the new next activity
	 */
	public void setNextActivity(Activity anActivity) {
		nextActivity = anActivity;
	}
	
	/**
	 * Sets the previous interaction activity.
	 *
	 * @param aPreviousInteractionActivity the new previous interaction activity
	 */
	public void setPreviousInteractionActivity(
			Activity aPreviousInteractionActivity) {
		previousInteractionActivity = aPreviousInteractionActivity;
		LOGGER.trace(previousInteractionActivity);
	}
	
	/**
	 * Sets the printJobId.
	 *
	 * @param printJobId the printJobId to set
	 */
	public void setPrintJobId(String printJobId) {
		this.printJobId = printJobId;
	}
	
	/**
	 * Sets the current business process ID for this context instance.
	 *
	 * @param anId the new process id
	 */
	public void setProcessId(String anId) {
		processId = anId;
	}
	
	/**
	 * Sets the process net authorizing password.
	 *
	 * @param processNetAuthorizingPassword the processNetAuthorizingPassword to set
	 */
	public void setProcessNetAuthorizingPassword(
			String processNetAuthorizingPassword) {
		this.processNetAuthorizingPassword = processNetAuthorizingPassword;
	}
	
	/**
	 * Sets the process net authorizing user id.
	 *
	 * @param processNetAuthorizingUserId the processNetAuthorizingUserId to set
	 */
	public void setProcessNetAuthorizingUserId(
			String processNetAuthorizingUserId) {
		this.processNetAuthorizingUserId = processNetAuthorizingUserId;
	}
	
	/**
	 * Sets the process registry.
	 *
	 * @param aRegistry the new process registry
	 */
	public void setProcessRegistry(IProcessRegistry aRegistry) {
		processRegistry = aRegistry;
	}
	
	/**
	 * Sets the selected action.
	 *
	 * @param anAction the new selected action
	 */
	public void setSelectedAction(Action anAction) {
		selectedAction = anAction;
	}
	
	/**
	 * Sets the transaction type registry.
	 *
	 * @param transactionTypeRegistry the new transaction type registry
	 */
	public void setTransactionTypeRegistry(
			ITransactionTypeRegistry transactionTypeRegistry) {
		this.transactionTypeRegistry = transactionTypeRegistry;
	}
	
	/**
	 * Sets the Validation Messages.
	 * 
	 * @param validationMessageObject the Validation Messages
	 */
	public void setValidationMessageObject(
			ErrorMessageCollector validationMessageObject) {
		messageCollector = validationMessageObject;
	}
	
	/**
	 * Sets the Work Type whether the DL or VR to the current process context.
	 * 
	 * @param workType the work type
	 */
	public void setWorkType(String workType) {
		//TODO - should not that be a code rather than string?
		this.workType = workType;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}
	
	/**
	 * Start.
	 */
	public void start() {
		LOGGER.debug("Process Context " + processId);
		getCurrentActivity().execute(this);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(2048);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append("...").append(e.getMessage()).append("...").append(
					"]");
			return aBuilder.toString();
		}
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#toStringOn(java.lang.StringBuilder, int)
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("authorizingPassword", authorizingPassword, anIndent,
				aBuilder);
		outputKeyValue("authorizingUserId", authorizingUserId, anIndent,
				aBuilder);
		outputKeyValue("currentActivity", currentActivity, anIndent, aBuilder);
		outputKeyValue("currentInteractionActivity",
				currentInteractionActivity, anIndent, aBuilder);
		outputKeyValue("messageCollector", messageCollector, anIndent, aBuilder);
		outputKeyValue("nextActivity", nextActivity, anIndent, aBuilder);
		outputKeyValue("previousInteractionActivity",
				previousInteractionActivity, anIndent, aBuilder);
		outputKeyValue("processId", processId, anIndent, aBuilder);
		outputKeyValue("printJobId", printJobId, anIndent, aBuilder);
		//outputKeyValue("processRegistry", processRegistry, anIndent, aBuilder);
		outputKeyValue("selectedAction", selectedAction, anIndent, aBuilder);
		//outputKeyValue("transactionTypeRegistry", transactionTypeRegistry,
		//		anIndent, aBuilder);
		outputKeyValue("workType", workType, anIndent, aBuilder);
	}
}
/**
 * Modification History:
 * 
 * $Log: ProcessContext.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/04/30 16:44:38  mwsec2
 * adjusted logging levels
 *
 * Revision 1.1  2012/10/01 02:57:17  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.72  2012/08/16 21:36:28  mwkzn
 * Renamed userContext to be in Camel Case format.
 *
 * Revision 1.71  2012/06/01 21:36:16  mwhys
 * Updated restore() to set the current interaction activity's reference. (Session Management)
 *
 * Revision 1.70  2011/10/12 20:54:53  mwkkc
 * Performance Merge
 *
 * Revision 1.69.8.1  2011/09/28 02:46:54  mwpxp2
 * Added de-springification todos
 *
 * Revision 1.69  2011/07/22 21:52:40  mwxxw
 * Update meothed name to doesExecutionSyncPointContextExist().
 *
 * Revision 1.68  2011/07/22 21:19:02  mwxxw
 * Add new method: isExecutionSyncPointContextExist().
 *
 * Revision 1.67  2011/06/15 21:03:24  mwrka1
 * update alternative printer functionalty
 *
 * Revision 1.66  2011/06/15 20:56:44  mwyxg1
 * remove Logger for performance, this getter is called many times, logger should be placed in function calls.
 *
 * Revision 1.65  2011/06/03 03:09:58  mwrka1
 * added isAlternativePrinterRequested
 *
 * Revision 1.64  2011/06/02 21:41:01  mwpxp2
 * Added resetErrorMessageCollector/0; cleaned up, incl. javadoc; modified for lazy instantiation of message collector
 *
 * Revision 1.63  2011/06/02 19:07:33  mwpxp2
 * Modified hasValidationErrors to avoid unnecessary collector instantiation
 *
 * Revision 1.62  2011/04/29 18:35:00  mwtjc1
 * containsError added
 *
 * Revision 1.61  2011/04/22 21:21:54  mwxxw
 * Move two fields to DlProcessContext.
 *
 * Revision 1.60  2011/04/22 16:39:45  mwxxw
 * Remove the bad comments that is causing the compile error.
 *
 * Revision 1.59  2011/04/22 00:54:17  mwxxw
 * Add the following two field for RCR#23:
 *
 * Revision 1.58  2011/03/03 19:58:15  mwsyk1
 * Reverted to version 1.56
 *
 * Revision 1.56  2011/01/20 19:47:52  mwpxp2
 * Imports and javadoc cleanup
 *
 * Revision 1.55  2011/01/03 01:19:34  mwpxr4
 * Added authorizing userid and password for fee waiver(collection application info page) and process net page.
 *
 * Revision 1.54  2010/12/08 04:14:06  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.53  2010/12/02 00:14:56  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.52  2010/10/27 22:53:35  mwjxa11
 * printJobId- to verify the status of the previous print job before proceeding to next action in every ttc
 *
 * Revision 1.51  2010/10/25 16:15:42  mwyxg1
 * move user id and password to process context
 *
 * Revision 1.50  2010/10/19 17:21:08  mwsec2
 * added superclass IntrospectiveContext
 *
 * Revision 1.49  2010/09/23 19:44:42  mwhys
 * (1) Restored the references to the activities from the process loader during session management.
 * (2) Made processRegistry and transactionTypeRegistry transient, as they are not part of the session and they can be obtained from the application context.
 *
 * Revision 1.48  2010/09/20 17:03:11  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.47  2010/09/03 16:54:43  mwsec2
 * TransactionTypeRegistry added as new property, with setter/getter
 *
 * Revision 1.46  2010/09/01 18:56:22  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.45  2010/08/26 23:41:31  mwsec2
 * Error propagation / rollback fixes
 *
 * Revision 1.44  2010/08/12 18:55:57  mwcsj3
 * Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 * Revision 1.43  2010/08/12 17:17:15  mwsec2
 * fixed bug occurring in certain fallback situations
 *
 * Revision 1.42  2010/08/10 23:02:47  mwakg
 * Removed getCurrentBusinessProcess() from ProcessContext
 *
 * Revision 1.41  2010/08/10 22:24:42  mwsec2
 * isSameProcess method added
 *
 * Revision 1.40  2010/08/10 17:19:32  mwpxp2
 * Removed unproductive this.~es; added todo
 *
 * Revision 1.39  2010/08/09 23:53:35  mwsec2
 * minor clean up
 *
 * Revision 1.38  2010/08/03 21:27:58  mwsec2
 * syncPoint enhancements
 *
 * Revision 1.37  2010/07/30 22:44:21  mwakg
 * Added executionSyncPointContext to the ProcessContext
 *
 * Revision 1.36  2010/07/23 14:49:47  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.33.2.1  2010/06/27 01:41:02  mwakg
 * Added support for sync point
 *
 * Revision 1.35  2010/07/14 21:35:35  mwcsj3
 * Deleted used method endSubProcess
 *
 * Revision 1.34  2010/07/14 20:36:36  mwcsj3
 * Updated resume method logic
 *
 * Revision 1.33  2010/06/21 23:00:42  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.28.6.5  2010/06/20 18:44:06  mwakg
 * Fixed API and updated java docs
 *
 * Revision 1.28.6.4  2010/06/20 18:06:59  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.28.6.3  2010/06/14 22:36:50  mwakg
 * Rebased code in branch from Head - June 14, 2010
 *
 * Revision 1.32  2010/06/14 21:15:36  mwvkm
 * Design for fraud protection is done. Spring-aop is removed and instead using the AspectJ
 *
 * Revision 1.31  2010/06/09 21:23:31  mwsyk1
 * Reverted back to 1.28
 *
 * Revision 1.28.6.2  2010/06/13 20:52:53  mwakg
 * Updated copyProcessContext method and moved it from ProcessContext
 *
 * Revision 1.28.6.1  2010/06/08 01:25:23  mwakg
 * Provided hook method for ProcessContext to copy another ProcessContext. This hook method will be used for switching PCs
 *
 * Revision 1.28  2010/05/05 02:16:00  mwvkm
 * Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 * Revision 1.27  2010/05/04 00:53:56  mwpxp2
 * Bulk cleanup - removed unnecessary casts
 *
 * Revision 1.26  2010/04/22 22:53:54  mwcsj3
 * Fixed FIX ME
 *
 * Revision 1.25  2010/04/22 19:02:59  mwpxp2
 * Added todo
 *
 * Revision 1.24  2010/04/22 18:31:35  mwpxp2
 * Bulk cleanup - added fixmes
 *
 * Revision 1.23  2010/04/13 21:48:43  mwyxg1
 * fix nullpointer
 *
 * Revision 1.22  2010/04/08 23:46:27  mwcsj3
 * Added logging for easy debugging
 *
 * Revision 1.21  2010/04/08 18:24:23  mwcsj3
 * Cleaned up, removed all unused and redundant methods
 *
 * Revision 1.20  2010/04/08 01:55:37  mwcsj3
 * Cleaned up, removed all unused and redundant methods
 *
 * Revision 1.19  2010/04/07 22:19:16  mwcsj3
 * Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 * Revision 1.18  2010/04/04 23:53:57  mwakg
 * Removed ChangeRecord and ChangeTracker as they are not used anymore
 *
 * Revision 1.17  2010/04/04 23:41:15  mwakg
 * Removed ServiceRequest and unused attributes in ProcessContext
 *
 * Revision 1.16  2010/04/04 23:32:00  mwakg
 * Removed ProcessContext from Activity class as it is invalid and not used by anyone
 *
 * Revision 1.15  2010/04/04 22:53:50  mwakg
 * As beans should not be aware of the container I have removed support for ApplicationContextAware for all processContexts
 *
 * Revision 1.14  2010/04/04 22:53:03  mwakg
 * As beans should not be aware of the container I have removed support for ApplicationContextAware for all processContexts
 *
 * Revision 1.13  2010/04/01 00:11:44  mwakg
 * Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 * Revision 1.12  2010/03/27 01:04:27  mwsxd10
 * getPreviousInteractionActivit() method is used for showing the error message on same screen.
 *
 * Revision 1.11  2010/03/23 18:39:06  mwbxp5
 * Added getCurrentActivity().execute(this to execute the current activity before executing the next activity.
 *
 * Revision 1.9  2010/03/22 16:53:00  mwakg
 * Made ProcessContext ApplicationContextAware
 *
 * Revision 1.8  2010/03/21 00:10:24  mwakg
 * Refactored Action class
 *
 * Revision 1.7  2010/03/20 20:34:19  mwkkc
 * WS#3 Merge - Trace work
 *
 * Revision 1.6  2010/03/18 19:03:42  mwyxg1
 * use action getActionKey
 *
 * Revision 1.5  2010/03/18 00:55:40  mwcsj3
 * Made changes to resume(), converted transitionKey to lower case string
 *
 * Revision 1.4  2010/03/11 22:21:06  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.3  2010/03/11 21:51:34  mwcsj3
 * Deleted SOP statements
 *
 * Revision 1.1.2.2  2010/03/04 03:03:33  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.1  2010/03/03 18:12:17  mwcsj3
 * Modified resume() method to accommodate multiple transitions functionality
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.7  2009/11/15 21:11:59  mwakg
 * Added ProcessRegistry as a variable and added cancel method
 *
 * Revision 1.6  2009/10/27 16:41:57  mwjjl7
 * add Serializable
 *
 * Revision 1.5  2009/10/13 03:03:12  mwrrv2
 * Cleaned to do.
 *
 * Revision 1.4  2009/10/07 19:16:35  mwbxp5
 * Removed LOGGER
 *
 * Revision 1.3  2009/10/07 00:48:19  mwhxa2
 * Fixed toString() for nextActivity being null
 *
 * Revision 1.2  2009/10/07 00:36:35  mwrrv2
 * Commented toString().
 *
 * Revision 1.1  2009/10/03 20:55:32  mwpxp2
 * Moved to .impl
 *
 * Revision 1.40  2009/09/30 20:02:39  mwrsk
 * cleanup the IAuditable & ILoggable implementations
 *
 * Revision 1.39  2009/09/28 21:23:22  mwrsk
 * IAuditable & ILoggable moved to framework project
 *
 * Revision 1.38  2009/09/23 22:16:52  mwakg
 * Fixed Sequence number for DL when in Counter mode
 *
 * Revision 1.37  2009/09/22 23:40:50  mwsmg6
 * added start and history
 *
 * Revision 1.36  2009/09/22 20:56:48  mwbxp5
 * Adding Sequence number to Process Context and added implementation for GenerateSequenceNumberActivity
 * Revision 1.35 2009/09/17 21:24:29 mwsxd10
 * Extends IAuditable and ILoggable for auditing and technical logging.
 * 
 * Revision 1.34 2009/09/15 17:40:11 mwsmg6 cleanup
 * 
 * Revision 1.33 2009/09/15 15:59:34 mwsmg6 cleanup
 * 
 * Revision 1.32 2009/09/03 04:17:37 mwjjl7 refactor for action handling
 * specification
 * 
 * Revision 1.30 2009/09/03 00:55:05 mwsmg6 refactoring ations
 * 
 * Revision 1.29 2009/09/02 23:12:13 mwsmg6 restart
 * 
 * Revision 1.28 2009/09/02 23:09:21 mwsmg6 restart
 * 
 * Revision 1.27 2009/09/02 20:55:09 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.26 2009/09/02 20:50:56 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.25 2009/09/02 20:44:14 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.24 2009/09/02 19:23:11 mwbvc added new attributes for workType and
 * Document Type for new Easehome page
 * 
 * Revision 1.23 2009/09/02 18:44:00 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.22 2009/08/31 18:11:20 mwakg Added support for viewMode into
 * ProcessContext
 * 
 * Revision 1.21 2009/08/28 04:18:14 mwsmg6 law of Demeter
 * 
 * Revision 1.20 2009/08/28 04:08:42 mwsmg6 law of Demeter
 * 
 * Revision 1.19 2009/08/28 00:49:07 mwsmg6 law of Demeter
 * 
 * Revision 1.18 2009/08/27 21:25:20 mwsmg6 law of Demeter
 * 
 * Revision 1.17 2009/08/27 20:58:19 mwsmg6 corrected method name
 * 
 * Revision 1.16 2009/08/27 18:44:48 mwsmg6 removed dead code
 * 
 * Revision 1.15 2009/08/27 18:43:51 mwsmg6 work toward restart
 * 
 * Revision 1.14 2009/08/27 08:25:01 mwpxp2 Fixed imports to reflect fw
 * migration; bulk cleanup
 * 
 * Revision 1.13 2009/08/25 18:24:21 mwsmg6 removed getSessionContext
 * 
 * Revision 1.12 2009/08/24 22:50:04 mwsmg6 provision for tracking value changes
 * 
 * Revision 1.11 2009/08/20 22:02:15 mwpxp2 Added getSessionContext and toString
 * 
 * Revision 1.8 2009/08/19 21:38:28 mwpxp2 Added class comment, serialVersionUID
 * 
 * Revision 1.7 2009/08/17 21:31:41 mwakg Fixed nullpointer exception
 * 
 * Revision 1.6 2009/08/16 21:52:50 mwakg Added support for storing the
 * selectedAction
 * 
 * Revision 1.5 2009/08/11 02:17:59 mwpxp2 Added logging; bulk cleanup; added
 * file decorations where missing
 * 
 * 
 * $Revision 1.4 2009/08/06 01:32:40 mwsmg6 $*** empty log message *** $
 * $Revision 1.3 2009/08/05 21:05:59 mwsmg6 $refactored ProcessContext $
 * $Revision 1.2 2009/08/05 20:53:18 mwsmg6 $*** empty log message *** $
 * $Revision 1.1 2009/08/05 17:00:49 mwsmg6 $moved ProcessContext to ...context
 * package $ $Revision 1.7 2009/08/05 01:58:10 mwbvc $Added
 * validationMessageObject to Process Context $ $Revision 1.6 2009/08/04
 * 17:55:04 mwsmg6 $added support for change events $ $Revision 1.5 2009/08/04
 * 17:13:08 mwpxm2 $Activity change $ $Revision 1.4 2009/07/25 18:54:59 mwcsj3
 * $Updated Comments and changed UserContext to IUserContext $
 * 
 */
