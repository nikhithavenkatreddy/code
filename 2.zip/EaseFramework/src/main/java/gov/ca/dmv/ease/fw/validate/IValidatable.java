/**
 * 
 */
package gov.ca.dmv.ease.fw.validate;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: I am interface for objects that require some form of validation.
 * I use IErrorCollector to collect potentially many validation exceptions.
 * File: IValidatable.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Jul 30, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IValidatable {
	/**
	 * Validate.
	 * 
	 * @return the i error collector
	 */
	IErrorCollector validate();

	/**
	 * Validate using.
	 * 
	 * @param aCollector the a collector
	 */
	void validateUsing(IErrorCollector aCollector);
}
/**
 *  Modification History:
 *
 *  $Log: IValidatable.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/11 17:20:35  mwpxp2
 *  uncommented interface calls
 *
 *  Revision 1.2  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:28:33  mwpxp2
 *  Moved into fw.validate
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/17 21:24:54  mwpxp2
 *  Added validate/0
 *
 *  Revision 1.1  2009/07/30 21:24:45  mwpxp2
 *  Initial
 *
 */
