/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */

package gov.ca.dmv.ease.ecs.ics.request.impl;

/**
 * Description: 
 * File: AbstractEcsImageCaptureSystemRequest
 * Module:  gov.ca.dmv.ease.ecs.ics.convert.impl
 * Created: Oct 05, 2010
 * @author MWPXR4  
 * @version $$Revision: 1.1 $$
 * Last Changed: $$Date: 2012/10/01 02:57:34 $Oct 05, 2010 1:54:24 PM $$
 * Last Changed By: $ MWPXR4 $
 */

import gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

public abstract class AbstractEcsImageCaptureSystemRequest extends
		FireAndForgetEcsRequest {

	/** The constant serial version uid. */
	private static final long serialVersionUID = 956956247078866610L;
	
	/**
	 * The Constructor - Instantiates the abstract image capture request using a request id, user context.
	 * @param anId
	 * @param context
	 */
	public AbstractEcsImageCaptureSystemRequest(String anId, IUserContext context) {
		super(anId, context);
	}
	
	/**
	 * Checks if the request is image capture request.
	 * @return boolean, always true.
	 */
	@Override
	public final boolean isIcsRequest() {
		return true;
	}

}

/**
 *  Modification History:
 * 
 *  $Log: AbstractEcsImageCaptureSystemRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/14 21:12:37  mwpxr4
 *  Abstract class ecs request class for ICS.
 *
 */