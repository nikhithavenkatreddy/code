/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response.impl;

import gov.ca.dmv.ease.tus.office.business.response.IRetrieveAuthorizedTtcsResponse;

import java.util.List;

/**
 * Description: I am an RetrieveAuthorizedTtcsResponse response
 * 
 * File: RetrieveAuthorizedTtcsResponse.java
 * Module:  gov.ca.dmv.ease.tus.office.business.response.impl
 * Created: Jan 12, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveAuthorizedTtcsResponse extends
		OfficeBusinessServiceResponse implements IRetrieveAuthorizedTtcsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5091012995786070403L;
	/** List of authorized ttcs */
	private List<String> authTtcList;

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveAuthorizedTtcsResponse(List<String> authTtcList) {
		super();
		this.authTtcList = authTtcList;
	}	

	/**
	 * Get TTCs for this office.
	 * @return
	 */
	public List<String> getAuthTtcs()  {
		return this.authTtcList;
	}
	
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
