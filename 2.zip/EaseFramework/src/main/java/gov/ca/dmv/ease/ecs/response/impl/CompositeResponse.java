/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.ecs.response.ICompositeResponse;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:  I am implementation of ICompositeResponse - 
 * I provide for a number for responses to be bundled together, 
 * typically as a result of executing a composite request.
 * File: CompositeResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response
 * Created: 16/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CompositeResponse extends AbstractEcsResponse implements
		ICompositeResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1291896070816788671L;
	/** The children. */
	private List <IEcsResponse> children = new ArrayList <IEcsResponse>();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.ICompositeResponse#add(gov.ca.dmv.ease.ecs.response.IEcsResponse)
	 */
	public void add(IEcsResponse response) {
		children.add(response);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.ICompositeResponse#addAll(java.util.List)
	 */
	public void addAll(List <IEcsResponse> responseList) {
		this.children = responseList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CompositeResponse other = (CompositeResponse) obj;
		/**Children can never be null**/
		if (!children.equals(other.children)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#getBusinessObjectNamed(java.lang.String)
	 */
	@Override
	public BusinessObject getBusinessObjectNamed(String propertyName) {
		return null;
	}

	/**
	 * Gets the children.
	 *
	 * @return the children
	 */
	protected List <IEcsResponse> getChildren() {
		return children;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.ICompositeResponse#getChildrenSize()
	 */
	public int getChildrenSize() {
		/**Children can never be null**/
		int returnint = children.size();
		return returnint;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#getObjectCount()
	 */
	@Override
	public int getObjectCount() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.ICompositeResponse#getResponses()
	 */
	public List <IEcsResponse> getResponses() {
		List <IEcsResponse> returnList = getChildren();
		return returnList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#hasChidren()
	 */
	@Override
	public boolean hasChidren() {
		/**Children can never be null**/
		if (children.size() == 0) {
			return false;
		}
		else {
			return true;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (children.hashCode());
		return result;
	}

	/**
	 * Sets the children.
	 *
	 * @param children the new children
	 */
	protected void setChildren(List <IEcsResponse> children) {
		this.children = children;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("children", children, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#validate()
	 */
	@Override
	public void validate() {
	}
}
/**
 *  Modification History:
 *
 *  $Log: CompositeResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.19  2009/10/14 21:00:57  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.18  2009/10/14 18:15:59  mwhxb3
 *  updated comments
 *
 *  Revision 1.17  2009/10/07 23:17:11  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.16  2009/10/07 18:19:38  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.15  2009/10/07 15:44:07  mwhxb3
 *  added comment
 *
 *  Revision 1.14  2009/10/07 15:43:20  mwhxb3
 *  implemented add(IEcsResponse)
 *
 *  Revision 1.13  2009/10/07 14:22:40  mwcsj3
 *  Cleaned todos
 *
 *  Revision 1.12  2009/10/07 03:34:19  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.11  2009/10/07 02:57:53  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.10  2009/10/06 21:54:08  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9.2.2  2009/10/06 20:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9.2.1  2009/10/06 20:28:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9  2009/10/03 21:23:42  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.8  2009/10/01 16:29:47  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.7  2009/08/10 23:09:42  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.6  2009/07/27 18:30:38  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.5  2009/07/27 18:02:17  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.4  2009/07/16 02:30:11  mwpxp2
 *  Bulk cleanup, incl javadoc and file decorations
 *
 *  Revision 1.3  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:10:05  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.1  2009-05-17 05:23:28  mwpxp2
 *  Initial
 *
 */
