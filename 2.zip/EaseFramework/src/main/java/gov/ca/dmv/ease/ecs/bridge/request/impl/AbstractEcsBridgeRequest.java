/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.bridge.request.impl;

import gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am abstract super class for requests sent to DMVA bridge
 *  
 * File: AbstractEcsBridgeRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request.impl
 * Created: Apr 10, 2010 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractEcsBridgeRequest extends FireAndForgetEcsRequest {
	/**
	 * @param anId
	 */
	public AbstractEcsBridgeRequest(String anId) {
		super(anId);
		
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2699109083100358647L;

	/**
	 * The Constructor - Instantiates the log request using a request id, user context, and a log entry.
	 * 
	 * @param anId Id of the request
	 * @param context the context
	 * @param aLogEntry the a log entry
	 */
	public AbstractEcsBridgeRequest(String anId, IUserContext context) {
		super(anId, context);
	}

	/**
	 * Instantiates a new abstract ecs bridge request.
	 * 
	 * @param context 
	 */
	public AbstractEcsBridgeRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Checks if is log request.
	 * 
	 * @return true, if is log request
	 */
	@Override
	public final boolean isBridgeRequest() {
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AbstractEcsBridgeRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/12/10 02:33:43  mwpxp2
 *  Added constructor from super
 *
 *  Revision 1.2  2010/12/06 20:13:28  mwpxp2
 *  Added contstructor/1 on user context
 *
 *  Revision 1.1  2010/09/22 18:17:35  mwpxp2
 *  Moved in to bridge-specific package
 *
 *  Revision 1.4  2010/09/22 18:09:58  mwpxp2
 *  Added fixme
 *
 *  Revision 1.3  2010/09/22 17:58:42  mwpxp2
 *  Added class comment; bulk cleanup
 *
 *  Revision 1.2  2010/04/22 19:22:30  mwpxp2
 *  Bulk cleanup; added todo
 *
 *  Revision 1.1  2010/04/12 02:33:54  mwpzs3
 *  update for bridge code communication
 *
*/
