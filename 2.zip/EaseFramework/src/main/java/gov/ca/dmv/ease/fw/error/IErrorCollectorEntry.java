/**
 * 
 */
package gov.ca.dmv.ease.fw.error;

import gov.ca.dmv.ease.bo.ITreePrintable;

import java.io.Serializable;

/**
 * Description: I am interface for an object registerable in IErrorCollector
 * File: IErrorCollectorEntry.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Jul 30, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IErrorCollectorEntry extends IErrorCollectorQuery,
		ITreePrintable, Serializable {
	/**
	 * Get the error field for the focus.
	 * @return
	 */
	String getErrorFieldToFocus();

	/**
	 * Gets the exception class name.
	 * 
	 * @return the exception class name
	 */
	String getExceptionClassName();

	/**
	 * Gets the exception message.
	 * 
	 * @return the exception message
	 */
	String getExceptionMessage();

	/**
	 * Gets the message parameters.
	 * 
	 * @return the message parameters
	 */
	String[] getMessageParameters();

	/**
	 * Checks for message including.
	 *
	 * @param aMessage the a message
	 * @return true, if successful
	 */
	boolean hasMessageIncluding(String aMessage);
}
/**
 *  Modification History:
 *
 *  $Log: IErrorCollectorEntry.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2011/02/04 01:20:25  mwpxp2
 *  Extended ITreePrintable
 *
 *  Revision 1.6  2011/01/21 02:57:38  mwpxp2
 *  Added hasMessageIncluding/1
 *
 *  Revision 1.5  2010/12/03 21:02:06  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.4  2010/10/12 18:13:30  mwpxp2
 *  Extended IErrorCollectorQuery
 *
 *  Revision 1.3  2010/09/29 20:27:39  mwtjc1
 *  Object[] parameters is replaced with String[] messageParameters
 *
 *  Revision 1.2  2010/09/28 18:06:03  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:16:41  mwpxp2
 *  Moved to fw.error; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/07/30 21:24:45  mwpxp2
 *  Initial
 *
 */
