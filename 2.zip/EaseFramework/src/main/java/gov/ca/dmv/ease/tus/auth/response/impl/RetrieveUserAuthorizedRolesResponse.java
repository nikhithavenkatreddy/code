/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveUserAuthorizedRolesResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am an AuthAndAuth response
 * 
 * File: RetrieveUserAuthorizedRolesResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveUserAuthorizedRolesResponse extends
		AuthAndAuthServiceResponse implements
		IRetrieveUserAuthorizedRolesResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5401065497217185867L;
	/** list of roles to return */
	List <String> rolesList = new ArrayList <String>();

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveUserAuthorizedRolesResponse(List <String> rolesList) {
		super();
		setRoles(rolesList);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveUserAuthorizedRolesResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RetrieveUserAuthorizedRolesResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Get role list.
	 * 
	 * @return the role list
	 */
	public List <String> getRoles() {
		return rolesList;
	}

	/**
	 * Sets the role list.
	 * 
	 * @param role list
	 */
	private void setRoles(List <String> rolesList) {
		this.rolesList = rolesList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveUserAuthorizedRolesResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
