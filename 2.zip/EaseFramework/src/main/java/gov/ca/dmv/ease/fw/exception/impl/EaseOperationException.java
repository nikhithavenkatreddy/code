/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am abstract superclass for exceptions related to performance of an operation, 
 * regardless of the layer in which that happens
 * File: EaseOperationException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EaseOperationException extends EaseException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5372394632070193810L;

	/**
	 * Instantiates a new ease operation exception.
	 */
	public EaseOperationException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseOperationException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseOperationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseOperationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseOperationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
