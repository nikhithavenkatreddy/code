/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response;

import java.util.Map;

/**
 * Description: I am an AuthAndAuthResponse interface
 * 
 * File: IAuthorizeApproverResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response
 * Created: Oct 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveAuthorizedTtcsMapResponse extends
		IAuthAndAuthServiceResponse {
	/**
	 * Gets the ttc map.
	 * 
	 * @return the ttc map
	 */
	Map <String, String> getTtcs();
}
/**
 *  Modification History:
 *
 *  $Log: IRetrieveAuthorizedTtcsMapResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
