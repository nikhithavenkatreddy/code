/**
 * 
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;

/**
 * Description: Message creator class for AKTS messages
 * File: VoterRegMessageCreator.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Jan 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2016/02/18 20:17:49 $
 * Last Changed By: $Author: mwskh1 $
 */
public class VoterRegMessageCreator implements MessageCreator {
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(VoterRegMessageCreator.class);
	/** Request for which this Message creator is used for **/
	private IEcsRequest request;

	/**
	 * @param aRequest
	 */
	public VoterRegMessageCreator(IEcsRequest aRequest) {
		request = aRequest;
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String msgCreatedByConverter = convertor.createMessage(request);
		TextMessage textMessage = session
				.createTextMessage(msgCreatedByConverter);
		return textMessage;
	}
}
/**
 *  Modification History:
 *
 *  $Log: VoterRegMessageCreator.java,v $
 *  Revision 1.2  2016/02/18 20:17:49  mwskh1
 *  Motor Voter - merge to head
 *
 *  Revision 1.1.2.1  2016/01/21 19:45:42  mwskh1
 *  Motor Voter - Add new subprocess and ECS message with queue settings
 *
 *
 */
