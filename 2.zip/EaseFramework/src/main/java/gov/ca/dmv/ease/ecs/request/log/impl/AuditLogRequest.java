/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.log.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.request.impl.AbstractEcsLogRequest;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am concrete request class for audit logging.
 * File: AuditLogRequest.java
 * Module:  gov.ca.dmv.ease.tus.log.request.impl
 * Created: 19/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuditLogRequest extends AbstractEcsLogRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9070088175173554782L;

	/**
	 * The Constructor that instantiates the AuditLogRequest
	 * 
	 * @param anId Id of the request
	 * @param context the context
	 * @param logEntry the log entry
	 */
	public AuditLogRequest(String anId, IUserContext context, String logEntry) {
		super(anId, context, logEntry);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest#execute()
	 */
	@Override
	public FireAndForgetReceipt execute() throws EcsServiceException {
		FireAndForgetReceipt returnReceipt = super.execute();
		return returnReceipt;
	}

	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	@Override
	public IMessageConverter getMessageConverter() {
		throw new EaseValidationException("provide a converter");
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuditLogRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:27:39  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/13 22:15:33  mwhxb3
 *  updated comments.
 *
 *  Revision 1.6  2009/10/07 02:57:18  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.5  2009/10/06 21:53:19  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.2  2009/10/06 20:41:52  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.1  2009/10/06 20:28:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/10/03 21:23:38  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 05:54:45  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/27 02:33:58  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/08/22 20:33:01  mwpxp2
 *  Moved to dedicated package; added getMessageConverter/0
 *
 *  Revision 1.4  2009/08/18 18:47:28  mwvkk1
 *  Updated with execute method
 *
 *  Revision 1.3  2009/07/27 18:48:51  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/27 17:46:48  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.1  2009/07/22 16:36:02  mwaxb1
 *  Refactor logging stubs by moving code related to ECS call to ECS project
 *
 *  Revision 1.1  2009/07/21 21:15:54  mwpxp2
 *  Implementation stub
 *
 *  Revision 1.1  2009-07-20 13:25:35  mwpxp2
 *  Initial
 *  
 *
 */
