/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process.rule.impl;

import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.rule.IProcessBooleanRule;

/**
 * Description: I am abstract implementation of IProcessBooleanRule
 * Concrete rule implementations are expected to inherit
 *
 * File: AbstractProcessBooleanRule.java
 * Module:  gov.ca.dmv.ease.fw.process.rule.impl
 * Created: Jan 21, 2011
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractProcessBooleanRule extends AbstractProcessRule
		implements IProcessBooleanRule {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8366255731895287227L;

	/**
	 * Instantiates a new abstract process boolean rule.
	 */
	protected AbstractProcessBooleanRule() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.rule.IProcessBooleanRule#evaluate(gov.ca.dmv.ease.fw.process.IProcessContext)
	 */
	public final boolean evaluate(IProcessContext aCtx) {
		validateArguments(aCtx);
		validateIfApplicable(aCtx);
		return localEvaluate(aCtx);
	}

	/**
	 * Local evaluate.
	 *
	 * @param aCtx the a ctx
	 * @return true, if successful
	 */
	protected abstract boolean localEvaluate(IProcessContext aCtx);
}
/**
 *  Modification History:
 *
 *  $Log: AbstractProcessBooleanRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:20  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/01/21 23:37:06  mwpxp2
 *  Added localEvaluate/1
 *
 *  Revision 1.1  2011/01/21 23:16:13  mwpxp2
 *  Initial
 *
 */
