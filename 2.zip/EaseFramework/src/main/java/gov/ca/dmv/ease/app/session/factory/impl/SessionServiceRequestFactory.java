/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.factory.impl;

import gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.request.impl.DeleteSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RestoreSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.StoreSessionRequest;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.util.impl.Serializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I define the interface to PersistenceServiceRequest.
 * File: SessionServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.app.session.factory.impl
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2014/01/13 21:30:37 $
 * Last Changed By: $Author: mwsec2 $
 */
public class SessionServiceRequestFactory implements
		ISessionServiceRequestFactory {
	/** The SINGLETON. */
	private static ISessionServiceRequestFactory SINGLETON = new SessionServiceRequestFactory();
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory
			.getLog(SessionServiceRequestFactory.class);
	
	/**
	 * Gets the single instance of SessionService.
	 * 
	 * @return single instance of SessionService
	 */
	public static ISessionServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}
	
	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new SessionServiceRequestFactory();
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createDeleteSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public DeleteSessionRequest createDeleteSessionRequest(
			IUserContext userContext) {
		return new DeleteSessionRequest(userContext);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createDeleteSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public DeleteSessionRequest createDeleteSessionRequest(
			IUserContext userContext, Session session) {
		return new DeleteSessionRequest(userContext, session);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createRestoreSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RestoreSessionRequest createRestoreSessionRequest(
			IUserContext userContext, String newSessionId) {
		Session sessionCriteria = new Session(userContext);
		return new RestoreSessionRequest(userContext, sessionCriteria,
				newSessionId);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createRetrieveSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public RetrieveSessionRequest createRetrieveSessionRequest(
			IUserContext userContext) {
		Session sessionCriteria = new Session(userContext);
		return new RetrieveSessionRequest(userContext, sessionCriteria);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createRetrieveSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public RetrieveSessionRequest createRetrieveSessionRequest(
			IUserContext userContext, Session session) {
		return new RetrieveSessionRequest(userContext, session);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createRetrieveSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveSessionRequest createRetrieveSessionRequest(
			IUserContext userContext, String sessionId) {
		Session sessionCriteria = new Session();
		sessionCriteria.setSessionId(sessionId);
		return new RetrieveSessionRequest(userContext, sessionCriteria);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createStoreSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public StoreSessionRequest createStoreSessionRequest(
			IUserContext userContext, Session session) {
		return new StoreSessionRequest(userContext, session);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createStoreSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public StoreSessionRequest createStoreSessionRequest(
			IUserContext userContext, Session session, SessionData sessionData) {
		if (Serializer.getInstance().isValidBlob(sessionData, true)) {
			session.setSessionData(Serializer.getInstance().getBlobFromObject(
					sessionData));
		}
		else {
			LOGGER.error(sessionData.getClass()
					+ " is not serializable or too big to store!");
			throw new EaseValidationException(sessionData.getClass()
					+ " is not serializable or too big to store!");
		}
		return new StoreSessionRequest(userContext, session);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.factory.ISessionServiceRequestFactory#createStoreSessionRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public StoreSessionRequest createStoreSessionRequest(
			IUserContext userContext, String sessionId, SessionData sessionData) {
		Session session = new Session(userContext, sessionId);
		if (Serializer.getInstance().isValidBlob(sessionData, true)) {
			session.setSessionData(Serializer.getInstance().getBlobFromObject(
					sessionData));
		}
		else {
			LOGGER.error(sessionData.getClass()
					+ " is not serializable or too big to store!");
			//			throw new EaseValidationException(sessionData.getClass()
			//					+ " is not serializable or too big to store!");
		}
		return new StoreSessionRequest(userContext, session);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionServiceRequestFactory.java,v $
 *  Revision 1.2  2014/01/13 21:30:37  mwsec2
 *  changed the logging level for the statement that reports the session was too big to save
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2012/05/08 00:26:44  mwhys
 *  Updated for Session Management.
 *
 *  Revision 1.12  2012/01/11 18:13:58  mwkfh
 *  reverted createRestoreSessionRequest
 *
 *  Revision 1.11  2012/01/11 17:15:43  mwkfh
 *  updated createRestoreSessionRequest
 *
 *  Revision 1.10  2012/01/10 18:10:44  mwkfh
 *  updated session create with userContext
 *
 *  Revision 1.9  2012/01/06 23:22:01  mwkfh
 *  updated comment for createRestoreSessionRequest
 *
 *  Revision 1.8  2012/01/06 19:39:24  mwkfh
 *  updated Session creation constructor
 *
 *  Revision 1.7  2011/01/31 22:17:36  mwkkc
 *  Preparing for March 1st
 *
 *  Revision 1.6  2011/01/27 20:18:08  mwkfh
 *  added log message for invalid blob to store
 *
 *  Revision 1.5  2011/01/27 19:04:21  mwsyk1
 *  Removed Check for serializable
 *
 *  Revision 1.4  2010/09/30 21:50:16  mwkfh
 *  added implements ISessionServiceRequestFactory
 *
 *  Revision 1.3  2010/09/30 21:21:42  mwkfh
 *  changed getInstance() to return interface
 *
 *  Revision 1.2  2010/09/30 19:28:20  mwkfh
 *  updated session restore to update record instead of delete
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
