/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.format.FieldValueType;
import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.IPayloadSampleProducer;

import java.util.Random;

/**
 * Description: I am default implementation of IPayloadSampleProducer
 * File: PayloadSampleProducer.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PayloadSampleProducer implements IPayloadSampleProducer {
	/** The RND. */
	protected static Random RND = new Random();

	/**
	 * Gets the alpha num random char.
	 * 
	 * @return the alpha num random char
	 */
	public static char getAlphaNumRandomChar() {
		//97 - 112 or 65 - 90 or 48 -57
		int aRandValue = getNextRandom();
		while (!Character.isLetterOrDigit((char) aRandValue)) {
			aRandValue = getNextRandom();
		}
		return (char) aRandValue;
	}

	/**
	 * Gets the alpha random char.
	 * 
	 * @return the alpha random char
	 */
	public static char getAlphaRandomChar() {
		//97 - 112 or 65 - 90
		int aRandValue = getNextRandom();
		while (!Character.isLetter((char) aRandValue)) {
			aRandValue = getNextRandom();
		}
		return (char) aRandValue;
	}

	/**
	 * Gets the random char.
	 * 
	 * @return the random char
	 */
	public static char getAnyRandomChar() {
		//33 - 112  
		int aRandValue = getNextRandom();
		while ((aRandValue >= 33 && aRandValue <= 112)) {
			aRandValue = getNextRandom();
		}
		return (char) aRandValue;
	}

	/**
	 * Gets the next random.
	 * 
	 * @return the next random
	 */
	protected static int getNextRandom() {
		return RND.nextInt(128);
	}

	/**
	 * Gets the num random char.
	 * 
	 * @return the num random char
	 */
	public static char getNumRandomChar() {
		//  48 -57
		int aRandValue = getNextRandom();
		while (!Character.isDigit((char) aRandValue)) {
			aRandValue = getNextRandom();
		}
		return (char) aRandValue;
	}

	/**
	 * Gets the random string.
	 * 
	 * @param length 
	 * 
	 * @return the random string
	 */
	public static String getRandomAnyString(int length) {
		StringBuffer aBuff = new StringBuffer(length);
		for (int i = 0; i < length; i++) {
			aBuff.append(getAnyRandomChar());
		}
		return aBuff.toString();
	}

	/**
	 * Gets the random char.
	 * 
	 * @param targetType 
	 * 
	 * @return the random char
	 */
	public static char getRandomChar(FieldValueType targetType) {
		if (targetType == FieldValueType.ANY
				|| targetType == FieldValueType.UNKNOWN) {
			return getAnyRandomChar();
		}
		if (targetType == FieldValueType.ALPHA) {
			return getAlphaRandomChar();
		}
		if (targetType == FieldValueType.ALPHANUM) {
			return getAlphaNumRandomChar();
		}
		if (targetType == FieldValueType.SPACE) {
			return ' ';
		}
		if (targetType == FieldValueType.NUMERIC) {
			return getNumRandomChar();
		}
		return getAnyRandomChar();
	}

	/**
	 * Gets the random correct sample.
	 * 
	 * @param targetType 
	 * @param size 
	 * 
	 * @return the random correct sample
	 */
	public static String getRandomCorrectSample(FieldValueType targetType,
			int size) {
		StringBuffer aBuff = new StringBuffer(size);
		for (int i = 0; i < size; i++) {
			aBuff.append(getRandomChar(targetType));
		}
		return aBuff.toString();
	}

	/**
	 * Instantiates a new payload randomizer.
	 */
	public PayloadSampleProducer() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomCorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IFieldFormat)
	 */
	public String createRandomCorrectPayloadUsing(IFieldFormat aFormat) {
		return aFormat.getRandomCorrectSample(getNextRandom());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomCorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IMessageFormat)
	 */
	public String createRandomCorrectPayloadUsing(IMessageFormat aFormat) {
		StringBuilder aBuilder = new StringBuilder(aFormat.getLength());
		for (IFieldFormat aField : aFormat.getFields()) {
			aBuilder.append(createRandomCorrectPayloadUsing(aField));
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomIncorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IFieldFormat)
	 */
	public String createRandomIncorrectPayloadUsing(IFieldFormat aFormat) {
		return aFormat.getRandomIncorrectSample(getNextRandom());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomIncorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IMessageFormat)
	 */
	public String createRandomIncorrectPayloadUsing(IMessageFormat aFormat) {
		StringBuilder aBuilder = new StringBuilder(aFormat.getLength());
		for (IFieldFormat aField : aFormat.getFields()) {
			aBuilder.append(createRandomIncorrectPayloadUsing(aField));
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createStringNotEqualTo(java.lang.String)
	 */
	public String createStringNotEqualTo(String allowedValue) {
		String aString = getRandomAnyString(allowedValue.length());
		while (aString.equals(allowedValue)) {
			aString = getRandomAnyString(allowedValue.length());
		}
		return aString;
	}
}
/**
 *  Modification History:
 *
 *  $Log: PayloadSampleProducer.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/01 01:50:42  mwpxp2
 *  Renamed
 *
 *  Revision 1.3  2010/12/01 01:22:51  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.2  2010/11/25 02:04:03  mwpxp2
 *  Adjusted rand-related var names
 *
 *  Revision 1.1  2010/11/25 00:54:05  mwpxp2
 *  Initial
 *
 */
