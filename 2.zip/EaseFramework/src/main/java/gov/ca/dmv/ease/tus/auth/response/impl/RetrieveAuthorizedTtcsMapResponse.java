/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsMapResponse;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Description: I am an AuthAndAuth response
 * 
 * File: RetrieveAuthorizedTtcsMapResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveAuthorizedTtcsMapResponse extends
		AuthAndAuthServiceResponse implements
		IRetrieveAuthorizedTtcsMapResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8361621414170097066L;
	/** map of ttcs to return */
	Map <String, String> ttcMap = new LinkedHashMap <String, String>();

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveAuthorizedTtcsMapResponse(Map <String, String> ttcMap) {
		super();
		setTtcs(ttcMap);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveAuthorizedTtcsMapResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RetrieveAuthorizedTtcsMapResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Gets the ttc map.
	 * 
	 * @return the ttc map
	 */
	public Map <String, String> getTtcs() {
		return ttcMap;
	}

	/**
	 * Sets the ttc map.
	 * 
	 * @param ttc map
	 */
	private void setTtcs(Map <String, String> ttcMap) {
		this.ttcMap = ttcMap;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveAuthorizedTtcsMapResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
