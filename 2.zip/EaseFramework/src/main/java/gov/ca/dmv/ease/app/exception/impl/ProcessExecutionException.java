/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessLayerException;

/**
 * Description: Exception class for business process execution exceptions
 * File: ProcessExecutionException.java
 * Module:  gov.ca.dmv.ease.app.exception.impl
 * Created: Aug 27, 2010 
 * @author MWCSJ3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProcessExecutionException extends EaseBusinessLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8512803266478989861L;

	/**
	 * Instantiates a new process execution exception.
	 */
	public ProcessExecutionException() {
		super();
	}
	
	/**
	 * Instantiates a new process execution exception.
	 * @param message
	 */
	public ProcessExecutionException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new process execution exception.
	 * 
	 * @param exception the exception
	 */
	public ProcessExecutionException(Exception exception) {
		super(exception);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ProcessExecutionException.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/12/16 17:43:21  mwsec2
 *  string-arg constructor added
 *
 *  Revision 1.2  2010/09/22 20:59:38  mwpxp2
 *  Fixed super; re-generated serialVersionUID
 *
 *  Revision 1.1  2010/08/27 15:55:48  mwcsj3
 *  Initial version
 *
 *  
 */
