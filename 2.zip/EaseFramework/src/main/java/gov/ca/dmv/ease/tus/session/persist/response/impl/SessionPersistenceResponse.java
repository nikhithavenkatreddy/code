/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.session.persist.response.ISessionPersistenceResponse;

/**
 * Description: //TODO - provide description!
 * File: SessionPersistenceResponse.java
 * Module:  gov.ca.dmv.ease.tus.session.persist.response.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SessionPersistenceResponse extends PersistenceServiceResponse
		implements ISessionPersistenceResponse {
	/** The serialVersionUID */
	private static final long serialVersionUID = 6296203320665217176L;

	/**
	 * Instantiates a new persistence service response.
	 */
	public SessionPersistenceResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public SessionPersistenceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public SessionPersistenceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param aCollector the a collector
	 * @param anItemCount the an item count
	 */
	public SessionPersistenceResponse(IErrorCollector aCollector,
			int anItemCount) {
		super(aCollector, anItemCount);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param anItemCount the an item count
	 */
	public SessionPersistenceResponse(Integer anItemCount) {
		super(anItemCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionPersistenceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/06 19:34:48  mwkfh
 *  Initial
 *
 */
