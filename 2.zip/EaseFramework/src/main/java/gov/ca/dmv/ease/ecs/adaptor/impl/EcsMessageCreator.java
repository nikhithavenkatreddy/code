/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.config.impl.Configuration;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageCreationException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;

/**
 * Description: I am a jms message creator.
 * File: EcsMessageCreator.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Aug 23, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsMessageCreator implements MessageCreator {
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(EcsMessageCreator.class);
	/** Request for which this Message creator is used for **/
	private String corrId = null;
	/** Request for which this Message creator is used for **/
	private IEcsRequest request = null;
	
	/**
	 * Utility method used for padding spaces to a UserId.
	 * 
	 * @param aUserId the uid
	 * 
	 * @return the string
	 */
	public static String convertToEcsUserId(String aUserId) {
		char space = ' ';
		StringBuilder aBuffer = new StringBuilder(aUserId);
		for (int i = aBuffer.length(); i < 32; i++) {
			aBuffer.append(space);
		}
		String returnString = (aBuffer.length() == 32) ? aBuffer.toString()
				: aBuffer.substring(0, 32);
		return returnString;
	}

	/**
	 * Ljustify Utility method used for padding zeroes to a number
	 * 
	 * @param number the number
	 * @param stringLength the string length
	 * 
	 * @return the string
	 */
	public static String ljustify(int number, int stringLength) {
		String preJust = Integer.toString(number);
		for (int j = preJust.length(); j < stringLength; j++) {
			preJust = "0" + preJust;
		}
		return preJust;
	}

	/**
	 * Utility method used for padding spaces to a UserId.
	 * 
	 * @param aUserId the uid
	 * 
	 * @return the string
	 */
	public static String pad(String aUserId, int len) {
		char space = ' ';
		StringBuilder aBuffer = new StringBuilder(aUserId);
		for (int i = aBuffer.length(); i < len; i++) {
			aBuffer.append(space);
		}
		String returnString = (aBuffer.length() == len) ? aBuffer.toString()
				: aBuffer.substring(0, len);
		return returnString;
	}

	/**
	 * Constructor - Instantiates a new creator.
	 * @param aRequest a request
	 * @param corrId a correlation id.
	 */
	public EcsMessageCreator(IEcsRequest aRequest, String aCorrelationId) {
		LOGGER.debug("EcsMessageCreator(IEcsRequest aRequest=" + aRequest
				+ ", String corrId=" + aCorrelationId + ") - start");
		request = aRequest;
		corrId = aCorrelationId; //TODO the request should already have the correlation id set in ecs request factory
		LOGGER.debug("EcsMessageCreator(IEcsRequest, String) - end");
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String req = convertor.createMessage(request);
		IUserContext userContext = request.getUserContext();
		validateUserContext(userContext);
		String racfId = userContext.getRacfId().toUpperCase();
		String officeId = userContext.getOfficeId().toUpperCase();
		String techId = userContext.getTechId().toUpperCase();
		String username = userContext.getUserName().toUpperCase();
		String ipAddress = userContext.getIpAddress();
		String reqWithHeader = prependHeader(req, racfId, officeId, techId,
				username, ipAddress);
		TextMessage message = null;
		message = session.createTextMessage(reqWithHeader);
		LOGGER.info(" correlation id: " + corrId + " in: " + this);
		LOGGER.info(" racfId: " + racfId);
		message.setJMSCorrelationID(corrId);
		return message;
	}

	/**
	 * This function is used to add the mandatory header for all out-bound requests
	 * Total length of header is 248
	 * 
	 * @param message the message
	 * @param racfId TODO
	 * @param officeId TODO
	 * @param techId TODO
	 * @param username TODO
	 * 
	 * @return the string
	 */
	public String prependHeader(String message, String racfId, String officeId,
			String techId, String username, String ipAddress) {
		java.util.Calendar c = java.util.Calendar.getInstance();
		StringBuilder sb = new StringBuilder();
		sb.append("S1"); //002-002-HEADER TYPE 
		sb.append("01"); //002-004-VERSION 
		sb.append(Configuration.getInstance().getOperateMode()); //001-005-MODE 
		sb.append("S"); //001-006-TYPE OF CONNECTION 
		sb.append("DMV FIELD OFFICE              "); //030-036-BUSINESS PARTNER NAME 
		sb.append(ljustify(c.get(java.util.Calendar.YEAR), 4)
				+ ljustify(c.get(java.util.Calendar.MONTH) + 1, 2)
				+ ljustify(c.get(java.util.Calendar.DATE), 2)
				+ //008-044-DATE
				ljustify(c.get(java.util.Calendar.HOUR), 2)
				+ ljustify(c.get(java.util.Calendar.MINUTE), 2)
				+ ljustify(c.get(java.util.Calendar.SECOND), 2)); //006-050-TIME
		/**
		 * Old format replaced with new format using RECF-id, OfficeID,TechId and TAM User-ID and a filler
		 * Collectively replacing 71 bytes
		 * 
		 * 	sb.append(convertToEcsUserId("MWBRN1")); //032-082-USERID OF END USER 
		 * 	sb.append("165.153.2.198                          "); //039-121-CLIENT IP
		 */
		sb.append(pad(racfId, 8));//008-058-RACFID
		sb.append(pad(officeId, 3));//003-061-OFFICEID
		sb.append(pad(techId, 2));//002-063-TECHID
		sb.append(convertToEcsUserId(username));//032-095-RACFID
		//sb.append("                          ");//026-121-FILLER
		sb.append(pad(ipAddress, 26)); //IP ADDRESS WITH FILLER
		sb.append("        "); //008-129-CAMV MQGET
		sb.append("        "); //008-137-CAMV MQPUT
		sb.append("           "); //011-148-USER SAVE AREA
		sb.append("T"); //001-149-MESSAGE TYPE
		sb.append("O"); //001-150-MESSAGE SEGMENTATION IND
		sb.append("01"); //002-152-MESSAGE SEGMENTATION NUM
		sb.append("  "); //002-154-ERROR CODE
		sb.append("                "); //016-170-DB STATUS
		sb
				.append("                                                                             "); //077-247-DMV WORKAREA
		sb.append("."); //001-248-END OF HEADER
		sb.append(message);
		return sb.toString();
	}

	public void validateUserContext(IUserContext userContext)
			throws EcsMessageCreationException {
		String racfId = userContext.getRacfId();
		String officeId = userContext.getOfficeId();
		String techId = userContext.getTechId();
		String username = userContext.getUserName(); //TAM User-ID
		if (racfId == null) {
			throw new EcsMessageCreationException("racfId cannot be null!");
		}
		if (officeId == null) {
			throw new EcsMessageCreationException("officeId cannot be null!");
		}
		if (techId == null) {
			throw new EcsMessageCreationException("techId cannot be null!");
		}
		if (username == null) {
			throw new EcsMessageCreationException("username cannot be null!");
		}
		if (racfId.trim().equals("")) {
			throw new EcsMessageCreationException("racfId cannot be empty!");
		}
		if (officeId.trim().equals("")) {
			throw new EcsMessageCreationException("officeId cannot be empty!");
		}
		if (techId.trim().equals("")) {
			throw new EcsMessageCreationException("techId cannot be empty!");
		}
		if (username.trim().equals("")) {
			throw new EcsMessageCreationException("username cannot be empty!");
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsMessageCreator.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.15  2012/08/16 21:34:35  mwkzn
 *  Renamed corrId to camel case format.
 *
 *  Revision 1.14  2012/08/16 18:28:37  mwkfh
 *  retrieve env from Configuration
 *
 *  Revision 1.13  2012/08/15 17:42:46  mwkfh
 *  updated OPERATE_MODE initialization
 *
 *  Revision 1.12  2012/08/14 20:30:35  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.11  2011/10/07 16:45:13  mwkkc
 *  Clean up for RTCICS
 *
 *  Revision 1.10  2011/06/09 18:00:40  mwyxg1
 *  clean up
 *
 *  Revision 1.9  2011/03/23 23:46:57  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.8  2010/12/16 22:43:41  mwsyk1
 *  Added OPERATE_MODE for prod pre-pilot build - PRAMOD.
 *
 *  Revision 1.7  2010/12/12 17:47:45  mwpxp2
 *  Added logging of correlationId; made utility methods static which should be moved to a common superclass
 *
 *  Revision 1.6  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.5  2010/05/25 22:10:13  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.4  2010/03/22 23:20:44  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/02/18 02:03:16  mwskd2
 *  Changed the techId, officeId and userName to upper case.
 *
 *  Revision 1.2  2010/02/02 03:21:39  mwrrv3
 *  Added IP address functionality to support back-end.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/11/16 22:51:11  mwakg
 *  Sending Racf ID in uppercase
 *
 *  Revision 1.9  2009/11/05 18:52:07  mwpzs3
 *  addition of racfid,techid,username to header
 *
 *  Revision 1.8  2009/11/03 23:29:19  mwpzs3
 *  Move to new header using racfId, OfficeId, techId, TAM userid
 *
 *  Revision 1.7  2009/11/03 02:15:28  mwpxp2
 *  Added todo
 *
 *  Revision 1.6  2009/10/29 20:37:53  mwhxb3
 *  convertToEcsUserId is made public static
 *
 *  Revision 1.5  2009/10/14 18:53:03  mwhxb3
 *  method refactored
 *
 *  Revision 1.4  2009/10/13 18:04:55  mwhxb3
 *  updated comments.
 *
 *  Revision 1.3  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:50:56  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:53  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:42  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/25 18:45:33  mwpzs3
 *  Update comments
 *
 *  Revision 1.2  2009/09/10 00:35:10  mwpzs3
 *  Move to JMS 1.2
 *
 *  Revision 1.1  2009/09/08 02:00:56  mwpzs3
 *  Move to JMS 1.1
 *
 */
