/**
 * 
 */
package gov.ca.dmv.ease.ecs.listen.impl;


/**
 * Description: A class for representing a fixed length message field that is part of a
 * fixed length message format.
 * File: MessageField.java
 * Module:  gov.ca.dmv.ease.ecs.listen.impl
 * Created: Oct 19, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MessageField {
	
	/** the length of the field */
	private int length;
	/** the offset (zero-based position) of the field within the message */
	private int offset;
	
	/**
	 * constructor with length arg
	 * 
	 * @param length
	 */
	public MessageField(int length) {
		this.length = length;
	}
	
	/**
	 * @param offset
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}

	/**
	 * @return the length
	 */
	public int getLength() {
		return length;
	}

	/**
	 * @return the offset
	 */
	public int getOffset() {
		return offset;
	}
}


/**
 *  Modification History:
 *
 *  $Log: MessageField.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/04/17 22:26:38  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/03/30 21:05:07  mwsec2
 *  comments added
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:09  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */
