/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.dl.core.constants;

/**
 * Description: This is a constants file that holds the different modes in EASE
 * File: IEaseModes.java
 * Module:  gov.ca.dmv.ease.dl.core.constants
 * Created: Mar 16, 2010 
 * @author MWBXP5  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEaseModes {
	/** The Constant COUNTER. */
	String COUNTER = "C";
	/** The Constant MAIL. */
	String MAIL = "P";
	/** The Constant MANUAL. */
	String MANUAL = "M";
	/** The Constant TRAVEL_CREW. */
	String TRAVEL_CREW = "T";
	/** The Constant for DRIVING_LICNSE_WORK_TYPE */
	String DRIVING_LICNSE_WORK_TYPE = "D";
}

/**
 * Modification History:
 * 
 * $Log: IEaseModes.java,v $
 * Revision 1.1  2012/10/01 02:57:17  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.4  2012/08/15 23:17:43  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.3  2011/09/02 19:50:21  mwrrv3
 * Added DRIVING_LICNSE_WORK_TYPE.
 *
 */
