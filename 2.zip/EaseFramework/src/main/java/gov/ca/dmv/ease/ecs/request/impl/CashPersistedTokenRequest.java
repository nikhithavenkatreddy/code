/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsValidationException;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.IPersistedResponseToken;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: I am request to obtain a part or whole of the persisted message.
 * File: CashPersistedTokenRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request.impl
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CashPersistedTokenRequest extends AbstractEcsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1968383086987886638L;
	/** The end index. */
	private int endIndex = ECS_UNDEF_INT;
	/** The persistedToken. */
	private IPersistedResponseToken persistedToken;
	/** The retrieve all. */
	private boolean retrieveAll = false;
	/** The start index. */
	private int startIndex = ECS_UNDEF_INT;

	/**
	 * Instantiates a new cash persisted persistedToken request.
	 */
	public CashPersistedTokenRequest() {
		super();
	}

	/**
	 * Instantiates a new cash persisted persistedToken request.
	 * 
	 * @param aToken the a persistedToken
	 */
	public CashPersistedTokenRequest(IPersistedResponseToken aToken) {
		super();
		setPersistedToken(aToken);
	}

	/**
	 * Instantiates a new cash persisted token request.
	 * 
	 * @param anId the an id
	 */
	public CashPersistedTokenRequest(String anId) {
		super(anId);
	}

	/**
	 * Does retrieve all.
	 * 
	 * @return true, if successful
	 */
	public boolean doesRetrieveAll() {
		return retrieveAll;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public IEcsResponse execute() throws EcsServiceException {
		IEcsResponse returnIecsResponse = getEcsService().processRequest(this);
		return returnIecsResponse;
	}

	/**
	 * Gets the end index.
	 * 
	 * @return the end index
	 */
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	@Override
	public IMessageConverter getMessageConverter() {
		throw new EaseValidationException("provide a converter");
	}

	/**
	 * Gets the persisted response class name.
	 * 
	 * @return the persisted response class name
	 */
	public String getPersistedResponseClassName() {
		if (persistedToken == null) {
			throw new EcsValidationException("null persistedToken in " + this);
		}
		String returnString = getPersistedToken()
				.getPersistedResponseClassName();
		return returnString;
	}

	/**
	 * Gets the persisted response id.
	 * 
	 * @return the persisted response id
	 */
	public String getPersistedResponseId() {
		if (persistedToken == null) {
			throw new EcsValidationException("null persistedToken in " + this);
		}
		String returnString = getPersistedToken().getPersistedResponseId();
		return returnString;
	}

	/**
	 * Gets the persistedToken.
	 * 
	 * @return the persistedToken
	 */
	public IPersistedResponseToken getPersistedToken() {
		return persistedToken;
	}

	/**
	 * Gets the start index.
	 * 
	 * @return the start index
	 */
	public int getStartIndex() {
		return startIndex;
	}

	/**
	 * Retrieves the range.
	 * 
	 * @param aStart the a start
	 * @param anEnd the an end
	 */
	public void retrieveRange(int aStart, int anEnd) {
		retrieveAll = false;
		startIndex = aStart;
		endIndex = anEnd;
	}

	/**
	 * Retrieves the whole.
	 */
	public void retrieveWhole() {
		retrieveAll = true;
		startIndex = ECS_UNDEF_INT;
		endIndex = ECS_UNDEF_INT;
	}

	/**
	 * Sets the end index.
	 * 
	 * @param endIndex the new end index
	 */
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	/**
	 * Sets the persistedToken.
	 * 
	 * @param token the token
	 */
	public void setPersistedToken(IPersistedResponseToken token) {
		this.persistedToken = token;
	}

	/**
	 * Sets the retrieve all.
	 * 
	 * @param retrieveAll the new retrieve all
	 */
	public void setRetrieveAll(boolean retrieveAll) {
		this.retrieveAll = retrieveAll;
	}

	/**
	 * Sets the start index.
	 * 
	 * @param startIndex the new start index
	 */
	protected void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CashPersistedTokenRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/06/09 17:54:01  mwyxg1
 *  clean up
 *
 *  Revision 1.5  2010/09/14 18:29:10  mwkfh
 *  made EcsService non-static
 *
 *  Revision 1.4  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/05/25 22:10:51  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.2  2010/03/22 23:26:54  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.17  2009/10/14 20:47:07  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.16  2009/10/14 20:15:14  mwhxb3
 *  refactored the constant DCS_UNDEF_INT to ECS_UNDEF_INT
 *
 *  Revision 1.15  2009/10/13 21:00:13  mwhxb3
 *  updated comments.
 *
 *  Revision 1.14  2009/10/07 19:28:30  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.13  2009/10/07 03:33:42  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.12  2009/10/07 02:56:47  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.11  2009/10/06 21:53:05  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.10.2.2  2009/10/06 20:41:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.10.2.1  2009/10/06 20:28:40  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.10  2009/10/03 21:23:36  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.9  2009/10/01 18:35:01  mwpzs3
 *  commenting out validation on cashPersistedToken which is not yet implemented
 *
 *  Revision 1.8  2009/08/27 02:33:54  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.7  2009/08/22 20:25:51  mwpxp2
 *  Added getMessageConverter/0 implementation
 *
 *  Revision 1.6  2009/08/10 23:05:45  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.5  2009/07/30 01:27:51  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.4  2009/07/27 18:56:40  mwpxp2
 *  Fixed constant refs
 *
 *  Revision 1.3  2009/07/27 18:28:59  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/16 02:17:52  mwpxp2
 *  Removed empty getUserContext method
 *
 *  Revision 1.1  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.6  2009-05-20 18:29:10  ppalacz
 *  Changed visibility of doesRetrieveAll/0 to public
 *
 *  Revision 1.5  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.4  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.3  2009-05-13 20:28:42  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-05-13 02:20:48  ppalacz
 *  Added utility calls
 *
 *  Revision 1.1  2009-05-12 22:20:14  ppalacz
 *  Initial
 *
*/
