/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code;

import gov.ca.dmv.ease.fw.IWithValidityPeriod;

/**
 * Description: I am interface for code set element implementations 
 * Note: the current method names follow the existing gov.ca.dmv.ease.bo.code.impl.CodeSetElement
 * File: ICodeSetElement.java
 * Module:  gov.ca.dmv.ease.bo.code
 * Created: Aug 4, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICodeSetElement extends IWithValidityPeriod {
	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	String getCode();

	/**
	 * Gets the Code Set.
	 * 
	 * @return the Code Set
	 */
	ICodeSet getCodeSet();

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	String getDescription();

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	String getName();

	/**
	 * Checks for code equal to.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasCodeEqualTo(String aCode);

	/**
	 * Checks for code equal to any of.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasCodeEqualToAnyOf(String... aCode);

	/**
	 * Checks for code not equal to.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasCodeNotEqualTo(String aCode);

	/**
	 * Checks for code not equal to any of.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasCodeNotEqualToAnyOf(String... aCode);

	/**
	 * Checks for name equal to.
	 * 
	 * @param aName the a name
	 * 
	 * @return true, if successful
	 */
	boolean hasNameEqualTo(String aName);

	/**
	 * Sets the Code.
	 * 
	 * @param code the Code
	 */
	void setCode(String code);

	/**
	 * Sets the codeset name
	 * 
	 * @param codeset the Code Set
	 */
	void setCodeSet(ICodeSet codeset);

	/**
	 * Sets the Description.
	 * 
	 * @param description the Description
	 */
	void setDescription(String description);

	/**
	 * Sets the Name.
	 * 
	 * @param name the name
	 */
	void setName(String name);
}
/**
 *  Modification History:
 *
 *  $Log: ICodeSetElement.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/07/08 01:55:09  mwpxp2
 *  Cleaned up
 *
 *  Revision 1.4  2010/05/26 00:33:59  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.3  2010/05/25 23:54:16  mwpxp2
 *  Added a handful of convenience boolean methods
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/03 21:06:35  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/13 20:45:40  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.2.2.2  2009/09/13 18:45:27  mwakg
 *  Fixed codeset service to load from DB instead of XML. Showing code as default instead of description. Only when needed description is appended for SelectItem in codeset
 *
 *  Revision 1.2.2.1  2009/09/13 01:34:29  mwakg
 *  Reading data from Database instead of XML for CodeSetService
 *
 *  Revision 1.2  2009/08/27 02:22:40  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/08/04 16:46:30  mwpxp2
 *  Initial
 *
 */
