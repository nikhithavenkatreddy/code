package gov.ca.dmv.ease.tus.docs.constants;

/**
 * Description: This interface contains the document service constants/codes 
 * File: IDocumentServiceConstants.java
 * Module:  gov.ca.dmv.ease.tus.docs.constants
 * Created: Aug 22, 2009 
 * @author MWJXA11  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IDocumentServiceConstants {
	/** The CDLIS Receipt generated. */
	String CDLIS_RECEIPT_GENERATED = "CDLIS Receipt is generated";
	/** The CDLIS Receipt not generated. */
	String CDLIS_RECEIPT_GENERATION_FAILED = "CDLIS Receipt is not generated";
	/** The CDLIS Receipt not printed. */
	String CDLIS_RECEIPT_PRINT_FAILED = "CDLIS Receipt is generated, but not printed";
	/** The CDLIS Receipt printed. */
	String CDLIS_RECEIPT_PRINTED = "CDLIS Receipt is generated and printed";
	/** The invalid CDLIS_PDPS records. */
	String INVALID_CDLIS_PDPS_RECORDS = "Invalid CDLIS Records object";
	/** The invalid DL Application. */
	String INVALID_DL_APPLICATION = "Invalid DlApplication Object";
	/** The invalid Invoice. */
	String INVALID_INVOICE = "Invalid Invoice object";
	/** The invalid INVALID_PERSON. */
	String INVALID_PERSON = "Invalid Person Object";
	/** The invalid User Context. */
	String INVALID_USER_CONTEXT = "Invalid User Context Object";
	/** The Organ Donor Receipt generated. */
	String ORGAN_DONOR_RECEIPT_GENERATED = "Organ Donor Receipt is generated";
	/** The Organ Donor Receipt not generated. */
	String ORGAN_DONOR_RECEIPT_GENERATION_FAILED = "Organ Donor Receipt is not generated";
	/** The Organ Donor Receipt not printed. */
	String ORGAN_DONOR_RECEIPT_PRINT_FAILED = "Organ Donor Receipt is generated, but not printed";
	/** The Organ Donor Receipt printed. */
	String ORGAN_DONOR_RECEIPT_PRINTED = "Organ Donor Receipt is generated and printed";
	/** The Payment Receipt generated. */
	String PAYMENT_RECEIPT_GENERATED = "Payment Receipt is generated";
	/** The Payment Receipt not generated. */
	String PAYMENT_RECEIPT_GENERATION_FAILED = "Payment Receipt is not generated";
	/** The Payment Receipt not printed. */
	String PAYMENT_RECEIPT_PRINT_FAILED = "Payment Receipt is generated, but not printed";
	/** The Payment Receipt printed. */
	String PAYMENT_RECEIPT_PRINTED = "Payment Receipt is generated and printed";
	/** Processed successfully. */
	String PROCESSSED_SUCCESSFULLY = "Document Generation request processed successfully";
	/** The valid CDLIS receipt request. */
	String VALID_CDLIS_RECEIPT_REQUEST = "Valid CDLIS Receipt Request";
	/** The valid Organ Donor receipt request. */
	String VALID_ORGAN_DONOR_RECEIPT_REQUEST = "Valid Organ Donor Receipt Request";
	/** The valid Payment receipt request. */
	String VALID_PAYMENT_RECEIPT_REQUEST = "Valid Payment Receipt Request";
	/** The valid Voter Registration receipt request. */
	String VALID_VOTER_REGISTRATION_RECEIPT_REQUEST = "Valid Voter Registration Receipt Request";
	/** The Voter Registration receipt generated. */
	String VOTER_REGISTRATION_RECEIPT_GENERATED = "Voter Registration Receipt is generated";
	/** The Voter Registration receipt not generated. */
	String VOTER_REGISTRATION_RECEIPT_GENERATION_FAILED = "Voter Registration Receipt is not generated";
	/** The Voter Registration receipt not printed. */
	String VOTER_REGISTRATION_RECEIPT_PRINT_FAILED = "Voter Registration Receipt is generated, but not printed";
	/** The Voter Registration receipt printed. */
	String VOTER_REGISTRATION_RECEIPT_PRINTED = "Voter Registration Receipt is generated and printed";
}
/**
 *  Modification History:
 *
 *  $Log: IDocumentServiceConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.22.1  2010/06/20 18:07:00  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/16 02:01:35  mwhxb3
 *  Added INVALID_DL_APPLICATION.
 *
 *  Revision 1.2  2010/06/16 01:59:57  mwhxb3
 *  Added INVALID_PERSON.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/16 01:36:32  mwhxa2
 *  Added valid comments
 *
 *  Revision 1.3  2009/10/03 21:32:48  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/08/27 20:11:52  mwjxa11
 *  Fixed the functionality issues introduced during code refactoring.
 *
 *  Revision 1.1  2009/08/27 04:40:28  mwpxp2
 *  Moved in from documetn service project and package-restructured
 *
 *  Revision 1.1  2009/08/26 22:00:53  mwpxp2
 *  Replaces DocumentServiceConstants
 *
 */
