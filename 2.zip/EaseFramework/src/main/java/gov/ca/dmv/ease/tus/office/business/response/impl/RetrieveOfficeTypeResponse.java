/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response.impl;

import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeTypeResponse;

import java.util.List;

/**
 * Description: I am an RetrieveOfficeTypeResponse response
 * 
 * File: RetrieveOfficeTypeResponse.java
 * Module:  gov.ca.dmv.ease.tus.office.business.response.impl
 * Created: Jan 11, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveOfficeTypeResponse extends
			OfficeBusinessServiceResponse implements IRetrieveOfficeTypeResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5091012995786070403L;
	
	private List<String> officeTypeList;

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveOfficeTypeResponse(List<String> officeTypeList) {
		super();
		
		this.officeTypeList = officeTypeList;
	}	

	/**
	 * Get Processing Allowed List.
	 * @return
	 */
	public List<String> getOfficeTypeList()  {
		return this.officeTypeList;
	}
	
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
