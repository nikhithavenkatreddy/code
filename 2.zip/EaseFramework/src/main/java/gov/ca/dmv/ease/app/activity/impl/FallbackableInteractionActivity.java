/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: I am type of interaction activity and I have knowledge how to fallback in a BP
 * File: FallbackableInteractionActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Jun 26, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FallbackableInteractionActivity extends InteractionActivity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1947196408593505184L;

	/**
	 * Finds the default target for fallback action. Subclasses can override this provide different implementation
	 * @param processContext
	 * @return
	 */
	protected Activity getFallbackTargetActivity(ProcessContext processContext) {
		return processContext.getExecutionSyncPointActivity();
	}

	/**
	 * Finds the context for a fallback action. Subclasses can override this to provide different implementation
	 * @param processContext
	 * @return
	 */
	protected ProcessContext getFallbackTargetContext(
			ProcessContext processContext) {
		return processContext.getExecutionSyncPointContext();
	}

	/**
	 * Override this method to compensates business process context because of fallback invocation, 
	 * or invoke validation rules related to fallback action.
	 * 
	 * @param processContext
	 */
	protected void postFallBackCondition(ProcessContext processContext) {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.InteractionActivity#resume(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	public void resume(ProcessContext processContext) {
		if (!processContext.getSelectedAction().equals(
				getActionsRegistry().getAction(IActionNamesConstants.FALLBACK))) {
			super.resume(processContext);
		}
		else {
			postFallBackCondition(processContext);
			Activity fallbackTarget = getFallbackTargetActivity(processContext);
			ProcessContext fallbackTargetProcessContext = getFallbackTargetContext(processContext);
			// if falling back within the same process
			if (processContext.isSameProcess(fallbackTargetProcessContext)) {
				fallbackTarget.execute(processContext);
			}
			else {
				ProcessContext parentContext = ((ChildContext) processContext)
						.getParentProcessContext();
				// if falling back to the parent process
				if (fallbackTargetProcessContext.getProcessId().equals(parentContext.getProcessId())) {
					processContext.end();
				// otherwise falling back to a sync point within a child process activity
				}
				else {
					((ChildContext) processContext)
							.getSyncPointSubprocessActivity().execute(
									processContext);
				}
			}
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: FallbackableInteractionActivity.java,v $
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.11  2011/01/13 19:49:59  mwsec2
 * fixed reported defect regarding context equality check
 *
 * Revision 1.10  2010/11/09 03:19:30  mwpxp2
 * Imports cleanup
 *
 * Revision 1.9  2010/09/23 21:24:17  mwyxg1
 * change compensateFallback to postFallBackCondition, this method can be override after invoking fallback action.
 *
 * Revision 1.8  2010/08/20 18:15:36  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.7  2010/08/10 22:24:42  mwsec2
 * isSameProcess method added
 *
 * Revision 1.6  2010/08/09 23:54:17  mwsec2
 * fallback functionality fixes
 *
 * Revision 1.5  2010/08/06 21:05:35  mwsec2
 * Modifications to support sub-to-sub process fallbacks
 *
 * Revision 1.4  2010/08/03 21:20:06  mwsec2
 * syncPoint enhancements
 *
 * Revision 1.3  2010/07/30 22:44:56  mwakg
 * Activities now register syncpoint activity and the processContext
 *
 * Revision 1.2  2010/07/29 14:21:42  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.1.2.4  2010/07/14 20:37:10  mwsec2
 * deleted extra comments
 *
 * Revision 1.1.2.3  2010/07/14 20:30:43  mwsec2
 * simplified how the current process is ended (in case of child-to-parent fallback)
 *
 * Revision 1.1.2.2  2010/07/06 21:39:51  mwsec2
 * added support for fallback to and from subprocesses
 *
 * Revision 1.1.2.1  2010/06/27 01:40:33  mwakg
 * Initial version
 *
 * 
 */
