/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

/**
 * Description: Concrete response to carry exception information; 
 * to be used in composite responses when avoiding of exception handling is desirable.
 * File: ExceptionResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: 16/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ExceptionResponse extends AbstractEcsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3760893785216419210L;
	/** The exception class name. */
	private String exceptionClassName;
	/** The exception message. */
	private String exceptionMessage;

	/**
	 * Instantiates a new exception response.
	 */
	public ExceptionResponse() {
		super();
	}

	/**
	 * Instantiates a new exception response.
	 * 
	 * @param ex the exception
	 */
	public ExceptionResponse(Exception ex) {
		super();
	}

	/**
	 * Gets the exception class name.
	 * 
	 * @return exceptionClassName the exception class name
	 */
	public String getExceptionClassName() {
		return exceptionClassName;
	}

	/**
	 * Gets the exception message.
	 * 
	 * @return exceptionMessage the exception message
	 */
	public String getExceptionMessage() {
		return exceptionMessage;
	}

	/**
	 * Sets the exception class name.
	 * 
	 * @param exceptionClassName the new exception class name
	 */
	public void setExceptionClassName(String exceptionClassName) {
		this.exceptionClassName = exceptionClassName;
	}

	/**
	 * Sets the exception message.
	 * 
	 * @param exceptionMessage the new exception message
	 */
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("exceptionClassName", exceptionClassName, anIndent,
				aBuilder);
		outputKeyValue("exceptionMessage", exceptionMessage, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ExceptionResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/14 18:17:10  mwhxb3
 *  updated comments
 *
 *  Revision 1.7  2009/10/06 21:54:08  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6.2.1  2009/10/06 20:28:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6  2009/10/01 16:29:47  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.5  2009/07/27 18:30:39  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.4  2009/07/27 18:02:17  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.3  2009/07/16 02:30:13  mwpxp2
 *  Bulk cleanup, incl javadoc and file decorations
 *
 *  Revision 1.2  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.3  2009-05-18 20:38:39  ppalacz
 *  Class comment modified
 *
 *  Revision 1.2  2009-05-18 20:36:51  ppalacz
 *  Changed superclass
 *
 *  Revision 1.1  2009-05-17 05:26:33  ppalacz
 *  Initial
 *
*/
