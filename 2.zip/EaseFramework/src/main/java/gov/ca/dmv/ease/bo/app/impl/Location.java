/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.app.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.io.Serializable;

/**
 * Description: This class represents the location information for EASE. 
 * This holds the IP Address in and the device hostname.  
 * Device hostname will be unique.  IP Address will contain some duplicates.  
 * Every native IP Address Record and Alias Record for a Neoware device should create a row.  
 * No printer rows will be created.  In the case of Alias Records, use the IP Address of the original device.
 * File: Location.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Jun 7, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Location extends BusinessObject implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5440631378682584074L;
	/** The station ip address. */
	private String ipAddress;
	/** The l1 Server Code */
	private String l1ServerCode;
	/** The l1 Server Suffix */
	private String l1ServerSuffix;
	/** The office id like 591 */
	private String officeId;
	/** The office processor Mnemonic like bx, by, jb .. */
	private String officeMnemonic;
	/** The station id like bx1, bx2, jbd */
	private Station station;

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	public String getL1ServerCode() {
		return l1ServerCode;
	}

	public String getL1ServerSuffix() {
		return l1ServerSuffix;
	}

	/**
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * @return the officeMnemonic
	 */
	public String getOfficeMnemonic() {
		return officeMnemonic;
	}

	/**
	 * @return the station
	 */
	public Station getStation() {
		return station;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public void setL1ServerCode(String serverCode) {
		l1ServerCode = serverCode;
	}

	public void setL1ServerSuffix(String serverSuffix) {
		l1ServerSuffix = serverSuffix;
	}

	/**
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * @param officeMnemonic the officeMnemonic to set
	 */
	public void setOfficeMnemonic(String officeMnemonic) {
		this.officeMnemonic = officeMnemonic;
	}

	/**
	 * @param station the station to set
	 */
	public void setStation(Station station) {
		this.station = station;
	}
}
/**
 *  Modification History:
 *
 *  $Log: Location.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/01/15 07:02:54  mwpxp2
 *  Cleanup for testing
 *
 *  Revision 1.3  2010/11/13 03:24:19  mwvxm6
 *  Updates to implement  new Office Id mapping for L1 Server processing
 *
 *  Revision 1.2  2010/07/08 01:53:42  mwpxp2
 *  Added footer; cleaned up
 *
 */
