/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.converter;

import gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest;

/**
 * Description: This is the Interface for Document Converters.
 * File: IDocumentConverter.java
 * Module:  gov.ca.dmv.ease.tus.print.converter
 * Created: Feb 9, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IDocumentConverter {
	/**
	 * This method converts Print Service Request to Document Binding.
	 * 
	 * @param request the Print service request
	 * 
	 * @return XML String
	 */
	public String convertToCompleteDocumentBinding(PrintServiceRequest request);

	/**
	 * This method converts the input PrintServiceRequest into XML String.
	 * 
	 * @param request the Print service request
	 * @return XML String
	 */
	public String convertToDocumentBinding(PrintServiceRequest request);
}
/**
 *  Modification History:
 * 
 *  $Log: IDocumentConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2010/09/01 19:07:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2010/07/12 23:03:03  mwhxa2
 *  updated java docs
 *
 *  Revision 1.8  2010/07/12 18:54:05  mwrsk
 *  Add capability for composite request
 *
 *  Revision 1.7  2010/05/07 23:52:20  mwhxb3
 *  Removed extending from IMessageConverter.
 *
 *  Revision 1.6  2010/05/07 23:10:35  mwhxb3
 *  Extends IMessageConverter
 *
 *  Revision 1.5  2010/05/04 00:55:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/03 16:17:10  mwrsk
 *  Changed from convertToDocument to convertToDocumentBinding
 *
 *  Revision 1.3  2010/04/27 18:04:35  mwrsk
 *  Changes related to DocumentConverters extending from AbstractDocumentConverter
 *
 *  Revision 1.2  2010/03/22 23:39:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/02/09 21:22:14  mwhxa2
 *  adding interface for document converters
 *
*/
