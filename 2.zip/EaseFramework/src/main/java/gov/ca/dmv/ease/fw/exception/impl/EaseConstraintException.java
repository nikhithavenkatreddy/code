/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

// TODO: Auto-generated Javadoc
/**
 * Description: I am abstract exception for constraint violations
 * See my concrete subclasses
 * File: EaseConstraintException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EaseConstraintException extends EaseOperationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3566086217946936201L;

	/**
	 * Instantiates a new ease constraint exception.
	 */
	public EaseConstraintException() {
		super();
	}

	/**
	 * @param message
	 */
	public EaseConstraintException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public EaseConstraintException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public EaseConstraintException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseConstraintException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
