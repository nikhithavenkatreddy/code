/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.action.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;

import java.io.Serializable;

/**
 * Description: I represent a action that the user had asked for 
 * 
 *  //FIXME - byPassValidations and its usage is problematic
 *  //FIXME - cnaBypassAction and its usage is problematic
 *  //FIXME - enabled and its usage is problematic
 *  //TODO - this class should arguably have no other state than key and description ("name")
 *  //TODO - extract interface 
 *  //TODO - create a hierarchy of concrete actions?
 *  
 * File: ActionRequest.java
 * Module:  gov.ca.dmv.ease.app.action.impl
 * Created: Apr 8, 2009
 * @author MWAKG
 * @version $Revision: 1.2 $
 * Last Changed: Apr 8, 2009 3:09:40 PM
 * Last Changed By: MWAKG
 */
public class Action implements IActionNamesConstants, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3708176150624689221L;
	/** When true bypasses the validations. */
	private boolean byPassValidations = false;
	/** ByPassCNA Action. */
	private boolean cnaBypassAction = false;
	/** Action is Enable flag. */
	private boolean enabled = true;
	/** The key. */
	private String key;
	/** The name. */
	private String name;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Action other = (Action) obj;
		if (key == null) {
			if (other.key != null) {
				return false;
			}
		}
		else if (!key.equals(other.key)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		}
		else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the key.
	 * 
	 * @return the key
	 */
	public String getKey() {
		return key;
	}
	
	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	/**
	 * Checks if is adds the more.
	 *
	 * @return true, if is adds the more
	 */
	public boolean isAddMore() {
		return getKey().equals(ADD_MORE);
	}
	
	/**
	 * Checks if is additional record action.
	 *
	 * @return true, if is additional record action
	 */
	public boolean isAdditionalRecordAction() {
		return getKey().equals(ADDITIONAL_RECORD);
	}
	
	/**
	 * Checks if is another form.
	 *
	 * @return true, if is another form
	 */
	public boolean isAnotherForm() {
		return getKey().equals(ANOTHER_FORM);
	}
	
	/**
	 * Checks if is AnotherTry.
	 * 
	 * @return true, if is AnotherTry
	 */
	public boolean isAnotherTry() {
		return getKey().equals(ANOTHER_TRY);
	}
	
	/**
	 * Checks if is browse.
	 * 
	 * @return true, if is browse
	 */
	public boolean isBrowse() {
		return getKey().equals(BROWSE_ACTION);
	}
	
	/**
	 * Checks if is BrowseBwd.
	 * 
	 * @return true, if is BrowseBwd
	 */
	public boolean isBrowseBwd() {
		return getKey().equals(BROWSE_BWD_ACTION);
	}
	
	/**
	 * Checks if is BrowseFwd.
	 * 
	 * @return true, if is BrowseFwd
	 */
	public boolean isBrowseFwd() {
		return getKey().equals(BROWSE_FWD_ACTION);
	}
	
	/**
	 * Checks if is by pass validations.
	 *
	 * @return the byPassValidations
	 */
	public boolean isByPassValidations() {
		return byPassValidations;
	}
	
	/**
	 * Checks if is Cancel.
	 * 
	 * @return true, if is Cancel
	 */
	public boolean isCancel() {
		return getKey().equals(CANCEL_ACTION);
	}
	
	/**
	 * Checks if is cna bypass.
	 *
	 * @return true, if is cna bypass
	 */
	public boolean isCnaBypass() {
		return getKey().equals(CNA_BYPASS);
	}
	
	/**
	 * Checks if is cna bypass action.
	 *
	 * @return the cnaBypassAction
	 */
	public boolean isCnaBypassAction() {
		return cnaBypassAction;
	}
	
	/**
	 * Checks if is corrections.
	 * 
	 * @return true, if is corrections
	 */
	public boolean isCorrections() {
		return getKey().equals(CORRECTIONS_ACTION);
	}
	
	/**
	 * Checks if is counselorinq.
	 * 
	 * @return true, if is counselorinq.
	 */
	public boolean isCounselorinq() {
		return getKey().equals(COUNSELOR_INQUIRY);
	}
	
	/**
	 * Checks if is daf update.
	 *
	 * @return true, if is daf update
	 */
	public boolean isDafUpdate() {
		return getKey().equals(DAF_UPDATE_ACTION);
	}
	
	/**
	 * Checks if is Display.
	 * 
	 * @return true, if is Display
	 */
	public boolean isDisplay() {
		return getKey().equals(DISPLAY_ACTION);
	}
	
	/**
	 * Checks if is enabled.
	 *
	 * @return the enabled
	 */
	public boolean isEnabled() {
		return enabled;
	}
	
	/**
	 * Checks if is enter.
	 * 
	 * @return true, if is enter
	 */
	public boolean isEnter() {
		return getKey().equals(ENTER_ACTION);
	}
	
	/**
	 * Checks if is fallback.
	 * 
	 * @return true, if is fallback
	 */
	public boolean isFallback() {
		return getKey().equals(FALLBACK);
	}
	
	/**
	 * Checks if is ModifyAppInfo.
	 * 
	 * @return true, if is ModifyAppInfo
	 */
	public boolean isModifyAppInfo() {
		return getKey().equals(MODIFY_APP_INFO);
	}
	
	/**
	 * Checks if is NoMoreTries.
	 * 
	 * @return true, if is NoMoreTries
	 */
	public boolean isNoMoreTries() {
		return getKey().equals(NO_MORE_TRIES);
	}
	
	/**
	 * Checks if is pay action.
	 *
	 * @return true, if is pay action
	 */
	public boolean isPayAction() {
		return getKey().equals(PAY);
	}
	
	/**
	 * Checks if is prints the test results.
	 *
	 * @return true, if is prints the test results
	 */
	public boolean isPrintTestResults() {
		return getKey().equals(PRINT_TEST_RESULTS);
	}
	
	/**
	 * Checks if is Purge.
	 * 
	 * @return true, if is Purge
	 */
	public boolean isPurge() {
		return getKey().equals(PURGE_ACTION);
	}
	
	/**
	 * Checks if is ReceiptOnly.
	 * 
	 * @return true, if is ReceiptOnly
	 */
	public boolean isReceiptOnly() {
		return getKey().equals(RECEIPT_ONLY);
	}
	
	/**
	 * Checks if is reset.
	 * 
	 * @return true, if is reset
	 */
	public boolean isReset() {
		return getKey().equals(RESET);
	}
	
	/**
	 * Checks if is Restart.
	 * 
	 * @return true, if is Restart
	 */
	public boolean isRestart() {
		return getKey().equals(RESTART_ACTION);
	}
	
	/**
	 * Checks if action is Retain Data.
	 * 
	 * @return true, if is Retain Data.
	 */
	public boolean isRetainData() {
		return getKey().equals(RETAIN_DATA_ACTION);
	}
	
	/**
	 * Checks if it is Serve_All.
	 *
	 * @return true, if it is Serve_All
	 */
	public boolean isServeAll() {
		return getKey().equals(SERVE_ALL);
	}
	
	/**
	 * Checks if is update only action.
	 *
	 * @return true, if is update only action
	 */
	public boolean isUpdateOnlyAction() {
		return getKey().equals(UPDATE_ONLY_ACTION);
	}
	
	/**
	 * Checks if is update pending.
	 *
	 * @return true, if is update pending
	 */
	public boolean isUpdatePending() {
		return getKey().equals(UPDATE_PENDING_ACTION);
	}
	
	/**
	 * Checks if is collect data.
	 *
	 * @return true, if is collect data
	 */
	public boolean isCollectData() {
		return getKey().equals(COLLECT_DATA_ACTION);
	}
	
	/**
	 * Checks if is customer copy action.
	 *
	 * @return true, if is customer copy action
	 */
	public boolean isCustomerCopyAction() {
		return getKey().equals(CUSTOMER_COPY_ACTION);
	}
	
	/**
	 * Checks if is new request.
	 * 
	 * @return true, if is new request
	 */
	public boolean isNewRequest() {
		return getKey().equals(NEW_REQUEST_ACTION);
	}
	
	/**
	 * Checks if is new request.
	 * 
	 * @return true, if is new request
	 */
	public boolean isAltPrint() {
		return getKey().equals(ALT_PRINT);
	}
	
	/**
	 * Sets the by pass validations.
	 *
	 * @param byPassValidations the byPassValidations to set
	 */
	public void setByPassValidations(boolean byPassValidations) {
		this.byPassValidations = byPassValidations;
	}
	
	/**
	 * Sets the cna bypass action.
	 *
	 * @param cnaBypassAction the cnaBypassAction to set
	 */
	public void setCnaBypassAction(boolean cnaBypassAction) {
		this.cnaBypassAction = cnaBypassAction;
	}
	
	/**
	 * Sets the enabled.
	 *
	 * @param enabled the enabled to set
	 */
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	/**
	 * Sets the key.
	 * 
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	
	/**
	 * Sets the name.
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getKey() + " - " + getName();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Action.java,v $
 *  Revision 1.2  2012/10/17 00:26:30  mwhys
 *  Added isCustomerCopyAction().
 *
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.31  2012/04/24 21:50:20  mwhys
 *  Added isAdditionalRecordAction().
 *
 *  Revision 1.30  2011/12/14 22:53:50  mwhys
 *  Added isCnaBypass().
 *
 *  Revision 1.29  2011/06/01 23:01:46  mwrrv3
 *  Added code for alternate printer.
 *
 *  Revision 1.28  2011/05/19 17:11:59  mwrrv3
 *  Added isRetainData() method for Retain Data action.
 *
 *  Revision 1.27  2011/05/12 22:40:11  mwyxg1
 *  add NEW_REQUEST_ACTION
 *
 *  Revision 1.26  2011/01/30 20:59:20  mwrka1
 *  UPDATED
 *
 *  Revision 1.25  2011/01/15 02:00:18  mwpxp2
 *  Cleanup
 *
 *  Revision 1.24  2011/01/07 20:02:58  mwrka1
 *  added action boolean methods to sync with other methods
 *
 *  Revision 1.23  2011/01/03 19:22:26  mwrrv3
 *  Added isModifyAppInfo method.
 *
 *  Revision 1.22  2010/12/07 00:56:07  mwhys
 *  Added isAddMore().
 *
 *  Revision 1.21  2010/12/03 17:32:01  mwhys
 *  Added isAnotherForm().
 *
 *  Revision 1.20  2010/12/01 00:44:09  mwtjc1
 *  isBrowse added
 *
 *  Revision 1.19  2010/11/18 19:40:14  mwhys
 *  Added isReceiptOnly() method.
 *
 *  Revision 1.18  2010/10/29 16:13:40  mwtjc1
 *  isReset added
 *
 *  Revision 1.17  2010/10/22 22:24:59  mwrxn3
 *  Added Serve_All Action
 *
 *  Revision 1.16  2010/10/21 22:10:35  mwhys
 *  Added isCounselorinq() method.
 *
 *  Revision 1.15  2010/09/29 16:06:09  mwhys
 *  Added isDisplay() and isPurge() methods.
 *
 *  Revision 1.14  2010/09/29 15:50:02  mwhys
 *  Added isBrowseFwd() and isBrowseBwd() methods.
 *
 *  Revision 1.13  2010/09/28 23:14:34  mwhys
 *  Added isRestart, isCancel and isNoMoreTries methods.
 *
 *  Revision 1.12  2010/09/28 21:46:25  mwhys
 *  Added isAnotherTry() method.
 *
 *  Revision 1.11  2010/09/24 18:29:02  mwhys
 *  Added isCorrections() method.
 *
 *  Revision 1.10  2010/09/17 20:56:19  mwpxp2
 *  Extended IActionNamesConstants; added fixmes and todos; added isEnter/0, isFallback/0
 *
 *  Revision 1.9  2010/09/01 18:55:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.8  2010/07/29 14:51:19  mwakg
 *  Added support for Cna. Merged code from Mike Seatris
 *
 *  Revision 1.7  2010/07/08 02:00:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/05/18 16:24:07  mwakg
 *  Added support for bypassing the Validation if necessary
 *
 *  Revision 1.5  2010/04/05 23:25:09  mwakg
 *  Overriden toString
 *
 *  Revision 1.4  2010/03/22 23:15:16  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/03/21 00:02:31  mwakg
 *  Refactored Action class.
 *
 *  Revision 1.2  2010/03/18 17:00:37  mwakg
 *  Removed instances of action classes and using generic Action class
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/08 01:21:14  mwyxg1
 *  Update comments
 *
 *  Revision 1.4  2009/10/03 20:56:04  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.9  2009/09/14 23:31:04  mwakg
 *  Overridden equals method
 *
 *  Revision 1.8  2009/09/03 04:11:36  mwjjl7
 *  refactor for action handling specification
 *
 *  Revision 1.7  2009/09/03 01:55:56  mwjjl7
 *  return simple class name
 *
 *  Revision 1.6  2009/08/05 17:00:52  mwsmg6
 *  moved ProcessContext to ...context package
 *
 *  Revision 1.5  2009/07/22 21:46:26  mwpxm2
 *  refactor
 *
 *  Revision 1.4  2009/07/22 16:51:24  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.3  2009/07/16 00:44:49  mwpxm2
 *  Updated by UI
 *
 *  Revision 1.1  2009/04/08 3:09:40 PM  mwakg
 *  Initial commit
 *
*/
