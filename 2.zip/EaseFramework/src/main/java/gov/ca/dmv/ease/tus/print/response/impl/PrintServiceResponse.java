/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;
import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;
import gov.ca.dmv.ease.tus.print.response.IPrintServiceResponse;

import java.util.Date;

/**
 * Description: PrintServiceResponse class //FIXME
 * //TODO this looks like an abstract class without being defined as one
 * 
 * File: PrintServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response.impl
 * Created: Aug 05, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PrintServiceResponse extends AbstractResponse implements
		IPrintServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5210075787151450236L;
	//TODO Need to move to ECS Constants file
	/** The Success Status Code. */
	public static final String SUCCESS_STATUS_CODE = "0";
	/** The HP OS Print Job Id. */
	private String clientJobId;
	/** The Print Execution Status. */
	private String printExecutionStatus;
	/** The requested time. */
	private Date requestedTime;
	private IPrintServiceRequest request;

	/**
	 * Constructor.
	 */
	@Deprecated
	public PrintServiceResponse() {
		// Empty Constructor
	}

	/**
	 * Instantiates a new Print Service Response.
	 * 
	 * @param errorCollector the Error Messages
	 */
	public PrintServiceResponse(IErrorCollector errorCollector) {
		setErrorCollector(errorCollector);
	}

	/**
	 * Instantiates a new Print Service Response.
	 * 
	 * @param clientJobId the Client Job Id
	 */
	public PrintServiceResponse(String clientJobId) {
		setClientJobId(clientJobId);
	}

	public PrintServiceResponse(String clientJobId, Date requestedTime) {
		setClientJobId(clientJobId);
		setRequestedTime(requestedTime);
	}

	/**
	 * Instantiates a new Print Service Response.
	 * 
	 * @param clientJobId the Client Job Id
	 * @param printExecutionStatus the Print Execution Status
	 */
	public PrintServiceResponse(String clientJobId, String printExecutionStatus) {
		setClientJobId(clientJobId);
		setPrintExecutionStatus(printExecutionStatus);
	}

	/**
	 * Instantiates a new Print Service Response.
	 * 
	 * @param e the Exception
	 */
	public PrintServiceResponse(Throwable e) {
		if (getErrorCollector() == null) {
			setErrorCollector(new ErrorCollector());
		}
		getErrorCollector().register(e);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.response.impl.IPrintServiceResponse#getClientJobId()
	 */
	public String getClientJobId() {
		return clientJobId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.response.impl.IPrintServiceResponse#getPrintExecutionStatus()
	 */
	public String getPrintExecutionStatus() {
		return printExecutionStatus;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.response.impl.IPrintServiceResponse#getRequestedTime()
	 */
	public Date getRequestedTime() {
		return requestedTime;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.response.impl.IPrintServiceResponse#isPrintExecuted()
	 */
	public boolean isPrintExecuted() {
		return (!hasErrors() && isPrintSuccess()); //FIXME the implementation does not fit the method name
	}

	/**
	 * This method Checks for Successful Print Job Execution Status.
	 * 
	 * @return true if Success
	 */
	protected boolean isPrintSuccess() {
		return SUCCESS_STATUS_CODE.equals(getPrintExecutionStatus());
		//		return (!EaseUtil.isNullOrBlank(getPrintExecutionStatus()) &&  getPrintExecutionStatus().equals(SUCCESS_STATUS_CODE)) ? true
		//				: false;
	}

	/**
	 * Sets the Client Job Id.
	 * 
	 * @param clientJobId the clientJobId to set
	 */
	protected void setClientJobId(String aClientJobId) {
		clientJobId = aClientJobId;
	}

	/**
	 * Sets the Print Execution Status.
	 * 
	 * @param printExecutionStatus the printExecutionStatus to set
	 */
	protected void setPrintExecutionStatus(String aStatusString) {
		printExecutionStatus = aStatusString;
	}

	/**
	 * @param requestedTime the requestedTime to set
	 */
	public void setRequestedTime(Date aDate) {
		requestedTime = aDate;
	}

	/**
	 * @return the request
	 */
	public IPrintServiceRequest getRequest() {
		return request;
	}

	/**
	 * @param request the request to set
	 */
	protected void setRequest(IPrintServiceRequest aRequest) {
		request = aRequest;
	}
}
/**
 *  Modification History:
 *	
 *  $Log: PrintServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2012/08/25 17:57:15  mwpxp2
 *  Added link to original request using the "IPrintServiceRequest" instance var
 *
 *  Revision 1.9  2011/06/15 21:20:24  mwrka1
 *  update alternative printer functionalty
 *
 *  Revision 1.8  2010/12/02 00:14:58  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.7  2010/06/21 23:00:42  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.5.6.2  2010/06/20 18:06:54  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6  2010/06/07 17:24:09  mwpxp2
 *  Added fixme, todo; bulk cleanup
 *
 *  Revision 1.5  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 *  Revision 1.4  2010/03/22 23:40:20  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/02/04 22:51:14  mwhxa2
 *  Updated Print Service Response
 *
 *  Revision 1.2  2010/02/04 17:57:18  mwhxa2
 *  Extends SynchronousResponse
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/14 01:30:26  mwjxa11
 *  Refactored
 *
 *  Revision 1.8  2009/10/14 00:27:24  mwjxa11
 *  Refactored
 *
 *  Revision 1.7  2009/10/03 21:32:45  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/01 01:03:37  mwjxa11
 *  Removed the unused constructor.
 *
 *  Revision 1.5  2009/08/27 07:06:57  mwpxp2
 *  Hooked up isPrintExecuted to errorcollector; removed setMessage/1
 *
 *  Revision 1.4  2009/08/27 06:29:21  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 03:32:29  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/27 01:40:21  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.1  2009/08/10 21:10:38  mwjxa11
 *  Updated with PrintServiceExecutionStatus and Message details.
 *
 */
