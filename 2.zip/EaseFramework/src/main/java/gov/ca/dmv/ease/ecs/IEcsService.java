/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs;

import java.io.Serializable;

import gov.ca.dmv.ease.ecs.adaptor.impl.SpringBasedJmsAdaptor;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory;

/**
 * Description: Defines public interface for the ECS.
 * 
 *   
 * File: IEcsService.java
 * Module:  gov.ca.dmv.ease.ecs
 * Created: 09/05/2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEcsService extends Serializable {

	/**
	 * Obtains an instance of  the persistence service.
	 *
	 * @return the persistence service
	 */
	IPersistenceServiceRequestFactory getPersistenceServiceRequestFactory();

	/**
	 * Processes AsynchronousEcsRequest.
	 *
	 * @param aRequest the a request
	 *
	 * @return the asynchronous response promise
	 */
	IEcsResponse processRequest(IEcsRequest aRequest);

	/**
	 * Sets the jms adaptor - for mock adaptors
	 *
	 * @param mockAdatptor the new jms adaptor
	 */
	void setJmsAdaptor(SpringBasedJmsAdaptor mockAdatptor);

	/**
	 * Processes AsynchronousResponsePromise.
	 *
	 * @param aPromise the a promise
	 *
	 * @return the IEcsResponse
	 */
	//IEcsResponse processRequest(IEcsResponsePromise aPromise);

	/**
	 * Processes CashPersistedTokenRequest.
	 *
	 * @param cashPersistedTokenRequest the cash persisted token request
	 *
	 * @return the   SynchronousResponse
	 */
//	IEcsResponse processRequest(
//			CashPersistedTokenRequest cashPersistedTokenRequest);

	/**
	 * Processes CashPromiseRequest.
	 *
	 * @param cashPromiseRequest the cash promise request
	 *
	 * @return the asynchronous response
	 */
	//IEcsResponse processRequest(CashPromiseRequest cashPromiseRequest);

	/**
	 * Processes CompositeRequest.
	 *
	 * @param aRequest the a request
	 *
	 * @return the composite response
	 */
	//ICompositeResponse processRequest(ICompositeRequest aRequest);

	/**
	 * Processes FireAndForgetEcsRequest.
	 *
	 * @param aRequest the a request
	 *
	 * @return the FireAndForgetReceipt
	 *
	 * @throws EaseServiceLayerException the service exception
	 */
	//IEcsResponse processRequest(FireAndForgetEcsRequest aRequest);

	/**
	 * Processes SynchronousEcsRequest.
	 *
	 * @param aRequest the a request
	 *
	 * @return the SynchronousResponse
	 *
	 * @throws EaseServiceLayerException the service exception
	 */
	//SynchronousResponse processRequest(SynchronousEcsRequest aRequest);
}
/**
 *  Modification History:
 *
 *  $Log: IEcsService.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/10/19 18:58:28  mwpxp2
 *  Extended Serializable
 *
 *  Revision 1.7  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.6.24.1  2011/09/26 05:23:35  mwpxp2
 *  Added setJmsAdaptor/1 for compatibility with a mock - to be revisited
 *
 *  Revision 1.6  2010/09/21 18:46:21  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< IEcsService.java
 *  Revision 1.5  2010/09/14 00:17:14  mwpxp2
 *  Import cleanup; added fixme
 *
=======
 *  Revision 1.4.4.2  2010/09/18 23:00:46  mwpxr4
 *  Removed concrete classes usage from interface.
 *
 *  Revision 1.4.4.1  2010/09/14 16:02:58  mwpxr4
 *  Added getter for peristence service request factory.
 *
>>>>>>> 1.4.4.2
 *  Revision 1.4  2010/09/13 04:39:50  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/03/23 20:30:45  mwpxp2
 *  Exception imports adjusted per exception tree mods
 *
 *  Revision 1.2  2010/03/22 23:19:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/13 17:59:10  mwhxb3
 *  updated comments.
 *
 *  Revision 1.2  2009/10/06 21:50:28  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:51  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:36  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6  2009/07/28 22:33:49  mwpxp2
 *  Fixed processRequest for asynch to return AsynchronousResponsePromise
 *
 *  Revision 1.5  2009/07/27 18:47:56  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.4  2009/07/27 18:27:20  mwpxp2
 *  Renamed to distinguish from IResponse in bo
 *
 *  Revision 1.3  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:02  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.15  2009-05-18 20:27:16  ppalacz
 *  Javadoc update
 *
 *  Revision 1.14  2009-05-18 15:49:17  ppalacz
 *  Javadoc update
 *
 *  Revision 1.13  2009-05-17 05:20:37  ppalacz
 *  Added support for composite requests
 *
 *  Revision 1.12  2009-05-15 02:31:08  ppalacz
 *  REvoed exceptions from signatures
 *
 *  Revision 1.11  2009-05-14 21:43:58  ppalacz
 *  Fixed return type for asynch request
 *
 *  Revision 1.10  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.9  2009-05-13 18:15:26  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.8  2009-05-12 22:18:13  ppalacz
 *  Added getPersistenceService/0
 *
 *  Revision 1.7  2009-05-11 19:43:31  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.6  2009-05-11 19:10:36  ppalacz
 *  Corrected misspelling
 *
 *  Revision 1.5  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.4  2009-05-11 17:40:26  mwpxp2
 *  Cleaned up
 *
 *
 *  Revision 1.1  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
*/
