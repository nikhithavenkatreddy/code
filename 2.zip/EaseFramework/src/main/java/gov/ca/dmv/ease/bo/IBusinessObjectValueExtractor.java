/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo;

import java.io.Serializable;

/**
 * Description: Interface for a mechanism to extract a value from a BO, e.g., reflection-based
 * File: IValueExtractor.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: 12/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IBusinessObjectValueExtractor extends Serializable {
	/** The EMPT y_ declaratio n_ metho d_ args. */
	Class <?>[] EMPTY_DECLARATION_METHOD_ARGS = new Class[] {};
	/** The EMPT y_ metho d_ args. */
	Object[] EMPTY_INVOCATION_METHOD_ARGS = new Object[] {};
	/** The GE t_ prefix. */
	String GET_PREFIX = "get";
	/** The SE t_ prefix. */
	String SET_PREFIX = "set";

	/**
	 * Gets the business object named.
	 * 
	 * @param aPropertyName the a property name
	 * @param aBo the a bo
	 * 
	 * @return the business object named
	 */
	IBusinessObject getBusinessObjectNamed(String aPropertyName,
			IBusinessObject aBo);

	/**
	 * Gets the integer value named.
	 * 
	 * @param aPropertyName the a property name
	 * @param aBo the a bo
	 * 
	 * @return the integer value named
	 */
	Integer getIntegerValueNamed(String aPropertyName, IBusinessObject aBo);

	/**
	 * Gets the object named.
	 * 
	 * @param aPropertyName the a property name
	 * @param aBo the a bo
	 * 
	 * @return the object named
	 */
	Object getObjectNamed(String aPropertyName, IBusinessObject aBo);

	/**
	 * Gets the string value named.
	 * 
	 * @param aPropertyName the a property name
	 * @param aBo the a bo
	 * 
	 * @return the string value named
	 */
	String getStringValueNamed(String aPropertyName, IBusinessObject aBo);
}
/**
 *  Modification History:
 * 
 *  $Log: IBusinessObjectValueExtractor.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/03/22 23:17:26  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:14:09  mwpxp2
 *  Moved to fw.bo
 *
 *
 *  Revision 1.1  2009-07-12 16:05:54  ppalacz
 *  Initial
 *
*/
