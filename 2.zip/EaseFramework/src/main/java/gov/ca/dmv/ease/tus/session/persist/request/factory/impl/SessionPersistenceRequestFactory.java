/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.request.factory.impl;

import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.session.persist.request.ISessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.factory.ISessionPersistenceRequestFactory;
import gov.ca.dmv.ease.tus.session.persist.request.impl.DeleteSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.impl.UpdateSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.service.ISessionPersistenceService;
import gov.ca.dmv.ease.tus.session.persist.service.impl.SessionPersistenceService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am the factory to create request for the session service.
 * File: SessionPersistenceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.factory.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:10:37 $
 * Last Changed By: $Author: mwhys $
 */
public class SessionPersistenceRequestFactory implements
		ISessionPersistenceRequestFactory {
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(SessionPersistenceRequestFactory.class);
	/** The SINGLETON. */
	private static SessionPersistenceRequestFactory SINGLETON;

	/**
	 * Gets the single instance of SessionPersistenceRequestFactory.
	 * 
	 * @return single instance of SessionPersistenceRequestFactory
	 */
	public static SessionPersistenceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new SessionPersistenceRequestFactory();
	}

	/** The session persistence service */
	private ISessionPersistenceService sessionPersistenceService;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.session.persist.request.factory.ISessionPersistenceRequestFactory#createDeleteSessionPersistenceRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public ISessionPersistenceRequest createDeleteSessionPersistenceRequest(
			IUserContext userContext, Session aSession) {
		DeleteSessionPersistenceRequest request = new DeleteSessionPersistenceRequest(
				userContext, aSession);
		request.setPersistenceService(getPersistenceService());
		return request;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.session.persist.request.factory.ISessionPersistenceRequestFactory#createUpdateSessionPersistenceRequest(gov.ca.dmv.ease.fw.process.IUserContext, gov.ca.dmv.ease.bo.app.impl.Session)
	 */
	public ISessionPersistenceRequest createUpdateSessionPersistenceRequest(
			IUserContext userContext, Session aSession) {
		UpdateSessionPersistenceRequest request = new UpdateSessionPersistenceRequest(
				userContext, aSession);
		request.setPersistenceService(getPersistenceService());
		return request;
	}

	/**
	 * Gets the session persistence service.
	 * 
	 * @return the session persistence service
	 */
	protected ISessionPersistenceService getPersistenceService() {
		LOGGER.debug("getPersistenceService() - start");
		ISessionPersistenceService persistenceService;
		if (sessionPersistenceService == null) {
			persistenceService = SessionPersistenceService.getInstance();
		}
		else {
			persistenceService = sessionPersistenceService;
		}
		LOGGER.debug("getPersistenceService() - end - return value="
				+ persistenceService);
		return persistenceService;
	}

	/**
	 * Sets the session persistence service for mocking.
	 * 
	 * @param the session persistence service
	 */
	public void setPersistenceService(
			ISessionPersistenceService persistenceService) {
		this.sessionPersistenceService = persistenceService;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionPersistenceRequestFactory.java,v $
 *  Revision 1.2  2012/12/13 00:10:37  mwhys
 *  Added createUpdateSessionPersistenceRequest
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/09/07 23:20:54  mwkfh
 *  added setPersistenceService for mocking
 *
 *  Revision 1.1  2012/01/06 19:34:48  mwkfh
 *  Initial
 *
 */
