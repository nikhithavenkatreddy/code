/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.request.impl;

import gov.ca.dmv.ease.app.session.request.ISessionServiceRequest;
import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.app.session.service.ISessionService;
import gov.ca.dmv.ease.app.session.service.impl.SessionService;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: I define the interface to PersistenceServiceRequest
 * 
 * File: SessionServiceRequest.java
 * Module:  gov.ca.dmv.ease.app.session.request.impl
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class SessionServiceRequest extends AbstractRequest implements
		ISessionServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3329863513533145368L;
	/** The session object. */
	private Session session;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public SessionServiceRequest(IUserContext userContext) {
		super(userContext);
	}

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public SessionServiceRequest(IUserContext userContext, Session aSession) {
		super(userContext);
		setSession(aSession);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.request.ISessionServiceRequest#execute()
	 */
	public abstract ISessionServiceResponse execute();

	/**
	 * Gets the service.
	 *
	 * @return the service
	 */
	protected ISessionService getService() {
		return SessionService.getInstance();
	}

	/**
	 * @return the session
	 */
	protected Session getSession() {
		return session;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.request.ISessionServiceRequest#getSessionObject()
	 */
	public Session getSessionObject() {
		return session;
	}

	/**
	 * @param session the session to set
	 */
	protected void setSession(Session session) {
		this.session = session;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		super.validateUsing(aCollector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				aCollector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/08/25 01:29:54  mwpxp2
 *  Added getService/0 to be overridden with mock in unit tests
 *
 *  Revision 1.3  2012/08/25 00:57:57  mwpxp2
 *  Added protected session setter and replaced direct accesses to the instance var in consstructor with tthe setter
 *
 *  Revision 1.2  2011/10/25 23:47:35  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.1  2010/09/30 17:49:53  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
