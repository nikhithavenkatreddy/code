/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.action;

import gov.ca.dmv.ease.app.action.impl.Action;

import java.util.List;

/**
 * Description: I am the class which holds the action of the application.
 * File: IActionsRegistry.java
 * Module:  gov.ca.dmv.ease.app.action
 * Created: Apr 15, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IActionsRegistry extends IActionNamesConstants {
	/**
	 * Gets the action.
	 * 
	 * @param actionKey the action key
	 * 
	 * @return the action
	 */
	public Action getAction(String actionKey);

	/**
	 * Gets the actions.
	 * 
	 * @return the actions
	 */
	public List <Action> getActions();
}
/**
 * Modification History:
 * 
 * $Log: IActionsRegistry.java,v $
 * Revision 1.1  2012/10/01 02:57:27  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.23  2010/09/17 20:44:41  mwpxp2
 * Refactored with IActionNamesConstants
 *
 * Revision 1.22  2010/09/14 17:52:15  mwyxg1
 * change ANOTHER_CO to ANOTHER_INSURANCE_COMPANY_ACTION
 *
 * Revision 1.21  2010/09/08 20:56:58  mwyxg1
 * add ANOTHER_CO
 *
 * Revision 1.20  2010/09/08 17:36:31  mwyxg1
 * add another try
 *
 * Revision 1.19  2010/09/04 21:19:31  mwtjc1
 * PAY added
 *
 * Revision 1.18  2010/09/04 21:14:32  mwtjc1
 * Update only and addtional record button added
 *
 * Revision 1.17  2010/09/01 18:55:54  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.16  2010/08/05 18:13:08  mwtjc1
 * DATBASE_STATUS_ACTION value changed
 *
 * Revision 1.15  2010/08/04 18:26:34  mwtjc1
 * CUSTOMER_COPY_ACTION added
 *
 * Revision 1.14  2010/08/04 16:47:09  mwtjc1
 * DATBASE_STATUS_ACTION added
 *
 * Revision 1.13  2010/07/27 00:16:22  mwcsj3
 * Added retain data action
 *
 * Revision 1.12  2010/07/23 14:49:47  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.11  2010/07/12 18:39:15  mwtjc1
 * BROWSE_ACTION added
 *
 * Revision 1.10  2010/07/08 02:00:55  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.9  2010/06/25 21:52:46  mwyxg1
 * add CNA_BYPASS
 *
 * Revision 1.8  2010/06/25 16:03:06  mwyxg1
 * add NO_MORE_TRIES
 *
 * Revision 1.7  2010/06/24 23:06:19  mwyxg1
 * add restart action
 *
 * Revision 1.6  2010/06/21 23:00:41  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.5.6.1  2010/06/08 01:18:27  mwakg
 * Added Transitions to SubBusinessProcess
 *
 * Revision 1.5  2010/05/07 00:18:39  mwrrv2
 * Added NAME_BD_CHANGE_ action
 *
 * Revision 1.4  2010/05/05 18:13:54  mwrrv2
 * Added more actions.
 *
 * Revision 1.3  2010/05/04 00:08:23  mwpxp2
 * Added two actual calls from the implementation
 *
 * Revision 1.2  2010/04/29 17:55:01  mwcsj3
 * Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 * Revision 1.1.2.4  2010/04/19 23:48:03  mwcsj3
 * Added BROWSE_FWD_ACTION string constant
 *
 * Revision 1.1.2.3  2010/04/19 15:58:49  mwcsj3
 * UPDATE_ALL_ACTION string is added
 *
 * Revision 1.1.2.2  2010/04/17 01:13:14  mwcsj3
 * Added Browse Bwd button action
 *
 * Revision 1.1.2.1  2010/04/15 22:13:15  mwakg
 * Integrated rules
 *
 * 
 */
