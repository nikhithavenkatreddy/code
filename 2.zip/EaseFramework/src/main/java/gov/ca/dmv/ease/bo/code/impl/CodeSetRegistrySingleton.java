/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Description: Singleton class for Code set Registry
 * File: CodeSetRegistrySingleton.java
 * Module:  gov.ca.dmv.ease.bo.code.impl
 * Created: Aug 4, 2009
 * @author MWBXP5
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2013/03/07 18:13:03 $
 * Last Changed By: $Author: mwkfh $
 */
public class CodeSetRegistrySingleton implements ICodeSetRegistrySingleton {
	/** The code set singleton. */
	private static CodeSetRegistrySingleton CODESET_SINGLETON = null;
	/** The Constant DEFAULT_SIZE. */
	private static final int DEFAULT_SIZE = 32;
	/** The Constant NO_CODESET_ELEMENTS. */
	private static final int NO_CODESET_ELEMENTS = 0;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8475464273480554556L;

	/**
	 * Gets the single instance of CodeSetRegistrySingleton.
	 * 
	 * @return single instance of CodeSetRegistrySingleton
	 */
	public static ICodeSetRegistrySingleton getInstance() {
		try {
			if (EaseApplicationContext.getApplicationContext() == null) {
				return getInitializedInstance();
			}
			else {
				//TODO: remove use of singleton bean after value loading changes
				return EaseApplicationContext.getCodeSetRegistrySingleton();
			}
		}
		catch (Exception e) {
			return getInitializedInstance();
		}
	}

	/**
	 * Gets the initialized instance.
	 *
	 * @return the initialized instance
	 */
	private static ICodeSetRegistrySingleton getInitializedInstance() {
		if (CODESET_SINGLETON == null) {
			CODESET_SINGLETON = new CodeSetRegistrySingleton();
		}
		return CODESET_SINGLETON;
	}

	/** The code sets. */
	private Map <String, ICodeSet> codeSets;

	/**
	 * Instantiates a new code set registry impl.
	 */
	private CodeSetRegistrySingleton() {
		codeSets = new ConcurrentHashMap <String, ICodeSet>();
	}

	/**
	 * @param codeSet
	 */
	private void cleanCodeSet(ICodeSet codeSet) {
		if (codeSet != null) {
			//Trim codeset name
			((CodeSet) codeSet).setCodeSetName(codeSet.getCodeSetName().trim());
			List <ICodeSetElement> elements = codeSet.getCodeSetElements();
			for (ICodeSetElement element : elements) {
				//Set CodeSet to CodeSetElement
				element.setCodeSet(codeSet);
				//Trim CodeSetElement code
				element.setCode(element.getCode().trim());
				//Trim CodeSetElement name
				element.setName(element.getName().trim());
				//Trim CodeSetElement description
				element.setDescription(element.getDescription().trim());
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#getAllCodeSets()
	 */
	public List <ICodeSet> getAllCodeSets() {
		List <ICodeSet> aList = new ArrayList <ICodeSet>();
		if (!isEmpty()) {
			for (ICodeSet aCodeSet : getCodeSets().values()) {
				aList.add(aCodeSet);
			}
		}
		return aList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#getCodeSetElement(java.lang.String, java.lang.String)
	 */
	public ICodeSetElement getCodeSetElement(String codeSetName,
			String codeSetElementCode) {
		ICodeSet aCodeSet = getCodeSets().get(codeSetName);
		if (aCodeSet == null) {
			throw new EaseValidationException("No code set named: "
					+ codeSetName);
		}
		ICodeSetElement anElem = aCodeSet
				.getElementWithCode(codeSetElementCode);
		if (anElem == null) {
			throw new EaseValidationException(
					"No code element with code value: " + codeSetElementCode
							+ " in code set named: " + codeSetName);
		}
		else {
			return new CodeSetElement(anElem);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#getCodeSetNamed(java
	 * .lang.String)
	 */
	public ICodeSet getCodeSetNamed(String codeSetName) {
		//unnecessary given lazy accessor for codeSets
		//		if (!codeSets.keySet().contains(codeSetName)) {
		//			codeSets = new HashMap <String, ICodeSet>();
		//		}
		return getCodeSets().get(codeSetName);
	}

	/**
	 * Gets the code sets.
	 * 
	 * @return the codeSets
	 */
	protected Map <String, ICodeSet> getCodeSets() {
		if (codeSets == null) {
			setCodeSets(new ConcurrentHashMap <String, ICodeSet>(DEFAULT_SIZE));
		}
		return codeSets;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#isEmpty()
	 */
	public boolean isEmpty() {
		return codeSets == null || codeSets.isEmpty();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#register(gov.ca.dmv
	 * .ease.bo.code.ICodeSet)
	 */
	public void register(ICodeSet codeSet) {
		cleanCodeSet(codeSet);
		getCodeSets().put(codeSet.getCodeSetName(), codeSet);
	}

	/**
	 * Reset.
	 */
	public void reset() {
		setCodeSets(null);
	}

	/**
	 * Sets the code sets.
	 * 
	 * @param codeSets the code sets
	 */
	protected void setCodeSets(Map <String, ICodeSet> codeSets) {
		this.codeSets = codeSets;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#size()
	 */
	public int size() {
		if (isEmpty()) {
			return NO_CODESET_ELEMENTS;
		}
		return codeSets.size();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return codeSets.toString();
	}
}
/**
 * Modification History:
 * 
 * $Log: CodeSetRegistrySingleton.java,v $
 * Revision 1.3  2013/03/07 18:13:03  mwkfh
 * Made HashMap thread safe with ConcurrentHashMap
 *
 * Revision 1.2  2013/03/07 17:59:56  mwkfh
 * added simple toString
 *
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.10  2011/10/12 20:55:24  mwkkc
 * Performance Merge
 *
 * Revision 1.8.6.2  2011/09/28 02:47:29  mwpxp2
 * Re-routed named spring calls to a EaseApplicationContext method
 *
 * Revision 1.8.6.1  2011/09/25 02:08:15  mwpxp2
 * Added getInitializedInstance to mitigate unit test failures that mistakenly depend on  populated app context
 *
 * Revision 1.8  2011/08/09 23:51:22  mwkfh
 * update getInstance() to return bean if exists
 *
 * Revision 1.7  2011/03/16 22:08:54  mwrka1
 * returning copy of codesetelement
 *
 * Revision 1.6  2010/12/08 04:35:36  mwpxp2
 * Change removing singleton static var and making default constructor public - reverted; singletons cannot have a public constructor
 *
 * Revision 1.5  2010/12/08 00:56:24  mwhxb3
 * made constructor public.
 *
 * Revision 1.4  2010/04/22 19:09:31  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.2  2010/01/28 18:04:37  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.12  2009/10/12 19:53:15  mwtjc1
 * To resolve pmd severity codeSetSingleton varaible's name is changed to CODESET_SINGLETON
 * PMD issue : [SEVERITY 2] Class Variable (Static Field) name 'codeSetSingleton' should be all in caps.
 *
 * Revision 1.11  2009/10/11 16:41:20  mwbxp5
 * Removed LOGGER
 *
 * Revision 1.10  2009/10/03 21:06:32  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.9  2009/09/13 20:45:36  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.8.2.2  2009/09/13 18:45:27  mwakg
 * Fixed codeset service to load from DB instead of XML. Showing code as default instead of description. Only when needed description is appended for SelectItem in codeset
 *
 * Revision 1.8.2.1  2009/09/13 01:34:28  mwakg
 * Reading data from Database instead of XML for CodeSetService
 *
 * Revision 1.8  2009/08/27 02:22:36  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.7  2009/08/10 21:39:18  mwpxp2
 * Adding logging
 *
 * Revision 1.6  2009/08/10 19:25:16  mwpxp2
 * Added reset/0
 *
 * Revision 1.5  2009/08/10 18:33:10  mwpxp2
 * Added getCodeSetElement/2
 *
 * Revision 1.4  2009/08/06 17:11:08  mwpxp2
 * Reverted to protected visibility of the internals. Cleaned up
 *
 * Revision 1.2  2009/08/06 01:09:54  mwpxp2
 * Modified size
 *
 * Revision 1.1  2009/08/06 01:00:14  mwpxp2
 * Renamed to remove the Impl part
 *
 * 
 * Revision 1.2  2009/08/05 21:02:21  mwkxk4
 * Made few changes by initializing  codeset and made a change in the getInstance method
 * Revision 1.1 2009/08/05 00:04:46
 * mwbxp5 Added CodeSet and CodeSetElement--Initial
 * 
 */
