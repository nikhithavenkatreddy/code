/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response;

import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am an IOfficeBusinessServiceResponse interface
 * 
 * File: IOfficeBusinessServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.office.business.response
 * Created: Jan 11, 2011 
 * @author MWXXW 
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeBusinessServiceResponse extends IResponse {
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeBusinessServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/01/12 01:26:55  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *
 */
