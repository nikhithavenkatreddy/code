/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

/**
 * Description: This class represents the abstract for all Application related supporting documents
 * that are not tied to a Applicant. 
 * File: NonSupportingDocument.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Aug 22, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class NonSupportingDocument extends Document {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2649336594867395495L;

	/**
	 * Default Constructor.
	 * 
	 */
	public NonSupportingDocument() {
	}
}
/**
 *  Modification History:
 *
 *  $Log: NonSupportingDocument.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/02/09 18:54:36  mwhxa2
 *  a. Moved to Architecture
 *        SupportingDocument
 *        NonSupportingDocument
 *  b. PrintDocument extends NonSupportingDocument instead of Document
 *
 *  Revision 1.1  2010/02/09 18:44:53  mwhxa2
 *  Adding Non Supporting Document to represent Documents tied to Application but not to the Applicant
 *
 *  Revision 1.6  2010/02/08 22:05:53  mwrsk
 *  Remove DocumentType Changes
 *
 *  Revision 1.5  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.4  2010/01/11 21:25:50  mwhxa2
 *  Added Document Type as Enum
 *
 *  Revision 1.3  2010/01/11 18:42:17  mwhxa2
 *  Person is now linked to Supporting Document
 *
 *  Revision 1.2  2010/01/05 03:01:42  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/08/27 05:39:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/22 23:20:36  mwrrv3
 *  Initial version.
 *
 */
