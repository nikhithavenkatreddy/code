/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.date.impl;

import static gov.ca.dmv.ease.bo.code.ICodeSetNameConstants.DATE_CODE_CATEGORY;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.config.impl.Configuration;
import gov.ca.dmv.ease.date.ICurrentDateProvider;
import gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am default implementation of ICurrentDateProvider
 * I provide canonical "current date" for EASE
 * Usage:
 * 			CurrentDateProvider.getInstance().getCurrentDate()
 *  Internals:
 *   * Read SPECIAL_TSTAMP in VSSM004U_SPECIAL_TEST_DATE
 *   * if the value can be read, return it
 *   * otherwise, return the underlying VM/OS date
 * 
 * File: CurrentDateProvider.java
 * Module:  gov.ca.dmv.ease.date.impl
 * Created: Dec 1, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CurrentDateProvider implements ICurrentDateProvider {
	/** The INSTANCE. */
	private static CurrentDateProvider INSTANCE;
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory
			.getLog(CurrentDateProvider.class);
	/** The Constant SYSTEM_DATE_CODE_SET_NAME. */
	private static final String SYSTEM_DATE_CODE_SET_NAME = "SYSTEM_DATE";

	/**
	 * Gets the single instance of CurrentDateProvider.
	 * 
	 * @return single instance of CurrentDateProvider
	 */
	public static ICurrentDateProvider getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new CurrentDateProvider();
		}
		return INSTANCE;
	}

	/**
	 * Instantiates a new current date provider.
	 */
	protected CurrentDateProvider() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.date.ICurrentDateProvider#getCurrentDate()
	 */
	public Date getCurrentDate() {
		//Date current;
		try {
			//Current date should be same as system date,
			//which in production env is the calendar date and
			//in test env gets its value from database (codeset table)
			return getSystemDate();
		}
		catch (Exception e) {
			return getSystemDate();
		}
	}

	/**
	 * Gets the system date as known to the executing JVM.
	 * 
	 * @return the system date
	 */
	public Date getSystemDate() {
		Date systemDate = null;
		//1. In production, return current system date
		//2. Else if in test environment, 
		//   2.1 Return the date from Codeset table (32U) if present
		//   2.2 Else return current system date
		if (!Configuration.getInstance().isInProductionMode()) {
			try {
				ICodeSetElement systemDateCodesetElement = CodeSetRegistrySingleton
						.getInstance().getCodeSetElement(DATE_CODE_CATEGORY,
								SYSTEM_DATE_CODE_SET_NAME);
				if (systemDateCodesetElement != null
						&& StringUtils.isNotBlank(systemDateCodesetElement
								.getDescription())) {
					DateFormat dateFormat = new SimpleDateFormat(
							EcsConverterHelper.FORMATTER_MMDDYYYY_HHMMSS);
					systemDate = dateFormat.parse(systemDateCodesetElement
							.getDescription()
							+ " "
							+ EcsConverterHelper.convertDateToString(Calendar
									.getInstance().getTime(),
									EcsConverterHelper.FORMATTER_HH_MM_SS));
				}
			}
			catch (Exception e) {
				systemDate = Calendar.getInstance().getTime();
			}
		}
		if (systemDate == null) {
			systemDate = Calendar.getInstance().getTime();
		}
		return systemDate;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CurrentDateProvider.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.15  2012/08/16 18:29:06  mwkfh
 *  retrieve env from Configuration
 *
 *  Revision 1.14  2012/08/08 20:04:26  mwkfh
 *  removed getCurrentDateFromDb
 *
 *  Revision 1.13  2012/03/24 00:15:58  mwxxw
 *  Get HHMMSS value for system time so startTime and endTime for BPRS can have the right value.
 *
 *  Revision 1.12  2012/03/13 02:06:53  mwkkc
 *  Clean up - Defect 7295 and 7296
 *
 *  Revision 1.11  2012/03/05 22:13:46  mwhys
 *  Updated getCurrentDate() to read the System date.
 *
 *  Revision 1.10  2012/01/18 20:49:48  mwhys
 *  Updated getSystemDate() for test environment to get the date from database (codeset table 32U),
 *  if present. Else return current system date.
 *
 *  Revision 1.9  2012/01/03 17:47:47  mwhys
 *  Updated getSystemDate() to return current date in production and 11/15/11 in test environment. (Defect 1123)
 *
 *  Revision 1.8  2011/10/12 20:56:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.7.8.4  2011/09/30 21:41:01  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.7.8.3  2011/09/30 21:40:34  mwpxp2
 *  Corrected instantiation of the request to use EaseApplicationContext.getUserContext() rather than usercontext.get~
 *
 *  Revision 1.7.8.2  2011/09/27 23:55:20  mwpxp2
 *  Corrected createCurrentDateRequest to use user context on date
 *
 *  Revision 1.7.8.1  2011/09/27 23:53:40  mwpxp2
 *  Corrected createCurrentDateRequest to use user context
 *
 *  Revision 1.7  2011/06/10 21:30:38  mwyxg1
 *  clean up
 *
 *  Revision 1.6  2011/03/23 23:46:58  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.5  2011/01/10 23:56:16  mwpxp2
 *  Made  public getSystemDate/0
 *
 *  Revision 1.4  2010/12/17 00:01:20  mwpxp2
 *  Fixed getSystemDate to use new instance of Calendar
 *
 *  Revision 1.3  2010/12/16 20:24:57  mwpxp2
 *  Added logging; corrected for null response
 *
 *  Revision 1.2  2010/12/16 20:08:00  mwpxp2
 *  Added implentation of getCurrentDateFromDb
 *
 *  Revision 1.1  2010/12/02 00:44:26  mwpxp2
 *  Initial
 *
 */
