/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: I am abstract superclass for synchronous responses.
 * File: SynchronousResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class SynchronousResponse extends AbstractEcsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3736349850884353333L;

	/**
	 * Instantiates a new synchronous response.
	 */
	public SynchronousResponse() {
		super();
	}

	/**
	 * Instantiates a new synchronous response.
	 */
	public SynchronousResponse(IErrorCollector errorCollector) {
		setErrorCollector(errorCollector);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#isSynchronousRespone()
	 */
	@Override
	public final boolean isSynchronousRespone() {
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SynchronousResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/14 18:23:47  mwhxb3
 *  updated comments
 *
 *  Revision 1.5  2009/10/06 21:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.2  2009/10/06 20:54:06  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.1  2009/10/06 20:28:48  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/10/03 21:23:42  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/02 21:38:27  mwrrv3
 *  Added constructor for validation errors.
 *
 *  Revision 1.2  2009/07/27 18:30:38  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.1  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.3  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.2  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-09 07:32:56  mwpxp2
 *  Moved in
 *
 *  Revision 1.3  2009-04-26 17:08:33  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-04-26 07:34:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
