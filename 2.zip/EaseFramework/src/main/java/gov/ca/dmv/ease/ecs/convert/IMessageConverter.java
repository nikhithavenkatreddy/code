/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert;

import gov.ca.dmv.ease.ecs.constants.IErrorMessageConstants;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;

import java.io.Serializable;
import java.util.List;

import org.springframework.jms.support.converter.MessageConverter;

/**
 * Description: Defines behavior of concrete converters:
 * -operating on request to produce messages to be sent out
 * -operating on received messages to produce response objects
 * Provides for validation of input (request, message) and output (response to client)
 * Extends Spring's org.springframework.jms.support.converter.MessageConverter.
 *
 * File: IMessageConverter.java
 * Module:  gov.ca.dmv.ease.ecs.convert
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageConverter extends IErrorMessageConstants,
		MessageConverter, Serializable {
	/**
	 * Get the log id for logging.
	 * 
	 * @return the message tcode
	 */
	String getLogId(IEcsRequest aRequest);
	
	/**
	 * Gets the message tcode.
	 * 
	 * @return the message tcode
	 */
	String getMessageTcode();

	/**
	 * Validate and populate TextMessage from client request.
	 *
	 * @param aRequest the a request
	 * @return String message
	 */
	public String createMessage(IEcsRequest aRequest);

	/**
	 * Convert incoming TextMessage into a response instance.
	 *
	 * @param aMessage the a message
	 *
	 * @return the IEcsResponse
	 *
	 * @throws EcsMessageConversionException the conversion exception
	 */
	public IEcsResponse createResponse(String message);

	/**
	 * Convert incoming TextMessage into a response instance.
	 *
	 * @param messages - list of messages 
	 *
	 * @return the IEcsResponse
	 *
	 * @throws EcsMessageConversionException the conversion exception
	 */
	public IEcsResponse createResponseFromMultiplePayloads(
			List <String> messages);
}
/**
 *  Modification History:
 *
 *  $Log: IMessageConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2012/02/29 01:00:02  mwxxw
 *  Add new interface String getLogId(IEcsRequest aRequest).
 *
 *  Revision 1.5  2010/12/13 20:02:23  mwpxp2
 *  Added getMessageTcode/0 throwing exception
 *
 *  Revision 1.4  2010/12/12 08:25:06  mwpxp2
 *  Cleanup
 *
 *  Revision 1.3  2010/12/06 20:13:50  mwpxp2
 *  Extended serializable
 *
 *  Revision 1.2  2010/05/25 22:10:50  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/13 18:21:30  mwhxb3
 *  updated comments.
 *
 *  Revision 1.7  2009/10/06 21:51:10  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6.2.1  2009/10/06 20:28:36  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6  2009/10/03 21:23:38  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/09/02 01:25:11  mwpzs3
 *  Mutiple payload response handling
 *
 *  Revision 1.4  2009/07/27 18:28:01  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.3  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:07:57  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.7  2009-05-18 16:06:13  ppalacz
 *  Javadoc update
 *
 *  Revision 1.6  2009-05-13 20:22:09  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.5  2009-05-12 06:28:24  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 17:42:44  mwpxp2
 *  Cleaned up
 *
 *  Revision 1.2  2009-05-10 19:38:19  mwpxp2
 *  Added createMessageFromClientRequest/2
 *
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
