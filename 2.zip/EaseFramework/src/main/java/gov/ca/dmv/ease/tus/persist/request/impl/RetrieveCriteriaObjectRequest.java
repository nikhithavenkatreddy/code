/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.IRetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveCriteriaObjectResponse;

/**
 * Description: I represent the request to retrieve a criteria object from request class
 * File: RetrieveCriteriaObjectRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Mar 22, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveCriteriaObjectRequest extends PersistenceServiceRequest
		implements IRetrieveCriteriaObjectRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2721783750616222652L;
	/**
	 * class name on which criteria has to be created
	 */
	private final Class <? extends IBusinessObject> businessObjectClass;

	/**
	 * Creates an instance of RetrieveCriteriaObjectRequest
	 * @param userContext User context on which this request is executed
	 * @param businessObjectClass Class on which criteria has to be created
	 */
	public RetrieveCriteriaObjectRequest(IUserContext userContext,
			Class <? extends IBusinessObject> businessObjectClass) {
		super(userContext);
		this.businessObjectClass = businessObjectClass;
	}

	/**
	 * Starts the transaction
	 */
	public void beginTransaction() {
		getPersistenceService().beginTransaction();
	}

	/**
	 * Commits the transaction
	 */
	public void commitTransaction() {
		getPersistenceService().commitTransaction();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public RetrieveCriteriaObjectResponse execute() {
		return getPersistenceService().execute(this);
	}

	/**
	 * This method retrieves the business object class
	 * @return class for criteria 
	 */
	public Class <? extends IBusinessObject> getBusinessObjectClass() {
		return businessObjectClass;
	}

	/**
	 * Rolls back the transaction
	 */
	public void rollbackTransaction() {
		getPersistenceService().rollbackTransaction();
	}
}
/**
 * Modification History:
 * 
 * $Log: RetrieveCriteriaObjectRequest.java,v $
 * Revision 1.1  2012/10/01 02:57:19  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.5  2010/12/28 21:32:16  mwkfh
 * updated RetrieveCriteriaObjectRequest to handle transaction outside of persistence service
 *
 * Revision 1.4  2010/09/14 00:40:33  mwkfh
 * made persistenceService non-static
 *
 * Revision 1.3  2010/09/13 04:39:45  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.2  2010/03/23 21:14:55  mwyxg1
 * add criteria support
 *
 * Revision 1.1.2.2  2010/03/23 20:55:50  mwyxg1
 * fix getter typo
 *
 * Revision 1.1.2.1  2010/03/22 15:54:21  mwakg
 * Added support for retrieving objects based on hibernate frameworks criteria object
 *
 * 
 */
