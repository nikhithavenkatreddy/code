/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.user.impl;

import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.COUNTER;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.MAIL;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.MANUAL;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.TRAVEL_CREW;
import static gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants.ROLE_DL_APU;
import static gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants.ROLE_DL_NO_UPDATE;
import static gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants.ROLE_INV_HQ_SERVICES;
import static gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants.ROLE_ISS_HQ_SERVICES;
import static gov.ca.dmv.ease.fw.constants.IMessageConstants.APPLICATION_NAME;
import static gov.ca.dmv.ease.fw.constants.IResourceBundleConstants.APPLICATION_LISTENER_NAME_RESOURCE_BUNDLE;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;
import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.code.ICodeSetNameConstants;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor;
import gov.ca.dmv.ease.fw.logging.IAuditable;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.SpringUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.auth.factory.impl.AuthAndAuthServiceRequestFactory;
import gov.ca.dmv.ease.tus.auth.request.IAuthAndAuthServiceRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsListResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveOperationalModesResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveUserAuthorizedRolesResponse;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am default implementation of IUserContext 
 * File: UserContext.java 
 * Module: gov.ca.dmv.ease.fw.user.impl 
 * Created: Jul 9, 2009
 * @author MWPXP2
 * @version $Revision: 1.28 $ 
 * Last Changed: $Date: 2017/08/07 16:56:15 $ 
 * Last Changed By: $Author: mwwwc $
 */
public class UserContext implements IUserContext, ITreePrintable, IAuditable {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(UserContext.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1895904868810619604L;

	/**
	 * Gets the default instance for Database.
	 * 
	 * @return the default instance for Database
	 */
	public static IUserContext getDefaultInstanceForDb() {
		return new UserContext(LOGGING_OFFICE_ID, LOGGING_TECH_ID,
				LOGGING_TECH_ID, null, LOGGING_USER_NAME, CurrentDateProvider
						.getInstance().getCurrentDate(), null, null, null);
	}

	/**
	 * Gets the default instance for db.
	 *
	 * @param aDate the a date
	 * @return the default instance for db
	 */
	public static IUserContext getDefaultInstanceForDb(Date aDate) {
		return new UserContext(LOGGING_OFFICE_ID, LOGGING_TECH_ID,
				LOGGING_TECH_ID, null, LOGGING_USER_NAME, aDate, null, null,
				null);
	}

	/**
	 * Gets the default instance for ecs.
	 * 
	 * @return the default instance for ecs
	 */
	public static IUserContext getDefaultInstanceForEcs() {
		return new UserContext(ECS_OFFICE_ID, ECS_TECH_ID, ECS_TECH_ID, null,
				ECS_USER_NAME, CurrentDateProvider.getInstance()
						.getCurrentDate(), null, null, null);
	}

	/**
	 * Gets the default instance for ecs.
	 *
	 * @param aTtc the a ttc
	 * @return the default instance for ecs
	 */
	public static IUserContext getDefaultInstanceForEcs(String aTtc) {
		return new UserContext(ECS_OFFICE_ID, ECS_TECH_ID, ECS_TECH_ID, aTtc,
				ECS_USER_NAME, CurrentDateProvider.getInstance()
						.getCurrentDate(), null, null, null);
	}

	/**
	 * Gets the default instance for jms.
	 * 
	 * @return the default instance for jms
	 */
	public static IUserContext getDefaultInstanceForJms() {
		return new UserContext(JMS_OFFICE_ID, JMS_TECH_ID, JMS_TECH_ID, null,
				JMS_USER_NAME, CurrentDateProvider.getInstance()
						.getCurrentDate(), null, null, null);
	}

	/**
	 * Gets the default instance for logging.
	 * 
	 * @return the default instance for logging
	 */
	public static IUserContext getDefaultInstanceForLogging() {
		return new UserContext(LOGGING_OFFICE_ID, LOGGING_TECH_ID,
				LOGGING_TECH_ID, null, LOGGING_USER_NAME, CurrentDateProvider
						.getInstance().getSystemDate(), null, null, null);
	}

	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/** The allowed ttc. */
	private List <String> allowedTtc;
	/** The authorized work dates list. */
	private List <Date> authdWorkDates;
	/** The Control Cashier Sequence number for the current TTC after it is received from the Bridge Code. It is required by the converters which do not have access to the Transaction or Process Context object */
	private Integer controlCashierSeqNumber;
	/** The DLA process sequence counter for counter mode. */
	private int dlaProcessSequenceCounterForCounterMode = 0;
	/** Mode II. e.g. V -Vehicle Registration/D -Driver License/C -Control Cashier/S -Safety Referee. */
	private CodeSetElement functionalMode;
	/** The original IP address. */
	private String ipAddress;
	/** The is issuance office only office. */
	private boolean isIssuanceOfficeOnly = false;
	/** The is DL No Update flag for help desk. */
	private boolean isDlNoUpdate = false;
	/** The Abstract Processing Unit. */
	private boolean isAbstractProcessingUnit = false;
	/** The ISSU Flag */
	private boolean issuFlag = false;
	/** The issHqServicesFlag */
	private boolean issHqServicesFlag = false;
	private boolean isLocationAuthorized = false;
	/** The location and station info. */
	private Location location;
	/** Mode. e.g. Counter mode or Postal Mode */
	@Deprecated
	private String mode;
	/** The office id. */
	private String officeId;
	/** Mode I. e.g. C -Counter/M -Manual/P -Mail/T -Travel Crew. */
	private CodeSetElement operationalMode;
	/** The list of available operational modes. */
	private Map <String, String> operationalModes;
	/** The racf id. */
	private String racfId;
	/** The remote office id. */
	private String remoteOfficeId;
	/** The request header extractor. */
	private transient IRequestHeaderExtractor requestHeaderExtractor;
	/** The role. */
	private List <String> roles;
	/** The session data. */
	private transient SessionData sessionData;
	/** System start date for production statistics for every TTC. */
	private Date systemStartDateForTtc;
	/** The host office id for satellite office. */
	private String hostOfficeId;
	/**
	 * The original office id is used to retain the original office id when user
	 * reset the mode.
	 */
	private String originalOfficeId;
	/**
	 * The original host office id is used to retain the original host office id
	 * when user reset the mode.
	 */
	private String originalHostOfficeId;
	/**
	 * The original technician id is used to retain the original technician id
	 * when user reset the mode.
	 */
	private String originalTechId;
	/** The technician id. */
	private String techId;
	/** Issuance office technician list. */
	private List <String> issuanceOfficeTechList;
	/** The Type Transaction Code. */
	private String ttc;
	/** The Type Transaction Code Description. */
	private String ttcDescription;
	/** The user name. */
	private String userName;
	/** The work date. */
	private Date workDate;
	/** user context. */
	private IUserContext user1Context;
	/** Set of employee IDs in the login office. */
	private Set <String> officeEmployeeIds;

	/**
	 * Instantiates a new user context.
	 */
	public UserContext() {
		super();
		// init();
	}

	/**
	 * Instantiates a new user context.
	 * 
	 * @param anOfficeId the an office id
	 * @param aRacfId the a racf id
	 * @param aTechId the tech id
	 * @param aTTc the TTC
	 * @param aUserName the user name
	 * @param aWorkDate the work date
	 * @param aMode the mode
	 * @param aOperationalMode the Mode I
	 * @param aFunctionalMode the Mode II
	 */
	public UserContext(String anOfficeId, String aRacfId, String aTechId,
			String aTTc, String aUserName, Date aWorkDate, String aMode,
			CodeSetElement aOperationalMode, CodeSetElement aFunctionalMode) {
		super();
		setOfficeId(anOfficeId);
		setRacfId(aRacfId);
		setTechId(aTechId);
		setOriginalOfficeId(anOfficeId);
		setOriginalTechId(aTechId);
		setTtc(aTTc);
		setUserName(aUserName);
		setWorkDate(aWorkDate);
		setMode(aMode);
		setOperationalMode(aOperationalMode);
		setFunctionalMode(aFunctionalMode);
		isCDLIS_52_10Q_Enabled();
		isCDLIS_52_Enabled();
	}

	/**
	 * Instantiates a new user context.
	 * 
	 * @param another the another
	 */
	public UserContext(UserContext another) {
		super();
		setAllowedTtc(another.getAllowedTtc());
		setControlCashierSeqNumber(another.getControlCashierSeqNumber());
		setFunctionalMode(another.getFunctionalMode());
		setIpAddress(another.getIpAddress());
		setDlNoUpdate(another.isDlNoUpdate());
		setAbstractProcessingUnit(another.isAbstractProcessingUnit());
		setMode(another.getMode());
		setOfficeId(another.getOfficeId());
		setHostOfficeId(another.getHostOfficeId());
		setOperationalMode(another.getOperationalMode());
		setRacfId(another.getRacfId());
		setLocation(another.getLocation());
		setSystemStartDateForTtc(another.getSystemStartDateForTtc());
		setTechId(another.getTechId());
		setOriginalOfficeId(another.originalOfficeId);
		setOriginalHostOfficeId(another.getOriginalHostOfficeId());
		setOriginalTechId(another.getTechId());
		//setSatelliteOfficeId(another.getSatelliteOfficeId());
		setTtc(another.getTtc());
		setTtcDescription(another.getTtcDescription());
		setUserName(another.getUserName());
		setWorkDate(another.getWorkDate());
		setAbstractProcessingUnit(another.isIssuFlag());
		setAbstractProcessingUnit(another.isIssHqServicesFlag());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	@Deprecated
	public Object clone() {
		//TODO - use copy constructor instead
		return new UserContext(this);
		//		UserContext userContext = new UserContext();
		//		userContext.setAllowedTtc(getAllowedTtc());
		//		userContext.setControlCashierSeqNumber(getControlCashierSeqNumber());
		//		userContext.setFunctionalMode(getFunctionalMode());
		//		userContext.setIpAddress(getIpAddress());
		//		userContext.setIssuanceOffice(isIssuanceOffice());
		//		userContext.setMode(getMode());
		//		userContext.setOfficeId(getOfficeId());
		//		userContext.setOperationalMode(getOperationalMode());
		//		userContext.setRacfId(getRacfId());
		//		userContext.setStationId(getStationId());
		//		userContext.setSystemStartDateForTtc(getSystemStartDateForTtc());
		//		userContext.setTechId(getTechId());
		//		userContext.setTtc(getTtc());
		//		userContext.setTtcDescription(getTtcDescription());
		//		userContext.setUserName(getUserName());
		//		userContext.setWorkDate(getWorkDate());
		//		return userContext;
	}

	/**
	 * Checks to see if the login office has employee with a specified ID.
	 *
	 * @param employeeId the employee id
	 * @return true, if successful
	 */
	public boolean doesThisOfficeHasEmployeeWithId(String employeeId) {
		return !EaseUtil.isNullOrBlank(getOfficeEmployeeIds())
				&& getOfficeEmployeeIds().contains(employeeId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getAllowedTtc()
	 */
	public List <String> getAllowedTtc() {
		return allowedTtc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getAuthdWorkDates()
	 */
	public List <Date> getAuthdWorkDates() {
		return authdWorkDates;
	}

	/**
	 * Gets the control cashier sequence number.
	 * 
	 * @return the controlCashierSeqNumber
	 * @deprecated - control cashier sequence number should be retrieved from application object.
	 */
	@Deprecated
	public Integer getControlCashierSeqNumber() {
		return controlCashierSeqNumber;
	}

	/**
	 * Gets the dla process sequence counter for counter mode.
	 * 
	 * @return the dlaProcessSequenceCounterForCounterMode
	 */
	public int getDlaProcessSequenceCounterForCounterMode() {
		dlaProcessSequenceCounterForCounterMode++;
		return dlaProcessSequenceCounterForCounterMode;
	}

	/**
	 * Gets the functionalMode.
	 * 
	 * @return the functionalMode
	 */
	public CodeSetElement getFunctionalMode() {
		return functionalMode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getIpAddress()
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getLocation()
	 */
	public Location getLocation() {
		return location;
	}

	/**
	 * Gets the mode.
	 * 
	 * @return the mode
	 */
	@Deprecated
	public String getMode() {
		return mode;
	}

	/**
	 * Gets the set of employee IDs in the login office.
	 *
	 * @return the officeEmployeeIds
	 */
	public Set <String> getOfficeEmployeeIds() {
		return officeEmployeeIds;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getOfficeId()
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Gets the operationalMode.
	 * 
	 * @return the operationalMode
	 */
	public CodeSetElement getOperationalMode() {
		return operationalMode;
	}

	/**
	 * Returns the Map of available operational modes.
	 * 
	 * @return Map <String, String> of operational modes
	 */
	public Map <String, String> getOperationalModes() {
		return operationalModes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getRacfId()
	 */
	public String getRacfId() {
		return racfId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getRemoteOfficeId()
	 */
	public String getRemoteOfficeId() {
		return remoteOfficeId;
	}

	/**
	 * Gets the request header extractor.
	 * 
	 * @return the requestHeaderExtractor
	 */
	public IRequestHeaderExtractor getRequestHeaderExtractor() {
		return requestHeaderExtractor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getRoles()
	 */
	public List <String> getRoles() {
		return roles;
	}

	/**
	 * Simple getter for the sessionData.
	 * 
	 * @return the sessionData
	 */
	public SessionData getSessionData() {
		//TODO - WHY?
		return sessionData;
	}

	/**
	 * Gets the Station Id.
	 * 
	 * @return the stationId
	 */
	public String getStationId() {
		if (EaseUtil.isNotNull(location)
				&& EaseUtil.isNotNull(location.getStation())) {
			return location.getStation().getStationId();
		}
		else {
			return null;
		}
	}

	/**
	 * Simple getter for the systemStartDateForTtc.
	 * 
	 * @return the systemStartDateForTtc
	 */
	public Date getSystemStartDateForTtc() {
		return systemStartDateForTtc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getTechId()
	 */
	public String getTechId() {
		return techId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getTtc()
	 */
	public String getTtc() {
		return ttc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getTtcDescription()
	 */
	public String getTtcDescription() {
		if ("DLA".equals(getTtc())) {
			return "DL ORIGINAL";
		}
		return ttcDescription;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.IUserContext#getUniqueIdentifier()
	 */
	public String getUniqueIdentifier() {
		return userName + officeId + techId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getUserName()
	 */
	public String getUserName() {
		return userName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getWorkDate()
	 */
	public Date getWorkDate() {
		return workDate;
	}

	/**
	 * Called by the DI framework before initializing this bean.
	 */
	public void myInit() {
		sessionData.setCurrentProcessContext(null);
		LOGGER.info("Creating an instance of UserContext");
		setSystemStartDateForTtc(CurrentDateProvider.getInstance()
				.getCurrentDate());
		setTtc(SpringUtils.getMessage(
				APPLICATION_LISTENER_NAME_RESOURCE_BUNDLE, APPLICATION_NAME));
		setOfficeId(getRequestHeaderExtractor().getOfficeId());
		setTechId(getRequestHeaderExtractor().getTechId());
		setOriginalOfficeId(getRequestHeaderExtractor().getOfficeId());
		setOriginalTechId(getRequestHeaderExtractor().getTechId());
		setUserName(getRequestHeaderExtractor().getOriginalUser());
		setRacfId(getRequestHeaderExtractor().getRacfId());
		setIpAddress(getRequestHeaderExtractor().getIpAddress());
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("HTTP REQUEST HEADER DATA		: "
					+ getRequestHeaderExtractor().toString());
		}
		if (getRequestHeaderExtractor().getRemoteOfficeId() != null) {
			setRemoteOfficeId(getRequestHeaderExtractor().getRemoteOfficeId());
		}
		loadLocationInfo(getRequestHeaderExtractor().getIpAddress());
		//	setIssHqServicesFlag(roles);
		//	populateIssuanceOfficeTechList();
		RetrieveUserAuthorizedRolesRequest rolesRequest = AuthAndAuthServiceRequestFactory
				.getInstance().createRetrieveUserAuthorizedRolesRequest(this);
		IRetrieveUserAuthorizedRolesResponse rolesResponse = (IRetrieveUserAuthorizedRolesResponse) rolesRequest
				.execute();
		setRoles(rolesResponse.getRoles());
		setIssHqServicesFlag(roles);
		populateIssuanceOfficeTechList();
		setIsIssuanceOfficeOnly();
		IAuthAndAuthServiceRequest ttcsRequest = AuthAndAuthServiceRequestFactory
				.getInstance().createRetrieveAuthorizedTtcsListRequest(this,
						roles);
		IRetrieveAuthorizedTtcsListResponse ttcsResponse = (IRetrieveAuthorizedTtcsListResponse) ttcsRequest
				.execute();
		setAllowedTtc(ttcsResponse.getTtcs());
		IAuthAndAuthServiceRequest opModesRequest = AuthAndAuthServiceRequestFactory
				.getInstance().createRetrieveOperationalModesRequest(this,
						getOfficeId());
		IRetrieveOperationalModesResponse opModesResponse = (IRetrieveOperationalModesResponse) opModesRequest
				.execute();
		setOperationalModes(opModesResponse.getOperationalModes());
		setIsDlNoUpdate(roles);
		setIsAbstractProcessingUnit(roles);
		setIssuFlag(roles);
		//		setCDLIS52enabled(populateIsFeatureEnabled("CDLIS_52_ENABLED",
		//				"CDLIS_52_ENABLED"));
		//		setCDLIS52_10Q_enabled(populateIsFeatureEnabled("CDLIS_52_ENABLED",
		//				"CDLIS_52_10Q_ENABLED"));
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("USER NAME		: " + getUserName());
			LOGGER.info("OFFICE ID		: " + getOfficeId());
			LOGGER.info("REMOTE OFFICE ID: " + getRemoteOfficeId());
			LOGGER.info("TECH ID  		: " + getTechId());
			LOGGER.info("RACF ID  		: " + getRacfId());
			LOGGER.info("IP ADDRESS  	: " + getIpAddress());
			LOGGER.info("STATION_ID  	: " + getStationId());
			LOGGER.info("PRIMARY PRINTER ID: " + getPrimaryPrinterId());
			LOGGER.info("ALTERNET PRINTER ID: " + getAlternatePrinterId());
			LOGGER.info("ROLES 	    : " + getRoles());
			LOGGER.info("OP MODES 	    : " + getOperationalModes());
			LOGGER.info("FN MODES 	    : " + getFunctionalMode());
		}
	}

	/**
	 * Re initialize For Updated Issuance Office.
	 */
	public void resetIssuanceRoleForUpdatedIssuanceOffice() {
		RetrieveUserAuthorizedRolesRequest rolesRequest = AuthAndAuthServiceRequestFactory
				.getInstance().createRetrieveUserAuthorizedRolesRequest(this);
		IRetrieveUserAuthorizedRolesResponse rolesResponse = (IRetrieveUserAuthorizedRolesResponse) rolesRequest
				.execute();
		setRoles(rolesResponse.getRoles());
		setIsIssuanceOfficeOnly();
	}

	/**
	 * Populate Issuance Office TechList.
	 */
	protected void populateIssuanceOfficeTechList() {
		issuanceOfficeTechList = new ArrayList <String>();
		if (isIssHqServicesFlag()) {
			issuanceOfficeTechList.add(this.getOriginalOfficeId() + "-"
					+ this.getOriginalTechId());
		}
		else {
			if (EaseUtil.isNotBlank(getRequestHeaderExtractor()
					.getIssuanceStr())) {
				List <String> issuanceItemList = Arrays
						.asList(getRequestHeaderExtractor().getIssuanceStr()
								.split("::"));
				Set <String> officeIdSet = new HashSet <String>();
				// Add login office id as the first one in the last - not required any more (Raghava - 10/03/2012)
				//issuanceOfficeTechList.add(getOfficeId() + "-" + getTechId());
				//officeIdSet.add(getOfficeId() + "-" + getTechId());
				String itemStr = null;
				for (String item : issuanceItemList) {
					List <String> subItemList = Arrays.asList(item.split("-"));
					if (subItemList.size() > 1) {
						itemStr = subItemList.get(0) + "-" + subItemList.get(1);
					}
					else {
						itemStr = subItemList.get(0);
					}
					if (!officeIdSet.contains(itemStr)) {
						issuanceOfficeTechList.add(itemStr);
						officeIdSet.add(itemStr);
					}
				}
			}
		}
	}

	/**
	 * Set IsAbstractProcessingUnit.
	 *
	 * @param roles the IsAbstractProcessingUnit.
	 */
	protected void setIsAbstractProcessingUnit(List <String> roles) {
		for (String role : roles) {
			if (ROLE_DL_APU.equals(role)) {
				isAbstractProcessingUnit = true;
				break;
			}
		}
		// Now we got flag, set the role back to original way.
		if (isAbstractProcessingUnit) {
			roles.remove(ROLE_DL_APU);
		}
	}

	/**
	 * Sets the checks if is DL no update.
	 *
	 * @param roles the new checks if is DL no update
	 */
	protected void setIsDlNoUpdate(List <String> roles) {
		for (String role : roles) {
			if (ROLE_DL_NO_UPDATE.equals(role)) {
				isDlNoUpdate = true;
				break;
			}
		}
		// Now we got flag, set the role back to original way.
		if (isDlNoUpdate) {
			roles.remove(ROLE_DL_NO_UPDATE);
		}
	}

	/**
	 * Loads the location and station info from the DB.
	 *
	 * @param ipAddress the IP address
	 */
	private void loadLocationInfo(String ipAddress) {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		if (!aCollector.hasErrors()) {
			Location requestlocation = new Location();
			requestlocation.setIpAddress(ipAddress);
			RetrieveBusinessObjectRequest retrieveBusinessObjectRequest = (RetrieveBusinessObjectRequest) PersistenceServiceRequestFactory
					.getInstance().createRetrieveBusinessObjectRequest(
							user1Context, requestlocation);
			RetrieveBusinessObjectResponse retrieveBusinessObjectResponse = retrieveBusinessObjectRequest
					.execute();
			if (retrieveBusinessObjectResponse.getResults().size() > 0) {
				setLocation((Location) retrieveBusinessObjectResponse
						.getResults().get(0));
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#logSummary()
	 */
	public String logSummary() {
		StringBuilder builder = new StringBuilder(128);
		builder.append("User name: ").append(getUserName());
		builder.append(", Office ID: ").append(getOfficeId());
		builder.append(", Tech ID: ").append(getTechId());
		builder.append(", TTC: ").append(getTtc());
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isCameraStationAvailable()
	 */
	public boolean isCameraStationAvailable() {
		/* TODO camera station stuff not available yet...implement.
		 * we need something more like a Terminal class that contains a 
		 * camera station class.  
		 */
		return true;
	}

	/**
	 * Checks if is current mode is counter mode.
	 * 
	 * @return true, if is operation mode is counter.
	 */
	public boolean isCurrentModeCounter() {
		if (getOperationalMode().getCode().equalsIgnoreCase(COUNTER)) {
			return Boolean.TRUE;
		}
		else {
			return Boolean.FALSE;
		}
	}

	/**
	 * Checks if it is local inventory assigned.
	 * 
	 * @return true if local inventory assigned
	 */
	public boolean isLocalInventoryAssigned() {
		if (EaseUtil.isNotNull(location)
				&& EaseUtil.isNotNull(location.getStation())) {
			return location.getStation().isInventoryAssigned();
		}
		else {
			return false;
		}
	}

	/**
	 * Checks if it is location authorized.
	 * 
	 * @return true if location authorized
	 */
	public boolean isLocationAuthorized() {
		return isLocationAuthorized;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bo.logging.audit.IAuditable#outputAuditLog(java.lang.
	 * StringBuilder)
	 */
	public void outputAuditLog(StringBuilder stringBuilder) {
		stringBuilder.append("USERCONTEXT(");
		stringBuilder.append("officeId:");
		stringBuilder.append(getOfficeId());
		stringBuilder.append("RemodeOfficeId:");
		stringBuilder.append(getRemoteOfficeId());
		stringBuilder.append(";racfId:");
		stringBuilder.append(getRacfId());
		stringBuilder.append(";techId:");
		stringBuilder.append(getTechId());
		stringBuilder.append(";stationId:");
		stringBuilder.append(getStationId());
		stringBuilder.append(";primaryPrinterId:");
		stringBuilder.append(getPrimaryPrinterId());
		stringBuilder.append(";alternatePrinterId:");
		stringBuilder.append(getAlternatePrinterId());
		stringBuilder.append(";userName:");
		stringBuilder.append(getUserName());
		stringBuilder.append(";workDate:");
		stringBuilder
				.append(CurrentDateProvider.getInstance().getCurrentDate());
		stringBuilder.append(";operationalMode (Mode I):");
		stringBuilder.append(getOperationalMode());
		stringBuilder.append(";FunctionalMode (Mode II):");
		stringBuilder.append(getFunctionalMode());
		stringBuilder.append(";ttc:");
		stringBuilder.append(getTtc() + ")");
	}

	/**
	 * Sets the allowed ttc.
	 * 
	 * @param ttcs the new allowed ttc
	 */
	public void setAllowedTtc(List <String> ttcs) {
		allowedTtc = ttcs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.user.IUserContext#getAuthdWorkDates()
	 */
	public void setAuthdWorkDates(List <Date> authdDates) {
		authdWorkDates = authdDates;
	}

	/**
	 * Sets the control cashier seq number.
	 * 
	 * @param aNumber the a number
	 */
	public void setControlCashierSeqNumber(Integer aNumber) {
		controlCashierSeqNumber = aNumber;
	}

	/**
	 * Sets the functionalMode.
	 * 
	 * @param functionalMode the functional Mode to set
	 */
	public void setFunctionalMode(CodeSetElement functionalMode) {
		this.functionalMode = functionalMode;
	}

	/**
	 * Sets the ip address.	
	 * 
	 * @param anAddress the an address
	 */
	public void setIpAddress(String anAddress) {
		this.ipAddress = anAddress;
	}

	/**
	 * Sets the issuance office only.
	 *
	 */
	protected void setIsIssuanceOfficeOnly() {
		isIssuanceOfficeOnly = false;
		if (!EaseUtil.isNullOrBlank(getRoles())) {
			for (String role : getRoles()) {
				if (role.contains(IAuthAndAuthConstants.ROLE_ISSUANCE + "_")
						|| isIssHqServicesFlag()) {
					isIssuanceOfficeOnly = true;
					break;
				}
			}
		}
		/*
		//If the user roles contain either 'DL_ISSUANCE' or 'DL_ISSUANCE_LP' or both
		//then the user can perform issuance operations.				
		if (!EaseUtil.isNullOrBlank(getRoles())) {
			if (getRoles().size() == 1
					&& (getRoles().contains(ROLE_DL_ISSUANCE) || getRoles()
							.contains(ROLE_DL_ISSUANCE_LP))) {
				isIssuanceOfficeOnly = true;
			}
			else if (getRoles().size() == 2
					&& getRoles().contains(ROLE_DL_ISSUANCE)
					&& getRoles().contains(ROLE_DL_ISSUANCE_LP)) {
				isIssuanceOfficeOnly = true;
			}
		}  */
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(Location location) {
		this.location = location;
	}

	/**
	 * Sets location authorized.
	 * 
	 * @param locationAuthorized flag
	 */
	public void setLocationAuthorized(boolean locationAuthorized) {
		this.isLocationAuthorized = locationAuthorized;
	}

	/**
	 * Sets the Mode.
	 * 
	 * @param aModeString the a mode string
	 */
	@Deprecated
	public void setMode(String aModeString) {
		mode = aModeString;
	}

	/**
	 * Sets the office employee ids.
	 *
	 * @param officeEmployeeIds the officeEmployeeIds to set
	 */
	public void setOfficeEmployeeIds(Set <String> officeEmployeeIds) {
		this.officeEmployeeIds = officeEmployeeIds;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param aString the a string
	 */
	public void setOfficeId(String aString) {
		if (!EaseUtil.isNullOrBlank(aString)) {
			officeId = aString.toUpperCase();
		}
		else {
			officeId = aString;
		}
	}

	/**
	 * Sets the operationalMode.
	 * 
	 * @param operationalMode the operational Mode to set
	 */
	public void setOperationalMode(CodeSetElement operationalMode) {
		this.operationalMode = operationalMode;
	}

	/**
	 * Sets the available operational modes.
	 *
	 * @param operationalModes the operational modes
	 */
	public void setOperationalModes(Map <String, String> operationalModes) {
		this.operationalModes = operationalModes;
	}

	/**
	 * Sets the racf id.
	 * 
	 * @param aString the a string
	 */
	public void setRacfId(String aString) {
		racfId = aString;
	}

	/**
	 * Sets the remote office id.
	 * 
	 * @param aString the a string
	 */
	public void setRemoteOfficeId(String aString) {
		remoteOfficeId = aString;
	}

	/**
	 * Sets the request header extractor.
	 * 
	 * @param anExtractor the an extractor
	 */
	public void setRequestHeaderExtractor(IRequestHeaderExtractor anExtractor) {
		requestHeaderExtractor = anExtractor;
	}

	/**
	 * Sets the roles.
	 * 
	 * @param aList the a list
	 */
	public void setRoles(List <String> aList) {
		roles = aList;
	}

	/**
	 * Simple setter for the sessionData.
	 * 
	 * @param aSessionData the a session data
	 */
	public void setSessionData(SessionData aSessionData) {
		//TODO - WHY?
		sessionData = aSessionData;
	}

	/**
	 * Simple setter for the stationId.
	 * 
	 * @param stationId the stationId to set
	 */
	public void setStationId(String stationId) {
		if (!EaseUtil.isNotNull(location)) {
			location = new Location();
		}
		if (EaseUtil.isNotNull(location.getStation())) {
			location.getStation().setStationId(stationId);
		}
		else {
			location.setStation(new Station(stationId));
		}
	}

	/**
	 * Simple setter for the systemStartDateForTtc.
	 * 
	 * @param systemStartDateForTtc the systemStartDateForTtc to set
	 */
	public void setSystemStartDateForTtc(Date systemStartDateForTtc) {
		this.systemStartDateForTtc = systemStartDateForTtc;
	}

	/**
	 * Sets the tech id.
	 * 
	 * @param aString the a string
	 */
	public void setTechId(String aString) {
		if (!EaseUtil.isNullOrBlank(aString)) {
			techId = aString.toUpperCase();
		}
		else {
			techId = aString;
		}
	}

	/**
	 * Sets the Ttc.
	 * 
	 * @param aString the a string
	 */
	public void setTtc(String aString) {
		ttc = aString;
	}

	/**
	 * Sets the TTC Description.
	 * 
	 * @param aString the a string
	 */
	public void setTtcDescription(String aString) {
		ttcDescription = aString;
	}

	/**
	 * Sets the user name.
	 * 
	 * @param aString the a string
	 */
	public void setUserName(String aString) {
		userName = aString;
	}

	/**
	 * Sets the work date.
	 * 
	 * @param aDate the a date
	 */
	public void setWorkDate(Date aDate) {
		workDate = aDate;
	}

	/**
	 * Getter for Primary Printer Id.
	 *
	 * @return the primary printer id
	 */
	public String getPrimaryPrinterId() {
		if (EaseUtil.isNotNull(location)
				&& EaseUtil.isNotNull(location.getStation())) {
			return location.getStation().getPrimaryPrinterId();
		}
		else {
			return null;
		}
	}

	/**
	 * Getter for Alternate Printer Id.
	 *
	 * @return the alternate printer id
	 */
	public String getAlternatePrinterId() {
		if (EaseUtil.isNotNull(location)
				&& EaseUtil.isNotNull(location.getStation())) {
			return location.getStation().getAlternatePrinterId();
		}
		else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(512);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#toStringOn(java.lang.StringBuilder, int)
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("userName", userName, anIndent, aBuilder);
		outputKeyValue("techId", techId, anIndent, aBuilder);
		outputKeyValue("workDate", workDate, anIndent, aBuilder);
		outputKeyValue("ttc", ttc, anIndent, aBuilder);
		outputKeyValue("ttcDescription", ttcDescription, anIndent, aBuilder);
		outputKeyValue("officeId", officeId, anIndent, aBuilder);
		outputKeyValue("originalHostOfficeId", originalHostOfficeId, anIndent,
				aBuilder);
		outputKeyValue("techId", techId, anIndent, aBuilder);
		outputKeyValue("originalTechId", originalTechId, anIndent, aBuilder);
		outputKeyValue("operationalMode", operationalMode, anIndent, aBuilder);
		outputKeyValue("operationalModes", operationalModes, anIndent, aBuilder);
		outputKeyValue("allowedTtc", allowedTtc, anIndent, aBuilder);
		outputKeyValue("authdWorkDates", authdWorkDates, anIndent, aBuilder);
		outputKeyValue("controlCashierSeqNumber", controlCashierSeqNumber,
				anIndent, aBuilder);
		outputKeyValue("dlaProcessSequenceCounterForCounterMode",
				dlaProcessSequenceCounterForCounterMode, anIndent, aBuilder);
		outputKeyValue("functionalMode", functionalMode, anIndent, aBuilder);
		outputKeyValue("ipAddress", getIpAddress(), anIndent, aBuilder);
		outputKeyValue("isDlNoUpdate", isDlNoUpdate, anIndent, aBuilder);
		outputKeyValue("isAbstractProcessingUnit", isAbstractProcessingUnit,
				anIndent, aBuilder);
		//outputKeyValue("mode", mode, anIndent, aBuilder);
		outputKeyValue("racfId", racfId, anIndent, aBuilder);
		outputKeyValue("remoteOfficeId", remoteOfficeId, anIndent, aBuilder);
		outputKeyValue("requestHeaderExtractor", requestHeaderExtractor,
				anIndent, aBuilder);
		outputKeyValue("roles", roles, anIndent, aBuilder);
		outputKeyValue("sessionData", sessionData, anIndent, aBuilder);
		outputKeyValue("stationId", getStationId(), anIndent, aBuilder);
		outputKeyValue("primaryPrinterId", getPrimaryPrinterId(), anIndent,
				aBuilder);
		outputKeyValue("alternatePrinterId", getAlternatePrinterId(), anIndent,
				aBuilder);
		outputKeyValue("isLocalInventoryAssigned", isLocalInventoryAssigned(),
				anIndent, aBuilder);
		outputKeyValue("systemStartDateForTtc", systemStartDateForTtc,
				anIndent, aBuilder);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.fw.IValidatable#validate()
	 */
	public IErrorCollector validate() {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		return aCollector;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.fw.IValidatable#validateUsing(gov.ca.dmv.ease.fw.
	 * IErrorCollector)
	 */
	public void validateUsing(IErrorCollector aCollector) {
		String strEmpId = getTechId();
		String strOfficeId = getOfficeId();
		String strTtc = getTtc();
		/*Date workDate = getWorkDate();*/
		String strRacfId = getRacfId();
		String ipAddress = getIpAddress();
		String userName = getUserName();
		//Validating Employee Id
		if (EaseUtil.isNullOrBlank(strEmpId)) {
			aCollector.register(new EaseValidationException(
					"Invalid Employee Id"));
		}
		//Validating Office Id
		if (EaseUtil.isNullOrBlank(strOfficeId)) {
			aCollector
					.register(new EaseValidationException("Invalid Office Id"));
		}
		//Validating TTC
		if (EaseUtil.isNullOrBlank(strTtc)) {
			aCollector.register(new EaseValidationException("Invalid TTC"));
		}
		//Validating Work date
		//Work date validation is commented out since "workDate" is _not_ mandatory 
		//for all business processes.
		/*if (workDate == null) {
			aCollector
					.register(new EaseValidationException("Invalid Work date"));
		}*/
		//Validating RACF Id
		if (EaseUtil.isNullOrBlank(strRacfId)) {
			aCollector.register(new EaseValidationException("Invalid RACF Id"));
		}
		//Validating IP Address
		if (EaseUtil.isNullOrBlank(ipAddress)) {
			aCollector.register(new EaseValidationException(
					"Invalid IP address"));
		}
		//Validating User Name
		if (EaseUtil.isNullOrBlank(userName)) {
			aCollector
					.register(new EaseValidationException("Invalid User Name"));
		}
	}

	/**
	 * Gets the original tech id.
	 *
	 * @return the originalTechId
	 */
	public String getOriginalTechId() {
		return originalTechId;
	}

	/**
	 * Sets the original tech id.
	 *
	 * @param originalTechId the originalTechId to set
	 */
	public void setOriginalTechId(String originalTechId) {
		this.originalTechId = originalTechId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getHostOfficeId()
	 */
	public String getHostOfficeId() {
		return hostOfficeId;
	}

	/**
	 * Sets the host office id.
	 *
	 * @param hostOfficeId the new host office id
	 */
	public void setHostOfficeId(String hostOfficeId) {
		this.hostOfficeId = hostOfficeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isIssuanceOfficeOnly()
	 */
	public boolean isIssuanceOfficeOnly() {
		return isIssuanceOfficeOnly;
	}

	/**
	 * Sets the issuance office only.
	 *
	 * @param isIssuanceOfficeOnly the new issuance office only
	 */
	public void setIssuanceOfficeOnly(boolean isIssuanceOfficeOnly) {
		this.isIssuanceOfficeOnly = isIssuanceOfficeOnly;
	}

	/**
	 * Sets the original office id.
	 *
	 * @param originalOfficeId the originalOfficeId to set
	 */
	public void setOriginalOfficeId(String originalOfficeId) {
		this.originalOfficeId = originalOfficeId;
	}

	/**
	 * Gets the original office id.
	 *
	 * @return the originalOfficeId
	 */
	public String getOriginalOfficeId() {
		return originalOfficeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isDlNoUpdate()
	 */
	public boolean isDlNoUpdate() {
		return isDlNoUpdate;
	}

	/**
	 * Sets the dl no update.
	 *
	 * @param isDlNoUpdate the new dl no update
	 */
	public void setDlNoUpdate(boolean isDlNoUpdate) {
		this.isDlNoUpdate = isDlNoUpdate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isModeManual()
	 */
	public boolean isModeManual() {
		return MANUAL.equalsIgnoreCase(getOperationalMode().getCode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isModeTravel()
	 */
	public boolean isModeTravel() {
		return TRAVEL_CREW.equalsIgnoreCase(getOperationalMode().getCode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isModeCounter()
	 */
	public boolean isModeCounter() {
		return COUNTER.equalsIgnoreCase(getOperationalMode().getCode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isModeMail()
	 */
	public boolean isModeMail() {
		return MAIL.equalsIgnoreCase(getOperationalMode().getCode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#isAbstractProcessingUnit()
	 */
	public boolean isAbstractProcessingUnit() {
		return isAbstractProcessingUnit;
	}

	/**
	 * Sets the abstract processing unit.
	 *
	 * @param isAbstractProcessingUnit the new abstract processing unit
	 */
	public void setAbstractProcessingUnit(boolean isAbstractProcessingUnit) {
		this.isAbstractProcessingUnit = isAbstractProcessingUnit;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getIssuanceOfficeTechList()
	 */
	public List <String> getIssuanceOfficeTechList() {
		return issuanceOfficeTechList;
	}

	/**
	 * Sets the issuance office tech list.
	 *
	 * @param issuanceOfficeTechList the new issuance office tech list
	 */
	public void setIssuanceOfficeTechList(List <String> issuanceOfficeTechList) {
		this.issuanceOfficeTechList = issuanceOfficeTechList;
	}

	/**
	 * Sets the original host office id.
	 *
	 * @param originalHostOfficeId the new original host office id
	 */
	public void setOriginalHostOfficeId(String originalHostOfficeId) {
		this.originalHostOfficeId = originalHostOfficeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IUserContext#getOriginalHostOfficeId()
	 */
	public String getOriginalHostOfficeId() {
		return originalHostOfficeId;
	}

	/*
	 * Temporary solution for AB91
	 */
	private boolean isAB91Enabled;

	public void setAB91Enabled(boolean isAB91Enabled) {
		this.isAB91Enabled = isAB91Enabled;
	}

	/*
	 * Temporary solution for CDLIS 5.2 AC Gap code
	 */
	private boolean isACGapCodeEnabled;

	public void setACGapCodeEnabled(boolean isACGapCodeEnabled) {
		this.isACGapCodeEnabled = isACGapCodeEnabled;
	}

	/*
	 * Temporary solution for CDLIS 5.2
	 */
	private boolean isCDLIS52enabled;

	public void setCDLIS52enabled(boolean isCDLIS52enabled) {
		this.isCDLIS52enabled = isCDLIS52enabled;
	}

	/*
	 * Temporary solution for CDLIS 5.2 10
	 */
	private boolean isCDLIS52_10Q_enabled;

	public void setCDLIS52_10Q_enabled(boolean isCDLIS52_10Q_enabled) {
		this.isCDLIS52enabled = isCDLIS52enabled;
	}

	private boolean isFeatureEnabled(String codeSetName,
			String codeSetElementName) {
		ICodeSet codeSet = CodeSetRegistrySingleton.getInstance()
				.getCodeSetNamed(codeSetName);
		if (!EaseUtil.isNullOrBlank(codeSet)) {
			ICodeSetElement codeSetElement = codeSet
					.getElementNamed(codeSetElementName);
			if (codeSetElement != null
					&& "true".equalsIgnoreCase(codeSetElement.getCode())) {
				return true;
			}
		}
		return false;
	}

	/** Temporary solution for CDLIS 52 */
	public boolean isCDLIS_52_Enabled() {
		return isFeatureEnabled("CDLIS_52_ENABLED", "CDLIS_52_ENABLED");
	}

	/** Temporary solution for CDLIS 52 10Q */
	public boolean isCDLIS_52_10Q_Enabled() {
		return isFeatureEnabled("CDLIS_52_ENABLED", "CDLIS_52_10Q_ENABLED");
	}

	/** Temporary solution for CDLIS 52 Med Cert*/
	public boolean isCDLIS_52_Med_Enabled() {
		return isFeatureEnabled("CDLIS_52_ENABLED", "CDLIS_52_MED_ENABLED");
	}

	/** Temporary solution for CDLIS 52 AC Gap Code*/
	public boolean isAcGapCodeEnabled() {
		return isFeatureEnabled("AC_GAP_CODE_ENABLED", "AC_GAP_CODE_ENABLED");
	}

	/** Support phases approach for AKTE */	
	public boolean isAkteEnabled() {
		ICodeSet akteEnabledCodeSet = CodeSetRegistrySingleton.getInstance()
				.getCodeSetNamed(ICodeSetNameConstants.AKTE_ENABLED_OFFICE);
		if (akteEnabledCodeSet != null && akteEnabledCodeSet.getCodeSetElements().size() > 0) {
			for (ICodeSetElement codeSetElement : akteEnabledCodeSet
					.getCodeSetElements()) {
				if (this.officeId.equals(codeSetElement.getCode())) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Check if office id in a code set is present.  Returns true if present.
	 * 
	 *
	 * @param String
	 */
	private boolean isOfficeInCodeList(String codeSetName) {
		ICodeSet codeSet = CodeSetRegistrySingleton.getInstance()
				.getCodeSetNamed(codeSetName);
		if (codeSet != null && codeSet.getCodeSetElements().size() > 0) {
			for (ICodeSetElement codeSetElement : codeSet.getCodeSetElements()) {
				if (this.officeId.equals(codeSetElement.getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Check if VoterReg is enabled.  Returns true if enabled.
	 * It checks for the presence of the office id in the code
	 * set VOTER_REG_ENABLED_OFFICE.  The purpose is to an allow
	 * incremental deployment
	 *
	 * @param 
	 */
	public boolean isVoterRegEnabled() {
		return isOfficeInCodeList("VOTER_REG_ENABLED_OFFICE");
	}

	public boolean isIssuFlag() {
		return issuFlag;
	}

	public boolean isIssHqServicesFlag() {
		return issHqServicesFlag;
	}

	public void setIssHqServicesFlag(boolean issHqServicesFlag) {
		this.issHqServicesFlag = issHqServicesFlag;
	}

	public void setIssuFlag(boolean issuFlag) {
		this.issuFlag = issuFlag;
	}

	/**
	 * setIssuFlag.
	 *
	 * @param roles .
	 */
	protected void setIssuFlag(List <String> roles) {
		for (String role : roles) {
			if (ROLE_INV_HQ_SERVICES.equals(role)) {
				String strOfficeId = getOfficeId();
				if (EaseUtil.isNotBlank(strOfficeId)) {
					if (strOfficeId.equals(INV_OFFICE_ID)) {
						issuFlag = true;
						break;
					}
				}
			}
		}
		// Now we got flag, set the role back to original way.
		if (isAbstractProcessingUnit) {
			roles.remove(ROLE_INV_HQ_SERVICES);
		}
	}

	/**
	 * setIssHqServicesFlag.
	 *
	 * @param roles .
	 */
	protected void setIssHqServicesFlag(List <String> roles) {
		for (String role : roles) {
			if (ROLE_ISS_HQ_SERVICES.equals(role)) {
				setIssHqServicesFlag(true);
				break;
			}
		}
		// Now we got flag, set the role back to original way.
		if (isAbstractProcessingUnit) {
			roles.remove(ROLE_ISS_HQ_SERVICES);
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: UserContext.java,v $
 * Revision 1.28  2017/08/07 16:56:15  mwwwc
 * Merge AKTE changes from branch to Head.
 *
 * Revision 1.27.6.1  2017/05/24 17:01:18  mwwwc
 * Added back AKTE changes
 *
 * Revision 1.27  2016/02/18 20:17:49  mwskh1
 * Motor Voter - merge to head
 *
 * Revision 1.26  2016/01/21 23:42:08  mwwwc
 * Remove AKTE changes from HEAD.
 *
 * Revision 1.23.1  2015/09/24 23:16:09  mwwwc
 * AKTE Changes: Add isAKTEEnabled() to check if office is running AKTE.
 *
 * Revision 1.23  2015/07/28 19:48:39  mwnxg5
 * Modified ISS_HQ_SERVICES functionality
 *
 * Revision 1.22  2015/07/24 22:18:38  mwnxg5
 * New Issuance Offices
 *
 * Revision 1.21  2015/06/12 22:21:19  mwnxg5
 * INV ISSU for EASE
 *
 * Revision 1.20  2013/12/03 19:14:02  mwlcr1
 * AB91 Clean up
 *
 * Revision 1.19  2013/12/02 20:57:48  mwlcr1
 * AB91 Clean up
 *
 * Revision 1.18  2013/10/03 14:57:45  mwskh1
 * CDLIS 5.2 - Code review changes
 *
 * Revision 1.17  2013/10/01 20:25:07  mwskh1
 * CDLIS 5.2 - added flag to check if AC gap code in use
 *
 * Revision 1.16  2013/09/05 21:21:44  mwgxd3
 * Remove logging
 *
 * Revision 1.13  2013/09/03 17:54:48  mwsec2
 * Add logSummary and put expensive log statement inside isInfoEnabled block
 *
 * Revision 1.12  2013/05/29 16:49:10  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.11.2.4  2013/04/11 15:06:21  mwgxd3
 * CDLIS - add flags
 *
 * Revision 1.11.2.2  2013/03/29 15:31:12  mwskh1
 * CDLIS 5.2 - added flag to check if CDLIS 5.2 in use
 *
 * Revision 1.11.2.1  2013/03/28 18:48:48  mwgxd3
 * CDLIS - create stubs for CDLIS_ENABLED.
 *
 * Revision 1.11  2013/01/11 19:11:20  mwxxw
 * Updated to fix satellite office BPRS corrlatiionId issue.
 *
 * Revision 1.10  2013/01/04 22:09:02  mwkfh
 * updated setOfficeId & setTechId to allow setting to null or blank
 *
 * Revision 1.9  2012/12/21 22:22:16  mwgxd3
 * AB91 Enabled Temp Solution
 *
 * Revision 1.8  2012/11/16 18:27:27  mwskh1
 * Uppercase techId and officeId due to lower case ids coming from request header.
 * Set logging levels to INFO
 *
 * Revision 1.7  2012/11/07 00:25:22  mwgxd3
 * AB91 - add new code set
 *
 * Revision 1.6  2012/11/06 16:39:58  mwgxd3
 * AB91 - add new codeset
 *
 * Revision 1.5  2012/11/05 21:20:23  mwgxd3
 * AB91 - temporary solution change
 *
 * Revision 1.4  2012/10/04 23:58:10  mwsyk1
 * Fix to display all the Office Id's and Tech ID's in drop drown for Issuance Office.
 *
 * Revision 1.3  2012/10/03 22:12:03  mwrrv3
 * Replaced Mode I and Mode II with meaningful names and updated the comments.
 *
 * Revision 1.2  2012/10/03 21:29:19  mwrrv3
 * Updated populateIssuanceOfficeTechList() method to comment the first item in the list issuanceOfficeTechList.
 *
 * Revision 1.1  2012/10/01 02:57:38  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.105  2012/08/03 23:47:13  mwhys
 * Added a field Set of employee IDs in the login office. (Defect 1429)
 *
 * Revision 1.104  2012/07/18 20:41:37  mwxxw
 * Add login office id to the issuance office id list.
 *
 * Revision 1.103  2012/07/11 01:44:31  mwsxv5
 * Added new originalHostOfficeId to retain the original host office when user reset the mode.
 *
 * Revision 1.102  2012/07/10 17:40:40  mwxxw
 * Remove unused field: satelliteOfficeId.
 *
 * Revision 1.101  2012/06/22 23:52:51  mwxxw
 * Change DL_ISSUANCE_212 to ISSUANCE_212
 *
 * Revision 1.100  2012/06/20 23:08:21  mwxxw
 * Fix ArrayIndexOutOfBoundsException.
 *
 * Revision 1.99  2012/06/20 17:04:58  mwxxw
 * Updated to filter out the duplicated office in the office list.
 *
 * Revision 1.98  2012/06/15 17:24:42  mwxxw
 * Add logic for issuance office functionality.
 *
 * Revision 1.97  2012/05/17 23:37:39  mwxxw
 * Add new header name value pair: issuance.
 *
 * Revision 1.96  2012/04/24 00:01:12  mwxxw
 * Add new field: hostOfficeId.
 *
 * Revision 1.95  2012/03/23 21:24:58  mwxxw
 * Change function name from init() to myInit() to avoid key word.
 *
 * Revision 1.94  2012/01/11 00:02:58  mwxxw
 * Add new role for EASE: DL_APU.
 *
 * Revision 1.93  2011/11/11 03:45:01  mwxxw
 * Validate userContext before query location info table.
 *
 * Revision 1.92  2011/10/26 17:10:59  mwhys
 * Updated setIsIssuanceOfficeOnly() for issuance role with legal presence bypass capability.
 *
 * Revision 1.91  2011/10/25 23:45:38  mwhys
 * Removed work date validation, as it is not required for certain TTCs.
 *
 * Revision 1.90  2011/10/25 00:23:52  mwxxw
 * Add new API: boolean bypassLegalPresence().
 *
 * Revision 1.89  2011/10/24 23:35:11  mwhys
 * Removed a field isIssuanceOffice.
 *
 * Revision 1.88  2011/10/12 20:55:24  mwkkc
 * Performance Merge
 *
 * Revision 1.84  2011/08/25 22:35:40  mwkfh
 * updated "is modes" methods
 *
 * Revision 1.83  2011/08/25 21:41:26  mwhxb3
 * Check if operating in mail mode or counter mode.
 *
 * Revision 1.82  2011/08/11 23:53:44  mwhxb3
 * Added methods :
 * 	1:isModeManual
 * 	2:isModeTravel
 * Used constants instead of Strings.
 *
 * Revision 1.81  2011/08/02 22:25:50  mwkfh
 * cleaned up imports
 *
 * Revision 1.80  2011/08/02 18:07:31  mwxxw
 * Check DL_ISSUANCE role instead of office type in setIsIssuanceOffice() and setIsIssuanceOfficeOnly().
 *
 * Revision 1.79  2011/07/27 01:28:31  mwrrv3
 * Updated setIsIssuanceOfficeOnly because it is mapped to wrong variable. Defect# 6557.
 *
 * Revision 1.78  2011/07/21 00:00:04  mwkfh
 * cleaned up imports
 *
 * Revision 1.77  2011/07/20 21:05:33  mwxxw
 * Fix the dl_no_update issue for IDA, IDP, DLP.
 *
 * Revision 1.76  2011/07/19 01:01:29  mwxxw
 * Add setter for isDlNoUpdate.
 *
 * Revision 1.75  2011/07/15 16:41:55  mwxxw
 * Add and initialize a new field: isDlNoUpdate.
 *
 * Revision 1.74  2011/05/16 18:52:04  mwkfh
 * added ipAddress property to differentiate from Location IP
 *
 * Revision 1.73  2011/05/06 17:33:45  mwkfh
 * added location info
 *
 * Revision 1.72  2011/05/05 16:23:20  mwkfh
 * added isLocalInventoryAssigned
 *
 * Revision 1.71  2011/04/26 20:55:22  mwrrv3
 * Updated to fix the defect# 3448.
 *
 * Revision 1.70  2011/04/13 21:15:10  mwkfh
 * changed getDefaultInstanceForLogging to use system date
 *
 * Revision 1.69  2011/02/14 18:12:09  mwrrv2
 * getControlCashierSeqNumber is deprecated
 *
 * Revision 1.68  2011/02/12 23:41:42  mwxxw
 * Add new IsOfficeIssuanceOnly() API.
 *
 * Revision 1.67  2011/01/26 23:39:05  mwkfh
 * setStationId to upper case
 *
 * Revision 1.66  2011/01/19 00:20:42  mwxxw
 * Remove the following API:
 * isHQOffice()
 * isTelephoneServiceCenter()
 *
 * Revision 1.65  2011/01/07 18:47:47  mwxxw
 * Set IssuanceOffice flag according to roles.
 *
 * Revision 1.64  2010/12/29 18:51:50  mwrrv3
 * Added original tech to retain the original tech id for counter mode.
 *
 * Revision 1.63  2010/12/16 20:13:35  mwpxp2
 * Added getDefaultInstanceForDb/2 to be used by current daet provider
 *
 * Revision 1.62  2010/12/15 00:36:58  mwkfh
 * replaced new Date() with CurrentDateProvider.getInstance().getCurrentDate()
 *
 * Revision 1.61  2010/12/11 23:41:00  mwxxw
 * Check the size of the location list before using it.
 *
 * Revision 1.60  2010/12/09 23:56:47  mwxxw
 * Set the following attributes during the init of userContext.
 * private String stationId;
 * private String primaryPrinterId;
 * private String alternatePrinterId;
 *
 * Revision 1.59  2010/12/08 19:27:44  mwpxp2
 * Added static getDefaultInstanceForEcs/1
 *
 * Revision 1.58  2010/12/07 23:42:36  mwxxw
 * Add new field: isLocationAuthorized.
 *
 * Revision 1.57  2010/12/07 22:07:54  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.56  2010/12/07 03:54:15  mwpxp2
 * Added toStringOn/1, toString/0; sorted
 *
 * Revision 1.55  2010/12/02 00:14:57  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.54  2010/11/29 23:59:21  mwxxw
 * Add new field remoteOfficeId for location enforcement service.
 *
 * Revision 1.53  2010/11/22 22:07:15  mwkfh
 * added OperationalModes
 *
 * Revision 1.52  2010/10/20 23:54:14  mwazg5
 * Added authdWorkDates list of date
 *
 * Revision 1.51  2010/10/04 21:39:26  mwkfh
 * refactored AuthAndAuthService to use factory/request/response/execute
 *
 * Revision 1.50  2010/09/21 18:45:54  mwpxr4
 * Merged branch mwkkc_ecs_persistance into HEAD.
 *
 * Revision 1.49.4.1  2010/09/16 20:42:45  mwpxr4
 * Updated code to use default user context for JMS.
 *
 * Revision 1.49  2010/09/13 04:39:51  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.48  2010/09/01 18:58:23  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.47  2010/08/31 17:56:34  mwhys
 * Marked Service(s) as transient.
 *
 * Revision 1.46  2010/08/16 19:19:46  mwkkc
 * Removed the temp setter for StartClock.
 *
 * Revision 1.45  2010/08/16 16:30:25  mwuxb
 * isTelephoneServiceCenter is added.
 *
 * Revision 1.44  2010/08/12 18:55:56  mwcsj3
 * Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 * Revision 1.43  2010/08/11 23:51:34  mwkfh
 * change sessionData method call
 *
 * Revision 1.42  2010/08/10 18:31:37  mwkkc
 * set the start clock time
 *
 * Revision 1.41  2010/08/10 00:01:55  mwpxp2
 * Added copy constructor and redirected clone to use it
 *
 * Revision 1.40  2010/08/06 02:26:50  mwakg
 * Added clone method for UserContext
 *
 * Revision 1.39  2010/08/05 22:35:21  mwcyl
 * add boolean method to determine if the users station is configured with  a camera  station
 *
 * Revision 1.38  2010/08/04 18:19:26  mwkfh
 * updated the name getAuthorizedTtcs
 *
 * Revision 1.37  2010/08/03 20:28:17  mwrrv2
 * Added isCurrentModeCounter() helper method to check if the current operation mode is counter or not.
 *
 * Revision 1.36  2010/07/27 18:01:38  mwkfh
 * moved SessionData
 *
 * Revision 1.35  2010/07/21 17:55:24  mwpxp2
 * Implemented outstanding validate, validateUsing
 *
 * Revision 1.34  2010/07/16 15:26:16  mwkfh
 * made requestHeaderExtractor transient
 *
 * Revision 1.33  2010/07/13 17:11:02  mwkfh
 * relocated session restore packages
 *
 * Revision 1.32  2010/07/12 23:23:21  mwhxb3
 * Modified isIssuanceOffice.
 *
 * Revision 1.31  2010/07/10 00:36:13  mwhxb3
 * Updated isIssuanceOffice method.
 *
 * Revision 1.30  2010/07/09 22:28:55  mwtjc1
 * isHqOffice added
 *
 * Revision 1.29  2010/07/08 02:00:56  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.28  2010/06/24 18:15:47  mwtjc1
 * isIssuanceOffice is added
 *
 * Revision 1.27  2010/06/21 21:57:08  mwvkm
 * systemStartDateForTtc is added in the UserContext in order to track the start time at the begining of TTC
 *
 * Revision 1.26  2010/05/25 22:27:14  mwpxp2
 * Restored class comment formatting; removed needless "t~his-es"; added todos
 *
 * Revision 1.25  2010/05/25 22:04:09  mwkkc
 * updated init() to use new RequestHeaderExtract - mwkfh
 *
 * Revision 1.24  2010/05/19 21:31:13  mwrpk
 * Code clean up
 * Revision 1.23 2010/05/18 23:08:21 mwvkm
 * Changes/Updates are made for Session Restore functionality POC.
 * 
 * Revision 1.22 2010/05/18 19:35:46 mwkkc authAndAuthService renamed to
 * AuthAndAuthService - mwkfh
 * 
 * Revision 1.21 2010/05/14 04:45:40 mwvkm Bulk Check-in for the migration of
 * LogProcessor and the integration of EaseListener
 * 
 * Revision 1.20 2010/05/10 22:14:29 mwrpk SLTT -- adding Role and Available TTC
 * a user can have Revision 1.17 2010/04/22 20:22:44 mwuxb Added Station Id for
 * the current TTC which is required by the converters
 * 
 * Revision 1.16 2010/04/22 19:10:28 mwpxp2 Bulk cleanup - added missing javadoc
 * 
 * Revision 1.15 2010/04/04 18:52:25 mwakg Removed usage of username and using
 * RequestHeaderExtractor
 * 
 * Revision 1.14 2010/04/01 22:56:28 mwvxm6 Added Control Cashier Sequence
 * number for the current TTC which is required by the converters. Update type
 * to Integer
 * 
 * Revision 1.13 2010/04/01 17:38:56 mwvxm6 Added Control Cashier Sequence
 * number for the current TTC which is required by the converters
 * 
 * Revision 1.12 2010/04/01 00:54:21 mwakg Added documentation for the init and
 * destroy methods
 * 
 * Revision 1.11 2010/03/31 22:26:46 mwakg Instantiating user context from
 * spring instead of the session listener
 * 
 * Revision 1.10 2010/03/29 16:18:44 mwhxa2 Changed names of methods form
 * getmodeI and getModeII to getOperationalMode and getFunctionalMode
 * 
 * Revision 1.9 2010/03/29 16:06:21 mwbxp5 Changed names of methods form
 * getmodeI and getModeII to getOperationalMode and getFunctionalMode.
 * 
 * Revision 1.8 2010/03/22 23:18:40 mwpxp2 Bulk cleanup
 * 
 * Revision 1.7 2010/03/22 23:12:01 mwpxp2 Javadoc/cleanup; added todo
 * 
 * Revision 1.6 2010/03/17 00:31:21 mwhxa2 Added getMode1() and getMode2()
 * 
 * Revision 1.5 2010/03/11 22:21:44 mwcsj3 Made changes to accommodate multiple
 * transitions
 * 
 * Revision 1.3 2010/02/02 03:21:39 mwrrv3 Added IP address functionality to
 * support back-end.
 * 
 * Revision 1.2 2010/01/28 18:04:37 mwhxa2 Updated Java Docs
 * 
 * Revision 1.1 2009/11/23 16:22:53 mwrsk Intial commit
 * 
 * Revision 1.22 2009/10/15 22:12:37 mwcsj3 Fixed to do's
 * 
 * Revision 1.21 2009/10/03 21:06:35 mwpxp2 Adjusted imports for fw
 * refactorings; bulk cleanup
 * 
 * Revision 1.20 2009/09/28 21:24:35 mwrsk IAuditable & ILoggable moved to
 * framework project
 * 
 * Revision 1.19 2009/09/24 02:25:19 mwhxa2 Implements IValidatable
 * 
 * Revision 1.18 2009/09/23 22:17:02 mwakg Fixed Sequence number for DL when in
 * Counter mode
 * 
 * Revision 1.17 2009/09/22 23:47:09 mwjjl7 add method to return unique
 * identifier for user
 * 
 * Revision 1.16 2009/09/22 01:11:03 mwbxp5 Added "Mode" Revision 1.15
 * 2009/09/17 21:38:55 mwsxd10 Log message structure changed.
 * 
 * Revision 1.14 2009/09/13 20:45:39 mwakg Merging CodeSetCleaning branch into
 * trunk
 * 
 * Revision 1.13 2009/09/12 22:19:29 mwbvc added ttc description
 * 
 * Revision 1.12 2009/09/10 21:38:11 mwpxp2 Added static methods to obtain
 * default instances for ECS, Logging services
 * 
 * Revision 1.11 2009/09/02 19:20:52 mwbvc removed unused import
 * 
 * Revision 1.10 2009/08/31 21:19:03 mwsxd10 outputAuditLog(StringBuffer)
 * implemented from IAuditable for logging.
 * 
 * Revision 1.9 2009/08/27 05:39:57 mwpxp2 Bulk cleanup
 * 
 * Revision 1.8 2009/08/27 02:22:39 mwsmg6 moved framework-related classes to
 * the Framework project
 * 
 * Revision 1.7 2009/08/19 23:40:09 mwakg Refactored ttc from string to
 * TypeTransactionCode class
 * 
 * Revision 1.6 2009/08/19 18:36:29 mwsxd10 Removed hard-coded instances
 * variables.
 * 
 * Revision 1.5 2009/08/19 16:00:31 mwsxd10 officeId and techId values
 * initialized.
 * 
 * Revision 1.4 2009/08/10 16:09:32 mwakg fixed binding issues for
 * SearchPersonByNumber
 * 
 * Revision 1.3 2009/07/16 00:23:24 mwcsj3 Added get and set methods for Ttc
 * 
 * Revision 1.2 2009/07/14 23:44:39 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.1 2009-07-12 15:52:20 ppalacz Initial
 * 
 * Revision 1.1 2009-07-10 07:13:10 ppalacz Synch
 * 
 */
