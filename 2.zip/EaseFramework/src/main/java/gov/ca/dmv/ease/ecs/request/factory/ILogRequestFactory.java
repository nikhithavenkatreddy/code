/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.factory;

import gov.ca.dmv.ease.ecs.request.log.impl.AuditLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.SystemManagementLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.TechnicalLogRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.io.Serializable;

/**
 * Description:  I am interface for a factory producing logging requests.
 * File: ILogRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.log.request.factory.impl
 * Created: 19/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ILogRequestFactory extends Serializable {
	/**
	 * Creates a new ILogRequest object.
	 * 
	 * @param aLogEntry the a log entry
	 * 
	 * @return the audit log request
	 */
	AuditLogRequest createAuditLogRequest(String aLogEntry,
			IUserContext aUserContext);

	/**
	 * Creates a new ILogRequest object.
	 * 
	 * @param aLogEntry the a log entry
	 * 
	 * @return the system management log request
	 */
	SystemManagementLogRequest createSystemManagementLogRequest(
			String aLogEntry, IUserContext aUserContext);

	/**
	 * Creates a new ILogRequest object.
	 * 
	 * @param aLogEntry the a log entry
	 * 
	 * @return the technical log request
	 */
	TechnicalLogRequest createTechLogRequest(String aLogEntry,
			IUserContext aUserContext);
}
/**
 *  Modification History:
 *
 *  $Log: ILogRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/13 20:50:37  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/10/03 21:23:44  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/08/27 02:34:03  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/22 20:33:58  mwpxp2
 *  Adjsuted imports
 *
 *  Revision 1.2  2009/07/22 23:25:58  mwbxp5
 *  Fixed compilation errors caused by refactoring BOs. Fixed the SendCdlisPdpsRequest object with the related objects.
 *
 *  Revision 1.1  2009/07/22 16:36:02  mwaxb1
 *  Refactor logging stubs by moving code related to ECS call to ECS project
 *
 *  Revision 1.1  2009/07/21 21:15:13  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-07-20 13:25:35  mwpxp2
 *  Initial
 *
 */
