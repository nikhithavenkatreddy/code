/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.validator.impl;

import gov.ca.dmv.ease.ecs.exception.impl.EcsPrintServiceValidationException;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.fw.validate.IValidatable;
import gov.ca.dmv.ease.fw.validate.impl.AbstractBaseValidator;
import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;

import java.util.Date;

/**
 * Description: This is Base Print Job Request Validator.
 * File: AbstractPrintJobRequestValidator.java
 * Module:  gov.ca.dmv.ease.tus.print.request.validator.impl
 * Created: Jun 29, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractPrintJobRequestValidator extends
		AbstractBaseValidator {
	/** The Constant NULL_REQUEST_ERROR_MESSAGE. */
	private static final String NULL_REQUEST_ERROR_MESSAGE = "Request is null";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2717636671801632796L;
	/** The Constant WRONG_REQUEST_TYPE_ERROR_MESSAGE. */
	private static final String WRONG_REQUEST_TYPE_ERROR_MESSAGE = "Request is not of expected type";

	/**
	 * Validates user context.
	 * 
	 * @param userContext the user context
	 * @param aCollector the a collector
	 * 
	 * @throws EcsPrintServiceValidationException the validation exception
	 */
	protected static void validateUserContext(IUserContext userContext,
			IErrorCollector aCollector)
			throws EcsPrintServiceValidationException {
		if (EaseUtil.isNotNull(userContext)) {
			String strEmpId = userContext.getTechId();
			String strOfficeId = userContext.getOfficeId();
			String strTtc = userContext.getTtc();
			Date workDate = userContext.getWorkDate();
			String strRacfId = userContext.getRacfId();
			String ipAddress = userContext.getIpAddress();
			String userName = userContext.getUserName();
			String stationId = userContext.getStationId();
			//Validating Employee Id
			if (isNullOrBlank(strEmpId)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid Employee Id"));
			}
			//Validating Office Id
			if (isNullOrBlank(strOfficeId)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid Office Id"));
			}
			//Validating TTC
			if (isNullOrBlank(strTtc)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid TTC"));
			}
			//Validating Work date
			if (workDate == null) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid Work date"));
			}
			//Validating RACF Id
			if (isNullOrBlank(strRacfId)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid RACF Id"));
			}
			//Validating IP Address
			if (isNullOrBlank(ipAddress)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid IP address"));
			}
			//Validating User Name
			if (isNullOrBlank(userName)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid User Name"));
			}
			//Validating Station ID
			if (isNullOrBlank(stationId)) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Invalid Station ID"));
			}
		}
		else {
			aCollector.register(new EcsPrintServiceValidationException(
					"Invalid UserContext : NULL"));
		}
	}

	/**
	 * Default Constructor
	 */
	public AbstractPrintJobRequestValidator() {
		//Need to move ecs message bundle
		super();
	}

	/**
	 * Validates request.
	 * 
	 * @param aRequest the a request
	 * @param aCollector the a collector
	 */
	protected static void validateRequest(IPrintServiceRequest aRequest,
			IErrorCollector aCollector) {}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.impl.AbstractBaseValidator#validateValidatable(gov.ca.dmv.ease.fw.validate.IValidatable, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public static void validateValidatable(IValidatable validatable,
			IErrorCollector collector) {
		if (validatable == null) {
			collector.register(new EcsPrintServiceValidationException(
					NULL_REQUEST_ERROR_MESSAGE));
			return;
		}
		else {
			if (validatable instanceof IPrintServiceRequest) {
				//Validate User Context
				validateUserContext(((IPrintServiceRequest) validatable)
						.getUserContext(), collector);
				//Validate Request
				validateRequest((IPrintServiceRequest) validatable, collector);
			}
			else {
				collector.register(new EcsPrintServiceValidationException(
						WRONG_REQUEST_TYPE_ERROR_MESSAGE
								+ validatable.getClass().getName()));
			}
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AbstractPrintJobRequestValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/02 00:14:56  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.3  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/08 02:04:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/06/30 00:24:59  mwhxa2
 *  Print Validators
 *
*/
