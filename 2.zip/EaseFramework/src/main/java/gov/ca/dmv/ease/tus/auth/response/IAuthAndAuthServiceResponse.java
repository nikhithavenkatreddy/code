/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response;

import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am an AuthAndAuthResponse interface
 * 
 * File: IAuthAndAuthServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response
 * Created: Oct 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IAuthAndAuthServiceResponse extends IResponse {
}
/**
 *  Modification History:
 *
 *  $Log: IAuthAndAuthServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
