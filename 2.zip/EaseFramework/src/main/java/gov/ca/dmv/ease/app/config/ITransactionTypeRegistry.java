/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.config;

import gov.ca.dmv.ease.app.process.impl.TransactionType;

/**
 * Description: Interface for Transaction Type Registry
 * File: ITransactionTypeRegistry.java
 * Module:  gov.ca.dmv.ease.app.config
 * Created: Aug 31, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ITransactionTypeRegistry {
	
	
	/**
	 * Adds TransactionType
	 * 
	 * @param trans
	 */
	public void addTransactionType(TransactionType trans);
	
	/**
	 * Gets the TransactionType object for a given tcode. Throws
	 * TransactionTypeNotFoundException if not found 
	 * 
	 * @param tcode the tcode that identifies the transaction
	 * 
	 * @return TransactionType
	 */
	public TransactionType getTransactionType(String tcode);
	
	/**
	 * Remove transaction type
	 * 
	 * @param key the key
	 */
	public void removeTransactionType(String key);
}


/**
 *  Modification History:
 *
 *  $Log: ITransactionTypeRegistry.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/10 00:00:22  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/09/03 16:43:36  mwsec2
 *  initial check in
 *
 */
