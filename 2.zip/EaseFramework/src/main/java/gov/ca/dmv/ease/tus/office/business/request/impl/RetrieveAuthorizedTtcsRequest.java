/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveAuthorizedTtcsResponse;
import gov.ca.dmv.ease.tus.office.business.service.impl.OfficeBusinessService;

/**
 * Description: I am an RetrieveAuthorizedTtcsRequest request
 * 
 * File: RetrieveAuthorizedTtcsRequest.java
 * Module:  gov.ca.dmv.ease.tus.office.business.request.impl
 * Created: Jan 12, 2010 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveAuthorizedTtcsRequest extends OfficeBusinessServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3173671017094001083L;
	/** The office id */
	String officeId;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public RetrieveAuthorizedTtcsRequest(IUserContext userContext,
			String officeId) {
		super(userContext);
		setOfficeId(officeId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.impl.IAuthAndAuthServiceRequest#execute()
	 */
	@Override
	public IRetrieveAuthorizedTtcsResponse execute() {
		return OfficeBusinessService.getInstance().execute(this);		
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param office id
	 */
	private void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
