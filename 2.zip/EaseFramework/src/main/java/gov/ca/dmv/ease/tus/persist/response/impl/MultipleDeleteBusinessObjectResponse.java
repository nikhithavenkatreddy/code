/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response to DeleteBusinessObject request
 * //TODO - remove unused constructors, starting with the default
 * 
 * File: MultipleDeleteBusinessObjectResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Sept 15, 2010
 * 
 * @author MWKFH
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleDeleteBusinessObjectResponse extends
		PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2355371068861527667L;

	/**
	 * Instantiates a new multiple delete business object response.
	 */
	public MultipleDeleteBusinessObjectResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public MultipleDeleteBusinessObjectResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new multiple delete business object response.
	 * 
	 * @param ex the ex
	 */
	public MultipleDeleteBusinessObjectResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public MultipleDeleteBusinessObjectResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public MultipleDeleteBusinessObjectResponse(IErrorCollector collector,
			int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public MultipleDeleteBusinessObjectResponse(int anItemCount) {
		super(anItemCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleDeleteBusinessObjectResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/13 00:58:06  mwpxp2
 *  Added constructors from super; added todo
 *
 *  Revision 1.1  2010/09/15 18:04:03  mwkfh
 *  added MultipleDeleteBusinessObjects
 *
 */
