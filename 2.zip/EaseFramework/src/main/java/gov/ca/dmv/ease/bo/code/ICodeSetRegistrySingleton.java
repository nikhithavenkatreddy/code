/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I am interface for an object registering existing code sets
 * The intention is to have singleton, application-scoped registry
 * File: ICodeSetRegistrySingleton.java
 * Module:  gov.ca.dmv.ease.bo.code
 * Created: Aug 4, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICodeSetRegistrySingleton extends Serializable {
	/**
	 * Gets the all code sets.
	 * 
	 * @return the all code sets
	 */
	List <ICodeSet> getAllCodeSets();

	/**
	 * Gets the code set element.
	 * 
	 * @param aCodeSetElementCode the   code set element code
	 * @param aCodeSetName the  code set name
	 * 
	 * @return the code set element
	 */
	ICodeSetElement getCodeSetElement(String aCodeSetElementCode,
			String aCodeSetName);

	/**
	 * Gets the code set named.
	 * 
	 * @param aCodeSetName the a code set name
	 * 
	 * @return the code set named
	 */
	ICodeSet getCodeSetNamed(String aCodeSetName);

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if is empty
	 */
	boolean isEmpty();

	/**
	 * Register.
	 * 
	 * @param aCodeSet the a code set
	 */
	void register(ICodeSet aCodeSet);

	/**
	 * Reset.
	 */
	void reset();

	/**
	 * Size.
	 * 
	 * @return the size
	 */
	int size();
}
/**
 *  Modification History:
 *
 *  $Log: ICodeSetRegistrySingleton.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/08/10 19:24:58  mwpxp2
 *  Added reset/0
 *
 *  Revision 1.3  2009/08/10 18:32:55  mwpxp2
 *  Added getCodeSetElement/2
 *
 *  Revision 1.2  2009/08/06 17:04:26  mwpxp2
 *  Added getAllCodeSets/0
 *
 *  Revision 1.1  2009/08/05 00:04:47  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 *  Revision 1.1  2009/08/04 16:50:16  mwpxp2
 *  Initial
 *
 */
