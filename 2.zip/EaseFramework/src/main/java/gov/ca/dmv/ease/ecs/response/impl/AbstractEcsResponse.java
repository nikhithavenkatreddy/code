/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

/**
 * Description: Abstract implementation of IEcsResponse.
 * File: AbstractEcsResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractEcsResponse extends AbstractResponse implements
		IEcsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8978751230645651921L;
	/** The has error. */
	private String errorMessage;
	/** The object count. */
	protected int objectCount = ECS_UNDEF_INT;
	/** The request id. */
	private String requestId;
	/** The response class name. */
	private String responseClassName;
	/** The response id. */
	private String responseId;

	/**
	* Instantiates a new abstract response.
	*/
	public AbstractEcsResponse() {
		super();
	}

	/**
	* Instantiates a new abstract response.
	*/
	public AbstractEcsResponse(IErrorCollector errorCollector) {
		super(errorCollector);
	}

	/* (non-Javadoc)
	* @see java.lang.Object#equals(java.lang.Object)
	*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AbstractEcsResponse other = (AbstractEcsResponse) obj;
		if (errorMessage == null) {
			if (other.errorMessage != null) {
				return false;
			}
		}
		else if (!errorMessage.equals(other.errorMessage)) {
			return false;
		}
		if (objectCount != other.objectCount) {
			return false;
		}
		if (requestId == null) {
			if (other.requestId != null) {
				return false;
			}
		}
		else if (!requestId.equals(other.requestId)) {
			return false;
		}
		if (responseClassName == null) {
			if (other.responseClassName != null) {
				return false;
			}
		}
		else if (!responseClassName.equals(other.responseClassName)) {
			return false;
		}
		if (responseId == null) {
			if (other.responseId != null) {
				return false;
			}
		}
		else if (!responseId.equals(other.responseId)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#getBusinessObjectNamed(java.lang.String)
	*/
	public BusinessObject getBusinessObjectNamed(String propertyName) {
		return null;
	}

	/**
	* Gets the error message.
	*
	* @return errorMessage the error message
	*/
	public String getErrorMessage() {
		return errorMessage;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#getObjectCount()
	*/
	public int getObjectCount() {
		return objectCount;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#getObjectValueNamed(java.lang.String)
	*/
	public Object getObjectValueNamed(String propertyName) {
		return null;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#getOriginalRequestId()
	*/
	public String getOriginalRequestId() {
		return requestId;
	}

	/**
	* Gets the request id.
	*
	* @return requestId the request id
	*/
	public String getRequestId() {
		return requestId;
	}

	/**
	* Gets the response class name.
	*
	* @return responseClassName the response class name
	*/
	public String getResponseClassName() {
		return responseClassName;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#getResponseId()
	*/
	public String getResponseId() {
		return responseId;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#hasChidren()
	*/
	public boolean hasChidren() {
		//I never have children - only composites do
		return false;
	}

	/**
	* Checks if is checks for error.
	*
	* @return true, if is checks for error
	*/
	public boolean hasError() {
		boolean returnboolean = errorMessage != null;
		return returnboolean;
	}

	/* (non-Javadoc)
	* @see java.lang.Object#hashCode()
	*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((errorMessage == null) ? 0 : errorMessage.hashCode());
		result = prime * result + objectCount;
		result = prime * result
				+ ((requestId == null) ? 0 : requestId.hashCode());
		result = prime
				* result
				+ ((responseClassName == null) ? 0 : responseClassName
						.hashCode());
		result = prime * result
				+ ((responseId == null) ? 0 : responseId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#isAsynchronousPromise()
	*/
	public boolean isAsynchronousPromise() {
		return false;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#isAsynchronousResponse()
	*/
	public boolean isAsynchronousResponse() {
		return false;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#isFireAndForgetResponse()
	*/
	public boolean isFireAndForgetResponse() {
		return false;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#isPersistedToken()
	*/
	public boolean isPersistedToken() {
		return false;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#isSynchronousRespone()
	*/
	public boolean isSynchronousRespone() {
		return false;
	}

	/**
	* Sets the error message.
	*
	* @param aMessage the new error message
	*/
	public void setErrorMessage(String aMessage) {
		errorMessage = aMessage;
	}

	/**
	* Sets the object count.
	*
	* @param objectCount the new object count
	*/
	public void setObjectCount(int objectCount) {
		this.objectCount = objectCount;
	}

	/**
	* Sets the request id.
	*
	* @param anId the an id
	*/
	public void setRequestId(String anId) {
		requestId = anId;
	}

	/**
	* Sets the response class name.
	*
	* @param aClassName the new response class name
	*/
	public void setResponseClassName(String aClassName) {
		responseClassName = aClassName;
	}

	/**
	* Sets the response id.
	*
	* @param anId the new response id
	*/
	public void setResponseId(String anId) {
		responseId = anId;
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("errorMessage", errorMessage, anIndent, aBuilder);
		outputKeyValue("objectCount", objectCount, anIndent, aBuilder);
		outputKeyValue("requestId", requestId, anIndent, aBuilder);
		outputKeyValue("responseClassName", responseClassName, anIndent,
				aBuilder);
		outputKeyValue("responseId", responseId, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.ecs.response.IEcsResponse#validate()
	*/
	public void validate() {
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractEcsResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.4  2010/10/06 16:25:22  mwhys
 *  Reverted to version 1.2
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
