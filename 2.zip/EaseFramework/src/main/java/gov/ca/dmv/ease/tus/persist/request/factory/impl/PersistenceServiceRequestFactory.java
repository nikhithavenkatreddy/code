/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.IRetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleDeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleInsertOrUpdateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleRetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.PurgeTableRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveAllBusinessObjectsRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveInventoryItemAndUpdateAsIssuedRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SaveOrUpdateBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;
import gov.ca.dmv.ease.tus.persist.service.impl.PersistenceService;

import java.util.Collection;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Implementation of the IPersistenceServiceRequestFactory request
 * interface 
 * 
 * File: PersistenceServiceRequestFactory.java
 * Module: gov.ca.dmv.ease.tus.print.request.factory.impl 
 * Created: Jul 26, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:53 $
 * Last Changed By: $Author: mwkfh $
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:53 $
 * Last Changed By: $Author: mwkfh $
 */
public class PersistenceServiceRequestFactory implements
		IPersistenceServiceRequestFactory {
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(PersistenceServiceRequestFactory.class);
	/**	The constant serial version id. */
	private static final long serialVersionUID = 3966403075334214401L;
	/** The SINGLETON. */
	private static PersistenceServiceRequestFactory SINGLETON;
	/** The Persistence Service. */
	private IPersistenceService persistenceService;

	/**
	 * Gets the single instance of PersistenceServiceRequestFactory.
	 * 
	 * @return single instance of PersistenceServiceRequestFactory
	 */
	public static PersistenceServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new PersistenceServiceRequestFactory();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.tus.print.request.factory.IPersistenceServiceRequestFactory
	 * #createDeleteBusinessObjectRequest(gov.ca.dmv.ease.bo.user.IUserContext,
	 * gov.ca.dmv.ease.bo.impl.BusinessObject)
	 */
	public IPersistenceServiceRequest createDeleteBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject) {
		DeleteBusinessObjectRequest aRequestObject = new DeleteBusinessObjectRequest(
				userContext, businessObject);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createMultipleInsertOrUpdateRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.Collection)
	 */
	public IPersistenceServiceRequest createMultipleDeleteBusinessObjectRequest(
			IUserContext userContext, Collection <IBusinessObject> boColl) {
		if (boColl == null || boColl.isEmpty()) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		MultipleDeleteBusinessObjectRequest aRequestObject = new MultipleDeleteBusinessObjectRequest(
				userContext, boColl);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createMultipleInsertOrUpdateRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.Collection)
	 */
	public IPersistenceServiceRequest createMultipleInsertOrUpdateRequest(
			IUserContext userContext, Collection <IBusinessObject> boColl) {
		if (boColl == null || boColl.isEmpty()) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		MultipleInsertOrUpdateRequest aRequestObject = new MultipleInsertOrUpdateRequest(
				userContext, boColl);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createMultipleRetrieveBusinessObjectRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.util.Collection)
	 */
	public IPersistenceServiceRequest createMultipleRetrieveBusinessObjectRequest(
			IUserContext userContext, Collection <IBusinessObject> boColl) {
		if (boColl == null || boColl.isEmpty()) {
			throw new EaseValidationException(
					"invalid collection of objects to persist in " + this);
		}
		MultipleRetrieveBusinessObjectRequest aRequestObject = new MultipleRetrieveBusinessObjectRequest(
				userContext, boColl);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createPurgeTableRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.Class)
	 */
	public IPersistenceServiceRequest createPurgeTableRequest(
			IUserContext userContext, Class <?> classToPurge) {
		PurgeTableRequest aRequestObject = new PurgeTableRequest(userContext,
				classToPurge);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createPurgeTableRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.Class, java.util.Date)
	 */
	public IPersistenceServiceRequest createPurgeTableRequest(
			IUserContext userContext, Class <?> classToPurge, Date createdBefore) {
		PurgeTableRequest aRequestObject = new PurgeTableRequest(userContext,
				classToPurge, createdBefore);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.tus.print.request.factory.IPersistenceServiceRequestFactory
	 * #
	 * createRetrieveAllBusinessObjectsRequest(gov.ca.dmv.ease.bo.user.IUserContext
	 * , java.lang.Class)
	 */
	public IPersistenceServiceRequest createRetrieveAllBusinessObjectsRequest(
			IUserContext userContext,
			Class <? extends IBusinessObject> className) {
		RetrieveAllBusinessObjectsRequest aRequestObject = new RetrieveAllBusinessObjectsRequest(
				userContext, className);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.tus.print.request.factory.IPersistenceServiceRequestFactory
	 * #
	 * createRetrieveBusinessObjectRequest(gov.ca.dmv.ease.bo.user.IUserContext,
	 * gov.ca.dmv.ease.bo.impl.BusinessObject)
	 */
	public IPersistenceServiceRequest createRetrieveBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject) {
		RetrieveBusinessObjectRequest aRequestObject = new RetrieveBusinessObjectRequest(
				userContext, businessObject);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#createRetrieveCriteriaObjectRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.Class)
	 */
	/**
	 * Creates a new PersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param businessObjectClass the business object class
	 * 
	 * @return the i persistence service request
	 */
	public IRetrieveCriteriaObjectRequest createRetrieveCriteriaObjectRequest(
			IUserContext userContext,
			Class <? extends IBusinessObject> businessObjectClass) {
		RetrieveCriteriaObjectRequest aRequestObject = new RetrieveCriteriaObjectRequest(
				userContext, businessObjectClass);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory#retrieveDlInventoryItemRequest(gov.ca.dmv.ease.bo.user.IUserContext)
	 */
	public IPersistenceServiceRequest createRetrieveInventoryItemAndUpdateAsIssuedRequest(
			IUserContext userContext, IInventoryItemRetrievable anInventoryItem) {
		RetrieveInventoryItemAndUpdateAsIssuedRequest aRequestObject = new RetrieveInventoryItemAndUpdateAsIssuedRequest(
				userContext, anInventoryItem);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.tus.print.request.factory.IPersistenceServiceRequestFactory
	 * #createSaveBusinessObjectRequest(gov.ca.dmv.ease.bo.user.IUserContext,
	 * gov.ca.dmv.ease.bo.impl.BusinessObject)
	 */
	public IPersistenceServiceRequest createSaveOrUpdateBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject) {
		SaveOrUpdateBusinessObjectRequest aRequestObject = new SaveOrUpdateBusinessObjectRequest(
				userContext, businessObject);
		aRequestObject.setPersistenceService(getPersistenceService());
		return aRequestObject;
	}

	/**
	 * Gets the persistence service.
	 * 
	 * @return the persistence service
	 */
	protected IPersistenceService getPersistenceService() {
		LOGGER.debug("getPersistenceService() - start");
		IPersistenceService returnPersistenceService;
		if (persistenceService == null) {
			returnPersistenceService = PersistenceService.getInstance();
		}
		else {
			returnPersistenceService = persistenceService;
		}
		LOGGER.debug("getPersistenceService() - end - return value="
				+ returnPersistenceService);
		return returnPersistenceService;
	}

	/**
	 * Sets the persistence service.  Can be used for mocking.
	 * 
	 * @param the persistence service
	 */
	public void setPersistenceService(IPersistenceService persistenceService) {
		this.persistenceService = persistenceService;
	}
}
/**
 * Modification History:
 * 
 * $Log: PersistenceServiceRequestFactory.java,v $
 * Revision 1.2  2012/10/23 23:39:53  mwkfh
 * added createPurgeTableRequest
 *
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.39  2012/08/08 20:06:25  mwkfh
 * removed createCurrentDateRequest
 *
 * Revision 1.38  2011/10/12 20:58:12  mwkkc
 * Performance Merge
 *
 * Revision 1.37.10.7  2011/09/30 01:00:36  mwrrv3
 * Revert
 *
 * Revision 1.37.10.5  2011/09/28 02:48:06  mwpxp2
 * Added de-springification todos
 *
 * Revision 1.37.10.4  2011/09/27 23:57:45  mwpxp2
 * Cleanup
 *
 * Revision 1.37.10.3  2011/09/27 23:51:43  mwpxp2
 * Corrected createCurrentDateRequest to use user context
 *
 * Revision 1.37.10.2  2011/09/26 05:24:50  mwpxp2
 * Adjusted for service singleton
 *
 * Revision 1.37.10.1  2011/09/25 16:31:21  mwpxp2
 * Made singleton; de-springified
 *
 * Revision 1.37  2011/03/23 23:46:58  mwyxk
 * Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 * Revision 1.36  2011/03/18 01:15:34  mwkfh
 * updated initSingleton to check for null app context
 *
 * Revision 1.35  2011/03/17 20:28:18  mwkfh
 * fixed initSingleton to catch the proper exception
 *
 * Revision 1.34  2011/01/17 05:53:41  mwpxp2
 * Modified getPersistenceService/0 to try to work when context is null
 *
 * Revision 1.33  2010/12/28 21:32:17  mwkfh
 * updated RetrieveCriteriaObjectRequest to handle transaction outside of persistence service
 *
 * Revision 1.32  2010/12/16 20:26:16  mwpxp2
 * Commented setting of factory instance in createCurrentDateRequest - to be changed
 *
 * Revision 1.31  2010/12/16 20:06:41  mwpxp2
 * Added createCurrentDateRequest/0
 *
 * Revision 1.30  2010/11/19 18:04:12  mwpxp2
 * modified initSingleton with try/catch
 *
 * Revision 1.29  2010/10/06 16:32:42  mwkfh
 * added MultipleRetrieveBusinessObject...
 *
 * Revision 1.28  2010/09/23 23:14:04  mwkfh
 * added initSingleton()
 *
 * Revision 1.27  2010/09/23 16:26:30  mwkfh
 * updated getInstance to return Spring bean
 *
 * Revision 1.26  2010/09/22 19:12:57  mwkfh
 * removed instance var
 *
 * Revision 1.25  2010/09/21 21:37:11  mwpxr4
 * Removed duplicate method deleting multiple business objects.
 *
 * Revision 1.24  2010/09/21 18:53:34  mwpxr4
 * Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< PersistenceServiceRequestFactory.java
 * Revision 1.23  2010/09/15 18:04:03  mwkfh
 * added MultipleDeleteBusinessObjects
 *
 * Revision 1.22  2010/09/14 19:27:09  mwpxp2
 * Fixed getInstance/0 to be static
 *
 * Revision 1.21  2010/09/14 19:24:47  mwpxp2
 * Added basic singleton and static getInstance/0. May or may not be replaced by named Spring bean access.
 *
 * Revision 1.20  2010/09/14 00:40:33  mwkfh
 * made persistenceService non-static
 *
=======
 * Revision 1.19.4.2  2010/09/14 17:37:34  mwpxr4
 * Added code to delete the processed payloads for a promise.
 *
 * Revision 1.19.4.1  2010/09/14 16:13:33  mwpxr4
 * *** empty log message ***
 *
>>>>>>> 1.19.4.2
 * Revision 1.19  2010/09/13 16:52:15  mwkfh
 * removed SeedPersistence for inventory
 *
 * Revision 1.18  2010/09/13 04:39:51  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.17  2010/09/10 22:05:17  mwkfh
 * updated createSeedPersistenceRequest
 *
 * Revision 1.16  2010/09/01 20:09:24  mwpxp2
 * Imports cleanup
 *
 * Revision 1.15  2010/09/01 20:08:48  mwpxp2
 * Added support for SeedPersistenceRequest and MultipleInsertOrUpdateRequest
 *
 * Revision 1.14  2010/09/01 19:24:59  mwpxp2
 * Fixed logger var name
 *
 * Revision 1.13  2010/09/01 19:07:00  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.12  2010/08/31 17:57:50  mwhys
 * Marked Service(s) as transient.
 *
 * Revision 1.11  2010/08/18 20:51:33  mwkfh
 * moved serialization methods to Serializer class
 *
 * Revision 1.10  2010/08/18 17:22:38  mwkfh
 * updated isRecursivelySerializable with array traversal and static modifier
 *
 * Revision 1.9  2010/08/18 01:12:36  mwkfh
 * add Map expansion to isRecursivelySerializable()
 *
 * Revision 1.8  2010/08/16 20:32:15  mwkfh
 * added isRecursivelySerializable() and isSerializable()
 *
 * Revision 1.7  2010/08/11 00:43:59  mwkfh
 * BlobFromObject and ObjectFromBlob have been moved to the PersistenceServiceRequestFactory
 *
 * Revision 1.6  2010/07/23 23:11:57  mwkfh
 * removed outdated ProcessContext persistence
 *
 * Revision 1.5  2010/04/22 19:25:57  mwpxp2
 * Bulk cleanup - added missing javadoc
 *
 * Revision 1.4  2010/03/27 23:57:45  mwakg
 * Injected PersistenceService into factory
 *
 * Revision 1.3  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.2  2010/03/23 21:14:55  mwyxg1
 * add criteria support
 *
 * Revision 1.1.6.2  2010/03/23 20:55:27  mwyxg1
 * add assignPersistenceService
 *
 * Revision 1.1.6.1  2010/03/22 15:54:21  mwakg
 * Added support for retrieving objects based on hibernate frameworks criteria object
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.33  2009/10/13 22:01:12  mwrsk
 * updated singleton to lowercase to avoid PMD violation
 *
 * Revision 1.32  2009/10/12 19:02:52  mwrsk
 * Update Modification History
 *
 * Revision 1.31  2009/10/12 16:28:25  mwrsk
 * Remove todo - Can't be static bcoz this might be the place where BusinessObjectInterceptior might be injected
 *
 * Revision 1.30  2009/10/12 16:26:00  mwrsk
 * code cleanup
 *
 * Revision 1.29  2009/10/06 18:17:05  mwrsk
 * Update the case for static variables
 *
 * Revision 1.28  2009/10/03 21:32:49  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.27  2009/09/30 00:42:20  mwrsk
 * Remove unused methods
 *
 * Revision 1.26  2009/09/03 22:55:02  mwrsk
 * code cleanup
 *
 * Revision 1.25  2009/09/03 22:35:36  mwrsk
 * refactor code
 *
 * Revision 1.24  2009/09/03 22:32:29  mwrsk
 * Use interface instead of a concrete class
 *
 * Revision 1.23  2009/09/03 22:26:54  mwrsk
 * Use IPersistenseSeriveRequest interface instead of the abstract class
 *
 * Revision 1.22  2009/09/03 22:18:15  mwrsk
 * Changed the return types to concrete types
 *
 * Revision 1.21  2009/09/03 22:10:39  mwrsk
 * cleanup imports
 *
 * Revision 1.20  2009/09/03 21:25:03  mwrsk
 * SaveProcessContextRequest now takes a byte array instead of IProcessContext
 *
 * Revision 1.19  2009/08/31 03:28:04  mwrsk
 * Comment SaveBusinessObject for now
 *
 * Revision 1.18  2009/08/31 01:23:54  mwrsk
 * Added SaveBusinessObject functionality
 *
 * Revision 1.17  2009/08/28 23:43:23  mwrsk
 * Refactor SaveBusinessObject request to SaveOrUpdate
 *
 * Revision 1.16  2009/08/28 23:33:58  mwrsk
 * Refactor SaveBusinessObject request to SaveOrUpdate
 *
 * Revision 1.15  2009/08/27 03:45:50  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.14  2009/08/25 22:02:08  mwpxp2
 * Added getPersistenceService/0
 *
 * Revision 1.13  2009/08/25 16:36:49  mwrsk
 * Changed the request name to RetrieveInventoryItemAndUpdateAsIssuedRequest
 *
 * Revision 1.12  2009/08/25 16:34:59  mwrsk
 * Changed the request name to RetrieveInventoryItemAndUpdateAsIssuedRequest
 *
 * Revision 1.11  2009/08/25 16:05:40  mwrsk
 * Updated to retrieve anyInventoryItem
 *
 * Revision 1.10  2009/08/25 01:56:34  mwrsk
 * Added new API for retrieving DL Inventory Item
 *
 * Revision 1.9  2009/08/21 01:08:08  mwrsk
 * Updated ProcessContextRequest methods
 *
 * Revision 1.8  2009/08/21 00:45:34  mwsxd10
 * Factory method created for creating LogRequest objects.
 * Revision 1.7 2009/08/13
 * 03:18:50 mwrsk Removed createSaveAllTransformationsRequest() method
 * 
 * Revision 1.6 2009/08/12 20:09:00 mwpxp2 modified return type of
 * createSaveBusinessObjectRequest; added fixme
 * 
 * Revision 1.5 2009/08/06 21:28:56 mwakg Merging from
 * MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 * 
 * Revision 1.4.2.1 2009/08/06 16:25:16 mwakg Changed the design of
 * PersistenceService. Instead of working with BusinessObject PersistenceService
 * is now working with IBusinessObject
 * 
 * Revision 1.4 2009/08/05 20:40:18 mwrsk Refactored code to make persistence
 * service work
 * 
 * Revision 1.3 2009/07/30 16:54:30 mwakg Removed Employee from
 * RestoreProcessContextRequest as we can can pull the same information from
 * UserContext
 * 
 * Revision 1.2 2009/07/30 16:35:34 mwakg Removed Employee from
 * SaveProcessContextRequest class
 * 
 * Revision 1.1 2009/07/29 16:57:00 mwakg Changed the design of persistence
 * service hence refractored code accordingly
 * 
 */
