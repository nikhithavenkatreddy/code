/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.factory;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.auth.request.impl.AuthorizeApproverRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsListRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsMapRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveOperationalModesRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest;

import java.util.List;

/**
 * Description: I define the interface to the AuthAndAuthRequestFactory
 * 
 * File: IAuthAndAuthServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.auth.factory
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IAuthAndAuthServiceRequestFactory {
	/**
	 * The purpose of this method is to validate user authorization approval.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	AuthorizeApproverRequest createAuthorizeApproverRequest(
			IUserContext userContext, String userName, String password,
			String approverRole);

	/**
	 * The purpose of this method is to validate user authorization approval.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	AuthorizeApproverRequest createAuthorizeApproverRequest(
			IUserContext userContext, String userName, String password,
			String approverRole, String officeId);

	/**
	 * The purpose of this method is to retrieve authorized ttc list.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	RetrieveAuthorizedTtcsListRequest createRetrieveAuthorizedTtcsListRequest(
			IUserContext userContext, List <String> roleList);

	/**
	 * The purpose of this method is to retrieve authorized ttc map.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	RetrieveAuthorizedTtcsMapRequest createRetrieveAuthorizedTtcsMapRequest(
			IUserContext userContext, List <String> roleList);

	/**
	 * The purpose of this method is to retrieve operational modes map.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	public RetrieveOperationalModesRequest createRetrieveOperationalModesRequest(
			IUserContext userContext, String officeId);

	/**
	 * The purpose of this method is to retrieve user authorized roles.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	RetrieveUserAuthorizedRolesRequest createRetrieveUserAuthorizedRolesRequest(
			IUserContext userContext);
	
	/**
	 * The purpose of this method is to validate user's location.
	 * 
	 * @return IAuthAndAuthServiceRequest
	 */
	LocationEnforcementRequest createLocationEnforcementRequest(
			IUserContext userContext, String ipAddress, String officeId,
			String remoteOfficeId);
		
}
/**
 *  Modification History:
 *
 *  $Log: IAuthAndAuthServiceRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/01/18 19:50:54  mwxxw
 *  Move office business related logic from AuthAndAuthService to OfficeBusinessService.
 *
 *  Revision 1.5  2010/12/09 00:30:26  mwxxw
 *  Add new service to AuthAndAuthService for Office Business.
 *
 *  Revision 1.4  2010/11/30 23:10:50  mwxxw
 *  Add new interface createLocationEnforcementRequest() for location enforcement service.
 *
 *  Revision 1.3  2010/11/22 22:07:41  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 *  Revision 1.2  2010/10/05 17:16:40  mwkfh
 *  swapped param in createAuthorizeApproverRequest
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
