/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I load the child process context, based on the business process
 * /TTC selection
 * 
 * File: CollectOfficeTechIdActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.dl.interaction.impl
 * Created: Jul 27, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LoadChildProcessContextActivity extends BusinessActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(Activity.class);
	/** serial Version UID */
	private static final long serialVersionUID = -2464159037992511950L;

	/**
	 * Instantiates a new collect office tech id activity.
	 */
	public LoadChildProcessContextActivity() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.BusinessActivity#invokeService(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void invokeService(ProcessContext processContext) {
		if (processContext.getUserContext().getTtc() != null) {
			BusinessProcess businessProcess = getProcessRegistry().getProcess(
					processContext.getUserContext().getTtc());
			if (businessProcess == null) {
				//FIXME - exception class too generic
				throw new ApplicationException("Invalid TTC");
			}
			ChildContext childContext = (ChildContext) businessProcess
					.getProcessContext();
			try {
				childContext.startIn(processContext);
			}
			catch (Exception e) {
				LOGGER.info("Error starting the child process :: "
						+ childContext.getProcessId());
			}
		}
		else {
			processContext.end();
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: LoadChildProcessContextActivity.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.14  2010/11/09 03:19:30  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.13  2010/09/23 18:06:21  mwsyk1
 *  reverse back to getProcess
 *
 *  Revision 1.12  2010/09/23 16:05:33  mwyxg1
 *  change from getProcess to getProcessByTtc
 *
 *  Revision 1.11  2010/08/27 15:48:18  mwyxg1
 *  remove rollback calls
 *
 *  Revision 1.10  2010/08/26 23:41:30  mwsec2
 *  Error propagation / rollback fixes
 *
 *  Revision 1.9  2010/08/20 18:30:36  mwpxp2
 *  Added fixmes;bulk formatted
 *
 *  Revision 1.8  2010/04/22 22:27:25  mwcsj3
 *  Fixed FIX ME
 *
 *  Revision 1.7  2010/04/22 19:08:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/04/10 23:11:58  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.5  2010/04/04 23:29:34  mwakg
 *  Changed ProcessRegistry variable to private and made a getter method for it
 *
 *  Revision 1.4  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/03/22 22:56:37  mwpxp2
 *  Added todo
 *
 *  Revision 1.2  2009/12/09 19:19:04  mwbxp5
 *  Adding serial Version UID
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/11/15 21:10:06  mwakg
 *  Changed to Business Activity as it does not have screen
 *
 *  Revision 1.6  2009/10/29 23:21:09  mwsxd10
 *  Unused imports removed.
 *
 *  Revision 1.5  2009/10/29 00:36:40  mwskd2
 *  updated @ 1028
 *
 *  Revision 1.4  2009/10/23 18:33:23  mwrka1
 *  removed unused imports
 *
 *  Revision 1.3  2009/10/22 18:47:18  mwskd2
 *  updated
 *
 *  Revision 1.2  2009/10/21 23:33:28  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.15  2009/10/07 19:16:27  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.14  2009/10/03 20:57:22  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.13  2009/09/08 22:49:12  mwbvc
 *  DlMenuProcessContext changes
 *
 *  Revision 1.12  2009/09/03 04:12:39  mwjjl7
 *  refactor for action handling specification
 *
 *  Revision 1.11  2009/09/02 22:41:26  mwbvc
 *  changes to capture tech ID and Office Id
 *
 *  Revision 1.10  2009/09/02 18:43:56  mwsmg6
 *  refactoring prepareResponse
 *
 *  Revision 1.9  2009/08/28 04:34:16  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.8  2009/08/27 08:24:59  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.7  2009/08/20 16:54:32  mwsmg6
 *  enhanced logging of various activities
 *
 *  Revision 1.6  2009/08/11 23:26:58  mwjjl7
 *  refactor for botton handling
 *
 *  Revision 1.5  2009/08/11 21:34:42  mwpxm2
 *  Added continue button.
 *
 *  Revision 1.4  2009/08/11 02:12:19  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 *  Revision 1.3  2009/08/05 17:00:46  mwsmg6
 *  moved ProcessContext to ...context package
 *
 *  Revision 1.2  2009/07/27 20:19:49  mwcsj3
 *  Added header, footer and super class methods
 *
 *  
 */
