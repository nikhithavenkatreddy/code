/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessExecutionException;
import gov.ca.dmv.ease.bo.user.impl.UserContext;

/**
 * Description: I represent a type of sub process which could be continued from any other business process
 * File: ContinuationSubprocessActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Jun 16, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class ContinuationSubprocessActivity extends SubprocessActivity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5362793751680214481L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#startChildProcessContext(gov.ca.dmv.ease.app.context.impl.ChildContext, gov.ca.dmv.ease.app.context.impl.ChildContext)
	 */
	@Override
	protected void executeSubprocess(ChildContext parentProcessContext,
			ChildContext childProcessContext) {
		ChildContext rootBpContext = parentProcessContext;
		while (!(rootBpContext.getParentProcessContext() instanceof SessionContext)) {
			rootBpContext = (ChildContext) rootBpContext
					.getParentProcessContext();
		}
		UserContext userContext = (UserContext) parentProcessContext.getUserContext();
		String previousTtc = userContext.getTtc();
		userContext.setTtc(childProcessContext.getProcessId());
		try {
			childProcessContext.startIn(rootBpContext, true);
		}
		catch (Exception e) {
			userContext.setTtc(previousTtc);
			throw new ProcessExecutionException(e);
		}
		if (childProcessContext.hasValidationErrors()) {
			userContext.setTtc(previousTtc);
		}
		moveErrorMessages(childProcessContext, parentProcessContext);
	}
}
/**
 * Modification History:
 * 
 * $Log: ContinuationSubprocessActivity.java,v $
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.7  2011/11/09 22:34:14  mwsec2
 * added logic to set the new TTC value before the new process is started, and to reset it the TTC to the previous one if there is any error
 *
 * Revision 1.6  2011/06/09 16:27:16  mwyxg1
 * clean up
 *
 * Revision 1.5  2010/10/20 21:34:37  mwyxg1
 * add move error message to ContinuationSubprocessActivity
 *
 * Revision 1.4  2010/07/08 02:00:55  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/06/23 01:41:12  mwakg
 * *) Changed getSubProcess to getSubprocess.
 * *) Moved postSubprocessExecute to only InclusionSubprocessActivity
 * *) Renamed businessProcessName variable to childProcessName in SubProcessActivity class
 *
 * Revision 1.2  2010/06/21 23:00:41  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.1.2.5  2010/06/20 20:20:13  mwakg
 * Moved name of the subprocess to spring configuration files
 *
 * Revision 1.1.2.4  2010/06/20 20:03:06  mwakg
 * Fixed API and 07Q navigations
 *
 * Revision 1.1.2.3  2010/06/20 18:06:53  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.1.2.2  2010/06/16 19:56:50  mwakg
 * Updated documentation
 *
 * Revision 1.1.2.1  2010/06/16 19:51:24  mwakg
 * Added ContinuationSubprocess and InclusionSubprocessActivity to divided SubprocesActivity responsibility
 *
 * 
 */
