/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.impl;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

/**
 * Description: I am the login Context used for JAAS calls.
 * File: AuthenticationLoginContext.java
 * Module:  gov.ca.dmv.ease.tus.auth.impl
* Created: Apr 16, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuthenticationLoginContext {
	/** The password fixture */
	private String password = null;
	/** The userId fixture */
	private String userId = null;

	/**
	 * Instantiates a new authentication login context.
	 */
	public AuthenticationLoginContext() {
		super();
	}

	/**
	 * Returns the Authentication Login Context object.
	 * 
	 * @param userId the user id
	 * @param password the password
	 */
	public LoginContext getAuthenticationContext() throws LoginException {
		LoginContext context = new LoginContext("WSLogin",
				new AuthenticationCallbackHandler(userId, password));
		return context;
	}

	/**
	 * Returns the password.
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Returns the userId.
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the password.
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Sets the userId.
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AuthenticationLoginContext.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:36:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.13  2009/11/18 19:38:51  mwhxb3
 *  restructured the class, added setters and getters for userId and password.
 *
 *  Revision 1.12  2009/10/29 21:13:15  mwjxa11
 *  Fixed the issues raised in PMD reports
 *
 *  Revision 1.11  2009/10/20 17:05:48  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.10  2009/10/15 22:16:12  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.9  2009/10/14 02:48:36  mwkkc
 *  I1 Close Down - Code Review
 *
 *  Revision 1.8  2009/10/12 23:36:35  mwkkc
 *  Got rid of Warning
 *
 *  Revision 1.7  2009/10/12 18:15:40  mwkkc
 *  Approval Authorization and JAAS implementation.
 *
 *  Revision 1.6  2009/10/03 21:31:28  mwpxp2
 *  Adjusted imports for fw refactorings; added javadoc
 *
 *  Revision 1.5  2009/09/22 22:23:38  mwkkc
 *  Reflection Update Design Doc
 *
 *  Revision 1.4  2009/08/27 06:29:26  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 05:18:18  mwpxp2
 *  Replaced system out with logger
 *
 *  Revision 1.2  2009/07/21 21:18:35  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:44  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-11 17:22:19  mwpxp2
 *  Moved to .impl package; cleaned up comments and javadoc; added todos
 *
 *  Revision 1.1  2009-07-10 07:13:57  mwpxp2
 *  Synch
 *
 */
