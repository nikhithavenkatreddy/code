/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.validator.impl;

import gov.ca.dmv.ease.app.action.impl.ActionsRegistry;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.IErrorCollectorEntry;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollectorEntry;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessage;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.List;

/**
 * Description: Abstract super class for all validation rules
 * File: AbstractValidateRule.java
 * Module:  gov.ca.dmv.ease.validator.impl
 * Created: Apr 27, 2010 
 * @author MWCSJ3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractValidateRule {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4014425076745730254L;

	/**
	 * @return the actionsRegistry
	 */
	public static ActionsRegistry getActionsRegistry() {
		return EaseApplicationContext.getActionsRegistry();
	}

	/**
	 * Gets the code set registry singleton.
	 * 
	 * @return the code set registry singleton
	 */
	protected static CodeSetRegistrySingleton getCodeSetRegistrySingleton() {
		return EaseApplicationContext.getCodeSetRegistrySingleton();
	}

	/**
	 * @return the errorCollector
	 * @deprecated
	 * AVOID - this is misguided
	 */
	@Deprecated
	public static IErrorCollector getErrorCollector() {
		//TODO - despringify
		return (IErrorCollector) EaseApplicationContext.getApplicationContext()
				.getBean("errorCollector");
	}

	protected static Boolean hasErrorMessage(IErrorCollector errorCollector,
			String message) {
		List <IErrorCollectorEntry> errorCollectorEntries = errorCollector
				.getEntries();
		for (IErrorCollectorEntry errorCollectorEntry : errorCollectorEntries) {
			if (message.equals(errorCollectorEntry.getExceptionMessage())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Populate error messages.
	 * 
	 * @param aContext the a context
	 * @param aCollector the a collector
	 */
	protected static void populateErrorMessages(IProcessContext aContext,
			IErrorCollector aCollector) {
		if (aCollector != null && !(aCollector.isEmpty())) {
			for (IErrorCollectorEntry anEntry : aCollector.getEntries()) {
				aContext.getMessageCollector().addValidationMessage(
						anEntry.getExceptionMessage(),
						new ErrorMessage(anEntry.getExceptionClassName(),
								anEntry.getExceptionMessage(), anEntry
										.getMessageParameters(), anEntry
										.getErrorFieldToFocus()));
			}
		}
	}

	/**
	 * Populate error messages.
	 * 
	 * @param errorCode the error code
	 * @param aContext the a context
	 */
	protected static void populateErrorMessages(String errorCode,
			ProcessContext aContext) {
		EaseValidationException easeValidationException = new EaseValidationException(
				errorCode);
		IErrorCollectorEntry anEntry = new ErrorCollectorEntry(
				easeValidationException);
		aContext.getMessageCollector()
				.addValidationMessage(
						anEntry.getExceptionMessage(),
						new ErrorMessage(anEntry.getExceptionClassName(),
								anEntry.getExceptionMessage(), anEntry
										.getMessageParameters()));
	}

	/**
	 * Populate error messages.
	 * 
	 * @param errorCode the error code
	 * @param aContext the a context
	 * @param messageParameters the message parameters
	 */
	protected static void populateErrorMessages(String errorCode,
			ProcessContext aContext, String[] messageParameters) {
		EaseValidationException easeValidationException = new EaseValidationException(
				errorCode);
		IErrorCollectorEntry anEntry = new ErrorCollectorEntry(
				easeValidationException, messageParameters);
		aContext.getMessageCollector()
				.addValidationMessage(
						anEntry.getExceptionMessage(),
						new ErrorMessage(anEntry.getExceptionClassName(),
								anEntry.getExceptionMessage(), anEntry
										.getMessageParameters()));
	}

	/**
	 * Populate error messages.
	 * 
	 * @param errorCode the error code
	 * @param aContext the a context
	 * @param messageParameters the message parameters
	 * @param errorField
	 */
	protected static void populateErrorMessages(String errorCode,
			ProcessContext aContext, String[] messageParameters,
			String errorField) {
		EaseValidationException easeValidationException = new EaseValidationException(
				errorCode);
		IErrorCollectorEntry anEntry = new ErrorCollectorEntry(
				easeValidationException, messageParameters, errorField);
		aContext.getMessageCollector().addValidationMessage(
				anEntry.getExceptionMessage(),
				new ErrorMessage(anEntry.getExceptionClassName(), anEntry
						.getExceptionMessage(), anEntry.getMessageParameters(),
						anEntry.getErrorFieldToFocus()));
	}

	/**
	 * @param errorCollector
	 * @param aMessage
	 */
	protected static void addErrorMessage(IErrorCollector aCollector,
			String aMessage) {
		if (!EaseUtil.isNullOrBlank(aMessage)) {
			aCollector.register(new ApplicationException(aMessage));
		}
	}

	/**
	 * Adds the error message.
	 *
	 * @param aCollector the a collector
	 * @param aMessage the a message
	 * @param uiField the ui field
	 */
	protected static void addErrorMessage(IErrorCollector aCollector,
			String aMessage, String uiField) {
		if (!EaseUtil.isNullOrBlank(aMessage)) {
			aCollector.register(new ApplicationException(aMessage), null,
					uiField);
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AbstractValidateRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.24  2011/10/12 20:58:37  mwkkc
 *  Performance Merge
 *
 *  Revision 1.23.8.1  2011/09/28 02:48:33  mwpxp2
 *  Re-routed named spring calls to a EaseApplicationContext method
 *
 *  Revision 1.23  2011/06/13 18:29:12  mwyxg1
 *  clean up
 *
 *  Revision 1.22  2011/04/05 22:21:55  mwrka1
 *  Fixed 518
 *
 *  Revision 1.21  2011/03/18 01:31:00  mwrrv3
 *  Defect 5602 fix -- Amar Bade
 *
 *  Revision 1.20  2011/02/03 00:53:15  mwrka1
 *  added not codition
 *
 *  Revision 1.19  2011/02/02 19:47:55  mwrka1
 *  aCollector renamed
 *
 *  Revision 1.18  2011/02/02 18:56:51  mwrka1
 *  added addErrorMessage method
 *
 *  Revision 1.17  2011/01/15 07:03:09  mwpxp2
 *  Cleanup for testing
 *
 *  Revision 1.16  2010/12/28 21:47:32  mwrka1
 *  hasErrorMessage added
 *
 *  Revision 1.15  2010/12/23 18:22:03  mwrxn3
 *  Updated
 *
 *  Revision 1.14  2010/12/09 21:02:33  mwrxn3
 *  populateErrorMessages added
 *
 *  Revision 1.13  2010/12/04 19:28:22  mwrrv3
 *  Added over loaded method for populateErrorMessages.
 *
 *  Revision 1.12  2010/11/19 19:07:09  mwtjc1
 *  getCodeSetRegistrySingleton added
 *
 *  Revision 1.11  2010/11/11 22:37:21  mwtjc1
 *  As getErrorCollector is deprecated, an alternate method populateErrorMessages is added
 *
 *  Revision 1.10  2010/11/09 20:21:33  mwpxp2
 *  Marked deprecation of getErrorCollector
 *
 *  Revision 1.9  2010/09/13 04:39:49  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.8  2010/09/04 17:33:24  mwhys
 *  Marked ActionsRegistry and ErrorCollector as transient.
 *
 *  Revision 1.7  2010/08/31 16:30:43  mwkfh
 *  clean-up
 *
 *  Revision 1.6  2010/08/31 16:27:24  mwkfh
 *  added writeObject method to serialize errorCollector
 *
 *  Revision 1.5  2010/08/24 17:37:25  mwyxg1
 *  add serialVersionUID
 *
 *  Revision 1.4  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/05/05 18:14:44  mwrrv2
 *  Added ActionsRegistry property.
 *
 *  Revision 1.2  2010/04/29 17:53:22  mwcsj3
 *  Initial version
 *
 *  Revision 1.1.2.1  2010/04/29 16:07:28  mwcsj3
 *  moved to package gov.ca.dmv.ease.validator.impl
 *
 *  Revision 1.1.2.1  2010/04/27 17:49:14  mwcsj3
 *  Initial version
 *
 *  
 */
