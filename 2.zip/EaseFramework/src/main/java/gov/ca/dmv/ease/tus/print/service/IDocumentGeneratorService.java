package gov.ca.dmv.ease.tus.print.service;

import java.io.File;

/**
 * Description: Interface for Generate Document Functionality.
 * File: IDocumentGeneratorService.java
 * Module:  gov.ca.dmv.ease.tus.print.service
 * Created: May 7, 2010
 * @author MWHXA2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IDocumentGeneratorService {
	/**
	 * This method generates the Post Script file for an input XML.
	 * 
	 * @param inputXmlData the Input Data in XML format
	 * @param fileName the File Name
	 * 
	 * @return the Post Script File
	 */
	File generate(String inputXmlData, String fileName);
}
/**
 *  Modification History:
 * 
 *  $Log: IDocumentGeneratorService.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/11 00:59:48  mwhxa2
 *  Document Generator service interface
 *
 */
