/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveOperationalModesResponse;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Description: I am an AuthAndAuth response
 * 
 * File: RetrieveOperationalModesResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response.impl
 * Created: Nov 19, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveOperationalModesResponse extends
		AuthAndAuthServiceResponse implements IRetrieveOperationalModesResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5091012995786070403L;
	/** map of operational modes to return */
	Map <String, String> operationalModes = new LinkedHashMap <String, String>();

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveOperationalModesResponse(
			Map <String, String> operationalModes) {
		super();
		setOperationalModes(operationalModes);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveOperationalModesResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RetrieveOperationalModesResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Gets the operational modes map.
	 * 
	 * @return the operational modes map
	 */
	public Map <String, String> getOperationalModes() {
		return operationalModes;
	}

	/**
	 * Sets the operational modes map.
	 * 
	 * @param operational modes map
	 */
	private void setOperationalModes(Map <String, String> operationalModes) {
		this.operationalModes = operationalModes;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveOperationalModesResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/11/22 22:07:41  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 */
