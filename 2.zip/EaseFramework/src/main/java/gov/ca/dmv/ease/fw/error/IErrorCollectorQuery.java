/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.error;

import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I define behavior for querying error collector and error entry instances
 * File: IErrorCollectorQuery.java
 * Module:  gov.ca.dmv.ease.fw.error
 * Created: Oct 12, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IErrorCollectorQuery {
	/**
	 * Checks for exception of class.
	 * 
	 * @param anExceptionClass the an exception class
	 * 
	 * @return true, if successful
	 */
	boolean hasEaseExceptionOfClass(
			Class <? extends EaseException> anExceptionClass);

	/**
	 * Checks for exception message.
	 * 
	 * @param aMessage the a message
	 * 
	 * @return true, if successful
	 */
	boolean hasExceptionMessage(String aMessage);

	/**
	 * Checks for exception message containing.
	 * 
	 * @param aMessage the a message
	 * 
	 * @return true, if successful
	 */
	boolean hasExceptionMessageContaining(String aMessage);

	/**
	 * Checks for exception of class.
	 * 
	 * @param anExceptionClass the an exception class
	 * 
	 * @return true, if successful
	 */
	boolean hasExceptionOfClass(Class <? extends Exception> anExceptionClass);
}
/**
 *  Modification History:
 *
 *  $Log: IErrorCollectorQuery.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/12 17:46:51  mwpxp2
 *  Initial
 *
 */
