/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.request.impl;

import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.session.persist.response.impl.UpdateSessionPersistenceResponse;

/**
 * Description: Persistence service request to update the session object.
 * File: UpdateSessionPersistenceRequest.java 
 * Module: gov.ca.dmv.ease.tus.session.persist.request.impl 
 * Created: Dec 12, 2012
 * @author MWHYS
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/12/13 00:07:33 $ 
 * Last Changed By: $Author: mwhys $
 */
public class UpdateSessionPersistenceRequest extends SessionPersistenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8443922976472057473L;

	/**
	 * The Constructor.
	 *
	 * @param userContext the user context
	 * @param aSession the a session
	 */
	public UpdateSessionPersistenceRequest(IUserContext userContext,
			Session aSession) {
		super(userContext, aSession);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public UpdateSessionPersistenceResponse execute() {
		return getPersistenceService().execute(this);
	}
}

/**
 *  Modification History:
 *
 *  $Log: UpdateSessionPersistenceRequest.java,v $
 *  Revision 1.1  2012/12/13 00:07:33  mwhys
 *  Initial.
 *
 *
 */