/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.docs.template.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/** 
 * Description: Provides the abstract implementation of the generic methods for substitution of variables, 
 * offset logic for positioning words in the in Document Templates
 * File: AbstractDocumentTemplate.java
 * Module:  gov.ca.dmv.ease.tus.docs.util
 * Created: Aug 11, 2009
 * @author MWJZC8
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractDocumentTemplate {
	/** The receipt lines. */
	protected static List <String> RECEIPTLINES = new ArrayList <String>();

	/**
	 * Substitute.
	 * 
	 * @param map the map
	 * @param lines the lines
	 * 
	 * @return the array list< string>
	 */
	public static List <String> substitute(Map <String, String> map,
			List <String> lines) {
		ArrayList <String> replacedLines = new ArrayList <String>();
		for (String originalLine : lines) {
			String replacedLine = originalLine;
			boolean tokenFound = false;
			StringTokenizer tokenizer = new StringTokenizer(replacedLine,
					",/ \t\n:");
			while (tokenizer.hasMoreTokens()) {
				String token = tokenizer.nextToken();
				if (token.startsWith("#")) {
					String value = map.get(token);
					if (value == null) {
						continue;
					}
					replacedLine = replacedLine.replaceAll(token, value);
					tokenFound = true;
				}
			}
			if (tokenFound) {
				replacedLines.add(replacedLine);
			}
			else {
				replacedLines.add(originalLine);
			}
		}
		return replacedLines;
	}

	/**
	 * Substitute variables.
	 * 
	 * @param map the map
	 * 
	 * @return the array list< string>
	 */
	public static List <String> substituteVariables(Map <String, String> map) {
		List <String> replacedLines = RECEIPTLINES;
		replacedLines = substitute(map, replacedLines);
		return replacedLines;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractDocumentTemplate.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:37:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/14 00:25:25  mwjxa11
 *  Refactored
 *
 *  Revision 1.3  2009/10/08 23:57:33  mwjxa11
 *  Removed the unused method - makeCopy
 *
 *  Revision 1.2  2009/08/29 20:12:52  mwakg
 *  Fixed logical issues
 *
 *  Revision 1.1  2009/08/27 04:40:28  mwpxp2
 *  Moved in from documetn service project and package-restructured
 *
 *  Revision 1.1  2009/08/26 22:14:07  mwpxp2
 *  Moved into dedicated package
 *
 *  Revision 1.2  2009/08/26 18:10:14  mwpxp2
 *  Cleanup: added javadoc
 *
 *  
 *  Revision 1.1  2009/08/20 02:29:12  mwjxa11
 *  - Added with respective comments
 *  - Moved the implemenation classes to service.impl package from util package
 *  - Moved the creation of default state of an object to a method and called that method from default constructor
 *  - etc.
 *
 *  Revision 1.1  2009/08/16 00:31:40  mwjxa11
 *  Deleted default constructor and setter methods; Added constructor of multiple arguments.
 *  Also moved from gov.ca.dmv.ease.bus.util to gov.ca.dmv.ease.tus.docs.util
 *
 *	Revision 1.1  2009/08/15 17:10:11  mwjxa11
 *  Deleted default constructor and setter methods; Added constructor of multiple arguments.
 *  Also moved from gov.ca.dmv.ease.bus.util to gov.ca.dmv.ease.tus.docs.util
 */
