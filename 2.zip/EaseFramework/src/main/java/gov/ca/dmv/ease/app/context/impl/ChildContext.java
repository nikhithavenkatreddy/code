/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.context.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.SubprocessActivity;
import gov.ca.dmv.ease.app.config.impl.ProcessLoader;
import gov.ca.dmv.ease.app.exception.impl.ProcessStateInvalidException;
import gov.ca.dmv.ease.bo.user.impl.UserContext;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This is the class for child context.
 * File: ChildContext.java
 * Module:  gov.ca.dmv.ease.app.context
 * Created:   2009 
 * @author NN  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class ChildContext extends ProcessContext {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(ChildContext.class);
	/** The non-data fields that should not be copied from one context object to another */
	private static final String[] NO_COPY_FIELDS;
	/**The Constant serialVersionUID*/
	private static final long serialVersionUID = -5175747336466068111L;
	static {
		/** initialize the array of no-copy fields during class load */
		List <String> combinedFieldNameList = new ArrayList <String>();
		Class <?> clazz = ChildContext.class;
		while (clazz != null) {
			Field[] fields = clazz.getDeclaredFields();
			String[] fieldNames = new String[fields.length];
			for (int i = 0; i < fieldNames.length; ++i) {
				fieldNames[i] = fields[i].getName();
			}
			List <String> fieldNamelist = Arrays.asList(fieldNames);
			combinedFieldNameList.addAll(fieldNamelist);
			clazz = clazz.getSuperclass();
		}
		Object[] objArr = combinedFieldNameList.toArray();
		String[] strArr = new String[objArr.length];
		System.arraycopy(objArr, 0, strArr, 0, objArr.length);
		NO_COPY_FIELDS = strArr;
	}
	/** Specifies whether this process, when running as a sub-process, interrupts the main transaction. */
	private boolean interruptMainTtc;
	/** Holds the transaction code (TTC) of the interrupted transaction */
	protected String interruptedTtc;
	/** The parent. */
	private ProcessContext parentProcessContext;
	/** The subprocess activity that wraps the last sync point activity that executed in a child process */
	private SubprocessActivity syncPointSubprocessActivity;

	/**
	 * Gets the parent.
	 * 
	 * @return the parent
	 */
	@Override
	public boolean canHaveParentContext() {
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.ProcessContext#end()
	 */
	@Override
	public void end() {
		LOGGER.debug("Current process context :: " + getProcessId());
		ProcessContext parentProcessContext = getParentProcessContext();
		getRootContext().setCurrentProcessContext(parentProcessContext);
		if (isChildOfMenuProcess(parentProcessContext)) {
			((UserContext) getUserContext()).setTtc(parentProcessContext
					.getProcessId());
			clearExecutionSyncPoints();
		}
		else {
			parentProcessContext.setSelectedAction(getSelectedAction());
			resetTtc();
		}
		LOGGER.debug("Switching to Parent process context :: "
				+ getParentProcessContext().getProcessId());
		parentProcessContext.resume(this);
	}

	/**
	 * Starts a process at a specific activity. Used when a parent process needs to
	 * fallback to an activity within a subprocess. If the fallback target argument
	 * is null, then the current execution sync point will be used.
	 * @param processContext
	 * @param fallbackTarget
	 */
	public void fallbackIn(ProcessContext processContext,
			Activity fallbackTarget) {
		if (fallbackTarget == null) {
			setParentProcessContext(processContext); // next line needs this set
			fallbackTarget = getExecutionSyncPointActivity();
		}
		setCurrentActivity(fallbackTarget);
		LOGGER.info("Falling back to Activity :: "
				+ fallbackTarget.getActivityName() + " in Child Process :: "
				+ getProcessId());
		startIn(processContext, false);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.impl.IntrospectiveContext#getIgnoredFields()
	 */
	@Override
	protected String[] getIgnoredFields() {
		return NO_COPY_FIELDS;
	}

	/**
	 * Gets the parent.
	 * 
	 * @return the parent
	 */
	public ProcessContext getParentProcessContext() {
		return parentProcessContext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.ProcessContext#getRootContext()
	 */
	@Override
	public SessionContext getRootContext() {
		return getParentProcessContext().getRootContext();
	}

	/**
	 * @return
	 */
	public SubprocessActivity getSyncPointSubprocessActivity() {
		return syncPointSubprocessActivity;
	}

	/**
	 * This method determines if the parent process is a menu process
	 * @param processContext the process is question
	 * @return is whether a menu process
	 */
	// TODO this needs work or replacement
	private boolean isChildOfMenuProcess(ProcessContext processContext) {
		if (isMenuProcess()) {
			return false;
		}
		ChildContext rootBpContext = (ChildContext) this
				.getParentProcessContext();
		while (!(rootBpContext.getParentProcessContext() instanceof SessionContext)) {
			rootBpContext = (ChildContext) rootBpContext
					.getParentProcessContext();
		}
		return rootBpContext.getClass().equals(processContext.getClass());
	}

	/**
	 * @return the interruptMainTtc flag, which says whether this process interrupts the main 
	 * transaction when it runs as a sub process (this is rarely true)
	 */
	public boolean isInterruptMainTtc() {
		return interruptMainTtc;
	}

	/**
	 * Evaluates to true if the context is the main business process context, as opposed
	 * to a menu context or a subprocess of the main business process context. Based on
	 * the assumption that a main business context is always the direct child of a menu process. 
	 * @return is whether a main business process context
	 */
	public boolean isMainBusinessProcess() {
		return !isMenuProcess()
				&& ((ChildContext) getParentProcessContext()).isMenuProcess();
	}

	/**
	 * Evaluates to true if the context is a menu context, based on the assumption that only menu processes are
	 * immediate children of the session context
	 * @return is whether a menu process
	 */
	public boolean isMenuProcess() {
		return getParentProcessContext() instanceof SessionContext;
	}

	/**
	 * Evaluates to true if the context is a sub process of the main business process context.
	 *  
	 * @return whether this is a sub process of a main business process context
	 */
	public boolean isSubProcess() {
		return !isMenuProcess()
				&& ((ChildContext) getParentProcessContext())
						.isMainBusinessProcess();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.impl.ProcessContext#registerSyncPoint(gov.ca.dmv.ease.app.activity.impl.Activity)
	 */
	@Override
	public void registerSyncPoint(Activity activity) {
		super.registerSyncPoint(activity);
		if (activity.isSyncPoint()) {
			if (!isMenuProcess()) {
				ChildContext parentContext = (ChildContext) getParentProcessContext();
				while (!parentContext.isMenuProcess()) {
					SubprocessActivity currentSubprocessActivity = (SubprocessActivity) parentContext
							.getCurrentActivity();
					parentContext
							.setSyncPointSubprocessActivity(currentSubprocessActivity);
					parentContext = (ChildContext) parentContext
							.getParentProcessContext();
				}
			}
		}
	}

	/**
	 * Conditionally resets the TTC in user context to the previous value 
	 * (i.e., the value of the interrupted TTC)
	 */
	protected void resetTtc() {
		if (interruptMainTtc) {
			((UserContext) getUserContext()).setTtc(interruptedTtc);
		}
	}

	/**
	 * Used during session management to restore the current child context
	 * with the saved session data.
	 */
	@Override
	public void restore() {
		super.restore();
		ChildContext restoredChildContext = this;
		String businessProcessId = restoredChildContext.getProcessId();
		//TODO despringify
		ProcessLoader processLoader = (ProcessLoader) EaseApplicationContext
				.getApplicationContext().getBean("processLoader");
		String syncPointSubprocessActivityName = null;
		if (isNotNull(syncPointSubprocessActivity)) {
			syncPointSubprocessActivityName = ((Activity) syncPointSubprocessActivity)
					.getActivityName();
		}
		Activity originalSyncPointSubprocessActivity = processLoader
				.getActivityReference(businessProcessId,
						syncPointSubprocessActivityName);
		restoredChildContext
				.setSyncPointSubprocessActivity((SubprocessActivity) originalSyncPointSubprocessActivity);
	}

	/**
	 * 
	 * @param interruptMainTtc sets the interruptMainTtc flag, which says whether this process interrupts the main 
	 * transaction when it runs as a sub process (this should be set to true only in rare cases)
	 */
	public void setInterruptMainTtc(boolean interrupt) {
		interruptMainTtc = interrupt;
	}

	/**
	 * Sets the parent.
	 * 
	 * @param parent the new parent
	 */
	public void setParentProcessContext(ProcessContext parent) {
		parentProcessContext = parent;
	}

	/**
	 * @param syncPointSubprocessActivity
	 */
	public void setSyncPointSubprocessActivity(SubprocessActivity anActivity) {
		syncPointSubprocessActivity = anActivity;
	}

	/**
	 * Starts this business process in the supplied business process context. 
	 * This method does not change the TTC in UserContext instance
	 * @param processContext the process context in which this context needs to be started in
	 */
	public void startIn(ProcessContext processContext) {
		startIn(processContext, false);
	}

	/**
	 * Starts this business process in the supplied business process context
	 * @param processContext the process context in which this context needs to be started in
	 * @param changeTtcInUserContext should the ttc in usercontext needs to be changed
	 */
	public void startIn(ProcessContext processContext,
			boolean changeTtcInUserContext) {
		validateParent(processContext);
		LOGGER.info("Starting " + getProcessId() + " in "
				+ processContext.getProcessId());
		setParentProcessContext(processContext);
		(getRootContext()).setCurrentProcessContext(this);
		LOGGER.debug("Switching to Child Process Context :: " + getProcessId());
		start();
		updateTtc(changeTtcInUserContext);
	}

	/**
	 * Conditionally updates the TTC in user context
	 * @param changeTtcInUserContext
	 */
	protected void updateTtc(boolean changeTtcInUserContext) {
		if ((changeTtcInUserContext || interruptMainTtc)
				&& !hasValidationErrors()) {
			if (interruptMainTtc) {
				interruptedTtc = ((UserContext) getUserContext()).getTtc();
			}
			((UserContext) getUserContext()).setTtc(getProcessId());
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.impl.ProcessContext#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		String parent;
		if (parentProcessContext == null) {
			parent = null;
		}
		else {
			parent = parentProcessContext.simpleToString();
		}
		outputKeyValue("parentProcessContext", parent, anIndent, aBuilder);
		outputKeyValue("syncPointSubprocessActivity",
				syncPointSubprocessActivity, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/**
	 * Validates that certain assumptions regarding the configuration of a child process context are met.
	 * If not, throws ProcessStateInvalidException
	 */
	private void validateParent(ProcessContext parentContext) {
		if (parentContext == null) {
			throw new ProcessStateInvalidException("Parent context is null");
		}
		if (equals(parentContext)) {
			throw new ProcessStateInvalidException(
					"Process cannot be started within itself");
		}
		if (parentContext instanceof ChildContext
				&& ((ChildContext) parentContext).getParentProcessContext() == null) {
			throw new ProcessStateInvalidException(
					"Parent context is not a SessionContext and has no parent context");
		}
		if (parentContext.getRootContext() == null) {
			throw new ProcessStateInvalidException(
					"Parent context is not attached to a SessionContext");
		}
		if (getProcessId() != null
				&& getProcessId().equals(parentContext.getProcessId())) {
			throw new ProcessStateInvalidException(
					"Process cannot be started within another instance of the same process");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ChildContext.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/04/30 16:44:38  mwsec2
 *  adjusted logging levels
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.37  2011/10/12 20:54:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.36.8.1  2011/09/28 02:46:54  mwpxp2
 *  Added de-springification todos
 *
 *  Revision 1.36  2011/06/09 16:31:55  mwyxg1
 *  clean up
 *
 *  Revision 1.35  2011/05/05 16:58:27  mwsec2
 *  refactored 'ttc interrupt' code to make it easier to unit test
 *
 *  Revision 1.34  2011/05/03 21:39:09  mwsec2
 *  added fields and logic to allow some subprocesses to change the user context's ttc field, if needed
 *
 *  Revision 1.33  2011/02/16 01:46:44  mwsec2
 *  fix for continuation subprocess rollback issue
 *
 *  Revision 1.32  2011/01/20 19:47:52  mwpxp2
 *  Imports and javadoc cleanup
 *
 *  Revision 1.31  2010/12/08 05:18:04  mwpxp2
 *  Modified output for parentProcessContext in toStringOn/1
 *
 *  Revision 1.30  2010/12/08 04:14:06  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.29  2010/12/02 00:14:56  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.28  2010/10/19 18:49:17  mwsec2
 *  added reflection optimization code (static block and instance method) to speed up inherited copyPropertiesFrom method
 *
 *  Revision 1.27  2010/09/24 00:22:48  mwhys
 *  Added restore method for session management.
 *
 *  Revision 1.26  2010/09/23 19:43:26  mwhys
 *  Restored the references to the activities from the process loader during session management.
 *
 *  Revision 1.25  2010/09/20 17:03:11  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.24  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.23  2010/09/09 15:23:49  mwkfh
 *  commented out writeObject
 *
 *  Revision 1.22  2010/09/04 17:26:49  mwhys
 *  Set the proxy objects to pojos before serialization.
 *
 *  Revision 1.21  2010/09/01 18:56:22  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.20  2010/08/23 20:41:12  mwsec2
 *  private validateParent method added
 *
 *  Revision 1.19  2010/08/18 23:25:39  mwsec2
 *  new predicate methods added
 *
 *  Revision 1.18  2010/08/16 18:28:20  mwtjc1
 *  isCNACondition is moved back to DlProcessContext
 *
 *  Revision 1.16  2010/08/10 17:18:41  mwpxp2
 *  Removed unproductive this.~es
 *
 *  Revision 1.15  2010/08/09 23:54:17  mwsec2
 *  fallback functionality fixes
 *
 *  Revision 1.14  2010/08/06 21:05:36  mwsec2
 *  Modifications to support sub-to-sub process fallbacks
 *
 *  Revision 1.13  2010/08/03 21:27:58  mwsec2
 *  syncPoint enhancements
 *
 *  Revision 1.12  2010/07/23 14:49:47  mwakg
 *  Merged from Fallback_branch
 *
 *  Revision 1.8.2.1  2010/07/06 21:43:51  mwsec2
 *  fallbackIn method added to support process-to-subprocess fallback
 *
 *  Revision 1.11  2010/07/14 21:34:29  mwcsj3
 *  Update end method and added isAChildOfMenuProcess method
 *
 *  Revision 1.10  2010/07/08 19:56:01  mwcsj3
 *  Uncommented setting TTC is user context in end()
 *
 *  Revision 1.9  2010/06/30 17:17:25  mwcsj3
 *  Commented setting TTC is user context in end(), need to revisit the logic
 *
 *  Revision 1.8  2010/06/21 23:00:42  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.6.10.7  2010/06/20 20:03:06  mwakg
 *  Fixed API and 07Q navigations
 *
 *  Revision 1.6.10.6  2010/06/20 18:44:06  mwakg
 *  Fixed API and updated java docs
 *
 *  Revision 1.6.10.5  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6.10.4  2010/06/13 20:52:53  mwakg
 *  Updated copyProcessContext method and moved it from ProcessContext
 *
 *  Revision 1.6.10.3  2010/06/08 01:25:23  mwakg
 *  Provided hook method for ProcessContext to copy another ProcessContext. This hook method will be used for switching PCs
 *
 *  Revision 1.6.10.2  2010/06/08 01:18:27  mwakg
 *  Added Transitions to SubBusinessProcess
 *
 *  Revision 1.6.10.1  2010/05/29 23:40:46  mwcsj3
 *  Added endSubProcess method
 *
 *  Revision 1.6  2010/04/22 22:27:25  mwcsj3
 *  Fixed FIX ME
 *
 *  Revision 1.5  2010/04/22 18:37:12  mwpxp2
 *  Added todo
 *
 *  Revision 1.4  2010/04/08 23:46:27  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.3  2010/04/04 23:41:15  mwakg
 *  Removed ServiceRequest and unused attributes in ProcessContext
 *
 *  Revision 1.2  2010/03/22 23:16:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/15 21:11:15  mwakg
 *  Added implementation of the cancel button
 *
 *  Revision 1.3  2009/10/13 02:59:01  mwrrv2
 *  provided class description.
 *
 *  Revision 1.2  2009/10/07 19:16:34  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:55:32  mwpxp2
 *  Moved to .impl
 *
 *  Revision 1.8  2009/08/27 08:25:01  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.7  2009/08/25 18:24:21  mwsmg6
 *  removed getSessionContext
 *
 *  Revision 1.6  2009/08/20 22:01:35  mwpxp2
 *  Added getSessionContext and serialVersionUID
 *
 *  Revision 1.5  2009/08/11 02:17:59  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
