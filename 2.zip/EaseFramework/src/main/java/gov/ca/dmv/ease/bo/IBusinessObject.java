/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo;

import gov.ca.dmv.ease.fw.IWithCreationModificationStamps;
import gov.ca.dmv.ease.fw.IWithLongId;
import gov.ca.dmv.ease.fw.IWithPropertyAccess;
import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.io.Serializable;

/**
 * Description: This is an interface and BusinessObject implements 
 * this interface.
 * File: IBusinessObject.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: 10/07/2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IBusinessObject extends IWithCreationModificationStamps,
		IWithLongId, IWithPropertyAccess, IValidatable, ITreePrintable, Serializable {
	/**
	 * Gets the business object named.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the business object named
	 */
	IBusinessObject getBusinessObjectNamed(String aPropertyName);

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	Long getId();
}
/**
 *  Modification History:
 * 
 *  $Log: IBusinessObject.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/07 22:07:12  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.3  2010/10/12 22:19:26  mwpxp2
 *  Reinstated IValidatable as super
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:14:09  mwpxp2
 *  Moved to fw.bo
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009-07-12 15:25:55  ppalacz
 *  Moved to BO
 *
*/
