/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.context.impl;

import gov.ca.dmv.ease.app.exception.impl.AccessorNotFoundException;
import gov.ca.dmv.ease.app.exception.impl.PropertyAccessException;
import gov.ca.dmv.ease.app.exception.impl.WrongTypeException;
import gov.ca.dmv.ease.fw.process.IIntrospectiveContext;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;

/**
 * Description: I am an abstract class implementing the context helper methods
 * defined in IIntrospectiveContext
 * 
 * File: IntrospectiveContext.java
 * Module:  gov.ca.dmv.ease.app.context.impl
 * Created: Sep 29, 2009
 * 
 * @author MWSEC2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class IntrospectiveContext implements IIntrospectiveContext {
	/** The fields of IntrospectiveContext as an array */
	private static final Field[] INTROSPECTIVE_CONTEXT_FIELDS = IntrospectiveContext.class
			.getDeclaredFields();
	/** A map of Java wrapper classes to the primitives that they wrap */
	private static final Map <Class <?>, Class <?>> PRIMITIVES;
	/** A static map containing the getter method maps for each concrete process context sub-class type **/
	private static Map<String, Map<String, Method>> GETTER_MAPS = new HashMap<String, Map<String, Method>>();
	/** A static map containing the setter method maps for each concrete process context sub-class type **/
	private static Map<String, Map<String, Method>> SETTER_MAPS = new HashMap<String, Map<String, Method>>();
	/** The serialVersionUID */
	private static final long serialVersionUID = 5678390907081454465L;
	static {
		/*
		 * Initialize the map of wrapper types to their primitives
		 */
		PRIMITIVES = new HashMap <Class <?>, Class <?>>();
		PRIMITIVES.put(Boolean.class, boolean.class);
		PRIMITIVES.put(Character.class, char.class);
		PRIMITIVES.put(Byte.class, byte.class);
		PRIMITIVES.put(Short.class, short.class);
		PRIMITIVES.put(Integer.class, int.class);
		PRIMITIVES.put(Long.class, long.class);
		PRIMITIVES.put(Float.class, float.class);
		PRIMITIVES.put(Double.class, double.class);
	}
	/** The getter methods of the concrete context class as an array (boolean getters included) */
	private transient Map <String, Method> getterMap;
	/** The setter methods of the concrete context class as an array */
	private transient Map <String, Method> setterMap;

	/**
	 * Default constructor
	 */
	public IntrospectiveContext() {
		super();
		init();
	}

	/**
	 * Adds a getter to the getter map. The key is the property name
	 * @param method
	 * @param prefixLen
	 */
	private void addGetter(Method method, int prefixLen) {
		String methodName = method.getName();
		String propName = methodName.substring(prefixLen, prefixLen + 1)
				.toLowerCase();
		if (methodName.length() > prefixLen + 1) {
			propName += methodName.substring(prefixLen + 1);
		}
		getterMap.put(propName, method);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IIntrospectiveContext#copyPropertiesFrom(gov.ca.dmv.ease.fw.process.IProcessContext)
	 */
	public void copyPropertiesFrom(IIntrospectiveContext source) {
		BeanUtils.copyProperties(source, this, getIgnoredFields());
	}

	/**
	 * A method for listing the fields that should not be copied from one context to 
	 * another. This is a default implementation that should be overridden as needed. 
	 */
	protected String[] getIgnoredFields() {
		int len = INTROSPECTIVE_CONTEXT_FIELDS.length;
		String[] fieldNames = new String[len];
		for (int i = 0; i < len; ++i) {
			fieldNames[i] = INTROSPECTIVE_CONTEXT_FIELDS[i].getName();
		}
		return fieldNames;
	}

	/**
	 * The purpose of this method is to provide a means by which concrete context classes
	 * can override this default implementation with a more performance-optimized version,
	 * e.g. one that returns the methods from a cached static member (thus eliminating the 
	 * need to repeatedly invoke the reflective getClass().getMethods method).
	 *  
	 * @return the methods of the class as an array of Method objects
	 */
	protected Method[] getMethods() {
		return getClass().getMethods();
	}

	/* (non-Javadoc)
	 * @see generic.IContextPropertyHelper#getProperty(java.lang.String, java.lang.Class, java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public <T> T getProperty(String name, Class <T> type) {
		T value = null;
		if (getterMap.get(name) == null) {
			throw new AccessorNotFoundException(
					"No public getter found for property " + name);
		}
		if (type == null) {
			throw new PropertyAccessException("Type parameter cannot be null");
		}
		try {
			value = (T) getterMap.get(name).invoke(this, (Object[]) null);
		}
		catch (Exception e) {
			throw new PropertyAccessException(
					"Exception occurred while trying to call getter for property "
							+ name, e);
		}
		if (value != null && !type.isInstance(value)
				&& !isWrapperFor(type.getClass(), value.getClass())
				&& !isWrapperFor(value.getClass(), type.getClass())) {
			throw new WrongTypeException("The getter for " + name + " returns "
					+ value.getClass().getSimpleName()
					+ ". Caller expected type " + type.getSimpleName());
		}
		return value;
	}

	/* (non-Javadoc)
	 * @see context.IContextPropertyAccessor#hasProperty(java.lang.String)
	 */
	public boolean hasProperty(String name) {
		return getterMap.containsKey(name) && setterMap.containsKey(name);
	}

	/**
	 * Initialization method that builds maps of getter and setter
	 * methods at object creation time, for quick access subsequent access
	 */
	private void init() {
		String className = getClass().getName();
		if (GETTER_MAPS.containsKey(className) && SETTER_MAPS.containsKey(className)) {
			getterMap = GETTER_MAPS.get(className);
			setterMap = SETTER_MAPS.get(className);
		} else {
			Method[] methods = getMethods();
			getterMap = new HashMap <String, Method>();
			setterMap = new HashMap <String, Method>();
			for (int i = 0; i < methods.length; ++i) {
				if (isGetter(methods[i])) {
					addGetter(methods[i], GET_LEN);
				}
				else if (isIsser(methods[i])) {
					addGetter(methods[i], IS_LEN);
				}
				else if (isSetter(methods[i])) {
					String methodName = methods[i].getName();
					int prefixLen = SET_LEN;
					int offset = prefixLen + 1;
					String propName = methodName.substring(prefixLen, offset)
							.toLowerCase();
					StringBuffer buffer = new StringBuffer(propName);
					if (methodName.length() > offset) {
						buffer.append(methodName.substring(offset));
					}
					setterMap.put(buffer.toString(), methods[i]);
				}
			}
			GETTER_MAPS.put(className, getterMap);
			SETTER_MAPS.put(className, setterMap);
		}
	}

	/**
	 * Returns true if a method is a Java Bean compliant getter
	 * @param method
	 * @return
	 */
	private boolean isGetter(Method method) {
		boolean isGetterMethod = true;
		if (!method.getName().startsWith(GET_PREFIX)) {
			isGetterMethod = false;
		}
		if (method.getParameterTypes().length != 0) {
			isGetterMethod = false;
		}
		if (void.class.equals(method.getReturnType())) {
			isGetterMethod = false;
		}
		return isGetterMethod;
	}

	/**
	 * Returns true if a method is a Java Bean compliant getter 
	 * for a property of type boolean or Boolean 
	 * @param method
	 * @return
	 */
	private boolean isIsser(Method method) {
		boolean isBooleanGetter = true;
		if (!method.getName().startsWith(IS_PREFIX)) {
			isBooleanGetter = false;
		}
		if (method.getParameterTypes().length != 0) {
			isBooleanGetter = false;
		}
		if (!boolean.class.equals(method.getReturnType())
				&& !Boolean.class.equals(method.getReturnType())) {
			isBooleanGetter = false;
		}
		return isBooleanGetter;
	}

	/**
	 * Returns true if a method is a Java Bean compliant setter 
	 * @param method
	 * @return
	 */
	private boolean isSetter(Method method) {
		boolean isSetterMethod = true;
		if (!method.getName().startsWith(SET_PREFIX)) {
			isSetterMethod = false;
		}
		if (method.getParameterTypes().length != 1) {
			isSetterMethod = false;
		}
		return isSetterMethod;
	}

	/**
	 * Helper method to determine whether one type is a Java wrapper for another, 
	 * e.g Integer is a wrapper for the primitive type int.
	 * @param w the wrapper candidate
	 * @param p the primitive candidate
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean isWrapperFor(Class wrapper, Class primitive) {
		return PRIMITIVES.get(wrapper) != null
				&& !PRIMITIVES.get(wrapper).equals(primitive);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.IIntrospectiveContext#setListProperty(java.lang.String, java.util.List, java.lang.Class)
	 */
	public <E> void setListProperty(String name, List <E> list,
			Class <E> elementType) {
		if (setterMap.get(name) == null) {
			throw new AccessorNotFoundException(
					"No public setter found for list property " + name);
		}
		try {
			Object[] args = { list };
			setterMap.get(name).invoke(this, args);
		}
		catch (Exception e) {
			throw new PropertyAccessException(
					"Exception occurred while trying to call setter for property "
							+ name, e);
		}
	}

	/* (non-Javadoc)
	 * @see generic.IContextPropertyHelper#setProperty(java.lang.String, java.lang.Object, java.lang.Object)
	 */
	public void setProperty(String name, Object value) {
		if (setterMap.get(name) == null) {
			throw new AccessorNotFoundException(
					"No public setter found for property " + name);
		}
		Class <?> paramType = setterMap.get(name).getParameterTypes()[0];
		if (value != null && paramType != null && !paramType.isInstance(value)
				&& !paramType.equals(PRIMITIVES.get(value.getClass()))) {
			throw new WrongTypeException("The setter for "
					+ name
					+ " expects "
					+ setterMap.get(name).getParameterTypes()[0]
							.getSimpleName()
					+ " or convertible type. Caller passed type "
					+ value.getClass().getSimpleName());
		}
		try {
			Object[] args = { value };
			setterMap.get(name).invoke(this, args);
		}
		catch (Exception e) {
			throw new PropertyAccessException(
					"Exception occurred while trying to call setter for property "
							+ name, e);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: IntrospectiveContext.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/08/16 21:56:04  mwkzn
 *  Fixed PMD Issues.
 *
 *  Revision 1.6  2011/08/05 22:05:06  mwsec2
 *  changed hash maps constructor calls to use default initial sizes
 *
 *  Revision 1.5  2011/08/05 20:05:47  mwsec2
 *  optimized init method
 *
 *  Revision 1.4  2011/01/20 19:47:51  mwpxp2
 *  Imports and javadoc cleanup
 *
 *  Revision 1.3  2010/12/01 17:51:47  mwhys
 *  Marked setter and getter maps as transient.
 *
 *  Revision 1.2  2010/10/19 17:19:40  mwsec2
 *  initial check-in
 *
 *  Revision 1.1.2.4  2010/10/12 16:54:25  mwsec2
 *  added getMethods method, to reduce Reflective API calls
 *
 *  Revision 1.1.2.3  2010/10/07 23:13:42  mwsec2
 *  refactored how the ignored fields are loaded
 *
 *  Revision 1.1.2.2  2010/10/07 15:57:28  mwsec2
 *  clean up
 *
 *  Revision 1.1.2.1  2010/10/05 21:26:01  mwsec2
 *  initial check in
 *
 */
