/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: I represent the START activity for all business processes
 * 
 * File: StartActivity.java
 * Module:  gov.ca.dmv.ease.handler.process.activity.impl
 * Created: Mar 23, 2009
 * 
 * @author mwrsk
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class StartActivity extends TransientActivity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4709241400842704030L;
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(StartActivity.class);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext context) {
		if (getNextActivity() != null) {
			LOGGER.debug("Next Activity :: " + getNextActivity().getActivityName());
			getNextActivity().execute(context);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: StartActivity.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/04/30 16:48:11  mwsec2
 *  added logger, logging statement
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2010/11/09 03:19:30  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.6  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/04/14 15:38:59  mwakg
 *  Made activities authorizedExecute protected
 *
 *  Revision 1.4  2010/04/13 23:24:19  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.3  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.2  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.2  2010/02/26 19:09:25  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/27 18:43:42  mwakg
 *  First cut of secuity changes.
 *
 *  1) moved SecurityRole from TUS to FW
 *  2) StartActivity exetends SecuredActivity
 *  3) SecuredActivity extends TransientActivity
 *  4) Created DlaStartActivity which would initiate Dla business process
 *  5) Added DlaStartActivity into dla_business_process-poc.xml and applicationContext-app.xml
 *
 *  Revision 1.3  2009/10/23 18:33:42  mwrka1
 *  removed unused imports
 *
 *  Revision 1.2  2009/10/21 23:33:28  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/03 20:57:18  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.4  2009/08/10 23:30:09  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
