/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.service.impl;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.bus.service.ICodeSetLoader;
import gov.ca.dmv.ease.bus.service.ICodeSetService;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am a Service for CodeSet.
 * File: CodeSetService.java 
 * Module: gov.ca.dmv.ease.bus.service.impl 
 * Created: Apr 11, 2009
 * @author MWKZD1
 * @version $Revision: 1.5 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ 
 * Last Changed By: $Author: mwsec2 $
 */
public class CodeSetService implements ICodeSetService {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(CodeSetService.class);
	/** The code set loader. */
	private ICodeSetLoader codeSetLoader;
	/** The code set registry. */
	private ICodeSetRegistrySingleton codeSetRegistry;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bus.service.impl.ICodeSetService#retrieveAllCodeSets(
	 * java.util.List)
	 */
	public List <ICodeSet> getAllCodeSets(IUserContext userContext) {
		List <ICodeSet> returnList = getPopulatedRegistry(userContext)
				.getAllCodeSets();
		return returnList;
	}

	/**
	 * Gets the code set loader.
	 * 
	 * @return the codeSetLoader
	 */
	public ICodeSetLoader getCodeSetLoader() {
		return codeSetLoader;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bus.service.ICodeSetService#getCodeSetNamed(java.lang
	 * .String, gov.ca.dmv.ease.bo.user.IUserContext)
	 */
	public ICodeSet getCodeSetNamed(String aCodeSetName,
			IUserContext userContext) {
		LOGGER.debug("getCodeSetNamed(String aCodeSetName = " + aCodeSetName
				+ ", IUserContext userContext)");
		ICodeSet codeSet = getPopulatedRegistry(userContext).getCodeSetNamed(
				aCodeSetName);
		LOGGER.debug("codeSet = " + codeSet);
		return codeSet;
	}

	/**
	 * Gets the code set registry.
	 * 
	 * @return the codeSetRegistry
	 */
	public ICodeSetRegistrySingleton getCodeSetRegistry() {
		return codeSetRegistry;
	}

	/**
	 * Gets the populated registry.
	 * 
	 * @param userContext the user context
	 * 
	 * @return the populated registry
	 */
	protected ICodeSetRegistrySingleton getPopulatedRegistry(
			IUserContext userContext) {
		if (codeSetRegistry.isEmpty()) {
			synchronized (this) {
				if (codeSetRegistry.isEmpty()) {
					loadCodeSets(userContext, codeSetRegistry);
				}
			}
		}
		return codeSetRegistry;
	}

	/**
	 * Load code sets.
	 * 
	 * @param userContext the user context
	 * @param aRegistry the a registry
	 */
	protected void loadCodeSets(IUserContext userContext,
			ICodeSetRegistrySingleton aRegistry) {
		LOGGER
				.debug("loadCodeSets(IUserContext userContext, ICodeSetRegistrySingleton aRegistry = "
						+ aRegistry + ")");
		getCodeSetLoader().loadAllCodeSets(userContext, aRegistry);
		LOGGER.debug("aRegistry = " + aRegistry + ")");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.service.ICodeSetService#reloadCodeSetRegistry()
	 */
	public void reloadCodeSetRegistry() {
		loadCodeSets(new UserContext(), getCodeSetRegistry());
	}
	
	/**
	 * Sets the code set loader.
	 * 
	 * @param codeSetLoader the codeSetLoader to set
	 */
	public void setCodeSetLoader(ICodeSetLoader codeSetLoader) {
		this.codeSetLoader = codeSetLoader;
	}

	/**
	 * Sets the code set registry.
	 * 
	 * @param codeSetRegistry the codeSetRegistry to set
	 */
	public void setCodeSetRegistry(ICodeSetRegistrySingleton codeSetRegistry) {
		this.codeSetRegistry = codeSetRegistry;
	}
}
/**
 * Modification History:
 * 
 * $Log: CodeSetService.java,v $
 * Revision 1.5  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.2  2013/05/30 17:36:02  mwsec2
 * rebase from Head
 *
 * Revision 1.4  2013/03/19 17:45:07  mwkfh
 * updated getPopulatedRegistry to sync load and allow future parallel reads
 *
 * Revision 1.3  2013/03/12 21:29:39  mwkfh
 * synchronized getPopulatedRegistry
 *
 * Revision 1.2  2013/03/07 18:00:12  mwkfh
 * added debug logging
 *
 * Revision 1.1  2012/10/01 02:57:32  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.6  2010/04/22 19:11:40  mwpxp2
 * Bulk cleanup - added missing javadoc
 *
 * Revision 1.5  2010/03/28 00:02:58  mwakg
 * Injected loader and registry instead of hardcoding
 *
 * Revision 1.4  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.3  2010/03/22 23:18:51  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2010/01/28 18:04:37  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.14  2009/10/20 23:14:39  mwsxd10
 * Test case updated.
 * Revision 1.13 2009/10/07 19:10:10 mwbxp5
 * Removed LOGGER
 * 
 * Revision 1.12 2009/10/03 21:19:26 mwpxp2 Adjusted imports for fw
 * refactorings; bulk cleanup
 * 
 * Revision 1.11 2009/08/27 04:26:03 mwsmg6 moved framework-related classes to
 * the Framework project
 * 
 * Revision 1.10 2009/08/19 00:05:29 mwbxp5 organized the imports
 * 
 * Revision 1.9 2009/08/17 15:46:22 mwbxp5 Added logging.
 * 
 * Revision 1.8 2009/08/06 17:52:37 mwpxp2 Adjusted for interface chamges
 * 
 */
