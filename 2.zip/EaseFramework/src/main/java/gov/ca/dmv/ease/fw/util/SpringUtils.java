/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.util;

import gov.ca.dmv.ease.fw.constants.IResourceBundleConstants;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Description:  A Spring Utility
 * <p>
 * contains Convenient methods: <p>
 * <code>
 * getBean(String name) -  Get the spring bean by the specified name.  <p>
 * getMessage(String resourceBundleType, String name) - Get the message by its name with a specified resource. <p>
 * getMessage(String name, Object[] param) - Get the message by its name with a replacement parameters
 * </code>
 * <p>
 * File: SpringUtils.java
 *  //FIXME - move this to .impl package 
 *  //FIXME - replace literals with static or interface-defined vars
 *  
 * Module:  gov.ca.dmv.ease.fw.util
 * Created: Oct 28, 2009 
 * @author MWRPK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SpringUtils implements ApplicationContextAware {
	/** The context. */
	public static ApplicationContext CONTEXT;

	/**
	 * The function initializes Spring Application Context. The code
	 * follows a singleton pattern
	 * <p>
	 * This function will be called only when the Container has not Initialized the Spring Validator Beans!!
	 * 
	 * @return ApplicationContext (spring application context)
	 * 
	 */
	private static ApplicationContext getApplicationContext() {
		if (CONTEXT == null) {
			String[] springContextFiles = new String[] {
					"classpath*:spring/applicationContext-ttc.xml",
					"classpath*:spring/applicationContext-office-type.xml",
					"classpath*:spring/applicationContext-office-processing-allowed.xml",
					"classpath*:spring/applicationContext-office-ttc.xml",
					"classpath*:spring/applicationContext-validators.xml" };
			CONTEXT = new ClassPathXmlApplicationContext(springContextFiles);
		}
		return CONTEXT;
	} // getApplicationContext

	/**
	 * Gets the bean by its name 
	 * 
	 * @param name The name of the bean
	 * 
	 * @return The Spring bean
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getBean(String name) {
		if (CONTEXT == null) {
			return (T) SpringUtils.getApplicationContext().getBean(name);
		}
		else {
			return (T) SpringUtils.CONTEXT.getBean(name);
		}
	} // getBean

	/**
	 *  Get the message by its name 
	 * 
	 * @param key The key of the message
	 * 
	 * @return The Spring bean
	 */
	public static String getMessage(String key) {
		if (CONTEXT == null) {
			return ((MessageSource) SpringUtils.getApplicationContext()
					.getBean("messages"))
					.getMessage(key, null, "Default", null);
		}
		else {
			return ((MessageSource) SpringUtils.CONTEXT.getBean("messages"))
					.getMessage(key, null, "Default", null);
		}
	} // getMessage

	/**
	 *  Get the message by its name with a replacement parameters
	 * 
	 * @param name The name of the bean
	 * @param param The replacement parameters
	 * @return The Spring bean
	 */
	public static String getMessage(String name, Object[] param) {
		if (CONTEXT == null) {
			return ((MessageSource) SpringUtils.getApplicationContext()
					.getBean("messages")).getMessage(name, param, "Default",
					null);
		}
		else {
			return ((MessageSource) SpringUtils.CONTEXT.getBean("messages"))
					.getMessage(name, param, "Default", null);
		}
	} // getMessage

	/**
	 *  Get the message by its name with a specified resource.
	 * 
	 * @param resourceBundleType the resource bundle type
	 * @param name The name of the bean
	 * 
	 * @return The Spring bean
	 * @see IResourceBundleConstants
	 */
	public static String getMessage(String resourceBundleType, String name) {
		if (CONTEXT == null) {
			return ((MessageSource) SpringUtils.getApplicationContext()
					.getBean(resourceBundleType)).getMessage(name, null,
					"Default", null);
		}
		else {
			return ((MessageSource) SpringUtils.CONTEXT
					.getBean(resourceBundleType)).getMessage(name, null,
					"Default", null);
		}
	} // getMessage

	/**
	 *  No Args Constructor
	 */
	protected SpringUtils() {
	} // SpringUtils

	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		CONTEXT = applicationContext;
	} //setApplicationContext
}
/**
 *  Modification History:
 *
 *  $Log: SpringUtils.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2012/08/16 21:44:30  mwkzn
 *  Renamed local variables appropriately per PMD
 *
 *  Revision 1.8  2011/06/09 18:03:29  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2011/01/18 18:32:45  mwxxw
 *  Add one more spring config file: "classpath*:spring/applicationContext-office-ttc.xml".
 *
 *  Revision 1.6  2011/01/18 18:23:27  mwxxw
 *  Add two new spring configuration files:
 *  "classpath*:spring/applicationContext-office-type.xml"
 *  "classpath*:spring/applicationContext-office-processing-allowed.xml"
 *
 *  Revision 1.5  2010/08/20 18:26:07  mwpxp2
 *  Added fixmes;bulk formatted
 *
 *  Revision 1.4  2010/05/28 16:49:32  mwrpk
 *  bug fix
 *
 *  Revision 1.3  2010/03/22 23:34:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 17:31:31  mwbxp5
 *  changed name to key
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/28 23:50:22  mwrpk
 *  Adding Java Docs.
 *
 *  Revision 1.2  2009/10/15 22:42:23  mwhxa2
 *  Added Generic getMessage() to accept Resource bundle bean as input
 *
 *  Revision 1.1  2009/10/11 22:51:35  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.3  2009/10/03 21:05:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/09/24 17:27:03  mwhxa2
 *  Added getMessage() to handle replacement params
 *
 *  Revision 1.1  2009/09/22 23:53:43  mwrrv3
 *  Re-factoring  business rule validations code from service layers (Task Service, Business Utility Service and Communication Service) to a common business objects project.
 *
 *  Revision 1.1  2009/09/08 23:50:03  mwrpk
 *  Modifying / Adding to Use Spring To read error messages and properties.
 *
 */
