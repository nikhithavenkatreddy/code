/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response;

/**
 * Description: I am interface for a response token provided to the caller
 * for accessing large/persisted messages.
 * File: IPersistedResponseToken.java
 * Module:  gov.ca.dmv.ease.ecs.response
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPersistedResponseToken extends IEcsResponse {
	/**
	 * Gets the persisted response class name.
	 *
	 * @return the persisted response class name
	 */
	String getPersistedResponseClassName();

	/**
	 * Answers the identifier of the persisted response object.
	 *
	 * @return the string
	 */
	String getPersistedResponseId();
}
/**
 *  Modification History:
 *
 *  $Log: IPersistedResponseToken.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/14 16:47:48  mwhxb3
 *  updated comments
 *
 *  Revision 1.4  2009/10/06 21:53:43  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.8.1  2009/10/06 20:28:48  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3  2009/07/27 18:30:07  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/14 23:58:50  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.4  2009-05-14 22:02:13  ppalacz
 *  Removed getIndexSize/0 in favor of  getObjectCount/0 in the superclass
 *
 *  Revision 1.3  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-05-13 20:29:11  ppalacz
 *  Added getPersistedResponse* calls
 *
 *  Revision 1.1  2009-05-12 22:20:32  ppalacz
 *  Initial
 *
*/
