/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request;

import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;

/**
 * Description: I define the interface to PersistenceServiceRequest
 * 
 * File: IPersistenceServiceRequest.java
 *  
 *  //FIXME - execute() should return an interface
 *  
 * Module:  gov.ca.dmv.ease.tus.persist.request
 * Created: Sep 3, 2009 
 * @author MWRSK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPersistenceServiceRequest {
	/**
	 * Abstract method which all the persistence service request classes should override
	 * for executing the corresponding method in persistence service.
	 * 
	 * @return the persistence service response
	 */
	PersistenceServiceResponse execute();
}
/**
 *  Modification History:
 * 
 *  $Log: IPersistenceServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/09/28 06:55:56  mwpxp2
 *  Added fixme
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/13 23:18:06  mwrsk
 *  Moved PersistenceServiceResponse to impl package
 *
 *  Revision 1.4  2009/10/13 22:21:27  mwrsk
 *  Remove access modifiers
 *
 *  Revision 1.3  2009/10/13 20:59:13  mwrsk
 *  Remove access modifiers
 *
 *  Revision 1.2  2009/10/03 21:32:50  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.1  2009/09/03 22:24:16  mwrsk
 *  Created an interface
 *
*/
