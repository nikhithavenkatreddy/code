/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.util.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Calendar;

/**
 * Description: This class contains the utility methods for generating unique IDs for ECS.
 * File: IdGeneratorUtil.java
 * Module:  gov.ca.dmv.ease.ecs.util.impl
 * Created: Apr 1, 2010 
 * @author MWHXB3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class IdGeneratorUtil {
	/** Default office id if not set in user context. **/
	private static final String DEFAULT_OFFICE_ID = "O20";
	/** Default tech id if not set in user context. **/
	private static final String DEFAULT_TECH_ID = "T2";

	/**
	 * Extract the time stamp.
	 * @param calender
	 * @return a String
	 */
	private static String extractTimestamp(Calendar calender) {
		return ljustify(calender.get(java.util.Calendar.YEAR), 4)
				+ ljustify(calender.get(java.util.Calendar.MONTH) + 1, 2)
				+ ljustify(calender.get(java.util.Calendar.DATE), 2)
				+ ljustify(calender.get(java.util.Calendar.HOUR), 2)
				+ ljustify(calender.get(java.util.Calendar.MINUTE), 2)
				+ ljustify(calender.get(java.util.Calendar.SECOND), 2)
				+ ljustify(calender.get(java.util.Calendar.MILLISECOND), 5);
	}

	/**
	 * Generate the unique id using UserContext information
	 * Uses the Office Id and Tech Id from the UserContext
	 * Also uses current timestamp .
	 * 
	 * @param userContext a UserContext
	 * 
	 * @return id an unique id
	 */
	public static String generateUniqueId(IUserContext userContext) {
		String id = null, officeId = null, techId = null;
		StringBuilder sb = new StringBuilder();
		if (userContext == null || userContext.getOfficeId() == null
				|| userContext.getOfficeId().equalsIgnoreCase("")) {
			officeId = DEFAULT_OFFICE_ID;
		}
		else {
			officeId = userContext.getOfficeId();
		}
		if (userContext == null || userContext.getTechId() == null
				|| userContext.getTechId().equalsIgnoreCase("")) {
			techId = DEFAULT_TECH_ID;
		}
		else {
			techId = userContext.getTechId();
		}
		sb.append(officeId + techId);
		Calendar calender = Calendar.getInstance();
		sb.append(extractTimestamp(calender));
		id = sb.toString();
		return id;
	}

	/**
	 * Used for padding zeroes to a number.
	 * 
	 * @param number the number
	 * @param stringLength the string length
	 * 
	 * @return the string
	 */
	public static String ljustify(int number, int stringLength) {
		String preJust = Integer.toString(number);
		for (int j = preJust.length(); j < stringLength; j++) {
			preJust = "0" + preJust;
		}
		return preJust;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IdGeneratorUtil.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/04/22 19:23:57  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/04/01 18:24:34  mwhxb3
 *  This class contains the utility methods for generating unique IDs for ECS.
 *
 */
