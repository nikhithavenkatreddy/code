/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.auth.request.IAuthAndAuthServiceRequest;
import gov.ca.dmv.ease.tus.auth.response.IAuthAndAuthServiceResponse;

import java.util.Date;

/**
 * Description: I define the AuthAndAuthRequest interface
 * 
 * File: AuthAndAuthServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.auth.request.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/30 17:05:06 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class AuthAndAuthServiceRequest extends AbstractRequest
		implements IAuthAndAuthServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7061534909735756181L;

	/**
	 * The Default Constructor.
	 */
	public AuthAndAuthServiceRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public AuthAndAuthServiceRequest(IUserContext userContext) {
		super(userContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.IAuthAndAuthServiceRequest#execute()
	 */
	public abstract IAuthAndAuthServiceResponse execute();

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuthAndAuthServiceRequest.java,v $
 *  Revision 1.2  2012/10/30 17:05:06  mwkfh
 *  added AuthAndAuthServiceRequest
 *
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/10/25 23:47:34  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
