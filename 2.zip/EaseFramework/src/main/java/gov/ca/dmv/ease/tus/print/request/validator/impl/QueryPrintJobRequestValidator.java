/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.validator.impl;

import gov.ca.dmv.ease.ecs.exception.impl.EcsPrintServiceValidationException;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;
import gov.ca.dmv.ease.tus.print.request.impl.QueryPrintJobRequest;

/**
 * Description: This is validator for {@link QueryPrintJobRequest}
 * File: QueryPrintJobRequestValidator.java
 * Module: gov.ca.dmv.ease.tus.print.request.validator.impl
 * Created: Feb 1, 2010
 * @author MWHXA2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class QueryPrintJobRequestValidator extends
		AbstractPrintJobRequestValidator {
	/** The Request. */
	private static final String REQUEST = "QueryPrintJobRequest";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4729413025839992451L;

	/**
	 * This method validates {@link QueryPrintJobRequest}.
	 * 
	 * @param request The QueryPrintJobRequest to validate
	 * @param aCollector the a collector
	 * 
	 * @return <code>IErrorCollector</code> containing Validation Messages.
	 * 
	 * @see IErrorCollector
	 * @see EcsPrintServiceValidationException
	 * @see QueryPrintJobRequest
	 */
	public static void validateRequest(IPrintServiceRequest request,
			IErrorCollector aCollector) {
		if (!(request instanceof QueryPrintJobRequest)) {
			aCollector.register(new EcsPrintServiceValidationException(
					"Not a valid Request Type. Expected: " + REQUEST + " was "
							+ request.getClass()));
		}
		else {
			//Validate Request
			QueryPrintJobRequest queryPrintJobRequest = (QueryPrintJobRequest) request;
			if (EaseUtil.isNullOrBlank(queryPrintJobRequest.getClientJobId())) {
				aCollector.register(new EcsPrintServiceValidationException(
						"Client Job ID is NULL"));
			}
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: QueryPrintJobRequestValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/02 00:14:56  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.3  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/08 02:04:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/06/30 00:24:59  mwhxa2
 *  Print Validators
 *
 */
