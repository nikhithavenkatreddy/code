/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: This interface holds constants for resource bundle messages. 
 * File: IMessageConstants.java
 * Module:  gov.ca.dmv.ease.fw.constants
 * Created: Oct 15, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageConstants {
	/** The Document Resource Bundle. */
	String APPLICATION_NAME = "ease.application.NAME";
	/** TAI_TOKEN_ENABLED */
	String TAI_TOKEN_ENABLED = "ease.application.TAI_TOKEN_ENABLED";
	/** TAI_TOKEN_ENABLED */
	String CDLIS_PDPS_CALL_WAIT_TIME = "ECS_CALL_WAIT_TIME";
}
/**
 *  Modification History:
 * 
 *  $Log: IMessageConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2011/06/22 20:52:10  mwyxg1
 *  add cdlis pdps wait time property
 *
 *  Revision 1.2  2009/12/02 18:06:24  mwakg
 *  Added support for dynamically mocking Username class
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/11/02 17:11:15  mwhxa2
 *  Updated error msg resource bundle value
 *
 *  Revision 1.1  2009/10/15 22:42:44  mwhxa2
 *  Adding Resource Bundle constants file
 *
*/
