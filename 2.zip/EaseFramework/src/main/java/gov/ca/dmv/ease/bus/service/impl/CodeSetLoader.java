/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.service.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.code.impl.CodeSet;
import gov.ca.dmv.ease.bus.service.ICodeSetLoader;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveAllBusinessObjectsResponse;

import java.util.List;

/**
 * Description: I am implementation of ICodeSetLoader.
 * File: CodeSetLoader.java
 * Module: gov.ca.dmv.ease.bus.service.impl 
 * Created: Aug 4, 2009
 * @author MWBXP5
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ Last
 * Changed By: $Author: mwsec2 $
 */
public class CodeSetLoader implements ICodeSetLoader {
	/** The persistence service request factory. */
	private PersistenceServiceRequestFactory persistenceServiceRequestFactory;

	/**
	 * 
	 * 
	 * @return the persistenceServiceRequestFactory
	 */
	public PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return persistenceServiceRequestFactory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.bus.service.ICodeSetLoader#loadAllCodeSets(gov.ca.dmv
	 * .ease.bo.user.IUserContext,
	 * gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton)
	 */
	public void loadAllCodeSets(IUserContext userContext,
			ICodeSetRegistrySingleton registry) {
		IPersistenceServiceRequest request = getPersistenceServiceRequestFactory()
				.createRetrieveAllBusinessObjectsRequest(userContext,
						CodeSet.class);
		RetrieveAllBusinessObjectsResponse aResponse = (RetrieveAllBusinessObjectsResponse) request
				.execute();
		// Casting the persistenceService response to the List of
		// BusinessObjects
		List <IBusinessObject> listOfBusinessObjects = aResponse.getResults();
		
		synchronized( registry ) { // blocks access to registry while it is reloaded 
			registry.reset();
			for (IBusinessObject obj : listOfBusinessObjects) {
				CodeSet codeSet = (CodeSet) obj;
				registry.register(codeSet);
			}
	    } 	
	}

	/**
	 * 
	 * 
	 * @param aFactory 
	 */
	public void setPersistenceServiceRequestFactory(
			PersistenceServiceRequestFactory aFactory) {
		persistenceServiceRequestFactory = aFactory;
	}
}
/**
 * Modification History:
 * 
 * $Log: CodeSetLoader.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/01/03 17:19:20  mwsec2
 * Adding support for reloading CodeSet registry via a JMX call
 *
 * Revision 1.1  2012/10/01 02:57:32  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.8  2011/01/17 05:52:30  mwpxp2
 * Cleanup
 *
 * Revision 1.7  2010/09/13 04:39:50  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.6  2010/08/31 17:56:45  mwhys
 * Marked Service(s) as transient.
 *
 * Revision 1.5  2010/04/22 19:13:01  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.4  2010/03/28 00:02:28  mwakg
 * Injected PersistenceServiceRequestFactory instead of working on ApplicationContextAware
 *
 * Revision 1.3  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.2  2010/01/28 18:04:37  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.9  2009/10/07 19:10:10  mwbxp5
 * Removed LOGGER
 *
 * Revision 1.8  2009/10/03 21:19:26  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.7  2009/10/01 18:45:54  mwsxd10
 * Removed auto-generated comments.
 *
 * Revision 1.6  2009/09/03 22:30:05  mwrsk
 * Use IPersistenseSeriveRequest interface instead of the abstract class
 *
 * Revision 1.5  2009/08/27 04:24:24  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.4  2009/08/19 00:05:30  mwbxp5
 * organized the imports
 *
 * Revision 1.3  2009/08/17 15:46:22  mwbxp5
 * Added logging.
 *
 * Revision 1.2  2009/08/07 00:12:59  mwkxk4
 * Provided implementation for loadAllCodeSets method
 * Revision 1.1 2009/08/06 17:51:48 mwpxp2 Renamed
 * - removed the Impl suffix; changed signature to a single call using a
 * registry instance
 * 
 * Revision 1.1 2009/08/05 00:05:44 mwbxp5 Added CodeSet and
 * CodeSetElement--Initial
 * 
 */
