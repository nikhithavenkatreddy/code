/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.impl;

import gov.ca.dmv.ease.fw.auth.IAuthorizable;

import java.util.List;

/**
 * Description: I am an AuthenticationRequestValidation class to provide the validation API's for Authentication and Authorization services
 *  
 *  
 * File: AuthenticationRequestValidation.java
 * Module:  gov.ca.dmv.ease.service.tech.auth.util
 * Created: Apr 16, 2009
 * 
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuthenticationRequestValidation {
	/** The password. */
	public String password = "";
	/** The role name. */
	public String roleName = "";
	/** The user id. */
	public String userId = "";

	/**
	 * Instantiates a new auth request validation.
	 */
	public AuthenticationRequestValidation() {
	}

	/**
	 * Validate authentication request.
	 * 
	 * @param userId the user id
	 * @param password the password
	 * 
	 * @return true, if successful
	 */
	public boolean validateAuthenticationRequest(List <IAuthorizable> managers,
			String password) {
		if (managers == null || password == null || managers.isEmpty()) {
			return false;
		}
		else {
			return true;
		}
	}

	/**
	 * Validate authentication request.
	 * 
	 * @param userId the user id
	 * @param password the password
	 * 
	 * @return true, if successful
	 */
	public boolean validateAuthenticationRequest(String userId, String password) {
		if (userId != null && userId.trim().length() > 0 && password != null
				&& password.trim().length() > 0) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Validate authorization request.
	 * 
	 * @param roleName the role name
	 * 
	 * @return true, if successful
	 */
	public boolean validateAuthorizationRequest(String roleName) {
		if (roleName != null && roleName.trim().length() > 0) {
			return true;
		}
		else {
			return false;
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AuthenticationRequestValidation.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:36:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/20 21:18:43  mwrsk
 *  Added disclaimer
 *
 *  Revision 1.4  2009/10/14 02:48:36  mwkkc
 *  I1 Close Down - Code Review
 *
 *  Revision 1.3  2009/10/12 18:15:41  mwkkc
 *  Approval Authorization and JAAS implementation.
 *
 *  Revision 1.2  2009/07/21 21:18:36  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:44  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 18:17:10  mwpxp2
 *  Added fixme
 *
 *  Revision 1.1  2009-07-11 17:23:03  mwpxp2
 *  Moved to .impl package; cleaned up comments and javadoc; added todos
 *
 *  Revision 1.1  2009-07-10 07:13:57  mwpxp2
 *  Synch
 *
 */
