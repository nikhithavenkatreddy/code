/*
 * 
 */
package gov.ca.dmv.ease.tus.auth.service;

import gov.ca.dmv.ease.tus.auth.request.impl.AuthorizeApproverRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsListRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsMapRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveOperationalModesRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest;
import gov.ca.dmv.ease.tus.auth.response.IAuthorizeApproverResponse;
import gov.ca.dmv.ease.tus.auth.response.ILocationEnforcementResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsListResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsMapResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveOperationalModesResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveUserAuthorizedRolesResponse;

import java.io.Serializable;

/**
 * Description: I am an Interface class to define the both the Authentication and Authorization services 
 * File: IAuthenticationService.java
 * Module:  gov.ca.dmv.ease.service.tech.auth
 * Created: Apr 16, 2009
 * 
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IAuthAndAuthService extends Serializable {
	/**
	 * Verify authorization of a user.  Returns true if user authenticates and
	 * has the approver group for the passed in office id assigned
	 * 
	 * @param AuthorizeApproverRequest
	 * 
	 * @return IAuthAndAuthServiceResponse
	 */
	IAuthorizeApproverResponse execute(AuthorizeApproverRequest request);

	/**
	 * Return List of authorized TTCs for passed in list of role names.
	 * 
	 * @param RetrieveAuthorizedTtcsListRequest
	 * 
	 * @return IRetrieveAuthorizedTtcsListResponse
	 */
	IRetrieveAuthorizedTtcsListResponse execute(
			RetrieveAuthorizedTtcsListRequest request);

	/**
	 * Return Map of authorized TTCs for passed in list of role names.
	 * 
	 * @param RetrieveAuthorizedTtcsMapRequest
	 * 
	 * @return IRetrieveAuthorizedTtcsMapResponse
	 */
	IRetrieveAuthorizedTtcsMapResponse execute(
			RetrieveAuthorizedTtcsMapRequest request);

	/**
	 * Return Map of operational modes for passed in office id.
	 * 
	 * @param RetrieveOperationalModesRequest
	 * 
	 * @return IRetrieveOperationalModesResponse
	 */
	IRetrieveOperationalModesResponse execute(
			RetrieveOperationalModesRequest request);

	/**
	 * Return List of user's authorized roles.
	 * 
	 * @param RetrieveUserAuthorizedRolesRequest
	 * 
	 * @return IRetrieveUserAuthorizedRolesResponse
	 */
	IRetrieveUserAuthorizedRolesResponse execute(
			RetrieveUserAuthorizedRolesRequest request);
	
	/**
	 * Verify the location of a user.  Returns true if user's office id or remote office id 
	 * match the user's office id in the DB.
	 * 
	 * @param LocationEnforcementRequest
	 * 
	 * @return ILocationEnforcementResponse
	 */
	ILocationEnforcementResponse execute(LocationEnforcementRequest request);
			
}
/**
 *  Modification History:
 * 
 *  $Log: IAuthAndAuthService.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.27  2011/01/18 19:50:54  mwxxw
 *  Move office business related logic from AuthAndAuthService to OfficeBusinessService.
 *
 *  Revision 1.26  2010/12/16 22:13:35  mwxxw
 *  Remove the old API: isAuthorizedApprover().
 *
 *  Revision 1.25  2010/12/09 00:30:26  mwxxw
 *  Add new service to AuthAndAuthService for Office Business.
 *
 *  Revision 1.24  2010/11/30 18:53:55  mwxxw
 *  Add the following new service for location enforcement service:
 *  ILocationEnforcementResponse execute(LocationEnforcementRequest request);
 *
 *  Revision 1.23  2010/11/22 22:07:41  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 *  Revision 1.22  2010/10/15 00:35:48  mwkfh
 *  moved constants to IAuthAndAuthContants
 *
 *  Revision 1.21  2010/10/12 21:54:56  mwkfh
 *  added APPROVAL_AUTHORITY_PASSWORD_REQUIRED
 *
 *  Revision 1.20  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 *  Revision 1.19  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.18  2010/09/01 19:07:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.17  2010/08/27 16:23:58  mwkfh
 *  removed methods
 *
 *  Revision 1.16  2010/08/20 16:20:57  mwkfh
 *  deprecated authenticateUser()
 *
 *  Revision 1.15  2010/08/04 18:19:26  mwkfh
 *  updated the name getAuthorizedTtcs
 *
 *  Revision 1.14  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2010/07/07 20:02:15  mwkfh
 *  caught CredentialDestroyedException and wrote to log
 *
 *  Revision 1.12  2010/07/07 19:47:41  mwkfh
 *  changed isAuthorizedApprover() to throw CredentialDestroyedException
 *
 *  Revision 1.11  2010/06/30 18:29:40  mwkfh
 *  overloaded isAuthorizedApprover()
 *
 *  Revision 1.10  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.6.2.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.9  2010/06/03 16:06:50  mwkfh
 *  changed authMgr to isAuthorizedApprover() and fixed FacesContext bug for invalid state.
 *
 *  Revision 1.8  2010/06/01 17:20:07  mwkfh
 *  set authorizeManager() to throw LoginException
 *
 *  Revision 1.7  2010/06/01 17:08:01  mwkfh
 *  added officeId to authorizeManager() params
 *
 *  Revision 1.6  2010/05/20 22:17:21  mwkkc
 *  Updated JavaDoc comments - mwkfh
 *
 *  Revision 1.5  2010/05/20 22:12:47  mwvkm
 *  Made it serializable
 *
 *  Revision 1.4  2010/05/20 20:38:02  mwrpk
 *  updating getAuthorizedTtcsMap()
 *
 *  Revision 1.3  2010/05/19 22:10:41  mwkkc
 *  added getAuthorizedTtcsMap() - mwkfh
 *
 *  Revision 1.2  2010/05/18 22:34:43  mwkkc
 *  Added getUserAuthorizedRoles(), getAuthorizedTtcs(), and getAuthorizedTtcs() - mwkfh
 *
 *  Revision 1.1  2010/05/18 19:35:46  mwkkc
 *  AuthenticationService renamed to AuthAndAuthService - mwkfh
 *
 *  Revision 1.2  2010/03/22 23:36:32  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/31 22:36:25  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.8  2009/10/20 21:22:07  mwrsk
 *  Removed modifiers
 *
 *  Revision 1.7  2009/10/16 02:33:21  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.6  2009/10/12 18:15:41  mwkkc
 *  Approval Authorization and JAAS implementation.
 *
 *  Revision 1.5  2009/10/03 21:32:47  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/09/23 00:01:15  mwbxp5
 *  Added authorization activity and its related classes
 *
 *  Revision 1.3  2009/09/22 23:15:17  mwkkc
 *  Design Work
 *
 *  Revision 1.2  2009/07/21 21:18:36  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:44  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 18:17:29  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-07-11 17:24:42  mwpxp2
 *  Moved to service package; cleaned up comments and javadoc; added todos
 *
 *  Revision 1.1  2009-07-10 07:13:56  mwpxp2
 *  Synch
 *
 */
