/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.validate.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Description: I am abstract implementation of IValidator
 * I also provide static utility methods usable in validation
 * File: AbstractValidator.java
 * Module:  gov.ca.dmv.ease.fw.validate.impl
 * Created: Jul 30, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractValidator {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4013674624393176422L;

	/**
	 * Check value as per regex.
	 * 
	 * @param aValue the a value
	 * @param aRegex the a regex
	 * 
	 * @return true, if successful
	 */
	public static boolean checkValueAsPerRegex(String aValue, String aRegex) {
		Pattern p = Pattern.compile(aRegex);
		Matcher m = p.matcher(aValue);
		boolean matches = m.matches();
		return matches;
	}

	/**
	 * Check value in the array.
	 * 
	 * @param value the value
	 * @param possibleValues the possible values
	 * 
	 * @return true, if successful
	 */
	public static boolean checkValueInTheArray(String value,
			String[] possibleValues) {
		boolean found = false;
		int length = possibleValues.length;
		for (int i = 0; i < length; i++) {
			if (possibleValues[i] != null
					&& possibleValues[i].trim().equals(value)) {
				found = true;
				break;
			}
		}
		return found;
	}

	/**
	 * Checks if is not blank.
	 * 
	 * @param aString the a string
	 * 
	 * @return true, if is not blank
	 */
	public static boolean isNotBlank(String aString) {
		return aString != null && aString.trim().length() > 0;
	}

	/**
	 * Checks if is not null.
	 * 
	 * @param anObject the input object
	 * 
	 * @return true, if is not null
	 */
	public static boolean isNotNull(Object anObject) {
		return anObject != null;
	}

	/**
	 * Check if Input Object is Null or Blank.
	 * 
	 * @param anObject 
	 * @return true, if null or blank
	 */
	public static boolean isNullOrBlank(Object anObject) {
		if (anObject == null) {
			return true;
		}
		else {
			if (anObject instanceof String) {
				String str = (String) anObject;
				return (str.trim().equals("")) ? true : false;
			}
			else if (anObject instanceof Collection) {
				Collection <?> collection = (Collection <?>) anObject;
				return (collection.size() == 0) ? true : false;
			}
			else if (anObject instanceof CodeSetElement) {
				return isNullOrBlank(((CodeSetElement) anObject).getCode()) ? true
						: false;
			}
		}
		return false;
	}

	/**
	 * Checks if is nullor empty.
	 * 
	 * @param obj the obj
	 * 
	 * @return true, if is nullor empty
	 */
	public static boolean isNullorEmpty(Object obj) {
		if (obj == null) {
			return true;
		}
		else {
			if (obj instanceof String) {
				String str = (String) obj;
				return (str.trim().equals("")) ? Boolean.TRUE : Boolean.FALSE;
			}
			else if (obj instanceof Collection) {
				Collection <?> collection = (Collection <?>) obj;
				return (collection.size() == 0) ? Boolean.TRUE : Boolean.FALSE;
			}
		}
		return false;
	}

	/**
	 * Check the value is numeric or not.
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str) {
		boolean flag = true;
		char chrArray[] = str.toCharArray();
		for (char element : chrArray) {
			if ((element >= 'A' && element <= 'Z')
					|| (element >= 'a' && element <= 'z')) {
				flag = false;
				break;
			}
		}
		return flag;
	}

	/**
	 * Checks if is values ordered.
	 * 
	 * @param values the values
	 * 
	 * @return the boolean
	 */
	protected static Boolean isValuesOrdered(List <CodeSetElement> values) {
		Boolean isNull = Boolean.FALSE;
		Boolean isLastValue = Boolean.FALSE;
		for (CodeSetElement element : values) {
			isNull = element.getCode() == null ? Boolean.TRUE : Boolean.FALSE;
			if (!isNull && isLastValue) {
				return Boolean.FALSE;
			}
			else if (isNull) {
				isLastValue = isNull;
			}
		}
		return Boolean.TRUE;
	}

	/**
	 * Validates the length.
	 * 
	 * @param str the string
	 * @param expectedMinLength the expected MIN length
	 * @param expectedMaxLength the expected MAX length
	 * 
	 * @return true, if validate length
	 */
	public static boolean validateLength(String str, int expectedMinLength,
			int expectedMaxLength) {
		return (str.trim().length() == expectedMinLength && str.trim().length() == expectedMaxLength);
	}

	/**
	 * Validate zip code.
	 * 
	 * @param zipCode the zip code
	 * 
	 * @return true, if validate zip code
	 */
	public static boolean validateZipCode(String zipCode) {
		String zipRegex = "[1-9][0-9][0-9][0-9][0-9]";
		return checkValueAsPerRegex(zipCode, zipRegex);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.9  2010/05/03 23:53:05  mwpxp2
 *  Imports cleaned up
 *
 *  Revision 1.8  2010/05/03 23:34:46  mwpxp2
 *  Copied methods from EaseUtil
 *
 *  Revision 1.7  2010/05/03 23:32:10  mwpxp2
 *  Added methods from ValidatorUtil that can be defined here
 *
 *  Revision 1.6  2010/03/22 23:35:28  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.5  2009/12/31 17:59:19  mwrka1
 *  Updated
 *
 *  Revision 1.4  2009/12/29 18:10:07  mwrka1
 *  cleanup
 *
 *  Revision 1.3  2009/12/28 22:13:54  mwrka1
 *  isValuesOrdered() added
 *
 *  Revision 1.2  2009/12/24 19:59:17  mwrka1
 *  isNullorEmpty added
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/23 17:19:27  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.4  2009/10/11 22:51:34  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.3  2009/10/06 23:00:17  mwpxp2
 *  Made isNumeric static
 *
 *  Revision 1.2  2009/10/06 02:16:59  mwpxp2
 *  Made all static methods public
 *
 *  Revision 1.1  2009/10/03 20:28:49  mwpxp2
 *  Moved into fw.validate.impl
 *
 *  Revision 1.6  2009/09/25 00:28:36  mwhxa2
 *  Added isNullOrBlank(Object)
 *
 *  Revision 1.5  2009/09/24 22:48:32  mwhxa2
 *  Added isNull()
 *
 *  Revision 1.4  2009/09/13 01:36:14  mwrrv3
 *  Added null condition.
 *
 *  Revision 1.3  2009/09/03 23:59:15  mwrpk
 *  Adding isNumeric method to AbstractValidator
 *
 *  Revision 1.2  2009/09/01 02:06:57  mwrrv3
 *  Changed the logic for isNullOrBlank and isNullOrEmpty methods.
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/18 03:13:54  mwpxp2
 *  Added common validation methods - harvested from subclasses
 *
 *  Revision 1.3  2009/08/03 22:57:59  mwpxp2
 *  Unit tested
 *
 *  Revision 1.2  2009/07/30 21:40:05  mwpxp2
 *  Initial
 *
 *  Revision 1.1  2009/07/30 21:31:55  mwpxp2
 *  Initial
 *
 */
