/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.incrementer;

/**
 * This is the interface for the SequenceMaxValueIncrementers
 * File: ISpringJdbcSequenceMaxValueIncrementer.java
 * Module:  gov.ca.dmv.ease.tus.persist.util
 * Created: November 17, 2010 
 * @author MWKFH 
 * @version $Revision: 1.1 $
 */
public interface ISpringJdbcSequenceMaxValueIncrementer {
	/**
	 * Gets the dB next long value.
	 * 
	 * @return the dB next long value
	 */
	public long getDbNextLongValue();

	/**
	 * Gets the query used to retrieve the DB next long value.
	 * 
	 * @return the query
	 */
	public String getSequenceQuery();

	/**
	 * Gets the name of the sequence incrementer.
	 * 
	 * @return the incrementer name
	 */
	public String getIncrementerName();
}
/**
 *  Modification History:
 *
 *  $Log: ISpringJdbcSequenceMaxValueIncrementer.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/09 18:06:10  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/11/18 20:02:28  mwkfh
 *  moved incrementer to new package
 *
 *  Revision 1.1  2010/11/18 18:35:56  mwkfh
 *  new interface for SpringJdbc Max Val Incrementer
 *
 */
