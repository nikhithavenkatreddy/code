/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.config;

import gov.ca.dmv.ease.fw.constants.IEaseEnvironmentConstants;

import java.io.Serializable;

/**
 * Description: I am interface for an object providing configuration information for EASE
 * File: IConfiguration.java
 * Module:  gov.ca.dmv.ease.config
 * Created: Aug 15, 2012
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IConfiguration extends IEaseEnvironmentConstants, Serializable {
	/**
	 * Returns the operate mode.
	 *
	 * @return P for prod; otherwise, T
	 */
	String getOperateMode();

	/**
	 * Read properties if not already loaded.
	 */
	void initialize();

	/**
	 * Checks if is in development mode.
	 *
	 * @return true, if is in development mode
	 */
	boolean isInDevelopmentMode();

	/**
	 * Checks if is in integration testing mode.
	 *
	 * @return true, if is in integration testing mode
	 */
	boolean isInIntegrationTestMode();

	/**
	 * Checks if is production.
	 *
	 * @return true, if is production
	 */
	boolean isInProductionMode();

	/**
	 * Checks if is in system testing mode.
	 *
	 * @return true, if is in system testing mode
	 */
	boolean isInSystemTestMode();

	/**
	 * Checks if is in testing mode.
	 *
	 * @return true, if is in testing mode
	 */
	boolean isInTestingMode();

	/**
	 * Checks if is training.
	 *
	 * @return true, if is training
	 */
	boolean isInTrainingMode();

	/**
	 * Checks if is in unknown mode.
	 *
	 * @return true, if is in unknown mode
	 */
	boolean isInUnknownMode();

	/**
	 * Checks if is in user acceptance testing mode.
	 *
	 * @return true, if is in user acceptance testing mode
	 */
	boolean isInUserAcceptanceTestMode();

	/**
	 * Read properties.
	 */
	void read();
	
	String getMode();
}
/**
 *  Modification History:
 *
 *  $Log: IConfiguration.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2012/09/25 20:32:42  mwrrv3
 *  Added getMode().
 *
 *  Revision 1.10  2012/08/16 19:50:07  mwkfh
 *  added initialize
 *
 *  Revision 1.9  2012/08/16 18:10:37  mwkfh
 *  added getOperateMode
 *
 *  Revision 1.8  2012/08/16 16:51:55  mwkfh
 *  added read
 *
 *  Revision 1.7  2012/08/16 15:48:05  mwkfh
 *  Completed implementation
 *
 *  Revision 1.6  2012/08/16 01:23:04  mwpxp2
 *  Added isInDevelopmentMode/0
 *
 *  Revision 1.5  2012/08/16 00:55:58  mwpxp2
 *  Added read/0, initialize/0
 *
 *  Revision 1.4  2012/08/15 17:44:56  mwpxp2
 *  Added isInUnknownMode
 *
 *  Revision 1.3  2012/08/15 17:41:27  mwpxp2
 *  Renamed test methods
 *
 *  Revision 1.2  2012/08/15 17:38:02  mwpxp2
 *  Made serializable
 *
 *  Revision 1.1  2012/08/15 17:36:06  mwpxp2
 *  Initial
 *
 */
