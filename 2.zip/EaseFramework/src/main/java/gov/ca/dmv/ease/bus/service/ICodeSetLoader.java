/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.service;

import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am interface for an object instantiating all codesets
 * File: ICodeSetLoader.java
 * Module:  gov.ca.dmv.ease.bus.service.impl
 * Created: Aug 4, 2009 
 * @author MWBXP5  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICodeSetLoader {
	/**
	 * Load all code sets.
	 * 
	 * @param userContext the user context
	 * @param registry the registry
	 * 
	 * @return the list< i code set>
	 */
	void loadAllCodeSets(IUserContext userContext,
			ICodeSetRegistrySingleton registry);
}
/**
 *  Modification History:
 *
 *  $Log: ICodeSetLoader.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/03 21:19:30  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 04:24:07  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/06 17:49:36  mwpxp2
 *  Changed signature to a single call using a registry instance
 *
 *  Revision 1.1  2009/08/05 00:05:44  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 */
