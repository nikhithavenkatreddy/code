/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.request;

import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.bo.app.impl.Session;

/**
 * Description: I define the interface to SessionServiceRequest
 * 
 * File: ISessionServiceRequest.java
 * Module:  gov.ca.dmv.ease.app.session.request
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionServiceRequest {
	/**
	 * Abstract method which all the session service request classes should override
	 * for executing the corresponding method in session service.
	 * 
	 * @return the session service response
	 */
	ISessionServiceResponse execute();

	/**
	 * This method returns the domain object.
	 * 
	 * @return the domainObject Domain object to save
	 */
	Session getSessionObject();
}
/**
 *  Modification History:
 *
 *  $Log: ISessionServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
