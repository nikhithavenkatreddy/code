/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am exception to be used when there is no asynchronous response within timeout.
 * File: EcsPromiseExpiredException.java
 * Module: gov.ca.dmv.ease.ecs.exceptions
 * Created: 09/05/2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsPromiseExpiredException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 76612534573246553L;

	/**
	 * Instantiates a new no message before timeout exception.
	 */
	public EcsPromiseExpiredException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message
	 * 
	 * @param arg0 the message
	 */
	public EcsPromiseExpiredException(String arg0) {
		super(arg0);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EcsPromiseExpiredException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public EcsPromiseExpiredException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsPromiseExpiredException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/25 22:09:42  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.2  2010/03/22 23:25:03  mwpxp2
 *  Inherits from EcsServiceException
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/13 20:09:35  mwhxb3
 *  updated comments.
 *
 *  Revision 1.2  2009/10/13 20:02:39  mwhxb3
 *  updated comments.
 *
 *  Revision 1.1  2009/07/14 23:58:49  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-13 02:08:25  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.3  2009-05-11 19:43:32  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.2  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.1  2009-05-10 04:38:01  mwpxp2
 *  Initial
 *
 *  Revision 1.1  2009-05-10 04:20:33  mwpxp2
 *  Initial
 *
*/
