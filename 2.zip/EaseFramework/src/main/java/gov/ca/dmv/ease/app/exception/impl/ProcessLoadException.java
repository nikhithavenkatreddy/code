/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessLayerException;


/**
 * Description: I am an exception class for process load-time errors
 * File: ProcessLoadException.java
 * Module:  gov.ca.dmv.ease.app.exception.impl
 * Created: Sep 2, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProcessLoadException extends EaseBusinessLayerException {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8767746169633206301L;

	/**
	 * Instantiates a new exception.
	 */
	public ProcessLoadException() {

	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 */
	public ProcessLoadException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 * @param cause
	 */
	public ProcessLoadException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new exception.
	 * @param cause
	 */
	public ProcessLoadException(Throwable cause) {
		super(cause);
	}
}


/**
 *  Modification History:
 *
 *  $Log: ProcessLoadException.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/03 16:43:25  mwsec2
 *  initial check in
 *
 */
