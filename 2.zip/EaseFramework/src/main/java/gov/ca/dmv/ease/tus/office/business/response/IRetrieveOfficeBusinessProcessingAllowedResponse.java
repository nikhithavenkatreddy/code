/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response;

import java.util.List;

/**
 * Description: I am an IRetrieveAuthorizedOfficeBusinessResponse interface
 * 
 * File: IRetrieveAuthorizedOfficeBusinessResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response
 * Created: Dec 8, 2010 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveOfficeBusinessProcessingAllowedResponse extends
		IOfficeBusinessServiceResponse {
	/**
	 * Get TTCs for this office.
	 * @return
	 */
	List<String> getProcessingAllowedList();
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
