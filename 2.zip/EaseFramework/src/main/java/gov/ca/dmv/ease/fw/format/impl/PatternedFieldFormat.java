/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.format.FieldValueType;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;

/**
 * Description: I am a field format with type information - see FieldValueType
 * File: PatternedFieldFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class PatternedFieldFormat extends FieldFormat {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4482356983544413934L;
	/** The type. */
	private FieldValueType type = FieldValueType.UNKNOWN;

	/**
	 * 
	 * 
	 * @param startPos 
	 * @param len 
	 */
	public PatternedFieldFormat(int startPos, int len) {
		super(startPos, len);
	}

	/**
	 * 
	 * 
	 * @param startPos 
	 * @param len 
	 * @param aTypeChar 
	 */
	public PatternedFieldFormat(int startPos, int len, char aTypeChar) {
		super(startPos, len);
		FieldValueType aType = FieldValueType.typeForChar(aTypeChar);
		setType(aType);
	}

	/**
	 * 
	 * 
	 * @param startPos 
	 * @param len 
	 * @param aType 
	 */
	public PatternedFieldFormat(int startPos, int len, FieldValueType aType) {
		super(startPos, len);
		setType(aType);
	}

	/**
	 * @param startPos
	 * @param len
	 * @param name
	 */
	public PatternedFieldFormat(int startPos, int len, String name) {
		super(startPos, len, name);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample(int)
	 */
	public String getRandomCorrectSample(int nextRandom) {
		return FieldValueType.getRandomCorrectSample(nextRandom, getType(),
				getLength());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample(int)
	 */
	public String getRandomIncorrectSample(int nextRandom) {
		return FieldValueType.getRandomIncorrectSample(nextRandom, getType(),
				getLength());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getType()
	 */
	@Override
	public FieldValueType getType() {
		return type;
	}

	/**
	 * 
	 * 
	 * @param aType 
	 */
	protected void setType(FieldValueType aType) {
		type = aType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append(getStartPos()).append(',');
		aBuilder.append(getLength());
		if (getFieldName() != null) {
			aBuilder.append(", \"").append(getFieldName()).append('\"');
		}
		aBuilder.append(']');
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#validate(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validate(String aField, IErrorCollector aCollector) {
		super.validate(aField, aCollector);
		validateType(aField, aCollector);
	}

	/**
	 * Validate char.
	 * 
	 * @param aChar 
	 * @param aCollector 
	 */
	public void validateChar(char aChar, IErrorCollector aCollector) {
		if (!Character.isDigit(aChar) && getType() == FieldValueType.NUMERIC) {
			aCollector.register(new FormatValidationException(
					"Expected a digit; has: \'" + aChar + "\'"));
			return;
		}
		if (!Character.isLetter(aChar) && getType() == FieldValueType.ALPHA) {
			aCollector.register(new FormatValidationException(
					"Expected alpha; has: \'" + aChar + "\'"));
			return;
		}
		if (!Character.isLetterOrDigit(aChar)
				&& getType() == FieldValueType.ALPHANUM) {
			aCollector.register(new FormatValidationException(
					"Expected alphanum; has: \'" + aChar + "\'"));
			return;
		}
		if (!Character.isWhitespace(aChar) && getType() == FieldValueType.SPACE) {
			aCollector.register(new FormatValidationException(
					"Expected space; has: \'" + aChar + "\'"));
			return;
		}
	}

	/**
	 * Validate type.
	 * 
	 * @param aField 
	 * @param aCollector 
	 */
	private void validateType(String aField, IErrorCollector aCollector) {
		if (getType() == FieldValueType.ANY
				|| getType() == FieldValueType.UNKNOWN) {
			return;
		}
		char aChar;
		for (int i = 0; i < aField.length(); i++) {
			aChar = aField.charAt(i);
			validateChar(aChar, aCollector);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: PatternedFieldFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/16 03:18:29  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.4  2010/11/29 07:43:52  mwpxp2
 *  Modified toString/0; made absract class
 *
 *  Revision 1.3  2010/11/25 01:33:11  mwpxp2
 *  Moved type-related methods in from super
 *
 *  Revision 1.2  2010/11/25 00:53:54  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.1  2010/11/24 20:39:43  mwpxp2
 *  Initial
 *
 */
