/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am exception to be thrown when message received by MDP does not match with any JMS message types under consideration. 
 * File: EcsMessageMismatchException.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: Nov 3, 2009 
 * @author MWHXB3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsMessageMismatchException extends EcsServiceException {
	/**
	 * The Constant serialVersionUID.
	 */
	private static final long serialVersionUID = 6466524872528054415L;

	/**
	 * Instantiates a new message mismatch exception.
	 */
	public EcsMessageMismatchException() {
		super();
	}

	/**
	 * Instantiates a new message mismatch exception.
	 * @param arg0 the message
	 */
	public EcsMessageMismatchException(String arg0) {
		super(arg0);
	}

	/**
	 * Instantiates a new message mismatch exception using a message and a cause.
	 * @param message the String message
	 * @param cause a Throwable cause
	 */
	public EcsMessageMismatchException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new message mismatch exception using a cause.
	 * @param cause the Throwable cause.
	 */
	public EcsMessageMismatchException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsMessageMismatchException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/25 22:09:42  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.2  2010/03/22 23:24:45  mwpxp2
 *  Inherits from EcsServiceException
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/11/03 19:42:52  mwhxb3
 *  I am exception to be thrown when message received by MDP does not match with any JMS message types under consideration.
 *
 */
