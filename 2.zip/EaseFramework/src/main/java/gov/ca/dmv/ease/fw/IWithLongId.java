package gov.ca.dmv.ease.fw;

/**
 * Description: Interface for objects requiring an identifier - Long
 * File: IWithId.java
 * Module:  gov.ca.dmv.ease.fw.id
 * Created: 10/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithLongId {
	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	Long getId();
}
/**
 *  Modification History:
 * 
 *  $Log: IWithLongId.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/07/14 23:44:24  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 15:45:42  ppalacz
 *  Moved in from FW
 *
 *  Revision 1.1  2009-07-11 07:33:12  ppalacz
 *  Initial
 *
 *  Revision 1.1  2009-07-11 06:58:15  ppalacz
 *  Initial
 *
*/
