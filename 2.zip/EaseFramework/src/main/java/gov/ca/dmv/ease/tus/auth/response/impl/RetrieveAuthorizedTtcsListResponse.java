/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsListResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am an AuthAndAuth response
 * 
 * File: RetrieveAuthorizedTtcsListResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveAuthorizedTtcsListResponse extends
		AuthAndAuthServiceResponse implements
		IRetrieveAuthorizedTtcsListResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4899785942828120561L;
	/** list of ttcs to return */
	List <String> ttcList = new ArrayList <String>();

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public RetrieveAuthorizedTtcsListResponse(List <String> ttcList) {
		super();
		setTtcs(ttcList);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveAuthorizedTtcsListResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new authorize approver object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RetrieveAuthorizedTtcsListResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Gets the ttc list.
	 * 
	 * @return the ttc list
	 */
	public List <String> getTtcs() {
		return ttcList;
	}

	/**
	 * Sets the ttc list.
	 * 
	 * @param ttc list
	 */
	private void setTtcs(List <String> ttcList) {
		this.ttcList = ttcList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveAuthorizedTtcsListResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
