/**
 * 
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.context.impl.SessionlessRootContext;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.bo.user.impl.UserContext;

/**
 * Description: Subprocess activity in the pseudo menu process that runs the targeted process
 * File: PseudoMenuSubprocessActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: May 31, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PseudoMenuSubprocessActivity extends MenuSubprocessActivity {
	private static final long serialVersionUID = 871917364953673079L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#getChildProcessContext(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected ProcessContext getChildProcessContext(
			ProcessContext processContext) {
		SessionlessRootContext rootContext = (SessionlessRootContext) processContext
				.getRootContext();
		ProcessContext processToRun = rootContext.getProcessToRun();
		String processName = rootContext.getTargetProcesName();
		BusinessProcess businessProcess = getProcessRegistry().getProcess(
				processName);
		ProcessContext processFromRegistry = businessProcess
				.getProcessContext();
		processToRun.setCurrentActivity(processFromRegistry
				.getCurrentActivity());
		processToRun.setProcessId(processFromRegistry.getProcessId());
		((ChildContext) processToRun).setParentProcessContext(processContext);
		((UserContext) processToRun.getUserContext()).setTtc(rootContext.getTtcToRunAs());
		return processToRun;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#preSubprocessExecute(gov.ca.dmv.ease.app.context.impl.ProcessContext, gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	protected void preSubprocessExecute(ProcessContext processContext,
			ProcessContext childProcessContext) {
		if (processContext.getSelectedAction() == null) { 
			processContext.setSelectedAction(getActionsRegistry().getAction(
					IActionNamesConstants.ENTER_ACTION));
		}
	}
}

/**
 *  Modification History:
 *
 *  $$Log: PseudoMenuSubprocessActivity.java,v $
 *  $Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.2  2012/06/08 17:19:38  mwsec2
 *  $initial check-in of classes to support the running of business processes outside an HTTP session context
 *  $$
 */