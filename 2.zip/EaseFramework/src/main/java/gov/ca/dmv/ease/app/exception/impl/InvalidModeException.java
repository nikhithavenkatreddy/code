/**
 * 
 */
package gov.ca.dmv.ease.app.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessLayerException;


/**
 * Description: Throw me if the user is trying to perform a transaction using an
 * operational mode (e.g Manual, Travel, etc.) that is invalid for that transaction.
 * File: InvalidModeException.java
 * Module:  gov.ca.dmv.ease.app.exception.impl
 * Created: Sep 28, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InvalidModeException extends EaseBusinessLayerException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1989366361048288683L;
	
	/**
	 * Instantiates a new exception.
	 */
	public InvalidModeException() {
		super();
	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 */
	public InvalidModeException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 * @param cause
	 */
	public InvalidModeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new exception.
	 * @param cause
	 */
	public InvalidModeException(Throwable cause) {
		super(cause);
	}
}


/**
 *  Modification History:
 *
 *  $Log: InvalidModeException.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/28 23:29:57  mwsec2
 *  initial checkin
 *
 */
