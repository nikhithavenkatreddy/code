/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessExecutionException;

import java.util.ConcurrentModificationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I represent a type of sub process which could be included in any other business process
 * File: InclusionSubprocessActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Jun 16, 2010 
 * @author MWAKG  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class InclusionSubprocessActivity extends SubprocessActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(InclusionSubprocessActivity.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = -5036878106140444960L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#executeNextActivity(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	private void executeNextActivity(ProcessContext processContext,
			ProcessContext childProcessContext) {
		Activity nextActivity = null;
		// make next activity the last sync point if action is 'fallback' into the current process
		if (isFallbackActionWithinCurrentProcess(processContext)) {
			nextActivity = processContext.getExecutionSyncPointActivity();
		}
		else {
			setTransitionKey(getTransitionKey(childProcessContext));
			nextActivity = getNextActivity();
		}
		if (nextActivity != null) {
			LOGGER.debug("Next Activity  :: " + nextActivity.getActivityName());
			try {
				nextActivity.execute(processContext);
				if (processContext.getMessageCollector().hasValidationErrors()) {
					processContext.setCurrentActivity(this); // fixes rollback issue when rolling back into subprocess 
				}
			}
			catch (Exception e) {
				processContext.setCurrentActivity(this); // fixes rollback issue when rolling back into subprocess 
				throw new ProcessExecutionException(e);
			}
		}
		else {
			signalInvalidNextActivityFor(processContext); //throws ProcessExecutionException
		}
	}

	/* (non-Javadoc)

	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#startChildProcessContext(gov.ca.dmv.ease.app.context.impl.ChildContext, gov.ca.dmv.ease.app.context.impl.ChildContext)
	 */
	@Override
	protected void executeSubprocess(ChildContext parentProcessContext,
			ChildContext childProcessContext) {
		if (!getActionsRegistry().getAction(IActionNamesConstants.FALLBACK)
				.equals(childProcessContext.getSelectedAction())) {
			moveErrorMessages(parentProcessContext, childProcessContext);
			childProcessContext.startIn(parentProcessContext);
			moveErrorMessages(childProcessContext, parentProcessContext);
		}
		else {
			childProcessContext.fallbackIn(parentProcessContext, null);
		}
	}

	/**
	 * This method returns the transition key that parent business process should execute
	 * @param processContext ProcessContext of the child
	 * @return The Transiiton Key
	 */
	protected abstract String getTransitionKey(ProcessContext processContext);

	/**
	 * Evaluates to true if the current user action is 'fallback' and the current 
	 * execution sync point context is the current process context. 
	 * @param processContext
	 * @return
	 */
	private boolean isFallbackActionWithinCurrentProcess(
			ProcessContext processContext) {
		if (processContext.doesExecutionSyncPointContextExist()) {
			return getActionsRegistry().getAction(
					IActionNamesConstants.FALLBACK).equals(
					processContext.getSelectedAction())
					&& processContext.getProcessId().equals(
							processContext.getExecutionSyncPointContext()
									.getProcessId());
		}
		else {
			return false;
		}
	}

	/**
	 * Method executed after the child business process execution is complete. 
	 * It copies properties from the subprocessContext to parent processContext,
	 * assuming the properties names are identical. Override this method if necessary.    
	 * @param processContext The current business process
	 * @param subprocessContext Process Context which has finished executing
	 */
	protected void postSubprocessExecute(ProcessContext processContext,
			ProcessContext subprocessContext) {
		LOGGER
				.debug("Copying properties from subprocess context to parent process context");
		processContext.copyPropertiesFrom(subprocessContext);
	}

	/**
	 * Resumes the parent business process once the child business process completes execution
	 * @param processContext The parent business process context
	 * @param childProcessContext The child business process context which completed execution
	 */
	public void resume(ProcessContext processContext,
			ProcessContext childProcessContext) {
		LOGGER.info("Resuming parent process " + processContext.getProcessId() 
				+ " from subprocess " + childProcessContext.getProcessId());
		processContext.setSelectedAction(childProcessContext
				.getSelectedAction());
		postSubprocessExecute(processContext, childProcessContext);
		executeNextActivity(processContext, childProcessContext);
		moveErrorMessages(processContext, childProcessContext);
	}
}
/**
 * Modification History:
 * 
 * $Log: InclusionSubprocessActivity.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/04/30 16:45:51  mwsec2
 * removed unneeded catch block and adjusted logging levels
 *
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.31  2011/10/21 20:48:49  mwpxp2
 * Modified to use signalInvalidNextActivityFor for handling of invalid next activity
 *
 * Revision 1.30  2011/07/22 21:53:15  mwxxw
 * Use new method name: doesExecutionSyncPointContextExist().
 *
 * Revision 1.29  2011/07/22 21:20:06  mwxxw
 * Fix null pointer issue in isFallbackActionWithinCurrentProcess() function.
 *
 * Revision 1.28  2011/07/20 17:15:12  mwsec2
 * fix to isFallbackActionWithinCurrentProcess to evaluate context equality based on process ID rather than object equality
 *
 * Revision 1.27  2011/06/14 13:34:58  mwkkc
 * Clean up
 *
 * Revision 1.26  2011/06/10 21:57:45  mwkkc
 * Clean up
 *
 * Revision 1.25  2011/06/08 04:20:57  mwpxp2
 * Added explicit catch for ConcurrentModificationException
 *
 * Revision 1.24  2011/01/07 19:29:54  mwsec2
 * rollback fix
 *
 * Revision 1.23  2010/12/16 18:15:10  mwsec2
 * cleaned up imports
 *
 * Revision 1.22  2010/12/16 18:03:40  mwsec2
 * exception type changed to be more specific
 *
 * Revision 1.21  2010/12/15 00:35:19  mwsec2
 * added try/catch to handle rollbacks into a subprocess
 *
 * Revision 1.20  2010/11/09 03:19:29  mwpxp2
 * Imports cleanup
 *
 * Revision 1.19  2010/10/20 21:42:40  mwyxg1
 * add move error message to ContinuationSubprocessActivity
 *
 * Revision 1.18  2010/10/20 21:05:51  mwsec2
 * ContextCopyUtil removed. Context objects now have their own copyPropertiesFrom(context) method
 *
 * Revision 1.17  2010/09/01 21:24:28  mwyxg1
 * add clear error message in moveErrorMessages
 *
 * Revision 1.16  2010/09/01 21:07:29  mwyxg1
 * replace copyErrorMessage with moveErrorMessage
 *
 * Revision 1.15  2010/09/01 18:55:54  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.14  2010/08/26 23:41:30  mwsec2
 * Error propagation / rollback fixes
 *
 * Revision 1.13  2010/08/20 19:13:15  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.12  2010/08/06 21:05:34  mwsec2
 * Modifications to support sub-to-sub process fallbacks
 *
 * Revision 1.11  2010/08/04 17:30:17  mwsec2
 * removed line that clears execution points from parent process. This line belongs  rather in the ContinuationSubprocessActivity
 *
 * Revision 1.10  2010/08/03 21:20:06  mwsec2
 * syncPoint enhancements
 *
 * Revision 1.9  2010/07/31 23:03:09  mwcsj3
 * Added NULL check in executeNextActivity method
 *
 * Revision 1.8  2010/07/30 22:44:55  mwakg
 * Activities now register syncpoint activity and the processContext
 *
 * Revision 1.7  2010/07/30 00:01:53  mwsec2
 * changed log statement text
 *
 * Revision 1.6  2010/07/29 22:10:04  mwsec2
 * providing default implementation of pre/postSubprocessExecute methods that copies properties from one context to another
 *
 * Revision 1.5  2010/07/23 14:49:47  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.3.2.2  2010/07/06 21:42:24  mwsec2
 * added support for fallback to and from subprocesses
 *
 * Revision 1.3.2.1  2010/06/27 01:41:36  mwakg
 * Assigning the sync point to child process
 *
 * Revision 1.4  2010/07/08 02:00:55  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/06/23 01:41:12  mwakg
 * *) Changed getSubProcess to getSubprocess.
 * *) Moved postSubprocessExecute to only InclusionSubprocessActivity
 * *) Renamed businessProcessName variable to childProcessName in SubProcessActivity class
 *
 * Revision 1.2  2010/06/21 23:00:41  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.1.2.4  2010/06/20 18:44:06  mwakg
 * Fixed API and updated java docs
 *
 * Revision 1.1.2.3  2010/06/20 18:06:53  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.1.2.2  2010/06/16 19:56:50  mwakg
 * Updated documentation
 *
 * Revision 1.1.2.1  2010/06/16 19:51:24  mwakg
 * Added ContinuationSubprocess and InclusionSubprocessActivity to divided SubprocesActivity responsibility
 *
 * 
 */
