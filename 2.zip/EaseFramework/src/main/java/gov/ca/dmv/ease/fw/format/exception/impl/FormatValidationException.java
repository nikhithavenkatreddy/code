/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: I am exception to be used with format validations
 * File: FormatValidationException.java
 * Module:  gov.ca.dmv.ease.fw.format.exception.impl
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FormatValidationException extends EaseValidationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 224890707000215546L;

	/**
	 * Instantiates a new format validation exception.
	 */
	public FormatValidationException() {
		super();
	}

	/**
	 * 
	 * 
	 * @param message 
	 */
	public FormatValidationException(String message) {
		super(message);
	}

	/**
	 * 
	 * 
	 * @param message 
	 * @param cause 
	 */
	public FormatValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * 
	 * @param cause 
	 */
	public FormatValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: FormatValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/11/29 07:42:32  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.1  2010/11/20 20:44:11  mwpxp2
 *  Initial
 *
 */
