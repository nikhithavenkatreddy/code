package gov.ca.dmv.ease.fw.service;

/**
 * Description: I am interface for a promise for a response
 * - I am applicable mainly to asynchronous requests
 * - I know what is my timeout
 * - I am sufficient to obtain the actual response from the service if one is available
 * File: IResponsePromise.java
 * Module:  gov.ca.dmv.ease.fw.service
 * Created: Mar 19, 2009
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IResponsePromise extends IResponse {
	/**
	 * Gets the Absolute Time Stamp.
	 * 
	 * @return the absolute time stamp
	 */
	public long getAbsoluteExpirationTimestamp();

	/**
	 * Gets the correlation id.
	 * 
	 * @return the correlation id
	 */
	String getCorrelationId();

	/**
	 * Gets the Expiration Time.
	 * 
	 * @return the expiration time
	 */
	long getExpirationTime();

	/**
	 * Gets the Original Request Id.
	 * 
	 * @return the originalRequestId
	 */
	public String getOriginalRequestId();

	/**
	 * Gets the response class name.
	 * 
	 * @return the response class name
	 */
	String getResponseClassName();

	/**
	 * Gets the sent request id.
	 * 
	 * @return the sent request id
	 */
	String getSentRequestId();

	/**
	 * Checks for expiration stamp.
	 * 
	 * @return true, if successful
	 */
	boolean hasExpirationStamp();
}
/**
 *  Modification History:
 *
 *  $Log: IResponsePromise.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/06/21 23:00:45  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.16.2  2010/06/20 18:06:56  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/01 20:14:14  mwpxp2
 *  Added missing getCorrelationId/0 (already present in implementation)
 *
 *  Revision 1.2  2010/03/22 23:34:14  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/23 17:14:30  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.2  2009/10/11 22:51:35  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.1  2009/10/03 20:24:35  mwpxp2
 *  Moved into fw.service; bulk cleanup
 *
 *  Revision 1.3  2009/09/30 21:11:06  mwhxa2
 *  Removed IValidatable
 *
 *  Revision 1.2  2009/09/30 21:07:00  mwhxa2
 *  Implemented validate() and getValidator()
 *
 *  Revision 1.1  2009/08/27 02:24:35  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/03 18:43:23  mwhxa2
 *  Update to include the following attributes expirationTime, originalRequestId, absoluteExpirationTimestamp.
 *
 *  Revision 1.1  2009/07/27 18:41:27  mwpxp2
 *  Copied from ECS
 *
 */
