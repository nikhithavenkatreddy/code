/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert;

import java.util.Arrays;
import java.util.List;

/**
 * Description: Interface containing constants for ecs converters
 * File:ICodeSetNameConstants.java
 * Module: gov.ca.dmv.ease.bo.code
 * Created: Apr 19,2010
 * @author MWTJC1
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2018/04/16 16:21:04 $
 * Last Changed By: $Author: mwskh1 $
 */
public interface IEcsConverterConstants {
	// Non categorized constants
	/** The constant STAR */
	String STAR = "*";
	/** The constant Y */
	String YES = "Y";
	/** The constant N */
	String NO = "N";
	/////////// SearchPersonByNumberConverter Constants //////////////
	/** The ELI_NON_COML_DRIVE_TEST_FEE_IND. */
	String ELI_NON_COML_DRIVE_TEST_FEE_IND = "NON_COML_DRIVE_TEST_FEE_IND";
	/** The ELI_MOTORCYCLE_DRIVE_TEST_FEE_IND. */
	String ELI_MOTORCYCLE_DRIVE_TEST_FEE_IND = "MOTORCYCLE_DRIVE_TEST_FEE_IND";
	/** The ELI_COML_DL_APP_FEE_IND. */
	String ELI_COML_DL_APP_FEE_IND = "COML_DL_APP_FEE_IND";
	/** The ELI_FIREFIGHTER_APP_FEE_IND. */
	String ELI_FIREFIGHTER_APP_FEE_IND = "FIREFIGHTER_APP_FEE_IND";
	/** The ELI_COML_DL_DRIVE_TEST_FEE_IND. */
	String ELI_COML_DL_DRIVE_TEST_FEE_IND = "COML_DL_DRIVE_TEST _FEE_IND";
	/////////// DatabaseStatusInquiryConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_LTR = "LTR";
	/////////// DriverRecordUpdateConverter Constants //////////////
	/** Transaction code */
	String TCODE_DAD = "DAD";
	String TCODE_DAK = "DAK";
	String TCODE_DL6 = "DL6";
	String TCODE_DLX = "DLX";
	String TCODE_DLU = "DLU";
	/** More constant TCODE */
	String TCODE_ELB = "ELB";
	String TCODE_EL1 = "EL1";
	String TCODE_EL2 = "EL2";
	String TCODE_EL3 = "EL3";
	String TCODE_EL4 = "EL4";
	String TCODE_DUH = "DUH";
	String TCODE_DUK = "DUK";
	String TCODE_DUP = "DUP";
	String TCODE_DCA = "DCA";
	String TCODE_DCF = "DCF";
	String TCODE_DL7 = "DL7";
	String TCODE_DLS = "DLS";
	String TCODE_C78 = "C78";
	String TTC_DLP = "DLP";
	/** The constant TRANSACTION SUB CODE */
	String TRANSACTION_SUB_CODE_U = "U";
	/** The constant REQUESTER CODE PREFIX */
	String REQUESTER_CODE_PREFIX = "80";
	/** The constant TTC_DPR1_07M */
	String TTC_DPR1_07M = "07M";
	/** The constant TTC_DPR1_14M */
	String TTC_DPR1_14M = "14M";
	/** The constant TTC_37U4_37U */
	String TTC_37U4_37U = "37U";
	/** The constant TTC_DPR4_30U */
	String TTC_DPR4_30U = "30U";
	/** The constant TTC 38U. */
	String TTC_38U = "38U";
	/** The constant TypeInputCode_C */
	String TYPE_INPUT_CODE_C = "C";
	/** The constant TypeInputCode_V */
	String TYPE_INPUT_CODE_V = "V";
	/** The constant FIELD_MNEMONIC_CODE_PO */
	String FIELD_MNEMONIC_CODE_PO = "PO";
	/** The constant FIELD_MNEMONIC_CODE_CT */
	String FIELD_MNEMONIC_CODE_CT = "CT";
	/** The constant FIELD_MNEMONIC_CODE_FP */
	String FIELD_MNEMONIC_CODE_FP = "FP";
	/** The constant FIELD_MNEMONIC_CODE_MG */
	String FIELD_MNEMONIC_CODE_MG = "MG";
	/** The constant FIELD_MNEMONIC_CODE_PP */
	String FIELD_MNEMONIC_CODE_PP = "PP";
	/** The constant FIELD_MNEMONIC_CODE_PN */
	String FIELD_MNEMONIC_CODE_PN = "PN";
	/** The constant FIELD_MNEMONIC_CODE_PN */
	String FIELD_MNEMONIC_CODE_0 = "    ";
	/** The constant FIELD_MNEMONIC_CODE_PN */
	String FIELD_MNEMONIC_CODE_2 = "CE04";
	/** The constant FIELD_MNEMONIC_CODE_4 */
	String FIELD_MNEMONIC_CODE_4 = "INZ ";
	/** The constant FIELD_MNEMONIC_CODE_5 */
	String FIELD_MNEMONIC_CODE_5 = "MX2 ";
	/** The constant FIELD_MNEMONIC_CODE_6 */
	String FIELD_MNEMONIC_CODE_6 = "CNN ";
	/** The constant FIELD_MNEMONIC_CODE_7 */
	String FIELD_MNEMONIC_CODE_7 = "RME ";
	/** The constant FIELD_MNEMONIC_CODE_8 */
	String FIELD_MNEMONIC_CODE_8 = "SL25";
	/** The constant FIELD_MNEMONIC_CODE_9 */
	String FIELD_MNEMONIC_CODE_9 = "DN  ";
	/** The constant INPUT_CODE_1 */
	String INPUT_CODE_1 = "1";
	/** The constant INPUT_CODE_3 */
	String INPUT_CODE_3 = "3";
	/** The constant INPUT_CODE_0 */
	String INPUT_CODE_0 = "0";
	/** The constant INPUT_CODE_2 */
	String INPUT_CODE_2 = "2";
	/** The constant INPUT_CODE_4 */
	String INPUT_CODE_4 = "4";
	/** The constant INPUT_CODE_5 */
	String INPUT_CODE_5 = "5";
	/** The constant INPUT_CODE_6 */
	String INPUT_CODE_6 = "6";
	/** The constant INPUT_CODE_7 */
	String INPUT_CODE_7 = "7";
	/** The constant INPUT_CODE_8 */
	String INPUT_CODE_8 = "8";
	/** The constant INPUT_CODE_9 */
	String INPUT_CODE_9 = "9";
	/** The constant UPDATE_DATA_30 */
	String UPDATE_DATA_30 = "30";
	/** The constant UPDATE_DATA_00 */
	String UPDATE_DATA_00 = "00";
	/////////// DeleteMasterReceiptFileConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_CIC = "CIC";
	/** The Constant RESPONSE_CODE. */
	String RESPONSE_CODE = "00";
	/** The Constant REMOVAL_INDICATOR. */
	String REMOVAL_INDICATOR = " ";
	/////////// LegalPresenceVerificationConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_LPV = "LPV";
	/** The constant version number. */
	String VERSION_NUMBER = "1.0";
	/** The Constant DOCUMENT_TYPE_A. */
	String DOCUMENT_TYPE_A = "A";
	/** The Constant DOCUMENT_TYPE_I. */
	String DOCUMENT_TYPE_I = "I";
	/** The Constant BDLP_VERIF_CODE_K. */
	String BDLP_CODE_FOR_VALID_CANADIAN_PASSPORT_WITH_I94 = "O";
	/** The Constant BDLP_VERIF_CODE_4. */
	String BDLP_CODE_FOR_PERMANENT_RESIDENT_CARD = "4";
	/** The Constant BDLP_VERIF_CODE_6. */
	String BDLP_CODE_FOR_EMPLOYMENT_AUTH_DOC_PRIOR_1989 = "6";
	/** The Constant BDLP_VERIF_CODE_7. */
	String BDLP_CODE_FOR_EMPLOYMENT_AUTH_DOC_PRIOR_1997 = "7";
	/** The Constant BDLP_VERIF_CODE_V. */
	String BDLP_CODE_FOR_EMPLOYMENT_AUTH_DOC = "V";
	/** The Constant BDLP_VERIF_CODE_G. */
	String BDLP_CODE_FOR_CERTIFICATE_OF_NATURALIZATION = "G";
	/** The Constant BDLP_VERIF_CODE_H. */
	String BDLP_CODE_FOR_COUNTRY_OF_CITIZENSHIP = "H";
	/** The Constant BDLP_VERIF_CODE_K. */
	String BDLP_CODE_FOR_CITIZEN_IDENTIFICATION_CARD = "K";
	/** The Constant BDLP_VERIF_CODE_L. */
	String BDLP_CODE_FOR_RESIDENT_ALIEN_CARD = "L";
	/** The Constant BDLP_VERIF_CODE_X. */
	String BDLP_CODE_FOR_MEXICAN_BORDER_CROSSING_CARD = "X";
	/** The Constant BDLP_VERIFICATION_CODE_Q. */
	String BDLP_CODE_FOR_NON_RESIDENT_ALIEN_CANADIAN_BORDER_CROSSING_CARD = "Q";
	/** The Constant BDLP_VERIFICATION_CODE_S. */
	String BDLP_CODE_FOR_RECORD_OF_ARRIVAL_DEPARTURE_I94W = "S";
	/** The Constant BDLP_VERIFICATION_CODE_W. */
	String BDLP_CODE_FOR_TMP_EVIDENCE_OF_LAWFUL_ADMIT_FOR_PERM_RES = "W";
	/** The Constant BDLP_VERIFICATION_CODE_2. */
	String BDLP_CODE_FOR_RECORD_OF_ARRIVAL_DEPARTURE_I94 = "2";
	/** The Constant BDLP_VERIFICATION_CODE_3. */
	String BDLP_CODE_FOR_REENTRY_PERMIT = "3";
	/** The Constant BDLP_VERIF_CODE_5. */
	String BDLP_CODE_FOR_REFUGEE_TRAVEL_DOCUMENT = "5";
	/** The Constant BDLP_VERIFICATION_CODE_M. */
	String BDLP_CODE_FOR_TMP_RESIDENT_ID_CARD = "M";
	/** The constant BENEFIT CODE 5 */
	String BENEFIT_CODE_5 = "5";
	/** The constant BENEFIT CODE 60 */
	String BENEFIT_CODE_60 = "60";
	/** The Constant DOC_DESC_FOR_BDLP_VERIF_CODE_K. */
	String DOC_DESC_FOR_BDLP_VERIF_CODE_K = "US CITIZEN IDENTIFICATION CARD";
	/** The Constant DOC_DESC_FOR_BDLP_VERIF_CODE_L. */
	String DOC_DESC_FOR_BDLP_VERIF_CODE_L = "RESIDENT ALIEN CARD";
	/** The Constant DOC_DESC_FOR_BDLP_VERIF_CODE_Q. */
	String DOC_DESC_FOR_BDLP_VERIF_CODE_Q = "NOR-RES ALIEN BORDER CROSSING";
	/** The Constant DOC_DESC_FOR_BDLP_VERIF_CODE_X. */
	String DOC_DESC_FOR_BDLP_VERIF_CODE_X = "MEXICAN BORDER CROSSING";
	/** The Constant DOCUMENT_ID_20. */
	String DOCUMENT_ID_20 = "20";
	/** The Constant DOCUMENT_ID_23. */
	String DOCUMENT_ID_23 = "23";
	/** The Constant DOCUMENT_ID_9. */
	String DOCUMENT_ID_9 = "9";
	/** The Constant DOCUMENT_ID_3. */
	String DOCUMENT_ID_3 = "3";
	/** The Constant DOCUMENT_ID_4. */
	String DOCUMENT_ID_4 = "4";
	/** The Constant DOCUMENT_ID_5. */
	String DOCUMENT_ID_5 = "5";
	/** The Constant DOCUMENT_ID_1. */
	String DOCUMENT_ID_1 = "1";
	/** The Constant DOCUMENT_ID_2. */
	String DOCUMENT_ID_2 = "2";
	/** The Constant DOCUMENT_ID_7. */
	String DOCUMENT_ID_7 = "7";
	/** The Constant DOCUMENT_ID_8. */
	String DOCUMENT_ID_8 = "8";
	/** The Constant DOCUMENT_ID_10. */
	String DOCUMENT_ID_10 = "10";
	/** The Constant DOCUMENT_ID_6. */
	String DOCUMENT_ID_6 = "6";
	/** The Constant LPV RESPONSE LENGTH. */
	int LPV_RESPONSE_LENGTH = 460; //457;
	/** LPV RESPONSE LAYOUT POSITIONS */
	int EXEC_STATUS_CODE_START = 392;
	int EXEC_STATUS_CODE_END = 396;
	int ELEGIBILITY_STATEMENT_CODE_START = 168;
	int ELEGIBILITY_STATEMENT_CODE_END = 173;
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_1 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_1 = "1";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_4 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_4 = "4";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_10 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_10 = "10";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_18 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_18 = "18";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_20 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_20 = "20";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_22 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_22 = "22";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_24 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_24 = "24";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_26 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_26 = "26";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_13 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_13 = "13";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_128 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_128 = "128";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_168 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_168 = "168";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_188 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_188 = "188";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_189 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_189 = "189";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_228 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_228 = "228";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_249 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_249 = "249";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_CONDITION_251 */
	String ELIGIBILITY_STATEMENT_CODE_CONDITION_251 = "251";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_O */
	String ELIGIBILITY_STATEMENT_CODE_O = "O";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_E */
	String ELIGIBILITY_STATEMENT_CODE_E = "E";
	/** The Constant ELIGIBILITY_STATEMENT_CODE_I */
	String ELIGIBILITY_STATEMENT_CODE_I = "I";
	/** The EXECUTION_STATUS_CODE_0 */
	int EXECUTION_STATUS_CODE_0 = 0;
	/** The EXECUTION_STATUS_CODE_1 */
	int EXECUTION_STATUS_CODE_1 = 1;
	/** The EXECUTION_STATUS_MESSAGE_0 */
	String EXECUTION_STATUS_MESSAGE_0 = "The Data Found: Process It Per This Document";
	/** The EXECUTION_STATUS_MESSAGE_1 */
	String EXECUTION_STATUS_MESSAGE_1 = "The Record Not Found: Record For Further Action";
	/** The EXECUTION_STATUS_MESSAGE_LOG_ERROR */
	String EXECUTION_STATUS_MESSAGE_LOG_ERROR = "ATTN: DMV MANAGER/INVALID RESPONSE LENGTH";
	/////////// ProblemDriverUpdateConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_DPS = "DPS";
	/** The OTHER_OSCODE. */
	String OTHER_OSCODE = "OT";
	/** The constant ISSUANCE_OFFICE_212 */
	String ISSUANCE_OFFICE_212 = "212";
	/** The constant ISSUANCE_OFFICE_231 */
	String ISSUANCE_OFFICE_231 = "231";
	/** The Constant QUESTIONABLE_INDICATOR_S */
	String QUESTIONABLE_INDICATOR_S = "S";
	/** The Constant ELIGIBILITY_INDICATOR_E */
	String ELIGIBILITY_INDICATOR_E = "E";
	/** The Constant ELIGIBILITY_INDICATOR_N */
	String ELIGIBILITY_INDICATOR_N = "N";
	/** The Constant DESIGNATE_ACTION_Q */
	String DESIGNATE_ACTION_Q = "Q";
	/** The Constant DESIGNATE_ACTION_S */
	String DESIGNATE_ACTION_S = "S";
	/** The Constant TYPE_INDICATOR_Nv */
	String TYPE_INDICATOR_N = "N";
	/** The Constant TYPE_INDICATOR_P */
	String TYPE_INDICATOR_P = "P";
	/** The Constant TYPE_INDICATOR_S */
	String TYPE_INDICATOR_S = "S";
	/** The constant STATE_OF_ORIGIN */
	String STATE_OF_ORIGIN = "ZZ";
	/////////// ReturnDriverInformationAndFeeIndicatorConverter Constants //////////////
	/** Transaction code */
	String TCODE_DS5 = "DS5";
	/** The constant TRANSACTION SUB CODE */
	String TRANSACTION_SUB_CODE_I = "I";
	/** The constant TTC_04M */
	String TTC_04M = "04M";
	/** The constant TTC_05M */
	String TTC_05M = "05M";
	/** The constant TTC_13M */
	String TTC_13M = "13M";
	/** The constant DRUG_CODE_8 */
	String DRUG_CODE_8 = "8";
	/** The constant PAS_CODE_A */
	String PAS_CODE_A = "A";
	/** The constant PAS_CODE_3 */
	String PAS_CODE_3 = "3";
	/** The constant HEX_NULL */
	String HEX_NULL_N = "\u0000";
	/** The constant space */
	String SPACE = " ";
	/** The constant space */
	String SPACES = "  ";
	/** Family Law Due Fee Rate Code. */
	String FAMILY_LAW_DUE_FEE_RATE_CODE = "762";
	/** Drug Screening Reissue Fee Rate Code. */
	String DRUG_SCREENING_REISSUE_FEE_RATE_CODE = "749";
	/** Preliminary Alcohol Screening Reissue Fee Rate Code. */
	String PRELIMINARY_ALCOHOL_SCREENING_REISSUE_FEE_RATE_CODE = "748";
	/** Add Restriction Ignition Device Fee Rate Code. */
	String ADD_RESTRICTION_IGNITION_INTERLOCK_DEVICE_FEE_RATE_CODE = "730";
	/** Driver License Reissue Type 01 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_01_FEE_RATE_CODE = "731";
	/** Driver License Reissue Type 02 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_02_FEE_RATE_CODE = "746";
	/** Driver License Reissue Type 03 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_03_FEE_RATE_CODE = "747";
	/** Driver License Reissue Type 04 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_04_FEE_RATE_CODE = "743";
	/** Driver License Reissue Type 05 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_05_FEE_RATE_CODE = "744";
	/** The response error code 00. */
	String RES_ERR_CODE_00 = "00";
	/** The response error code R0. */
	String RES_ERR_CODE_R0 = "R0";
	/** The response error code RO. */
	String RES_ERR_CODE_RO = "RO";
	/** The hex null filler */
	String HEX_FILL = "nn";
	/** The constant STATE_CODE_04 */
	String STATE_CODE_04 = "04";
	/** The constant STATE_CODE_REG_EXP*/
	String STATE_CODE_REG_EXP = "[0-9][0-9]";
	/////////// SearchPersonByNameConverter Constants //////////////
	/** The Constant BIRTH_DATE_FIELD_CODE. */
	String BIRTH_DATE_FIELD_CODE = "B";
	/** The Constant CITY_FIELD_CODE. */
	String CITY_FIELD_CODE = "C";
	/** The Constant HIT_COUNTER. */
	String HIT_COUNTER = "00";
	/** The Constant LENGTH_OF_ONE_RECORD_IN_ACTUAL_RESPONSE. */
	int LENGTH_OF_ONE_RECORD_IN_ACTUAL_RESPONSE = 62;
	/** The Constant REQUEST_PART_OF_RESPONSE_LENGTH. */
	int REQUEST_PART_OF_RESPONSE_LENGTH = 75;
	/** The Constant Search Person By Number tcode. */
	String SEARCH_PERSON_BY_NUMBER_TCODE = "DLA";
	/** The Constant TCODE. */
	String TCODE_ATL = "ATL";
	/** The constant CODESET_NAME */
	String CODESET_NAME = "AniMultipleResponseErrorCode";
	/////////// SendCdlisAndPdpsConverter Constants //////////////
	/** CDLIS/PDPS record length */
	int MESSAGE_PAYLOAD_CDLIS_RECORD_LENGTH = 874;
	/** CDLIS/PDPS record length */
	int MESSAGE_PAYLOAD_CDLIS5_52_RECORD_LENGTH = 1354;
	/** CDU header length */
	int MESSAGE_PAYLOAD_HEADER_LENGTH = 318;
	/** Logger for this class */
	/** The Constant APPLICATION_ID_CDLIS. */
	String APPLICATION_ID_CDLIS = "02";
	/** The Constant APPLICATION_ID_PDPS. */
	String APPLICATION_ID_PDPS = "12";
	/** The Constant BILLING_ID. */
	String BILLING_ID = "CA";
	/**The Constant default SSN */
	String DEFAULT_SSN = "999999999";
	/** regular ssn length**/
	int COMPLETE_SSN_LENGTH = 9;
	/** Shortened ssn length**/
	int RD_SSN_LENGTH = 5;
	/** The Constant DESTINATION. */
	String DESTINATION = "XX";
	/** The Constant ERROR_INDICATOR. */
	String ERROR_INDICATOR = "N";
	/** The Constant INBOUND_APP_NAME. */
	String INBOUND_APP_NAME = "DMCS";
	/** The Constant LAST_SEGMENT_INDICATOR. */
	String LAST_SEGMENT_INDICATOR = "Y";
	/** The Constant MESSAGE_LENGTH. */
	String MESSAGE_LENGTH = "1254";
	/** The Constant MODE_OF_TRANSMISSION. */
	String MODE_OF_TRANSMISSION = "1";
	/** The Constant MSG_DESTINATION. */
	String MSG_DESTINATION_CDLIS = "XX";
	/** The Constant MSG_DESTINATION1. */
	String MSG_DESTINATION_PDPS = "ZZ";
	/** The Constant MSG_ORIGIN. */
	String MSG_ORIGIN = "CA";
	/** The Constant MSG_TYPE. */
	String MSG_TYPE = "IO";
	/** The Constant NETWORK_SESSION_MGR_IND. */
	String NETWORK_SESSION_MGR_IND = "Y";
	/** The NCB TEST/PRODUCTION INDICATOR */
	String NETWORK_TEST_PROD_IND = "Y";
	/** NCB MODE OF TRANSMISSION INDICATOR */
	String MODE_OF_TRANS_IND = "Y";
	/** The Constant NETWORK_STATUS_INDICATOR. */
	String NETWORK_STATUS_INDICATOR = "00";
	/** The network app indicator */
	String NETWORK_APP_INDICATOR = "0";
	/** The System release code F */
	String SYSTEM_RELEASE_CODE_F = "F";
	/** The System release code H */
	String SYSTEM_RELEASE_CODE_H = "H";
	/** The Constant NO_OF_RETRIES. */
	String NO_OF_RETRIES = "0";
	/** The Constant RECORD_TYPE. */
	String RECORD_TYPE = "";
	/** The Constant SEGMENT_NUMBER. */
	String SEGMENT_NUMBER = "01";
	/** The Constant STORE_FORWARD_TIME. */
	String STORE_FORWARD_TIME = "0000";
	/** The Constant TCODE. */
	String TCODE_CDU = "CDU";
	/** The Constant TEST_PRODUCTION_INDICATOR. */
	String TEST_PRODUCTION_INDICATOR = "P";
	/** The Constant TIME_OUT_INTERVAL. */
	String TIME_OUT_INTERVAL = "000040";
	/** The Constant MESSAGE_TYPE. */
	String MESSAGE_TYPE_KEY = "MESSAGE_TYPE";
	/** The Constant ERROR_INDICATOR. */
	String ERROR_INDICATOR_KEY = "ERROR_INDICATOR";
	/** The Constant MATCH_COUNT. */
	String MATCH_COUNT_KEY = "MATCH_COUNT";
	/** The Constant MATCH_INDICATOR. */
	String MATCH_INDICATOR_KEY = "MATCH_INDICATOR";
	/** The Constant AKA_DL_NUMBER_COUNT. */
	String AKA_DL_NUMBER_COUNT_KEY = "AKA_DL_NUMBER_COUNT";
	/** The Constant AKA_SSN_NUMBER_COUNT. */
	String AKA_SSN_NUMBER_COUNT_KEY = "AKA_SSN_NUMBER_COUNT";
	/** The Constant MATCH_LIMIT_INDICATOR. */
	String MATCH_LIMIT_INDICATOR_KEY = "MATCH_LIMIT_INDICATOR";
	/** The Constant MATCH_SEQUENCE_NUMBER_ID. */
	String MATCH_SEQUENCE_NUMBER_ID_KEY = "MATCH_SEQUENCE_NUMBER_ID";
	/** The Constant STATE_OF_RECORD_CODE. */
	String STATE_OF_RECORD_CODE_KEY = "STATE_OF_RECORD_CODE";
	/** The Constant APPLICATION_ID. */
	String APPLICATION_ID_KEY = "APPLICATION_ID";
	/** The Constant RR_NAME. */
	String RR_NAME_KEY = "RR_NAME";
	/** The Constant RR_DATE_OF_BIRTH. */
	String RR_DATE_OF_BIRTH_KEY = "RR_DATE_OF_BIRTH";
	/** The Constant RR_SOCIAL_SECURITY_NUMBER. */
	String RR_SOCIAL_SECURITY_NUMBER_KEY = "RR_SOCIAL_SECURITY_NUMBER";
	/** The Constant RR_DRIVER_LICENSE_NUMBER. */
	String RR_DRIVER_LICENSE_NUMBER_KEY = "RR_DRIVER_LICENSE_NUMBER";
	/** The Constant RR_AKA1_NAME. */
	String RR_AKA1_NAME_KEY = "RR_AKA1_NAME";
	/** The Constant RR_OUT_OF_STATE_JURISDICTION. */
	String RR_OUT_OF_STATE_JURISDICTION_KEY = "RR_OUT_OF_STATE_JURISDICTION";
	/** The Constant RR_OUT_OF_STATE_LICENSE_NUMBER. */
	String RR_OUT_OF_STATE_LICENSE_NUMBER_KEY = "RR_OUT_OF_STATE_LICENSE_NUMBER";
	/** The Constant RR_2ND_INQUIRY_INDICATOR. */
	String RR_2ND_INQUIRY_INDICATOR_KEY = "RR_2ND_INQUIRY_INDICATOR";
	/** The Constant RR_AKA2_NAME. */
	String RR_AKA2_NAME_KEY = "RR_AKA2_NAME";
	/** The Constant RR_OUT_OF_STATE_DL_LAST_5. */
	String RR_OUT_OF_STATE_DL_LAST_5_KEY = "RR_OUT_OF_STATE_DL_LAST_5";
	/** The Constant RR_AKA3_NAME. */
	String RR_AKA3_NAME_KEY = "RR_AKA3_NAME";
	/** The Constant DL_CLASS. */
	String DL_CLASS_KEY = "DL_CLASS";
	/** The Constant DL_ENDORSEMENTS. */
	String DL_ENDORSEMENTS_KEY = "DL_ENDORSEMENTS";
	/** The Constant DL_EXPIRATION_DATE. */
	String DL_EXPIRATION_DATE_KEY = "DL_EXPIRATION_DATE";
	/** The Constant COMMERCIAL_STATUS. */
	String COMMERCIAL_STATUS_KEY = "COMMERCIAL_STATUS";
	/** The Constant NON_COMMERCIAL_STATUS. */
	String NON_COMMERCIAL_STATUS_KEY = "NON_COMMERCIAL_STATUS";
	/** The Constant STATE_OF_ORIGIN. */
	String STATE_OF_ORIGIN_KEY = "STATE_OF_ORIGIN";
	/** The Constant DL_RESTRICTION_CODE1. */
	String DL_RESTRICTION_CODE1_KEY = "DL_RESTRICTION_CODE1";
	/** The Constant DL_RESTRICTION_CODE2. */
	String DL_RESTRICTION_CODE2_KEY = "DL_RESTRICTION_CODE2";
	/** The Constant DL_RESTRICTION_CODE3. */
	String DL_RESTRICTION_CODE3_KEY = "DL_RESTRICTION_CODE3";
	/** The Constant DL_RESTRICTION_CODE4. */
	String DL_RESTRICTION_CODE4_KEY = "DL_RESTRICTION_CODE4";
	/** The Constant DL_RESTRICTION_CODE5. */
	String DL_RESTRICTION_CODE5_KEY = "DL_RESTRICTION_CODE5";
	/** The Constant DL_RESTRICTION_CODE6. */
	String DL_RESTRICTION_CODE6_KEY = "DL_RESTRICTION_CODE6";
	/** The Constant DL_RESTRICTION_CODE7. */
	String DL_RESTRICTION_CODE7_KEY = "DL_RESTRICTION_CODE7";
	/** The Constant DL_RESTRICTION_CODE8. */
	String DL_RESTRICTION_CODE8_KEY = "DL_RESTRICTION_CODE8";
	/** The Constant DL_RESTRICTION_CODE9. */
	String DL_RESTRICTION_CODE9_KEY = "DL_RESTRICTION_CODE9";
	/** The Constant DL_RESTRICTION_CODE10. */
	String DL_RESTRICTION_CODE10_KEY = "DL_RESTRICTION_CODE10";
	/** The Constant DL_RESTRICTION_CODE11. */
	String DL_RESTRICTION_CODE11_KEY = "DL_RESTRICTION_CODE11";
	/** The Constant DL_RESTRICTION_CODE12. */
	String DL_RESTRICTION_CODE12_KEY = "DL_RESTRICTION_CODE12";
	/** The Constant CURRENT_NAME. */
	String CURRENT_NAME_KEY = "CURRENT_NAME";
	/** The Constant AKA1_NAME. */
	String AKA1_NAME_KEY = "AKA1_NAME";
	/** The Constant 1ST_AKA_DL_NUMBER_STATE. */
	String AKA_1ST_DL_NUMBER_STATE_KEY = "1ST_AKA_DL_NUMBER_STATE";
	/** The Constant 1ST_AKA_DL_NUMBER. */
	String AKA_1ST_DL_NUMBER_KEY = "1ST_AKA_DL_NUMBER";
	/** The Constant AKA2_NAME. */
	String AKA2_NAME_KEY = "AKA2_NAME";
	/** The Constant AKA3_NAME. */
	String AKA3_NAME_KEY = "AKA3_NAME";
	/** The Constant CURRENT_DATE_OF_BIRTH. */
	String CURRENT_DATE_OF_BIRTH_KEY = "CURRENT_DATE_OF_BIRTH";
	/** The Constant CURRENT_SEX_CODE. */
	String CURRENT_SEX_CODE_KEY = "CURRENT_SEX_CODE";
	/** The Constant CURRENT_HEIGHT. */
	String CURRENT_HEIGHT_KEY = "CURRENT_HEIGHT";
	/** The Constant CURRENT_WEIGHT. */
	String CURRENT_WEIGHT_KEY = "CURRENT_WEIGHT";
	/** The Constant CURRENT_EYE_COLOR. */
	String CURRENT_EYE_COLOR_KEY = "CURRENT_EYE_COLOR";
	/** The Constant CURRENT_PRIMARY_DL_NUMBER_STATE. */
	String CURRENT_PRIMARY_DL_NUMBER_STATE_KEY = "CURRENT_PRIMARY_DL_NUMBER_STATE";
	/** The Constant CURRENT_PRIMARY_DL_NUMBER. */
	String CURRENT_PRIMARY_DL_NUMBER_KEY = "CURRENT_PRIMARY_DL_NUMBER";
	/** The Constant CURRENT_PRIMARY_SSN_NUMBER. */
	String CURRENT_PRIMARY_SSN_NUMBER_KEY = "CURRENT_PRIMARY_SSN_NUMBER";
	/** The Constant AKA_SSN_NUMBER. */
	String AKA_SSN_NUMBER_KEY = "AKA_SSN_NUMBER";
	/** The Constant TRANSACTION_CODE. */
	String TRANSACTION_CODE_KEY = "TRANSACTION_CODE";
	/** The Constant FILLER. */
	String FILLER_KEY = "FILLER";
	/** The Constant DATE_OF_MESSAGE. */
	String DATE_OF_MESSAGE_KEY = "DATE_OF_MESSAGE";
	/** The Constant TIME_OF_MESSAGE. */
	String TIME_OF_MESSAGE_KEY = "TIME_OF_MESSAGE";
	/** The Constant MESSAGE_ID. */
	String MESSAGE_ID_KEY = "MESSAGE_ID";
	/** The Constant NETWORK_STATUS_INDICATOR. */
	String NETWORK_STATUS_INDICATOR_KEY = "NETWORK_STATUS_INDICATOR";
	/** The Constant APPLICATION_STATUS_INDICATOR. */
	String APPLICATION_STATUS_INDICATOR_KEY = "APPLICATION_STATUS_INDICATOR";
	/** The Constant PROCESSING_STATUS. */
	String PROCESSING_STATUS_KEY = "PROCESSING_STATUS";
	/** The Constant LAST_MATCH_INDICATOR. */
	String LAST_MATCH_INDICATOR_KEY = "LAST_MATCH_INDICATOR";
	/** The Constant CHANGE_SOR_CODE. */
	String CHANGE_SOR_CODE_KEY = "CHANGE_SOR_CODE";
	/** The Constant DUPLICATE_FLAG. */
	String DUPLICATE_FLAG_KEY = "DUPLICATE_FLAG";
	/** The Constant AKA_NAME_COUNT. */
	String AKA_NAME_COUNT_KEY = "AKA_NAME_COUNT";
	/** The Constant 1ST_HIT_STATE_CODE. */
	String HIT_1ST_STATE_CODE_KEY = "1ST_HIT_STATE_CODE";
	/** The Constant ERROR_BLOCK. */
	String ERROR_BLOCK_KEY = "ERROR_BLOCK";
	/** The Constant FILTER1. */
	String FILTER1_KEY = "FILTER1";
	/** The Constant FILLER2. */
	String FILLER2_KEY = "FILLER2";
	/** The Constant FILLER3. */
	String FILLER3_KEY = "FILLER3";
	/** The Constant FILLER4. */
	String FILLER4_KEY = "FILLER4";
	/** The Constant FILLER4. */
	String FILLER5_KEY = "FILLER5";
	/** The Constant DL_WITHDRAWAL_PENDING_INDICATOR. */
	String DL_WITHDRAWAL_PENDING_INDICATOR_KEY = "DL_WITHDRAWAL_PENDING_INDICATOR";
	/** The Constant ERROR_RESPONSE. */
	String ERROR_RESPONSE = "ERROR RESPONSE";
	/** The Constant RECORD_TOO_LONG. */
	String RECORD_TOO_LONG = "RECORD TOO LONG";
	/** The Constant PARTIAL_RESPONSE. */
	String PARTIAL_RESPONSE = "PARTIAL RESPONSE";
	/** The Constant LENGTH_ERROR. */
	String LENGTH_ERROR = "LENGTH ERROR";
	/** The Constant NO_RESPONSE_RECEIVED. */
	String NO_RESPONSE_RECEIVED = "NO RESPONSE RECEIVED";
	/** The MATCH_INDICATOR_Y. */
	String MATCH_INDICATOR_Y = "Y";
	/** The MATCH_INDICATOR_N. */
	String MATCH_INDICATOR_N = "N";
	/** The Constant RC. */
	String CONST_RC = "RC";
	/** The Constant RD. */
	String CONST_RD = "RD";
	String CONST_RO = "RO";
	String CONST_R2 = "R2";
	String CONST_R3 = "R3";
	String CONST_XX = "XX";
	String CONST_ZZ = "ZZ";
	String CONST_IO = "IO";
	String CONST_TRUE = "Y";
	String CONST_D = "D";
	String CONST_U = "U";
	String CONST_P = "P";
	String CONST_T = "T";
	String CONST_I = "I";
	String CONST_M = "M";
	String CONST_F = "F";
	String CONST_G = "G";
	String CONST_N = "N";
	String CONST_B = "B";
	String CONST_A = "A";
	String CONST_C = "C";
	String CONST_S = "S";
	String CONST_W = "W";
	String CONST_R = "R";
	String CONST_CNA = "CNA";
	String CONST_1 = "1";
	String CONST_4 = "4";
	String CONST_6 = "6";
	String CONST_8 = "8";
	String CONST_9 = "9";
	/** The Constant HC. */
	String CONST_HC = "HC";
	/** The Constant E. */
	String CONST_E = "E";
	/** The Constant L. */
	String CONST_L = "L";
	/** The Constant SECOND_INQ_IND. */
	String SECOND_INQ_IND = "Y";
	/** The Constant MESSAGE_DEST_COUNTER_1. */
	String MESSAGE_DEST_COUNTER_1 = "1";
	/** The Constant MESSAGE_DEST_COUNTER_2. */
	String MESSAGE_DEST_COUNTER_2 = "2";
	/** The Constant MALE_GENDER_CODE. */
	String MALE_GENDER_CODE = "1";
	/** The Constant FEMALE_GENDER_CODE. */
	String FEMALE_GENDER_CODE = "2";
	/** The Constant MALE_GENDER_CODE_VALUE. */
	String MALE_GENDER_CODE_VALUE = "M";
	/** The Constant FEMALE_GENDER_CODE_VALUE. */
	String FEMALE_GENDER_CODE_VALUE = "F";
	/** The Constant BROWN_COLOR_CODE. */
	String BROWN_COLOR_CODE = "BRO";
	/** The Constant BROWN_COLOR_CODE_VALUE. */
	String BROWN_COLOR_CODE_VALUE = "BRN";
	/** The Constant HAZEL_COLOR_CODE. */
	String HAZEL_COLOR_CODE = "HAZ";
	/** The Constant HAZEL_COLOR_CODE_VALUE. */
	String HAZEL_COLOR_CODE_VALUE = "HZL";
	/** The Constant PINK_COLOR_CODE. */
	String PINK_COLOR_CODE = "PNK";
	/** The Constant DIC_COLOR_CODE. */
	String DIC_COLOR_CODE = "DIC";
	/** The Constant UNK_COLOR_CODE. */
	String UNK_COLOR_CODE = "UNK";
	String MMDD_FORMAT = "MMdd";
	/////////// SendLogMessageToNetworkControlCenterConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_NCC = "NCC";
	/////////// UpdateDlHistoryConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_DPR = "DPR";
	/** The Constant SYM_AT. */
	String SYM_AT = "@";
	/////////// UpdateDriverLicenseConverter Constants //////////////
	/** Transaction code */
	String TCODE_DL5 = "DL5";
	/** The constant CC_FLAG */
	String CC_FLAG = "Y";
	/** The constant A */
	String CON_A = "A";
	/////////// UpdateExtendedNameIndexConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_EN2 = "EN2";
	/** The Constant FUNCTION. */
	String FUNCTION_U = "U";
	/** The Constant RESPONSE_COUNT. */
	String RESPONSE_COUNT_01 = "01";
	/** The Constant ACTION. */
	String ACTION_A = "A";
	/** The Constant TRUE_OR_AKA_NAME. */
	String TRUE_OR_AKA_NAME = "T";
	/** The Constant BDLP_VERIFICATION_CODE. */
	String BDLP_VERIFICATION_CODE = "N";
	/////////// ValidateAutomatedReceiptConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_CIA = "CIA";
	/** The Constant SIZE_OF_INITIAL_PART_OF_INQUIRY. */
	int SIZE_OF_INITIAL_PART_OF_INQUIRY = 18;
	/** The Constant SIZE_OF_ONE_INQUIRED_VOUCHER. */
	int SIZE_OF_ONE_INQUIRED_VOUCHER = 15;
	/** The Constant GOOD_RESPONSE_SIZE. */
	int SIZE_OF_GOOD_RESPONSE = 95;
	/** The Constant ERROR_RESPONSE_SIZE. */
	int SIZE_OF_ERROR_RESPONSE = 5;
	/** The Constant ERRORMSG_FOR_ERRORCODE_73_AND_74. */
	String ERRORMSG_FOR_ERRORCODE_73_AND_74 = "F057 - CNA-CANNOT PROCESS Z97 - CANCEL TRANS";
	/** The Constant ERRORMSG_FOR_ERRORCODE_75. */
	String ERRORMSG_FOR_ERRORCODE_75 = "F068 - RECEIPT NOT ON FILE - CANNOT PROCESS Z97";
	/** The Constant ERRORMSG_FOR_ERRORCODE_TR. */
	String ERRORMSG_FOR_ERRORCODE_TR = "AR NOT FOUND";
	/** The Constant MISC_RECEIPT_COMMENT_CNA */
	String MISC_RECEIPT_COMMENT_CNA = "CNA         "; //12 chars
	/** The Constant MISC_RECEIPT_COMMENT_AR */
	String MISC_RECEIPT_COMMENT_AR = "AR NOT FOUND";
	/////////// ValidateSsnInquiryConverter Constants //////////////
	/** The Constant TCODE. */
	String TCODE_SS5 = "SS5";
	/** The Constant RETURN_CODE_DESCRIPTION_1 */
	String RETURN_CODE_DESCRIPTION_1 = "SSN, Name and DOB Verified";
	/** The Constant RETURN_CODE_DESCRIPTION_2 */
	String RETURN_CODE_DESCRIPTION_2 = "No Such SSN";
	/** The Constant RETURN_CODE_DESCRIPTION_3 */
	String RETURN_CODE_DESCRIPTION_3 = "Name Did Not Verify; DOB is Valid";
	/** The Constant RETURN_CODE_DESCRIPTION_4 */
	String RETURN_CODE_DESCRIPTION_4 = "DOB Did Not Verify, Name is Valid";
	/** The Constant RETURN_CODE_DESCRIPTION_5 */
	String RETURN_CODE_DESCRIPTION_5 = "Name and DOB Did Not Verify";
	/** The Constant RETURN_CODE_DESCRIPTION_6 */
	String RETURN_CODE_DESCRIPTION_6 = "Customer Contact Local SSA";
	/** The Constant RETURN_CODE_DESCRIPTION_9 */
	String RETURN_CODE_DESCRIPTION_9 = "CNA Unable to Process At This Time";
	/** The Constant SSN_MESSAGE_LENGTH */
	int SSN_MESSAGE_LENGTH = 268;
	/** The Constant SSN_MESSAGE_MIN_LENGTH */
	int SSN_MESSAGE_MIN_LENGTH = 69;
	/** The Constant SSN_VERIF_CODE_1 */
	String SSN_VERIF_CODE_1 = "1";
	/** The Constant SSN_VERIF_CODE_9 */
	String SSN_VERIF_CODE_9 = "9";
	/** The Constant SSN_VERIF_CODE_A */
	String SSN_VERIF_CODE_A = "A";
	/** The Constant SSN_VERIF_CODE_D */
	String SSN_VERIF_CODE_D = "D";
	/** The Constant SSN_VERIF_CODE_X */
	String SSN_VERIF_CODE_X = "X";
	/** The Constant SSN_VERIF_CODE_R */
	String SSN_VERIF_CODE_R = "R";
	/////////// ProofInquiryWithCompanyNumberConverter Constants //////////////
	/** The Constant TCODE_DHA */
	String TCODE_DHA = "DHA";
	/** The Constant FIELD_OFFICE_CODE */
	String FIELD_OFFICE_CODE = "80";
	/** The Constant INFORMATION_CODE */
	String INFORMATION_CODE = "1";
	/** The Constant FILE_CODE_N */
	String FILE_CODE_N = "N";
	/////////// ProofInquiryWithAbbrCompanyNumberConverter Constants //////////////
	/** The Constant TCODE_DHB */
	String TCODE_DHB = "DHB";
	/** The Constant FILE_CODE_A */
	String FILE_CODE_A = "A";
	/////////// AutomatedNameIndexDlInquiryConverter Constants //////////////
	/** The Constant TCODE_ADQ */
	String TCODE_ADQ = "ADQ";
	/** The Constant VARIABLE_DATA_FIELD_CODE */
	String VARIABLE_DATA_FIELD_CODE = "F";
	/** The Constant VARIABLE_DATA_LENGTH_001 */
	String VARIABLE_DATA_LENGTH_000 = "000";
	/** The Constant VARIABLE_DATA_LENGTH_003 */
	String VARIABLE_DATA_LENGTH_003 = "003";
	/** The constant TTC_07Q */
	String TTC_07Q = "07Q";
	/** The constant TTC_PRF */
	String TTC_PRF = "PRF";
	/** The constant TTC_PF3 */
	String TTC_PF3 = "PF3";
	/** The Constant UNLABELED */
	String UNLABELED = "1";
	/** The Constant ADQ_REQUEST_PART_OF_RESPONSE_LENGTH. */
	int ADQ_REQUEST_PART_OF_RESPONSE_LENGTH = 80;
	int ADQ_PRF_REQUEST_PART_OF_RESPONSE_LENGTH = 83;
	/** The Constant ADQ_ERRORCODE_OF_RESPONSE_LENGTH. */
	int ADQ_ERRORCODE_OF_RESPONSE_LENGTH = 2;
	/** The Constant ADQ_ANIRECORD_OF_RESPONSE_LENGTH. */
	int ADQ_ANIRECORD_OF_RESPONSE_LENGTH = 62;
	/** The constant GOOD_RETURN_CODE */
	String GOOD_RETURN_CODE = "  ";
	// Converter constants for TCodes DLC, DLD or DFT
	/** The constant TCODE_DLC. */
	String TCODE_DLC = "DLC";
	/** The constant TCODE_DLF. */
	String TCODE_DLF = "DLF";
	/** The constant TCODE_DLD. */
	String TCODE_DLD = "DLD";
	/** The constant TCODE_DLT. */
	String TCODE_DFT = "DFT";
	/** The constant TCODE_DRT. */
	String TCODE_DRT = "DRT";
	/** The constant DLC DLD Return Code*/
	String DLC_DLD_RETURN_CODE = "DLC DLD Return Code";
	/** The constant DUH DUP DQ1 Error Code*/
	String DUH_DUP_DQ1_ERROR_CODE = "DUH DUP DQ1 Error Code";
	/** The constant DHA DHB Return Code */
	String DHA_DHB_RETURN_CODE = "DHA_DHB_Return_Code";
	/** The constant DCA DCF Return Code */
	String DCA_DCF_RETURN_CODE = "DCA_DCF_Return_Code";
	String DCA_DCF_OTHER_RETURN_CODE = "otherReturnCode";
	/** The constant CDU Return Code */
	String CDU_RETURN_CODE = "CDU_Return_Code";
	/** The constant CDS Return Code */
	String CDS_RETURN_CODE = "CDS_Return_Code";
	/** The constant CDLIS Return Code */
	String CDLIS_RETURN_CODE = "CDLIS_Return_Code";
	/** The constant PDPS Return Code */
	String PDPS_RETURN_CODE = "PDPS_Return_Code";
	/** The constant DS5 DLL Return Code */
	String DS5_DLL_RETURN_CODE = "DS5_DLL_Return_Code";
	String DS5_DLL_OTHER_RETURN_CODE = "otherReturnCode";
	/** The constant ADQ Return Code */
	String ADQ_RETURN_CODE = "ADQ_Return_Code";
	/** The constant DLC DLD Return Code*/
	String PHOTO_RQUIRED_CODE_SET_NAME = "PHOTO_REQUIRED";
	/** The Long term CNA Return Code */
	String LONG_TERM_CNA_RETURN_CODE = "01";
	/** The constant for the variable data length field */
	String DATA_LENGTH_FIELD = new String("000");
	/** The constant 22. */
	int INT_22 = 22;
	/** The constant 24. */
	int INT_24 = 24;
	/** The constant 25. */
	int INT_25 = 25;
	// The converter constants for TCodes R62, RHC, RHI.
	/** The Constant TCode for R62 */
	String TCODE_R62 = "R62";
	/** The Constant TCode for RHC */
	String TCODE_RHC = "RHC";
	/** The Constant TCode for RHI */
	String TCODE_RHI = "RHI";
	/** The constant 99933*/
	String CONSTANT_99933 = "99933";
	/** The info code element 4 */
	String INFO_CODE_4 = "4";
	/** The Constant V */
	String CONSTANT_V = "V";
	// The converter constants for TCodes DFA, DFP.
	/** The constant TCode for DFA. */
	String TCODE_DFA = "DFA";
	/** The constant TCode for DFP. */
	String TCODE_DFP = "DFP";
	/** The constant service fee of $1 */
	String CONSTANT_SERVICE_FEE = "0100";
	// The State constants
	/** The constant STATE_CA */
	String STATE_CA = "CA";
	// Suffix Constants
	/** The constant SUFFIX_JR */
	String SUFFIX_JR = "JR";
	/** The constant SUFFIX_SR */
	String SUFFIX_SR = "SR";
	/** The constant SUFFIX_II */
	String SUFFIX_II = "II";
	/** The constant SUFFIX_III */
	String SUFFIX_III = "III";
	/** The constant SUFFIX_IV */
	String SUFFIX_IV = "IV";
	// The converter constants for TCode AHQ.
	/** The constant TOCE_AHQ */
	String TCODE_AHQ = "AHQ";
	/** The constant REQUESTER_CODE */
	String REQUESTER_CODE = "99933";
	/** The constant ANI_ADDRESS_CONST_A */
	String ANI_ADDRESS_CONST_A = ";A";
	/** The constant ANI_ADDRESS_CONST_C */
	String ANI_ADDRESS_CONST_C = ";C";
	/** The constant ANI_ADDRESS_CONST_B */
	String ANI_ADDRESS_CONST_B = ";B";
	/** The constant ANI_ADDRESS_CONST_Y */
	String ANI_ADDRESS_CONST_Y = ";Y";
	/** The constant ANI_ADDRESS_CONST_M */
	String ANI_ADDRESS_CONST_M = ";M";
	/** The constant ANI_INFOCODE_H6 */
	String ANI_INFOCODE_H6 = "H6";
	/** The constant ANI_INFOCODE_H9 */
	String ANI_INFOCODE_H9 = "H9";
	/** The constant ANI_INFOCODE_KX */
	String ANI_INFOCODE_FIRST_CHAR_K = "K";
	/** The constant ANI_INFOCODE_K3 */
	String ANI_INFOCODE_K3 = "K3";
	/** The constant ANI_INFOCODE_K4 */
	String ANI_INFOCODE_K4 = "K4";
	/** The constant ANI_INFOCODE_ */
	String ANI_INFOCODE_D = "D";
	/** The constant ANI_INFOCODE_H */
	String ANI_INFOCODE_H = "H";
	/** The constant ANI_INFOCODE_K */
	String ANI_INFOCODE_K = "K";
	/** The constant ANI_TYPE_INQUIRY_7 */
	String ANI_TYPE_INQUIRY_7 = "7";
	/** The constant ANI_TYPE_INQUIRY_8 */
	String ANI_TYPE_INQUIRY_8 = "8";
	/** The constant ANI_TYPE_INQUIRY_9 */
	String ANI_TYPE_INQUIRY_9 = "9";
	/** The constant TCODE_DQ1 */
	String TCODE_DQ1 = "DQ1";
	/** The constant TCODE_DQ1_RESPONSE_LENGTH */
	int TCODE_DQ1_RESPONSE_LENGTH = 189;
	/** The constant TCODE_RP1 */
	String TCODE_RP1 = "RP1";
	/** The constant PEASE_OFFICER_REUQEST_FOR_EMPLOYEE */
	String PEASE_OFFICER_REUQEST_FOR_EMPLOYEE = "EM";
	/** The constant PEACE_OFFICE_REQUEST_UPDATE_FOR_REGISTERED_OWNER */
	String PEACE_OFFICE_REQUEST_UPDATE_FOR_REGISTERED_OWNER = "R";
	//Commercial Status Codes
	String INPUT_COMM_STATUS_VAL = "VAL";
	String INPUT_COMM_STATUS_DIS = "DIS";
	String INPUT_COMM_STATUS_REV = "REV";
	String INPUT_COMM_STATUS_SUS = "SUS";
	String INPUT_COMM_STATUS_CAN = "CAN";
	String INPUT_COMM_STATUS_EXP = "EXP";
	String INPUT_COMM_STATUS_OTH = "OTH";
	String INPUT_COMM_STATUS_DED = "DED";
	String INPUT_COMM_STATUS_ELG = "ELG";
	String INPUT_COMM_STATUS_LIC = "LIC";
	String INPUT_COMM_STATUS_NOT = "NOT";
	String INPUT_COMM_STATUS_NEN = "NEN";
	String INPUT_COMM_STATUS_RPD = "RPD";
	String OUTPUT_COMM_STATUS_VAL = "8";
	String OUTPUT_COMM_STATUS_DIS = "2";
	String OUTPUT_COMM_STATUS_REV = "3";
	String OUTPUT_COMM_STATUS_SUS = "4";
	String OUTPUT_COMM_STATUS_CAN = "5";
	String OUTPUT_COMM_STATUS_EXP = "6";
	String OUTPUT_COMM_STATUS_OTH = "7";
	String OUTPUT_COMM_STATUS_DED = "1";
	String OUTPUT_COMM_STATUS_ELG = "A";
	String OUTPUT_COMM_STATUS_LIC = "B";
	String OUTPUT_COMM_STATUS_NOT = "C";
	String OUTPUT_COMM_STATUS_NEN = "C";
	String OUTPUT_COMM_STATUS_RPD = "D";
	String OUTPUT_COMM_STATUS_DEFAULT = "9";
	String OUTPUT_COMM_STATUS_DESC_VAL = "VALID";
	String OUTPUT_COMM_STATUS_DESC_DIS = "DISQUALIFIED";
	String OUTPUT_COMM_STATUS_DESC_REV = "REVOKED";
	String OUTPUT_COMM_STATUS_DESC_SUS = "SUSPENDED";
	String OUTPUT_COMM_STATUS_DESC_CAN = "CANCELLED";
	String OUTPUT_COMM_STATUS_DESC_EXP = "EXPIRED";
	String OUTPUT_COMM_STATUS_DESC_OTH = "OTHER NOT VALID";
	String OUTPUT_COMM_STATUS_DESC_DED = "DECEASED";
	String OUTPUT_COMM_STATUS_DESC_ELG = "ELIGIBLE";
	String OUTPUT_COMM_STATUS_DESC_LIC = "LICENSED";
	String OUTPUT_COMM_STATUS_DESC_NOT = "NOT ELIGIBLE";
	String OUTPUT_COMM_STATUS_DESC_NEN = "NOT ELIGIBLE";
	String OUTPUT_COMM_STATUS_DESC_RPD = "REPORTED DECEASED";
	String OUTPUT_COMM_STATUS_DESC_DEFAULT = "UNKNOWN STATUS";
	String TTC_DLA = "DLA";
	String TTC_DLE = "DLE";
	String TTC_DLG = "DLG";
	String ATTACHMENT_23 = "23";
	String ATTACHMENT_51 = "51";
	String ATTACHMENT_52 = "52";
	String ATTACHMENT_54 = "54";
	String ENDORSEMENT_SB = "SB";
	String ENDORSEMENT_HM = "HM";
	String RESTRICTION_CODE_29 = "29";
	int PDPS_APPLICATION_ID = 12;
	/** The constant TCode CAU1 */
	String TCODE_CAU1 = "CAU1";
	/** The fingerprint request type */
	String FINGER_PRINT_REQUEST_TYPE = "SVR";
	/** The photo request type. */
	String PHOTO_REQUEST_TYPE = "ICS";
	/** The type message request I*/
	String TYPE_MESSAGE_REQUEST_I = "I";
	/** The constant version number 1 */
	String VERSION_NUMBER_1 = "1";
	/** The application types */
	String APPLICATION_TYPE_D = "D";
	String APPLICATION_TYPE_I = "I";
	String APPLICATION_TYPE_S = "S";
	/** The retrieval indicators*/
	String RETRIEVAL_INDICATOR_E = "E";
	String RETRIEVAL_INDICATOR_R = "R";
	String RETRIEVAL_INDICATOR_S = "S";
	/** The Dl Expiration codes */
	String ELI_DL_EXPIRATION_CODE_30 = "30";
	String ELI_DL_EXPIRATION_CODE_31 = "31";
	String ELI_DL_EXPIRATION_CODE_32 = "32";
	/** The Id Expiration codes */
	String ELI_ID_EXPIRATION_CODE_31 = "31";
	String ELI_ID_EXPIRATION_CODE_NO = "NO";
	String TCODE_CDS = "CDS";
	String CDS_MESSAGE_TYPE_SB = "SB";
	String CDS_MESSAGE_TYPE_SG = "SG";
	String TTC_IDS = "IDS";
	String TTC_IDP = "IDP";
	String TTC_IDA = "IDA";
	String PHOTO_REQUIRED = "Y";
	String ENDORSEMENT_H_CODE = "H";
	String ENDORSEMENT_N_CODE = "N";
	String ENDORSEMENT_P_CODE = "P";
	String ENDORSEMENT_T_CODE = "T";
	String ENDORSEMENT_X_CODE = "X";
	String ENDORSEMENT_S_CODE = "S";
	String ENDORSEMENT_H_VALUE = "HM";
	String ENDORSEMENT_N_VALUE = "TV";
	String ENDORSEMENT_P_VALUE = "PV";
	String ENDORSEMENT_T_VALUE = "DT";
	String ENDORSEMENT_X_VALUE = "HM";
	String ENDORSEMENT_S_VALUE = "SB";
	/** The Constant FIRE_FIGHTER_CLASSS_A. */
	String FIRE_FIGHTER_CLASSS_A = "1";
	/** The Constant FIRE_FIGHTER_CLASSS_B. */
	String FIRE_FIGHTER_CLASSS_B = "2";
	String TRAILER_COACH = "3";
	/** The Constant License Class Type A. */
	String COMMERCIAL_APP_CLASS_A = "A";
	/** The Constant License Class Type B. */
	String COMMERCIAL_APP_CLASS_B = "B";
	/** The Constant License Class Type C. */
	String COMMERCIAL_APP_CLASS_C = "C";
	/** The Constant incomplete application commercial inquiry. */
	String INCOMPLETE_APP_COMMERCIAL_INQUIRY = "CI";
	/** The Constant incomplete application reason code PDPS inquiry. */
	String INCOMPLETE_APP_PDPS_INQUIRY = "PD";
	/** The Constant incomplete application reason code skill test required. */
	String INCOMPLETE_APP_SKILL_TEST_REQUIRED = "CE";
	/** The Constant incomplete application reason code PDPS withheld. */
	String INCOMPLETE_APP_PDPS_WITHHELD = "WP";
	/** The Constant incomplete application test results. */
	String INCOMPLETE_APP_TEST_RESULTS = "TR";
	/** The Constant incomplete application birthdate verification. */
	String INCOMPLETE_APP_BIRTHDATE_VERIFICATION = "RB";
	/** The Constant test results complete. */
	String TEST_RESULTS_COMPLETE = "C";
	/** The Constant written test failed. */
	String WRITTEN_TEST_FAILED = "W";
	/** The Constant drive test failed. */
	String DRIVE_TEST_FAILED = "D";
	/** The Constant written and drive test failed. */
	String WRITTEN_AND_DRIVE_TEST_FAILED = "B";
	/** The Constant test incomplete. */
	String TEST_INCOMPLETE = "T";
	/** The Constant test pass. */
	String TEST_RESULT_PASS = "P";
	/** The Constant test waived. */
	String TEST_RESULT_WAIVED = "W";
	/** The Constant test result satisfactory. */
	String TEST_RESULT_SATISFACTORY = "S";
	/** The Constant test result with certificate of compentense. */
	String TEST_RESULTS_CERTIFICATE_COMPENTENSE = "C";
	/** The Constant photo type on file P. */
	String PHOTO_TYPE_ON_FILE_P = "P";
	/** The Constant photo type on file L. */
	String PHOTO_TYPE_ON_FILE_L = "L";
	/** The Constant photo taken type P. */
	String PHOTO_TAKEN_TYPE_P = "P";
	/** The CD s_ erro r_ indicato r_ y. */
	String CDS_ERROR_INDICATOR_Y = "Y";
	/** The CD s_ erro r_ indicato r_ n. */
	String CDS_ERROR_INDICATOR_N = "N";
	/** The CD s_ erro r_ indicato r_ cna. */
	String CDS_ERROR_INDICATOR_CNA = "D";
	/** The CD s_ erro r_ indicato r_ undeliverable. */
	String CDS_ERROR_INDICATOR_UNDELIVERABLE = "U";
	/** The CD s_ matc h_ indicato r_ y. */
	String CDS_MATCH_INDICATOR_Y = "Y";
	/** The CD s_ messag e_ typ e_ hg. */
	String CDS_MESSAGE_TYPE_HG = "HG";
	/** The Constant DMV_RETEST Attachment. */
	String DMV_RETEST_ATTACHMENT = "36";
	/** The Constant ATTACHMENT_13. */
	String ATTACHMENT_13 = "13";
	/** The Constant ATTACHMENT_00. */
	String ATTACHMENT_00 = "00";
	/** The constant for vision only test required */
	String VISION_ONLY_TEST_REQ = "VISION ONLY TEST REQ";
	/** The constant for hazardous material only test required */
	String HM_ONLY_TEST_REQ = "HM ONLY TEST REQ";
	/** The non commercial application class A. */
	String NON_COMMERCIAL_APP_CLASS_A = "D";
	/** The non commercial application class B. */
	String NON_COMMERCIAL_APP_CLASS_B = "E";
	/** The non commercial application class C. */
	String NON_COMMERCIAL_APP_CLASS_C = "F";
	/** The motor cycle application class. */
	String MOTOR_CYCLE_APP_CLASS = "M";
	/** The photo code based on the system LIS. */
	String PHOTO_CODE_LIS = "LIS";
	/** The duplicate photo code. */
	String PHOTO_CODE_DUP = "DUP";
	/** The poloroid photo code. */
	String PHOTO_CODE_POL = "POL";
	/** The poloroid photo codes. */
	List <String> POLOROID_PHOTO_CODES = Arrays.asList("994", "995", "996");
	/** The NULL_OR_BLANK_ECS_EXCEPTION_MESSAGE. */
	String NULL_OR_BLANK_ECS_EXCEPTION_MESSAGE = "Invalid Response: Unable to process on null message";
	/** The constant for blank date in MM/DD/YY format. */
	String BLANK_DATE_MM_DD_YY = "000000";
	/** The Constant LAST_NAME. */
	String LAST_NAME_KEY = "LAST_NAME";
	/** The Constant FIRST_NAME. */
	String FIRST_NAME_KEY = "FIRST_NAME";
	/** The Constant MIDDLE_NAME. */
	String MIDDLE_NAME_KEY = "MIDDLE_NAME";
	/** The Constant NAME_SUFFIX. */
	String NAME_SUFFIX_KEY = "NAME_SUFFIX";
	/** The Constant AKA1 LAST_NAME. */
	String AKA1_LAST_NAME_KEY = "AKA1_LAST_NAME";
	/** The Constant AKA1 FIRST_NAME. */
	String AKA1_FIRST_NAME_KEY = "AKA1_FIRST_NAME";
	/** The Constant AKA1 MIDDLE_NAME. */
	String AKA1_MIDDLE_NAME_KEY = "AKA1_MIDDLE_NAME";
	/** The Constant AKA1 NAME_SUFFIX. */
	String AKA1_NAME_SUFFIX_KEY = "AKA1_NAME_SUFFIX";
	/** The Constant AKA2 LAST_NAME. */
	String AKA2_LAST_NAME_KEY = "AKA2_LAST_NAME";
	/** The Constant AKA2 FIRST_NAME. */
	String AKA2_FIRST_NAME_KEY = "AKA2_FIRST_NAME";
	/** The Constant AKA2 MIDDLE_NAME. */
	String AKA2_MIDDLE_NAME_KEY = "AKA2_MIDDLE_NAME";
	/** The Constant AKA2 NAME_SUFFIX. */
	String AKA2_NAME_SUFFIX_KEY = "AKA2_NAME_SUFFIX";
	/** The Constant AKA3 LAST_NAME. */
	String AKA3_LAST_NAME_KEY = "AKA3_LAST_NAME";
	/** The Constant AKA3 FIRST_NAME. */
	String AKA3_FIRST_NAME_KEY = "AKA3_FIRST_NAME";
	/** The Constant AKA3 MIDDLE_NAME. */
	String AKA3_MIDDLE_NAME_KEY = "AKA3_MIDDLE_NAME";
	/** The Constant AKA3 NAME_SUFFIX. */
	String AKA3_NAME_SUFFIX_KEY = "AKA3_NAME_SUFFIX";
	/** The constants TCODE_ME7. */
	String TCODE_ME7 = "ME7";
	/** The constants TCODE_ME8. */
	String TCODE_ME8 = "ME8";
	/** The constants TCODE_DLM. */
	String TCODE_DLM = "DLM";
	// passport verification tcode
	String TCODE_PAS = "PAS";
	// verified/match
	String PAS_VERIF_CODE_V = "Y";
	// non-match
	String PAS_VERIF_CODE_N = "N";
	// timeout or some other error (CNA)
	String PAS_VERIF_CODE_C = "C";
	//Canada country code
	String CAN = "CAN";
}
/**
 *  Modification History:
 *
 *  $Log: IEcsConverterConstants.java,v $
 *  Revision 1.10  2018/04/16 16:21:04  mwskh1
 *  SAVE Project for LPV message changes merge to HEAD
 *
 *  Revision 1.9.14.1  2018/04/09 19:51:48  mwnxg5
 *  Modifications to LPV request and parsing of the response.
 *
 *  Revision 1.9  2017/11/09 16:31:05  mwskh1
 *  Real ID - Merge to HEAD
 *
 *  Revision 1.8  2013/12/31 21:20:36  mwftd
 *  Added tcode for DLM
 *
 *  Revision 1.7.22.1  2017/08/11 22:25:35  mwsec2
 *  Added passport verification constants
 *
 *  Revision 1.7  2013/08/27 21:06:15  mwskh1
 *  CDLIS 5.2 - added SSN lengths
 *
 *  Revision 1.6  2013/08/23 16:25:05  mwskh1
 *  CDLIS 5.2 - updated the message length
 *
 *  Revision 1.5  2013/05/29 16:49:10  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *
 *  Revision 1.3.2.6  2013/05/08 20:14:24  mwgxd3
 *  CDLIS - Update TCode name ME7, ME8.
 *
 *  Revision 1.3.2.5  2013/05/07 16:03:04  mwskh1
 *  CDLIS 5.2 - added MESSAGE_PAYLOAD_CDLIS5_52_RECORD_LENGTH
 *
 *  Revision 1.3.2.4  2013/04/15 19:35:26  mwskh1
 *  CDLIS 5.2 -added FILLER5_KEY
 *
 *  Revision 1.3.2.3  2013/03/27 22:26:41  mwskh1
 *  CDLIS Mod 5.2 	updated MESSAGE_PAYLOAD_CDLIS_RECORD_LENGTH to 1362;
 *
 *  Revision 1.3.2.2  2013/03/11 20:21:51  mwgxd3
 *  CDLIS - add ME2 TCode
 *
 *  Revision 1.3.2.1  2013/03/06 16:16:37  mwskh1
 *  CDLIS 5.2 - added constants to support expanded name and expanded AKA names
 *
 *  Revision 1.4  2013/03/04 23:28:26  mwgxd3
 *  CDLIS/PDPS add new TCode constants
 *
 *  Revision 1.3  2013/01/07 20:41:28  mwhys
 *  Added CONST_S. (Defect 8402)
 *
 *  Revision 1.2  2012/11/05 18:51:28  mwgxd3
 *  AB91 - Remove duplicate constants; these constants are in IFeeConstants class.
 *
 *  Revision 1.1.2.1  2012/10/08 16:32:00  mwgxd3
 *  AB91 - consolidate fee indicator constants into IFeeConstants.
 *
 * $Log: IEcsConverterConstants.java,v $
 * Revision 1.10  2018/04/16 16:21:04  mwskh1
 * SAVE Project for LPV message changes merge to HEAD
 *
 * Revision 1.9.14.1  2018/04/09 19:51:48  mwnxg5
 * Modifications to LPV request and parsing of the response.
 *
 * Revision 1.9  2017/11/09 16:31:05  mwskh1
 * Real ID - Merge to HEAD
 *
 * Revision 1.8  2013/12/31 21:20:36  mwftd
 * Added tcode for DLM
 *
 * Revision 1.7  2013/08/27 21:06:15  mwskh1
 * CDLIS 5.2 - added SSN lengths
 *
 * Revision 1.6  2013/08/23 16:25:05  mwskh1
 * CDLIS 5.2 - updated the message length
 *
 * Revision 1.5  2013/05/29 16:49:10  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.4  2013/03/04 23:28:26  mwgxd3
 * CDLIS/PDPS add new TCode constants
 *
 * Revision 1.3  2013/01/07 20:41:28  mwhys
 * Added CONST_S. (Defect 8402)
 *
 * Revision 1.2  2012/11/05 18:51:28  mwgxd3
 * AB91 - Remove duplicate constants; these constants are in IFeeConstants class.
 *
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/08/14 20:30:59  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.7  2012/07/12 23:21:51  mwxxw
 *  Add new constant: CONST_R.
 *
 *  Revision 1.6  2012/06/26 20:54:15  mwhys
 *  Added SSN_MESSAGE_MIN_LENGTH.
 *
 *  Revision 1.5  2012/01/30 23:53:43  mwsec2
 *  FODI integration code merged to HEAD
 *
 *  Revision 1.4  2011/11/02 18:38:50  mwuxb
 *  Added constant BLANK_DATE_MM_DD_YY
 *
 *  Revision 1.3  2011/08/19 16:29:24  mwhys
 *  Added constant NULL_OR_BLANK_ECS_EXCEPTION_MESSAGE.
 *
 *  Revision 1.2  2011/07/16 00:49:14  mwxxw
 *  Add more tcode constants.
 *
 *  Revision 1.1  2011/07/15 21:48:09  mwxxw
 *  Move this constant file from EASEDriverLicense to EASEArchitecture.
 *
 *  Revision 1.98  2011/07/11 22:35:39  mwhys
 *  Added ELIGIBILITY_STATEMENT_CODE_CONDITION_26
 *
 *  Revision 1.97  2011/06/05 23:31:47  mwuxb
 *  Added constant for IARC code RB
 *
 *  Revision 1.96  2011/05/04 15:49:57  mwuxb
 *  Removed duplicate constants.
 *
 *  Revision 1.95  2011/05/04 15:49:26  mwuxb
 *  Updated to add incomplete application reason code constants
 *
 *  Revision 1.94  2011/05/04 01:58:30  mwsyk1
 *  Added constants for Incomplete Application Reason Codes
 *
 *  Revision 1.93  2011/04/21 00:31:55  mwuxb
 *  Added constants for photo codes.
 *
 *  Revision 1.92  2011/04/15 22:52:14  mwuxb
 *  Added constants for photo codes.
 *
 *  Revision 1.91  2011/04/14 23:29:07  mwjxa11
 *  Incorporated the change request updates
 *
 *  Revision 1.90  2011/03/21 22:10:59  mwhys
 *  Fixed for CDS.
 *
 *  Revision 1.89  2011/03/18 01:37:17  mwuxb
 *  Added constants.
 *
 *  Revision 1.88  2011/03/16 18:46:26  mwhys
 *  Updated with 2 constants used in cdlis/pdps converter.
 *
 *  Revision 1.87  2011/03/16 16:44:17  mwhys
 *  Added CDS_RETURN_CODE.
 *
 *  Revision 1.86  2011/03/16 16:07:16  mwyxg1
 *  code review change
 *
 *  Revision 1.85  2011/03/15 18:43:12  mwyxg1
 *  add three new constants, fix 5220
 *
 *  Revision 1.84  2011/03/15 18:13:16  mwyxg1
 *  add PHOTO_RQUIRED_CODE_SET_NAME
 *
 *  Revision 1.83  2011/03/15 18:10:08  mwyxg1
 *  add PHOTO_RQUIRED_CODE
 *
 *  Revision 1.82  2011/03/15 17:52:44  mwyxg1
 *  add TTC_DLD
 *
 *  Revision 1.81  2011/03/10 21:29:14  mwhxb3
 *  Chanded spelling ro TRAILER_COACH.
 *
 *  Revision 1.80  2011/03/10 21:26:22  mwhxb3
 *  Added constant.
 *
 *  Revision 1.79  2011/03/07 00:18:00  mwuxb
 *  Added constants for test results.
 *
 *  Revision 1.78  2011/03/01 01:25:00  mwuxb
 *  Added license class constants.
 *
 *  Revision 1.77  2011/03/01 00:51:49  mwuxb
 *  Added fire fighter categories constants.
 *
 *  Revision 1.76  2011/02/28 22:37:35  mwhys
 *  Fixed defects 4108 and 4518.
 *
 *  Revision 1.75  2011/02/08 02:09:17  mwpxr4
 *  Updated DLP to ttc.
 *
 *  Revision 1.74  2011/02/02 02:15:46  mwrrv2
 *  Updated the constant files as per new requirements.
 *
 *  Revision 1.73  2011/01/31 00:53:33  mwpxr4
 *  Added new constants.
 *
 *  Revision 1.72  2011/01/24 23:56:30  mwhys
 *  Added constants for CDL commercial and non commercial statuses.
 *
 *  Revision 1.71  2011/01/19 17:24:31  mwhys
 *  Added a constant CONST_ZZ.
 *
 *  Revision 1.70  2011/01/07 02:03:11  mwhys
 *  Updated DESTINATION to "XX" (Used in CDU tcode)
 *
 *  Revision 1.69  2010/12/24 17:23:46  mwhxb3
 *  REMOVAL_INDICATOR changes to SPACE.
 *
 *  Revision 1.68  2010/12/23 06:49:05  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.67.4.4  2010/12/23 04:18:26  mwkkc
 *  Rebase from head - DL
 *
 *  Revision 1.67  2010/12/15 21:44:16  mwpxr4
 *  Corrected value.
 *
 *  Revision 1.66  2010/12/15 03:17:39  mwpxr4
 *  Corrected Hex NULL value.
 *
 *  Revision 1.65  2010/11/22 23:37:53  mwpxr4
 *  Added new constants.
 *
 *  Revision 1.64  2010/11/13 00:32:56  mwhys
 *  Added more constants.
 *
 *  Revision 1.63  2010/11/09 18:30:28  mwpxr4
 *  Unicode character is removed from request. This is to fix irrelevant response for DLC TCode.
 *
 *  Revision 1.62  2010/10/15 21:22:57  mwpxr4
 *  Added new constants related to CAU1 TCode.
 *
 *  Revision 1.61  2010/10/14 21:19:45  mwpxr4
 *  New constants added for CAU1 TCode.
 *
 *  Revision 1.60  2010/10/07 18:43:13  mwhys
 *  Updated.
 *
 *  Revision 1.59  2010/10/07 18:23:22  mwhys
 *  Updated.
 *
 *  Revision 1.58  2010/10/07 18:18:55  mwhys
 *  Inserted 2 fields for holding other return codes.
 *
 *  Revision 1.57  2010/10/06 21:07:32  mwhys
 *  Added ADQ_Return_Code field, updated MISC_RECEIPT_COMMENT.
 *
 *  Revision 1.56  2010/10/06 17:31:50  mwhys
 *  Added a field "DS5_DLL_Return_Code".
 *
 *  Revision 1.55  2010/10/06 00:14:50  mwhys
 *  Added a field "DCA_DCF_Return_Code".
 *
 *  Revision 1.54  2010/10/05 23:22:29  mwhys
 *  Added a field "DHA_DHB_Return_Code".
 *
 *  Revision 1.53  2010/10/05 20:35:06  mwhys
 *  Added a field "DUH DUP DQ1 Error Code" which is used to get the return codes (CodeSetElement) from the EcsConverter response message.
 *
 *  Revision 1.52  2010/09/14 23:27:31  mwyxg1
 *  add ADQ_PRF_REQUEST_PART_OF_RESPONSE_LENGTH
 *
 *  Revision 1.51  2010/08/31 22:07:59  mwhxb3
 *  Added Reissue Fee indicators.
 *
 *  Revision 1.50  2010/08/31 21:50:36  mwhxb3
 *  Added fee indicators.
 *
 *  Revision 1.49  2010/08/11 16:17:37  mwpxr4
 *  Added new constants for ATL-DLA updates.
 *
 *  Revision 1.48  2010/07/19 20:47:51  mwpxr4
 *  Added new constants as part of update in ATL-DLA converter.
 *
 *  Revision 1.47  2010/06/25 21:01:34  mwhxa2
 *  Added Constants for CDLIS/PDPS Ecs Converter
 *
 *  Revision 1.46  2010/06/21 23:18:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.39.2.2  2010/06/20 18:09:00  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.45  2010/06/04 22:01:06  mwhxb3
 *  Modified constant name.
 *
 *  Revision 1.44  2010/06/04 20:45:49  mwbxg3
 *  Added New TCODEs for: DAD, DAK, DLX,DLU converters
 *
 *  Revision 1.43  2010/06/03 18:33:07  mwuxb
 *  updated for Tcode RP1
 *
 *  Revision 1.42  2010/06/01 21:13:50  mwhxb3
 *  Updated BDLP constants.
 *
 *  Revision 1.41  2010/06/01 20:56:30  mwhxb3
 *  Updated BDLP constants.
 *
 *  Revision 1.40  2010/06/01 20:40:54  mwhxb3
 *  Updated BDLP constants.
 *
 *  Revision 1.39  2010/05/29 18:27:21  mwuxb
 *  updated for tcode rp1
 *
 *  Revision 1.38  2010/05/22 23:41:27  mwhxb3
 *  Updated VARIABLE_DATA_LENGTH_000.
 *
 *  Revision 1.37  2010/05/22 23:16:36  mwuxb
 *  Added new constants
 *
 *  Revision 1.36  2010/05/22 20:09:39  mwhxb3
 *  Added ANI type inquiry constants.
 *
 *  Revision 1.35  2010/05/22 18:23:13  mwhxb3
 *  Added ANI_ADDRESS_CONSts.
 *
 *  Revision 1.34  2010/05/22 18:06:49  mwhxb3
 *  Updated TOCE_AHQ.
 *
 *  Revision 1.33  2010/05/22 18:04:40  mwhxb3
 *  Added converter constants for TCode AHQ.
 *
 *  Revision 1.32  2010/05/21 00:24:06  mwhxb3
 *  Added TCODE_DLF constant.
 *
 *  Revision 1.31  2010/05/21 00:21:50  mwhxb3
 *  Added TTC_PF3.
 *
 *  Revision 1.30  2010/05/20 00:36:32  mwhxb3
 *  Added SYM_AT constant.
 *
 *  Revision 1.29  2010/05/20 00:24:21  mwhxb3
 *  Added yess. no constants
 *
 *  Revision 1.28  2010/05/20 00:05:31  mwhxb3
 *  Added STATE_CODE_REG_EXP.
 *
 *  Revision 1.27  2010/05/19 23:53:54  mwhxb3
 *  Added state of origin.
 *
 *  Revision 1.26  2010/05/19 23:50:50  mwhxb3
 *  Added ProblemDriverUpdateConverter costansts
 *
 *  Revision 1.25  2010/05/19 23:32:15  mwhxb3
 *  Added UPDATE_DATA constants
 *
 *  Revision 1.24  2010/05/19 23:28:43  mwhxb3
 *  Added * constant.
 *
 *  Revision 1.23  2010/05/19 23:24:41  mwhxb3
 *  Added state and suffix constants.
 *
 *  Revision 1.22  2010/05/19 21:05:18  mwhxb3
 *  Added GOOD_RETURN_CODE.
 *
 *  Revision 1.21  2010/05/19 20:52:17  mwhxb3
 *  Added DHA_DHB_RETURN_CODE_00.
 *
 *  Revision 1.20  2010/05/19 20:46:08  mwhxb3
 *  Added DHA_DHB_RETURN_CODESETNAME.
 *
 *  Revision 1.19  2010/05/19 18:45:08  mwhxb3
 *  Added AutomatedNameIndexDlInquiryConverter constants.
 *
 *  Revision 1.18  2010/05/19 18:37:15  mwhxb3
 *  Added ADQ_CODESET_NAME.
 *
 *  Revision 1.17  2010/05/19 16:34:08  mwpxr4
 *  Moved constants from Converter files to Ecs constants.
 *
 *  Revision 1.16  2010/05/17 17:54:20  mwhxb3
 *  Added Constants
 *
 *  Revision 1.15  2010/05/16 01:05:41  mwhxb3
 *  Added AutomatedNameIndexDlInquiryConverter constants.
 *
 *  Revision 1.14  2010/05/13 18:05:31  mwhxb3
 *  Added constants
 *
 *  Revision 1.13  2010/05/04 21:31:34  mwhxb3
 *  Added constants.
 *
 *  Revision 1.12  2010/05/04 21:27:40  mwhxb3
 *  Added constants.
 *
 *  Revision 1.11  2010/05/04 21:25:34  mwhxb3
 *  Added constants.
 *
 *  Revision 1.10  2010/05/04 21:23:13  mwhxb3
 *  Added constants.
 *
 *  Revision 1.9  2010/05/04 21:16:06  mwhxb3
 *  Added constants.
 *
 *  Revision 1.8  2010/05/04 21:12:56  mwhxb3
 *  Added constants.
 *
 *  Revision 1.7  2010/05/04 21:07:41  mwhxb3
 *  Added constants.
 *
 *  Revision 1.6  2010/05/04 21:03:38  mwhxb3
 *  Added constants.
 *
 *  Revision 1.5  2010/05/04 20:57:38  mwhxb3
 *  Added constants.
 *
 *  Revision 1.4  2010/05/04 20:55:36  mwhxb3
 *  Added constants.
 *
 *  Revision 1.3  2010/05/04 20:50:23  mwhxb3
 *  Added constants.
 *
 *  Revision 1.2  2010/05/04 20:38:59  mwhxb3
 *  Adding constants.
 *
 *  Revision 1.1  2010/04/20 20:19:40  mwtjc1
 *  updated
 *
 *  Revision 1.1  2010/04/19 22:55:11  mwtjc1
 *  interface containing constants for ecs converters
 *
 */
