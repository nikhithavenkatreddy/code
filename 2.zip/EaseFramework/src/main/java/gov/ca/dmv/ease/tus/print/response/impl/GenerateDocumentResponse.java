package gov.ca.dmv.ease.tus.print.response.impl;

import gov.ca.dmv.ease.bo.document.impl.Document;
import gov.ca.dmv.ease.ecs.response.impl.SynchronousResponse;

/**
 * Description: Response class for GenerateDocumentResponse
 * File: GenerateDocumentResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response.impl
 * Created: 2009 
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class GenerateDocumentResponse extends SynchronousResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2273715437225930750L;
	private String data;
	/** The document identifier. */
	private Document document;

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * get the documentIdentifier.
	 * 
	 * @return the document identifier
	 */
	public Document getDocumentIdentifier() {
		return document;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	/**
	 * set the documentIdentifier.
	 * 
	 * @param document the document identifier
	 */
	public void setDocumentIdentifier(Document document) {
		this.document = document;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("data", data, anIndent, aBuilder);
		outputKeyValue("document", document, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: GenerateDocumentResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/08/25 17:57:28  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/12/12 05:53:49  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.6  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/06/21 23:00:42  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.6.2  2010/06/20 18:06:54  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.4  2010/06/07 17:42:55  mwpxp2
 *  Added fle footer
 *
 */
