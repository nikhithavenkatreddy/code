/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.process.impl;

import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;

import java.io.Serializable;
import java.util.List;

/**
 * Description: This is the implementation of the business process which keeps track of the context class name, 
 * ID of the business process like DLA or VR A00 and starts the StartActivity of the respective business process.
 * File: BusinessProcess.java
 * Module:  gov.ca.dmv.ease.app.process
 * Created: Aug 10, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BusinessProcess implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4466963219708002725L;
	//	/** The application context. */
	//	private transient ApplicationContext applicationContext;
	/** The context class name. */
	private String contextClassName;
	/** The id. */
	private String id;
	/** The starting activity. */
	private Activity startingActivity;
	/** The transaction types. */
	private List <TransactionType> transactionTypes;

	/**
	 * Gets the context class name.
	 * 
	 * @return the contextClassName
	 */
	public String getContextClassName() {
		return contextClassName;
	}

	/**
	 * Gets the ID of the business process.
	 * 
	 * @return Business Process ID
	 */
	public String getId() {
		return id;
	}

	/**
	 * Returns the current process context for the business process.
	 * 
	 * @return ProcessContext instance
	 */
	public ProcessContext getProcessContext() {
		ProcessContext processContext = (ProcessContext) EaseProxyUtils
				.getProxyObject(EaseApplicationContext.getApplicationContext()
						.getBean(getContextClassName()));
		processContext.setProcessId(getId());
		processContext.setCurrentActivity(getStartingActivity());
		return processContext;
	}

	/**
	 * Get the start activity for this business process.
	 * 
	 * @return Start Activity
	 */
	public Activity getStartingActivity() {
		return startingActivity;
	}

	/**
	 * Get the transaction types associated with this business process
	 * 	 * 
	 * @return
	 */
	public List <TransactionType> getTransactionTypes() {
		return transactionTypes;
	}

	//	/* (non-Javadoc)
	//	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	//	 */
	//	public void setApplicationContext(ApplicationContext aCtx)
	//			throws BeansException {
	//		applicationContext = aCtx;
	//	}
	/**
	 * Sets the context class name.
	 * 
	 * @param contextClassName the context class name
	 */
	public void setContextClassName(String aName) {
		contextClassName = aName;
	}

	/**
	 * Sets the business process ID for the current process.
	 * 
	 * @param id Business Process ID
	 */
	public void setId(String anId) {
		id = anId;
	}

	/**
	 * Sets the start activity for the business process.
	 * 
	 * @param startingActivity Start activity for the process
	 */
	public void setStartingActivity(Activity anActivity) {
		startingActivity = anActivity;
	}

	/**
	 * Set the transaction codes associated with this business process
	 * 
	 * @param transactionCodes
	 */
	public void setTransactionTypes(List <TransactionType> transTypes) {
		transactionTypes = transTypes;
	}
}
/**
 *  Modification History:
 *
 *  $Log: BusinessProcess.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.14  2011/10/12 20:54:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.13.20.1  2011/09/28 02:47:10  mwpxp2
 *  Removed unnecessary this.
 *
 *  Revision 1.13  2010/09/28 23:30:04  mwsec2
 *  removed security roles from business process
 *
 *  Revision 1.12  2010/09/23 19:46:13  mwhys
 *  clean-up.
 *
 *  Revision 1.11  2010/09/14 17:16:52  mwhys
 *  (1) Removed implements ApplicationContextAware.
 *  (2) Replaced applicationContext injection with the static method EaseApplicationContext.getApplicationContext().
 *
 *  Revision 1.10  2010/09/03 16:51:51  mwsec2
 *  list of TransactionType added as property, security role property marked to be removed
 *
 *  Revision 1.9  2010/07/13 17:11:02  mwkfh
 *  relocated session restore packages
 *
 *  Revision 1.8  2010/05/27 21:08:19  mwpxp2
 *  Removed needless t~his-es
 *
 *  Revision 1.7  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.6  2010/05/05 02:15:59  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.5  2010/05/04 23:14:32  mwvkm
 *  Made the application constant transient
 *
 *  Revision 1.4  2010/04/08 18:24:23  mwcsj3
 *  Cleaned up, removed all unused and redundant methods
 *
 *  Revision 1.3  2010/03/22 23:17:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/11 22:21:44  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.1  2010/02/26 17:34:25  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/11/02 21:19:02  mwsmg6
 *  Serailizable
 *
 *  Revision 1.4  2009/10/13 03:17:42  mwrrv2
 *  provided class description.
 *
 *  Revision 1.3  2009/10/07 19:16:34  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.2  2009/10/05 16:54:19  mwakg
 *  Removed use of TransformationType class
 *
 *  Revision 1.1  2009/10/03 20:56:42  mwpxp2
 *  Moved to .impl
 *
 *  Revision 1.5  2009/08/27 08:25:04  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.4  2009/08/11 02:22:38  mwpxp2
 *  Added logging; bulk cleanup; added javadoc,  fixed class header; added fixmes
 *
 */
