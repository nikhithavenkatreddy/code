/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

/**
 * Description: I am interface for class producing sample randomized payloads given a format
 * File: IPayloadSampleProducer.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPayloadSampleProducer {
	/**
	 * Creates the random correct payload using.
	 * 
	 * @param aFormat 
	 * 
	 * @return the string
	 */
	String createRandomCorrectPayloadUsing(IFieldFormat aFormat);

	/**
	 * Creates the random correct payload using.
	 * 
	 * @param aFormat 
	 * 
	 * @return the string
	 */
	String createRandomCorrectPayloadUsing(IMessageFormat aFormat);

	/**
	 * Creates the random incorrect payload using.
	 * 
	 * @param aFormat 
	 * 
	 * @return the string
	 */
	String createRandomIncorrectPayloadUsing(IFieldFormat aFormat);

	/**
	 * Creates the random incorrect payload using.
	 * 
	 * @param aFormat 
	 * 
	 * @return the string
	 */
	String createRandomIncorrectPayloadUsing(IMessageFormat aFormat);

	/**
	 * Creates the string not equal to.
	 * 
	 * @param allowedValue 
	 * 
	 * @return the string
	 */
	String createStringNotEqualTo(String allowedValue);
}
/**
 *  Modification History:
 *
 *  $Log: IPayloadSampleProducer.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/01 01:21:50  mwpxp2
 *  Renamed
 *
 *  Revision 1.1  2010/11/25 00:52:43  mwpxp2
 *  Initial
 *
 */
