/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process;

import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Description: I am interface for an object representing data related to the
 * user I do not depend on any business objects ...
 * 
 * File: IUserContext.java 
 * Module: gov.ca.dmv.ease.fw.user 
 * Created: Jul 9, 2009
 * @author MWPXP2
 * @version $Revision: 1.15 $ 
 * Last Changed: $Date: 2017/08/07 16:56:15 $ 
 * Last Changed By: $Author: mwwwc $
 */
public interface IUserContext extends IUserContextConstants, IValidatable,
		Serializable {
	/**
	 * Checks to see if the login office has employee with a specified ID.
	 *
	 * @param employeeId the employee id
	 * @return true, if successful
	 */
	boolean doesThisOfficeHasEmployeeWithId(String employeeId);

	/**
	 * Reset Issuance Role For Updated Issuance Office.
	 */
	void resetIssuanceRoleForUpdatedIssuanceOffice();

	/**
	 * @return a summary of the user context for logging purposes
	 */
	String logSummary();

	/**
	 * Gets the allowed ttc.
	 * 
	 * @return the allowed ttc
	 */
	List <String> getAllowedTtc();

	/**
	 * Gets the Control Cashier Sequence number for the current TTC after it is
	 * received from the Bridge Code.
	 * 
	 * @return the Control Cashier Sequence number
	 * @deprecated - control cashier sequence number should be retrieved from application object.
	 */
	@Deprecated
	Integer getControlCashierSeqNumber();

	/**
	 * DlaProcess sequence counter for counter mode.
	 * 
	 * @return increment
	 */
	int getDlaProcessSequenceCounterForCounterMode();

	/**
	 * Gets the functional mode. Operational mode includes: DL, VR, CC, Admin
	 * and Special Functions, Please refer to BRM for functional modes: NOTE -
	 * Functional Mode is also referenced by Process Context as Work Type
	 * 
	 * @return the modeII
	 */
	CodeSetElement getFunctionalMode();

	/**
	 * Gets the Ip Address.
	 * 
	 * @return the Ip Address
	 */
	String getIpAddress();

	/**
	 * Gets the location.
	 * 
	 * @return the location
	 */
	Location getLocation();

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();

	/**
	 * Gets the set of employee IDs in the login office.
	 *
	 * @return the office employee ids
	 */
	Set <String> getOfficeEmployeeIds();

	/**
	 * Gets the remote office id.
	 * 
	 * @return the remote office id
	 */
	String getRemoteOfficeId();

	/**
	 * Get Issuance Office Tech List.
	 *
	 * @return the issuance office tech list
	 */
	List <String> getIssuanceOfficeTechList();

	/**
	 * Gets the operational Mode. Operational mode includes: Counter, Postal, HQ
	 * and Travel Crew Modes
	 * 
	 * @return the operational mode.
	 */
	CodeSetElement getOperationalMode();

	/**
	 * Gets the racf id.
	 * 
	 * @return the racf id
	 */
	String getRacfId();

	/**
	 * Gets the role.
	 * 
	 * @return the role
	 */
	List <String> getRoles();

	/**
	 * Gets the Station Id.
	 * 
	 * @return the stationId
	 */
	public String getStationId();

	/**
	 * Gets the system start date for ttc.
	 * 
	 * @return the system start date for ttc
	 */
	Date getSystemStartDateForTtc();

	/**
	 * Gets the tech id.
	 * 
	 * @return the tech id
	 */
	String getTechId();

	/**
	 * Get the original technician id (Counter mode we need original tech id).
	 *
	 * @return the original office id
	 */
	String getOriginalOfficeId();

	/**
	 * Get the original technician id (Counter mode we need original tech id).
	 *
	 * @return the original tech id
	 */
	String getOriginalTechId();

	/**
	 * Get the host office id.
	 *
	 * @return the host office id
	 */
	public String getHostOfficeId();

	/**
	 * Gets the Type Transaction Code.
	 * 
	 * @return the Type Transaction Code
	 */
	String getTtc();

	/**
	 * Gets the Type Transaction Code Description.
	 * 
	 * @return the Type Transaction Code Description
	 */
	String getTtcDescription();

	/**
	 * Gets unique identifier for this user for use in searching for existing
	 * active sessions.
	 * 
	 * @return the unique identifier
	 */
	String getUniqueIdentifier();

	/**
	 * Gets the user name.
	 * 
	 * @return the user name
	 */
	String getUserName();

	/**
	 * Gets the work date.
	 * 
	 * @return the work date
	 */
	Date getWorkDate();

	/**
	 * Getter for Primary Printer Id.
	 *
	 * @return the primary printer id
	 */
	String getPrimaryPrinterId();

	/**
	 * Getter for Alternate Printer Id.
	 *
	 * @return the alternate printer id
	 */
	String getAlternatePrinterId();

	/**
	 * checks to see if the terminal the user is on has a camera station associated
	 * with it.
	 *
	 * @return true, if is camera station available
	 */
	boolean isCameraStationAvailable();

	/**
	 * Checks if is current mode is counter mode.
	 * 
	 * @return true, if is operation mode is counter.
	 */
	boolean isCurrentModeCounter();

	/**
	 * Checks if it is local inventory assigned.
	 * 
	 * @return true if local inventory assigned
	 */
	boolean isLocalInventoryAssigned();

	/**
	 * Checks if it is location authorized.
	 * 
	 * @return true if location authorized
	 */
	boolean isLocationAuthorized();

	/**
	 * Checks if is issuance office.
	 * 
	 * @return true, if is issuance office
	 */
	boolean isIssuanceOfficeOnly();

	/**
	 * Checks if it is Dl not update (for help desk operation).
	 *
	 * @return true, if is dl no update
	 */
	public boolean isDlNoUpdate();

	/**
	 * Sets the office employee ids.
	 *
	 * @param employeeIds the new office employee ids
	 */
	void setOfficeEmployeeIds(Set <String> employeeIds);

	/**
	 * Simple setter for the systemStartDateForTtc.
	 * 
	 * @param systemStartDateForTtc the systemStartDateForTtc to set
	 */
	void setSystemStartDateForTtc(Date systemStartDateForTtc);

	/**
	 * Validate using.
	 * 
	 * @param aCollector the a collector
	 */
	void validateUsing(IErrorCollector aCollector);

	/**
	 * Gets the authorized work dates.
	 * 
	 * @return the authorized work dates
	 */
	List <Date> getAuthdWorkDates();

	/**
	 * Sets the authorized work dates.
	 *
	 * @param authdDates the new authd work dates
	 */
	void setAuthdWorkDates(List <Date> authdDates);

	/**
	 * Sets location authorized.
	 * 
	 * @param locationAuthorized flag
	 */
	void setLocationAuthorized(boolean locationAuthorized);

	/**
	 * Checks if is mode manual.
	 * 
	 * @return true, if is operation mode is manual.
	 */
	boolean isModeManual();

	/**
	 * Checks if is mode travel.
	 * 
	 * @return true, if is operation mode is travel.
	 */
	boolean isModeTravel();

	/**
	 * Check if user is in Counter mode.
	 * 
	 * @return true, if is operation mode is manual.
	 */
	boolean isModeCounter();

	/**
	 *  Check if user is in Mail mode.
	 * 
	 * @return true, if is operation mode is travel.
	 */
	boolean isModeMail();

	/**
	 * Check if the user is APU.
	 *
	 * @return true, if is abstract processing unit
	 */
	public boolean isAbstractProcessingUnit();

	/**
	 * Get the original host office id.
	 *
	 * @return the original host office id
	 */
	public String getOriginalHostOfficeId();

	public boolean isCDLIS_52_Enabled();

	public boolean isCDLIS_52_10Q_Enabled();

	public boolean isCDLIS_52_Med_Enabled();

	/** Temporary solution for CDLIS 52 AC Gap Code*/
	public boolean isAcGapCodeEnabled();
	
	public boolean isIssuFlag();


	/**
	 * Check if VoterReg is enabled.  Returns true if enabled.
	 * It checks for the presence of the office id in the code
	 * set VOTER_REG_ENABLED_OFFICE.  The purpose is to an allow
	 * incremental deployment
	 *
	 * @param 
	 */
	boolean isVoterRegEnabled();
	
	/**
	 * Check if the field office is running AKTE. Returns true if enabled.
	 * It checks for the presence of the office id in the code
	 * set AKTE_ENABLED_OFFICE.  The purpose is to an allow
	 * incremental deployment
	 */
	public boolean isAkteEnabled(); 
}
/**
 * Modification History:
 * 
 * $Log: IUserContext.java,v $
 * Revision 1.15  2017/08/07 16:56:15  mwwwc
 * Merge AKTE changes from branch to Head.
 *
 * Revision 1.14.6.1  2017/05/24 17:01:18  mwwwc
 * Added back AKTE changes
 *
 * Revision 1.14  2016/02/18 20:17:49  mwskh1
 * Motor Voter - merge to head
 *
 * Revision 1.12.2.2  2016/02/09 22:01:16  mwskh1
 * Motor Voter - synch to EASE_2_5_3_1_AKTE_BKOUT (EASE_2_5_3_1 was backed out at management's request to roll back AKTE)
 *
 * Revision 1.12.2.1  2016/01/21 19:45:42  mwskh1
 * Motor Voter - Add new subprocess and ECS message with queue settings
 *
 * Revision 1.13  2016/01/21 23:42:08  mwwwc
 * Remove AKTE changes from HEAD.
 *
 * Revision 1.10.1  2015/09/24 23:13:37  mwwwc
 * AKTE Changes: Add isAkteEnabled() to check if office is running AKTE.
 * 
 * Revision 1.10  2015/06/12 22:35:55  mwnxg5
 * INV ISSU for EASE
 *
 * Revision 1.9  2013/12/02 21:00:40  mwlcr1
 * AB91 Clean up
 *
 * Revision 1.8  2013/10/03 14:57:45  mwskh1
 * CDLIS 5.2 - Code review changes
 *
 * Revision 1.7  2013/09/05 20:58:39  mwgxd3
 * AKTE II removed
 *
 * Revision 1.5  2013/09/03 17:56:33  mwsec2
 * Add logSummary
 *
 * Revision 1.4  2013/05/29 16:49:10  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.3.2.2  2013/04/09 16:05:44  mwskh1
 * CDLIS 5.2 -added med cert
 *
 * Revision 1.3.2.1  2013/03/28 18:46:55  mwgxd3
 * CDLIS - create stubs for CDLIS_ENABLED.
 *
 * Revision 1.3  2012/12/21 22:24:53  mwgxd3
 * AB91 Enabled Temp Solution
 *
 * Revision 1.2  2012/11/05 21:09:10  mwgxd3
 * AB91 - temporary solution change
 *
 * Revision 1.1  2012/10/01 02:57:27  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.51  2012/08/03 23:48:34  mwhys
 * Added getter/setter for officeEmployeeIds. (Defect 1429)
 *
 * Revision 1.50  2012/07/11 01:44:55  mwsxv5
 * Added new originalHostOfficeId to retain the original host office when user reset the mode.
 *
 * Revision 1.49  2012/07/10 17:40:59  mwxxw
 * Remove unused field: satelliteOfficeId.
 *
 * Revision 1.48  2012/06/15 17:24:42  mwxxw
 * Add logic for issuance office functionality.
 *
 * Revision 1.47  2012/05/17 23:37:39  mwxxw
 * Add new header name value pair: issuance.
 *
 * Revision 1.46  2012/04/24 23:12:26  mwxxw
 * Add new interface: public String getHostOfficeId();
 *
 * Revision 1.45  2012/01/11 00:02:58  mwxxw
 * Add new role for EASE: DL_APU.
 *
 * Revision 1.44  2011/10/25 00:23:52  mwxxw
 * Add new API: boolean bypassLegalPresence().
 *
 * Revision 1.43  2011/10/24 23:34:43  mwhys
 * Removed isIssuanceOffice()
 *
 * Revision 1.42  2011/10/12 20:57:19  mwkkc
 * Performance Merge
 *
 * Revision 1.39  2011/08/25 21:40:29  mwhxb3
 * Check if operating in mail mode or counter mode.
 *
 * Revision 1.38  2011/08/11 23:54:07  mwhxb3
 * Added methods :
 * 	1:isModeManual
 * 	2:isModeTravel
 *
 * Revision 1.37  2011/07/15 16:41:55  mwxxw
 * Add and initialize a new field: isDlNoUpdate.
 *
 * Revision 1.36  2011/05/06 17:33:45  mwkfh
 * added location info
 *
 * Revision 1.35  2011/05/05 16:30:03  mwkfh
 * added isLocalInventoryAssigned
 *
 * Revision 1.34  2011/04/26 20:55:21  mwrrv3
 * Updated to fix the defect# 3448.
 *
 * Revision 1.33  2011/02/14 18:12:22  mwrrv2
 * getControlCashierSeqNumber is deprecated
 *
 * Revision 1.32  2011/02/12 23:41:41  mwxxw
 * Add new IsOfficeIssuanceOnly() API.
 *
 * Revision 1.31  2011/01/19 00:20:42  mwxxw
 * Remove the following API:
 * isHQOffice()
 * isTelephoneServiceCenter()
 *
 * Revision 1.30  2010/12/29 18:54:08  mwrrv3
 * Added getOriginalTechId method.
 *
 * Revision 1.29  2010/12/09 23:56:46  mwxxw
 * Set the following attributes during the init of userContext.
 * private String stationId;
 * private String primaryPrinterId;
 * private String alternatePrinterId;
 *
 * Revision 1.28  2010/12/07 23:42:36  mwxxw
 * Add new field: isLocationAuthorized.
 *
 * Revision 1.27  2010/11/29 23:59:21  mwxxw
 * Add new field remoteOfficeId for location enforcement service.
 *
 * Revision 1.26  2010/10/20 23:52:54  mwazg5
 * Added getAuthdWorkDates and setAuthdWorkDates
 *
 * Revision 1.25  2010/09/13 04:39:49  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.24  2010/09/01 19:03:19  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.23  2010/08/16 19:18:45  mwkkc
 * Removed the temp setter for StartClock.
 *
 * Revision 1.22  2010/08/16 16:30:36  mwuxb
 * isTelephoneServiceCenter is added.
 *
 * Revision 1.21  2010/08/10 18:31:03  mwkkc
 * set the start clock time
 *
 * Revision 1.20  2010/08/05 22:35:21  mwcyl
 * add boolean method to determine if the users station is configured with  a camera  station
 *
 * Revision 1.19  2010/08/03 20:28:42  mwrrv2
 * Added isCurrentModeCounter() helper method to check if the current operation mode is counter or not.
 *
 * Revision 1.18  2010/07/09 22:34:09  mwtjc1
 * isHqOffice added
 *
 * Revision 1.17  2010/07/08 02:04:41  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.16  2010/06/25 21:16:43  mwtjc1
 * isIssuanceOffice added
 *
 * Revision 1.15  2010/06/21 21:57:08  mwvkm
 * systemStartDateForTtc is added in the UserContext in order to track the start time at the begining of TTC
 *
 * Revision 1.14  2010/05/19 21:31:13  mwrpk
 * Code clean up
 *
 * Revision 1.13  2010/05/10 22:15:41  mwrpk
 * SLTT -- adding Role and Available TTC a user can have
 * Revision 1.12 2010/05/04 00:55:19 mwpxp2 Bulk
 * cleanup
 * 
 * Revision 1.11 2010/04/26 20:29:06 mwuxb Added getStationId ()
 * 
 * Revision 1.10 2010/04/22 19:25:05 mwpxp2 Bulk cleanup
 * 
 * Revision 1.9 2010/04/01 22:56:28 mwvxm6 Added Control Cashier Sequence number
 * for the current TTC which is required by the converters. Update type to
 * Integer
 * 
 * Revision 1.8 2010/03/29 16:16:19 mwbxp5 Changed names of methods form
 * getmodeI and getModeII to getOperationalMode and getFunctionalMode.
 * 
 * Revision 1.7 2010/03/29 16:13:19 mwbxp5 Changed names of methods form
 * getmodeI and getModeII to getOperationalMode and getFunctionalMode. Revision
 * 1.6 2010/03/29 16:06:21 mwbxp5 Changed names of methods form getmodeI and
 * getModeII to getOperationalMode and getFunctionalMode. Revision 1.5
 * 2010/03/22 23:32:50 mwpxp2 Javadoc/cleanup
 * 
 * Revision 1.4 2010/03/17 00:25:58 mwhxa2 Added getMode1() and getMode2()
 * 
 * Revision 1.3 2010/03/17 00:22:15 mwhxa2 Added getMode1() and getMode2()
 * 
 * Revision 1.2 2010/02/02 03:21:39 mwrrv3 Added IP address functionality to
 * support back-end.
 * 
 * Revision 1.1 2009/11/23 16:22:52 mwrsk Intial commit
 * 
 * Revision 1.2 2009/10/06 18:46:16 mwpxp2 Removed obsolete todo
 * 
 * Revision 1.1 2009/10/03 20:23:26 mwpxp2 Moved into fw.process; bulk cleanup
 * 
 * Revision 1.8 2009/09/24 02:24:46 mwhxa2 Added IValidatable
 * 
 * Revision 1.7 2009/09/23 22:17:36 mwakg Fixed Sequence number for DL when in
 * Counter mode
 * 
 * Revision 1.6 2009/09/22 23:47:55 mwjjl7 add method to return unique
 * identifier for user
 * 
 * Revision 1.5 2009/09/22 01:10:48 mwbxp5 Added "Mode"
 * 
 * Revision 1.4 2009/09/12 22:20:42 mwbvc added ttc description
 * 
 * Revision 1.3 2009/09/10 21:31:36 mwpxp2 Added copyright notice
 * 
 * Revision 1.2 2009/09/10 21:29:01 mwpxp2 Added IUserContextConstants as super
 * interface
 * 
 * Revision 1.1 2009/08/27 02:24:38 mwsmg6 moved framework-related classes to
 * the Framework project
 * 
 * Revision 1.5 2009/08/19 23:40:09 mwakg Refactored ttc from string to
 * TypeTransactionCode class
 * 
 * Revision 1.4 2009/07/27 18:17:56 mwpxp2 Added file footer
 * 
 */
