/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.ecs.request.impl.AsynchronousEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponsePromise;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.util.Date;

/**
 * Description: I am implementation of IEcsResponsePromise, 
 * I can be used as a request to obtain an asynchronous response.
 * File: AysnchronousResponsePromise.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: Mar 18, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AsynchronousResponsePromise extends AbstractAsynchronousResponse
		implements IEcsResponsePromise {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1959879806823391466L;
	/** The sent request id. */
	private String sentRequestId;

	/**
	 * Instantiates a new asynchronous response promise.
	 */
	protected AsynchronousResponsePromise() {
		super();
	}

	/**
	 * Instantiates a new asynchronous response promise.
	 * 
	 * @param asynchRequest the asynchronous request
	 */
	public AsynchronousResponsePromise(AsynchronousEcsRequest asynchRequest) {
		super();
		setSentRequestId(asynchRequest.getRequestId());
		setExpirationTimestamp(asynchRequest.getAbsoluteExpirationTime());
	}

	/**
	 * Instantiates a new asynchronous response promise.
	 * 
	 * @param asynchRequest the asynchronous request
	 */
	public AsynchronousResponsePromise(AsynchronousEcsRequest asynchRequest,
			String aCorrelationId) {
		super();
		setSentRequestId(asynchRequest.getRequestId());
		setExpirationTimestamp(asynchRequest.getAbsoluteExpirationTime());
		setCorrelationId(aCorrelationId);
	}

	/**
	 * Instantiates a new asynchronous response promise.
	 * 
	 * @param error collector
	 */
	public AsynchronousResponsePromise(IErrorCollector errorCollector) {
		super(errorCollector);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractAsynchronousResponse#getAbsoluteExpirationTimestamp()
	 */
	@Override
	public long getAbsoluteExpirationTimestamp() {
		return absoluteExpirationTimestamp;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getExpirationTime()
	 */
	public long getExpirationTime() {
		long returnlong = getAbsoluteExpirationTimestamp();
		return returnlong;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#getResponseId()
	 */
	@Override
	public String getResponseId() {
		return sentRequestId;
	}

	/**
	 * Gets the sent request id.
	 * 
	 * @return sentRequestId the sent request id
	 */
	public String getSentRequestId() {
		return sentRequestId;
	}

	/**
	 * Checks for expiration stamp.
	 * 
	 * @return returnboolean returns true, if successful
	 */
	public boolean hasExpirationStamp() {
		boolean returnboolean = absoluteExpirationTimestamp != UNDEF_EXPIRATION;
		return returnboolean;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractAsynchronousResponse#hasTimedOut()
	 */
	@Override
	public boolean hasTimedOut() {
		boolean returnboolean = (new Date()).getTime() > getAbsoluteExpirationTimestamp();
		return returnboolean;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#isAsynchronousPromise()
	 */
	@Override
	public final boolean isAsynchronousPromise() {
		return true;
	}

	/**
	 * Sets the expiration time.
	 * 
	 * @param absoluteExpirationTimestamp the new expiration time
	 */
	public void setExpirationTime(long aLongTime) {
		absoluteExpirationTimestamp = aLongTime;
	}

	/**
	 * Sets the expiration timestamp.
	 * 
	 * @param aMsecTimestamp the new expiration timestamp
	 */
	protected void setExpirationTimestamp(long aMsecTimestamp) {
		absoluteExpirationTimestamp = aMsecTimestamp;
	}

	/**
	 * Sets the sent request id.
	 * 
	 * @param aRequestId the a request id
	 */
	protected void setSentRequestId(String aRequestId) {
		sentRequestId = aRequestId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("sentRequestId", sentRequestId, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AsynchronousResponsePromise.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.3  2010/11/09 04:34:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/09/24 00:21:29  mwpxr4
 *  Added constructor with error collector
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.13  2009/10/14 21:00:58  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.12  2009/10/14 18:08:33  mwhxb3
 *  updated comments
 *
 *  Revision 1.11  2009/10/07 03:34:19  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.10  2009/10/07 02:57:54  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.9  2009/10/06 21:54:08  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.8.8.2  2009/10/06 20:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.8.8.1  2009/10/06 20:28:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.8  2009/08/21 01:18:07  mwpxp2
 *  Added 2-arg constructor using correlation id
 *
 *  Revision 1.7  2009/08/10 22:51:52  mwpxp2
 *  Added logging
 *
 *  Revision 1.6  2009/08/05 01:43:25  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2009/08/05 01:27:44  mwpxp2
 *  Refactored with super
 *
 *  Revision 1.4  2009/07/28 00:06:43  mwpxp2
 *  Cleanup
 *
 *  Revision 1.3  2009/07/27 18:49:39  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/27 18:30:39  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
