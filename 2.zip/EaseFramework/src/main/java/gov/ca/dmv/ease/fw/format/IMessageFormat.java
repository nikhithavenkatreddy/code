/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I describe a format of (simple) messages 
 * File: IMessageFormat.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageFormat extends ISampleProvider, IValidationProvider,
		Serializable {
	/**
	 * Adds the.
	 * 
	 * @param aField 
	 * 
	 * @return the i message format
	 */
	IMessageFormat add(IFieldFormat aField);

	/**
	 * As pattern string.
	 * 
	 * @return the string
	 */
	String asPatternString();

	/**
	 * Gets the fields.
	 * 
	 * @return the fields
	 */
	List <IFieldFormat> getFields();

	/**
	 * Gets the end pos.
	 * 
	 * @return the end pos
	 */
	int getLength();

	/**
	 * Gets the message name.
	 * 
	 * @return the message name
	 */
	String getMessageName();

	/**
	 * Parses the payload.
	 * 
	 * @param aMessagePayload 
	 * 
	 * @return the string
	 */
	String parsePayload(String aMessagePayload);

	/**
	 * Parses the payload.
	 * 
	 * @param aMessagePayload 
	 * @param aBuilder 
	 */
	void parsePayload(String aMessagePayload, StringBuilder aBuilder);
}
/**
 *  Modification History:
 *
 *  $Log: IMessageFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2010/12/16 03:18:29  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.5  2010/12/01 01:22:24  mwpxp2
 *  Added super interfaces
 *
 *  Revision 1.4  2010/11/25 00:52:31  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.3  2010/11/24 20:39:18  mwpxp2
 *  Added getMessageName/0
 *
 *  Revision 1.2  2010/11/20 23:07:47  mwpxp2
 *  Added getEndPos/0, asPatternString
 *
 *  Revision 1.1  2010/11/20 21:20:17  mwpxp2
 *  Initial
 *
 */
