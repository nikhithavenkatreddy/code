/**
 * 
 */
package gov.ca.dmv.ease.date.impl;

import java.util.Calendar;
import java.util.Date;


/**
 * Description: Provides date utility methods based on the 'current date' as provided by CurrentDateProvider.
 * File: CurrentDateUtil.java
 * Module:  gov.ca.dmv.ease.date.impl
 * Created: Jan 13, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CurrentDateUtil {
	
	/** The Constant DAYS_00. */
	private static final int DAYS_00 = 00;
	/** The Constant MONTHS_00. */
	private static final int MONTHS_00 = 00;
	/** The Constant YEARS_18. */
	private static final int YEARS_18 = 18;
	
	/**
	 * This method checks if the applicant is above 18 years old, compared to current date
	 * as provided by CurrentDateProvider.
	 *
	 * @param birthdate the birthdate
	 * @return true, if is 18 years old
	 */
	public static boolean is18YearsOld(Date birthDate) {
		Date currentDate = CurrentDateProvider.getInstance()
								.getCurrentDate();
		Date birthday18 = addToSpecifiedDate(birthDate, YEARS_18,
				MONTHS_00, DAYS_00);
		return currentDate.after(birthday18);
	}
	
	/**
	 * This method checks if the applicant is under 18 years old
	 *
	 * @param birthdate the birthdate
	 * @return true, if is 18 years old
	 */
	public static boolean isMinor(Date birthDate){
		return !is18YearsOld(birthDate);
	}
	public static final Date addToSpecifiedDate(Date referenceDate, int year,
			int month, int day) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(referenceDate);
		calendar.add(Calendar.YEAR, year);
		calendar.add(Calendar.MONTH, month);
		calendar.add(Calendar.DATE, day);
		return calendar.getTime();
	}
	
	public static int getAge(Date dateOfBirth) {
	    int age = 0;
	    Calendar born = Calendar.getInstance();
	    Calendar now = Calendar.getInstance();
	    if(dateOfBirth!= null) {
	        now.setTime(CurrentDateProvider.getInstance()
	        					.getCurrentDate());
	        born.setTime(dateOfBirth);  
	        if(born.after(now)) {
	            throw new IllegalArgumentException("Can't be born in the future");
	        }
	        age = now.get(Calendar.YEAR) - born.get(Calendar.YEAR);             
	        if(now.get(Calendar.DAY_OF_YEAR) < born.get(Calendar.DAY_OF_YEAR))  {
	            age-=1;
	        }
	    }  
	    return age;
	}

	
}


/**
 *  Modification History:
 *
 *  $Log: CurrentDateUtil.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/04/17 22:26:37  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/03/29 18:49:37  mwgxd3
 *  update basic provisional
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:08  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */