/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.ecs.exception.impl.EcsResponseIsNullException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponse;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.exception.impl.SystemException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.IResponsePromise;

/**
 * Description: I am a request to cash on a IEcsResponsePromise.
 * File: CashPromiseRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request.impl
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CashPromiseRequest extends AbstractEcsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7854551619124376973L;
	/** The promise. */
	private IResponsePromise promise;

	/**
	 * Instantiates a new cash promise request.
	 */
	protected CashPromiseRequest() {
		super();
	}

	/**
	 * Instantiates a new cash promise request.
	 * 
	 * @param aPromise the a promise
	 */
	public CashPromiseRequest(IResponsePromise aPromise,
			IUserContext userContext) {
		super(userContext);
		setPromise(aPromise);
	}

	/**
	 * Instantiates a new cash promise request.
	 * 
	 * @param anId the an id
	 */
	public CashPromiseRequest(String anId) {
		super(anId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public IEcsResponse execute() throws EcsServiceException {
		AsynchronousResponse returnAsynchronousResponse = null;
		try {
			returnAsynchronousResponse = (AsynchronousResponse) getEcsService()
					.processRequest(this);
		}
		catch (EcsResponseIsNullException responseIsNullException) {
			returnAsynchronousResponse.getErrorCollector().register(
					new EaseValidationException(CNA_SHORT_TERM_MESSAGE));
		}
		catch (SystemException sysEx) {
			returnAsynchronousResponse.getErrorCollector().register(
					new EaseValidationException(RESOURCE_PROBLEM_MESSAGE));
		}
		return returnAsynchronousResponse;
	}

	/**
	 * Gets the promise.
	 * 
	 * @return the promise
	 */
	public IResponsePromise getPromise() {
		return promise;
	}

	/**
	 * Sets the promise.
	 * 
	 * @param aPromise the new promise
	 */
	protected void setPromise(IResponsePromise aPromise) {
		promise = aPromise;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CashPromiseRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2010/10/27 00:50:04  mwhys
 *  Added try-catch block around getEcsService().processRequest(this) call.
 *
 *  Revision 1.7  2010/10/21 21:28:42  mwpxr4
 *  UserContext set in constructor, this is to fix nullpointer in Aspects invoked in CDLIS/PDPS flow.
 *
 *  Revision 1.6  2010/09/22 18:00:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/09/21 18:51:26  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< CashPromiseRequest.java
 *  Revision 1.4  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
=======
 *  Revision 1.3.4.2  2010/09/18 23:07:55  mwpxr4
 *  Typecasted concrete classes
 *
 *  Revision 1.3.4.1  2010/09/14 22:13:09  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.4  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
>>>>>>> 1.3.4.2
 *  Revision 1.3  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/03/22 23:27:03  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.22  2009/11/05 00:36:22  mwhxb3
 *  removed unnecessary testValidator() method
 *
 *  Revision 1.21  2009/10/14 20:47:08  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.20  2009/10/13 21:01:49  mwhxb3
 *  updated comments.
 *
 *  Revision 1.19  2009/10/07 19:28:43  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.18  2009/10/07 14:32:20  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.17  2009/10/07 03:33:43  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.16  2009/10/07 02:56:48  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.15  2009/10/06 21:53:05  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.14.2.2  2009/10/06 20:41:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.14.2.1  2009/10/06 20:28:40  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.14  2009/10/03 21:23:37  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.13  2009/08/27 05:54:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.12  2009/08/27 02:33:54  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.11  2009/08/26 01:59:52  mwpxp2
 *  Replaced IEcsResponsePromise with IResponsePromise
 *
 *  Revision 1.10  2009/08/25 22:35:29  mwcsj3
 *  Changed IResponsePromise to AsynchronousResponsePromise
 *
 *  Revision 1.9  2009/08/22 20:30:04  mwpxp2
 *  Cleanup
 *
 *  Revision 1.8  2009/08/17 23:42:53  mwpxp2
 *  bulk cleanup
 *
 *  Revision 1.7  2009/08/13 02:56:35  mwpzs3
 *  Asynchronous message handling
 *
 *  Revision 1.6  2009/08/10 23:05:46  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.5  2009/07/27 18:48:50  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.4  2009/07/16 02:17:52  mwpxp2
 *  Removed empty getUserContext method
 *
 *  Revision 1.3  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.5  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.4  2009-05-17 05:28:09  ppalacz
 *  Imports cleanup
 *
 *  Revision 1.3  2009-05-15 13:14:52  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.2  2009-05-14 21:46:24  ppalacz
 *  Fixed visibiity of constructor/1 to public
 *
 *  Revision 1.1  2009-05-12 22:20:14  ppalacz
 *  Initial
 *
*/
