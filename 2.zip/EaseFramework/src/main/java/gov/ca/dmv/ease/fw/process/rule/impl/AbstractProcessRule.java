/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process.rule.impl;

import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.rule.IProcessRuleValidation;
import gov.ca.dmv.ease.fw.rule.exception.impl.RuleArgumentsValidationException;
import gov.ca.dmv.ease.fw.rule.exception.impl.RuleNotApplicableException;

/**
 * Description: I am abstract implementation of IProcessRuleValidation
 * File: AbstractProcessRule.java
 * Module:  gov.ca.dmv.ease.fw.process.rule
 * Created: Jan 21, 2011
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractProcessRule implements IProcessRuleValidation {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2595488113977368342L;

	/**
	 * Instantiates a new abstract process rule.
	 */
	protected AbstractProcessRule() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.rule.IProcessRuleValidation#isApplicableTo(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public abstract boolean isApplicableTo(IProcessContext processContext);

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public final String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		//		try {
		//			StringBuilder aBuilder = new StringBuilder(2048);
		//			aBuilder.append(getClass().getSimpleName()).append(" [");
		//			toStringOn(aBuilder, 1);
		//			aBuilder.append("\n]");
		//			return aBuilder.toString();
		//		}
		//		catch (Exception e) {
		return simpleToString();
		//		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#toStringOn(java.lang.StringBuilder, int)
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		//		outputKeyValue("parentProcessContext", parent, anIndent, aBuilder);
		//		outputKeyValue("syncPointSubprocessActivity",
		//				syncPointSubprocessActivity, anIndent, aBuilder);
		//super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.rule.IProcessRuleValidation#validateArguments(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public void validateArguments(IProcessContext processContext) {
		if (processContext == null) {
			throw new RuleArgumentsValidationException(
					"null porcess context not allowed");
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.process.rule.IProcessRuleValidation#validateIfApplicable(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public void validateIfApplicable(IProcessContext processContext) {
		if (!isApplicableTo(processContext)) {
			throw new RuleNotApplicableException("Rule: " + this
					+ " is not applicable to: " + processContext);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractProcessRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:20  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2011/02/04 02:20:12  mwpxp2
 *  Simplified toString/0
 *
 *  Revision 1.4  2011/02/04 01:21:19  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.3  2011/01/22 00:02:55  mwpxp2
 *  Made validateIfApplicable abstract, and isApplicable/1 concrete
 *
 *  Revision 1.2  2011/01/21 23:37:16  mwpxp2
 *  Parameter/imports cleanup for passing collector and context by interface
 *
 *  Revision 1.1  2011/01/21 23:13:31  mwpxp2
 *  Initial
 *
 */
