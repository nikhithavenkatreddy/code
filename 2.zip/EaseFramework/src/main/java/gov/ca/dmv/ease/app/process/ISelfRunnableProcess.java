/**
 * 
 */
package gov.ca.dmv.ease.app.process;


/**
 * Description: Interface for self-runnable business processes (independent of web container)
 * 
 * File: ISelfRunnableBusinessProcess.java
 * Module:  gov.ca.dmv.ease.app.process
 * Created: May 31, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISelfRunnableProcess {
	/**
	 * Run the business process
	 */
	void run();
}

/**
 *  Modification History:
 *
 *  $$Log: ISelfRunnableProcess.java,v $
 *  $Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.2  2012/06/08 17:19:38  mwsec2
 *  $initial check-in of classes to support the running of business processes outside an HTTP session context
 *  $$
 */
