/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service;

import gov.ca.dmv.ease.tus.persist.request.impl.CashierTransactionIdRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleDeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleInsertOrUpdateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleRetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.PurgeTableRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveAllBusinessObjectsRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveInventoryItemAndUpdateAsIssuedRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SaveOrUpdateBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.CashierTransactionIdResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleDeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleInsertOrUpdateResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleRetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PurgeTableResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveAllBusinessObjectsResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveCriteriaObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveInventoryItemAndUpdateAsIssuedResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SaveOrUpdateBusinessObjectResponse;

/**
 * Description: I am the interface to persistence service. 
 * 
 * File: IPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service
 * Created: Jul 25, 2009 
 * @author MWAKG  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:07 $
 * Last Changed By: $Author: mwkfh $
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:07 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IPersistenceService {
	/**
	 * Starts the transaction
	 */
	void beginTransaction();

	/**
	 * Commits the transaction
	 */
	void commitTransaction();

	/**
	 * Execute.
	 * 
	 * @param cashierTransactionIdRequest 
	 * 
	 * @return the cashier transaction id response
	 */
	CashierTransactionIdResponse execute(
			CashierTransactionIdRequest cashierTransactionIdRequest);

	/**
	 * This method deletes the domain object from the database.
	 * 
	 * @param request Request containing the domain object to be deleted
	 * 
	 * @return Response containing status of the deletion operation
	 */
	DeleteBusinessObjectResponse execute(DeleteBusinessObjectRequest request);

	/**
	 * This method deletes the domain objects from the database.
	 * 
	 * @param request Request containing the domain objects to be deleted
	 * 
	 * @return Response containing status of the deletion operation
	 */
	MultipleDeleteBusinessObjectResponse execute(
			MultipleDeleteBusinessObjectRequest request);

	/**
	 * Execute.
	 * 
	 * @param multipleInsertOrUpdateRequest the multiple insert or update request
	 * 
	 * @return the persistence service response
	 */
	MultipleInsertOrUpdateResponse execute(
			MultipleInsertOrUpdateRequest multipleInsertOrUpdateRequest);

	/**
	 * Execute.
	 * 
	 * @param multipleRetrieveBusinessObjectRequest the multiple retrieve request
	 * 
	 * @return the persistence service response
	 */
	MultipleRetrieveBusinessObjectResponse execute(
			MultipleRetrieveBusinessObjectRequest multipleRetrieveBusinessObjectRequest);

	/**
	 * This method purges the table records relating to the class from the database.
	 * 
	 * @param request
	 *            Request containing the table class to be purged
	 * 
	 * @return Response containing status of the purge operation
	 */
	PurgeTableResponse execute(PurgeTableRequest request);

	/**
	 * This method returns all the instances of a domain object.
	 * 
	 * @param request Request object containing the domain object class
	 * 
	 * @return Response object containing the instances of domain object
	 */
	RetrieveAllBusinessObjectsResponse execute(
			RetrieveAllBusinessObjectsRequest request);

	/**
	 * This method saves all the data required by the downstream functions into the persistence storage.
	 * 
	 * @param request Request containing the transformed data
	 * 
	 * @return Response containing the status of the operation
	 */
	//public SaveAllTransformationsResponse execute(SaveAllTransformationsRequest request);
	/**
	 * This method retrieves the domain objects from the database based on the request object
	 * This method uses Query by example pattern of hibernate.
	 * 
	 * @param request Request containing the parameters requiring for retrieving a domain object
	 * 
	 * @return Response containing the retrieved domain object
	 */
	RetrieveBusinessObjectResponse execute(RetrieveBusinessObjectRequest request);

	/**
	 * This method retrieves the hibernate framework's criteria instance based on the 
	 * RetrieveCriteriaObjectRequest instance.
	 * @param request Request object containing the class on which criteria needs to be created
	 * @return Response containing criteria instance
	 */
	RetrieveCriteriaObjectResponse execute(RetrieveCriteriaObjectRequest request);

	/**
	 * Retrieve an unused DL inventory item from the persistent store and update
	 * the issued status to true;
	 * 
	 * @param request the request
	 * 
	 * @return the persistence service response containing the inventory item issued
	 */
	RetrieveInventoryItemAndUpdateAsIssuedResponse execute(
			RetrieveInventoryItemAndUpdateAsIssuedRequest request);

	/**
	 * This method saves or updates the complete domain object and its children.
	 * 
	 * @param request Request object containing the domain object to be saved or updated
	 * 
	 * @return Response containing the status of execution of the request  
	 */
	SaveOrUpdateBusinessObjectResponse execute(
			SaveOrUpdateBusinessObjectRequest request);

	/**
	 * rolls back the transaction
	 */
	void rollbackTransaction();
}
/**
 *  Modification History:
 *
 *  $Log: IPersistenceService.java,v $
 *  Revision 1.2  2012/10/23 23:39:07  mwkfh
 *  added execute(PurgeTableRequest)
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/08/08 20:08:55  mwkfh
 *  removed execute(CurrentDateRequest)
 *
 *  Revision 1.15  2010/12/28 21:32:17  mwkfh
 *  updated RetrieveCriteriaObjectRequest to handle transaction outside of persistence service
 *
 *  Revision 1.14  2010/12/16 19:50:44  mwpxp2
 *  Added execute(CurrentDateRequest currentDateRequest)
 *
 *  Revision 1.13  2010/12/15 03:01:23  mwpxp2
 *  Added execute on CashierTransactionIdRequest
 *
 *  Revision 1.12  2010/10/06 16:32:41  mwkfh
 *  added MultipleRetrieveBusinessObject...
 *
 *  Revision 1.11  2010/09/21 21:37:38  mwpxr4
 *  Removed duplicate method deleting multiple business objects.
 *
 *  Revision 1.10  2010/09/21 19:36:15  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.9  2010/09/15 18:04:02  mwkfh
 *  added MultipleDeleteBusinessObjects
 *
 *  Revision 1.8.4.1  2010/09/14 17:38:57  mwpxr4
 *  Added code to delete the processed payloads for a promise.
 *
 *  Revision 1.8  2010/09/13 16:52:14  mwkfh
 *  removed SeedPersistence for inventory
 *
 *  Revision 1.7  2010/09/09 22:04:25  mwkfh
 *  updated responses for new methods
 *
 *  Revision 1.6  2010/09/01 20:00:52  mwpxp2
 *  Added support for SeedPersistenceRequest and MultipleInsertOrUpdateRequest
 *
 *  Revision 1.5  2010/07/23 23:11:56  mwkfh
 *  removed outdated ProcessContext persistence
 *
 *  Revision 1.4  2010/04/22 19:26:13  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/03/23 21:14:55  mwyxg1
 *  add criteria support
 *
 *  Revision 1.2  2010/03/22 23:39:08  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.15  2009/10/13 21:00:33  mwrsk
 *  Remove access modifiers
 *
 *  Revision 1.14  2009/10/07 21:09:31  mwrsk
 *  Deleted LoggingRequest.java
 *
 *  Revision 1.13  2009/10/03 21:32:49  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.12  2009/09/03 22:50:42  mwrsk
 *  code cleanup
 *
 *  Revision 1.11  2009/09/03 22:49:29  mwrsk
 *  Delete save business object request
 *
 *  Revision 1.10  2009/08/31 01:23:54  mwrsk
 *  Added SaveBusinessObject functionality
 *
 *  Revision 1.9  2009/08/29 00:06:04  mwrsk
 *  Refactor SaveBusinessObject request to SaveOrUpdate....
 *
 *  Revision 1.8  2009/08/28 23:34:44  mwrsk
 *  Refactor SaveBusinessObject request to SaveOrUpdate
 *
 *  Revision 1.7  2009/08/27 06:29:26  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.6  2009/08/25 16:34:20  mwrsk
 *  Changed the request name to RetrieveInventoryItemAndUpdateAsIssuedRequest
 *
 *  Revision 1.5  2009/08/25 16:05:41  mwrsk
 *  Updated to retrieve anyInventoryItem
 *
 *  Revision 1.4  2009/08/25 01:56:34  mwrsk
 *  Added new API for retrieving DL Inventory Item
 *
 *  Revision 1.3  2009/08/21 00:47:35  mwsxd10
 *  execute() method added for processing LoggingRequest.
 *
 *  Revision 1.2  2009/08/13 03:22:01  mwrsk
 *  Remove transaction service related request
 *
 *  Revision 1.1  2009/07/29 16:57:00  mwakg
 *  Changed the design of persistence service hence refractored code accordingly
 *
 */
