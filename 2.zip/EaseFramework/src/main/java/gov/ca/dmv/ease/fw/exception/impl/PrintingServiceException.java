/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am superclass for exceptions coming from Printing Service(s)
 * File: PrintingServiceException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Aug 27, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class PrintingServiceException extends
		EaseServiceLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9051729074695547142L;

	/**
	 * Instantiates a new printing service exception.
	 */
	public PrintingServiceException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public PrintingServiceException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public PrintingServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public PrintingServiceException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PrintingServiceException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/08/27 16:51:21  mwpxp2
 *  Initial
 *
 */
