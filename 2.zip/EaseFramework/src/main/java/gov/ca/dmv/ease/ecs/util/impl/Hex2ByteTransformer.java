/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.util.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.UnsupportedEncodingException;

/**
 * Description: Utility to convert Hex to ASCII.
 * File: Hex2ByteTransformerUtil.java
 * Module:  gov.ca.dmv.ease.ecs.util.impl
 * Created: Aug 5, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Hex2ByteTransformer {
	/**
	 * Converts ASCII texts to Hexadecimal.
	 * @param ascii the ASCII String
	 * @return the Hexadecimal String
	 */
	public static String asciiToHex(String ascii) {
		StringBuilder hex = new StringBuilder();
		for (int i = 0; i < ascii.length(); i++) {
			hex.append(Integer.toHexString(ascii.charAt(i)));
		}
		return hex.toString();
	}

	/**
	 * Converts Hexadecimal String.
	 * @param hexString the hexadecimal string
	 * @param length the length
	 * @param buffer the buffer
	 * @param evenByte the even bytes
	 * @param nextByte the next byte
	 * @param bufferOffset the buffer offset
	 */
	private static void convertHex(String hexString, int length, byte[] buffer,
			boolean evenByte, byte nextByte, int bufferOffset) {
		if ((length % 2) == 1) {
			evenByte = false;
		}
		for (int i = 0; i < length; i++) {
			char c = hexString.charAt(i);
			int nibble;
			if ((c >= '0') && (c <= '9')) {
				nibble = c - '0';
			}
			else if ((c >= 'A') && (c <= 'F')) {
				nibble = c - 'A' + 0x0A;
			}
			else if ((c >= 'a') && (c <= 'f')) {
				nibble = c - 'a' + 0x0A;
			}
			else {
				throw new NumberFormatException("Invalid hex digit '" + c
						+ "'.");
			}
			if (evenByte) {
				nextByte = (byte) (nibble << 4);
			}
			else {
				nextByte += (byte) nibble;
				buffer[bufferOffset++] = nextByte;
			}
			evenByte = !evenByte;
		}
	}

	/**
	 * Converts EBCIDIC To Hexadecimal.
	 * @param ascii the ASCII String.
	 * @return the EBCIDIC String
	 */
	public static String ebcidicToHex(String ascii) {
		StringBuilder hex = new StringBuilder();
		String ebcidic = null;
		try {
			ebcidic = new String(ascii.getBytes("Cp1047"));
		}
		catch (UnsupportedEncodingException e1) {
			throw new EaseValidationException(e1);
			//			e1.printStackTrace();
		}
		//		byte[] bytes = ascii.getBytes();
		//		try {
		//			ebcidic = new String(bytes, "Cp1047");
		//		} catch (UnsupportedEncodingException e) {
		//			e.printStackTrace();
		//		}
		for (int i = 0; i < ebcidic.length(); i++) {
			hex.append(Integer.toHexString(ebcidic.charAt(i)));
		}
		return hex.toString();
	}

	/**
	 * Converts Hexadecimal to String.
	 * @param hexString the Hexadecimal String
	 * @return tranMsg the converted message String
	 */
	public static String transform(String hexString) {
		int length = hexString.length();
		byte[] buffer = new byte[(length + 1) / 2];
		boolean evenByte = true;
		byte nextByte = 0;
		int bufferOffset = 0;
		try {
			convertHex(hexString, length, buffer, evenByte, nextByte,
					bufferOffset);
			//String tranMsg = new String(new String(buffer, "Cp1047").getBytes("8859_1"));
			String tranMsg = new String(buffer);
			return tranMsg;
		}
		catch (NumberFormatException e) {
			throw new EaseValidationException(e);
			//			e.printStackTrace();
			//			return null;
		}
	}

	/**
	 * Transforms from EBCIDIC.
	 * @param hexString the hexadecimal string
	 * @return tranMsg the transformed message.
	 */
	public static String transformFromEbcidic(String hexString) {
		int length = hexString.length();
		byte[] buffer = new byte[(length + 1) / 2];
		boolean evenByte = true;
		byte nextByte = 0;
		int bufferOffset = 0;
		try {
			convertHex(hexString, length, buffer, evenByte, nextByte,
					bufferOffset);
			String tranMsg = new String(new String(buffer, "Cp1047")
					.getBytes("8859_1"));
			//String tranMsg = new String(buffer);
			return tranMsg;
		}
		catch (NumberFormatException e) {
			throw new EaseValidationException(e);
			//			e.printStackTrace();
			//			return null;
		}
		catch (UnsupportedEncodingException e) {
			throw new EaseValidationException(e);
			//			e.printStackTrace();
			//			return null;
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Hex2ByteTransformer.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:27:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.14  2009/10/14 17:22:24  mwhxb3
 *  updated comments
 *
 *  Revision 1.13  2009/10/08 20:27:15  mwpzs3
 *  cpd refactor
 *
 *  Revision 1.12  2009/10/03 21:23:41  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/09/03 20:31:08  mwpxp2
 *  Replaced printStackTrace with EaseValidationException
 *
 *  Revision 1.10  2009/09/03 00:53:12  mwhxb3
 *  removed the decodeHexString method, similar functionality provided by the transform method
 *
 *  Revision 1.9  2009/09/01 00:30:48  mwpzs3
 *  3270 Convertor initial version
 *
 *  Revision 1.8  2009/08/27 05:54:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2009/08/27 01:00:23  mwpzs3
 *  EBCIDIC transform
 *
 *  Revision 1.6  2009/08/19 03:01:04  mwpzs3
 *  Correlation in synchronous
 *
 *  Revision 1.5  2009/08/10 23:10:07  mwpxp2
 *  Cleanup
 *
 *  Revision 1.4  2009/08/05 20:52:59  mwpzs3
 *  Non ascii convertor
 *
 *  Revision 1.3  2009/08/05 19:55:13  mwhxb3
 *  added method for ASCII Hex string to character conversion
 *
 *  Revision 1.2  2009/08/05 18:25:58  mwpzs3
 *  change comment
 *
 *  Revision 1.1  2009/08/05 18:23:59  mwpzs3
 *  util class for converting hex to ascii
 *
 */
