/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: I define the interface to PersistenceServiceRequest
 * 
 * File: DeleteSessionResponse.java
 * Module:  gov.ca.dmv.ease.app.session.response.impl
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DeleteSessionResponse extends SessionServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9088102548957440313L;

	/**
	 * Instantiates a new delete business object response.
	 */
	public DeleteSessionResponse() {
		super();
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param ex the exception
	 */
	public DeleteSessionResponse(Exception exception) {
		super();
		getErrorCollector().register(exception);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public DeleteSessionResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DeleteSessionResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/10 21:02:44  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
