/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import static org.springframework.util.StringUtils.trimTrailingWhitespace;
import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper;
import gov.ca.dmv.ease.ecs.exception.impl.EcsInvalidResponseException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsJmsException;
import gov.ca.dmv.ease.ecs.exception.impl.MessageConversionException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.util.impl.Decoder3270;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * Description: Abstract implementation of IMessageConverter
 * Concrete subclasses are responsible for converting Requests to messages
 * and for converting messages to response objects
 * Provides support for commonalities in the implementation.
 * 
 * File: AbstractDlConverter.java
 * Module:  gov.ca.dmv.ease.ecs.convert.impl
 * Created: Mar 19, 2009
 * 
 * @author mwpxp2
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2017/12/22 18:34:32 $
 * Last Changed By: $Author: mwwwc $
 */
public abstract class AbstractEcsMessageConverter implements IMessageConverter {
	/** The EMPTY_BLANK. */
	protected static final String BLANK = "";
	/** The CDL PASSWORD */
	protected static final String CDL_PASSWORD = "PASSWD";
	/** The Constant COMMERCIAL_CLASS_A. */
	private static final String COMMERCIAL_CLASS_A = "A";
	/** The Constant COMMERCIAL_CLASS_B. */
	private static final String COMMERCIAL_CLASS_B = "B";
	/** The Constant COMMERCIAL_CLASS_C. */
	private static final String COMMERCIAL_CLASS_C = "C";
	/** The Constant Real ID COMMERCIAL_CLASS_K (A). */
	private static final String REAL_ID_COMMERCIAL_CLASS_A = "K";
	/** The Constant Real ID COMMERCIAL_CLASS_L (B). */
	private static final String REAL_ID_COMMERCIAL_CLASS_B = "L";
	/** The Constant Real ID COMMERCIAL_CLASS_Q (C). */
	private static final String REAL_ID_COMMERCIAL_CLASS_C = "Q";
	/** The ecs message sources. */
	private static ResourceBundleMessageSource ECS_MESSAGES;// previously Injected by spring
	/** The EMPTY_SPACE. */
	protected static final String EMPTY_SPACE = " ";
	/** The Constant EYE_COLOR_CODES. */
	protected static Map <String, String> EYE_COLOR_CODES;
	/** The Constant GENDER_CODES. */
	protected static Map <String, String> GENDER_CODES;
	/** The Constant HAIR_COLOR_CODES. */
	protected static Map <String, String> HAIR_COLOR_CODES;
	/** The HEX_SEPERATOR. */
	private static int HEX_SEPERATOR = 0x1C;
	/** The Constant LINE_SEPARATOR. */
	protected static final String LINE_SEPARATOR = System
			.getProperty("line.separator");
	/** The Constant MINOR_GUARANTOR_CODES. */
	protected static Map <String, String> MINOR_GUARANTOR_CODES;
	/** The Constant MOTOR_CYCLE. */
	private static final String MOTOR_CYCLE = "M";
	/** The Constant NON_COMMERCIAL_CLASS_A. */
	private static final String NON_COMMERCIAL_CLASS_A = "D";
	/** The Constant NON_COMMERCIAL_CLASS_B. */
	private static final String NON_COMMERCIAL_CLASS_B = "E";
	/** The Constant NON_COMMERCIAL_CLASS_C. */
	private static final String NON_COMMERCIAL_CLASS_C = "F";
	///** The HE x_ en d_ o f_ text. */
	/* private static char HEX_END_OF_TEXT = '\u0003';*/
	/** The REQUESTOR_CODE. */
	private static String REQUESTOR_CODE = "99933";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7576436398502730237L;
	/** The Constant STATECODES. */
	private static Map <String, String> STATECODES;
	/** The Constant STATECODES_NAMES. */
	private static Map <String, String> STATECODES_NAMES;
	/** The Constant STATECODES_REVERSED. */
	private static Map <String, String> STATECODES_REVERSED;
	/**The BigDecimal 0. */
	private static BigDecimal ZERO = BigDecimal.ZERO;

	/**
	 * adds an year to the date.
	 * 
	 * @param date the date
	 * 
	 * @return date
	 */
	protected static Date addAnYear(Date date) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(date);
		c1.add(Calendar.YEAR, 1);
		return c1.getTime();
	}

	/**
	 * Adds the header.
	 *
	 * @param builder the builder
	 * @param header the header
	 * @return the string builder
	 */
	protected static StringBuilder addHeader(StringBuilder builder,
			String header) {
		String body = builder.toString();
		if (isNullOrBlank(body)) {
			return builder;
		}
		StringBuilder strBuilder = new StringBuilder();
		if (!EaseUtil.isNullOrBlank(header)) {
			strBuilder.append(header);
		}
		strBuilder.append(body);
		return strBuilder;
	}

	/**
	 * Adds the not null element in list.
	 *
	 * @param <T> the generic type
	 * @param element the element
	 * @param list the list
	 */
	protected static <T> void addNotNullElementInList(T element, List <T> list) {
		if (!isNull(element)) {
			list.add(element);
		}
	}

	/**
	 * Return a hexadecimal string.
	 *
	 * @param buf the buf
	 * @return the string
	 */
	protected static String asHex(byte[] buf) {
		char[] hexaChars = "0123456789abcdef".toCharArray();
		char[] chars = new char[2 * buf.length];
		for (int i = 0; i < buf.length; ++i) {
			chars[2 * i] = hexaChars[(buf[i] & 0xF0) >>> 4];
			chars[2 * i + 1] = hexaChars[buf[i] & 0x0F];
		}
		return new String(chars);
	}

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	protected static String convertDateToString(Date date) {
		return EcsConverterHelper.convertDateToString(date);
	}

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	protected static String convertDateToStringMM_DD_YYYY(Date date) {
		return EcsConverterHelper.convertDateToStringMM_DD_YYYY(date);
	}

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * @param format the format
	 * 
	 * @return the string
	 */
	public static String convertDateToString(Date date, String format) {
		if (date == null) {
			return BLANK;
		}
		DateFormat formatter = new SimpleDateFormat(format);
		StringBuilder sDate = new StringBuilder(formatter.format(date));
		String returnString = sDate.toString();
		return returnString;
	}

	/**
	 * Convert hexadecimal string to ascii.
	 *
	 * @param hex the hex
	 * @return a string
	 */
	protected static String convertHexToString(String hex) {
		StringBuilder sb = new StringBuilder();
		StringBuilder temp = new StringBuilder();
		//49204c6f7665204a617661 split into two characters 49, 20, 4c...
		for (int i = 0; i < hex.length() - 1; i += 2) {
			//grab the hex in pairs
			String output = hex.substring(i, (i + 2));
			//convert hex to decimal
			int decimal = Integer.parseInt(output, 16);
			//convert the decimal to character
			sb.append((char) decimal);
			temp.append(decimal);
		}
		return sb.toString();
	}

	/**
	 * Convert integer to string.
	 * 
	 * @param integer the integer
	 * 
	 * @return the string
	 */
	protected static String convertIntegerToString(Integer integer) {
		if (isNull(integer)) {
			return null;
		}
		return integer.toString();
	}

	/**
	 * Convert string to date.
	 * 
	 * @param date the date
	 * 
	 * @return the date
	 */
	protected static Date convertStringToDate(String date) {
		return EcsConverterHelper.convertStringToDate(date);
	}

	/**
	 * Convert string to date.
	 * 
	 * @param date the date
	 * @param format the format
	 * 
	 * @return the date
	 */
	protected static Date convertStringToDate(String date, String format) {
		return EcsConverterHelper.convertStringToDate(date, format);
	}

	/**
	 * Convert String to Hexadecimal.
	 *
	 * @param input the input
	 * @return a hexadecimal string
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	protected static String convertStringToHexaDecimal(String input)
			throws UnsupportedEncodingException {
		return asHex(input.getBytes("8859_1"));
	}

	/**
	 * Convert string to integer.
	 * 
	 * @param str the str
	 * 
	 * @return the integer
	 */
	protected static Integer convertStringToInteger(String str) {
		return EcsConverterHelper.convertStringToInteger(str);
	}

	/**
	 * Convert yor n to boolean.
	 * 
	 * @param yOrn the y orn
	 * 
	 * @return the boolean
	 */
	public static Boolean convertYornToBoolean(String yOrn) {
		if (yOrn.equalsIgnoreCase("Y")) {
			return Boolean.TRUE;
		}
		else if (yOrn.equalsIgnoreCase("N")) {
			return Boolean.FALSE;
		}
		return null;
	}

	/**
	 * Does state code key exist.
	 * 
	 * @param stateCodeKey the state code key
	 * 
	 * @return true, if successful
	 */
	public static boolean doesStateCodeKeyExist(String stateCodeKey) {
		return getStateCodes().containsKey(stateCodeKey);
	}

	/**
	 * Does state code value exist.
	 * 
	 * @param stateCodeValue the state code value
	 * 
	 * @return true, if successful
	 */
	public static boolean doesStateCodeValueExist(String stateCodeValue) {
		return getStateCodes().containsValue(stateCodeValue);
	}

	/**
	 * The Filler.
	 * 
	 * @param string the string
	 * @param expectedLength the expected length
	 * 
	 * @return returnString the string
	 */
	public static String filler(String string, int expectedLength) {
		if (string == null) {
			string = EcsConverterHelper.PAD;
		}
		String returnString = filler(string, expectedLength,
				EcsConverterHelper.EMPTY_FILLER);
		return returnString;
	}

	/**
	 * Pads a given string with spaces to generate a fixed length String.
	 * This method also removes the extra characters if the string length
	 * is greater the expected length.
	 *
	 * @param inputString the input string
	 * @param expectedLength int specifying the length of the String
	 * @param replaceChar Character to be replaced
	 * @return String padded string
	 */
	protected static String filler(String inputString, int expectedLength,
			char replaceChar) {
		String returnString = filler(inputString, expectedLength, replaceChar,
				EcsConverterHelper.PAD_RIGHT);
		return returnString;
	}

	/**
	 * The Filler.
	 * 
	 * @param inputString the input string
	 * @param expectedLength the expected length
	 * @param replaceChar the replace char
	 * @param justification the justification
	 * 
	 * @return the string
	 */
	protected static String filler(String inputString, int expectedLength,
			char replaceChar, int justification) {
		StringBuilder stringBuilder = null;
		if (inputString != null) {
			if (inputString.length() > expectedLength) {
				inputString = inputString.substring(0, expectedLength);
			}
		}
		else if (inputString == null) {
			inputString = BLANK;
		}
		int paddingNeeded = expectedLength - inputString.length();
		if (paddingNeeded <= 0) {
			return inputString;
		}
		char padding[] = new char[paddingNeeded];
		java.util.Arrays.fill(padding, replaceChar);
		stringBuilder = new StringBuilder(expectedLength);
		if (justification == EcsConverterHelper.PAD_LEFT) {
			stringBuilder.append(padding);
			stringBuilder.append(inputString);
		}
		else if (justification == EcsConverterHelper.PAD_RIGHT) {
			stringBuilder.append(inputString);
			stringBuilder.append(padding);
		}
		String returnString = stringBuilder.toString();
		return returnString;
	}

	/**
	 * Format multi segment response.
	 * 
	 * @param inboundMessagePayloads the inbound message payloads
	 * 
	 * @return the string
	 */
	protected static String formatMultiSegmentResponse(
			List <String> inboundMessagePayloads) {
		StringBuilder strBuff = new StringBuilder();
		for (String payload : inboundMessagePayloads) {
			String ebcidic = null;
			String screen = null;
			String formattedScreen = null;
			try {
				ebcidic = new String(payload.getBytes("Cp1047"));
				screen = Decoder3270.decode(ebcidic);
				formattedScreen = Decoder3270.formatScreen(screen);
				strBuff.append(formattedScreen).append(LINE_SEPARATOR);
			}
			catch (UnsupportedEncodingException e) {
				throw new MessageConversionException(e);
			}
		}
		return trimTrailingWhitespace(removeDuplicateHeader(strBuff));
	}

	/**
	 * Gets the century.
	 * 
	 * @param century the century
	 * 
	 * @return the century
	 */
	protected static String getCentury(String century) {
		century = century.trim();
		String[] validCenturyParams = { "8", "9", "0" };
		if (!Arrays.asList(validCenturyParams).contains(century)) {
			century = "9";
		}
		if (century.equals("8")) {
			century = "18";
		}
		else if (century.equals("9")) {
			century = "19";
		}
		else if (century.equals("0")) {
			century = "20";
		}
		return century;
	}

	/**
	 * Gets the century indicator.
	 * 
	 * @param date the date
	 * 
	 * @return the century indicator
	 */
	public static String getCenturyIndicator(Date date) {
		String centuryIndicator = BLANK;
		if (!EaseUtil.isNullOrBlank(date)) {
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.setTime(date);
			int year = calendar.get(Calendar.YEAR);
			if ((year >= 1800) && (year < 1900)) {
				centuryIndicator = "8";
			}
			else if ((year >= 1900) && (year < 2000)) {
				centuryIndicator = "9";
			}
			else if (year >= 2000) {
				centuryIndicator = "0";
			}
		}
		return centuryIndicator;
	}

	/**
	 * Gets the code value of CodeSetElement.
	 * 
	 * @param codeSetElement the code set element
	 * @param codeLength the code length
	 * 
	 * @return the code value of CodeSetElement
	 */
	protected static String getCodeSetElementValue(
			CodeSetElement codeSetElement, int codeLength) {
		if (EaseUtil.isNotNull(codeSetElement)) {
			return filler(codeSetElement.getCode(), codeLength);
		}
		else {
			return filler(BLANK, codeLength);
		}
	}

	/**
	 * Gets the code set registry singleton.
	 * 
	 * @return the code set registry singleton
	 */
	protected static ICodeSetRegistrySingleton getCodeSetRegistrySingleton() {
		return CodeSetRegistrySingleton.getInstance();
	}

	/**
	 * Gets current time as String.
	 * 
	 * @param format the format
	 * 
	 * @return String Current time
	 */
	protected static String getCurrentTimeAsString(String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		String returnString = dateFormat.format(date);
		return returnString;
	}

	/**
	 * Gets the ecs message sources.
	 * 
	 * @return the ecs message sources
	 */
	protected static ResourceBundleMessageSource getEcsMessageSources() {
		if (ECS_MESSAGES == null) {
			initEcsMessages();
		}
		return ECS_MESSAGES;
	}

	/**
	 * This method returns the 2 character employee ID from the user context.
	 * 
	 * @param userContext User Context instance
	 * 
	 * @return Employee ID from the user context
	 */
	protected static String getEmployeeId(IUserContext userContext) {
		String returnString = filler(userContext.getTechId(), 2);
		return returnString;
	}

	/**
	 * This method returns the user ID from the user context.
	 * 
	 * @param userContext User Context instance
	 * 
	 * @return Employee ID from the user context
	 */
	protected static String getUserId(IUserContext userContext) {
		String returnString = filler(userContext.getUserName(), 32);
		return returnString;
	}

	/**
	 * Gets the error code from the response assuming error code as 2.
	 * 
	 * @param response Response which needs to be parsed for error code
	 * @param errorCodeStartPos Error code start position
	 * 
	 * @return Error code
	 */
	protected static String getErrorCode(String response, int errorCodeStartPos) {
		String returnString = getErrorCode(response, errorCodeStartPos, 2);
		return returnString;
	}

	/**
	 * Gets the error code from the response.
	 * 
	 * @param response Response which needs to be parsed for error code
	 * @param errorCodeStartPos Error code start position
	 * @param length length of the error code
	 * 
	 * @return Error code
	 */
	protected static String getErrorCode(String response,
			int errorCodeStartPos, int length) {
		String returnString = response.substring(errorCodeStartPos,
				errorCodeStartPos + length).trim();
		return returnString;
	}

	/**
	 * Gets the eye color codes.
	 *
	 * @return the eye color codes
	 */
	protected static Map <String, String> getEyeColorCodes() {
		if (EYE_COLOR_CODES == null) {
			initEyeColorCodes();
		}
		return EYE_COLOR_CODES;
	}

	/**
	 * Gets the gender codes.
	 *
	 * @return the gender codes
	 */
	protected static Map <String, String> getGenderCodes() {
		if (GENDER_CODES == null) {
			initGenderCodes();
		}
		return GENDER_CODES;
	}

	/**
	 * Gets the hair color codes.
	 *
	 * @return the hair color codes
	 */
	protected static Map <String, String> getHairColorCodes() {
		if (HAIR_COLOR_CODES == null) {
			initHairColorCodes();
		}
		return HAIR_COLOR_CODES;
	}

	/**
	 * Gets the header.
	 *
	 * @param builder the builder
	 * @return the header
	 */
	protected static String getHeader(StringBuilder builder) {
		if (builder == null) {
			return "";
		}
		String string = builder.toString();
		if (isNullOrBlank(string)) {
			return "";
		}
		StringTokenizer tokenizer = new StringTokenizer(string, LINE_SEPARATOR);
		int headerLengh = tokenizer.nextToken().length();
		return string.substring(0, headerLengh);
	}

	/**
	 * Gets the issuance offices.
	 * 
	 * @return the issuance offices
	 */
	protected static List <String> getIssuanceOffices() {
		return Arrays.asList(new String[] { "212", "231" });// TODO: list the issuance ids.
	}

	/**
	 * Gets the lic cls0.
	 * 
	 * @return the lic cls0
	 */
	protected static String getLicCls0() {
		return getMessageFromResourceBundle("LICENSE_CLASS_0");
	}

	/**
	 * Gets the lic cls1.
	 * 
	 * @return the lic cls1
	 */
	protected static String getLicCls1() {
		return getMessageFromResourceBundle("LICENSE_CLASS_1");
	}

	/**
	 * Gets the lic cls2.
	 * 
	 * @return the lic cls2
	 */
	protected static String getLicCls2() {
		return getMessageFromResourceBundle("LICENSE_CLASS_2");
	}

	/**
	 * Gets the lic cls3.
	 * 
	 * @return the lic cls3
	 */
	protected static String getLicCls3() {
		return getMessageFromResourceBundle("LICENSE_CLASS_3");
	}

	/**
	 * Gets the lic cls4.
	 * 
	 * @return the lic cls4
	 */
	protected static String getLicCls4() {
		return getMessageFromResourceBundle("LICENSE_CLASS_4");
	}

	/**
	 * Gets the lic cls a.
	 * 
	 * @return the lic cls a
	 */
	protected static String getLicClsA() {
		return getMessageFromResourceBundle("LICENSE_CLASS_A");
	}

	/**
	 * Gets the lic cls b.
	 * 
	 * @return the lic cls b
	 */
	protected static String getLicClsB() {
		return getMessageFromResourceBundle("LICENSE_CLASS_B");
	}

	/**
	 * Gets the lic cls c.
	 * 
	 * @return the lic cls c
	 */
	protected static String getLicClsC() {
		return getMessageFromResourceBundle("LICENSE_CLASS_C");
	}

	/**
	 * Gets the lic cls d.
	 * 
	 * @return the lic cls d
	 */
	protected static String getLicClsD() {
		return getMessageFromResourceBundle("LICENSE_CLASS_D");
	}

	/**
	 * Gets the lic cls e.
	 * 
	 * @return the lic cls e
	 */
	protected static String getLicClsE() {
		return getMessageFromResourceBundle("LICENSE_CLASS_E");
	}

	/**
	 * Gets the lic cls f.
	 * 
	 * @return the lic cls f
	 */
	protected static String getLicClsF() {
		return getMessageFromResourceBundle("LICENSE_CLASS_F");
	}

	/**
	 * Gets the lic cls m.
	 * 
	 * @return the lic cls m
	 */
	protected static String getLicClsM() {
		return getMessageFromResourceBundle("LICENSE_CLASS_M");
	}

	/**
	 * Gets the message from resource bundle.
	 * 
	 * @param key the key
	 * 
	 * @return the message from resource bundle
	 */
	protected static String getMessageFromResourceBundle(String key) {
		return EcsConverterHelper.getMessageFromResourceBundle(
				getEcsMessageSources(), key);
	}

	/**
	 * Gets the message from resource bundle with default message.
	 * 
	 * @param key the key
	 * @param defaultMsg the default msg
	 * 
	 * @return the message from resource bundle with default message
	 */
	protected static String getMessageFromResourceBundleWithDefaultMessage(
			String key, String defaultMsg) {
		return EcsConverterHelper
				.getMessageFromResourceBundleWithDefaultMessage(
						getEcsMessageSources(), key, defaultMsg);
	}

	/**
	 * Gets the message from resource bundle with parameters and default message.
	 * 
	 * @param key the key
	 * @param parameter the parameter
	 * @param defaultMsg the default msg
	 * 
	 * @return the message from resource bundle with parameters and default message
	 */
	protected static String getMessageFromResourceBundleWithParametersAndDefaultMessage(
			String key, String[] parameter, String defaultMsg) {
		return EcsConverterHelper
				.getMessageFromResourceBundleWithParametersAndDefaultMessage(
						getEcsMessageSources(), key, parameter, defaultMsg);
	}

	/**
	 * Gets the minor guarantor codes.
	 *
	 * @return the minor guarantor codes
	 */
	protected static Map <String, String> getMinorGuarantorCodes() {
		if (MINOR_GUARANTOR_CODES == null) {
			initMinorGuarantorCodes();
		}
		return MINOR_GUARANTOR_CODES;
	}

	/**
	 * Gets the non empty string.
	 * 
	 * @param str the str
	 * 
	 * @return the non empty string
	 */
	protected static String getNonNullString(String str) {
		String returnString = (str == null) ? BLANK : str;
		return returnString;
	}

	/**
	 * This method returns the 3 characer office ID from the user context.
	 * 
	 * @param userContext the user context
	 * 
	 * @return Office ID from the user context
	 */
	protected static String getOfficeId(IUserContext userContext) {
		String returnString = filler(BLANK, 3);
		if (EaseUtil.isNotNull(userContext)) {
			returnString = filler(userContext.getOfficeId(), 3);
		}
		return returnString;
	}

	/**
	 * Gets the requestor code user id.
	 * 
	 * @param userContext the user context
	 * 
	 * @return the requestor code user id
	 */
	protected static String getRequestorCodeAndUserIdCombination(
			IUserContext userContext) {
		return (REQUESTOR_CODE + getEmployeeId(userContext) + EcsConverterHelper.EMPTY_FILLER);
	}

	/**
	 * Gets the reversed state codes.
	 *
	 * @return the reversed state codes
	 */
	protected static Map <String, String> getReversedStateCodes() {
		if (STATECODES_REVERSED == null) {
			initReversedStateCodes();
		}
		return STATECODES_REVERSED;
	}

	/**
	 * Gets the state codes.
	 *
	 * @return the state codes
	 */
	protected static Map <String, String> getStateCodes() {
		if (STATECODES == null) {
			initStateCodes();
		}
		return STATECODES;
	}

	/**
	 * Gets the state names.
	 *
	 * @return the state names
	 */
	protected static Map <String, String> getStateNames() {
		if (STATECODES_NAMES == null) {
			initStateNames();
		}
		return STATECODES_NAMES;
	}

	/**
	 * Gets the sub string.
	 * 
	 * @param str the str
	 * @param start the start
	 * @param end the end
	 * 
	 * @return the sub string
	 */
	protected static String getSubString(String str, Integer start, Integer end) {
		if (end != null) {
			return str.substring(start, end).trim();
		}
		else {
			return str.substring(start).trim();
		}
	}

	/**
	 * This method returns the 3 character TTC from the user context.
	 * 
	 * @param userContext User Context instance
	 * 
	 * @return current TTC
	 */
	protected static String getTtc(IUserContext userContext) {
		String returnString = null;
		if (EaseUtil.isNotNull(userContext)) {
			returnString = filler(userContext.getTtc(), 3);
		}
		return returnString;
	}

	/**
	 * Gets the work date.
	 * 
	 * @param userContext the user context
	 * 
	 * @return the work date
	 */
	protected static String getWorkDate(IUserContext userContext) {
		String returnString = null;
		if (EaseUtil.isNotNull(userContext)) {
			returnString = EcsConverterHelper.convertDateToString(
					userContext.getWorkDate(),
					EcsConverterHelper.FORMATTER_YY_MM_DD);
		}
		return returnString;
	}

	/**
	 * Gets the work date.
	 * 
	 * @param userContext the user context
	 * @param format the format
	 * 
	 * @return the work date
	 */
	protected static String getWorkDate(IUserContext userContext, String format) {
		String returnString = null;
		if (EaseUtil.isNotNull(userContext)) {
			returnString = convertDateToString(userContext.getWorkDate(),
					format);
		}
		return returnString;
	}

	/**
	 * Inits the ecs messages.
	 */
	protected static void initEcsMessages() {
		ECS_MESSAGES = new ResourceBundleMessageSource();
		ECS_MESSAGES.setBasenames(new String[] { "ecsValidationMessages",
				"ecsCodes" });
	}

	/**
	 * Inits the eye color codes.
	 */
	protected static void initEyeColorCodes() {
		EYE_COLOR_CODES = new HashMap <String, String>();
		EYE_COLOR_CODES.put("1", "BRN");
		EYE_COLOR_CODES.put("2", "BLK");
		EYE_COLOR_CODES.put("3", "GRY");
		EYE_COLOR_CODES.put("4", "BLU");
		EYE_COLOR_CODES.put("5", "HZL");
		EYE_COLOR_CODES.put("6", "GRN");
	}

	/**
	 * Inits the gender codes.
	 */
	protected static void initGenderCodes() {
		GENDER_CODES = new HashMap <String, String>();
		GENDER_CODES.put("1", "M");
		GENDER_CODES.put("2", "F");
	}

	/**
	 * Inits the hair color codes.
	 */
	protected static void initHairColorCodes() {
		HAIR_COLOR_CODES = new HashMap <String, String>();
		HAIR_COLOR_CODES.put("1", "BRN");
		HAIR_COLOR_CODES.put("2", "BLK");
		HAIR_COLOR_CODES.put("3", "GRY");
		HAIR_COLOR_CODES.put("4", "RED");
		HAIR_COLOR_CODES.put("5", "BLN");
		HAIR_COLOR_CODES.put("6", "BAL");
		HAIR_COLOR_CODES.put("7", "AUB");
		HAIR_COLOR_CODES.put("8", "WHT");
		HAIR_COLOR_CODES.put("9", "OTH");
	}

	/**
	 * Inits the minor guarantor codes.
	 */
	protected static void initMinorGuarantorCodes() {
		MINOR_GUARANTOR_CODES = new HashMap <String, String>();
		MINOR_GUARANTOR_CODES.put("1", "PS");
		MINOR_GUARANTOR_CODES.put("2", "EM");
		MINOR_GUARANTOR_CODES.put("3", "PP");
		MINOR_GUARANTOR_CODES.put("4", "EP");
		MINOR_GUARANTOR_CODES.put("5", "NR");
		MINOR_GUARANTOR_CODES.put("6", "XM");
		MINOR_GUARANTOR_CODES.put("7", "SM");
		MINOR_GUARANTOR_CODES.put("A", "EM");
		MINOR_GUARANTOR_CODES.put("Z", "EO");
	}

	/**
	 * Inits the reversed state codes.
	 */
	protected static void initReversedStateCodes() {
		STATECODES_REVERSED = new HashMap <String, String>();
		STATECODES_REVERSED.put("AL", "01");
		STATECODES_REVERSED.put("AZ", "02");
		STATECODES_REVERSED.put("AR", "03");
		STATECODES_REVERSED.put("CA", "04");
		STATECODES_REVERSED.put("CO", "05");
		STATECODES_REVERSED.put("CT", "06");
		STATECODES_REVERSED.put("DE", "07");
		STATECODES_REVERSED.put("FL", "08");
		STATECODES_REVERSED.put("GA", "09");
		STATECODES_REVERSED.put("ID", "10");
		STATECODES_REVERSED.put("IL", "11");
		STATECODES_REVERSED.put("IN", "12");
		STATECODES_REVERSED.put("IA", "13");
		STATECODES_REVERSED.put("KS", "14");
		STATECODES_REVERSED.put("KY", "15");
		STATECODES_REVERSED.put("LA", "16");
		STATECODES_REVERSED.put("ME", "17");
		STATECODES_REVERSED.put("MD", "18");
		STATECODES_REVERSED.put("MA", "19");
		STATECODES_REVERSED.put("MI", "20");
		STATECODES_REVERSED.put("MN", "21");
		STATECODES_REVERSED.put("MS", "22");
		STATECODES_REVERSED.put("MO", "23");
		STATECODES_REVERSED.put("MT", "24");
		STATECODES_REVERSED.put("NE", "25");
		STATECODES_REVERSED.put("NV", "26");
		STATECODES_REVERSED.put("NH", "27");
		STATECODES_REVERSED.put("NJ", "28");
		STATECODES_REVERSED.put("NM", "29");
		STATECODES_REVERSED.put("NY", "30");
		STATECODES_REVERSED.put("NC", "31");
		STATECODES_REVERSED.put("ND", "32");
		STATECODES_REVERSED.put("OH", "33");
		STATECODES_REVERSED.put("OK", "34");
		STATECODES_REVERSED.put("OR", "35");
		STATECODES_REVERSED.put("PA", "36");
		STATECODES_REVERSED.put("RI", "37");
		STATECODES_REVERSED.put("SC", "38");
		STATECODES_REVERSED.put("SD", "39");
		STATECODES_REVERSED.put("TN", "40");
		STATECODES_REVERSED.put("TX", "41");
		STATECODES_REVERSED.put("UT", "42");
		STATECODES_REVERSED.put("VT", "43");
		STATECODES_REVERSED.put("VA", "44");
		STATECODES_REVERSED.put("WA", "45");
		STATECODES_REVERSED.put("WV", "46");
		STATECODES_REVERSED.put("WI", "47");
		STATECODES_REVERSED.put("WY", "48");
		STATECODES_REVERSED.put("AK", "49");
		STATECODES_REVERSED.put("HI", "50");
		STATECODES_REVERSED.put("HI", "51");
		STATECODES_REVERSED.put("HI", "52");
		STATECODES_REVERSED.put("HI", "53");
		STATECODES_REVERSED.put("DC", "54");
		STATECODES_REVERSED.put("PR", "55");
		STATECODES_REVERSED.put("GU", "57");
		STATECODES_REVERSED.put("VI", "58");
		STATECODES_REVERSED.put("AS", "59");
		STATECODES_REVERSED.put("AB", "60");
		STATECODES_REVERSED.put("BC", "61");
		STATECODES_REVERSED.put("MB", "62");
		STATECODES_REVERSED.put("NB", "63");
		STATECODES_REVERSED.put("NS", "64");
		STATECODES_REVERSED.put("ON", "65");
		STATECODES_REVERSED.put("PE", "66");
		STATECODES_REVERSED.put("QC", "67");
		STATECODES_REVERSED.put("SK", "68");
		STATECODES_REVERSED.put("FR", "69");
		STATECODES_REVERSED.put("KE", "70");
		STATECODES_REVERSED.put("MK", "71");
		STATECODES_REVERSED.put("YT", "72");
		STATECODES_REVERSED.put("NF", "73");
		STATECODES_REVERSED.put("CN", "74");
		STATECODES_REVERSED.put("NU", "75");
		STATECODES_REVERSED.put("NT", "76");
		STATECODES_REVERSED.put("AE", "94");
		STATECODES_REVERSED.put("AP", "95");
		STATECODES_REVERSED.put("AA", "96");
		STATECODES_REVERSED.put("MX", "98");
		STATECODES_REVERSED.put("OT", "99");
	}

	/**
	 * Inits the state codes.
	 */
	protected static void initStateCodes() {
		STATECODES = new HashMap <String, String>();
		STATECODES.put("01", "AL");
		STATECODES.put("02", "AZ");
		STATECODES.put("03", "AR");
		STATECODES.put("04", "CA");
		STATECODES.put("05", "CO");
		STATECODES.put("06", "CT");
		STATECODES.put("07", "DE");
		STATECODES.put("08", "FL");
		STATECODES.put("09", "GA");
		STATECODES.put("10", "ID");
		STATECODES.put("11", "IL");
		STATECODES.put("12", "IN");
		STATECODES.put("13", "IA");
		STATECODES.put("14", "KS");
		STATECODES.put("15", "KY");
		STATECODES.put("16", "LA");
		STATECODES.put("17", "ME");
		STATECODES.put("18", "MD");
		STATECODES.put("19", "MA");
		STATECODES.put("20", "MI");
		STATECODES.put("21", "MN");
		STATECODES.put("22", "MS");
		STATECODES.put("23", "MO");
		STATECODES.put("24", "MT");
		STATECODES.put("25", "NE");
		STATECODES.put("26", "NV");
		STATECODES.put("27", "NH");
		STATECODES.put("28", "NJ");
		STATECODES.put("29", "NM");
		STATECODES.put("30", "NY");
		STATECODES.put("31", "NC");
		STATECODES.put("32", "ND");
		STATECODES.put("33", "OH");
		STATECODES.put("34", "OK");
		STATECODES.put("35", "OR");
		STATECODES.put("36", "PA");
		STATECODES.put("37", "RI");
		STATECODES.put("38", "SC");
		STATECODES.put("39", "SD");
		STATECODES.put("40", "TN");
		STATECODES.put("41", "TX");
		STATECODES.put("42", "UT");
		STATECODES.put("43", "VT");
		STATECODES.put("44", "VA");
		STATECODES.put("45", "WA");
		STATECODES.put("46", "WV");
		STATECODES.put("47", "WI");
		STATECODES.put("48", "WY");
		STATECODES.put("49", "AK");
		STATECODES.put("50", "HI");
		STATECODES.put("51", "HI");
		STATECODES.put("52", "HI");
		STATECODES.put("53", "HI");
		STATECODES.put("54", "DC");
		STATECODES.put("55", "PR");
		STATECODES.put("57", "GU");
		STATECODES.put("58", "VI");
		STATECODES.put("59", "AS");
		STATECODES.put("60", "AB");
		STATECODES.put("61", "BC");
		STATECODES.put("62", "MB");
		STATECODES.put("63", "NB");
		STATECODES.put("64", "NS");
		STATECODES.put("65", "ON");
		STATECODES.put("66", "PE");
		STATECODES.put("67", "QC");
		STATECODES.put("68", "SK");
		STATECODES.put("69", "FR");
		STATECODES.put("70", "KE");
		STATECODES.put("71", "MK");
		STATECODES.put("72", "YT");
		STATECODES.put("73", "NF");
		STATECODES.put("74", "CN");
		STATECODES.put("75", "NU");
		STATECODES.put("76", "NT");
		STATECODES.put("94", "AE");
		STATECODES.put("95", "AP");
		STATECODES.put("96", "AA");
		STATECODES.put("98", "MX");
		STATECODES.put("99", "OT");
	}

	/**
	 * Inits the state names.
	 */
	protected static void initStateNames() {
		STATECODES_NAMES = new HashMap <String, String>();
		STATECODES_NAMES.put("01", "ALABAMA");
		STATECODES_NAMES.put("02", "ARIZONA");
		STATECODES_NAMES.put("03", "ARKANSAS");
		STATECODES_NAMES.put("04", "CALIFORNIA");
		STATECODES_NAMES.put("05", "COLORADO");
		STATECODES_NAMES.put("06", "CONNECTICUT");
		STATECODES_NAMES.put("07", "DELAWARE");
		STATECODES_NAMES.put("08", "FLORIDA");
		STATECODES_NAMES.put("09", "GEORGIA");
		STATECODES_NAMES.put("10", "IDAHO");
		STATECODES_NAMES.put("11", "ILLINOIS");
		STATECODES_NAMES.put("12", "INDIANA");
		STATECODES_NAMES.put("13", "IOWA");
		STATECODES_NAMES.put("14", "KANSAS");
		STATECODES_NAMES.put("15", "KENTUCKY");
		STATECODES_NAMES.put("16", "LOUISIANA");
		STATECODES_NAMES.put("17", "MAINE");
		STATECODES_NAMES.put("18", "MARYLAND");
		STATECODES_NAMES.put("19", "MASSACHUSETTS");
		STATECODES_NAMES.put("20", "MICHIGAN");
		STATECODES_NAMES.put("21", "MINNESOTA");
		STATECODES_NAMES.put("22", "MISSISSIPPI");
		STATECODES_NAMES.put("23", "MISSOURI");
		STATECODES_NAMES.put("24", "MONTANA");
		STATECODES_NAMES.put("25", "NEBRASKA");
		STATECODES_NAMES.put("26", "NEVADA");
		STATECODES_NAMES.put("27", "NEW HAMPSHIRE");
		STATECODES_NAMES.put("28", "NEW JERSEY");
		STATECODES_NAMES.put("29", "NEW MEXICO");
		STATECODES_NAMES.put("30", "NEW YORK");
		STATECODES_NAMES.put("31", "NORTH CAROLINA");
		STATECODES_NAMES.put("32", "NORTH DAKOTA");
		STATECODES_NAMES.put("33", "OHIO");
		STATECODES_NAMES.put("34", "OKLAHOMA");
		STATECODES_NAMES.put("35", "OREGON");
		STATECODES_NAMES.put("36", "PENNSYLVANIA");
		STATECODES_NAMES.put("37", "RHODE ISLAND");
		STATECODES_NAMES.put("38", "SOUTH CAROLINA");
		STATECODES_NAMES.put("39", "SOUTH DAKOTA");
		STATECODES_NAMES.put("40", "TENNESSEE");
		STATECODES_NAMES.put("41", "TEXAS");
		STATECODES_NAMES.put("42", "UTAH");
		STATECODES_NAMES.put("43", "VERMONT");
		STATECODES_NAMES.put("44", "VIRGINIA");
		STATECODES_NAMES.put("45", "WASHINGTON");
		STATECODES_NAMES.put("46", "WEST VIRGINIA");
		STATECODES_NAMES.put("47", "WISCONSIN");
		STATECODES_NAMES.put("48", "WYOMING");
		STATECODES_NAMES.put("49", "ALASKA");
		STATECODES_NAMES.put("50", "HAWAII");
		STATECODES_NAMES.put("51", "HILO, HAWAII");
		STATECODES_NAMES.put("52", "KAUAI, HAWAII");
		STATECODES_NAMES.put("53", "MAUI, HAWAII");
		STATECODES_NAMES.put("54", "DISTRICT OF COLUMBIA");
		STATECODES_NAMES.put("55", "PUERTO RICO");
		STATECODES_NAMES.put("57", "GUAM");
		STATECODES_NAMES.put("58", "VIRGIN ISLAND");
		STATECODES_NAMES.put("59", "AMERICAN SAMOA");
		STATECODES_NAMES.put("60", "ALBERTA");
		STATECODES_NAMES.put("61", "BRITISH COLUMBIA");
		STATECODES_NAMES.put("62", "MANITOBA");
		STATECODES_NAMES.put("63", "NEW BRUNSWICK");
		STATECODES_NAMES.put("64", "NOVA SCOTIA");
		STATECODES_NAMES.put("65", "ONTARIO");
		STATECODES_NAMES.put("66", "PRINCE EDWARD ISLAND");
		STATECODES_NAMES.put("67", "QUEBEC");
		STATECODES_NAMES.put("68", "SASKATCHEWAN");
		STATECODES_NAMES.put("69", "PROVISIONAL DISTRICT OF FRANKLIN");
		STATECODES_NAMES.put("70", "PROVISIONAL DISTRICT OF KEEWATIN");
		STATECODES_NAMES.put("71", "PROVISIONAL DISTRICT OF MACKENZIE");
		STATECODES_NAMES.put("72", "YUKON TERRITORY");
		STATECODES_NAMES.put("73", "NEWFOUNDLAND");
		STATECODES_NAMES.put("74", "CCMTA - CANADIAN AAMVA");
		STATECODES_NAMES.put("75", "NUNAVUT");
		STATECODES_NAMES.put("76", "NORTHWEST TERRITORY");
		STATECODES_NAMES.put("94", "MILITARY EUROPE");
		STATECODES_NAMES.put("95", "MILITARY PACIFIC");
		STATECODES_NAMES.put("96", "MILITARY AMERICAN");
		STATECODES_NAMES.put("98", "MEXICO");
		STATECODES_NAMES.put("99", "Other");
	}

	/**
	 * Checks if is blank.
	 * 
	 * @param str the str
	 * 
	 * @return true, if is blank
	 */
	protected static boolean isBlank(String str) {
		boolean returnboolean = (str.trim().length() == 0);
		return returnboolean;
	}

	/**
	 * Tells whether applied class is an upgrade to existing class.
	 *
	 * @param appliedClass the applied class
	 * @param existingClass the existing class
	 * @return isClassUpgrade
	 */
	protected static boolean isClassUpgrade(String appliedClass,
			String existingClass) {
		boolean isClassUpgrade = false;
		if (COMMERCIAL_CLASS_A.equals(appliedClass)) {
			if (!COMMERCIAL_CLASS_A.equals(existingClass)) {
				isClassUpgrade = true;
			}
		}
		else if (COMMERCIAL_CLASS_B.equals(appliedClass)) {
			if (!(COMMERCIAL_CLASS_A.equals(existingClass) && COMMERCIAL_CLASS_B
					.equals(existingClass))) {
				isClassUpgrade = true;
			}
		}
		else if (COMMERCIAL_CLASS_C.equals(appliedClass)) {
			if (!(COMMERCIAL_CLASS_A.equals(existingClass)
					&& COMMERCIAL_CLASS_B.equals(existingClass)
					&& COMMERCIAL_CLASS_C.equals(existingClass)
					&& NON_COMMERCIAL_CLASS_A.equals(existingClass) && NON_COMMERCIAL_CLASS_B
						.equals(existingClass))) {
				isClassUpgrade = true;
			}
		}
		else if (NON_COMMERCIAL_CLASS_A.equals(appliedClass)) {
			if (!(COMMERCIAL_CLASS_A.equals(existingClass) && NON_COMMERCIAL_CLASS_A
					.equals(existingClass))) {
				isClassUpgrade = true;
			}
		}
		else if (NON_COMMERCIAL_CLASS_B.equals(appliedClass)) {
			if (!(COMMERCIAL_CLASS_A.equals(existingClass)
					&& COMMERCIAL_CLASS_B.equals(existingClass)
					&& NON_COMMERCIAL_CLASS_A.equals(existingClass) && NON_COMMERCIAL_CLASS_B
						.equals(existingClass))) {
				isClassUpgrade = true;
			}
		}
		else if (NON_COMMERCIAL_CLASS_C.equals(appliedClass)) {
			if (MOTOR_CYCLE.equals(existingClass)) {
				isClassUpgrade = true;
			}
		}
		else if (MOTOR_CYCLE.equals(appliedClass)) {
			if (!MOTOR_CYCLE.equals(existingClass)) {
				isClassUpgrade = true;
			}
		}
		return isClassUpgrade;
	}

	/**
	 * Checks if is commercial license class code.
	 * 
	 * @param licenseClassCode the license class code
	 * 
	 * @return true, if is commercial license class code
	 */
	protected static boolean isCommercialLicenseClassCode(
			String licenseClassCode) {
		final String[] commercialLicenseClassCodes = { COMMERCIAL_CLASS_A,
				COMMERCIAL_CLASS_B, COMMERCIAL_CLASS_C,
				REAL_ID_COMMERCIAL_CLASS_A, REAL_ID_COMMERCIAL_CLASS_B,
				REAL_ID_COMMERCIAL_CLASS_C };
		if (Arrays.asList(commercialLicenseClassCodes).contains(
				licenseClassCode)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if is commercial license class code.
	 * 
	 * @param licenseClassCode the license class code
	 * 
	 * @return true, if is commercial license class code
	 */
	protected static boolean isCommercialPermitClassCode(String licenseClassCode) {
		final String[] commercialLicenseClassCodes = { COMMERCIAL_CLASS_A,
				COMMERCIAL_CLASS_B, COMMERCIAL_CLASS_C,
				REAL_ID_COMMERCIAL_CLASS_A, REAL_ID_COMMERCIAL_CLASS_B,
				REAL_ID_COMMERCIAL_CLASS_C };
		if (Arrays.asList(commercialLicenseClassCodes).contains(
				licenseClassCode)) {
			return true;
		}
		return false;
	}

	/**
	 * Check if is not null.
	 * 
	 * @param obj the obj
	 * 
	 * @return true, if is null
	 */
	protected static boolean isNotNull(Object obj) {
		if (obj != null) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Checks if is null.
	 * 
	 * @param obj the obj
	 * 
	 * @return true, if is null
	 */
	protected static boolean isNull(Object obj) {
		if (obj == null) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Checks if is null or blank.
	 * 
	 * @param anObject the an object
	 * 
	 * @return true, if is null or blank
	 */
	protected static boolean isNullOrBlank(Object anObject) {
		return EaseUtil.isNullOrBlank(anObject);
	}

	/**
	 * Checks if is null or blank.
	 *
	 * @param collection the collection
	 * @return true, if is null or blank
	 */
	public static boolean isNullOrBlank(Collection <?> collection) {
		return EaseUtil.isNullOrBlank(collection);
	}

	/**
	 * Checks if string is null or blank.
	 *
	 * @param string the string
	 * @return true, if is null or blank
	 */
	protected static boolean isNullOrBlank(String string) {
		return EaseUtil.isNullOrBlank(string);
	}

	/**
	 * Checks if is null or blank.
	 *
	 * @param codeSetElement the code set element
	 * @return true, if is null or blank
	 */
	protected static boolean isNullOrBlank(CodeSetElement codeSetElement) {
		return EaseUtil.isNullOrBlank(codeSetElement);
	}

	/**
	 * This method removes duplicate header in given input string. first line of input string treated as a header.
	 * 
	 * @param builder the buffer
	 * 
	 * @return returnString the string
	 */
	protected static String removeDuplicateHeader(StringBuilder builder) {
		String string = builder.toString();
		if (isNullOrBlank(string)) {
			return string;
		}
		StringTokenizer tokenizer = new StringTokenizer(string, LINE_SEPARATOR);
		int headerLengh = tokenizer.nextToken().length();
		String header = string.substring(0, headerLengh);
		String body = string.replace(header, "");
		StringBuilder stringBuilder = new StringBuilder();
		if (!body.contains(header)) {
			stringBuilder.append(header).append(LINE_SEPARATOR);
		}
		stringBuilder.append(body);
		String returnString = stringBuilder.toString();
		return returnString;
	}

	/**
	 * Removes the headers.
	 *
	 * @param builder the builder
	 * @return the string
	 */
	protected static String removeHeaders(StringBuilder builder) {
		String string = builder.toString();
		if (isNullOrBlank(string)) {
			return string;
		}
		StringTokenizer tokenizer = new StringTokenizer(string, LINE_SEPARATOR);
		int headerLengh = tokenizer.nextToken().length();
		String header = string.substring(0, headerLengh);
		String body = string.replace(header, "");
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(body);
		String returnString = stringBuilder.toString();
		return returnString;
	}

	/**
	 * Throw message conversion exception.
	 * 
	 * @param message the message
	 */
	protected static void throwMessageConversionException(String message) {
		throw new MessageConversionException(message);
	}

	/**
	 * Instantiates a new abstract ecs message converter.
	 */
	public AbstractEcsMessageConverter() {
		super();
	}

	/**
	 * Populates outgoing message.
	 * 
	 * @param aRequest the request from client
	 * 
	 * @return the string
	 */
	public abstract String createMessage(IEcsRequest aRequest);

	/**
	 * Creates the message format.
	 * 
	 * @param message the message
	 * 
	 * @return the string
	 */
	public String createMessageFormat(Object[] message) {
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < message.length; i++) {
			buffer.append("{");
			buffer.append(i);
			buffer.append("}");
		}
		return ((new MessageFormat(buffer.toString())).format(message));
	}

	/**
	 * Produces response to client.
	 * 
	 * @param anInboundMessagePayload the an inbound message payload
	 * 
	 * @return IEcsResponse
	 */
	public abstract IEcsResponse createResponse(String anInboundMessagePayload);

	/**
	 * Produces response to client.
	 * 
	 * @param inboundMessagePayloads - list of inbound message payloads
	 * 
	 * @return IEcsResponse
	 */
	public IEcsResponse createResponseFromMultiplePayloads(
			List <String> inboundMessagePayloads) {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#fromMessage(javax.jms.Message)
	 */
	public final Object fromMessage(Message aMessage) {
		if (aMessage instanceof TextMessage) {
			throw new EcsInvalidResponseException(EXPECTED_ARG_TYPE
					+ TextMessage.class);
		}
		TextMessage aTextMsg = (TextMessage) aMessage;
		Object returnObject;
		try {
			returnObject = createResponse(aTextMsg.getText());
			return returnObject;
		}
		catch (JMSException e) {
			throw new EcsJmsException(e);
		}
	}

	/**
	 * Gets the code set element.
	 * 
	 * @param codeSetname the code setname
	 * @param codeSetElementCode the code set element code
	 * 
	 * @return the code set element
	 */
	protected CodeSetElement getCodeSetElement(String codeSetname,
			char codeSetElementCode) {
		return getCodeSetElement(codeSetname, BLANK + codeSetElementCode);
	}

	/**
	 * Gets the code set element.
	 * 
	 * @param codeSetname the code set name
	 * @param codeSetElementCode the code set element code
	 * 
	 * @return the code set element
	 */
	protected CodeSetElement getCodeSetElement(String codeSetname,
			String codeSetElementCode) {
		/*		if (codeSetElementCode == null
						|| BLANK.equals(codeSetElementCode.trim())) {
					return new CodeSetElement(BLANK, BLANK, BLANK);
				}
				else {*/
		return EcsConverterHelper.getCodeSetElement(codeSetname,
				codeSetElementCode, getCodeSetRegistrySingleton());
		/*		}*/
	}

	/**
	 * The purpose of this method is to create the code set element.
	 *
	 * @param licenceStatusCode the licence status code
	 * @return licence status display data
	 */
	public String getLicenceStatusDisplayData(String licenceStatusCode) {
		if ("DEN".equalsIgnoreCase(licenceStatusCode)) {
			return "DECEASED";
		}
		else if ("CAN".equalsIgnoreCase(licenceStatusCode)) {
			return "CANCELLED";
		}
		else if ("DED".equalsIgnoreCase(licenceStatusCode)) {
			return "DECEASED";
		}
		else if ("DIS".equalsIgnoreCase(licenceStatusCode)) {
			return "DISQUALIFIED";
		}
		else if ("ELG".equalsIgnoreCase(licenceStatusCode)) {
			return "ELIGIBLE";
		}
		else if ("EXP".equalsIgnoreCase(licenceStatusCode)) {
			return "EXPIRED";
		}
		else if ("LIC".equalsIgnoreCase(licenceStatusCode)) {
			return "LICENSED";
		}
		else if ("NOT".equalsIgnoreCase(licenceStatusCode)) {
			return "NOT LICENSED";
		}
		else if ("REV".equalsIgnoreCase(licenceStatusCode)) {
			return "REVOKED";
		}
		else if ("RPD".equalsIgnoreCase(licenceStatusCode)) {
			return "REPORT DECEASED";
		}
		else if ("SUS".equalsIgnoreCase(licenceStatusCode)) {
			return "SUSPENDED";
		}
		else if ("VAL".equalsIgnoreCase(licenceStatusCode)) {
			return "VALID";
		}
		else if ("OTH".equalsIgnoreCase(licenceStatusCode)) {
			return "OTHER NOT VALID";
		}
		else if (EaseUtil.isNullOrBlank(licenceStatusCode)) {
			return "UNKNOWN";
		}
		else if ("ELI".equalsIgnoreCase(licenceStatusCode)) {
			return "UNKNOWN (ELI)";
		}
		return licenceStatusCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.IMessageConverter#getMessageTcode()
	 */
	public String getMessageTcode() {
		return "TCOD";
		/*
		throw new EaseValidationException(
				"provide concreate implementation of getMessageTcode() in "
						+ this); */
	}

	/**
	 * Gets the update eye color code.
	 *
	 * @param eyeColor the eye color
	 * @return the update eye color code
	 */
	public String getUpdateEyeColorCode(String eyeColor) {
		if (!EaseUtil.isNullOrBlank(eyeColor)
				&& "BRO".equalsIgnoreCase(eyeColor)) {
			eyeColor = "BRN";
		}
		else if (!EaseUtil.isNullOrBlank(eyeColor)
				&& "HAZ".equalsIgnoreCase(eyeColor)) {
			eyeColor = "HZL";
		}
		return eyeColor;
	}

	/**
	 * Sets the code set registry singleton.
	 * 
	 * @param aCodeSetRegistrySingleton the new code set registry singleton
	 */
	public void setCodeSetRegistrySingleton(// method for spring injection
			ICodeSetRegistrySingleton aCodeSetRegistrySingleton) {
		//do nothing - should not be called
		//TODO remove
	}

	/**
	 * Sets the ecs message sources.
	 *
	 * @param aEcsMessageSources the new ecs message sources
	 */
	public void setEcsMessageSources(// method for spring injection
			ResourceBundleMessageSource aEcsMessageSources) {
		//should not be called
		//TODO remove
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	public final Message toMessage(Object anObject, Session aSession)
			throws JMSException, MessageConversionException {
		if (anObject instanceof IEcsRequest) {
			throw new MessageConversionException(EXPECTED_ARG_TYPE
					+ IEcsRequest.class);
		}
		IEcsRequest aRequest = (IEcsRequest) anObject;
		TextMessage message = aSession.createTextMessage();
		String header = null;
		String content = createMessage(aRequest);
		message.setText(header + content);
		return message;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractEcsMessageConverter.java,v $
 *  Revision 1.5  2017/12/22 18:34:32  mwwwc
 *  merge from branch to head for version 2.8.1.4
 *
 *  Revision 1.4.2.1  2017/12/22 00:19:09  mwsec2
 *  fixed isCommercialLicenseClassCode for RID defects 147, 149
 *
 *  Revision 1.4  2017/12/14 21:13:31  mwskh1
 *  Real ID - merge REAL_ID_EASE_2_8_1_1 branch to head for 2.8.1.3
 *
 *  Revision 1.3.10.1  2017/12/05 19:33:17  mwskh1
 *  Real ID defect 76 - fixed D921 and SearchByNumberConverter by adding the Real ID commercial permit codes K, L, Q
 *
 *  Revision 1.3  2016/02/18 20:17:49  mwskh1
 *  Motor Voter - merge to head
 *
 *  Revision 1.2.10.1  2016/01/14 17:02:27  mwskh1
 *  Motor Voter -added getUserId
 *
 *  Revision 1.2  2013/05/29 16:49:10  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *  Revision 1.1.6.3  2013/04/30 17:27:22  mwskh1
 *  CDLIS 5.2 - updated CDL PASSWORD comment
 *
 *  Revision 1.1.6.2  2013/04/25 17:23:13  mwskh1
 *  CDLIS 5.2 - added CDL Password
 *
 *  Revision 1.1.6.1  2013/04/17 21:10:56  mwgxd3
 *  CDLIS - add MMDDYYYY formatting
 *
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.151  2012/08/14 20:31:11  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.150  2011/12/23 17:39:34  mwhys
 *  Added isNullOrBlank(CodeSetElement).
 *
 *  Revision 1.149  2011/11/15 22:39:16  mwxxw
 *  Add new function : isNullOrBlank(Collection <?> collection)
 *
 *  Revision 1.148  2011/10/18 18:32:26  mwpxp2
 *  Merged 1.146.8. into head
 *
 *  Revision 1.147  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.146.8.2  2011/09/27 23:27:29  mwhys
 *  Removed userContext as a state variable.
 *
 *  Revision 1.146.8.1  2011/09/24 20:33:03  mwpxp2
 *  Added getters for statics; provided separate init methods for statics
 *
 *  Revision 1.146  2011/06/13 19:33:06  mwuxb
 *  Updated logic for class upgrade.
 *
 *  Revision 1.145  2011/06/09 17:45:25  mwyxg1
 *  clean up
 *
 *  Revision 1.144  2011/06/09 17:42:09  mwyxg1
 *  clean up
 *
 *  Revision 1.143  2011/05/13 17:36:55  mwhxb3
 *  Used constants instead of literals.
 *
 *  Revision 1.142  2011/05/07 00:08:27  mwtjc1
 *  utility methods are added to fix defect 631
 *
 *  Revision 1.141  2011/03/07 21:39:30  mwxxw
 *  Make the default tcode length to 4.
 *
 *  Revision 1.140  2011/01/24 19:16:06  mwsym2
 *  Committed on behalf of Prabhu Rajendran mwpxr5
 *  Fix for 3920
 *
 *  Revision 1.139  2011/01/20 23:09:41  mwhxb3
 *  Removed static modifier.
 *
 *  Revision 1.138  2011/01/20 19:43:26  mwhxb3
 *  Added utility methods for string conversions.
 *
 *  Revision 1.137  2011/01/15 00:47:10  mwpxr4
 *  Added unknown type for license class status
 *
 *  Revision 1.136  2011/01/13 02:05:23  mwpxr4
 *  Added logic to update eyecolor code if back-end returns BRO and HAZ
 *
 *  Revision 1.135  2010/12/23 06:10:40  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.134.2.4  2010/12/22 23:51:30  mwxxw
 *  Return just "TCODE" instead of "ECS_TCODE" for defualt message tcode.
 *
 *  Revision 1.134.2.3  2010/12/21 23:39:12  mwtjc1
 *  getCodeSetElement is updated not to create a new CodeSetElement with BLANK code
 *
 *  Revision 1.134.2.2  2010/12/21 23:02:11  mwhys
 *  Added null check in getCodeSetElement().
 *
 *  Revision 1.134.2.1  2010/12/20 23:02:07  mwhys
 *  Fixed getCodeSetElement method to return a valid codeSetElement when the code is a SPACE(S)/BLANK.
 *
 *  Revision 1.134  2010/12/15 01:10:28  mwxxw
 *  Return "ECS_TCODE" if the message tcode is not set.
 *
 *  Revision 1.133  2010/12/14 19:28:49  mwpxp2
 *  Made a couple of static utilities public to avoid compilation problems for now
 *
 *  Revision 1.132  2010/12/13 20:02:41  mwpxp2
 *  Added getMessageTcode/0 throwing exception
 *
 *  Revision 1.131  2010/12/10 19:33:46  mwhxb3
 *  Code to interface not implementation, used ICodeSetRegistrySingleton.
 *
 *  Revision 1.130  2010/12/08 21:23:49  mwpxr4
 *  Added isNullOrBlank(String string) method
 *
 *  Revision 1.129  2010/12/04 00:38:10  mwpxr4
 *  Added fillers as required.
 *
 *  Revision 1.128  2010/12/02 00:14:57  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.127  2010/11/22 23:34:44  mwpxr4
 *  Moved getLicenseStatusDisplayData to abstract converter class.
 *
 *  Revision 1.126  2010/11/03 16:49:13  mwyxg1
 *  remove dlaTo60U
 *
 *  Revision 1.125  2010/11/03 16:47:06  mwyxg1
 *  add dlaTo60U
 *
 *  Revision 1.124  2010/10/12 20:23:59  mwhys
 *  Removed keyword THIS, where it's not required.
 *
 *  Revision 1.123  2010/09/01 19:01:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.122  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.121  2010/08/03 17:34:43  mwtjc1
 *  formatMultiSegmentResponse added
 *
 *  Revision 1.120  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.119  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.113.2.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.118  2010/06/08 01:23:57  mwtjc1
 *  getCodeSetElementValue made protected
 *
 *  Revision 1.117  2010/06/08 01:23:26  mwtjc1
 *  getCodeSetElement updated
 *
 *  Revision 1.116  2010/06/07 20:53:18  mwtjc1
 *  getMessageFromResourceBundle is made public because it is used in AbstractEcsTestCase
 *
 *  Revision 1.115  2010/06/07 19:54:12  mwtjc1
 *  code in getMessageFromResourceBundle* methods is changed
 *
 *  Revision 1.114  2010/06/03 18:32:16  mwuxb
 *  updated for Tcode RP1
 *
 *  Revision 1.113  2010/05/29 19:45:19  mwtjc1
 *  updated to use EcsConverterHelper's constants
 *
 *  Revision 1.112  2010/05/26 01:56:17  mwpxp2
 *  Refactoring
 *
 *  Revision 1.111  2010/05/26 01:22:51  mwpxp2
 *  Cleanup
 *
 *  Revision 1.110  2010/05/20 17:11:22  mwtjc1
 *  place of LOGGER is moved
 *
 *  Revision 1.109  2010/05/19 23:45:29  mwtjc1
 *  Autowiring for CODE_SET_REGISTRY_SINGLETON and ecsMessageSources is replaced by get/set methods
 *
 *  Revision 1.108  2010/05/15 20:44:09  mwtjc1
 *  some issuance office ids are added in getIssuanceOffices
 *
 *  Revision 1.107  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.106  2010/05/11 01:12:18  mwjxa11
 *  Updated
 *
 *  Revision 1.105  2010/05/06 18:43:37  mwgxd3
 *  Add code to support $ amounts.
 *
 *  Revision 1.104  2010/05/05 20:21:32  mwtjc1
 *  updated
 *
 *  Revision 1.103  2010/05/05 18:36:15  mwtjc1
 *  updated
 *
 *  Revision 1.102  2010/05/04 01:25:59  mwtjc1
 *  updated
 *
 *  Revision 1.101  2010/05/04 00:55:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.100  2010/04/30 22:22:00  mwtjc1
 *  updated
 *
 *  Revision 1.99  2010/04/30 22:14:36  mwtjc1
 *  getIssuanceOffices method added
 *
 *  Revision 1.98  2010/04/30 21:04:58  mwtjc1
 *  updated
 *
 *  Revision 1.97  2010/04/28 17:54:46  mwtjc1
 *  updated
 *
 *  Revision 1.96  2010/04/27 22:08:37  mwrka1
 *  Temp Fixed
 *
 *  Revision 1.95  2010/04/26 20:58:15  mwjxa11
 *  Updated
 *
 *  Revision 1.94  2010/04/26 18:36:40  mwtjc1
 *  updated
 *
 *  Revision 1.93  2010/04/23 21:44:09  mwtjc1
 *  updated
 *
 *  Revision 1.92  2010/04/23 21:25:16  mwtjc1
 *  updated
 *
 *  Revision 1.91  2010/04/22 19:15:26  mwpxp2
 *  Added todo
 *
 *  Revision 1.90  2010/04/20 17:18:24  mwpxr4
 *  Added null checks for usercontext.
 *
 *  Revision 1.89  2010/04/19 22:37:08  mwtjc1
 *  updated
 *
 *  Revision 1.88  2010/04/19 21:33:44  mwtjc1
 *  getMessageFromResourceBundle method is updated
 *
 *  Revision 1.87  2010/04/19 21:23:02  mwtjc1
 *  updated
 *
 *  Revision 1.86  2010/04/19 21:09:21  mwtjc1
 *  updated
 *
 *  Revision 1.85  2010/04/19 20:50:44  mwtjc1
 *  ecsMessageSources variable is added
 *
 *  Revision 1.84  2010/04/19 19:02:33  mwpxr4
 *  Update to getCenturyIndicator.
 *
 *  Revision 1.83  2010/04/12 23:10:10  mwpxr4
 *  Updated century indicator logic.
 *
 *  Revision 1.82  2010/04/12 20:34:17  mwtjc1
 *  throwMessageConversionException method is added
 *
 *  Revision 1.81  2010/04/11 00:48:01  mwpxr4
 *  Moved generic methods from ELB converter to abstract converter.
 *
 *  Revision 1.80  2010/04/08 20:00:46  mwjxa11
 *  Updated
 *
 *  Revision 1.79  2010/04/08 18:09:32  mwhxb3
 *  Added method to check if it is not null.
 *
 *  Revision 1.78  2010/04/07 23:24:49  mwtjc1
 *  updated
 *
 *  Revision 1.77  2010/04/07 20:10:50  mwjxa11
 *  Updated
 *
 *  Revision 1.76  2010/04/07 19:53:41  mwjxa11
 *  Updated
 *
 *  Revision 1.75  2010/04/05 19:01:00  mwtjc1
 *  updated
 *
 *  Revision 1.74  2010/04/02 18:22:36  mwtjc1
 *  convertStringToDate method is changed
 *
 *  Revision 1.73  2010/04/02 00:07:27  mwtjc1
 *  updated
 *
 *  Revision 1.72  2010/04/01 23:22:58  mwakg
 *  Cleanup
 *
 *  Revision 1.71  2010/04/01 22:16:01  mwtjc1
 *  updated
 *
 *  Revision 1.70  2010/04/01 22:14:43  mwtjc1
 *  updated
 *
 *  Revision 1.69  2010/04/01 22:08:18  mwtjc1
 *  updated
 *
 *  Revision 1.68  2010/04/01 22:06:07  mwtjc1
 *  updated
 *
 *  Revision 1.66  2010/03/31 23:41:23  mwtjc1
 *  updated
 *
 *  Revision 1.65  2010/03/31 23:27:29  mwtjc1
 *  updated
 *
 *  Revision 1.64  2010/03/29 22:11:14  mwtjc1
 *  updated
 *
 *  Revision 1.63  2010/03/29 21:42:01  mwpxr4
 *  Added new method to determine class upgrade.
 *
 *  Revision 1.62  2010/03/29 16:43:25  mwtjc1
 *  getCentury method updated
 *
 *  Revision 1.61  2010/03/27 22:31:13  mwtjc1
 *  updated
 *
 *  Revision 1.60  2010/03/27 22:22:36  mwtjc1
 *  updated
 *
 *  Revision 1.59  2010/03/27 16:43:16  mwtjc1
 *  updated
 *
 *  Revision 1.58  2010/03/27 16:36:38  mwtjc1
 *  updated
 *
 *  Revision 1.57  2010/03/26 21:19:10  mwcsj3
 *  Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 *  Revision 1.56  2010/03/24 19:07:32  mwtjc1
 *  updated
 *
 *  Revision 1.55  2010/03/23 22:15:48  mwtjc1
 *  updated
 *
 *  Revision 1.54  2010/03/23 21:58:03  mwtjc1
 *  updated
 *
 *  Revision 1.53  2010/03/23 18:12:21  mwtjc1
 *  updated
 *
 *  Revision 1.52  2010/03/23 17:14:14  mwtjc1
 *  updated
 *
 *  Revision 1.51  2010/03/23 17:12:48  mwtjc1
 *  updated
 *
 *  Revision 1.50  2010/03/23 16:33:34  mwpxr4
 *  Added new Map for character(key) and numeric state codes.
 *
 *  Revision 1.49  2010/03/22 23:23:13  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.48  2010/03/22 20:15:02  mwrsk
 *  Removed codeset methods
 *
 *  Revision 1.47  2010/03/22 16:46:33  mwrsk
 *  Code cleanup
 *
 *  Revision 1.46  2010/03/20 22:13:41  mwtjc1
 *  updated
 *
 *  Revision 1.45  2010/03/20 18:35:33  mwtjc1
 *  updated
 *
 *  Revision 1.44  2010/03/20 18:34:58  mwtjc1
 *  convertToBoolean method is added
 *
 *  Revision 1.43  2010/03/20 17:54:12  mwtjc1
 *  updated
 *
 *  Revision 1.42  2010/03/20 17:22:02  mwtjc1
 *  updated
 *
 *  Revision 1.41  2010/03/20 17:13:43  mwtjc1
 *  updated
 *
 *  Revision 1.40  2010/03/18 21:59:49  mwtjc1
 *  updated
 *
 *  Revision 1.39  2010/03/18 21:56:58  mwtjc1
 *  isCommercialLicenseClassCode method is added
 *
 *  Revision 1.38  2010/03/18 21:22:52  mwtjc1
 *  addCodeSetElementInListIfCodeIsNotBlank(char code, List <CodeSetElement> codeSetElements) method added
 *
 *  Revision 1.37  2010/03/18 21:21:16  mwtjc1
 *  updated
 *
 *  Revision 1.36  2010/03/18 16:41:06  mwtjc1
 *  getCodeSetElementIfCodeIsNotBlank(char code) method is added
 *
 *  Revision 1.35  2010/03/18 14:20:18  mwrsk
 *  added new method getSpringBeanByName()
 *
 *  Revision 1.34  2010/03/18 14:17:19  mwrsk
 *  ALso now implements ApplicationContextAware
 *
 *  Revision 1.33  2010/03/18 00:39:34  mwtjc1
 *  getCodeSetElementWithBlankCodeIfCodeIsNullOrBlank method is added
 *
 *  Revision 1.32  2010/03/18 00:36:16  mwtjc1
 *  updated
 *
 *  Revision 1.31  2010/03/18 00:35:09  mwtjc1
 *  updated
 *
 *  Revision 1.30  2010/03/18 00:34:49  mwtjc1
 *  updated
 *
 *  Revision 1.29  2010/03/17 22:42:02  mwtjc1
 *  getCodeSetElementIfCodeIsNotBlank(String code, String description) method added
 *
 *  Revision 1.28  2010/03/17 22:36:17  mwtjc1
 *  updated
 *
 *  Revision 1.27  2010/03/17 22:20:09  mwtjc1
 *  addCodeSetElementInListIfCodeIsNotBlank method is added
 *
 *  Revision 1.26  2010/03/17 22:15:44  mwtjc1
 *  getCodeSetElementEvenIfCodeIsBlank method is removed
 *
 *  Revision 1.25  2010/03/17 22:12:16  mwtjc1
 *  getCodeSetElementEvenIfCodeIsBlank is added
 *
 *  Revision 1.24  2010/03/17 21:46:34  mwtjc1
 *  getCodeSetElementIfNotBlank method is added
 *
 *  Revision 1.23  2010/03/17 18:48:10  mwtjc1
 *  getCodeSetElement method is added
 *
 *  Revision 1.22  2010/03/17 01:14:11  mwtjc1
 *  updated
 *
 *  Revision 1.21  2010/03/17 01:04:04  mwtjc1
 *  updated
 *
 *  Revision 1.20  2010/03/17 01:01:16  mwtjc1
 *  updated
 *
 *  Revision 1.19  2010/03/17 00:58:30  mwtjc1
 *  updated
 *
 *  Revision 1.18  2010/03/16 22:39:48  mwtjc1
 *  updated
 *
 *  Revision 1.17  2010/03/16 21:31:00  mwtjc1
 *  updated
 *
 *  Revision 1.16  2010/03/16 21:22:26  mwtjc1
 *  STATECODES map is added
 *
 *  Revision 1.15  2010/03/16 15:53:57  mwtjc1
 *  updated
 *
 *  Revision 1.14  2010/03/16 01:09:16  mwtjc1
 *  convertStringToDate method is updated
 *
 *  Revision 1.13  2010/03/15 16:41:29  mwyxg1
 *  fix compilation errors
 *
 *  Revision 1.12  2010/03/11 22:21:44  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.10  2010/02/17 23:30:38  mwtjc1
 *  variable FORMATTER_YY is added
 *
 *  Revision 1.9  2010/02/17 21:29:48  mwtjc1
 *  isBlank method is added
 *
 *  Revision 1.8  2010/02/17 18:39:38  mwtjc1
 *  convertStringToInteger method is added
 *
 *  Revision 1.7  2010/02/16 17:40:29  mwtjc1
 *  isNull method is added
 *
 *  Revision 1.6  2010/01/25 22:32:23  mwtjc1
 *  some functions are made static to use them in UpdateHeadquartersSystemHelper class
 *
 *  Revision 1.5  2010/01/19 21:14:41  mwtjc1
 *  variable FORMATTER_HH_MM is added
 *
 *  Revision 1.4  2010/01/05 00:27:34  mwtjc1
 *  New method getWorkDate(IUserContext userContext, String format) is added
 *
 *  Revision 1.3  2009/11/25 23:35:22  mwtjc1
 *  FORMATTER_MM_DD static string variable is added
 *
 *  Revision 1.2  2009/11/23 19:21:57  mwtjc1
 *  FORMATTER_MM_DD_YYCC static string variable is added
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/10/28 22:29:43  mwcsj3
 *  Updated filler method
 *
 *  Revision 1.9  2009/10/22 16:25:11  mwrka1
 *  removeDuplicateHeader() updated
 *
 *  Revision 1.8  2009/10/14 22:05:58  mwrrv3
 *  Removed the trim() method (as per Rama).
 *
 *  Revision 1.7  2009/10/14 18:24:07  mwrrv3
 *  Fixed the issue with duplicate header (checked-in on behalf of Rama).
 *
 *  Revision 1.6  2009/10/13 18:27:38  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/10/07 20:37:43  mwtjc1
 *  unused methods are removed
 *
 *  Revision 1.4  2009/10/07 03:32:24  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:55:51  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:51:22  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:46  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.38  2009/10/03 21:23:40  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.37  2009/10/01 23:17:58  mwrka1
 *  condition added for null handling.
 *
 *  Revision 1.36  2009/09/29 18:20:02  mwrka1
 *  JavaDoc added
 *
 *  Revision 1.35  2009/09/29 18:08:59  mwrka1
 *  remove blank lines  and duplicate header in response string
 *
 *  Revision 1.34  2009/09/28 22:55:25  mwrka1
 *  removed blank lines in response string and request message should be one time in response
 *
 *  Revision 1.33  2009/09/02 23:11:41  mwrka1
 *  getFormatStringForScreen removed
 *
 *  Revision 1.32  2009/09/02 21:39:24  mwrka1
 *  getFormatStringForScreen method added
 *
 *  Revision 1.31  2009/09/02 01:25:11  mwpzs3
 *  Mutiple payload response handling
 *
 *  Revision 1.30  2009/08/27 05:54:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.29  2009/08/27 02:34:01  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.28  2009/08/26 20:05:18  mwrka1
 *  HEX_END_OF_TEXT constant removed
 *
 *  Revision 1.27  2009/08/25 21:23:22  mwrka1
 *  Hexa 'End of text'  constant added
 *
 *  Revision 1.26  2009/08/25 20:56:34  mwtjc1
 *  getRequestorCodeAndUserIdCombination and createMessageFormat utility methods are added.
 *
 *  Revision 1.25  2009/08/19 23:41:04  mwakg
 *  Refactored ttc from string to TypeTransactionCode class
 *
 *  Revision 1.24  2009/08/13 17:16:28  mwcsj3
 *  Updated convertStringToDate method
 *
 *  Revision 1.23  2009/08/10 22:42:57  mwpxp2
 *  Added logging
 *
 *  Revision 1.22  2009/08/10 19:26:48  mwakg
 *  Setting the results of ENI search to the process context
 *
 *  Revision 1.21  2009/08/07 01:49:43  mwazd1
 *  Added constant for mm/dd/yyyy format of date
 *
 *  Revision 1.20  2009/08/05 17:00:41  mwtjc1
 *  getWorkDate method is added
 *
 *  Revision 1.19  2009/08/04 22:32:28  mwpxp2
 *  Bulk cleanup; fixed method naming to follow guidelines
 *
 *  Revision 1.18  2009/08/04 21:34:10  mwazd1
 *  Checked date for null in convertDateToString method
 *
 *  Revision 1.17  2009/08/03 23:08:51  mwtjc1
 *  trim() is added in getErrorCode method
 *
 *  Revision 1.16  2009/08/03 21:30:26  mwtjc1
 *  getOfficeID method is added
 *
 *  Revision 1.15  2009/08/03 21:15:36  mwakg
 *  Restructed code for ANI
 *
 *  Revision 1.14  2009/07/30 01:31:21  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2009/07/30 01:26:17  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.12  2009/07/27 18:28:21  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.11  2009/07/27 17:29:56  mwpxp2
 *  Made utility methods static; added logger; renamed method to reflect their function
 *
 *  Revision 1.10  2009/07/16 23:35:10  mwtjc1
 *  filler method is changed to put right condition for left and right justification
 *
 *  Revision 1.9  2009/07/16 18:24:17  mwtjc1
 *  filler method is changed to avoid nullpointerexception, if inputString is null.
 *  It is changed to support both left and right padding.
 *
 *  Revision 1.8  2009/07/16 17:05:28  mwsmg6
 *  removed dependency on obsolete StringFormatter and non-Ecs response
 *
 *  Revision 1.7  2009/07/16 01:58:35  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.6  2009/07/16 01:45:10  mwcsj3
 *  Added get current time method
 *
 *  Revision 1.5  2009/07/16 01:13:01  mwpxp2
 *  Bulk cleanup, including imports
 *
 *  Revision 1.4  2009/07/15 23:42:52  mwakg
 *  Code review of receipt converter
 *
 *  Revision 1.3  2009/07/15 20:18:30  mwtjc1
 *  isBlank and getNonEmptyString methods are added
 *
 *  Revision 1.2  2009/07/15 17:44:42  mwtjc1
 *  fillSuffix method is added
 *
 *  Revision 1.1  2009/07/14 23:58:49  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:08:12  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.10  2009-05-18 16:08:51  ppalacz
 *  Javadoc update
 *
 *  Revision 1.9  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.8  2009-05-11 17:43:01  mwpxp2
 *  Cleaned up
 *
 *  Revision 1.7  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.6  2009-05-11 07:31:48  mwpxp2
 *  Synch
 *
 *  Revision 1.5  2009-05-10 19:38:35  mwpxp2
 *  Synch
 *
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
