/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.auth.response.IAuthorizeApproverResponse;
import gov.ca.dmv.ease.tus.auth.service.impl.AuthAndAuthService;

/**
 * Description: I am an AuthAndAuth request
 * 
 * File: AuthorizeApproverRequest.java
 * Module:  gov.ca.dmv.ease.tus.auth.request.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuthorizeApproverRequest extends AuthAndAuthServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3016449705052657744L;
	private String userName;
	private String password;
	private String approverRole;
	private String officeId;

	/**
	 * The Constructor.
	 * 
	 * @param userContext
	 * @param userName
	 * @param password
	 * @param approverRole
	 */
	public AuthorizeApproverRequest(IUserContext userContext, String userName,
			String password, String approverRole) {
		super(userContext);
		this.userName = userName;
		this.password = password;
		this.approverRole = approverRole;
	}

	/**
	 * The Constructor.
	 * 
	 * @param userContext
	 * @param userName
	 * @param password
	 * @param approverRole
	 * @param officeId
	 */
	public AuthorizeApproverRequest(IUserContext userContext, String userName,
			String password, String approverRole, String officeId) {
		super(userContext);
		this.userName = userName;
		this.password = password;
		this.approverRole = approverRole;
		this.officeId = officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.impl.IAuthAndAuthServiceRequest#execute()
	 */
	@Override
	public IAuthorizeApproverResponse execute() {
		return AuthAndAuthService.getInstance().execute(this);
	}

	/**
	 * Gets the user name.
	 * 
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Gets the password.
	 * 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Gets the approver role.
	 * 
	 * @return the approver role
	 */
	public String getApprovalRole() {
		return approverRole;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuthorizeApproverRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
