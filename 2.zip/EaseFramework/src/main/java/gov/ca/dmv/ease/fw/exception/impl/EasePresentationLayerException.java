/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am abstract superclass for presentation-related exceptions
 * File: EasePresentationLayerException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EasePresentationLayerException extends EaseLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5941054628802978236L;

	/**
	 * Instantiates a new ease presentation layer exception.
	 */
	public EasePresentationLayerException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EasePresentationLayerException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EasePresentationLayerException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EasePresentationLayerException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EasePresentationLayerException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
