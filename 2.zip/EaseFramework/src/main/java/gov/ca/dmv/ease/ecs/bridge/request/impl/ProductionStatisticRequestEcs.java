/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.bridge.request.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.convert.impl.ProductionStatisticsConverter;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * The purpose of this class is to define the behavior of 
 * constructing the message for production statistics message.
 *   
 * File: ProductionStatisticRequestEcs.java
 * Module:  gov.ca.dmv.ease.ecs.request.prodctionstatistic.impl
 * Created: July 17, 2010 
 * @author MWSZM12 
 * @version $Revision: 1.1 $
 */
public class ProductionStatisticRequestEcs extends BridgeRequest {
	/**
	 * Serial UID 
	 */
	private static final long serialVersionUID = -1632512667713874348L;
	/** The cashier sequence nbr. */
	private String cashierSequenceNbr;
	/** The completion code. */
	private String completionCode;
	/** The dl or id indicator. */
	private String dlOrIdIndicator;
	/** The ttc. */
	private String ttc;

	/**
	 * @param context
	 */
	public ProductionStatisticRequestEcs(IUserContext context) {
		super(context);
	}

	/**
	 * @param anId
	 * @param context
	 */
	public ProductionStatisticRequestEcs(String anId, IUserContext context) {
		super(anId, context);
	}

	/**
	 * Instantiates a new production statistic request ecs.
	 * 
	 * @param anId 
	 * @param userContext 
	 * @param messageIdentifier 
	 */
	public ProductionStatisticRequestEcs(String anId, IUserContext userContext,
			String messageIdentifier) {
		super(anId, userContext, messageIdentifier);
	}

	/**
	 * Instantiates a new production statistics request.
	 * 
	 * @param aUserContext 
	 * @param aCompletionCode 
	 * @param aCachierSequenceNbr 
	 * @param aDlOrIdIndicator 
	 * @param aTtc 
	 */
	public ProductionStatisticRequestEcs(IUserContext aUserContext,
			String aCompletionCode, String aCachierSequenceNbr,
			String aDlOrIdIndicator, String aTtc) {
		super(aUserContext);
		setCompletionCode(aCompletionCode);
		setCashierSequenceNbr(aCachierSequenceNbr);
		setDlOrIdIndicator(aDlOrIdIndicator);
		setTtc(aTtc);
	}

	/**
	 * 
	 * 
	 * @return the cashierSequenceNbr
	 */
	public String getCashierSequenceNbr() {
		return cashierSequenceNbr;
	}

	/**
	 * 
	 * 
	 * @return the completionCode
	 */
	public String getCompletionCode() {
		return completionCode;
	}

	/**
	 * 
	 * 
	 * @return the dlOrIdIndicator
	 */
	public String getDlOrIdIndicator() {
		return dlOrIdIndicator;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#getMessageConverter()
	 */
	@Override
	public IMessageConverter getMessageConverter() {
		return ProductionStatisticsConverter.getInstance();
	}

	/**
	 * 
	 * 
	 * @return the ttc
	 */
	public String getTtc() {
		return ttc;
	}

	/**
	 * 
	 * 
	 * @param cachierSequenceNbr 
	 */
	public void setCashierSequenceNbr(String cachierSequenceNbr) {
		this.cashierSequenceNbr = cachierSequenceNbr;
	}

	/**
	 * 
	 * 
	 * @param completionCode the completionCode to set
	 */
	public void setCompletionCode(String completionCode) {
		this.completionCode = completionCode;
	}

	/**
	 * 
	 * 
	 * @param dlOrIdIndicator the dlOrIdIndicator to set
	 */
	public void setDlOrIdIndicator(String dlOrIdIndicator) {
		this.dlOrIdIndicator = dlOrIdIndicator;
	}

	/**
	 * 
	 * 
	 * @param ttc the ttc to set
	 */
	public void setTtc(String ttc) {
		this.ttc = ttc;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ProductionStatisticRequestEcs.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2011/10/12 20:56:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.4.8.1  2011/09/26 23:21:26  mwpxp2
 *  Modified for singleton converter
 *
 *  Revision 1.4  2011/06/10 21:32:17  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/12/10 03:29:49  mwpxp2
 *  REmoved erroneous shadowing of user context from super
 *
 *  Revision 1.2  2010/12/10 02:20:47  mwpxp2
 *  Added more fields as needed by the triggering aspect
 *
 *  Revision 1.1  2010/09/22 18:18:05  mwpxp2
 *  Moved in to bridge-specific package
 *
 */
