/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

/**
 * Description: I represent the request to retrieve object from the persistent store
 * 
 * File: RetrieveDomainObjectRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request
 * Created: May 8, 2009
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveBusinessObjectRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1124635122100284359L;
	/** The domain object. */
	private IBusinessObject businessObject;

	/**
	 * Instantiates a new retrieve business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public RetrieveBusinessObjectRequest(IUserContext userContext,
			IBusinessObject businessObject) {
		super(userContext);
		this.businessObject = businessObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public RetrieveBusinessObjectResponse execute() {
		return getPersistenceService().execute(this);
	}

	/**
	 * This method gets the business object based on which the search has to be done.
	 * 
	 * @return the businessObject BusinessObject to be searched on
	 */
	public IBusinessObject getBusinessObject() {
		return businessObject;
	}
}
/**
 * Modification History:
 * 
 * $Log: RetrieveBusinessObjectRequest.java,v $
 * Revision 1.1  2012/10/01 02:57:19  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.3  2010/09/14 00:40:33  mwkfh
 * made persistenceService non-static
 *
 * Revision 1.2  2010/09/13 04:39:45  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.8  2009/10/12 16:23:23  mwrsk
 * Add class description
 *
 * Revision 1.7  2009/10/03 21:32:44  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.6  2009/09/03 22:35:02  mwrsk
 * refactor code
 *
 * Revision 1.5  2009/08/27 03:45:06  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.4  2009/08/26 00:07:58  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2009/08/06 21:28:57  mwakg
 * Merging from MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 *
 * Revision 1.2.2.1  2009/08/06 16:25:17  mwakg
 * Changed the design of PersistenceService. Instead of working with BusinessObject PersistenceService is now working with IBusinessObject
 *
 * Revision 1.2  2009/08/05 20:40:17  mwrsk
 * Refactored code to make persistence service work
 *
 * Revision 1.1  2009/07/29 16:56:59  mwakg
 * Changed the design of persistence service hence refractored code accordingly
 *
 * Revision 1.4  2009/07/21 21:47:33  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2009/07/15 01:08:50  mwpxp2
 * Fixed arg type in 1-arg constructor
 *
 * Revision 1.2  2009/07/15 01:03:45  mwbxp5
 * Removed the UserContext from the constructor
 *
 * Revision 1.1  2009/07/15 00:59:41  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.2  2009-07-12 18:17:46  mwpxp2
 * Imports adjusted
 *
 * Revision 1.1  2009-07-11 17:18:49  mwpxp2
 * Moved to .impl package; changed superclass; cleaned up comments and javadoc; added todos
 *
 * Revision 1.1  2009-07-10 07:13:56  mwpxp2
 * Synch
 * Revision 1.1 May 6, 2009 4:34:26
 * PM MWAKG Initial commit
 * 
 */
