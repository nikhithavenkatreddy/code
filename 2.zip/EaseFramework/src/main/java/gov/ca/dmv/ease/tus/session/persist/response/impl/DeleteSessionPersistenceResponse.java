/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response class for deleting a session.
 * File: DeleteSessionPersistenceResponse.java
 * Module:  gov.ca.dmv.ease.tus.session.persist.response.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DeleteSessionPersistenceResponse extends
		SessionPersistenceResponse {
	/** The serialVersionUID */
	private static final long serialVersionUID = 5756927097696518552L;

	/**
	 * Instantiates a new persistence service response.
	 */
	public DeleteSessionPersistenceResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public DeleteSessionPersistenceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public DeleteSessionPersistenceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param aCollector the a collector
	 * @param anItemCount the an item count
	 */
	public DeleteSessionPersistenceResponse(IErrorCollector aCollector,
			Integer anItemCount) {
		super(aCollector, anItemCount);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param anItemCount the an item count
	 */
	public DeleteSessionPersistenceResponse(Integer anItemCount) {
		super(anItemCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DeleteSessionPersistenceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/01/10 19:20:46  mwkfh
 *  update the description
 *
 *  Revision 1.2  2012/01/10 19:19:47  mwkfh
 *  removed implements
 *
 *  Revision 1.1  2012/01/06 19:34:48  mwkfh
 *  Initial
 *
 */
