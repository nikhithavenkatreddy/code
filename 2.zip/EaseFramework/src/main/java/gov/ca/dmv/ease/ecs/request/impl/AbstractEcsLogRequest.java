/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am abstract implementation for all concrete logging-related requests.
 * File: AbstractEcsLogRequest.java
 * Module:  gov.ca.dmv.ease.tus.log.request.impl
 * Created: 19/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractEcsLogRequest extends FireAndForgetEcsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1034830563337700935L;
	/** The log entry. */
	private String logEntry;

	/**
	 * Instantiates a new abstract log request.
	 */
	protected AbstractEcsLogRequest() {
		super();
	}

	/**
	 * The Constructor - Instantiates the log request using a request id, user context, and a log entry.
	 * 
	 * @param anId Id of the request
	 * @param context the context
	 * @param aLogEntry the a log entry
	 */
	public AbstractEcsLogRequest(String anId, IUserContext context,
			String aLogEntry) {
		super(anId, context);
		setLogEntry(aLogEntry);
	}

	/**
	 * Gets the log entry.
	 * 
	 * @return logEntry the log entry
	 */
	public String getLogEntry() {
		return logEntry;
	}

	/**
	 * Checks if is log request.
	 * 
	 * @return true, if is log request
	 */
	@Override
	public final boolean isLogRequest() {
		return true;
	}

	/**
	 * Sets the log entry.
	 * 
	 * @param logEntry the new log entry
	 */
	protected void setLogEntry(String logEntry) {
		this.logEntry = logEntry;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractEcsLogRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:26:38  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/03 02:03:54  mwpxp2
 *  Added isLogRequest/0
 *
 *  Revision 1.3  2009/10/13 20:52:24  mwhxb3
 *  updated comments.
 *
 *  Revision 1.2  2009/10/06 21:53:01  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:54:06  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:37  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/10/03 21:23:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 02:33:53  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/04 22:42:05  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/27 18:48:15  mwpxp2
 *  Renamed to insert "Dcs" into the name
 *
 *  Revision 1.2  2009/07/27 17:17:54  mwaxb1
 *  Updated as per feedback on v0.11 design document.
 *
 *  Revision 1.1  2009-07-20 13:25:35  mwpxp2
 *  Initial
 *
 */
