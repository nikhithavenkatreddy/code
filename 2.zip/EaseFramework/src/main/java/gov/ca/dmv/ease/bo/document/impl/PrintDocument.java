/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

/** 
 * Description: This class represents Document to Print.
 * File: PrintDocument.java
 * Module:  gov.ca.dmv.ease.bo.document
 * Created: May 4, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PrintDocument extends NonSupportingDocument {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4305146447387202861L;
}
/**
 *  Modification History:
 * 
 *  $Log: PrintDocument.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/06/13 20:31:16  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2010/12/07 02:52:22  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.6  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/03/22 23:18:10  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/02/09 18:54:36  mwhxa2
 *  a. Moved to Architecture
 *        SupportingDocument
 *        NonSupportingDocument
 *  b. PrintDocument extends NonSupportingDocument instead of Document
 *
 *  Revision 1.3  2010/02/08 22:12:51  mwrsk
 *  Remove DocumentType Changes
 *
 *  Revision 1.2  2010/01/11 21:40:32  mwhxa2
 *  Updated constructor
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/10/15 22:22:48  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.9  2009/10/15 17:47:35  mwrka1
 *  removed default constructor
 *
 *  Revision 1.8  2009/10/13 17:26:18  mwtjc1
 *  getValidator method is made public
 *
 *  Revision 1.7  2009/10/03 21:06:31  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/29 22:06:06  mwhxa2
 *  Extends BaseBusinessObject
 *
 *  Revision 1.5  2009/08/27 05:39:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/22 23:19:33  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.3  2009/08/04 20:52:26  mwyxg1
 *  add constructor
 *
 *  Revision 1.2  2009/07/14 23:44:33  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  
 *  $Revision 1.1  May 4, 2009 10:53:19 AM  MWCSJ3
 *  $Initial
 *  $
*/
