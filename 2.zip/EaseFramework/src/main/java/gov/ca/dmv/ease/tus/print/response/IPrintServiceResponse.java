package gov.ca.dmv.ease.tus.print.response;

import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;

import java.util.Date;

/**
 * Description: I am interface for responses to print requests
 * 
 * File: IPrintServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response
 * Created: Aug 25, 2012 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPrintServiceResponse {
	/**
	 * Gets the Client Job Id.
	 * 
	 * @return the clientJobId
	 */
	String getClientJobId();

	/**
	 * Gets the Print Execution Status.
	 * 
	 * @return the printExecutionStatus
	 */
	String getPrintExecutionStatus();

	/**
	 * Gets the request.
	 *
	 * @return the request
	 */
	IPrintServiceRequest getRequest();

	/**
	 * @return the requestedTime
	 */
	Date getRequestedTime();

	/**
	 * Gets the print execution status.
	 * 
	 * @return the print execution status
	 */
	boolean isPrintExecuted();
}
/**
 *  Modification History:
 *
 *  $Log: IPrintServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/08/25 17:56:34  mwpxp2
 *  Initial - refactored out from existing implementation
 *
 */
