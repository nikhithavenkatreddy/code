/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am exception to be used when a response is accessed when none can be provided.
 * 
 * File: EcsNoResponseExpectedException.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: Dec 8, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsNoResponseExpectedException extends EcsValidationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6335604128349968999L;

	public EcsNoResponseExpectedException() {
		super();
	}

	/**
	 * @param message
	 */
	public EcsNoResponseExpectedException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public EcsNoResponseExpectedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public EcsNoResponseExpectedException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsNoResponseExpectedException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/08 19:09:37  mwpxp2
 *  Initial
 *
 */
