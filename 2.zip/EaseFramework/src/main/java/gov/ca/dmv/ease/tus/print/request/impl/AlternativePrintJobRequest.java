/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.print.response.impl.PrintServiceResponse;
import gov.ca.dmv.ease.tus.print.service.impl.PrintService;

/**
 * Description: //TODO - provide description!
 * File: AlternativePrintJobRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: Jun 1, 2011 
 * @author MWRKA1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AlternativePrintJobRequest extends AbstractPrintServiceRequest {
	private String clientJobId;

	/**
	 * @return the clientJobId
	 */
	public String getClientJobId() {
		return clientJobId;
	}

	/**
	 * @param clientJobId the clientJobId to set
	 */
	public void setClientJobId(String clientJobId) {
		this.clientJobId = clientJobId;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -4576577047115777572L;

	/**
	 * @param context
	 */
	public AlternativePrintJobRequest(IUserContext context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public AlternativePrintJobRequest(String clientJobId, IUserContext aContext) {
		super(aContext);
		setClientJobId(clientJobId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.impl.AbstractPrintServiceRequest#execute()
	 */
	@Override
	public PrintServiceResponse execute() {
		return PrintService.execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AlternativePrintJobRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/06/02 17:23:15  mwrka1
 *  added alternative printer functionalty
 *
 */
