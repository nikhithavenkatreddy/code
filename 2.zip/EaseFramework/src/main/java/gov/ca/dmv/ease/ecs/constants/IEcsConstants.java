/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.constants;

import java.util.Arrays;
import java.util.List;

/**
 * Description: Contains common constants used in ECS.
 * File: IEcsConstants.java
 * Module:  gov.ca.dmv.ease.ecs
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2013/09/03 18:03:40 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface IEcsConstants {
	/** Expiration timestamp for asynchronous promise, 69 secs*/
	long CASH_PROMISE_EXPIRATION_MSEC = 69000;
	/** The wait time between persistence calls, 0.5 sec. */
	long CASH_PROMISE_WAIT_TIME_MSEC = 500;
	/** The wait time between persistence calls, 0.5 sec. */
	long FINGER_PRINT_RESPONSE_WAIT_TIME_MSEC = 5000;
	/**Constant for CNA Long Term message. */
	String CNA_LONG_TERM_MESSAGE = "Q022";
	/**Constant for CNA Short Term message. */
	String CNA_SHORT_TERM_MESSAGE = "Q023";
	/** The Constant COUNTYCODE_LENGTH. */
	int COUNTYCODE_LENGTH = 2;
	/** The DEFAUL t_ encoding. */
	String DEFAULT_ENCODING = "8859_1";
	/** Undefined int value. */
	int ECS_UNDEF_INT = -1;
	/** The Constant EMPLOYEEID_LENGTH. */
	int EMPLOYEEID_LENGTH = 2;
	/** The Constant LICENSENUMBER_LENGTH. */
	int LICENSENUMBER_LENGTH = 8;
	/** The Constant OFFICEID_LENGTH. */
	int OFFICEID_LENGTH = 3;
	/** Constant for resource problem message. */
	String RESOURCE_PROBLEM_MESSAGE = "0222";
	/** Indicates that current segment is the final one in response.*/
	String SEGMENT_INDICATOR_FINAL = "F";
	/** Indicates that current segment is the only one in response.*/
	String SEGMENT_INDICATOR_ONLY = "O";
	/** The Constant SSNNUMBER_LENGTH. */
	int SSNNUMBER_LENGTH = 9;
	/** Constant for Transaction Unavailable.*/
	String TRANSACTION_UNAVAILABLE = "TUVA";
	/** threshold for logging slow response times */
	long SLOW_RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS = 5;
	
	/** 'bad response' messages (EASE may receive these archaic 13-byte messages from CAMV)*/
	String VR_DB_DOWN = 			"VR DATA BASE";
	String SYS_DOWN = 				"SYSTEM DOWN";
	String DL_DB_DOWN = 			"DL DATA BASE";
	String ANI_DB_DOWN = 			"ANI DATA BAS";
	String TEST_COMPUTER_DOWN = 	"TEST COMPUTE";
	String CNA = 					"COMMUNICATIO";
	String NO_RESPONSE = 			"NO RESPONSE";
	String INVALID_PAGE_REQUEST = 	"INVALID PAGE";
	String STAT_ID_NOT_IN_DCS_TABL ="S/1 SENT BAD";
	String FMAT =					"FMAT";
	String TUVA =					"TUVA";
	String TRCD =					"TRCD";
	String UNAUTHORIZED =			"ERROR UNAUTH";
	String EXCESSIVE_BACKSPACES =	"EXCEEDED BAC";
	String ILLEGAL_BACKSPACE = 		"ILLEGAL BACK";
	String SYSTEM_OVERLOAD = 		"SYSTEMS OVER";
	String UNAUTHORIZED_T_CODE = 	"ERROR-UNAUTH";
	String T_CODE_INACTIVE = 		"TRANSACTION";
	String INQ_NOT_WITHIN_TIME =	"INQUIRY NOT"; // INQUIRY NOT WITHIN ASSIGNED TIME
	String INVALID_RQST_FOR_TERM =	"SET-INVALID";
	String NO_PRINTER_FOR_TERM =	"NO PRINTER A";
	String RESUBMIT_IN_24HRS =		"PROGRAM ERRO";
	String NAME_INQ_NOT_SUPPORTED =	"NAM INQUIRY";
	String DMV_SYSTEM_DOWN =		"DMV SYSTEM D";
	String QUEUE_OVERFLOW = 		"QUEUE OVERFL";
	String INVALID_LENGTH = 		"INVALID LENG";
	String INVALID_T_CODE =			"INVALID T-CO";
	String DEVICE_TEST_MODE = 		"DEVICE TEST";
	String DEVICE_PROD_MODE = 		"DEVICE PROD";
	String INVALID_DL =				"INVALID DRIV";
	String LIC_NUMBER_INVALID = 	"LIC NUMBER I";
	String INVALID_STAT_CODE =		"INVALID STAT";
	String INVALID_INPUT =			"INVALID INPU";
	
	List <String> BAD_RESPONSE_MSGS = Arrays.asList(VR_DB_DOWN, SYS_DOWN, DL_DB_DOWN, ANI_DB_DOWN, TEST_COMPUTER_DOWN,
			CNA, NO_RESPONSE, INVALID_PAGE_REQUEST, STAT_ID_NOT_IN_DCS_TABL, FMAT, TUVA, TRCD, UNAUTHORIZED,
			EXCESSIVE_BACKSPACES, ILLEGAL_BACKSPACE, SYSTEM_OVERLOAD, UNAUTHORIZED_T_CODE, T_CODE_INACTIVE,
			INQ_NOT_WITHIN_TIME, INVALID_RQST_FOR_TERM, NO_PRINTER_FOR_TERM, RESUBMIT_IN_24HRS, NAME_INQ_NOT_SUPPORTED,
			DMV_SYSTEM_DOWN, QUEUE_OVERFLOW, INVALID_LENGTH, INVALID_T_CODE, DEVICE_TEST_MODE, DEVICE_PROD_MODE,
			INVALID_DL, LIC_NUMBER_INVALID, INVALID_STAT_CODE, INVALID_INPUT);

}
/**
 *  Modification History:
 *
 *  $Log: IEcsConstants.java,v $
 *  Revision 1.3  2013/09/03 18:03:40  mwsec2
 *  added 'bad response' string constants and list
 *
 *  Revision 1.2  2012/10/08 20:24:39  mwsec2
 *  added SLOW_RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS
 *
 *  Revision 1.11  2011/08/12 18:25:09  mwhys
 *  Added CNA_LONG_TERM_MESSAGE.
 *
 *  Revision 1.10  2011/07/28 21:31:58  mwxxw
 *  Add new constant: FINGER_PRINT_RESPONSE_WAIT_TIME_MSEC.
 *
 *  Revision 1.9  2011/07/17 01:23:20  mwhys
 *  Updated the value of CASH_PROMISE_WAIT_TIME_MSEC.
 *
 *  Revision 1.8  2011/07/16 04:35:42  mwhys
 *  Added CASH_PROMISE_WAIT_TIME_MSEC.
 *
 *  Revision 1.7  2010/11/09 04:37:55  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/10/01 17:26:46  mwpxr4
 *  increased expiration duration for asynchronous promise.
 *
 *  Revision 1.5  2010/09/21 18:48:10  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.4.8.1  2010/09/17 21:38:35  mwpxr4
 *  Added new constants.
 *
 *  Revision 1.4  2010/08/14 23:01:48  mwcsj3
 *  Updated constants
 *
 *  Revision 1.3  2010/05/26 01:17:47  mwpxp2
 *  Added DEFAULT_ENCODING
 *
 *  Revision 1.2  2010/03/22 23:22:54  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/15 23:28:13  mwhxa2
 *  Removed redundant modifiers
 *
 *  Revision 1.2  2009/10/14 20:15:15  mwhxb3
 *  refactored the constant DCS_UNDEF_INT to ECS_UNDEF_INT
 *
 *  Revision 1.1  2009/10/14 20:09:46  mwhxb3
 *  changes due to renaming IDcsConstants to IEcsConstants.
 *
 *  Revision 1.13  2009/10/13 18:19:23  mwhxb3
 *  updated comments.
 *
 *  Revision 1.12  2009/10/03 21:23:42  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/09/30 21:28:08  mwsmg6
 *  Corrected ragahava's omission of Bhirud's changes
 *
 *  Revision 1.10  2009/09/30 20:49:15  mwrrv3
 *  Added constant for RESOURCE_PROBLEM_MESSAGE.
 *
 *  Revision 1.9  2009/09/25 21:29:25  mwrrv3
 *  Added constant for CNA.
 *
 *  Revision 1.8  2009/09/23 23:28:39  mwrrv3
 *  Added constant for DCS transaction unavailable.
 *
 *  Revision 1.7  2009/08/05 01:37:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/07/27 18:27:44  mwpxp2
 *  Renamed  UNDEF_INT to DCS_UNDEF_INT
 *
 *  Revision 1.5  2009/07/16 01:49:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/07/16 01:04:46  mwpxp2
 *  Bulk cleanup, including imports
 *
 *  Revision 1.3  2009/07/14 23:58:53  mwpxp2
 *  Initial move to hnode20
 *
 *
 *  Revision 1.1  2009-05-12 21:35:01  ppalacz
 *  Initial
 *
*/
