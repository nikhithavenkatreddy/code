/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.request.impl.SynchronousEcsRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.ts.print.convert.GenerateDocumentConverter;
import gov.ca.dmv.ease.tus.print.response.impl.GenerateDocumentResponse;

/**
 * Description: Request class for GenerateDocumentRequest.
 * File: GenerateDocumentRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: 2009
 * 
 * @author MWRRV2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class GenerateDocumentRequest extends SynchronousEcsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8861234524429210521L;
	/** The xml data. */
	private String xmlData;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 * @param xmlData the xml data
	 */
	public GenerateDocumentRequest(IUserContext userContext, String xmlData) {
		super.setUserContext(userContext);
		setXmlData(xmlData);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.SynchronousEcsRequest#execute()
	 */
	@Override
	public GenerateDocumentResponse execute() throws EcsServiceException {
		return (GenerateDocumentResponse) super.execute();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#getMessageConverter()
	 */
	@Override
	public IMessageConverter getMessageConverter() {
		return new GenerateDocumentConverter();
	}

	/**
	 * Gets the xml data.
	 * 
	 * @return the xmlData
	 */
	public String getXmlData() {
		return xmlData;
	}

	/**
	 * Sets the xml data.
	 * 
	 * @param xmlData the xmlData to set
	 */
	public void setXmlData(String xmlData) {
		this.xmlData = xmlData;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: GenerateDocumentRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/18 21:04:29  mwtjc1
 *  unnecessary constructor and comments are removed
 *
 *  Revision 1.3  2010/05/17 21:58:22  mwhxb3
 *  Added  settter and getter for xmlData.
 *
 *  Revision 1.2  2010/05/10 16:22:20  mwhxb3
 *  Extends SynchronousEcsRequest.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/14 00:27:01  mwjxa11
 *  Refactored
 *
 *  Revision 1.6  2009/10/03 21:32:41  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/08/27 06:29:27  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.4  2009/08/27 04:53:17  mwpxp2
 *  Fxied argument type in  constructor/1
 *
 *  Revision 1.3  2009/08/27 03:31:33  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/07/21 21:45:35  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:44  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 18:18:27  mwpxp2
 *  Imports adjusted
 *
 *  Revision 1.1  2009-07-11 17:40:31  mwpxp2
 *  Moved to .impl package; cleaned up comments and javadoc; added todos
 *
 */
