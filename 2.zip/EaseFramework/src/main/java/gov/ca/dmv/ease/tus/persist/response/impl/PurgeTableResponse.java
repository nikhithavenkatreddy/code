/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response to PurgeTableRequest
 * File: PurgeTableResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Oct 23, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/23 23:37:32 $
 * Last Changed By: $Author: mwkfh $
 */
public class PurgeTableResponse extends PersistenceServiceResponse {
	/** The serialVersionUID */
	private static final long serialVersionUID = -6428827494973195269L;

	/**
	 * Instantiates a new delete business object response.
	 */
	public PurgeTableResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public PurgeTableResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param ex the ex
	 */
	public PurgeTableResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public PurgeTableResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public PurgeTableResponse(IErrorCollector collector, int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public PurgeTableResponse(int anItemCount) {
		super(anItemCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PurgeTableResponse.java,v $
 *  Revision 1.1  2012/10/23 23:37:32  mwkfh
 *  Initial
 *
 */
