/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: It is used to throw Document Generation related exceptions.
 * File: DocumentGeneratorException.java
 * Module:  gov.ca.dmv.ease.docgen.exception
 * Created: May 26, 2010
 * 
 * @author MWTJC1
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DocumentGeneratorException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6828294865049511267L;

	/**
	 * Instantiates a new jms exception.
	 */
	public DocumentGeneratorException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param arg0 the arg0
	 */
	public DocumentGeneratorException(String arg0) {
		super(arg0);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public DocumentGeneratorException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public DocumentGeneratorException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DocumentGeneratorException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/05/26 17:26:39  mwtjc1
 *  header comment added
 *
 *  Revision 1.1  2010/05/26 17:22:29  mwtjc1
 *  DocumentGeneratorException is created
 *
 */
