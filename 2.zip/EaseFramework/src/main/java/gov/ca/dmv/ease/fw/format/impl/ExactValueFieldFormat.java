/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;
import gov.ca.dmv.ease.fw.format.reader.IFormatReaderConstants;

/**
 * Description: I am format of a field with unique possible string value
 * File: ExactValueFieldFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ExactValueFieldFormat extends FieldFormat {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1137487209490372390L;
	/** The allowed value. */
	private String allowedValue;

	/**
	 * Instantiates a new exact value field format.
	 * 
	 * @param startPos 
	 * @param len 
	 * @param anAllowedValue 
	 */
	public ExactValueFieldFormat(int startPos, int len, String anAllowedValue) {
		super(startPos, len);
		setAllowedValue(anAllowedValue);
	}

	/**
	 * Instantiates a new exact value field format.
	 * 
	 * @param startPosInContext 
	 * @param value 
	 */
	public ExactValueFieldFormat(int startPosInContext, String aValue) {
		super(startPosInContext, aValue.length());
		setAllowedValue(aValue);
	}

	/**
	 * Instantiates a new exact value field format.
	 * 
	 * @param startPosInContext 
	 * @param allowed 
	 * @param name 
	 */
	public ExactValueFieldFormat(int startPosInContext, String allowed,
			String name) {
		super(startPosInContext, allowed.length());
		setAllowedValue(allowed);
		setFieldName(name);
	}

	public ExactValueFieldFormat(String aValue) {
		super(UNDEF_POS, aValue.length());
		setAllowedValue(aValue);
	}

	/**
	 * 
	 * 
	 * @return the allowedValue
	 */
	public String getAllowedValue() {
		return allowedValue;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.impl.FieldFormat#getLength()
	 */
	@Override
	public int getLength() {
		if (getAllowedValue() == null) {
			return 0;
		}
		else {
			return allowedValue.length();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample()
	 */
	@Override
	public String getRandomCorrectSample() {
		return getAllowedValue();
		//return RANDOMIZER.createRandomCorrectPayloadUsing(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample(int)
	 */
	public String getRandomCorrectSample(int nextRandom) {
		return getAllowedValue();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample()
	 */
	@Override
	public String getRandomIncorrectSample() {
		return PRODUCER.createStringNotEqualTo(getAllowedValue());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample(int)
	 */
	public String getRandomIncorrectSample(int nextRandom) {
		return getRandomIncorrectSample();
	}

	/**
	 * 
	 * 
	 * @param aValue 
	 */
	protected void setAllowedValue(String aValue) {
		allowedValue = aValue;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append(getLength()).append(',');
		aBuilder.append(IFormatReaderConstants.OPTIONS_START).append('\"')
				.append(getAllowedValue()).append('\"').append(
						IFormatReaderConstants.OPTIONS_END);
		if (getFieldName() != null) {
			aBuilder.append(", \"").append(getFieldName()).append('\"');
		}
		aBuilder.append(']');
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.impl.FieldFormat#validate(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validate(String aField, IErrorCollector aCollector) {
		if (!getAllowedValue().equals(aField)) {
			aCollector.register(new FormatValidationException("Expected: \""
					+ getAllowedValue() + " got: \"" + aField + "\" in: "
					+ this));
			return;
		}
		validateType(aField, aCollector);
	}

	/**
	 * Validate type.
	 * 
	 * @param aField 
	 * @param aCollector 
	 */
	protected void validateType(String aField, IErrorCollector aCollector) {
		if (!aField.equals(getAllowedValue())) {
			aCollector.register(new FormatValidationException(
					"Unexpected field value; should be: " + getAllowedValue()
							+ " is: " + aField + " in: " + this));
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ExactValueFieldFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2010/12/16 03:18:28  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.9  2010/12/14 02:46:03  mwpxp2
 *  Cleanup
 *
 *  Revision 1.8  2010/12/12 08:26:55  mwpxp2
 *  Modified exception messages to inclue receiver
 *
 *  Revision 1.7  2010/12/01 02:48:15  mwpxp2
 *  Added constructor for field name
 *
 *  Revision 1.6  2010/12/01 01:51:34  mwpxp2
 *  Adjusted refs to sample producer
 *
 *  Revision 1.5  2010/12/01 01:37:23  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.4  2010/12/01 01:22:51  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.3  2010/11/29 07:43:21  mwpxp2
 *  Modified toString/0
 *
 *  Revision 1.2  2010/11/25 00:53:13  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.1  2010/11/24 20:39:43  mwpxp2
 *  Initial
 *
 */
