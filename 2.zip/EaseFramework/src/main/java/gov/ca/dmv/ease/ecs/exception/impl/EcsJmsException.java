/**
 * 
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am the exception to be used for JMS problems in ECS
 * File: EcsJmsException.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: Mar 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsJmsException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5547255128881129827L;

	/**
	 * Instantiates a new jms exception.
	 */
	public EcsJmsException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param arg0 the arg0
	 */
	public EcsJmsException(String arg0) {
		super(arg0);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EcsJmsException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EcsJmsException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsJmsException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/22 23:23:50  mwpxp2
 *  Initial
 *
 */
