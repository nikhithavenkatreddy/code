package gov.ca.dmv.ease.fw.service;

/**
 * Description: I ma interface for a service
 * File: IService.java
 * Module:  gov.ca.dmv.ease.fw.service
 * Created: 2008
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IService {
	/**
	 * Execute.
	 * 
	 * @param request the request
	 * 
	 * @return the i response
	 */
	public IResponse execute(IRequest request);
}
/**
 *  Modification History:
 *
 *  $Log: IService.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:34:01  mwpxp2
 *  Added file decorations, class comment
 *
 */
