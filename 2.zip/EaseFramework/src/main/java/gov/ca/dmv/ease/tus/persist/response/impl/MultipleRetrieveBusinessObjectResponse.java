/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am the response for MultipleRetrieveBusinessObjectRequest
 *  //TODO - remove unused constructors, starting with the default
 * 
 * File: MultipleRetrieveBusinessObjectResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Oct 6, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleRetrieveBusinessObjectResponse extends
		PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 77760259694224577L;
	/** The results. */
	private List <IBusinessObject> results = new ArrayList <IBusinessObject>();

	/**
	 * 
	 */
	public MultipleRetrieveBusinessObjectResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public MultipleRetrieveBusinessObjectResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new retrieve multiple business objects response.
	 * 
	 * @param ex the ex
	 */
	public MultipleRetrieveBusinessObjectResponse(Exception ex) {
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public MultipleRetrieveBusinessObjectResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public MultipleRetrieveBusinessObjectResponse(IErrorCollector collector,
			int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public MultipleRetrieveBusinessObjectResponse(int anItemCount) {
		super(anItemCount);
	}

	/**
	 * Instantiates a new retrieve multiple business objects response.
	 * 
	 * @param results the results
	 */
	public MultipleRetrieveBusinessObjectResponse(List <IBusinessObject> results) {
		setResults(results);
	}

	/**
	 * This method returns the results of the retrieve all search operation.
	 * 
	 * @return the results in the form of a list object
	 */
	public List <IBusinessObject> getResults() {
		super.throwExceptionIfErrorFound();
		return results;
	}

	/**
	 * This method sets the results to this response instance.
	 * 
	 * @param results the results to set
	 */
	private void setResults(List <IBusinessObject> results) {
		this.results = results;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleRetrieveBusinessObjectResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/13 00:58:05  mwpxp2
 *  Added constructors from super; added todo
 *
 *  Revision 1.1  2010/10/06 16:32:42  mwkfh
 *  added MultipleRetrieveBusinessObject...
 *
 */
