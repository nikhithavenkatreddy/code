package gov.ca.dmv.ease.app.activity;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: I am interface for activity
 * File: IActivity.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created: Nov 23, 2009
 * @author mwrsk  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IActivity {
	/**
	 * Execute.
	 * 
	 * @param context the context
	 */
	void execute(ProcessContext context);

	/**
	 * Checks if is named.
	 *
	 * @param aName the a name
	 * @return true, if is named
	 */
	boolean isNamed(String aName);
}
/**
 *  Modification History:
 *
 *  $Log: IActivity.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2011/12/01 04:30:40  mwpxp2
 *  Added isNamed/1; removed redundant public method modifiers
 *
 *  Revision 1.2  2010/03/22 22:54:20  mwpxp2
 *  Added file decorations, class comment, javadoc
 *
 */
