/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleRetrieveBusinessObjectResponse;

import java.util.Collection;

/**
 * Description: I am request to retrieve a number of persisted BOs
 * preferably using a minimal number of db calls.
 * 
 * File: MultipleRetrieveBusinessObjectRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Oct 6, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleRetrieveBusinessObjectRequest extends
		MultiObjectPersistenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7436108300802283840L;

	/**
	 * @param userContext
	 * @param list
	 */
	public MultipleRetrieveBusinessObjectRequest(IUserContext userContext,
			Collection <IBusinessObject> list) {
		super(userContext, list);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public MultipleRetrieveBusinessObjectResponse execute() {
		return getPersistenceService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleRetrieveBusinessObjectRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/06 16:32:41  mwkfh
 *  added MultipleRetrieveBusinessObject...
 *
 */
