/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.incrementer.impl;

import gov.ca.dmv.ease.tus.persist.incrementer.ISpringJdbcSequenceMaxValueIncrementer;

import javax.sql.DataSource;

import org.springframework.jdbc.support.incrementer.HsqlSequenceMaxValueIncrementer;

/**
 * Purpose of this class is to retrieve the db table sequence number from the HSQL
 * File: SpringJdbcHsqlSequenceMaxValueIncrementer.java
 * Module:  gov.ca.dmv.ease.tus.persist.util.impl
 * Created: November 17, 2010 
 * @author MWKFH 
 * @version $Revision: 1.1 $
 */
public class SpringJdbcHsqlSequenceMaxValueIncrementer extends
		HsqlSequenceMaxValueIncrementer implements
		ISpringJdbcSequenceMaxValueIncrementer {
	/**
	 * Instantiates a new spring jdbc sequence max value incrementer.
	 * 
	 * @param ds the ds
	 * @param incrementerName the incrementer name
	 */
	public SpringJdbcHsqlSequenceMaxValueIncrementer(DataSource ds,
			String incrementerName) {
		super(ds, incrementerName);
	}

	/**
	 * Gets the dB next long value.
	 * 
	 * @return the dB next long value
	 */
	public long getDbNextLongValue() {
		return getNextKey();
	}

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.support.incrementer.HsqlSequenceMaxValueIncrementer#getSequenceQuery()
	 */
	public String getSequenceQuery() {
		return super.getSequenceQuery();
	}

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.support.incrementer.AbstractDataFieldMaxValueIncrementer#getIncrementerName()
	 */
	public String getIncrementerName() {
		return super.getIncrementerName();
	}
}
/**
 *  Modification History:
 *
 *  $Log: SpringJdbcHsqlSequenceMaxValueIncrementer.java,v $
 *  Revision 1.1  2012/10/01 02:57:20  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/09 18:06:10  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/11/18 20:02:28  mwkfh
 *  moved incrementer to new package
 *
 *  Revision 1.1  2010/11/18 18:36:17  mwkfh
 *  new incrementer for HSQL
 *
 */
