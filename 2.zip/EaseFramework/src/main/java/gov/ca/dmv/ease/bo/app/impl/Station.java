/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.app.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: I represent Station Information.
 * This is the concrete class that has the station id as well as printers associated with it.
 * Another process based on the bridge between EASE and DMVA maintains the 
 * association between a Neoware hostname and up to two printer names.  
 * The database created from this association information will be used to 
 * determine the printer associations for the session.
 * File: Station.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Jul 28, 2009
 * @author MWRRV3
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Station extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5183365970379237607L;
	/** The alternate printer. */
	private String alternatePrinterId;
	/** The inventory assigned flag */
	private Boolean isInventoryAssigned;
	/** The primary printer like bx-pa1. */
	private String primaryPrinterId;
	/** The station id. */
	private String stationId;

	/**
	 * Default Constructor.
	 */
	public Station() {
		super();
	}

	/**
	 * Instantiates a new station.
	 * 
	 * @param anId 
	 */
	public Station(String anId) {
		super();
		setStationId(anId);
	}

	/**
	 * Instantiates a new station.
	 * 
	 * @param anId 
	 * @param isInventoryAssigned 
	 */
	public Station(String anId, Boolean isInventoryAssigned) {
		super();
		setStationId(anId);
		setInventoryAssigned(isInventoryAssigned);
	}

	/**
	 * Instantiates a new station.
	 * 
	 * @param anId 
	 * @param aPrinter1 
	 * @param aPrinter2 
	 */
	public Station(String anId, String aPrinter1, String aPrinter2) {
		super();
		setStationId(anId);
		setPrimaryPrinterId(aPrinter1);
		setAlternatePrinterId(aPrinter2);
	}

	/**
	 * Instantiates a new station.
	 * 
	 * @param anId 
	 * @param aPrinter1 
	 * @param aPrinter2 
	 * @param isInventoryAssigned 
	 */
	public Station(String anId, String aPrinter1, String aPrinter2,
			Boolean isInventoryAssigned) {
		super();
		setStationId(anId);
		setPrimaryPrinterId(aPrinter1);
		setAlternatePrinterId(aPrinter2);
		setInventoryAssigned(isInventoryAssigned);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Station other = (Station) obj;
		if (alternatePrinterId == null) {
			if (other.alternatePrinterId != null) {
				return false;
			}
		}
		else if (!alternatePrinterId.equals(other.alternatePrinterId)) {
			return false;
		}
		if (isInventoryAssigned == null) {
			if (other.isInventoryAssigned != null) {
				return false;
			}
		}
		else if (!isInventoryAssigned.equals(other.isInventoryAssigned)) {
			return false;
		}
		if (primaryPrinterId == null) {
			if (other.primaryPrinterId != null) {
				return false;
			}
		}
		else if (!primaryPrinterId.equals(other.primaryPrinterId)) {
			return false;
		}
		if (stationId == null) {
			if (other.stationId != null) {
				return false;
			}
		}
		else if (!stationId.equals(other.stationId)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the alternatePrinterId
	 */
	public String getAlternatePrinterId() {
		return alternatePrinterId;
	}

	/**
	 * @return the inventoryAssigned
	 */
	public boolean isInventoryAssigned() {
		return (isInventoryAssigned != null && isInventoryAssigned
				.booleanValue());
	}

	/**
	 * @return the primaryPrinterId
	 */
	public String getPrimaryPrinterId() {
		return primaryPrinterId;
	}

	/**
	 * @return the stationId
	 */
	public String getStationId() {
		return stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((alternatePrinterId == null) ? 0 : alternatePrinterId
						.hashCode());
		result = prime
				* result
				+ ((isInventoryAssigned == null) ? 0 : isInventoryAssigned
						.hashCode());
		result = prime
				* result
				+ ((primaryPrinterId == null) ? 0 : primaryPrinterId.hashCode());
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		return result;
	}

	/**
	 * @param alternatePrinterId the alternatePrinterId to set
	 */
	public void setAlternatePrinterId(String alternatePrinterId) {
		this.alternatePrinterId = alternatePrinterId;
	}

	/**
	 * @param inventoryAssigned the inventoryAssigned to set
	 */
	public void setInventoryAssigned(Boolean inventoryAssigned) {
		this.isInventoryAssigned = inventoryAssigned;
	}

	/**
	 * @param primaryPrinterId the primaryPrinterId to set
	 */
	public void setPrimaryPrinterId(String primaryPrinterId) {
		this.primaryPrinterId = primaryPrinterId;
	}

	/**
	 * @param stationId the stationId to set
	 */
	public void setStationId(String stationId) {
		if (stationId != null) {
			this.stationId = stationId.toUpperCase();
		}
		else {
			this.stationId = stationId;
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Station.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2011/07/19 00:59:52  mwkfh
 *  removed isInventoryAssigned preset
 *
 *  Revision 1.8  2011/05/05 16:20:54  mwkfh
 *  initialized isInventoryAssigned to false
 *
 *  Revision 1.7  2011/03/15 16:40:42  mwkfh
 *  updated hashCode
 *
 *  Revision 1.6  2011/02/22 19:22:46  mwkfh
 *  updated isInventoryAssigned to return false if null
 *
 *  Revision 1.5  2011/02/16 17:52:27  mwkfh
 *  added isInventoryAssigned
 *
 *  Revision 1.4  2011/01/26 23:39:26  mwkfh
 *  setStationId to upper case
 *
 *  Revision 1.3  2010/11/29 19:12:00  mwpxp2
 *  Added constructor/3
 *
 *  Revision 1.2  2010/07/08 01:54:18  mwpxp2
 *  Cleaned up
 *
 *  Revision 1.1  2010/06/28 18:37:09  mwvxm6
 *  Moved to Architecture process as it is required by the Print Service
 *
 *  Revision 1.2  2010/06/24 22:19:52  mwvxm6
 *  Cleanup of admin package. removed Camera class and updated Station as per new requirements
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.4  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/12 01:09:05  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.14  2009/10/11 16:41:24  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.13  2009/10/07 01:16:49  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.12  2009/09/13 20:45:35  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.11.2.1  2009/09/12 19:08:47  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.11  2009/08/28 01:24:51  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.10  2009/08/27 05:39:44  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2009/08/22 23:19:32  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.8  2009/08/19 18:41:32  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.7  2009/08/06 02:01:14  mwrrv2
 *  Updated annotations
 *
 *  Revision 1.6  2009/08/06 01:45:17  mwrrv2
 *  updated the table annotations
 *
 *  Revision 1.5  2009/08/05 05:52:50  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.4  2009/08/05 01:23:12  mwyxg1
 *  add constructor
 *
 *  Revision 1.3  2009/08/05 00:36:35  mwrsk
 *  Changed STATION_ID to STATION_NUM
 *
 *  Revision 1.2  2009/07/29 17:21:36  mwrrv3
 *  Code formated and added comments.
 *
*/
