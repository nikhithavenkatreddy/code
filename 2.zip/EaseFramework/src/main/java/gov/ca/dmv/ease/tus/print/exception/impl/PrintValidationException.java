/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: I am to be used for signaling validation problems.
 * File: PrintValidationException.java
 * Module:  gov.ca.dmv.ease.tus.print.exception.impl
 * Created: Mar 17, 2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PrintValidationException extends EaseValidationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7112073296538781105L;

	/**
	 * Instantiates a new validation exception.
	 */
	public PrintValidationException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message.
	 * 
	 * @param message the message
	 */
	public PrintValidationException(String message) {
		super(message);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * @param message the message
	 * @param cause the Throwable cause
	 */
	public PrintValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public PrintValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: PrintValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:39:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/02/10 00:03:32  mwhxa2
 *  Print Validation Exception class
 *
*/
