/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session;

import gov.ca.dmv.ease.app.session.impl.SessionData;

import java.io.Serializable;

/**
 * Description: I am interface for a converter between SessionData and byte array, and vice versa
 * File: ISessionDataSerializer.java
 * Module:  gov.ca.dmv.ease.app.session
 * Created: Sep 18, 2012
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionDataBinaryConverter extends Serializable {
	/**
	 * To byte array.
	 *
	 * @param data the data
	 * @return the byte[]
	 */
	byte[] toByteArray(SessionData data);

	/**
	 * From byte array.
	 *
	 * @param aByteArray the a byte array
	 * @return the session data
	 */
	SessionData fromByteArray(byte[] aByteArray);
}
/**
 *  Modification History:
 *
 *  $Log: ISessionDataBinaryConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/09/24 23:58:07  mwpxp2
 *  Formatting
 *
 *  Revision 1.1  2012/09/18 18:19:41  mwpxp2
 *  Initial
 *
 */
