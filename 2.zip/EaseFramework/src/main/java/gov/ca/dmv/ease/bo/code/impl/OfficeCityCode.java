/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code.impl;

import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;

import java.io.Serializable;

/**
 * Description: I represent a city code
 * File: OfficeCityCode.java
 * Module:  gov.ca.dmv.ease.bo.code.impl
 * Created: Jul 28, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class OfficeCityCode extends BaseBusinessObject implements
		Comparable <OfficeCityCode>, Serializable {
	private static final long serialVersionUID = 2029526809567861341L;
	/** The city code. */
	private String cityCode;
	/** The city name. */
	private String cityName;
	/** The county code. */
	private String countyCode;
	/** The ZIP code. */
	private String zipCode;

	/**
	 * Constructor.
	 * 
	 * @param code the code
	 * @param name the name
	 * @param countyCode the county code
	 * @param zipCode the ZIP code
	 */
	public OfficeCityCode(String code, String name, String countyCode,
			String zipCode) {
		this.setCityCode(code);
		this.setCityName(name);
		this.setCountyCode(countyCode);
		this.setZipCode(zipCode);
	}

	/**
	 * Gets the City Code.
	 * 
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * Gets the City Name.
	 * 
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * Gets the County Code.
	 * 
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * Gets the ZIP Code.
	 * 
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * Sets the City Code.
	 * 
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	/**
	 * Sets the City Name.
	 * 
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * Sets the County Code.
	 * 
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * Sets the ZIP Code.
	 * 
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	/*
	 * (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public final int compareTo(OfficeCityCode officeCityCode) {
		return cityCode.compareToIgnoreCase(officeCityCode.cityCode);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OfficeCityCode.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/08/03 00:09:12  mwrrv3
 *  Removed public constructor (This issue is related to sorting the city codes).
 *
 *  Revision 1.3  2012/08/02 01:07:19  mwrrv3
 *  Implemented Comparable for sorting the city codes.
 *
 *  Revision 1.2  2011/01/17 00:44:41  mwpxp2
 *  Builk cleanup
 *
 *  Revision 1.1  2010/10/08 20:45:31  mwrrv3
 *  Office City code initial commit.
 *
 */
