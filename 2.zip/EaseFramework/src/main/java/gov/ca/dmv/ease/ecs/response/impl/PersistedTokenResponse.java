/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.ecs.response.IPersistedResponseToken;

/**
 * Description: I am default implementation of IPersistedResponseToken.
 * File: PersistedTokenResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PersistedTokenResponse extends SynchronousResponse implements
		IPersistedResponseToken {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5545858568542169127L;
	/** The persisted response class name. */
	private String persistedResponseClassName;
	/** The persisted response id. */
	private String persistedResponseId;

	/**
	 * Instantiates a new persisted response token.
	 */
	protected PersistedTokenResponse() {
		super();
	}

	/**
	 * Instantiates a new persisted response token.
	 * 
	 * @param anIndexSize the an index size
	 * @param aPersistedResponseId the a persisted response id
	 * @param aPersistedResponseClassName the a persisted response class name
	 */
	public PersistedTokenResponse(String aPersistedResponseId,
			String aPersistedResponseClassName, int anIndexSize) {
		super();
		setPersistedResponseId(aPersistedResponseId);
		setPersistedResponseClassName(aPersistedResponseClassName);
		setObjectCount(anIndexSize);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.IPersistedResponseToken#getPersistedResponseClassName()
	 */
	public String getPersistedResponseClassName() {
		return persistedResponseClassName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.IPersistedResponseToken#getPersistedResponseId()
	 */
	public String getPersistedResponseId() {
		return persistedResponseId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#isPersistedToken()
	 */
	@Override
	public final boolean isPersistedToken() {
		return true;
	}

	/**
	 * Sets the persisted response class name.
	 * 
	 * @param aClassName the a class name
	 */
	protected void setPersistedResponseClassName(String aClassName) {
		persistedResponseClassName = aClassName;
	}

	/**
	 * Sets the persisted response id.
	 * 
	 * @param anId the new persisted response id
	 */
	protected void setPersistedResponseId(String anId) {
		persistedResponseId = anId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("persistedResponseClassName",
				persistedResponseClassName, anIndent, aBuilder);
		outputKeyValue("persistedResponseId", persistedResponseId, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PersistedTokenResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/14 18:20:00  mwhxb3
 *  updated comments
 *
 *  Revision 1.5  2009/10/06 21:54:08  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.8.1  2009/10/06 20:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/07/27 18:30:38  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.3  2009/07/16 02:30:12  mwpxp2
 *  Bulk cleanup, incl javadoc and file decorations
 *
 *  Revision 1.2  2009/07/16 02:28:43  mwpxp2
 *  Bulk cleanup, incl javadoc and file decorations
 *
 *  Revision 1.1  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.5  2009-05-14 22:02:31  ppalacz
 *  Removed getIndexSize/0 in favor of  getObjectCount/0 in the superclass
 *
 *  Revision 1.4  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.3  2009-05-13 20:30:40  ppalacz
 *  Added getPersistedResponse* calls and constructors
 *
 *  Revision 1.2  2009-05-13 02:22:10  ppalacz
 *  Made 0 arg constructor protected
 *
 *  Revision 1.1  2009-05-12 22:21:35  ppalacz
 *  Initial
 *
*/
