/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.request.impl;

import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.ISessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.service.ISessionPersistenceService;

/**
 * Description: I am the abstract session persistence service request object.
 * File: SessionPersistenceRequest.java
 * Module:  gov.ca.dmv.ease.tus.session.persist.request.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class SessionPersistenceRequest extends
		PersistenceServiceRequest implements ISessionPersistenceRequest {
	/** The serialVersionUID */
	private static final long serialVersionUID = -7131460184347133401L;
	/** The session */
	private Session session;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public SessionPersistenceRequest(IUserContext userContext, Session aSession) {
		super(userContext);
		setSession(aSession);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#getPersistenceService()
	 */
	@Override
	public ISessionPersistenceService getPersistenceService() {
		return (ISessionPersistenceService) super.getPersistenceService();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.session.persist.request.ISessionPersistenceRequest#getSession()
	 */
	public Session getSession() {
		return session;
	}

	/**
	 * @param aSession the aSession to set
	 */
	private void setSession(Session aSession) {
		this.session = aSession;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionPersistenceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/06 19:34:45  mwkfh
 *  Initial
 *
 */
