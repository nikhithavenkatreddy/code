/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsMapResponse;
import gov.ca.dmv.ease.tus.auth.service.impl.AuthAndAuthService;

import java.util.List;

/**
 * Description: I am an AuthAndAuth request
 * 
 * File: RetrieveAuthorizedTtcsMapRequest.java
 * Module:  gov.ca.dmv.ease.tus.auth.request.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveAuthorizedTtcsMapRequest extends AuthAndAuthServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4616580264782391324L;
	/** list of roles */
	List <String> roleList;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public RetrieveAuthorizedTtcsMapRequest(IUserContext userContext,
			List <String> roleList) {
		super(userContext);
		setRoles(roleList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.impl.IAuthAndAuthServiceRequest#execute()
	 */
	@Override
	public IRetrieveAuthorizedTtcsMapResponse execute() {
		return AuthAndAuthService.getInstance().execute(this);
	}

	/**
	 * Gets the ttc list.
	 * 
	 * @return the ttc list
	 */
	public List <String> getRoles() {
		return roleList;
	}

	/**
	 * Sets the ttc list.
	 * 
	 * @param ttc list
	 */
	private void setRoles(List <String> roleList) {
		this.roleList = roleList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveAuthorizedTtcsMapRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
