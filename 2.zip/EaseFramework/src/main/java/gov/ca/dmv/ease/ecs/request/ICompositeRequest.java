/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request;

import java.util.List;

/**
 * Description: Interface for a composite request - a request consisting of a number of other requests.
 * File: ICompositeRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request
 * Created: 16/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICompositeRequest extends IEcsRequest {
	/**
	 * Registers a request
	 *
	 * @param aRequest the a request
	 */
	void add(IEcsRequest aRequest);

	/**
	 * Adds the all requests in the collection.
	 *
	 * @param aRequestList the a request list
	 */
	void addAll(List <IEcsRequest> aRequestList);

	/**
	 * Gets the  size of children requests.
	 *
	 * @return the children size
	 */
	int getChildrenSize();

	/**
	 * Gets the requests contained.
	 *
	 * @return the request
	 */
	List <IEcsRequest> getRequests();
}
/**
 *  Modification History:
 *
 *  $Log: ICompositeRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/13 20:25:35  mwhxb3
 *  updated comments.
 *
 *  Revision 1.3  2009/10/06 21:52:15  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.2.12.1  2009/10/06 20:28:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.2  2009/07/14 23:58:52  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.2  2009-05-18 16:22:34  ppalacz
 *  Javadoc update
 *
 *  Revision 1.1  2009-05-17 05:22:07  ppalacz
 *  Initial
 *
*/
