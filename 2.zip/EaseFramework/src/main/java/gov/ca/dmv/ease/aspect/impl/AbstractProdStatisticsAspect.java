/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.aspect.impl;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.bridge.request.impl.ProductionStatisticRequestEcs;
import gov.ca.dmv.ease.ecs.convert.impl.ProductionStatisticsConverter;
import gov.ca.dmv.ease.fw.process.IUserContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 * Description: The purpose of this class is to act as base class for the production statistics.
 * //FIXME - replace the hardcoded values (typically, Strings) by constants
 *
 * File: AbstractProdStatisticsAspect.java
 * Module:  gov.ca.dmv.ease.aspect.impl
 * Created: Jun 21, 2010
 * @author MWVKM
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/03/22 22:24:35 $
 * Last Changed By: $Author: mwsec2 $
 *
 */
@Aspect
public abstract class AbstractProdStatisticsAspect extends AbstractAspect {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(AbstractProdStatisticsAspect.class);

	/**
	 * Advises all subclasses of FallbackableInteractionActivity (unless the subclass overrides getFallbackTargetActivity)
	 */
	//@Before("!inEaseLogExecution() && execution(* gov.ca.dmv.ease.app.activity.impl.FallbackableInteractionActivity.getFallbackTargetActivity(..) ) ")
	public void fallbackOfBusinessProcess(JoinPoint jp) {
		adviseFallback(jp);
	}
	
	/**
	 * To be overridden by subclasses that need to advise fallbacks.
	 * 
	 * @param jp
	 */
	protected void adviseFallback(JoinPoint jp) {
		// intentionally does nothing
	}
	
	// TODO rename to logSystemManagmentLogMessage
	/**
	 * The purpose of this method is to send the session context information across the ecs service.
	 *
	 * @param joinPoint the joint point
	 */
	public void logSessionContextMessage(JoinPoint joinPoint,
			ProcessContext processContext) {
		logSessionContextMessage(joinPoint, processContext, "");
	}

	// TODO rename to logSystemManagmentLogMessage
	/**
	 * 
	 * The purpose of this method is to send the bridge message across the ecs service for system management log.
	 *
	 * @param joinPoint the joint point
	 */
	public void logSessionContextMessage(JoinPoint joinPoint,
			ProcessContext processContext, String bridgeMessage) {
		LOGGER.debug("logSessionContextMessage(JoinPoint joinPoint="
				+ joinPoint + ", ProcessContext processContext="
				+ processContext + ", String bridgeMessage=" + bridgeMessage
				+ ") - start");
		IUserContext userContext = (IUserContext) EaseProxyUtils
				.getProxyObject(processContext.getUserContext());
		StringBuilder logString = this.generateHeaderSection(joinPoint,
				processContext);
		logString.append(PRINCIPAL_ID + NAME_VALUE_SEPERATOR
				+ userContext.getUniqueIdentifier() + FIELD_DELIMITER);
		logString.append(LOG_ENTRY + NAME_VALUE_SEPERATOR);
		logString.append(StringUtils.rightPad(userContext.getIpAddress(), 15));
		logString.append(" ; ");
		logString.append(StringUtils.rightPad(bridgeMessage, 15));
		String message = logString.toString();
		LOGGER.info("log session context message ---> " + message + " in: "
				+ this);
		super.processSystemLogRequestMessage(message, userContext);
		LOGGER.debug("logSessionContextMessage(JoinPoint=" + joinPoint
				+ ", ProcessContext=" + processContext + ", String="
				+ bridgeMessage + ") - end");
	}

	// TODO rename to logSystemManagmentLogMessage
	/**
	 * The purpose of this method is to send the bridge message across the ecs service for system management log.
	 *
	 * @param joinPoint the joint point
	 */
	public void logSessionContextMessage(JoinPoint joinPoint,
			UserContext userContext, String bridgeMessage) {
		LOGGER.debug("logSessionContextMessage(JoinPoint joinPoint="
				+ joinPoint + ", UserContext userContext=" + userContext
				+ ", String bridgeMessage=" + bridgeMessage + ") - start");
		StringBuilder logString = this.generateHeaderSection(joinPoint);
		logString.append(PRINCIPAL_ID + NAME_VALUE_SEPERATOR
				+ userContext.getUniqueIdentifier() + FIELD_DELIMITER);
		logString.append(LOG_ENTRY + NAME_VALUE_SEPERATOR);
		logString.append(StringUtils.rightPad(userContext.getIpAddress(), 15));
		logString.append(" ; ");
		logString.append(StringUtils.rightPad(bridgeMessage, 15));
		String message = logString.toString();
		LOGGER.info("log session context message ---> " + message + " in: "
				+ this);
		super.processSystemLogRequestMessage(message, userContext);
		LOGGER.debug("logSessionContextMessage(JoinPoint=" + joinPoint
				+ ", UserContext=" + userContext + ", String=" + bridgeMessage
				+ ") - end");
	}

	/**
	 * The purpose of this method is to convert the production statistics message.
	 *
	 * @param processContext the instance of process context
	 * @param completionCode the completion code
	 * @param cachierSequenceNbr cachier sequence number
	 * @param dlOrIdIndicator DL ID indicator
	 * @param ttc Type transaction code
	 */
	public String processProductionStatistics(ProcessContext processContext,
			String completionCode, String cashierSequenceNbr,
			String dlOrIdIndicator, String ttc) {
		/*// commented out for performance considerations
		LOGGER
				.debug("processProductionStatistics(ProcessContext processContext="
						+ processContext
						+ ", String completionCode="
						+ completionCode
						+ ", String cashierSequenceNbr="
						+ cashierSequenceNbr
						+ ", String dlOrIdIndicator="
						+ dlOrIdIndicator + ", String ttc=" + ttc + ") - start");
		*/
		ProductionStatisticsConverter prodStatisticsConverter = ProductionStatisticsConverter
				.getInstance();
		ProductionStatisticRequestEcs aRequest = BRIDGE_REQUEST_FACTORY
				.createProductionStatisticRequestEcs(processContext
						.getUserContext(), completionCode, cashierSequenceNbr,
						dlOrIdIndicator, ttc);
		//		ProductionStatisticRequestEcs aRequest = new ProductionStatisticRequestEcs(
		//				processContext.getUserContext(), completionCode, cashierSequenceNbr,
		//				dlOrIdIndicator, ttc);
		//		String messageText = prodStatisticsConverter.createMessage(processContext
		//				.getUserContext(), completionCode, cashierSequenceNbr,
		//				dlOrIdIndicator, ttc);
		String messageText = prodStatisticsConverter.createMessage(aRequest);
		LOGGER.info("[" + messageText + "] in: " + this);
		return messageText;
	}

	/**
	 * The purpose of this method is to send the converted production statistics message across the bridge service.
	 *
	 * @param processContext the instance of process context
	 * @param messageText constructed message for the bridge service
	 */
	protected void sendConvertedBridgeMessage(String messageText,
			ProcessContext processContext) {
		LOGGER.debug("sendConvertedBridgeMessage(String messageText="
				+ messageText + ", ProcessContext processContext="
				+ processContext + ") - start");
		ProductionStatisticRequestEcs bridgeRequest = BRIDGE_REQUEST_FACTORY
				.createProductionStatisticRequestEcs(messageText,
						processContext.getUserContext());
		bridgeRequest.execute();
		LOGGER.info("sent bridge message: [" + bridgeRequest.getMessage()
				+ "] in: " + this);
		LOGGER.debug("sendConvertedBridgeMessage(String=" + messageText
				+ ", ProcessContext=" + processContext + ") - end");
	}

	/**
	 * The purpose of this method is to send the converted production statistics message across the bridge service.
	 *
	 * @param processContext the instance of process context
	 * @param messageText constructed message for the bridge service
	 */
	protected void sendConvertedBridgeMessage(String messageText,
			UserContext userContext) {
		LOGGER.debug("sendConvertedBridgeMessage(String messageText="
				+ messageText + ", UserContext userContext=" + userContext
				+ ") - start");
		ProductionStatisticRequestEcs bridgeRequest = BRIDGE_REQUEST_FACTORY
				.createProductionStatisticRequestEcs(messageText, userContext);
		bridgeRequest.execute();
		LOGGER.info("sent bridge message: [" + bridgeRequest.getMessage()
				+ "] in: " + this);
		LOGGER.debug("sendConvertedBridgeMessage(String=" + messageText
				+ ", UrocessContext=" + userContext + ") - end");
	}
}
/**
 *  Modification History:
 *  $Log: AbstractProdStatisticsAspect.java,v $
 *  Revision 1.2  2013/03/22 22:24:35  mwsec2
 *  Added advise for fallbacks (not yet enabled) and TODO comments
 *
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.25  2012/09/27 15:48:37  mwkfh
 *  removed isValid since in parent now
 *
 *  Revision 1.24  2012/09/26 21:09:30  mwpxp2
 *  Added isValid on process context
 *
 *  Revision 1.23  2012/02/16 22:39:03  mwxxw
 *  Add logging for additional fields: officeId, techId, dlNumber and partitionId.
 *
 *  Revision 1.22  2011/10/12 20:55:24  mwkkc
 *  Performance Merge
 *
 *  Revision 1.21.8.1  2011/09/26 23:21:07  mwpxp2
 *  Modified for singleton factories
 *
 *  Revision 1.21  2011/06/29 23:27:55  mwxxw
 *  Add two new function for BPRS for camera.
 *
 *  Revision 1.20  2011/06/10 21:10:14  mwyxg1
 *  clean up
 *
 *  Revision 1.19  2011/04/20 22:51:15  mwxxw
 *  Use UniqueIdentifier for PRINCIPAL_ID field.
 *
 *  Revision 1.18  2011/04/20 17:29:31  mwxxw
 *  Remove the tcode field in the log.
 *
 *  Revision 1.17  2011/04/20 00:54:52  mwxxw
 *  Add BPRS tcode before the bridge message.
 *
 *  Revision 1.16  2011/03/23 23:38:44  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.15  2011/01/10 23:52:32  mwxxw
 *  Remove the Remove constant: DELIMITER. Use FIELD_DELIMITER instead.
 *
 *  Revision 1.14  2010/12/12 20:38:23  mwpxp2
 *  Added logging
 *
 *  Revision 1.13  2010/12/10 03:32:37  mwpxp2
 *  Used BRIDGE_REQUEST_FACTORY to create request
 *
 *  Revision 1.12  2010/12/10 02:26:14  mwpxp2
 *  Modified to use ProductionStatisticRequestEcs rather than ProductionStatisticRequest
 *
 *  Revision 1.11  2010/12/09 20:22:23  mwpxp2
 *  Adjusted processProductionStatistics to create a request for processing by converter
 *
 *  Revision 1.10  2010/09/22 18:19:34  mwpxp2
 *  Adjusted imports for bridge-related request class move
 *
 *  Revision 1.9  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.8  2010/08/06 19:10:26  mwkkc
 *  Principal Id is added to the log session context message
 *
 *  Revision 1.7  2010/07/31 00:13:13  mwkkc
 *  Auditing and Logging Work
 *
 *  Revision 1.6  2010/07/13 17:11:02  mwkfh
 *  relocated session restore packages
 *
 *  Revision 1.5  2010/07/08 01:52:14  mwpxp2
 *  Added fixmes; cleaned up
 *
 *  Revision 1.4  2010/06/29 00:09:12  mwvkm
 *  Java Docs are updated.
 *
 *  Revision 1.3  2010/06/25 21:18:03  mwvkm
 *  bridge message is included in the system log message
 *
 *  Revision 1.2  2010/06/24 16:58:32  mwvkm
 *  Problem fixed with ClassCastException
 *
 *  Revision 1.1  2010/06/22 00:05:10  mwvkm
 *  Production statistics is updated with Sign and Sign Off.
 *
 */
