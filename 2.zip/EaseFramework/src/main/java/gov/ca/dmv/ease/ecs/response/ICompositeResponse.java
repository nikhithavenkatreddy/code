/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response;

import java.util.List;

/**
 * Description: I am interface for a composite response -
 * an object collecting responses for a composite request.
 * File: ICompositeResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response
 * Created: 16/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICompositeResponse extends IEcsResponse {
	/**
	 * Adds the ECS response.
	 *
	 * @param aResponse the response
	 */
	void add(IEcsResponse aResponse);

	/**
	 * Adds the all ECS responses.
	 *
	 * @param aResponseList the response list
	 */
	void addAll(List <IEcsResponse> aResponseList);

	/**
	 * Gets the children size.
	 *
	 * @return the children size
	 */
	int getChildrenSize();

	/**
	 * Gets the responses.
	 *
	 * @return the responses
	 */
	List <IEcsResponse> getResponses();
}
/**
 *  Modification History:
 *
 *  $Log: ICompositeResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/14 16:44:06  mwhxb3
 *  updated comments
 *
 *  Revision 1.4  2009/10/06 21:53:43  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.8.1  2009/10/06 20:28:47  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3  2009/07/27 18:29:20  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/14 23:58:50  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.1  2009-05-17 05:25:13  ppalacz
 *  Initial
 *
*/
