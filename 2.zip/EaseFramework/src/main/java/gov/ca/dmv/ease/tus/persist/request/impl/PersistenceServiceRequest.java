/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;

import java.util.Date;

/**
 * Description: This is an abstract PersistenceServiceRequest class.
 * 
 * File: PersistenceServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request
 * Created: Jul 26, 2009 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class PersistenceServiceRequest extends AbstractRequest
		implements IPersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5767183072849022253L;
	/** The persistence service. */
	private transient IPersistenceService persistenceService;
	
	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public PersistenceServiceRequest(IUserContext userContext) {
		super(userContext);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest#execute()
	 */
	public abstract PersistenceServiceResponse execute();
	
	/**
	 * Gets the persistence service.
	 * 
	 * @return the persistence service
	 */
	public IPersistenceService getPersistenceService() {
		return persistenceService;
	}
	
	/**
	 * Sets the persistence service.
	 * 
	 * @param persistenceService the new persistence service
	 */
	public void setPersistenceService(IPersistenceService persistenceService) {
		this.persistenceService = persistenceService;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: PersistenceServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/10/25 23:47:35  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.5  2011/10/12 20:58:12  mwkkc
 *  Performance Merge
 *
 *  Revision 1.4.24.2  2011/09/30 01:01:08  mwrrv3
 *  Revert
 *
 *  Revision 1.3.4.1  2010/09/14 16:14:38  mwpxr4
 *  Removed compilation errors from branch by taking latest from head
 *
 *  Revision 1.4  2010/09/14 00:40:33  mwkfh
 *  made persistenceService non-static
 *
 *  Revision 1.3  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/08/31 17:57:58  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/13 23:18:06  mwrsk
 *  Moved PersistenceServiceResponse to impl package
 *
 *  Revision 1.2  2009/10/03 21:32:44  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.1  2009/09/03 22:35:01  mwrsk
 *  refactor code
 *
 *  Revision 1.6  2009/09/03 22:24:16  mwrsk
 *  Created an interface
 *
 *  Revision 1.5  2009/08/27 03:46:41  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/25 21:56:41  mwpxp2
 *  Cleanup; added javadoc
 *
 *  Revision 1.3  2009/08/06 21:28:56  mwakg
 *  Merging from MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 *
 *  Revision 1.2.2.1  2009/08/06 16:25:16  mwakg
 *  Changed the design of PersistenceService. Instead of working with BusinessObject PersistenceService is now working with IBusinessObject
 *
 *  Revision 1.2  2009/08/05 20:40:18  mwrsk
 *  Refactored code to make persistence service work
 *
 *  Revision 1.1  2009/07/29 16:56:58  mwakg
 *  Changed the design of persistence service hence refractored code accordingly
 *
 */
