/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.context.impl;

import gov.ca.dmv.ease.app.activity.impl.Activity;

import java.io.Serializable;

/**
 * Description: I am an encapsulation of the execution sync point activity and its associated context
 * 
 * File: ExecutionSyncPoint.java
 * Module:  gov.ca.dmv.ease.app.context
 * Created:    2010 
 * @author MWSEC@  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ExecutionSyncPoint implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5965040098474587192L;
	/** The execution sync point. */
	private Activity executionSyncPointActivity;
	/** The execution sync point context. */
	private ProcessContext executionSyncPointContext;

	public ExecutionSyncPoint(Activity executionSyncPointActivity,
			ProcessContext executionSyncPointContext) {
		super();
		this.executionSyncPointActivity = executionSyncPointActivity;
		this.executionSyncPointContext = executionSyncPointContext;
	}

	/**
	 * Gets the execution syncPoint activity
	 * @return
	 */
	public Activity getExecutionSyncPointActivity() {
		return executionSyncPointActivity;
	}

	/**
	 * Gets the execution syncPoint context
	 * @return
	 */
	public ProcessContext getExecutionSyncPointContext() {
		return executionSyncPointContext;
	}

	/**
	 * Sets the execution syncPoint activity
	 * @param executionSyncPointActivity
	 */
	public void setExecutionSyncPoint(Activity executionSyncPointActivity) {
		this.executionSyncPointActivity = executionSyncPointActivity;
	}

	/**
	 * Sets the execution syncPoint context
	 * @param executionSyncPointContext
	 */
	public void setExecutionSyncPointContext(
			ProcessContext executionSyncPointContext) {
		this.executionSyncPointContext = executionSyncPointContext;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String activityName = null;
		if (executionSyncPointActivity != null) {
			activityName = executionSyncPointActivity.getActivityName();
		}
		String processId = null;
		if (executionSyncPointContext != null) {
			processId = executionSyncPointContext.getProcessId();
		}
		return activityName + " in " + processId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ExecutionSyncPoint.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/01/20 19:47:52  mwpxp2
 *  Imports and javadoc cleanup
 *
 *  Revision 1.5  2010/12/23 19:56:52  mwsec2
 *  made toString null-safe
 *
 *  Revision 1.4  2010/09/20 17:02:46  mwpxp2
 *  Added mising javadoc;bulk cleanup
 *
 *  Revision 1.3  2010/09/04 17:27:26  mwhys
 *  Made serializable.
 *
 *  Revision 1.2  2010/09/01 18:56:22  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/08/03 21:27:58  mwsec2
 *  syncPoint enhancements
 *
 */
