/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.factory;

import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.request.impl.DeleteSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RestoreSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.StoreSessionRequest;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I define the interface to PersistenceServiceRequest.
 * File: ISessionServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.app.session.request.factory
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionServiceRequestFactory {
	/**
	 * Creates a DeleteSessionRequest.
	 *
	 * @param userContext the user context
	 * @return DeleteSessionRequest
	 */
	DeleteSessionRequest createDeleteSessionRequest(IUserContext userContext);
	
	/**
	 * Creates a DeleteSessionRequest.
	 *
	 * @param userContext the user context
	 * @param session the session
	 * @return DeleteSessionRequest
	 */
	DeleteSessionRequest createDeleteSessionRequest(IUserContext userContext,
			Session session);
	
	/**
	 * Creates a RestoreSessionRequest.
	 *
	 * @param userContext the user context
	 * @param newSessionId the new session id
	 * @return RestoreSessionRequest
	 */
	RestoreSessionRequest createRestoreSessionRequest(IUserContext userContext,
			String newSessionId);
	
	/**
	 * Creates a RetrieveSessionRequest.
	 *
	 * @param userContext the user context
	 * @return RetrieveSessionRequest
	 */
	RetrieveSessionRequest createRetrieveSessionRequest(IUserContext userContext);
	
	/**
	 * Creates a RetrieveSessionRequest.
	 *
	 * @param userContext the user context
	 * @param session the session
	 * @return RetrieveSessionRequest
	 */
	RetrieveSessionRequest createRetrieveSessionRequest(
			IUserContext userContext, Session session);
	
	/**
	 * Creates a RetrieveSessionRequest.
	 *
	 * @param userContext the user context
	 * @param sessionId the session id
	 * @return RetrieveSessionRequest
	 */
	RetrieveSessionRequest createRetrieveSessionRequest(
			IUserContext userContext, String sessionId);
	
	/**
	 * Creates a StoreSessionRequest.
	 *
	 * @param userContext the user context
	 * @param session the session
	 * @return StoreSessionRequest
	 */
	StoreSessionRequest createStoreSessionRequest(IUserContext userContext,
			Session session);
	
	/**
	 * Creates a StoreSessionRequest.
	 *
	 * @param userContext the user context
	 * @param session the session
	 * @param sessionData the session data
	 * @return StoreSessionRequest
	 */
	StoreSessionRequest createStoreSessionRequest(IUserContext userContext,
			Session session, SessionData sessionData);
	
	/**
	 * Creates a StoreSessionRequest.
	 *
	 * @param userContext the user context
	 * @param sessionId the session id
	 * @param sessionData the session data
	 * @return StoreSessionRequest
	 */
	StoreSessionRequest createStoreSessionRequest(IUserContext userContext,
			String sessionId, SessionData sessionData);
}
/**
 *  Modification History:
 *
 *  $Log: ISessionServiceRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/05/08 00:27:22  mwhys
 *  Updated for Session Management.
 *
 *  Revision 1.2  2010/09/30 21:21:05  mwkfh
 *  added methods
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
