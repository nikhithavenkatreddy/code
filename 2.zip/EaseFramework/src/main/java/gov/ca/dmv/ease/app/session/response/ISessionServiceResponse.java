/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.response;

import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I define the interface to SessionServiceResponse
 * 
 * File: ISessionServiceResponse.java
 * Module:  gov.ca.dmv.ease.app.session.response
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionServiceResponse extends IResponse {
}
/**
 *  Modification History:
 *
 *  $Log: ISessionServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/01/06 19:33:44  mwkfh
 *  added extends
 *
 *  Revision 1.1  2010/09/30 17:49:55  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
