/** *
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.util;

import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.constants.IOfficeBusinessConstants;
import gov.ca.dmv.ease.tus.office.business.factory.impl.OfficeBusinessServiceRequestFactory;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeTypeResponse;


/**
 * Description: Utility class used by all DL activities to determine office business types.
 * File: OfficeBusinessTypeUtil.java
 * Module:  gov.ca.dmv.ease.ts.util
 * Created: Feb 13, 2011 
 * @author MWXXW 
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class OfficeBusinessTypeUtil {
	/**
	 * Checks if the office is TELEPHONE_SERVICE_CENTER only.
	 * 
	 * @param userContext the user context
	 * 
	 * @return true, if is TELEPHONE_SERVICE_CENTER
	 */
	public static boolean isOfficeTelephoneServiceCenterOnly(UserContext userContext) {
		return isThisTypeOfficeOnly(IOfficeBusinessConstants.OFFICE_TYPE_TELEPHONE_SERVICE_CENTER, userContext);
	}
	
	/**
	 * Checks if the office is DL_ISSUANCE_OFFICE only.
	 * 
	 * @param userContext the user context
	 * 
	 * @return true, if is DL_ISSUANCE_OFFICE
	 */
	public static boolean isOfficeIssuanceOfficeOnly(UserContext userContext) {
		return isThisTypeOfficeOnly(IOfficeBusinessConstants.OFFICE_TYPE_DL_ISSUANCE_OFFICE, userContext);
	}
	
	/**
	 * Checks if the office is TELEPHONE_SERVICE_CENTER type.
	 * 
	 * @param userContext the user context
	 * 
	 * @return true, if is TELEPHONE_SERVICE_CENTER
	 */
	public static boolean isOfficeTelephoneServiceCenter(UserContext userContext) {
		return isThisTypeOffice(IOfficeBusinessConstants.OFFICE_TYPE_TELEPHONE_SERVICE_CENTER, userContext);
	}
	
	/**
	 * Checks if the office is DL_ISSUANCE_OFFICE.
	 * 
	 * @param userContext the user context
	 * 
	 * @return true, if is DL_ISSUANCE_OFFICE
	 */
	public static boolean isOfficeIssuanceOffice(UserContext userContext) {
		return isThisTypeOffice(IOfficeBusinessConstants.OFFICE_TYPE_DL_ISSUANCE_OFFICE, userContext);
	}
	/**
	 * Checks if the office is this type of office only.
	 * @param officeType
	 * @param userContext
	 * @return 
	 */
	private static boolean isThisTypeOfficeOnly(String officeType, UserContext userContext) {	
		boolean returnFlg = false;				
		RetrieveOfficeTypeRequest request = OfficeBusinessServiceRequestFactory
			.getInstance().createRetrieveOfficeTypeRequest(userContext, userContext.getOfficeId());
		IRetrieveOfficeTypeResponse response = request.execute();
		
		if (!EaseUtil.isNullOrBlank(response.getOfficeTypeList())) {
			if (response.getOfficeTypeList().size() == 1 && 
			    officeType.equals(response.getOfficeTypeList().get(0))) {
				returnFlg = true;
			}
		}
		return returnFlg;
	}
	
	/**
	 * Checks if the office is this type of office only.
	 * @param officeType
	 * @param userContext
	 * @return 
	 */
	private static boolean isThisTypeOffice(String officeType, UserContext userContext) {	
		boolean returnFlg = false;
		RetrieveOfficeTypeRequest request = OfficeBusinessServiceRequestFactory
			.getInstance().createRetrieveOfficeTypeRequest(userContext, userContext.getOfficeId());
		IRetrieveOfficeTypeResponse response = request.execute();
		
		if (!EaseUtil.isNullOrBlank(response.getOfficeTypeList())) {
			if (ArrayUtils.contains(response.getOfficeTypeList(), officeType)) {
				returnFlg = true;
			}
		}
		return returnFlg;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OfficeBusinessTypeUtil.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/10 23:13:14  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.1  2011/02/12 23:41:41  mwxxw
 *  Add new IsOfficeIssuanceOnly() API.
 *
 *  
 */