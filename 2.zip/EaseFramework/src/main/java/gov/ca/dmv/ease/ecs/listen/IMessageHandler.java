/**
 * 
 */
package gov.ca.dmv.ease.ecs.listen;

import javax.jms.Message;


/**
 * Description: Interface for message handlers
 * File: IMessageHandler.java
 * Module:  gov.ca.dmv.ease.ecs.listen.impl
 * Created: Oct 19, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageHandler {
	
	void process(Message message);
}


/**
 *  Modification History:
 *
 *  $Log: IMessageHandler.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/04/17 22:26:36  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:08  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */
