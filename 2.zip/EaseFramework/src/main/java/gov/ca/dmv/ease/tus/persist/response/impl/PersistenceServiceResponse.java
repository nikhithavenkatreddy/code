/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;
import gov.ca.dmv.ease.tus.persist.response.IPersistenceServiceResponse;

/**
 * Description: I am the base response for any persistence request
 *  //TODO - remove unused constructors, starting with the default
 *  //TODO - extract interface
 * File: PersistenceServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response.impl
 * Created: Jul 26, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PersistenceServiceResponse extends AbstractResponse implements
		IPersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1927483612211620168L;
	/** The affected items count. */
	private Integer affectedItemsCount = new Integer("0");

	/**
	 * Instantiates a new persistence service response.
	 */
	public PersistenceServiceResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public PersistenceServiceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public PersistenceServiceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param aCollector the a collector
	 * @param anItemCount the an item count
	 */
	public PersistenceServiceResponse(IErrorCollector aCollector,
			Integer anItemCount) {
		super(aCollector);
		setAffectedItemsCount(anItemCount);
	}

	/**
	 * Instantiates a new persistence service response.
	 * 
	 * @param anItemCount the an item count
	 */
	public PersistenceServiceResponse(Integer anItemCount) {
		super();
		setAffectedItemsCount(anItemCount);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof PersistenceServiceResponse)) {
			return false;
		}
		PersistenceServiceResponse other = (PersistenceServiceResponse) obj;
		if (affectedItemsCount == null) {
			if (other.affectedItemsCount != null) {
				return false;
			}
		}
		else if (!affectedItemsCount.equals(other.affectedItemsCount)) {
			return false;
		}
		return true;
	}

	/**
	 * @return the affectedItemsCount
	 */
	public Integer getAffectedItemsCount() {
		return affectedItemsCount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((affectedItemsCount == null) ? 0 : affectedItemsCount
						.hashCode());
		return result;
	}

	/**
	 * @param affectedItemsCount the affectedItemsCount to set
	 */
	protected void setAffectedItemsCount(Integer affectedItemsCount) {
		this.affectedItemsCount = affectedItemsCount;
	}

	/**
	 * Throws ITM exception if errors are found
	 */
	protected void throwExceptionIfErrorFound() {
		if (hasErrors()) {
			throw new EaseException("Persistence Response has errors");
		}
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("affectedItemsCount", affectedItemsCount, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: PersistenceServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2012/01/06 19:36:32  mwkfh
 *  added IPersistenceServiceResponse
 *
 *  Revision 1.8  2011/01/06 19:46:01  mwkfh
 *  initialized affectedItemsCount to 0
 *
 *  Revision 1.7  2010/12/16 20:00:30  mwpxp2
 *  Removed toString/0; added toStringOn/2
 *
 *  Revision 1.6  2010/12/15 03:09:22  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.5  2010/10/13 00:56:58  mwpxp2
 *  Refactored to carry info about the number of affected items
 *
 *  Revision 1.4  2010/10/12 20:55:33  mwpxp2
 *  Added constructors from super
 *
 *  Revision 1.3  2010/09/15 00:18:55  mwpxp2
 *  Fixed serialVersionUID from default to generated value; added todo
 *
 *  Revision 1.2  2010/03/22 23:38:37  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/13 23:18:03  mwrsk
 *  Moved PersistenceServiceResponse to impl package
 *
 *  Revision 1.9  2009/10/12 19:03:48  mwrsk
 *  uncomment "throw new ItmException ("Persistence Response has errors");"
 *
 *  Revision 1.8  2009/10/03 21:32:45  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.7  2009/09/13 20:39:16  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.5.2.1  2009/09/12 19:09:19  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.5  2009/09/11 00:12:39  mwrsk
 *  added throwExceptionIfErrorFound();
 *
 *  Revision 1.4  2009/08/27 06:29:21  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.3  2009/08/27 03:42:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/05 20:40:18  mwrsk
 *  Refactored code to make persistence service work
 *
 *  Revision 1.1  2009/07/29 16:57:00  mwakg
 *  Changed the design of persistence service hence refractored code accordingly
 *
 */
