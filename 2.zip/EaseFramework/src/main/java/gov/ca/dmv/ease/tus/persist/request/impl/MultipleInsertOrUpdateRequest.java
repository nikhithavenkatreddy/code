/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleInsertOrUpdateResponse;

import java.util.Collection;

/**
 * Description: I am request to have a number of BOs persisted (inserted or updated)
 * preferably using a minimal number of db calls.
 * 
 * File: MultipleInsertOrUpdateRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Sep 1, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleInsertOrUpdateRequest extends
		MultiObjectPersistenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6046238360161420570L;

	/**
	 * @param userContext
	 * @param list
	 */
	public MultipleInsertOrUpdateRequest(IUserContext userContext,
			Collection <IBusinessObject> list) {
		super(userContext, list);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public MultipleInsertOrUpdateResponse execute() {
		return getPersistenceService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleInsertOrUpdateRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/09/14 00:40:33  mwkfh
 *  made persistenceService non-static
 *
 *  Revision 1.4  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/09/09 22:03:44  mwkfh
 *  removed default constructor and changed response object
 *
 *  Revision 1.2  2010/09/09 16:07:15  mwkfh
 *  added serialVersionUID
 *
 *  Revision 1.1  2010/09/01 20:00:06  mwpxp2
 *  Initial
 *
 */
