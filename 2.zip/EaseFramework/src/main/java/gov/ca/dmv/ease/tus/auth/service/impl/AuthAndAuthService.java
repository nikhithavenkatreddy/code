/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.service.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.fw.constants.IAuthAndAuthConstants;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.SpringUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.auth.impl.AuthenticationLoginContext;
import gov.ca.dmv.ease.tus.auth.impl.AuthenticationRequestValidation;
import gov.ca.dmv.ease.tus.auth.request.impl.AuthorizeApproverRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsListRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsMapRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveOperationalModesRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest;
import gov.ca.dmv.ease.tus.auth.response.IAuthorizeApproverResponse;
import gov.ca.dmv.ease.tus.auth.response.ILocationEnforcementResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsListResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveAuthorizedTtcsMapResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveOperationalModesResponse;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveUserAuthorizedRolesResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.AuthorizeApproverResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.LocationEnforcementResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.RetrieveAuthorizedTtcsListResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.RetrieveAuthorizedTtcsMapResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.RetrieveOperationalModesResponse;
import gov.ca.dmv.ease.tus.auth.response.impl.RetrieveUserAuthorizedRolesResponse;
import gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.auth.login.LoginContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ibm.websphere.security.auth.CredentialDestroyedException;
import com.ibm.ws.security.auth.WSCredentialImpl;

/**
 * Description: I am an AuthAndAuthServiceImpl class to provide 
 * the implementation of both Authentication and Authorization services
 * I check authentication using JAAS, i provide Approval Authorization and i provide the authorization.
 * File: AuthAndAuthService.java
 * Module:  gov.ca.dmv.ease.service.tech.auth.impl
 * Created: Apr 16, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 */
public class AuthAndAuthService implements IAuthAndAuthService {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(AuthAndAuthService.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7038440652653814011L;
	/** The AuthenticationLoginContext */
	private AuthenticationLoginContext authenticationLoginContext = new AuthenticationLoginContext();
	/** The FacesContext */
	private FacesContext facesContext = null;
	/** The operational modes */
	private Map <String, String> operationalModes;
	/** The server role list */
	private List <String> serverRoles = null;
	/** web.xml locations */
	private List <String> webxmlLocations;
	/** user context */
	private IUserContext user1Context;

	/**
	 * Gets the instance of IAuthAndAuthService.
	 * 
	 * @return instance of IAuthAndAuthService
	 */
	public static IAuthAndAuthService getInstance() {
		return (IAuthAndAuthService) EaseApplicationContext
				.getApplicationContext().getBean("authAndAuthService");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.AuthorizeApproverRequest)
	 */
	public IAuthorizeApproverResponse execute(AuthorizeApproverRequest request) {
		if (EaseUtil.isNullOrBlank(request.getUserName())
				|| EaseUtil.isNullOrBlank(request.getPassword())) {
			return new AuthorizeApproverResponse(new EaseValidationException(
					IAuthAndAuthConstants.APPROVAL_AUTHORITY_PASSWORD_REQUIRED));
		}
		else {
			try {
				if (isAuthorizedApprover(request.getUserName().toLowerCase(),
						request.getPassword(), request.getOfficeId(), request
								.getApprovalRole())) {
					return new AuthorizeApproverResponse(true);
				}
				else {
					return new AuthorizeApproverResponse(
							new EaseValidationException(
									IAuthAndAuthConstants.APPROVAL_AUTHORITY_APPROVER_INVALID));
				}
			}
			catch (EaseValidationException e) {
				return new AuthorizeApproverResponse(
						new EaseValidationException(
								IAuthAndAuthConstants.APPROVAL_AUTHORITY_PASSWORD_INVALID));
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsRequest)
	 */
	public IRetrieveAuthorizedTtcsListResponse execute(
			RetrieveAuthorizedTtcsListRequest request) {
		return new RetrieveAuthorizedTtcsListResponse(getAuthorizedTtcs(request
				.getRoles()));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsRequest)
	 */
	public IRetrieveAuthorizedTtcsMapResponse execute(
			RetrieveAuthorizedTtcsMapRequest request) {
		return new RetrieveAuthorizedTtcsMapResponse(
				getAuthorizedTtcsMap(request.getRoles()));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.RetrieveOperationalModesRequest)
	 */
	public IRetrieveOperationalModesResponse execute(
			RetrieveOperationalModesRequest request) {
		Map <String, String> modesMap = getOperationalModeMap(request
				.getOfficeId());
		return new RetrieveOperationalModesResponse(modesMap);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest)
	 */
	public IRetrieveUserAuthorizedRolesResponse execute(
			RetrieveUserAuthorizedRolesRequest request) {
		List <String> rolesList = getUserAuthorizedRoles(request.getOfficeId());
		return new RetrieveUserAuthorizedRolesResponse(rolesList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.service.IAuthAndAuthService#execute(gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest)
	 */
	public ILocationEnforcementResponse execute(
			LocationEnforcementRequest request) {
		boolean locationAuthorized = false;
		String authOfficeId = null;
		List<Location> locationList = null;
		List<String> authOfficeIdList = null;
		IErrorCollector aCollector = new ErrorCollector();
		request.getUserContext().validateUsing(aCollector);
		
		if (!aCollector.hasErrors()) {
			locationList = getAuthOfficeIdListByIpAddress(request.getIpAddress());	
			authOfficeIdList = new ArrayList <String>();
			for (Location location : locationList ) {
				authOfficeId = location.getOfficeId();
				authOfficeIdList.add(authOfficeId);
				if (authOfficeId.equals(request.getOfficeId())
						|| authOfficeId.equals(request.getRemoteOfficeId())) {
					locationAuthorized = true;
					break;
				} 
			}
		}
		return new LocationEnforcementResponse(locationAuthorized, authOfficeIdList);
	}

	/**
	 * Get Authorized Office Id By Ip Address.
	 * @param String ipAddress
	 * @return Authorized Office Id
	 */
	private List<Location> getAuthOfficeIdListByIpAddress(String ipAddress) {
		// Get Authorized Office Id list from LOCATION_INFO table
		List<Location> locationList = null;
		Location returnedLocation = null;
		Location location = new Location();
		location.setIpAddress(ipAddress);
		RetrieveBusinessObjectRequest retrieveBusinessObjectRequest = (RetrieveBusinessObjectRequest) PersistenceServiceRequestFactory
				.getInstance().createRetrieveBusinessObjectRequest(
						user1Context, location);
		RetrieveBusinessObjectResponse retrieveBusinessObjectResponse = retrieveBusinessObjectRequest
				.execute();
		if (retrieveBusinessObjectResponse.getResults() != null) {
			locationList = new ArrayList <Location>();
			for (IBusinessObject item : retrieveBusinessObjectResponse.getResults()) {
				returnedLocation = (Location) item;
				locationList.add(returnedLocation);
			}			
		} 
		return locationList;
	}

	/**
	 * Returns the authorized ttc list for the passed in role list.
	 * 
	 * @param roleNames
	 * @return List of ttcs
	 */
	@SuppressWarnings("unchecked")
	private List <String> getAuthorizedTtcs(List <String> roleNames) {
		List <String> ttcList = new ArrayList <String>();
		if (roleNames != null) {
			Iterator <String> iterRole = roleNames.iterator();
			while (iterRole.hasNext()) {
				ttcList.addAll(getAuthorizedTtcs(iterRole.next()));
			}
			if (roleNames.size() > 1) { //otherwise assume no duplicates
				//remove duplicates
				HashSet hashSet = new HashSet(ttcList);
				ttcList.clear();
				ttcList.addAll(hashSet);
			}
			Collections.sort(ttcList);
		}
		return ttcList;
	}

	/**
	 * Returns the authorized ttc list for the passed in role.
	 * 
	 * @param roleName
	 * @return List of ttcs
	 */
	@SuppressWarnings("unchecked")
	private List <String> getAuthorizedTtcs(String roleName) {
		List <String> ttcList = new ArrayList <String>();
		if (roleName != null) {
			try { //trap invalid role name
				Map <String, String[]> roleTtcs = SpringUtils.getBean(roleName);
				if (!roleTtcs.isEmpty()) {
					Iterator iter = roleTtcs.entrySet().iterator();
					while (iter.hasNext()) {
						Map.Entry pairs1 = (Map.Entry) iter.next();
						ttcList.addAll(Arrays.asList(pairs1.getValue()
								.toString().split(",")));
					}
				}
			}
			catch (NoSuchBeanDefinitionException be) {
				LOGGER.warn("Role name '" + roleName
						+ "' does not have a TTC map.");
			}
			//remove duplicates
			/* should not have any dups set in role
			HashSet hs = new HashSet(ttcList);
			ttcList.clear();
			ttcList.addAll(hs);
			*/
			Collections.sort(ttcList);
		}
		return ttcList;
	}

	/**
	 * Returns the authorized ttc map for the passed in role list.
	 * 
	 * @param roleNames
	 * @return Map of ttcs
	 */
	@SuppressWarnings("unchecked")
	private Map <String, String> getAuthorizedTtcsMap(List <String> roleNames) {
		Map <String, String> ttcMap = new LinkedHashMap <String, String>();
		if (roleNames != null) { //get TTC map
			Map <String, String> ttcMapAdd;
			Iterator <String> iterRole = roleNames.iterator();
			String roleName;
			while (iterRole.hasNext()) { //loop through roles list
				roleName = iterRole.next();
				try { //trap invalid role name
					ttcMapAdd = (Map <String, String>) SpringUtils
							.getBean(roleName); //returns Map<String, String>
					if ((ttcMapAdd != null) && !ttcMapAdd.isEmpty()) {
						if (!ttcMap.isEmpty()) {
							Map.Entry <String, String> mapEntry;
							Iterator <Map.Entry <String, String>> iterMap = ttcMapAdd
									.entrySet().iterator();
							while (iterMap.hasNext()) { //step through new map
								mapEntry = iterMap.next();
								if (ttcMap.containsKey(mapEntry.getKey())) {
									String ttcValue = ttcMap.get(mapEntry
											.getKey());
									if (!mapEntry.getValue().equals(ttcValue)) { //values don't equal
										//combine values
										List <String> meList = new ArrayList <String>();
										meList.addAll(Arrays.asList(mapEntry
												.getValue().toString().split(
														",")));
										meList.addAll(Arrays.asList(ttcValue
												.toString().split(",")));
										//remove duplicates and sort
										HashSet hashSet = new HashSet(meList);
										meList.clear();
										meList.addAll(hashSet);
										Collections.sort(meList);
										//convert back to csv String
										String temp = meList.toString();
										if (temp.length() > 1) {
											temp = temp.substring(1, temp
													.length() - 1);
										}
										//temp = temp.replaceAll("[", "");
										//temp = temp.replaceAll("]", "");
										temp = temp.replaceAll(" ", "");
										mapEntry.setValue(temp);
									} //else is new key
								}
							}
						}
						ttcMap.putAll(ttcMapAdd); //add or replace maps entries
					}
				}
				catch (NoSuchBeanDefinitionException be) {
					LOGGER.warn("Role name '" + roleName
							+ "' does not have a TTC map.");
				}
			}
		}
		LOGGER.debug("Returning TTC Map === " + ttcMap.toString());
		return ttcMap;
	}

	/**
	 * Returns the faces context.
	 * 
	 * @return the faces context
	 */
	private FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		}
		else {
			return facesContext;
		}
	}

	/**
	 * This method instantiates the AuthenticationLoginContext, which uses the appropriate LoginModule
	 * and callback handler with userId and password, and returns the login context.
	 * 
	 * @param String user id
	 * @param String password
	 * @return LoginContext or null
	 */
	private LoginContext getLoginContext(String userId, String password) {
		LoginContext loginContext = null;
		AuthenticationRequestValidation authValidation = new AuthenticationRequestValidation();
		boolean validAuthRequest = authValidation
				.validateAuthenticationRequest(userId, password);
		if (validAuthRequest) {
			try {
				authenticationLoginContext.setUserId(userId);
				authenticationLoginContext.setPassword(password);
				loginContext = authenticationLoginContext
						.getAuthenticationContext();
			}
			catch (Exception e) {
				LOGGER.debug("getLoginContext(String, String) - "
						+ e.toString());
			}
		}
		return loginContext;
	}

	/**
	 * Returns the operational mode map for the passed in office.
	 * 
	 * @param officeId
	 * @return Map of operational modes
	 */
	private Map <String, String> getOperationalModeMap(String officeId) {
		if (EaseUtil.isNullOrBlank(officeId)) {
			return null;
		}
		else {
			return getOperationalModes();
		}
	}

	/**
	 * Returns the operational modes.
	 * 
	 * @return Map <String, String> operational modes
	 */
	private Map <String, String> getOperationalModes() {
		return operationalModes;
	}

	/**
	 * Returns a list of roles.
	 * 
	 * @return the list of roles
	 */
	private List <String> getServerRoles() {
		/*
		serverRoles = getServerRolesFromWebXml();
		if (serverRoles.isEmpty()) {
			serverRoles.add("DL_CASHIER");
			serverRoles.add("DL_CORRECTIONS");
			serverRoles.add("DL_COUNSELOR");
			serverRoles.add("DL_CAMERA");
			serverRoles.add("DL_ISSUANCE");
		}
		LOGGER.info("Server roles === " + serverRoles.toString());
		*/
		return serverRoles;
	}

	/**
	 * Returns a list of roles from the web.xml.
	 * 
	 * @return the list of roles
	 */
	private List <String> getServerRolesFromWebXml() {
		List <String> webXmlRoles = new ArrayList <String>();
		try {
			if (getWebxmlLocations() != null) {
				boolean isFound = false;
				String webxmlLoc = "";
				Resource webXml = null;
				Iterator <String> iterWebxmlList = getWebxmlLocations()
						.iterator();
				while (!isFound && iterWebxmlList.hasNext()) {
					webxmlLoc = iterWebxmlList.next();
					webXml = new ClassPathResource(webxmlLoc);
					LOGGER.info("web.xml location === '"
							+ webXml.getDescription() + "'");
					if (webXml.exists()) {
						isFound = true;
					}
					else {
						webXml = new FileSystemResource(webxmlLoc);
						LOGGER.info("web.xml location === '"
								+ webXml.getDescription() + "'");
						if (webXml.exists()) {
							isFound = true;
						}
					}
				}
				if (isFound) {
					LOGGER.info("Found webxml at '" + webXml.getDescription()
							+ "'");
					DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
							.newInstance();
					DocumentBuilder docBuilder = docBuilderFactory
							.newDocumentBuilder();
					Document doc = docBuilder.parse(webXml.getFile());
					NodeList listOfRoles = doc
							.getElementsByTagName(IAuthAndAuthConstants.TAG_SECURITY_ROLE);
					if ((listOfRoles != null) && listOfRoles.getLength() > 0) {
						for (int index = 0; index < listOfRoles.getLength(); index++) {
							Node roleNode = listOfRoles.item(index);
							if (roleNode.getNodeType() == Node.ELEMENT_NODE) {
								Element roleElement = (Element) roleNode;
								NodeList roleNameList = roleElement
										.getElementsByTagName(IAuthAndAuthConstants.TAG_ROLE_NAME);
								if ((roleNameList != null)
										&& roleNameList.getLength() > 0) {
									Element roleNameElement = (Element) roleNameList
											.item(0);
									NodeList textNameList = roleNameElement
											.getChildNodes();
									if ((textNameList != null)
											&& textNameList.getLength() > 0) {
										webXmlRoles.add((textNameList.item(0))
												.getNodeValue().trim());
									}
								}
							}
						}
					}
				}
			}
		}
		catch (Exception e) {
			LOGGER.error("Error loading roles from web.xml.  " + e.toString());
		}
		LOGGER.info("web.xml roles loaded === " + webXmlRoles.toString());
		return webXmlRoles;
	}

	/**
	 * Returns the list of roles for the current user.
	 * 
	 * @return List of roles
	 */
	private List <String> getUserAuthorizedRoles(String officeId) {
		List <String> rolesList = new ArrayList <String>();
		List <String> serverRolesList = getServerRoles();
		if (serverRolesList != null) {
			String role;
			Iterator <String> iter = serverRolesList.iterator();
			//int nbrServerRoles = serverRolesList.size();
			while (iter.hasNext()) {
				role = iter.next();
				if (isUserAuthorized(role)) {
					rolesList.add(role);
				}
			}
			
			addIssuanceRole(rolesList, officeId);
			
			if (!rolesList.isEmpty()) {
				if (rolesList.contains(IAuthAndAuthConstants.ROLE_DL_CASHIER) && 
					rolesList.contains(IAuthAndAuthConstants.ROLE_DL_CORRECTIONS) &&
					rolesList.contains(IAuthAndAuthConstants.ROLE_DL_COUNSELOR) &&
					rolesList.contains(IAuthAndAuthConstants.ROLE_DL_CAMERA)) {
					
					// remove this 4 item and add "DL_ALL"
					rolesList.remove(IAuthAndAuthConstants.ROLE_DL_CASHIER);
					rolesList.remove(IAuthAndAuthConstants.ROLE_DL_CORRECTIONS);
					rolesList.remove(IAuthAndAuthConstants.ROLE_DL_COUNSELOR);
					rolesList.remove(IAuthAndAuthConstants.ROLE_DL_CAMERA);
					
					rolesList.add((serverRolesList.get(0)).substring(0, 3)
							+ IAuthAndAuthConstants.ROLE_ALL_SUFFIX);																
				}
			}						
		}
		LOGGER.info("user roles === " + rolesList.toString());
		return rolesList; //(rolesList.isEmpty()?null:rolesList);
	}

	/**
	 * @param rolesList
	 * @param officeId
	 */
	private void addIssuanceRole(List <String> rolesList, String officeId) {
		String role = IAuthAndAuthConstants.ROLE_ISSUANCE + "_" + officeId;
		if (isUserAuthorized(role)) {
			rolesList.add(role);
		}		
	}

	/**
	 * Returns the location of the web.xml file.
	 * 
	 * @return String the location of the web.xml file
	 */
	private List <String> getWebxmlLocations() {
		/*
		List <String> webxmlLocations = new ArrayList <String>();
		webxmlLocations.add("../EASEDriversLicense/WEB-INF/web.xml");
		if (webxmlLocations == null) {
			webxmlLocations = new ArrayList <String>();
		}
		//add possible cell server locations
		File celldir = new File("installedApps");
		if (celldir.isDirectory()) {
			File[] subdirs = celldir.listFiles();
			for (File subdir : subdirs) {
				webxmlLocations.add("installedApps/" + subdir.getName()
						+ "/DLear.ear/EASEDriversLicense.war/WEB-INF/web.xml");
			}
		}
		*/
		return webxmlLocations;
	}

	/**
	 * Authenticates and Authorizes user as approver.
	 * 
	 * @param userId
	 * @param password
	 * @param officeId
	 * @param approverRole
	 * 
	 * @return true if authorized; else false if authenticated but not authorized
	 * @throws EaseValidationException if not authenticated
	 */
	@SuppressWarnings("unchecked")
	private boolean isAuthorizedApprover(String userId, String password,
			String officeId, String approverRole)
			throws EaseValidationException {
		//user id lower case
		userId = userId.toLowerCase();
		LoginContext loginContext = getLoginContext(userId, password);
		if (loginContext != null) {
			try {
				loginContext.login();
			}
			catch (Exception e) {
				LOGGER
						.debug("isAuthorizedApprover(String, String, String, String) - "
								+ e.toString());
				throw new EaseValidationException(e);
			}
			if ((loginContext != null)
					&& (loginContext.getSubject() != null)
					&& (loginContext.getSubject().getPublicCredentials() != null)) {
				String approvalGroup = approverRole;
				if ((officeId != null) && !officeId.trim().equals("")) {
					approvalGroup += "_" + officeId;
				}
				Iterator <Object> iterCreds = loginContext.getSubject()
						.getPublicCredentials().iterator();
				while (iterCreds.hasNext()) {
					WSCredentialImpl cred = (WSCredentialImpl) iterCreds.next();
					try {
						ArrayList <String> groupIds = cred.getGroupIds();
						if (groupIds != null) {
							Iterator <String> iterGroups = groupIds.iterator();
							while (iterGroups.hasNext()) {
								String groupId = iterGroups.next();
								LOGGER.debug("User '" + userId
										+ "' with group = '" + groupId + "'.");
								if (groupId.contains(approvalGroup)) {
									LOGGER
											.debug(userId
													+ " has group '"
													+ approvalGroup
													+ "' and has been authorized to approve.");
									return true;
								}
							}
						}
					}
					catch (CredentialDestroyedException cde) {
						LOGGER
								.warn("CredentialDestroyedException thrown for user '"
										+ userId + "'::" + cde.getMessage());
					}
					catch (CredentialExpiredException cde) {
						LOGGER
								.warn("CredentialExpiredException thrown for user '"
										+ userId + "'::" + cde.getMessage());
					}
				}
			}
		}
		return false;
	}

	/**
	 * Authorize user.  Returns true is user has the passed in role.
	 * 
	 * @param String roleName the role name
	 * 
	 * @return boolean true, if successful
	 */
	private boolean isUserAuthorized(String roleName) {
		boolean isAuthorized = false;
		AuthenticationRequestValidation authValidation = new AuthenticationRequestValidation();
		boolean validAuthRequest = authValidation
				.validateAuthorizationRequest(roleName);
		if (validAuthRequest) {
			FacesContext facesContext = getFacesContext();
			//if (FacesContext.getCurrentInstance() != null) {
			if (facesContext != null) {
				LOGGER.debug("fCtx === not null");
				//facesContext = FacesContext.getCurrentInstance();
				ExternalContext externalCtx = facesContext.getExternalContext();
				if (externalCtx != null) {
					isAuthorized = externalCtx.isUserInRole(roleName);
					LOGGER.debug("User Principal === "
							+ externalCtx.getUserPrincipal());
					LOGGER.info("rolename === " + roleName
							+ " eCtx.isUserInRole() === "
							+ externalCtx.isUserInRole(roleName));
					LOGGER.debug("externalCtx.getAuthType()"
							+ externalCtx.getAuthType());
				}
			}
		}
		return isAuthorized;
	}

	/**
	 * Sets the authenticationLoginContext.
	 * 
	 * @param authenticationLoginContext the authenticationLoginContext to set
	 */
	public void setAuthenticationLoginContext(AuthenticationLoginContext aCtx) {
		authenticationLoginContext = aCtx;
	}

	/**
	 * Returns the faces context.
	 * 
	 * @param facesContext the facesContext to set
	 */
	public void setFacesContext(FacesContext aCtx) {
		facesContext = aCtx;
	}

	/**
	 * Sets the operational modes map.
	 * 
	 * @param operationalModes
	 */
	public void setOperationalModes(Map <String, String> operationalModes) {
		this.operationalModes = operationalModes;
	}

	/**
	 * Sets a list of roles.
	 * 
	 * @param List of roles
	 */
	public void setServerRoles(List <String> roles) {
		if ((roles != null) && (!roles.isEmpty())) {
			//override roles
			serverRoles = roles;
		}
		else {
			serverRoles = getServerRolesFromWebXml();
		}
		LOGGER.info("Server roles === " + serverRoles.toString());
	}

	/**
	 * Sets the location of the web.xml file.
	 * 
	 * @param String the location of the web.xml file
	 */
	public void setWebxmlLocations(List <String> webxmlLocs) {
		webxmlLocations = webxmlLocs;
		if (webxmlLocations == null) {
			webxmlLocations = new ArrayList <String>();
		}
		//add possible cell server locations
		File celldir = new File("installedApps");
		if (celldir.isDirectory()) {
			File[] subdirs = celldir.listFiles();
			for (File subdir : subdirs) {
				webxmlLocations.add("installedApps/" + subdir.getName()
						+ "/DLear.ear/EASEDriversLicense.war/WEB-INF/web.xml");
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuthAndAuthService.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.71  2012/06/22 23:52:17  mwxxw
 *  Change DL_ISSUANCE_212 to ISSUANCE_212
 *
 *  Revision 1.70  2012/06/15 17:27:19  mwxxw
 *  Add new function: addIssuanceRole() to set dynamic roles.
 *
 *  Revision 1.69  2012/01/11 00:02:58  mwxxw
 *  Add new role for EASE: DL_APU.
 *
 *  Revision 1.68  2012/01/10 19:34:58  mwxxw
 *  Display AuthOfficeIdList on location enforcement page.
 *
 *  Revision 1.67  2012/01/09 22:17:38  mwxxw
 *  Updated to allow multiple authorized office ids for one IP address.
 *
 *  Revision 1.66  2011/11/11 02:21:02  mwxxw
 *  Validate userContext before query location table.
 *
 *  Revision 1.65  2011/10/25 18:18:14  mwxxw
 *  Add new security role: EASE_R_DL_ISSUANCE_LP.
 *
 *  Revision 1.64  2011/07/15 16:45:20  mwxxw
 *  Update logic for getUserAuthorizedRoles() to handle new security role DL_NO_UPDATE.
 *
 *  Revision 1.63  2011/03/23 23:46:58  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.62  2011/01/18 19:50:53  mwxxw
 *  Move office business related logic from AuthAndAuthService to OfficeBusinessService.
 *
 *  Revision 1.61  2010/12/24 18:43:47  mwhxb3
 *  converted user id to lowecase.
 *
 *  Revision 1.60  2010/12/23 06:10:40  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.59.2.2  2010/12/23 01:29:49  mwkkc
 *  Rebase from head - Arch
 *
 *  Revision 1.59  2010/12/16 22:13:35  mwxxw
 *  Remove the old API: isAuthorizedApprover().
 *
 *  Revision 1.58  2010/12/14 01:23:21  mwxxw
 *  Fix the empty location list issue for a ipAddress.
 *
 *  Revision 1.57  2010/12/09 21:33:39  mwxxw
 *  Pass in the ipAddress for location info table query.
 *
 *  Revision 1.56  2010/12/09 00:30:25  mwxxw
 *  Add new service to AuthAndAuthService for Office Business.
 *
 *  Revision 1.55  2010/12/07 20:20:08  mwxxw
 *  Add authOfficeId to the service response.
 *
 *  Revision 1.54  2010/12/07 00:42:26  mwxxw
 *  Update for location enforcement service.
 *
 *  Revision 1.53  2010/12/03 01:25:31  mwxxw
 *  Updated logic for location enforcement service.
 *
 *  Revision 1.52  2010/12/02 00:14:59  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.51  2010/11/30 23:11:53  mwxxw
 *  Updated logic for location enforcement service.
 *
 *  Revision 1.50  2010/11/30 18:53:55  mwxxw
 *  Add the following new service for location enforcement service:
 *  ILocationEnforcementResponse execute(LocationEnforcementRequest request);
 *
 *  Revision 1.49  2010/11/22 22:07:41  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 *  Revision 1.48  2010/11/10 16:49:49  mwkfh
 *  clean up
 *
 *  Revision 1.47  2010/10/15 00:35:48  mwkfh
 *  moved constants to IAuthAndAuthContants
 *
 *  Revision 1.46  2010/10/12 21:56:26  mwkfh
 *  added APPROVAL_AUTHORITY_PASSWORD_REQUIRED check to execute(AuthApprReq)
 *
 *  Revision 1.45  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 *  Revision 1.44  2010/09/23 16:29:21  mwsec2
 *  FIXME added
 *
 *  Revision 1.43  2010/09/13 16:48:09  mwkfh
 *  added call to getServerRolesFromWebXml in getServerRoles
 *
 *  Revision 1.42  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.41  2010/09/09 15:21:22  mwkfh
 *  updated getLoginContext to use getter
 *
 *  Revision 1.40  2010/09/01 19:07:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.39  2010/08/27 16:23:08  mwkfh
 *  moved constant, deleted authorizeManager, and cleanup
 *
 *  Revision 1.38  2010/08/20 16:20:57  mwkfh
 *  deprecated authenticateUser()
 *
 *  Revision 1.37  2010/08/10 23:07:27  mwkfh
 *  updated setServerRoles() to print roles from web.xml every load
 *
 *  Revision 1.36  2010/08/05 22:24:16  mwkfh
 *  code cleanup
 *
 *  Revision 1.35  2010/08/04 18:19:26  mwkfh
 *  updated the name getAuthorizedTtcs
 *
 *  Revision 1.34  2010/07/30 22:09:40  mwkfh
 *  made getServerRolesFromWebXml() private
 *
 *  Revision 1.33  2010/07/15 22:40:06  mwkfh
 *  printed server roles to log in setServerRoles
 *
 *  Revision 1.32  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.31  2010/07/07 20:02:15  mwkfh
 *  caught CredentialDestroyedException and wrote to log
 *
 *  Revision 1.30  2010/07/07 19:47:30  mwkfh
 *  changed isAuthorizedApprover() to throw CredentialDestroyedException
 *
 *  Revision 1.29  2010/07/01 16:47:43  mwkfh
 *  re-added lost changes to getServerRolesFromWebXml()
 *
 *  Revision 1.28  2010/06/30 18:29:40  mwkfh
 *  overloaded isAuthorizedApprover()
 *
 *  Revision 1.27  2010/06/25 01:32:55  mwkfh
 *  updated GROUP_APPROVER
 *
 *  Revision 1.26  2010/06/21 23:00:47  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.16.2.2  2010/06/20 18:06:58  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.24  2010/06/14 20:08:58  mwkfh
 *  Changed webxmlLocations to List and added Log to test reading roles in  web.xml
 *
 *  Revision 1.23  2010/06/03 18:58:25  mwkfh
 *  added injection for webxmlLocation and fixed FacesContext to work with JUnit tests.
 *
 *  Revision 1.22  2010/06/03 16:06:50  mwkfh
 *  changed authMgr to isAuthorizedApprover() and fixed FacesContext bug for invalid state.
 *
 *  Revision 1.21  2010/06/01 21:30:51  mwkfh
 *  added space in logger output
 *
 *  Revision 1.20  2010/06/01 19:00:51  mwkfh
 *  added null office id check to authorizeManager()
 *
 *  Revision 1.19  2010/06/01 17:20:07  mwkfh
 *  set authorizeManager() to throw LoginException
 *
 *  Revision 1.18  2010/06/01 17:08:01  mwkfh
 *  added officeId to authorizeManager() params
 *
 *  Revision 1.17  2010/06/01 16:21:29  mwkfh
 *  added getFacesContext() and updated facesContext in isUserAuthorized()
 *
 *  Revision 1.16  2010/05/28 19:06:29  mwkkc
 *  added getServerRolesFromWebXml() - mwkfh
 *
 *  Revision 1.15  2010/05/26 17:36:30  mwkkc
 *  injected Server Roles list from Spring - mwkfh
 *
 *  Revision 1.14  2010/05/25 21:34:00  mwpxp2
 *  Removed unnecessary "t~his.-es"
 *
 *  Revision 1.13  2010/05/20 22:29:50  mwkkc
 *  Changed return logger in getAuthorizedTtcsMap() to debug.
 *
 *  Revision 1.12  2010/05/20 22:12:47  mwvkm
 *  Made it serializable
 *
 *  Revision 1.11  2010/05/20 21:54:22  mwkkc
 *  Removed spaces from result in getAuthorizedTtcsMap() - mwkfh
 *
 *  Revision 1.10  2010/05/20 21:34:28  mwkkc
 *  updated getAuthorizedTtcsMap() - mwkfh
 *
 *  Revision 1.9  2010/05/20 20:38:02  mwrpk
 *  updating getAuthorizedTtcsMap()
 *
 *  Revision 1.8  2010/05/20 19:29:37  mwkkc
 *  Updated getAuthorizedTtcsMap() - mwkfh
 *
 *  Revision 1.7  2010/05/19 22:51:07  mwkkc
 *  Updated getUserAuthorizedRoles() to return DL_ALL if user has all roles. - mwkfh
 *
 *  Revision 1.6  2010/05/19 22:10:41  mwkkc
 *  added getAuthorizedTtcsMap() - mwkfh
 *
 *  Revision 1.5  2010/05/19 00:39:20  mwkkc
 *  Added trap for invalid role not to return NoSuchBeanDefinitionException - kfh
 *
 *  Revision 1.4  2010/05/19 00:13:39  mwkkc
 *  only remove duplicates if more than one role passed - mwkfh
 *
 *  Revision 1.3  2010/05/19 00:10:52  mwkkc
 *  implemented sort and dup removal for getAuthorizedTtcs() - mwkfh
 *
 *  Revision 1.2  2010/05/18 22:34:43  mwkkc
 *  Added getUserAuthorizedRoles(), getAuthorizedTtcs(), and getAuthorizedTtcs() - mwkfh
 *
 *  Revision 1.1  2010/05/18 19:35:46  mwkkc
 *  AuthenticationService renamed to AuthAndAuthService - mwkfh
 *
 *  Revision 1.6  2010/05/10 22:16:28  mwrpk
 *  SLTT -- bug fix
 *
 *  Revision 1.5  2010/03/22 23:36:45  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/03/20 20:34:19  mwkkc
 *  WS#3 Merge - Trace work
 *
 *  Revision 1.3  2010/01/14 18:31:23  mwpzs3
 *  move to JCL logging
 *
 *  Revision 1.2  2009/12/09 19:37:08  mwpxp2
 *  Replaced system.outs with logging
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.32  2009/11/18 19:37:48  mwhxb3
 *  restructured class, initialized the authenticationLoginContext and facesContext in constructor, added setters and getters for them.
 *
 *  Revision 1.31  2009/11/11 21:37:43  mwakg
 *  Commented debug statements
 *
 *  Revision 1.30  2009/10/31 23:36:30  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.29  2009/10/31 22:36:25  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.28  2009/10/30 22:23:22  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.27  2009/10/29 21:13:15  mwjxa11
 *  Fixed the issues raised in PMD reports
 *
 *  Revision 1.26  2009/10/29 00:48:07  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.25  2009/10/28 16:34:26  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.24  2009/10/28 02:57:10  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.23  2009/10/28 01:29:57  mwrsk
 *  Stage 2 testing
 *
 *  Revision 1.22  2009/10/27 23:59:59  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.21  2009/10/27 23:15:23  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.20  2009/10/27 22:59:23  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.19  2009/10/27 22:47:56  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.18  2009/10/27 21:54:05  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.17  2009/10/27 21:20:54  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.16  2009/10/27 16:53:40  mwkkc
 *  Stage 2 Security Testing
 *
 *  Revision 1.15  2009/10/20 21:18:11  mwrsk
 *  Added disclaimer
 *
 *  Revision 1.14  2009/10/17 23:36:55  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.13  2009/10/16 02:33:44  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.12  2009/10/16 01:27:47  mwrsk
 *  Business Transaction Level Authorization
 *
 *  Revision 1.11  2009/10/15 22:38:30  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.10  2009/10/15 22:16:12  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.9  2009/10/14 02:48:35  mwkkc
 *  I1 Close Down - Code Review
 *
 *  Revision 1.8  2009/10/12 23:36:34  mwkkc
 *  Got rid of Warning
 *
 *  Revision 1.7  2009/10/12 18:15:40  mwkkc
 *  Approval Authorization and JAAS implementation.
 *
 *  Revision 1.6  2009/10/03 21:32:50  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/09/23 00:01:14  mwbxp5
 *  Added authorization activity and its related classes
 *
 *  Revision 1.4  2009/09/22 23:15:09  mwkkc
 *  Design Work
 *
 *  Revision 1.3  2009/09/22 22:24:02  mwkkc
 *  Reflection Update Design Doc
 *
 *  Revision 1.2  2009/07/21 21:18:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:45  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 18:17:29  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-07-11 17:26:25  mwpxp2
 *  Moved to service.impl package; cleaned up comments and javadoc; added todos
 *
 *  Revision 1.1  2009-07-10 07:13:57  mwpxp2
 *  Synch
 *
 */
