/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.service.impl;

import gov.ca.dmv.ease.app.session.request.impl.DeleteSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RestoreSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.StoreSessionRequest;
import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.app.session.response.impl.DeleteSessionResponse;
import gov.ca.dmv.ease.app.session.response.impl.RestoreSessionResponse;
import gov.ca.dmv.ease.app.session.response.impl.RetrieveSessionResponse;
import gov.ca.dmv.ease.app.session.response.impl.StoreSessionResponse;
import gov.ca.dmv.ease.app.session.service.ISessionService;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.ServiceRequestExecutionException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.IPersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SaveOrUpdateBusinessObjectResponse;
import gov.ca.dmv.ease.tus.session.persist.request.ISessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.factory.impl.SessionPersistenceRequestFactory;
import gov.ca.dmv.ease.tus.session.persist.response.impl.UpdateSessionPersistenceResponse;

import java.util.Calendar;

/**
 * Description: The purpose of this class is to implement the persistence store logic for the session
 * with minimal public interface.
 *
 * File: SessionService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service.impl
 * Created: Apr 28, 2010
 * @author MWVKM
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/12/13 00:15:24 $
 * Last Changed By: $Author: mwhys $
 */
public class SessionService implements ISessionService {
	/** Logger for this class. */
	//private static final Log LOGGER = LogFactory.getLog(SessionService.class);
	/** The SINGLETON. */
	private static ISessionService SINGLETON;

	/**
	 * Gets the instance of SessionService.
	 *
	 * @return instance of SessionService
	 */
	public static ISessionService getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		SINGLETON = new SessionService();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.impl.ISessionService#execute(gov.ca.dmv.ease.app.session.request.impl.DeleteSessionRequest)
	 */
	public ISessionServiceResponse execute(DeleteSessionRequest request) {
		IPersistenceServiceResponse persistenceResponse = executeDeleteSession(
				request.getUserContext(), request.getSessionObject());
		if (persistenceResponse.hasErrors()) {
			return new DeleteSessionResponse(persistenceResponse
					.getErrorCollector());
		}
		else {
			return new DeleteSessionResponse(); //TODO values from the persistence response should be retained
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.impl.ISessionService#execute(gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest)
	 */
	public ISessionServiceResponse execute(RestoreSessionRequest request) {
		Session sessionObject = request.getSessionObject();
		IUserContext userContext = request.getUserContext();
		if (!sessionObject.hasId()) {
			/* retrieve object */
			RetrieveBusinessObjectResponse retrieveResponse = executeRetrieveSession(
					userContext, sessionObject);
			if (retrieveResponse.hasErrors()) {
				return new RestoreSessionResponse(retrieveResponse
						.getErrorCollector());
			}
			else if (retrieveResponse.hasResults()) {
				sessionObject = (Session) retrieveResponse.getResults().get(0);
			}
		}
		if (sessionObject.hasId()) {
			/* Update session id in the database */
			// Session ID is not used, so there is no need to update it.
			/*sessionObject.setSessionId(request.getNewSessionId());
			SaveOrUpdateBusinessObjectResponse persistenceServiceResponse = executeStoreSession(
					userContext, sessionObject);
			if (persistenceServiceResponse.hasErrors()) {
				return new RestoreSessionResponse(persistenceServiceResponse
						.getErrorCollector());
			}
			else {*/
			return new RestoreSessionResponse(sessionObject);
			//}
		}
		else {
			return new RestoreSessionResponse(
					new ServiceRequestExecutionException(SESSION_NOT_FOUND));
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.impl.ISessionService#execute(gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest)
	 */
	public ISessionServiceResponse execute(RetrieveSessionRequest request) {
		/* Fetch from database */
		RetrieveBusinessObjectResponse persistenceServiceResponse = executeRetrieveSession(
				request.getUserContext(), request.getSessionObject());
		if (persistenceServiceResponse.hasErrors()) {
			return new RetrieveSessionResponse(persistenceServiceResponse
					.getErrorCollector());
		}
		else if (persistenceServiceResponse.getResults().size() > 0) {
			/* There is a hit in the database */
			/* check if older than today */
			Calendar calToday = Calendar.getInstance();
			//Note: Do not use CurrentDateProvider, as BusinessObjectInterceptor uses current date.
			//calToday.setTime(CurrentDateProvider.getInstance().getSystemDate());
			calToday.set(Calendar.HOUR_OF_DAY, 0);
			calToday.set(Calendar.MINUTE, 0);
			calToday.set(Calendar.SECOND, 0);
			calToday.set(Calendar.MILLISECOND, 0);
			//comparing to tomorrow in case system date ever set back
			Calendar calTomorrow = Calendar.getInstance();
			/*calTomorrow.setTime(CurrentDateProvider.getInstance()
					.getSystemDate());*/
			calTomorrow.add(Calendar.DATE, 1);
			calTomorrow.set(Calendar.HOUR_OF_DAY, 0);
			calTomorrow.set(Calendar.MINUTE, 0);
			calTomorrow.set(Calendar.SECOND, 0);
			calTomorrow.set(Calendar.MILLISECOND, 0);
			Session session = (Session) persistenceServiceResponse.getResults()
					.get(0);
			if (calToday.getTime().before(session.getModifiedDate())
					&& calTomorrow.getTime().after(session.getModifiedDate())) {
				return new RetrieveSessionResponse(session);
			}
			else {
				//delete old session
				IPersistenceServiceResponse deletePersistenceServiceResponse = executeDeleteSession(
						request.getUserContext(), session);
				if (deletePersistenceServiceResponse.hasErrors()) {
					return new RetrieveSessionResponse(
							deletePersistenceServiceResponse
									.getErrorCollector());
				}
				else {
					return new RetrieveSessionResponse(
							new ServiceRequestExecutionException(
									OLD_SESSION_FOUND));
				}
			}
		}
		else {
			/* There is no record in the database */
			return new RetrieveSessionResponse(
					new ServiceRequestExecutionException(SESSION_NOT_FOUND));
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.impl.ISessionService#execute(gov.ca.dmv.ease.app.session.request.impl.StoreSessionRequest)
	 */
	public ISessionServiceResponse execute(StoreSessionRequest request) {
		Session sessionObject = request.getSessionObject();
		IUserContext userContext = request.getUserContext();
		if (sessionObject.hasId()) {
			//Update the existing session in the database
			UpdateSessionPersistenceResponse updateSessionPersistenceResponse = executeUpdateSession(
					userContext, sessionObject);
			if (updateSessionPersistenceResponse.hasErrors()) {
				return new StoreSessionResponse(
						updateSessionPersistenceResponse.getErrorCollector());
			}
		}
		else {
			//Insert a new session in the database
			/* Load old session from database */
			RetrieveBusinessObjectResponse fetchResponse = executeRetrieveSession(
					userContext, new Session(sessionObject.getOfficeId(),
							sessionObject.getTechId(), sessionObject
									.getUserName()));
			if (fetchResponse.hasResults()) {
				IBusinessObject fetchedSession = fetchResponse.getResults()
						.get(0);
				sessionObject.setId(fetchedSession.getId());
				sessionObject.setCreatedBy(fetchedSession.getCreatedBy());
				sessionObject.setCreatedDate(fetchedSession.getCreatedDate());
			}
			/* Store in the database */
			SaveOrUpdateBusinessObjectResponse persistenceServiceResponse = executeStoreSession(
					userContext, sessionObject);
			if (persistenceServiceResponse.hasErrors()) {
				return new StoreSessionResponse(persistenceServiceResponse
						.getErrorCollector());
			}
		}
		return new StoreSessionResponse();
	}

	/**
	 * Deletes the passed in session object.
	 *
	 * @param userContext the user context
	 * @param sessionObject the session object
	 * @return IPersistenceServiceResponse
	 */
	private IPersistenceServiceResponse executeDeleteSession(
			IUserContext userContext, Session sessionObject) {
		IErrorCollector aCollector = sessionObject.validate();
		if (aCollector.hasErrors()) {
			return new PersistenceServiceResponse(aCollector);
		}
		else {
			ISessionPersistenceRequest persistenceRequest = SessionPersistenceRequestFactory
					.getInstance().createDeleteSessionPersistenceRequest(
							userContext, sessionObject);
			return persistenceRequest.execute();
		}
	}

	/**
	 * Retrieves session object from the database.
	 *
	 * @param userContext the user context
	 * @param sessionObject the session object
	 * @return RetrieveBusinessObjectResponse
	 */
	private RetrieveBusinessObjectResponse executeRetrieveSession(
			IUserContext userContext, Session sessionObject) {
		IPersistenceServiceRequest persistenceServiceRequest = PersistenceServiceRequestFactory
				.getInstance().createRetrieveBusinessObjectRequest(userContext,
						sessionObject);
		/* Fetch from database */
		return (RetrieveBusinessObjectResponse) persistenceServiceRequest
				.execute();
	}

	/**
	 * Stores session object to the database.
	 *
	 * @param userContext the user context
	 * @param sessionObject the session object
	 * @return SaveOrUpdateBusinessObjectResponse
	 */
	private SaveOrUpdateBusinessObjectResponse executeStoreSession(
			IUserContext userContext, Session sessionObject) {
		IPersistenceServiceRequest persistenceServiceRequest = PersistenceServiceRequestFactory
				.getInstance().createSaveOrUpdateBusinessObjectRequest(
						userContext, sessionObject);
		/* Fetch from database */
		return (SaveOrUpdateBusinessObjectResponse) persistenceServiceRequest
				.execute();
	}
	
	/**
	 * Updates session object in the database.
	 *
	 * @param userContext the user context
	 * @param sessionObject the session object
	 * @return the update session persistence response
	 */
	private UpdateSessionPersistenceResponse executeUpdateSession(
			IUserContext userContext, Session sessionObject) {
		ISessionPersistenceRequest sessionPersistenceServiceRequest = SessionPersistenceRequestFactory
				.getInstance().createUpdateSessionPersistenceRequest(
						userContext, sessionObject);
		/* Update database */
		return (UpdateSessionPersistenceResponse) sessionPersistenceServiceRequest
				.execute();
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionService.java,v $
 *  Revision 1.3  2012/12/13 00:15:24  mwhys
 *  Updated execute(StoreSessionRequest) to update session based on SYS_ID.
 *
 *  Revision 1.2  2012/10/29 20:49:09  mwkfh
 *  fixed execute(RetrieveSessionRequest) set HOUR to 12am
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.35  2012/09/10 17:00:36  mwkfh
 *  zeroed out calTomorrow hour, minute, seconds
 *
 *  Revision 1.34  2012/09/07 02:09:23  mwrrv3
 *  Replaced IBM package with java.util package.
 *
 *  Revision 1.33  2012/08/25 01:29:05  mwpxp2
 *  Added todo
 *
 *  Revision 1.32  2012/05/08 00:20:10  mwhys
 *  Changes made for Session Management:
 *  1. Updated restore process (to not update the session in database)
 *  2. Updated retrieve process (to use calendar date against CurrentDateProvider)
 *
 *  Revision 1.31  2012/01/11 19:02:04  mwkfh
 *  updated retrieve to use system date
 *
 *  Revision 1.30  2012/01/11 01:21:59  mwkfh
 *  updated execute store
 *
 *  Revision 1.29  2012/01/10 23:50:03  mwkfh
 *  updated execute RestoreSessionRequest
 *
 *  Revision 1.28  2012/01/10 18:11:50  mwkfh
 *  removed SINGLETON initializer
 *
 *  Revision 1.27  2012/01/06 23:13:26  mwkfh
 *  updated StoreSession
 *
 *  Revision 1.26  2012/01/06 19:40:11  mwkfh
 *  updated DeleteSessionRequest
 *
 *  Revision 1.25  2011/01/24 22:56:17  mwkfh
 *  updated execute(RetrieveSessionRequest) to use CurrentDateProvider
 *
 *  Revision 1.24  2010/11/10 16:49:49  mwkfh
 *  clean up
 *
 *  Revision 1.23  2010/10/12 18:40:29  mwkfh
 *  refactored and clean-up
 *
 *  Revision 1.22  2010/10/12 17:20:04  mwkfh
 *  added delete for old records
 *
 *  Revision 1.21  2010/10/12 15:29:08  mwkfh
 *  updated execute(RetrieveSessionRequest) to only return a record if modified date is from today
 *
 *  Revision 1.20  2010/09/30 21:50:59  mwkfh
 *  added implements ISessionService
 *
 *  Revision 1.19  2010/09/30 21:25:04  mwkfh
 *  changed getInstance() to return the interface
 *
 *  Revision 1.18  2010/09/30 19:28:19  mwkfh
 *  updated session restore to update record instead of delete
 *
 *  Revision 1.17  2010/09/30 17:49:55  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 *  Revision 1.16  2010/09/29 20:27:19  mwsyk1
 *  Updated User Context
 *
 *  Revision 1.15  2010/09/29 16:55:55  mwgxd3
 *  changed getUserContext to return default db instance
 *
 *  Revision 1.14  2010/09/13 04:39:49  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.13  2010/09/02 18:17:54  mwkfh
 *  updated serializer call in storeSessionBo
 *
 *  Revision 1.12  2010/09/01 18:56:53  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.11  2010/08/31 17:56:21  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.10  2010/08/19 15:43:57  mwkfh
 *  enabled validation exception in storeSessionBo serialization check
 *
 *  Revision 1.9  2010/08/18 20:51:33  mwkfh
 *  moved serialization methods to Serializer class
 *
 *  Revision 1.8  2010/08/17 20:57:54  mwkfh
 *  updated storeSessionBo() to only save the session if serializable
 *
 *  Revision 1.7  2010/08/17 16:07:09  mwkfh
 *  updated storeSessionBo to always call getBlobFromObject after checking session object
 *
 *  Revision 1.6  2010/08/16 20:31:42  mwkfh
 *  added isRecursivelySerializable() call
 *
 *  Revision 1.5  2010/08/11 23:52:23  mwkfh
 *  fixed fixme in fetchSessionBo()
 *
 *  Revision 1.4  2010/08/11 15:59:24  mwpxp2
 *  Added missing accessors; removed noisy this.~es; cleaned imports; added fixmes
 *
 *  Revision 1.3  2010/08/11 00:43:59  mwkfh
 *  BlobFromObject and ObjectFromBlob have been moved to the PersistenceServiceRequestFactory
 *
 *  Revision 1.2  2010/08/03 16:58:37  mwkfh
 *  clean-up
 *
 *  Revision 1.1  2010/07/30 22:07:56  mwkfh
 *  refactored and merge session store and restore
 *
 *  Revision 1.2  2010/07/29 17:53:16  mwkfh
 *  added fetchSessionId()
 *
 *  Revision 1.1  2010/07/27 18:01:05  mwkfh
 *  updated and moved session services
 *
 *  Revision 1.3  2010/07/16 15:32:40  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.1.2.2  2010/07/13 20:39:20  mwkfh
 *  update location in comments
 *
 *  Revision 1.1.2.1  2010/07/12 21:26:57  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.5.4.2  2010/06/28 23:29:17  mwvkm
 *  A bug with session restore is fixed.
 *
 *  Revision 1.5.4.1  2010/05/20 22:59:26  mwvkm
 *  Aspects are removed/commented for Session restore POC
 *
 *  Revision 1.5  2010/05/04 00:56:53  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/04 00:17:58  mwvkm
 *  Cleaned up the code
 *
 *  Revision 1.3  2010/05/02 17:56:56  mwkkc
 *  Clean up
 *
 *  Revision 1.2  2010/05/02 17:50:39  mwkkc
 *  WS#3 - Trace work JCL
 *
 *  Revision 1.1  2010/04/29 23:52:04  mwvkm
 *  Initial check-in for session restore in session management
 *
 */
