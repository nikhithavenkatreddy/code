/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.util.Date;

/**
 * Description: I am response to no-response (fire and forget) requests.
 * File: FireAndForgetReceipt.java
 * Module:  gov.ca.dmv.ease.service.impl
 * Created: 26/04/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FireAndForgetReceipt extends AbstractEcsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5771783406764434095L;
	private String correlationId;
	/** The execution timestamp. */
	private long executionTimestamp;
	/** The sent request id. */
	private String sentRequestId;

	/**
	 * Instantiates a new null response.
	 */
	protected FireAndForgetReceipt() {
		super();
		setExecutionTimestamp(0);
	}

	/**
	 * Instantiates a new fire and forget receipt.
	 * 
	 * @param fireAndForgetRequest the fire and forget request
	 */
	public FireAndForgetReceipt(FireAndForgetEcsRequest fireAndForgetRequest) {
		super();
		setSentRequestId(fireAndForgetRequest.getRequestId());
		setExecutionTimestamp((new Date()).getTime());
	}

	/**
	 * Instantiates a new fire and forget receipt.
	 * 
	 * @param fireAndForgetRequest the fire and forget request
	 */
	public FireAndForgetReceipt(FireAndForgetEcsRequest fireAndForgetRequest,
			String aCorrelationId) {
		super();
		setSentRequestId(fireAndForgetRequest.getRequestId());
		setExecutionTimestamp((new Date()).getTime());
		setCorrelationId(aCorrelationId);
	}

	/**
	 * Instantiates a new FireAndForgetReceipt with error collector.
	 * 
	 */
	public FireAndForgetReceipt(IErrorCollector errorCollector) {
		setErrorCollector(errorCollector);
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * Gets the execution timestamp.
	 * 
	 * @return the execution timestamp
	 */
	public long getExecutionTimestamp() {
		return executionTimestamp;
	}

	/**
	 * Gets the sent request id.
	 * 
	 * @return the sent request id
	 */
	public String getSentRequestId() {
		return sentRequestId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#isFireAndForgetResponse()
	 */
	@Override
	public final boolean isFireAndForgetResponse() {
		return true;
	}

	/**
	 * @param correlationId the correlationId to set
	 */
	protected void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * Sets the execution timestamp.
	 * 
	 * @param executionTimestamp the new execution timestamp
	 */
	protected void setExecutionTimestamp(long executionTimestamp) {
		this.executionTimestamp = executionTimestamp;
	}

	/**
	 * Sets the sent request id.
	 * 
	 * @param anId the an id
	 */
	protected void setSentRequestId(String anId) {
		sentRequestId = anId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("sentRequestId", sentRequestId, anIndent, aBuilder);
		outputKeyValue("executionTimestamp", executionTimestamp, anIndent,
				aBuilder);
		outputKeyValue("correlationId", correlationId, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 * Modification History:
 *
 * $Log: FireAndForgetReceipt.java,v $
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.4  2010/12/12 05:51:43  mwpxp2
 * Added correlationId field; added toStringOn/2
 *
 * Revision 1.3  2010/04/22 19:23:57  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2010/04/09 17:06:30  mwhxb3
 * Added a new constructor with error collector.
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.8  2009/10/14 18:18:09  mwhxb3
 * updated comments
 *
 * Revision 1.7  2009/10/06 21:54:07  mwhxb3
 * refactoring from dcs to ecs
 *
 * Revision 1.6.8.2  2009/10/06 20:54:07  mwhxb3
 * refactoring from dcs to ecs
 *
 * Revision 1.6.8.1  2009/10/06 20:28:49  mwhxb3
 * refactoring from dcs to ecs
 *
 * Revision 1.6  2009/07/27 18:49:39  mwpxp2
 * Adjusted imports for renames
 *
 * Revision 1.5  2009/07/27 18:30:38  mwpxp2
 * Adjusted imports and super  for renames
 *
 * Revision 1.4  2009/07/27 18:02:17  mwpxp2
 * Bulk cleanup; javadoc
 *
 * Revision 1.3  2009/07/16 02:30:11  mwpxp2
 * Bulk cleanup, incl javadoc and file decorations
 *
 * Revision 1.2  2009/07/16 02:28:42  mwpxp2
 * Bulk cleanup, incl javadoc and file decorations
 *
 * Revision 1.1  2009/07/14 23:58:48  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.1  2009-07-10 07:10:25  mwpxp2
 * Synch
 *
 * Revision 1.2  2009-05-17 05:28:56  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.1  2009-04-26 07:32:41  mwpxp2
 * Initial
 *
 */
