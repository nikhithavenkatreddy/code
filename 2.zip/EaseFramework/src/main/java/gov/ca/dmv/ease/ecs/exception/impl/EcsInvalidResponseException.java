/**
 * 
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am exception to identify invalid responses in ECS
 * File: EcsInvalidResponseException.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: May 25, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsInvalidResponseException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2454986782632537323L;

	/**
	 * Instantiates a new ecs invalid response exception.
	 */
	public EcsInvalidResponseException() {
		super();
	}

	/**
	 * Instantiates a new ecs invalid response exception.
	 * 
	 * @param arg0 the arg0
	 */
	public EcsInvalidResponseException(String arg0) {
		super(arg0);
	}

	/**
	 * Instantiates a new ecs invalid response exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EcsInvalidResponseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new ecs invalid response exception.
	 * 
	 * @param cause the cause
	 */
	public EcsInvalidResponseException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsInvalidResponseException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/26 00:46:41  mwpxp2
 *  Initial
 *
 */
