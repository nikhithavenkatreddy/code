/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.request.impl;

import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am the request used to delete the stored session.
 * File: DeleteSessionRequest.java
 * Module:  gov.ca.dmv.ease.app.session.request.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DeleteSessionRequest extends SessionServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3989352628643910551L;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public DeleteSessionRequest(IUserContext userContext) {
		super(userContext, new Session(userContext));
	}

	/**
	 * The Constructor.
	 *
	 * @param userContext the user context
	 * @param session the session
	 */
	public DeleteSessionRequest(IUserContext userContext, Session session) {
		super(userContext, session);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public ISessionServiceResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DeleteSessionRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2012/08/25 01:30:31  mwpxp2
 *  Refactored to use super getSrevice/0
 *
 *  Revision 1.4  2012/05/08 00:24:58  mwhys
 *  Removed unwanted constructor for Session Management.
 *
 *  Revision 1.3  2012/01/10 18:11:18  mwkfh
 *  updated DeleteSessionRequest userContext
 *
 *  Revision 1.2  2012/01/06 19:38:28  mwkfh
 *  added constructor
 *
 *  Revision 1.1  2010/09/30 17:49:53  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
