/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.listen.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.constants.IEcsConstants;
import gov.ca.dmv.ease.ecs.exception.impl.EcsJmsException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageMismatchException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.persist.impl.Payload;
import gov.ca.dmv.ease.ecs.persist.impl.Promise;
import gov.ca.dmv.ease.ecs.util.impl.Hex2ByteTransformer;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: A spring MDP listener listening asynchronous response messages on receiving queue.
 * //FIXME - the service should be stateless
 
 * File: SimpleJmsMessageListener.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Aug 3, 2009 
 * @author MWHXB3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SimpleJmsMessageListener implements MessageListener {
	/** correlaton id in hexadecimal starts with [ID:] so ignoring first 3 characters. */
	private static final int BEGIN = 3;
	/** Encoding type. */
	private static final String ENCODING = "8859_1";
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(SimpleJmsMessageListener.class);
	/** The RESPONSE_HEADER_LEN. */
	protected static final int RESPONSE_HEADER_LEN = 150;
	/** The SEQ_FLAG_HEADER_POS. */
	protected static final int SEQ_FLAG_HEADER_POS = 149;
	/** The persistence service request factory. */
	private transient PersistenceServiceRequestFactory persistenceServiceRequestFactory;

	/**
	 * Instantiates a new SimpleJmsMessageListener service.
	 */
	public SimpleJmsMessageListener() {
		super();
	}

	/**
	 * Instantiates a new SimpleJmsMessageListener service.
	 * 
	 * @param persistenceServiceRequestFactory the persistence service request factory
	 */
	public SimpleJmsMessageListener(
			PersistenceServiceRequestFactory persistenceServiceRequestFactory) {
		super();
		this.persistenceServiceRequestFactory = persistenceServiceRequestFactory;
	}

	/**
	 * Bytes message to string.
	 * 
	 * @param retValue the ret value
	 * @param recvBytes the recv bytes
	 * 
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 * @throws JMSException the JMS exception
	 */
	public void bytesMessageToString(StringBuilder retValue,
			BytesMessage recvBytes) throws UnsupportedEncodingException,
			JMSException {
		long foo;
		String tranMsg = null;
		foo = recvBytes.getBodyLength();
		Long foo2 = new Long(foo);
		byte[] byteMsg = new byte[foo2.intValue()];
		recvBytes.readBytes(byteMsg);
		tranMsg = new String(new String(byteMsg, "Cp1047")
				.getBytes(getEncoding()));
		retValue.append(tranMsg);
	}

	/**
	 * Returns the encoding type.
	 * 
	 * @return the encoding type.
	 */
	public String getEncoding() {
		return ENCODING;
	}

	/**
	 * Gets the persistence service.
	 * 
	 * @return the persistence service
	 */
	public PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return persistenceServiceRequestFactory;
	}

	/* (non-Javadoc)
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	public void onMessage(Message message) {
		synchronized (this) {
			BytesMessage receivedBytesMessage;
			StringBuilder aBuilder = new StringBuilder();
			String camvresponse = null;
			String corrId = null;
			String hexCorrId = null;
			int seqNum = 0;
			String segmentIndicator = null;
			LOGGER.info(" onMessage of simpleJmsMessageListener ");
			if (message instanceof javax.jms.BytesMessage) {
				receivedBytesMessage = (javax.jms.BytesMessage) message;
				try {
					hexCorrId = message.getJMSCorrelationID();
					corrId = Hex2ByteTransformer.transform(hexCorrId
							.substring(BEGIN));
					seqNum = message.getIntProperty("JMSXGroupSeq");
					bytesMessageToString(aBuilder, receivedBytesMessage);
					segmentIndicator = aBuilder.substring(SEQ_FLAG_HEADER_POS,
							RESPONSE_HEADER_LEN);
					LOGGER.info(" hexCorrId " + hexCorrId + " corrId " + corrId
							+ " seqNum " + seqNum + " segmentIndicator "
							+ segmentIndicator + " aBuilder "
							+ aBuilder.toString());
				}
				catch (UnsupportedEncodingException e) {
					//e.printStackTrace();
					throw new EcsJmsException(e);
				}
				catch (JMSException e) {
					//					e.printStackTrace();
					throw new EcsJmsException(e);
				}
				camvresponse = aBuilder.toString();
				int dot = camvresponse.lastIndexOf(".");
				String response = camvresponse.substring(dot + 1);
				LOGGER.info(" response before calling persistence " + response);
				IUserContext userContext = UserContext
						.getDefaultInstanceForJms();
				Promise promise = new Promise(corrId);
				//promise.setCorrelationId(corrId);
				LOGGER.info(" calling persistence for promise ");
				promise = (Promise) retrievePromise(userContext, promise);
				Payload payload = new Payload();
				payload.setCorrelationId(corrId);
				payload.setPayload(response);
				payload.setSeqNum(seqNum);
				payload.setSegmentIndicator(segmentIndicator);
				if (!EaseUtil.isNullOrBlank(promise)) {
					LOGGER
							.info("Received promise from SendCdlisAndPdpsRequest. AbsoluteTimeStamp : "
									+ promise.getAbsoluteTimestamp());
					payload
							.setAbsoluteTimestamp(promise
									.getAbsoluteTimestamp());
				}
				else {
					long absoluteTimeStamp = (new Date()).getTime()
							+ IEcsConstants.CASH_PROMISE_EXPIRATION_MSEC;
					LOGGER
							.info("Received promise from SendCdlisAndPdpsRequest is NULL. Using AbsoluteTimeStamp : "
									+ absoluteTimeStamp);
					payload.setAbsoluteTimestamp(absoluteTimeStamp);
				}
				IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
						.createSaveOrUpdateBusinessObjectRequest(userContext,
								payload);
				PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
						.execute();
				if (aPeristenceResponse.hasErrors()) {
					LOGGER
							.info("Persistence returned errors while storing payloads in database "
									+ aPeristenceResponse.getErrorCollector()
											.toString());
					throw new EcsServiceException(aPeristenceResponse
							.getErrorCollector().toString());
				}
			}
			else {
				throw new EcsMessageMismatchException(
						"The message is not of any JMS Message type under consideration.");
			}
		}
	}

	/**
	 * Retrieves business objects for a given cash promise from persistence.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 * 
	 * @return business objects
	 */
	private IBusinessObject retrievePromise(IUserContext userContext,
			IBusinessObject businessObject) {
		IPersistenceServiceRequest retrieveBusinessObjectRequest = getPersistenceServiceRequestFactory()
				.createRetrieveBusinessObjectRequest(userContext,
						businessObject);
		RetrieveBusinessObjectResponse retrieveBusinessObjectResponse = (RetrieveBusinessObjectResponse) retrieveBusinessObjectRequest
				.execute();
		if (!retrieveBusinessObjectResponse.hasErrors()
				&& retrieveBusinessObjectResponse.getResults().size() > 0) {
			LOGGER.info(" Persistence has returned promise ");
			return retrieveBusinessObjectResponse.getResults().get(0);
		}
		else {
			//FIXME - implicit exception hiding
			return null;
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SimpleJmsMessageListener.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/08/14 20:32:17  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.15  2011/06/09 17:52:15  mwyxg1
 *  clean up
 *
 *  Revision 1.14  2011/03/22 18:59:46  mwhys
 *  Fixed AbsoluteTimeStamp in onMessage().
 *
 *  Revision 1.13  2010/12/12 17:53:03  mwpxp2
 *  Replaced creation of Promise with multiple public setters with a single constructor
 *
 *  Revision 1.12  2010/12/02 00:14:58  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.11  2010/11/09 03:32:26  mwpxp2
 *  Added throwing EcsJmsException in onMessage/1 rather than logging exception only
 *
 *  Revision 1.10  2010/09/28 16:32:01  mwpxr4
 *  Corrected exception class.
 *
 *  Revision 1.9  2010/09/24 17:47:24  mwpxr4
 *  Application exception thrown if persistence fails in listener.
 *
 *  Revision 1.8  2010/09/22 20:31:34  mwpxr4
 *  Organized imports.
 *
 *  Revision 1.7  2010/09/21 18:49:25  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.6.4.4  2010/09/17 17:21:07  mwpxr4
 *  Added segment indicator by which we can if all the responses have been received for a given request.
 *
 *  Revision 1.6.4.3  2010/09/16 20:41:36  mwpxr4
 *  Updated code to use default user context for JMS.
 *
 *  Revision 1.6.4.2  2010/09/16 20:26:17  mwpxr4
 *  Updated logic to populate payloads table with expiration time from the corresponding record in promises table.
 *
 *  Revision 1.6.4.1  2010/09/14 16:12:07  mwpxr4
 *  Removed Simple Persistence dependency for Asynchronous type of ECS communication.
 *
 *  Revision 1.6  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/09/03 22:44:57  mwpxr4
 *  Added loggers.
 *
 *  Revision 1.4  2010/08/31 17:57:10  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.3  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/07/08 02:06:15  mwpxp2
 *  Added fixme
 *
 *  Revision 1.1  2010/05/26 01:22:08  mwpxp2
 *  Moved in from improper package
 *
 *  Revision 1.4  2010/05/25 22:10:13  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.3  2010/05/25 21:57:25  mwpxp2
 *  Fixed instance var naming and unnecessary "t~his-es"
 *
 *  Revision 1.2  2010/03/22 23:20:44  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.23  2009/11/03 19:43:44  mwhxb3
 *  thrown EcsMessageMismatchException
 *
 *  Revision 1.22  2009/11/02 21:36:22  mwhxb3
 *   updated onMessage method
 *
 *  Revision 1.21  2009/11/02 19:24:30  mwhxb3
 *  updated onMessage method
 *
 *  Revision 1.20  2009/11/02 17:55:55  mwhxb3
 *  Updated the onMessage method
 *
 *  Revision 1.19  2009/10/13 18:08:52  mwhxb3
 *  imports clean up
 *
 *  Revision 1.18  2009/10/08 00:02:52  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.17  2009/10/07 23:47:55  mwpzs3
 *  removing unneeded method
 *
 *  Revision 1.16  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.15  2009/10/06 21:50:56  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.14.8.1  2009/10/06 20:28:42  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.14  2009/08/27 05:54:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2009/08/18 23:48:21  mwpxp2
 *  Added more logging; bulk cleanup
 *
 *  Revision 1.12  2009/08/18 02:11:36  mwpzs3
 *  change for asynchronous
 *
 *  Revision 1.10  2009/08/14 02:22:31  mwpzs3
 *  Change to handle multiple payload
 *
 *  Revision 1.9  2009/08/13 03:06:22  mwpzs3
 *  Asynchronous Message handling
 *
 *  Revision 1.8  2009/08/10 22:39:28  mwpxp2
 *  Added logging, missing javadoc; removed explicit log4j initialization
 *
 *  Revision 1.7  2009/08/06 01:44:48  mwpzs3
 *  Cahnges for Asnychronous Response retrieval
 *
 *  Revision 1.6  2009/08/05 21:52:59  mwhxb3
 *  No need for removing extra zeros from response correlation id. The correlation Id is of size 24.
 *
 *  Revision 1.5  2009/08/05 19:56:02  mwhxb3
 *  converted hexa Correlation Id to string
 *
 *  Revision 1.4  2009/08/05 01:49:17  mwhxb3
 *  added logger to display correlation id that is in hex-form.
 *
 *  Revision 1.3  2009/08/05 01:08:40  mwpxp2
 *  REplaced system outs with logging; added todos
 *
 *  Revision 1.2  2009/08/04 22:00:05  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/03 18:46:56  mwhxb3
 *  A MDP listener listening asynchronous response messages on receiving queue.
 *
 */
