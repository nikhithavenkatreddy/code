/**
 * 
 */
package gov.ca.dmv.ease.listeners.bridge.handler.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseLayerException;

/**
 * Description: I am abstract exception grouping exception categories by layer
 *  //FIXME - this should be integrated into the EASE exception hierarchy
 *  //FIXME - this exception should be unchecked
 *  
 * File: EaseLayerException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseBridgeMessageException extends EaseLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3694519086757304309L;

	/**
	 * Instantiates a new ease layer exception.
	 */
	public EaseBridgeMessageException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseBridgeMessageException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseBridgeMessageException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseBridgeMessageException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseBridgeMessageException.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/10/06 02:11:09  mwpxp2
 *  Addressed fixmes - for inheritance
 *
 *  Revision 1.3  2010/09/16 17:49:17  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.2  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/05/07 02:20:16  mwakg
 *  Moved EaseBridgeMessageException from Bridge to Architecture
 *
 *  Revision 1.1  2010/05/02 00:16:19  mwakg
 *  Merged code from BridgeService
 *
 *  Revision 1.1  2010/04/19 19:32:09  mwgrk
 *  Requires EJB 2.1 support.
 *
 *  Revision 1.1  2010/04/12 19:25:57  mwgrk
 *  EASEBridgeService is a new J2EE Project.
 *
 *  Revision 1.1.2.1  2010/03/31 02:03:24  mwgrk
 *  Initial Version.
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
