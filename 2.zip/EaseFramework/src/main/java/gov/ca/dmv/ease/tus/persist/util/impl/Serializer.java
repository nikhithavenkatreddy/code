/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.util.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;

/**
 * Description: This class is used to check and serialize objects.
 * File: Serializer.java
 * Module:  gov.ca.dmv.ease.tus.persist.util.impl
 * Created: Aug 18, 2010
 * @author MWKFH
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Serializer {
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory.getLog(Serializer.class);
	/** The SINGLETON. */
	private static Serializer SINGLETON;
	/** The max recursively serializable depth. 
	 * -1 negates function, 0 only root class, 1 or more traverses tree. */
	private int maxTreeDepth = 1;
	/** The max recursively serializable line count. */
	private int treeLineCount;
	/** The expand on serializable. */
	private boolean expandOnSerializable = false;
	/** The max blob size. */
	private int maxBlobSize = 102400;

	/**
	 * Gets the instance of Serializer.
	 * 
	 * @return instance of Serializer
	 */
	public static Serializer getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	private static void initSingleton() {
		SINGLETON = new Serializer();
	}

	/**
	 * Gets all the fields of a class including parent classes.
	 *
	 * @param type the type
	 * @return List of fields
	 */
	private List <Field> getAllFields(Class <?> type) {
		List <Field> fields = new ArrayList <Field>();
		for (Field field : type.getDeclaredFields()) {
			fields.add(field);
		}
		if (type.getSuperclass() != null) {
			fields.addAll(getAllFields(type.getSuperclass()));
		}
		return fields;
	}

	/**
	 * The purpose of this method is to get the blob from the business object.
	 *
	 * @param object the object
	 * @return the blob from object
	 */
	public Blob getBlobFromObject(Object object) {
		Blob blob = null;
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(
					byteArrayOutputStream);
			objectOutputStream.writeObject(object);
			byte[] bytes = byteArrayOutputStream.toByteArray();
			blob = Hibernate.createBlob(bytes);
			//writeBlobToFile(blob);
			return blob;
		}
		catch (IOException e) {
			throw new EaseException(e);
		}
	}

	/**
	 * Gets the max recursively serializable tree depth.
	 * 
	 * @return the maxTreeDepth
	 */
	private int getMaxTreeDepth() {
		return maxTreeDepth;
	}

	/**
	 * Gets the expand tree on serializable.
	 * 
	 * @return the expandOnSerializable
	 */
	private boolean getExpandOnSerializable() {
		return expandOnSerializable;
	}

	/**
	 * Gets the max blob size.
	 * 
	 * @return the maxBlobSize
	 */
	private int getMaxBlobSize() {
		return maxBlobSize;
	}

	/**
	 * The purpose of this method is to read the object from blob.
	 * 
	 * @param blob the blob
	 * @return the object
	 */
	public Object getObjectFromBlob(Blob blob) {
		Object obj = null;
		InputStream is = null;
		ObjectInputStream oip = null;
		try {
			if (EaseUtil.isNotNull(blob)) {
				is = blob.getBinaryStream();
				oip = new ObjectInputStream(is);
				obj = oip.readObject();
			}
			return obj;
		}
		catch (SQLException e) {
			throw new EaseException(e);
		}
		catch (IOException e) {
			throw new EaseException(e);
		}
		catch (ClassNotFoundException e) {
			throw new EaseException(e);
		}
	}

	/**
	 * The purpose of this method is to the byte size of the business object.
	 * -1 is returned if not serializable;
	 *
	 * @param object the object
	 * @return int Object byte size
	 */
	private int getSerializableSize(Object object) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(
					byteArrayOutputStream);
			objectOutputStream.writeObject(object);
			return byteArrayOutputStream.size();
		}
		catch (IOException e) {
			return -1;
		}
	}

	/**
	 * The purpose of this method is to determine if the business object is serializable.
	 * A recursive tree is printed in the log during processing.
	 *
	 * @param depth the depth
	 * @param currentObject the current object
	 * @param fieldName the field name
	 * @param visited the visited
	 * @param maxDepth the max depth
	 * @return int object serializable size
	 */
	private int getSerializableSize(int depth, Object currentObject,
			String fieldName, List <Class <?>> visited, int maxDepth) {
		int objectSize = 0;
		if (EaseUtil.isNotNull(currentObject)) {
			int propertiesSize = 0;
			objectSize = getSerializableSize(currentObject);
			//isSerializable = isSerializable(currentObject);
			String currentClassName = currentObject.getClass().toString();
			if (currentClassName.endsWith(".Class")) {
				currentClassName = currentObject.toString();
			}
			LOGGER.info(StringUtils.leftPad(" " + ++treeLineCount, 5) + "|"
					+ StringUtils.rightPad(" ", depth * 4) + depth + " "
					+ (objectSize >= 0 ? "- " : "+ ") + currentClassName + " "
					+ fieldName + " (" + (objectSize >= 0 ? "" : "Not ")
					+ "Serializable)"
					+ (objectSize >= 0 ? " (" + objectSize + " bytes)" : ""));
			if (objectSize < 0 || getExpandOnSerializable()) {
				int propertySize = 0;
				if (!EaseUtil.isNotNull(visited)) {
					visited = new ArrayList <Class <?>>();
				}
				if (currentObject.getClass().isArray()) {
					//traverse array
					for (Object objItem : (Object[]) currentObject) {
						if (objItem != null) {
							propertySize = getSerializableSize(depth + 1,
									objItem,
									objItem.getClass().getSimpleName(),
									visited, maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
					}
				}
				else if (currentObject instanceof List) {
					//traverse List
					for (Iterator <Object> objIterator = ((List <Object>) currentObject)
							.iterator(); objIterator.hasNext();) {
						Object listObject = objIterator.next();
						if (listObject != null) {
							propertySize = getSerializableSize(depth + 1,
									listObject, listObject.getClass()
											.getSimpleName(), visited, maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
					}
				}
				else if (currentObject instanceof Map) {
					//traverse Map
					Map <Object, Object> map = (Map <Object, Object>) currentObject;
					Iterator <Map.Entry <Object, Object>> mapIterator = map
							.entrySet().iterator();
					while (mapIterator.hasNext()) {
						Map.Entry <Object, Object> pairs = mapIterator.next();
						if (pairs.getKey() != null) {
							propertySize = getSerializableSize(depth + 1, pairs
									.getKey(), pairs.getKey().getClass()
									.getSimpleName(), visited, maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
						if (pairs.getValue() != null) {
							propertySize = getSerializableSize(depth + 1, pairs
									.getValue(), pairs.getValue().getClass()
									.getSimpleName(), visited, maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
					}
				}
				else if ((depth < maxDepth)
						&& (!visited.contains(currentObject.getClass()))
						&& (currentObject.getClass().getName()
								.startsWith("gov.ca"))
						&& (!currentObject.getClass().getName().contains("$"))) {
					//process current object properties
					List <Field> fieldList = getAllFields(currentObject
							.getClass());
					for (Field field : fieldList) {
						field.setAccessible(true);
						Object fieldObject = null;
						try {
							fieldObject = field.get(currentObject);
						}
						catch (IllegalArgumentException e) {
							LOGGER.warn(e.toString());
						}
						catch (IllegalAccessException e) {
							LOGGER.warn(e.toString());
						}
						if (Modifier.isTransient(field.getModifiers())
								|| Modifier.isStatic(field.getModifiers())) {
							String modifier = "";
							if (Modifier.isTransient(field.getModifiers())) {
								modifier += "Transient";
							}
							else if (Modifier.isStatic(field.getModifiers())) {
								modifier += "Static";
							}
							Class <?> fieldClass = field.getType();
							if (EaseUtil.isNotNull(fieldObject)) {
								fieldClass = fieldObject.getClass();
							}
							LOGGER.info(StringUtils.leftPad(" "
									+ ++treeLineCount, 5)
									+ "|"
									+ StringUtils
											.rightPad(" ", (depth + 1) * 4)
									+ (depth + 1)
									+ " "
									+ "- "
									+ fieldClass
									+ " "
									+ field.getName()
									+ " ("
									+ modifier
									+ ")");
						}
						else if (!EaseUtil.isNotNull(fieldObject)) {
							propertySize = getSerializableSize(depth + 1, field
									.getType(), field.getName(), visited,
									maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
						else {
							if (!visited.contains(currentObject.getClass())
									&& !currentObject.getClass().toString()
											.endsWith("Map")
									&& !currentObject.getClass().toString()
											.endsWith("List")) {
								visited.add(currentObject.getClass());
							}
							propertySize = getSerializableSize(depth + 1,
									fieldObject, field.getName(), visited,
									maxDepth);
							if (propertySize > -1) {
								propertiesSize += propertySize;
							}
						}
					}
				}
			}
			if (propertiesSize == 0) {
				propertiesSize = objectSize;
			}
			if (depth == 0) {
				LOGGER
						.info("Total estimate of object's serializable properties = "
								+ propertiesSize);
			}
			else if (objectSize < 0) {
				objectSize = propertiesSize;
			}
		}
		return objectSize;
	}

	/**
	 * The purpose of this method is to determine if the business object is serializable.
	 * A recursive tree is printed in the log during processing.
	 *
	 * @param object the object
	 * @param printTree the print tree
	 * @return int size of serializable object
	 */
	public int getSerializableSize(Object object, boolean printTree) {
		if (getMaxTreeDepth() < 0) {
			return 0;
		}
		else if ((object != null) && printTree) {
			LOGGER.info("Max tree depth = " + maxTreeDepth);
			treeLineCount = 0;
			return getSerializableSize(0, object, object.getClass()
					.getSimpleName(), null, getMaxTreeDepth());
		}
		else {
			return getSerializableSize(object);
		}
	}

	/**
	 * The purpose of this method is to determine if the business object is serializable.
	 * A recursive tree is printed in the log during processing.
	 *
	 * @param object the object
	 * @param printTree the print tree
	 * @return true if serializable
	 */
	public boolean isSerializable(Object object, boolean printTree) {
		return (getSerializableSize(object, printTree) >= 0);
	}

	/*
	 * The purpose of this method is to determine if the business object is serializable.
	 * 
	 * @param Object object
	 * 
	 * @return true if serializable
	 *
	private boolean isSerializable(Object object) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(
					byteArrayOutputStream);
			objectOutputStream.writeObject(object);
			return true;
		}
		catch (IOException e) {
			//LOGGER.info("is not serializable == " + e.toString());
			return false;
		}
	}
	*/
	/**
	 * The purpose of this method is to determine if the business object is serializable.
	 * A recursive tree is printed in the log during processing.
	 *
	 * @param object the object
	 * @param printTree the print tree
	 * @return true if serializable and not bigger than max blob size
	 */
	public boolean isValidBlob(Object object, boolean printTree) {
		int objSize = getSerializableSize(object, printTree);
		return ((objSize > -1) && (objSize <= getMaxBlobSize()));
	}

	/**
	 * Sets the max recursively serializable tree depth.
	 *
	 * @param maxDepth the new max tree depth
	 */
	public void setMaxTreeDepth(int maxDepth) {
		this.maxTreeDepth = maxDepth;
	}

	/**
	 * Sets the max recursively serializable depth.
	 *
	 * @param expand the new expand on serializable
	 */
	public void setExpandOnSerializable(boolean expand) {
		this.expandOnSerializable = expand;
	}

	/**
	 * Sets the max max blob size in bytes.
	 *
	 * @param maxBlobSize the new max blob size
	 */
	public void setMaxBlobSize(int maxBlobSize) {
		this.maxBlobSize = maxBlobSize;
	}
	/*
	 * The purpose of this method is to write a blob to a file.
	 * 
	 * @param blob the blob
	 *
	private void writeBlobToFile(Blob blob) {
		final int minBlobSize = 50;
		final int maxNumberOfFiles = 100;
		if (blob != null) {
			try {
				int blobLength = (int) blob.length();
				if (blobLength > minBlobSize) {
					String fileName = "C://EaseBlobs/EaseDlBlob";
					int count = 0;
					String fileExt = ".txt";
					File outputFile;
					do {
						outputFile = new File(fileName + ++count + fileExt);
					}
					while (outputFile.exists() && count < maxNumberOfFiles);
					outputFile.createNewFile();
					InputStream inputStream = blob.getBinaryStream();
					FileOutputStream outputStream = new FileOutputStream(
							outputFile);
					int read = 0;
					byte[] bytes = new byte[1024];
					while ((read = inputStream.read(bytes)) != -1) {
						outputStream.write(bytes, 0, read);
					}
					inputStream.close();
					outputStream.flush();
					outputStream.close();
					LOGGER.info("Blob has been written to file '" + fileName
							+ ++count + fileExt + "'.  size = " + blobLength);
				}
			}
			catch (IOException e) {
				LOGGER.info(e);
				//throw new EaseException(e);
			}
			catch (SQLException e) {
				LOGGER.info(e);
				//throw new EaseException(e);
			}
		}
	}
	*/
	/*
	 * The purpose of this method is to convert an object to XML.
	 * 
	 * @param Object object
	 * 
	 * @return true if serializable
	 *
	public String getXmlFromObject(Object object) {
		XStream xstream = new XStream();
		return xstream.toXML(object);
	}

	/*
	 * The purpose of this method is to convert XML to an object.
	 * 
	 * @param String xml
	 * 
	 * @return true if serializable
	 *
	public Object getObjectFromXml(String xml) {
		XStream xstream = new XStream();
		return xstream.fromXML(xml);
	}

	/*
	 * The purpose of this method is to convert an object to XML and write it to a file.
	 * 
	 * @param Object object
	 * @param Writer file/stream to write to
	 *
	public void writeXmlToFile(Object object, Writer outWriter)
			throws EaseConversionException {
		try {
			XStream xstream = new XStream();
			ObjectOutputStream out = xstream
					.createObjectOutputStream(outWriter);
			out.writeObject(object);
			out.close();
		}
		catch (IOException e) {
			LOGGER.info(e.toString());
			throw new EaseConversionException(e.toString());
		}
	}
	*/
}
/**
 * Modification History:
 * 
 * $Log: Serializer.java,v $
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.24  2012/09/20 22:07:33  mwkfh
 * added writeBlobToFile
 *
 * Revision 1.23  2012/05/08 16:14:41  mwhys
 * Fixed todo (de-springified).
 *
 * Revision 1.22  2011/10/12 20:58:11  mwkkc
 * Performance Merge
 *
 * Revision 1.21.8.2  2011/09/28 02:48:23  mwpxp2
 * Added de-springification todos
 *
 * Revision 1.21.8.1  2011/09/28 01:55:05  mwpxp2
 * Logger name fixed
 *
 * Revision 1.21  2011/05/10 18:15:04  mwkfh
 * set defaults
 *
 * Revision 1.20  2010/12/02 00:14:58  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.19  2010/10/08 21:03:51  mwkfh
 * added null check in getSerializableSize()
 *
 * Revision 1.18  2010/09/30 17:49:02  mwkfh
 * added getInstance()
 *
 * Revision 1.17  2010/09/08 16:40:35  mwkfh
 * comment out the never used method isSerializable(Object object)
 *
 * Revision 1.16  2010/09/02 22:03:57  mwkfh
 * changed properties size to estimate
 *
 * Revision 1.15  2010/09/02 21:06:03  mwkfh
 * enabled expandOnSerializable functionality
 *
 * Revision 1.14  2010/09/02 19:26:56  mwkfh
 * added sum of properties  to print at the bottom of tree to estimate size when non-serializable
 *
 * Revision 1.13  2010/09/02 18:18:21  mwkfh
 * update methods and added new properties
 *
 * Revision 1.12  2010/09/01 19:07:00  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.11  2010/09/01 16:21:54  mwkfh
 * added byte count for serializable objects
 *
 * Revision 1.10  2010/08/31 17:07:28  mwkfh
 * fixed exception when Map value is null
 *
 * Revision 1.9  2010/08/30 20:06:54  mwkfh
 * added line numbers and depth number to isRecursivelySerializable tree
 *
 * Revision 1.8  2010/08/26 22:00:20  mwkfh
 * cleanup + commented out Xstream mothods
 *
 * Revision 1.7  2010/08/23 16:03:05  mwkfh
 * added use of EaseUtil.isNotNull
 *
 * Revision 1.6  2010/08/20 22:01:41  mwkfh
 * added "+" in front of non-serializable lines and removed TransitionsMap from visited to show more details
 *
 * Revision 1.5  2010/08/20 19:17:01  mwkfh
 * removed expansion of Spring proxy objects
 *
 * Revision 1.4  2010/08/18 23:43:51  mwkfh
 * cleaned up imports
 *
 * Revision 1.3  2010/08/18 22:39:29  mwkfh
 * removed expansion of serializable Lists, Maps, and Arrays
 *
 * Revision 1.2  2010/08/18 22:24:52  mwkfh
 * does not traverse serializable
 *
 * Revision 1.1  2010/08/18 20:50:48  mwkfh
 * new serializer class
 *
 */
