package gov.ca.dmv.ease.fw.event.impl;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I represent a change to a property in an object
 * File: ValueChangeEvent.java
 * Module:  gov.ca.dmv.ease.fw.event
 * Created: Aug 4, 2009 
 * @author mwdks7  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ValueChangeEvent {
	/**
	* Logger for this class
	*/
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(ValueChangeEvent.class);
	/** The old value. */
	private Object oldValue;
	/** The property name. */
	private String propertyName;
	/** The subject. */
	private Object subject;

	/**
	 * Gets the old value.
	 * 
	 * @return the old value
	 */
	public Object getOldValue() {
		return oldValue;
	}

	/**
	 * Gets the property name.
	 * 
	 * @return the property name
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * Gets the subject.
	 * 
	 * @return the subject
	 */
	public Object getSubject() {
		return subject;
	}

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	 
	public String getValue() {
		Class<?> c = subject.getClass();
		Method m;
		Object value;
		String aMethodName = "get" + propertyName;
		try {
			m = c.getMethod(aMethodName, new Class[0]);
			value = m.invoke(subject, new Object[0]);
			return value.toString();
		}
		catch (Exception e) {
			LOGGER.debug("getValue() - Exception: " + e.getMessage() + " in "
					+ this);
			return null;
		}
	}

	/**
	 * Checks if is valid.
	 * 
	 * @return true, if is valid
	 */
	public boolean hasValueChanged() {
		if (!isValid()) {
			return false;
		}
		Object value = getValue();
		if (oldValue == value) {
			return false;
		}
		if (oldValue.equals(value)) {
			return false;
		}
		return true;
	}

	/**
	 * Checks if is valid.
	 * 
	 * @return true, if is valid
	 */
	public boolean isValid() {
		if (propertyName == null) {
			return false;
		}
		if (subject == null) {
			return false;
		}
		return true;
	}

	/**
	 * Obtain method.
	 * 
	 * @param name the name
	 * 
	 * @return the method
	 */
	private Method obtainMethod(String name) {
		Method[] methods = subject.getClass().getMethods();
		for (Method method : methods) {
			if (method.getName().equals(name)) {
				return method;
			}
		}
		return null;
	}

	/**
	 * Sets the old value.
	 * 
	 * @param oldValue the new old value
	 */
	public void setOldValue(Object oldValue) {
		this.oldValue = oldValue;
	}

	/**
	 * Sets the property name.
	 * 
	 * @param propertyName the new property name
	 */
	public void setPropertyName(String propertyName) {
		if (propertyName != null) {
			String s1 = (propertyName.substring(0, 1)).toUpperCase();
			String s2 = propertyName.substring(1, propertyName.length());
			this.propertyName = s1 + s2;
		}
	}

	/**
	 * Sets the subject.
	 * 
	 * @param subject the new subject
	 */
	public void setSubject(Object subject) {
		this.subject = subject;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return subject.getClass().getSimpleName() + " changed " + propertyName
				+ " from " + oldValue; // + " to " + getValue();
	}

	/**
	 * Undo.
	 */
	public boolean undo() {
		Object[] parameterList = new Object[1];
		parameterList[0] = oldValue;
		try {
			Method aMethod = obtainMethod("set" + propertyName);
			aMethod.invoke(subject, parameterList);
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValueChangeEvent.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2012/08/25 18:12:53  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.5  2011/03/23 23:46:58  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.4  2010/03/22 23:29:25  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/01/14 18:31:23  mwpzs3
 *  move to JCL logging
 *
 *  Revision 1.2  2009/12/09 19:37:32  mwpxp2
 *  Replaced system.outs with logging
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/06 23:59:42  mwpxp2
 *  Separated isValid from hasValueChanged
 *
 *  Revision 1.4  2009/10/06 23:17:05  mwpxp2
 *  Modified getValue, isValid, toString
 *
 *  Revision 1.3  2009/10/06 02:16:36  mwpxp2
 *  Changed undo to return a boolean
 *
 *  Revision 1.2  2009/10/04 02:12:45  mwpxp2
 *  modified getValue for null value
 *
 *  Revision 1.1  2009/10/03 19:43:16  mwpxp2
 *  Moved to proper package; added class comment, javadoc
 *
 *  Revision 1.8  2009/09/15 18:16:42  mwsmg6
 *  refactored list changes
 *
 *  Revision 1.7  2009/09/15 17:44:26  mwsmg6
 *  refactored list changes
 *
 *  Revision 1.6  2009/09/15 17:41:16  mwsmg6
 *  cleanup
 *
 *  Revision 1.5  2009/09/03 04:52:16  mwsmg6
 *  cleanup
 *
 *  Revision 1.4  2009/09/03 04:43:37  mwsmg6
 *  cleanup
 *
 *  Revision 1.3  2009/09/03 03:56:14  mwsmg6
 *  restart
 *
 *  Revision 1.2  2009/08/04 20:41:19  mwpxp2
 *  Added class header and footer; fixme
 *
 */
