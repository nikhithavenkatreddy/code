/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am abstract exception for business layer
 * File: EaseBusinessLayerException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EaseBusinessLayerException extends EaseLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3360875541327058730L;

	/**
	 * Instantiates a new ease business layer exception.
	 */
	public EaseBusinessLayerException() {
		super();
	}

	/**
	 * @param message
	 */
	public EaseBusinessLayerException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public EaseBusinessLayerException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public EaseBusinessLayerException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseBusinessLayerException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
