/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am exception to be used for failures in service request execution
 * File: ServiceRequestExecutionException.java
 * Module:  gov.ca.dmv.ease.bus.dl.exception.impl
 * Created: Jun 1, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ServiceRequestExecutionException extends EaseServiceLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5625071965044696598L;

	/**
	 * Instantiates a new service request execution exception.
	 */
	public ServiceRequestExecutionException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public ServiceRequestExecutionException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public ServiceRequestExecutionException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public ServiceRequestExecutionException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ServiceRequestExecutionException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.2.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.1  2010/06/01 18:23:09  mwpxp2
 *  Initial
 *
 */
