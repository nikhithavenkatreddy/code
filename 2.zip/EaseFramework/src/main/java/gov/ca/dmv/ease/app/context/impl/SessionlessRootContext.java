/**
 * 
 */
package gov.ca.dmv.ease.app.context.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;


/**
 * Description: Root context for processes which run outside a session context
 * File: SessionlessRootContext.java
 * Module:  gov.ca.dmv.ease.app.context.impl
 * Created: May 31, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SessionlessRootContext extends SessionContext {

	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(SessionlessRootContext.class);

	private static final long serialVersionUID = -5851346575604860654L;
	/* the process context to run */
	private ProcessContext processToRun;
	/* the name of the process to run */
	private String targetProcessName;
	/* the TTC to run the process as */
	private String ttcToRunAs;

	/**
	 * @return the processToRun
	 */
	public ProcessContext getProcessToRun() {
		return processToRun;
	}

	/**
	 * @return the targetProcessName
	 */
	public String getTargetProcesName() {
		return targetProcessName;
	}

	/**
	 * @return the ttcToRunAs
	 */
	public String getTtcToRunAs() {
		return ttcToRunAs;
	}

	/**
	 * @param processToRun the processToRun to set
	 */
	public void setProcessToRun(ProcessContext processToRun) {
		this.processToRun = processToRun;
	}
	
	/**
	 * @param targetProcessName the targetProcessName to set
	 */
	public void setTargetProcessName(String targetProcessName) {
		this.targetProcessName = targetProcessName;
	}

	/**
	 * @param ttcToRunAs the ttcToRunAs to set
	 */
	public void setTtcToRunAs(String ttcToRunAs) {
		this.ttcToRunAs = ttcToRunAs;
	}

	/**
	 * Bootstraps the process engine and starts it. 
	 * 
	 * Note: This code duplicates the inherited 'myInit' method from SessionContext. The reason for this is to 
	 * avoid invoking the aspects which are advising myInit. 
	 */
	public void startProcess() {
		BusinessProcess topBusinessProcess = getProcessRegistry().getProcess(
				IProcessRegistry.TOP_BUSINESS_PROCESS);
		LOGGER.info("Business Process :: " + topBusinessProcess.getId());
		setProcessId(topBusinessProcess.getId());
		setCurrentActivity(topBusinessProcess.getStartingActivity());
		getCurrentActivity().execute(this);
	}
}

/**
 *  Modification History:
 *
 *  $$Log: SessionlessRootContext.java,v $
 *  $Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.2  2012/06/08 17:19:37  mwsec2
 *  $initial check-in of classes to support the running of business processes outside an HTTP session context
 *  $$
 */
