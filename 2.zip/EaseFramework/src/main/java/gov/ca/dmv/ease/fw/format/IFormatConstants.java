/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

import java.io.Serializable;

/**
 * Description: I define constants used in reading format expressions
 * File: IFormatConstants.java
 * Module:  gov.ca.dmv.ease.fw.format.reader
 * Created: Nov 28, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IFormatConstants extends Serializable {
	/** The ALPH a_ type. */
	char ALPHA_TYPE = 'A';
	/** The DAT e_ type. */
	char DATE_TYPE = 'D';
	
	/** The NU m_ type. */
	char NUM_TYPE = 'N';
	
	/** The TIM e_ type. */
	char TIME_TYPE = 'T';
	/** The WHITESPAC e_ type. */
	char WHITESPACE_TYPE = 'Z';
}
/**
 *  Modification History:
 *
 *  $Log: IFormatConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/01 01:36:30  mwpxp2
 *  Refactored with reader constatns
 *
 *  Revision 1.1  2010/12/01 01:21:17  mwpxp2
 *  Moved in from another package
 *
 *  Revision 1.1  2010/11/29 07:44:07  mwpxp2
 *  Initial
 *
 */
