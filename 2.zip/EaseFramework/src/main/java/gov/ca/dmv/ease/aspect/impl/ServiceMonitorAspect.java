/**
 * 
 */
package gov.ca.dmv.ease.aspect.impl;

import gov.ca.dmv.ease.ecs.impl.EcsService;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.service.impl.PersistenceService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;


/**
 * Description: An aspect class to monitor the response times of service calls
 * File: ServiceMonitorAspect.java
 * Module:  gov.ca.dmv.ease.aspect.impl
 * Created: Oct 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:50 $
 * Last Changed By: $Author: mwsec2 $
 */
@Aspect
public class ServiceMonitorAspect extends AbstractAspect {
	
	/** The logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(ServiceMonitorAspect.class);
	
	/** The logger for PersistenceService class */
	private static final Log ECS_SERVICE_LOGGER = LogFactory
			.getLog(EcsService.class);
	
	/** The logger for PersistenceService class */
	private static final Log PERSISTENCE_SERVICE_LOGGER = LogFactory
			.getLog(PersistenceService.class);
	
	private static final long RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS = 2;
	
	/**
	 * This method advises persistence calls, to log warnings if the call completion
	 * exceeds a threshold
	 *
	 * @param joinPoint the joinPoint
	 */
	@Around("execution(* gov.ca.dmv.ease.tus.persist.service.impl.PersistenceService.execute(..)) && args(request)")
	public Object persistenceCall(ProceedingJoinPoint joinPoint,
			IPersistenceServiceRequest request) throws Throwable {
		Object returnValue = null;
		long startTimeStamp = System.nanoTime();
		returnValue = joinPoint.proceed();
		long endTimeStamp = System.nanoTime();
		double totalTime = (endTimeStamp - startTimeStamp) / 1000000000.0;
		if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
			PERSISTENCE_SERVICE_LOGGER.warn("persistence service call for request of type "
					+ request.getClass().getSimpleName() + " took " + totalTime
					+ " seconds");
		}
		return returnValue;
	}
	
	@Around("execution(* gov.ca.dmv.ease.ecs.impl.EcsService.processRequest(..)) && args(request)")
	public Object ecsCall(ProceedingJoinPoint joinPoint,
			IEcsRequest request) throws Throwable {
		Object returnValue = null;
		long startTimeStamp = System.nanoTime();
		returnValue = joinPoint.proceed();
		long endTimeStamp = System.nanoTime();
		double totalTime = (endTimeStamp - startTimeStamp) / 1000000000.0;
		if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
			ECS_SERVICE_LOGGER.warn("ECS service call for request of type "
					+ request.getClass().getSimpleName() + " took " + totalTime
					+ " seconds");
		}
		return returnValue;
	}
	
}


/**
 *  Modification History:
 *
 *  $Log: ServiceMonitorAspect.java,v $
 *  Revision 1.2  2013/06/26 21:59:50  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2013/01/17 21:00:35  mwsec2
 *  rebase from HEAD
 *
 */