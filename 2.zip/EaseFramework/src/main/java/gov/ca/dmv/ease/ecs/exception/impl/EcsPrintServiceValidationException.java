/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: This class represents Print Service Validation Exception.
 * File: EcsPrintServiceValidationException.java
 * Module:  gov.ca.dmv.ease.ecs.msg
 * Created: Mar 17, 2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsPrintServiceValidationException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7457535177837849051L;

	/**
	 * Instantiates a new Print Service Validation exception.
	 */
	public EcsPrintServiceValidationException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message.
	 * 
	 * @param message the message
	 */
	public EcsPrintServiceValidationException(String message) {
		super(message);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * 
	 * @param message the message
	 * @param cause the Throwable cause
	 */
	public EcsPrintServiceValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public EcsPrintServiceValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsPrintServiceValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/06/30 00:24:05  mwhxa2
 *  Ecs Print Validation Exception
 *
 */
