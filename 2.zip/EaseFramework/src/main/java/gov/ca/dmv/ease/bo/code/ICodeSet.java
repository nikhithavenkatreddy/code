/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code;

import gov.ca.dmv.ease.fw.IWithValidityPeriod;

import java.util.Date;
import java.util.List;

/**
 * Description: I am interface for a named  collection of code set elements
 * File: ICodeSet.java
 * Module:  gov.ca.dmv.ease.bo.code
 * Created: Aug 4, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICodeSet extends IWithValidityPeriod {
	/**
	 * Adds the.
	 * 
	 * @param anElem the an elem
	 * 
	 * @return the i code set
	 */
	ICodeSet add(ICodeSetElement anElem);

	/**
	 * Gets the elements.
	 * 
	 * @return the elements
	 */
	List <ICodeSetElement> getCodeSetElements();

	/**
	 * Gets the code set name.
	 * 
	 * @return the code set name
	 */
	String getCodeSetName();

	/**
	 * @param codeSetElementName
	 * @return
	 */
	ICodeSetElement getElementNamed(String codeSetElementName);

	/**
	 * @return
	 */
	List <ICodeSetElement> getElementsEffectiveNow();

	/**
	 * @param aDate
	 * @return
	 */
	List <ICodeSetElement> getElementsEffectiveOn(Date aDate);

	/**
	 * Gets the element with code.
	 * 
	 * @param codeSetElementCode the code set element code
	 * 
	 * @return the element with code
	 */
	ICodeSetElement getElementWithCode(String codeSetElementCode);

	/**
	 * Checks for element.
	 * 
	 * @param anElem the an elem
	 * 
	 * @return true, if successful
	 */
	boolean hasElement(ICodeSetElement anElem);

	/**
	 * Checks for element named.
	 * 
	 * @param codeSetElementName the a name
	 * 
	 * @return true, if successful
	 */
	boolean hasElementNamed(String codeSetElementName);

	/**
	 * Checks for code equal to.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasElementWithCodeEqualTo(String aCode);

	/**
	 * Checks for element with code equal to any of.
	 * 
	 * @param aCodeArr the a code arr
	 * 
	 * @return true, if successful
	 */
	boolean hasElementWithCodeEqualToAnyOf(String... aCodeArr);

	/**
	 * Checks for no element with code equal to.
	 * 
	 * @param aCode the a code
	 * 
	 * @return true, if successful
	 */
	boolean hasNoElementWithCodeEqualTo(String aCode);

	/**
	 * Checks for no element with code equal to any of.
	 * 
	 * @param aCodeArr the a code arr
	 * 
	 * @return true, if successful
	 */
	boolean hasNoElementWithCodeEqualToAnyOf(String... aCodeArr);

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if is empty
	 */
	boolean isEmpty();
}
/**
 *  Modification History:
 *
 *  $Log: ICodeSet.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/05/26 00:33:44  mwpxp2
 *  Added a handful of has~ utility test methods
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/08/27 05:39:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/08/27 02:22:40  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.5  2009/08/10 18:32:04  mwpxp2
 *  Added getElementWithCode/1
 *
 *  Revision 1.4  2009/08/06 00:47:39  mwpxp2
 *  Added three methods - getElement~
 *
 *  Revision 1.3  2009/08/05 00:04:47  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 *  Revision 1.2  2009/08/04 16:47:48  mwpxp2
 *  Added boolean calls
 *
 *  Revision 1.1  2009/08/04 16:46:30  mwpxp2
 *  Initial
 *
 */
