/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.util.impl;

import org.hibernate.dialect.DB2390Dialect;

/**
 * Description: The syntax for use of sequences varies between OS390 platform and the default does not work with the current DMV DB2 version
 * File: Db2390DialectSequenceFix.java
 * Module:  gov.ca.dmv.ease.tus.persist.util.impl
 * Created: Sep 9, 2009 
 * @author MWVXM6  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Db2390DialectSequenceFix extends DB2390Dialect {
	/**
	 * The syntax for use of sequences varies between OS390 platform and the default does not work with the current DMV DB2 version
	 * 
	 * @return the next sequence Number
	 */
	@Override
	public String getSequenceNextValString(String sequenceName) {
		return "select next value for " + sequenceName
				+ " from sysibm.sysdummy1;";
	}
}
