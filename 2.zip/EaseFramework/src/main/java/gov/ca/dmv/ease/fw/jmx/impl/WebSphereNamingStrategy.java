/**
 * 
 */
package gov.ca.dmv.ease.fw.jmx.impl;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.springframework.jmx.export.naming.ObjectNamingStrategy;
import org.springframework.jmx.support.ObjectNameManager;
import org.springframework.util.ClassUtils;

/**
 * Description: Provides Websphere-specific object names. Used by the MBeanExporter to obtain 
 * ObjectNames when registering beans.
 *  
 * File: WebSphereNamingStrategy.java
 * Module:  gov.ca.dmv.ease.fw.jmx.impl
 * Created: Jul 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/17 17:56:58 $
 * Last Changed By: $Author: mwkfh $
 */
public class WebSphereNamingStrategy implements ObjectNamingStrategy {
	private String domainName;
	private String cellName;
	private String mbeanId;
	private String nodeName;
	private String processName;

	/* (non-Javadoc)
	 * @see org.springframework.jmx.export.naming.ObjectNamingStrategy#getObjectName(java.lang.Object, java.lang.String)
	 */
	public ObjectName getObjectName(Object object, String name)
			throws MalformedObjectNameException {
		StringBuffer objectName = new StringBuffer();
		objectName.append(domainName);
		objectName.append(":cell=");
		objectName.append(cellName);
		objectName.append(",name=");
		objectName.append(name);
		objectName.append(",mBeanIdentifier=");
		objectName.append(mbeanId);
		objectName.append(",type=");
		objectName.append(ClassUtils.getShortName(object.getClass()));
		objectName.append(",node=");
		objectName.append(nodeName);
		objectName.append(",process=");
		objectName.append(processName);
		return ObjectNameManager.getInstance(objectName.toString());
	}

	/**
	 * @return
	 */
	public String getCellName() {
		return cellName;
	}

	/**
	 * @param cellName
	 */
	public void setCellName(String cellName) {
		this.cellName = cellName;
	}

	/**
	 * @return
	 */
	public String getMbeanId() {
		return mbeanId;
	}

	/**
	 * @param mbeanId
	 */
	public void setMbeanId(String mbeanId) {
		this.mbeanId = mbeanId;
	}

	/**
	 * @return
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return
	 */
	public String getNodeName() {
		return nodeName;
	}

	/**
	 * @param nodeName
	 */
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	/**
	 * @return
	 */
	public String getProcessName() {
		return processName;
	}

	/**
	 * @param processName
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}
}
/**
 *  Modification History:
 *
 *  $Log: WebSphereNamingStrategy.java,v $
 *  Revision 1.1  2012/10/17 17:56:58  mwkfh
 *  Initial
 *
 *  Revision 1.1.6.1  2012/09/04 22:30:03  mwsec2
 *  logging & jmx enhancements
 *
 *  Revision 1.1.4.1  2012/08/01 21:17:50  mwsec2
 *  initial commit to new branch
 *
 *  Revision 1.1.2.1  2012/07/31 17:21:38  mwsec2
 *  checking in logging enhancements
 *
 */
