/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Collection;

/**
 * Description: I am abstract class for persistence operation on multiple objects, 
 * of one or more class.
 * 
 * File: MultiObjectPersistenceRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Sep 1, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class MultiObjectPersistenceRequest extends
		PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3910106935036987825L;
	/** The business objects. */
	private Collection <IBusinessObject> businessObjects;

	/**
	 * Instantiates a new multi object persistence request.
	 * 
	 * @param userContext the user context
	 * @param aList the a list
	 */
	public MultiObjectPersistenceRequest(IUserContext userContext,
			Collection <IBusinessObject> aList) {
		super(userContext);
		setBusinessObjects(aList);
	}

	/**
	 * Adds the.
	 * 
	 * @param aBo the a bo
	 */
	public void add(IBusinessObject aBo) {
		getBusinessObjects().add(aBo);
	}

	/**
	 * Adds the all.
	 * 
	 * @param aBoColl the a bo coll
	 */
	public void addAll(Collection <IBusinessObject> aBoColl) {
		getBusinessObjects().addAll(aBoColl);
	}

	/**
	 * Gets the business objects.
	 * 
	 * @return the business objects
	 */
	public Collection <IBusinessObject> getBusinessObjects() {
		return businessObjects;
	}

	/**
	 * Sets the business objects.
	 * 
	 * @param businessObjects the new business objects
	 */
	protected void setBusinessObjects(
			Collection <IBusinessObject> businessObjects) {
		this.businessObjects = businessObjects;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultiObjectPersistenceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/09/09 22:02:37  mwkfh
 *  removed default constructor and changed constructor to use setBusinessObjects instead of addAll to fix null pointer exception
 *
 *  Revision 1.2  2010/09/09 16:08:03  mwkfh
 *  changed getBusinessObjects to public
 *
 *  Revision 1.1  2010/09/01 20:00:06  mwpxp2
 *  Initial
 *
 */
