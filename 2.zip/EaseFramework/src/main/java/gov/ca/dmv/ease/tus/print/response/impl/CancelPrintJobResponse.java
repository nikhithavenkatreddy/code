/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: The Response for Cancel Print Job.
 * File: CancelPrintJobResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response.impl
 * Created: Aug 05, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CancelPrintJobResponse extends PrintServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1698125547927730894L;

	/**
	 * Constructor.
	 */
	public CancelPrintJobResponse() {
		// Empty Constructor
	}

	/**
	 * Instantiates a new Cancel Print Job Response.
	 * 
	 * @param errorCollector the Error Messages
	 */
	public CancelPrintJobResponse(IErrorCollector errorCollector) {
		super(errorCollector);
	}

	/**
	 * Instantiates a new Cancel Print Job Response.
	 * 
	 * @param clientJobId the Client Job Id
	 * @param printExecutionStatus the Print Execution Status
	 */
	public CancelPrintJobResponse(String clientJobId,
			String printExecutionStatus) {
		super(clientJobId, printExecutionStatus);
	}

	/**
	 * Instantiates a new Cancel Print Job Response.
	 * 
	 * @param e the Exception
	 */
	public CancelPrintJobResponse(Throwable e) {
		super(e);
	}
}
/**
 *  Modification History:
 *	
 *  $Log: CancelPrintJobResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/06/21 23:00:42  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.6.2  2010/06/20 18:06:54  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/07 17:42:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 *
 */
