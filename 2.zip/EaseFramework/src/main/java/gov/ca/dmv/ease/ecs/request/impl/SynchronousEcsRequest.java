/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.impl.SynchronousResponse;
import gov.ca.dmv.ease.fw.constants.IEaseLoggingConstants;
import gov.ca.dmv.ease.fw.logging.ISystemManagementLoggable;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Calendar;

/**
 * Description: I am abstract superclass for synchronous requests.
 * File: SynchronousEcsRequest.java
 * Module:  gov.ca.dmv.ease.service.request.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class SynchronousEcsRequest extends AbstractEcsRequest
		implements ISystemManagementLoggable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6219527708565336545L;
	/** Multi segment response indicator */
	private boolean isMultiSegment = false;

	/**
	 * Instantiates a new synchronous request.
	 */
	public SynchronousEcsRequest() {
		this(null, null);
	}

	/**
	 * Instantiates a new synchronous ECS request.
	 * 
	 * @param userContext the user context
	 */
	public SynchronousEcsRequest(IUserContext userContext) {
		this(null, userContext);
	}

	/**
	 * Instantiates a new synchronous ECS request.
	 * 
	 * @param anId the an id
	 */
	public SynchronousEcsRequest(String anId) {
		this(anId, null);
	}

	/**
	 * Instantiates a new synchronous request with an request ID and UserContext instance.
	 * 
	 * @param anId ID of the request
	 * @param aContext UserContext instance
	 */
	public SynchronousEcsRequest(String anId, IUserContext aContext) {
		super(anId, aContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public SynchronousResponse execute() throws EcsServiceException {
		SynchronousResponse returnSynchronousResponse = null;
		//		try {
		returnSynchronousResponse = (SynchronousResponse) getEcsService()
				.processRequest(this);
		//		}
		//		catch (EcsResponseIsNullException responseIsNullException) {
		//			returnSynchronousResponse.getErrorCollector().register(
		//					new EaseValidationException(CNA_SHORT_TERM_MESSAGE));
		//		}
		//		catch (SystemException sysEx) {
		//			returnSynchronousResponse.getErrorCollector().register(
		//					new EaseValidationException(RESOURCE_PROBLEM_MESSAGE));
		//		}
		return returnSynchronousResponse;
	}

	/**
	 * Returns true if the request is multi-segment.
	 * @return isMultiSegment the isMultiSegment
	 */
	public boolean isMultiSegment() {
		return isMultiSegment;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#isSynchronousRequest()
	 */
	@Override
	public final boolean isSynchronousRequest() {
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ISystemManagementLoggable#outputSystemManagementLog(java.lang.StringBuilder)
	 */
	public void outputSystemManagementLog(StringBuilder aStringBuilder) {
		aStringBuilder.append("CREATED_BY="
				+ ((UserContext) getUserContext()).getUserName() + IEaseLoggingConstants.FIELD_DELIMITER);
		aStringBuilder.append("CREATED_DATE="
				+ Calendar.getInstance().getTime() + IEaseLoggingConstants.FIELD_DELIMITER);
		aStringBuilder.append("LOG_ENTRY=");
		((UserContext) getUserContext()).outputAuditLog(aStringBuilder);
	}

	/**
	 * Sets the request to be the multi-segments.
	 * @param isMultiSegment the isMultiSegment to set
	 */
	public void setMultiSegment(boolean isMultiSegment) {
		this.isMultiSegment = isMultiSegment;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SynchronousEcsRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2011/01/11 00:37:31  mwxxw
 *  Use constant: FIELD_DELIMITER.
 *
 *  Revision 1.9  2010/11/05 22:16:27  mwtjc1
 *  try-catch block commented in execute method
 *
 *  Revision 1.8  2010/10/27 00:50:30  mwhys
 *  Added try-catch block around getEcsService().processRequest(this) call.
 *
 *  Revision 1.7  2010/09/22 18:04:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/09/21 18:52:22  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< SynchronousEcsRequest.java
 *  Revision 1.5  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
=======
 *  Revision 1.4.4.2  2010/09/18 23:08:35  mwpxr4
 *  Typecasted concrete classes
 *
 *  Revision 1.4.4.1  2010/09/14 22:13:09  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.5  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
>>>>>>> 1.4.4.2
 *  Revision 1.4  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/03/22 23:27:26  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/14 20:47:10  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.5  2009/10/13 21:19:51  mwhxb3
 *  updated comments.
 *
 *  Revision 1.4  2009/10/07 03:33:43  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:56:50  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:53:04  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:37  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9  2009/10/03 21:23:36  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.8  2009/09/28 21:37:32  mwrsk
 *  ISystemManagementLoggable moved to framework project
 *
 *  Revision 1.7  2009/09/17 21:37:55  mwsxd10
 *  Log message structure changed.
 *
 *  Revision 1.6  2009/09/10 16:51:07  mwsxd10
 *  Implements SystemManageableLaggable.
 *
 *  Revision 1.5  2009/09/02 01:25:12  mwpzs3
 *  Mutiple payload response handling
 *
 *  Revision 1.4  2009/08/27 02:33:54  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/22 20:31:09  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2009/08/10 23:05:48  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.1  2009/07/27 18:48:52  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.9  2009/07/27 17:46:47  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.8  2009/07/21 15:29:57  mwakg
 *  Merging from branch MWAKG_ECS_CONVERTERS-CLEANING_BRANCH_20090720
 *
 *  Revision 1.7.2.1  2009/07/20 22:32:36  mwakg
 *  Fixed the constuctors and compilation errors in converters
 *
 *  Revision 1.7  2009/07/20 17:15:42  mwcsj3
 *  Added constructor which sets IUsercontext
 *
 *  Revision 1.6  2009/07/18 19:56:55  mwbxp5
 *  Refactoring
 *
 *  Revision 1.5  2009/07/17 00:20:51  mwakg
 *  Added IUserContext as a parameter to request classes of ECS's converters
 *
 *  Revision 1.4  2009/07/16 02:18:11  mwpxp2
 *  Removed empty getUserContext method; added file decorations, javadoc
 *
 *  Revision 1.3  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.5  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 17:45:21  mwpxp2
 *  Moved in
 *
 *  Revision 1.2  2009-05-11 07:31:48  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-09 07:32:42  mwpxp2
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
