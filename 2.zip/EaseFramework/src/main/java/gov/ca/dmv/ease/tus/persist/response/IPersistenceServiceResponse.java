/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response;

import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am the interface for the PersistenceServiceResponse class.
 * File: IPersistenceServiceResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPersistenceServiceResponse extends IResponse {
	/**
	 * Compares object to 'other' and returns true if equal.
	 * 
	 * @param obj
	 * 
	 * @return true if equal; otherwise, false
	 */
	boolean equals(Object obj);

	/**
	 * Returns the effected item count number.
	 * 
	 * @return affectedItemsCount
	 */
	Integer getAffectedItemsCount();

	/**
	 * Generates and returns the hash code.
	 * 
	 * @return hashCode
	 */
	int hashCode();

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	void toStringOn(StringBuilder aBuilder, int anIndent);
}
/**
 *  Modification History:
 *
 *  $Log: IPersistenceServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/06 19:36:19  mwkfh
 *  Inital
 *
 */
