/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Description:  I am default implementation of IBusinessObjectValueExtractor
 * File: BusinessObjectValueExtractor.java
 * Module:  gov.ca.dmv.ease.bo.impl
 * Created: Aug 3, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BusinessObjectValueExtractor implements
		IBusinessObjectValueExtractor {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1268069033258408295L;

	/**
	 * Gets the getter name for.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the getter name for
	 */
	public static String getGetterNameFor(String aPropertyName) {
		validateProperty(aPropertyName);
		return prepend(GET_PREFIX, aPropertyName);
	}

	/**
	 * Gets the setter name for.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the setter name for
	 */
	public static String getSetterNameFor(String aPropertyName) {
		validateProperty(aPropertyName);
		return prepend(SET_PREFIX, aPropertyName);
	}

	/**
	 * Prepend.
	 * 
	 * @param aPrefix the a prefix
	 * @param aPropertyName the a property name
	 * 
	 * @return the string
	 */
	protected static String prepend(String aPrefix, String aPropertyName) {
		StringBuilder aBuff = new StringBuilder(aPropertyName.length()
				+ aPrefix.length());
		aBuff.append(aPrefix);
		aBuff.append(Character.toUpperCase(aPropertyName.charAt(0)));
		for (int i = 1; i < aPropertyName.length(); i++) {
			aBuff.append(aPropertyName.charAt(i));
		}
		return aBuff.toString();
	}

	/**
	 * Validate property.
	 * 
	 * @param aPropertyName the a property name
	 */
	public static void validateProperty(String aPropertyName) {
		if (aPropertyName == null) {
			throw new EaseValidationException("null property name");
		}
		if (aPropertyName.trim().length() == 0) {
			throw new EaseValidationException("empty or blank property name");
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor#getBusinessObjectNamed(java.lang.String, gov.ca.dmv.ease.bo.IBusinessObject)
	 */
	public IBusinessObject getBusinessObjectNamed(String aPropertyName,
			IBusinessObject aSourceBo) {
		try {
			return (IBusinessObject) getObjectNamed(aPropertyName, aSourceBo,
					IBusinessObject.class);
		}
		catch (ClassCastException e) {
			throw new EaseValidationException("Cast exception on property: \""
					+ aPropertyName + "\"", e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor#getIntegerValueNamed(java.lang.String, gov.ca.dmv.ease.bo.IBusinessObject)
	 */
	public Integer getIntegerValueNamed(String aPropertyName,
			IBusinessObject aSourceBo) {
		try {
			return (Integer) getObjectNamed(aPropertyName, aSourceBo,
					Integer.class);
		}
		catch (ClassCastException e) {
			throw new EaseValidationException("Cast exception on property: \""
					+ aPropertyName + "\"", e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor#getObjectNamed(java.lang.String, gov.ca.dmv.ease.bo.IBusinessObject)
	 */
	public Object getObjectNamed(String aPropertyName, IBusinessObject aSourceBo) {
		return getObjectNamed(aPropertyName, aSourceBo, Object.class);
	}

	/**
	 * Gets the object named.
	 * 
	 * @param aPropertyName the a property name
	 * @param aSourceBo the a source bo
	 * @param aTargetReturnType the a target return type
	 * 
	 * @return the object named
	 */
	public Object getObjectNamed(String aPropertyName,
			IBusinessObject aSourceBo, Class <?> aTargetReturnType) {
		String aGetterName = getGetterNameFor(aPropertyName);
		try {
			Class <?> aClass = aSourceBo.getClass();
			Method aMethod = aClass.getMethod(aGetterName,
					EMPTY_DECLARATION_METHOD_ARGS);
			Class <?> aReturnType = aMethod.getReturnType();
			if (aTargetReturnType != Object.class) {
				validateMethodReturnType(aReturnType, aTargetReturnType);
			}
			return aMethod.invoke(aSourceBo, EMPTY_INVOCATION_METHOD_ARGS);
		}
		catch (SecurityException e) {
			throw new EaseValidationException("SecurityException on: \""
					+ aGetterName + "\"", e);
		}
		catch (NoSuchMethodException e) {
			throw new EaseValidationException("No getter: \"" + aGetterName
					+ "\"", e);
		}
		catch (IllegalArgumentException e) {
			throw new EaseValidationException("IllegalArgumentException on: \""
					+ aGetterName + "\"", e);
		}
		catch (IllegalAccessException e) {
			throw new EaseValidationException("IllegalAccessException on: \""
					+ aGetterName + "\"", e);
		}
		catch (InvocationTargetException e) {
			throw new EaseValidationException(
					"InvocationTargetException on: \"" + aGetterName + "\"", e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor#getStringValueNamed(java.lang.String, gov.ca.dmv.ease.bo.IBusinessObject)
	 */
	public String getStringValueNamed(String aPropertyName,
			IBusinessObject aSourceBo) {
		try {
			return (String) getObjectNamed(aPropertyName, aSourceBo,
					String.class);
		}
		catch (ClassCastException e) {
			throw new EaseValidationException("Cast exception on property: \""
					+ aPropertyName + "\"", e);
		}
	}

	/**
	 * This method checks if an Interface is implemented.
	 * 
	 * @param anUnknownClass the Class to be checked.
	 * @param aDeclaredReturnInterface the Declared Interface implemented by the class.
	 * 
	 * @return true if Class Implements the Interface.
	 */
	private boolean isImplementedInterface(Class <?> anUnknownClass,
			Class <?> aDeclaredReturnInterface) {
		Class <?> anInterface;
		for (int i = 0; i < anUnknownClass.getInterfaces().length; i++) {
			anInterface = anUnknownClass.getInterfaces()[i];
			if (anInterface == aDeclaredReturnInterface) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This method checks if the Class is of Sub Class type.
	 * 
	 * @param anUnknownClass the Class to be check for Sub class
	 * @param aDeclaredReturnType the Class who is the Sub Class
	 * 
	 * @return true if the Class is a Sub Class
	 */
	private boolean isSubclass(Class <?> anUnknownClass,
			Class <?> aDeclaredReturnType) {
		if (aDeclaredReturnType == Object.class) {
			return true;
		}
		Class <?> aSuper = anUnknownClass;
		while (aSuper != Object.class && aSuper != null) {
			if (aSuper == aDeclaredReturnType) {
				return true;
			}
			aSuper = aSuper.getSuperclass();
		}
		return false;
	}

	/**
	 * Validate method return type.
	 * 
	 * @param returnType the return type
	 * @param targetReturnType the target return type
	 */
	protected void validateMethodReturnType(Class <?> aReturnType,
			Class <?> aTargetReturnType) {
		if (aReturnType != aTargetReturnType) {
			if (!isSubclass(aReturnType, aTargetReturnType)
					&& !isImplementedInterface(aReturnType, aTargetReturnType)) {
				throw new EaseValidationException("Incompatible actual type: "
						+ aReturnType.getName() + " with target: "
						+ aTargetReturnType.getName());
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: BusinessObjectValueExtractor.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/08/25 18:08:13  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.3  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/15 18:09:56  mwrka1
 *  removed default constructor
 *
 *  Revision 1.5  2009/10/03 21:06:30  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/08/27 02:22:35  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/06 23:05:22  mwpxp2
 *  Adjusted per interface mods
 *
 *  Revision 1.2  2009/08/04 17:58:59  mwpxp2
 *  Added catch clauses for cast exceptions
 *
 *  Revision 1.1  2009/08/04 01:37:08  mwpxp2
 *  Initial
 *
 */
