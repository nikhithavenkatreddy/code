/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.common.impl;

import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;

/**
 * Description: This activity class collects the document work type of the transaction.
 * File: CollectDocumentWorkTypeActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.common.impl
 * Created: Sep 01, 2009 
 * @author MWBVC  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CollectDocumentWorkTypeActivity extends InteractionActivity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3276598475101347231L;

	/**
	 * Instantiates a new collect office tech id activity.
	 */
	public CollectDocumentWorkTypeActivity() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.InteractionActivity#executeAction(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	public void executeAuthorized(ProcessContext context) {
		//FIX - this method must not be public - it should not increase visibility from the superclass
		//TODO - add convenience methods in context to do the test
		if ("DL".equals(context.getWorkType())) {
			BusinessProcess businessProcess = getProcessRegistry().getProcess(
					IProcessRegistry.DL_MENU_BUSINESS_PROCESS);
			startBusinessProcess(businessProcess, context);
		}
		//TODO - add convenience methods in context to do the test
		else if ("IN".equals(context.getWorkType())) {
			BusinessProcess businessProcess = getProcessRegistry().getProcess(
					IProcessRegistry.DCS_MENU_BUSINESS_PROCESS);
			startBusinessProcess(businessProcess, context);
		}
		else {
			BusinessProcess businessProcess = getProcessRegistry().getProcess(
					IProcessRegistry.COURT_INQUIRY_BUSINESS_PROCESS);
			startBusinessProcess(businessProcess, context);
		}
	}

	/**
	 * Start business process.
	 * 
	 * @param businessProcess the business process
	 * @param parentContext the parent context
	 */
	private void startBusinessProcess(BusinessProcess businessProcess,
			ProcessContext parentContext) {
		if (businessProcess == null) {
			throw new ApplicationException("Invalid TTC");
		}
		ChildContext childContext = (ChildContext) businessProcess
				.getProcessContext();
		childContext.startIn(parentContext);
	}
}
/**
 *  Modification History:
 *  $Log: CollectDocumentWorkTypeActivity.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.9.14.1  2010/06/20 20:03:06  mwakg
 *  Fixed API and 07Q navigations
 *
 *  Revision 1.9  2010/04/13 17:40:17  mwpxp2
 *  Added fixme and todos; javadoc
 *
 *  Revision 1.8  2010/04/08 01:26:49  mwcsj3
 *  Changed executeAction to executeAuthorized
 *
 *  Revision 1.6  2010/04/07 22:19:16  mwcsj3
 *  Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 *  Revision 1.5  2010/04/04 23:29:34  mwakg
 *  Changed ProcessRegistry variable to private and made a getter method for it
 *
 *  Revision 1.4  2010/03/22 22:55:11  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.3  2010/03/11 22:20:26  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.2.2.1  2010/02/27 00:02:43  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.2  2009/12/01 19:07:54  mwyxg1
 *  add serialVersionUID
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.12  2009/10/13 01:03:06  mwrrv2
 *  provided class description.
 *
 *  Revision 1.11  2009/10/07 19:16:32  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.10  2009/10/03 20:57:25  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.9  2009/09/22 23:47:59  mwsmg6
 *  cleanup
 *
 *  Revision 1.8  2009/09/22 23:45:27  mwsmg6
 *  cleanup
 *
 *  Revision 1.7  2009/09/22 23:43:16  mwsmg6
 *  cleanup
 *
 *  Revision 1.6  2009/09/09 21:58:13  mwbvc
 *  condition to check the inquiry
 *
 *  Revision 1.5  2009/09/08 22:49:12  mwbvc
 *  DlMenuProcessContext changes
 *
 *  Revision 1.4  2009/09/03 20:34:52  mwyxg1
 *  Added court inquiry business process
 *
 *  Revision 1.3  2009/09/03 04:12:29  mwjjl7
 *  refactor for action handling specification
 *
 *  Revision 1.2  2009/09/02 22:41:26  mwbvc
 *  changes to capture tech ID and Office Id
 *
 *  Revision 1.1  2009/09/02 19:21:35  mwbvc
 *  New Activity for collecting Document and work type as per the new Easehome
 * 
 *   
 */
