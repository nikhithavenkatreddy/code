/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service.impl;

/**
 * Description: I am mock version of my superclass
 * I am not a singleton
 *  //TODO complecte implementation
 * 
 * File: MockPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service.impl
 * Created: Oct 19, 2011 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
@Deprecated

public class MockPersistenceService extends PersistenceService {
	/**
	 * Gets the single instance of MockPersistenceService.
	 *
	 * @return single instance of MockPersistenceService
	 */
	public static MockPersistenceService getInstance() {
		return new MockPersistenceService();
	}

	/**
	 * Instantiates a new mock persistence service.
	 */
	public MockPersistenceService() {
		super();
	}
}
/**
 *  Modification History:
 *
 *  $Log: MockPersistenceService.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/08/25 17:52:03  mwpxp2
 *  Deprecated - use a mock in the test tree
 *
 *  Revision 1.1  2011/10/19 17:42:12  mwpxp2
 *  Initial - for unit testing only
 *
 */
