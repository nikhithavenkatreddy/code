/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.app.config;

import gov.ca.dmv.ease.app.process.impl.BusinessProcess;

/**
 * Description: //TODO - add class comment
 * File: IProcessRegistry.java
 * Module:  gov.ca.dmv.ease.app.config
 * Created: Mar 31, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IProcessRegistry {
	/** The CD a_ men u_ busines s_ process. */
	String CDA_MENU_BUSINESS_PROCESS = "CDA";
	/** The DL inquiry business Process. */
	String COUNSELOR_INQUIRY = "07Q";
	/** The COUR t_ inquir y_ busines s_ process. */
	String COURT_INQUIRY_BUSINESS_PROCESS = "COURTINQUIRY";
	/** The DA f_ men u_ busines s_ process. */
	String DAF_MENU_BUSINESS_PROCESS = "DAF";
	/** The DC s_ men u_ busines s_ process. */
	String DCS_MENU_BUSINESS_PROCESS = "DCSMENU";
	/** The DL inquiry business Process. */
	String DL_INQUIRY_BUSINESS_PROCESS = "DLInquiry";
	/** The D l_ men u_ busines s_ process. */
	String DL_MENU_BUSINESS_PROCESS = "DLMENU";
	/** The 70U menu business process. */
	String DLC_MENU_BUSINESS_PROCESS = "70U";
	/** The TO p_ busines s_ process. */
	String TOP_BUSINESS_PROCESS = "TOP_BUSINESS_PROCESS";
	/** The DL_ busines s_ process. */
	String DL_BUSINESS_PROCESS = "DL";
	/** The ID_ busines s_ process. */
	String ID_BUSINESS_PROCESS = "ID";
	/** The DRT_ ttc. */
	String DRT_TTC = "DRT";
	/** The IRT_ ttc. */
	String IRT_TTC = "IRT";

	/**
	 * Add business process.
	 * 
	 * @param businessProcess the business process
	 */
	public void addProcess(BusinessProcess businessProcess);

	/**
	 * Gets the BusinessProcess object based on id.
	 * 
	 * @param businessProcessId the business process id
	 * 
	 * @return BusinessProcess
	 */
	public BusinessProcess getProcess(String businessProcessId);

	/**
	 * Gets the BusinessProcess object for a given transaction.
	 * 
	 * @param businessProcessId the tcode that identifies the transaction
	 * 
	 * @return BusinessProcess
	 */
	public BusinessProcess getProcessForTransaction(String tcode);

	/**
	 * Remove business process.
	 * 
	 * @param key the key
	 */
	public void removeProcess(String key);
}
/**
 * Modification History:
 * 
 * $Log: IProcessRegistry.java,v $
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.11  2010/09/23 18:11:03  mwsyk1
 * remove getProcessByTtc
 *
 * Revision 1.10  2010/09/23 16:12:35  mwyxg1
 * change DRT, IRT constant names
 *
 * Revision 1.9  2010/09/23 16:00:44  mwyxg1
 * add getProcessByTtc
 *
 * Revision 1.8  2010/09/22 00:08:17  mwyxg1
 * change DL to DLMENU, DL will be used for all the DL ttcs
 *
 * Revision 1.7  2010/09/03 16:59:15  mwsec2
 * getProcessForTransaction method added
 *
 * Revision 1.6  2010/07/08 02:00:56  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.5  2010/06/21 23:00:49  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.3.10.3  2010/06/20 18:07:00  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.4  2010/06/15 23:07:10  mwgxd3
 * add 70U
 *
 * Revision 1.3.10.2  2010/06/08 03:09:30  mwakg
 * Added support for 07Q to test process switching
 *
 * Revision 1.3.10.1  2010/06/08 01:18:27  mwakg
 * Added Transitions to SubBusinessProcess
 *
 * Revision 1.3  2010/04/22 19:08:36  mwpxp2
 * Added javadoc, todo
 *
 * Revision 1.2  2010/04/04 23:29:34  mwakg
 * Changed ProcessRegistry variable to private and made a getter method for it
 *
 * Revision 1.1  2010/04/01 00:11:44  mwakg
 * Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 * 
 */
