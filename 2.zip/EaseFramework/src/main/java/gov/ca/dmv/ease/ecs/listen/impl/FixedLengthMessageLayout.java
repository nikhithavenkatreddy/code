/**
 * 
 */
package gov.ca.dmv.ease.ecs.listen.impl;



/**
 * Description: Abstract class for fixed length message layouts.
 * 
 * File: FixedLengthMessageLayout.java
 * Module:  gov.ca.dmv.ease.ecs.listen.impl
 * Created: Oct 19, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class FixedLengthMessageLayout {
	
	/**
	 * Helper method for setting the offsets of the message fields
	 * 
	 * @param fields
	 */
	protected void initFields(MessageField[] fields) {
		for (int i = 0, offset = 0; i < fields.length; ++i) {
			MessageField field = fields[i];
			fields[i].setOffset(offset);
			offset += field.getLength();
		}
	}
	
	/**
	 * returns the requested field from the given message string
	 * 
	 * @param messageString
	 * @param field
	 * @return
	 */
	protected String getFieldValue(String messageString, MessageField field) {
		return messageString.substring(
				field.getOffset(), 
					field.getOffset() + 
						field.getLength()).
							trim();
	}
}


/**
 *  Modification History:
 *
 *  $Log: FixedLengthMessageLayout.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/04/17 22:26:38  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/03/30 21:11:59  mwsec2
 *  comments added
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:09  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */
