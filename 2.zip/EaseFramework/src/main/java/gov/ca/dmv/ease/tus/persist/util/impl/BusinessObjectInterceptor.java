/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.util.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

/**
 * Description: This class is used to update the audit trail fields (createdDate, 
 * modifiedDate, createdBy, modifiedBy) of the business objects.
 * 
 * File: DomainObjectInterceptor.java
 * Module:  gov.ca.dmv.ease.tus.persist.util.impl
 * Created: May 7, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BusinessObjectInterceptor extends EmptyInterceptor {
	/** The Constant CREATED_BY. */
	private static final String CREATED_BY = "createdBy";
	/** The Constant CREATED_DATE. */
	private static final String CREATED_DATE = "createdDate";
	/** The Constant MODIFIED_BY. */
	private static final String MODIFIED_BY = "modifiedBy";
	/** The Constant MODIFIED_DATE. */
	private static final String MODIFIED_DATE = "modifiedDate";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5569842226406197472L;
	/** The Variable CREATED and MODIFIED BY. */
	private String createdBy = "admin";
	private String modifiedBy = "admin";

	/**
	 * Called when an object is detected to be dirty, during a flush. The interceptor may modify the detected currentState, which will be
	 * propagated to both the database and the persistent object. Note that not all flushes end in actual synchronization with the database,
	 * in which case the new currentState will be propagated to the object, but not necessarily (immediately) to the database.
	 * It is strongly recommended that the interceptor not modify the previousState.
	 * 
	 * @param entity the entity
	 * @param id the id
	 * @param currentState the current state
	 * @param previousState the previous state
	 * @param propertyNames the property names
	 * @param types the types
	 * 
	 * @return true, if on flush dirty
	 */
	@Override
	public boolean onFlushDirty(Object entity, Serializable id,
			Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		if (entity instanceof IBusinessObject) {
			if (entity instanceof AbstractLog) {
				modifiedBy = ((AbstractLog) entity).getPrincipalId();
			}
			for (int i = 0; i < propertyNames.length; i++) {
				if (MODIFIED_DATE.equalsIgnoreCase(propertyNames[i])) {
					currentState[i] = new Date();
				}
				else if (MODIFIED_BY.equals(propertyNames[i])) {
					if (EaseUtil.isNullOrBlank(currentState[i])) {
						//state[i] = Set the created user principle here;
						currentState[i] = modifiedBy;
					}
				}
			}
		}
		return true;
	}

	/**
	 * Called before an object is saved. The interceptor may modify the state, which will be used for the SQL INSERT
	 * and propagated to the persistent object.
	 * 
	 * @param entity the entity
	 * @param id the id
	 * @param state the state
	 * @param propertyNames the property names
	 * @param types the types
	 * 
	 * @return true, if on save
	 */
	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		if (entity instanceof IBusinessObject) {
			if (entity instanceof AbstractLog) {
				createdBy = ((AbstractLog) entity).getPrincipalId();
			}
			for (int i = 0; i < propertyNames.length; i++) {
				if (MODIFIED_DATE.equals(propertyNames[i])
						|| CREATED_DATE.equals(propertyNames[i])) {
					state[i] = new Date();
				}
				else if (CREATED_BY.equals(propertyNames[i])
						|| MODIFIED_BY.equals(propertyNames[i])) {
					if (EaseUtil.isNullOrBlank(state[i])) {
						//state[i] = Set the created user principle here;
						state[i] = createdBy;
					}
				}
			}
		}
		return true;
	}
}
/**
 * Modification History:
 * 
 * $Log: BusinessObjectInterceptor.java,v $
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.6  2010/12/02 00:14:58  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.5  2010/11/04 16:59:02  mwkfh
 * updated so the date is always reset
 *
 * Revision 1.4  2010/11/03 16:28:10  mwkfh
 * updated to only set value if values are null or blank
 *
 * Revision 1.3  2010/03/22 23:39:08  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2009/12/15 01:29:53  mwvxm6
 * Fix to update created and modified by fields.
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.5  2009/10/03 21:32:45  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.4  2009/09/16 00:23:51  mwrsk
 * Change to use IBusinessObject
 *
 * Revision 1.3  2009/08/27 06:29:21  mwpxp2
 * Fixed imports for fw migration to compile; bulk cleanup
 *
 * Revision 1.2  2009/08/11 20:12:46  mwrsk
 * Code cleanup - Use constants & provide class description
 *
 * Revision 1.1  2009/07/29 16:57:01  mwakg
 * Changed the design of persistence service hence refractored code accordingly
 *
 * Revision 1.2  2009/07/21 21:45:35  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.1  2009/07/15 00:59:44  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.1  2009-07-11 17:34:02  mwpxp2
 * Moved to .impl package; cleaned up comments and javadoc; added todos
 *
 * Revision 1.1  2009-07-10 07:13:57  mwpxp2
 * Synch
 * Revision 1.1 May 7, 2009 5:27:39 PM MWAKG
 * Initial commit
 * 
 */
