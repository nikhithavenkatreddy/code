/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service.impl;

import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.MANUAL;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.TRAVEL_CREW;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.fw.exception.impl.EasePersistenceServiceException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.impl.CashierTransactionIdRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleDeleteBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleInsertOrUpdateRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MultipleRetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.PurgeTableRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveAllBusinessObjectsRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveInventoryItemAndUpdateAsIssuedRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SaveOrUpdateBusinessObjectRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.CashierTransactionIdResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleDeleteBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleInsertOrUpdateResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleRetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PurgeTableResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveAllBusinessObjectsResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveCriteriaObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveInventoryItemAndUpdateAsIssuedResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SaveOrUpdateBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;

/**
 * Description: I provide methods that used to save, retrieve, update and delete
 * business objects to/from the persistence store
 * File: PersistenceService.java 
 * Module: gov.ca.dmv.ease.tus.persist.service.impl 
 * Created: Apr 30, 2009
 * @author MWAKG
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2012/10/23 23:39:07 $ 
 * Last Changed By: $Author: mwkfh $
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2012/10/23 23:39:07 $ 
 * Last Changed By: $Author: mwkfh $
 */
public class PersistenceService implements IPersistenceService {
	private static final String HIBERNATE_CONFIG_FILE = "/src/main/resources/hibernate.cfg.xml";
	//private static String HIBERNATE_CONFIG_FILE = "classpath:hibernate.cfg.xml";
	private static final String HIBERNATE_EXT = ".hbm.xml";
	private static final String HIBERNATE_HBM_XML_DIR = "hibernate-xml-mapping";
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(PersistenceService.class);

	protected static Configuration createHibernateConfiguration() {
		ClassLoader aLoader = ClassLoader.getSystemClassLoader();
		URL aConfigUrl = aLoader.getResource(HIBERNATE_CONFIG_FILE);
		URL aConfigUrl2 = aLoader.getResource("/hibernate.cfg.xml");
		Configuration aCfg = new Configuration();
		aCfg.configure(aConfigUrl); //configuration file
		File aDir = new File(HIBERNATE_CONFIG_FILE, HIBERNATE_HBM_XML_DIR);
		createHibernateConfiguration(aDir, aCfg);
		return aCfg;
	}

	protected static void createHibernateConfiguration(File aHbmXmlDir,
			Configuration aCfg) {
		File[] aFileArr = aHbmXmlDir.listFiles();
		File aFile;
		for (File element : aFileArr) {
			aFile = element;
			if (aFile.getName().endsWith(HIBERNATE_EXT)) {
				aCfg.addResource(aFile.getAbsolutePath());
			}
		}
	}

	protected static SessionFactory createSessionFactoryFromConfig() {
		return createHibernateConfiguration().buildSessionFactory();
		//		LocalSessionFactoryBean aBean = new LocalSessionFactoryBean();
		//		 Resource aConfigResource = new ClassPathResource("classpath:test-hibernate.cfg.xml");
		//		aBean.setConfigLocation(aConfigResource);
		//		return aBean.buildSessionFactory() ;
	}

	protected static File getHibernateConfigFile() {
		return new File(HIBERNATE_CONFIG_FILE);
	}

	/**
	 * Gets the single instance of PersistenceService.
	 *
	 * @return single instance of PersistenceService
	 */
	public static PersistenceService getInstance() {
		return new PersistenceService();
	}

	protected static Properties loadHibernateProperties() {
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(HIBERNATE_CONFIG_FILE));
			return properties;
		}
		catch (IOException e) {
			throw new EasePersistenceServiceException("Loading from \""
					+ HIBERNATE_CONFIG_FILE + "\" failed.", e);
		}
	}

	/** The session factory. */
	private transient SessionFactory sessionFactory; //Spring injected

	/**
	 * Instantiates a new persistence service.
	 */
	protected PersistenceService() {
		super();
	}

	/**
	 * Starts the transaction
	 */
	public void beginTransaction() {
		getSessionFactory().getCurrentSession().beginTransaction();
	}

	/**
	 * Commits the transaction
	 */
	public void commitTransaction() {
		getSessionFactory().getCurrentSession().getTransaction().commit();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.CashierTransactionIdRequest)
	 */
	public CashierTransactionIdResponse execute(
			CashierTransactionIdRequest aRequest) {
		//TODO - not finished - requires employeeWorkDateControls to be moved to arch to avoid reflection acrobatics
		Integer aSequenceNoIncremented = 0;
		Integer aSequenceNoRead;
		IUserContext userContext = aRequest.getUserContext();
		Class <?> aClass;
		try {
			aClass = Class.forName(CashierTransactionIdRequest
					.getBusinessObjectClassName());
		}
		catch (ClassNotFoundException e) {
			return new CashierTransactionIdResponse(
					new EaseValidationException(e));
		}
		Criteria criteria = getSessionFactory().getCurrentSession()
				.createCriteria(aClass, "ewc").createCriteria("ewc.employee",
						"emp").add(
						Restrictions.eq("emp.employeeTechId", userContext
								.getTechId())).createCriteria(
						"ewc.officeWorkdate", "offWd").createCriteria(
						"offWd.office", "off").add(
						Restrictions.eq("offWd.authorizedWorkDate", userContext
								.getWorkDate())).add(
						Restrictions.eq("offWd.status", "A")).add(
						Restrictions.eq("off.officeId", userContext
								.getOfficeId())).add(
						Restrictions.eq("ewc.status", "A"));
		List <IBusinessObject> retrievedList = criteria.list();
		List <IBusinessObject> employeeWorkDateControls = retrievedList;
		LOGGER.info("For Tech Id:" + userContext.getTechId() + " Office Id:"
				+ userContext.getOfficeId() + " and Work Date:"
				+ userContext.getWorkDate()
				+ ", Total number of active employee workdate control records:"
				+ employeeWorkDateControls.size());
		IBusinessObject employeeWorkDateControl = null;
		if (employeeWorkDateControls != null
				&& employeeWorkDateControls.size() > 0) {
			employeeWorkDateControl = employeeWorkDateControls.get(0);
			if (userContext.getOperationalMode().equals(TRAVEL_CREW)
					|| userContext.getOperationalMode().equals(MANUAL)) {
				aSequenceNoRead = Integer.valueOf(employeeWorkDateControl
						.getIntegerValueNamed("currentDlMtSequenceNumber"));
				aSequenceNoIncremented = aSequenceNoRead + 1;
			}
			else {
				//				getCurrentDlSequenceNumber
				aSequenceNoRead = Integer.valueOf(employeeWorkDateControl
						.getIntegerValueNamed("currentDlSequenceNumber"));
			}
			aSequenceNoIncremented = aSequenceNoRead + 1;
			//employeeWorkDateControl		.setCurrentDlSequenceNumber(aSequenceNoIncremented); //FIXME
			getSessionFactory().getCurrentSession().update(
					employeeWorkDateControl);
		}
		commitTransaction();
		return new CashierTransactionIdResponse(aSequenceNoIncremented);
	}

	/**
	 * This method deletes the domain object from the database.
	 * 
	 * @param request
	 *            Request containing the domain object to be deleted
	 * 
	 * @return Response containing status of the deletion operation
	 */
	public DeleteBusinessObjectResponse execute(
			DeleteBusinessObjectRequest request) {
		try {
			IBusinessObject domainObject = request.getBusinessObject();
			executeDeleteBusinessObject(domainObject);
			return new DeleteBusinessObjectResponse();
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new DeleteBusinessObjectResponse(ex);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.MultipleInsertOrUpdateRequest)
	 */
	public MultipleDeleteBusinessObjectResponse execute(
			MultipleDeleteBusinessObjectRequest request) {
		try {
			List <IBusinessObject> domainObjects = (List <IBusinessObject>) request
					.getBusinessObjects();
			executeMultiDeleteBusinessObjects(domainObjects);
			return new MultipleDeleteBusinessObjectResponse();
		}
		catch (Exception e) {
			LOGGER.error(e);
			return new MultipleDeleteBusinessObjectResponse(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.MultipleInsertOrUpdateRequest)
	 */
	public MultipleInsertOrUpdateResponse execute(
			MultipleInsertOrUpdateRequest request) {
		try {
			List <IBusinessObject> domainObjects = (List <IBusinessObject>) request
					.getBusinessObjects();
			executeMultiInsertOrUpdateBusinessObjects(domainObjects);
			return new MultipleInsertOrUpdateResponse(domainObjects.size());
		}
		catch (Exception e) {
			LOGGER.error(e);
			return new MultipleInsertOrUpdateResponse(e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.MultipleRetrieveBusinessObjectRequest)
	 */
	public MultipleRetrieveBusinessObjectResponse execute(
			MultipleRetrieveBusinessObjectRequest request) {
		try {
			List <IBusinessObject> domainObjects = (List <IBusinessObject>) request
					.getBusinessObjects();
			List <IBusinessObject> results = retrieveMultipleBusinessObjects(domainObjects);
			return new MultipleRetrieveBusinessObjectResponse(results);
		}
		catch (Exception e) {
			LOGGER.error(e);
			return new MultipleRetrieveBusinessObjectResponse(e);
		}
	}

	/**
	 * This method deletes the domain object from the database.
	 * 
	 * @param request
	 *            Request containing the table class to be purged
	 * 
	 * @return Response containing status of the purge operation
	 */
	public PurgeTableResponse execute(PurgeTableRequest request) {
		try {
			return new PurgeTableResponse(executePurgeTable(request
					.getClassToPurge(), request.getCreatedBefore()));
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new PurgeTableResponse(ex);
		}
	}

	/**
	 * This method returns all the instances of a domain object.
	 * 
	 * @param request
	 *            Request object containing the domain object class
	 * 
	 * @return Response object containing the instances of domain object
	 */
	@SuppressWarnings("unchecked")
	public RetrieveAllBusinessObjectsResponse execute(
			RetrieveAllBusinessObjectsRequest request) {
		try {
			beginTransaction();
			try {
				Criteria criteria = getSessionFactory().getCurrentSession()
						.createCriteria(request.getBusinessObjectClass())
						.setResultTransformer(
								CriteriaSpecification.DISTINCT_ROOT_ENTITY);
				RetrieveAllBusinessObjectsResponse allDomainObjectsResponse = new RetrieveAllBusinessObjectsResponse(
						criteria.list());
				commitTransaction();
				return allDomainObjectsResponse;
			}
			catch (HibernateException e) {
				rollbackTransaction();
				return new RetrieveAllBusinessObjectsResponse(e);
			}
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new RetrieveAllBusinessObjectsResponse(ex);
		}
	}

	/**
	 * This method retrieves the domain objects from the database based on the
	 * request object This method uses Query by example pattern of hibernate.
	 * 
	 * @param request
	 *            Request containing the parameters requiring for retrieving a
	 *            domain object
	 * 
	 * @return Response containing the retrieved domain object
	 */
	public RetrieveBusinessObjectResponse execute(
			RetrieveBusinessObjectRequest request) {
		try {
			List <IBusinessObject> aList = retrieveBusinessObject(request
					.getBusinessObject());
			return new RetrieveBusinessObjectResponse(aList);
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new RetrieveBusinessObjectResponse(ex);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca.dmv.ease.tus.persist.request.impl.RetrieveCriteriaObjectRequest)
	 */
	public RetrieveCriteriaObjectResponse execute(
			RetrieveCriteriaObjectRequest request) {
		try {
			Criteria criteria = getSessionFactory().getCurrentSession()
					.createCriteria(request.getBusinessObjectClass());
			return new RetrieveCriteriaObjectResponse(criteria);
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new RetrieveCriteriaObjectResponse(ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.tus.persist.service.IPersistenceService#execute(gov.ca
	 * .dmv.ease.tus.persist.request.impl.RetrieveDlInventoryItemRequest)
	 */
	@SuppressWarnings("unchecked")
	public RetrieveInventoryItemAndUpdateAsIssuedResponse execute(
			RetrieveInventoryItemAndUpdateAsIssuedRequest request) {
		try {
			if ((request.getInventoryItem() == null)
					|| (request.getInventoryItem().getIssued() == true)) {
				return new RetrieveInventoryItemAndUpdateAsIssuedResponse(
						new ApplicationException(
								"Either inventory item is null or isIssued is set to false"));
			}
			IInventoryItemRetrievable inventoryItem = request
					.getInventoryItem();
			List <IBusinessObject> aList = retrieveBusinessObject(inventoryItem);
			if (aList.size() > 0) {
				IInventoryItemRetrievable anInventoryItem = (IInventoryItemRetrievable) aList
						.get(0);
				anInventoryItem.setIssued(true);
				anInventoryItem.setIssuedDate(new Date());
				// Need to update the issued inventory with Office and Employee details:
				// For time being, just updating the inventory with tech Id, TTC and Issued date.
				anInventoryItem.setModifiedBy(request.getUserContext()
						.getTechId());
				anInventoryItem.setTypeTransactionCode(request.getUserContext()
						.getTtc());
				executeSaveOrUpdateBusinessObject(anInventoryItem);
				return new RetrieveInventoryItemAndUpdateAsIssuedResponse(
						anInventoryItem);
			}
			return new RetrieveInventoryItemAndUpdateAsIssuedResponse();
		}
		catch (Exception e) {
			LOGGER.error(e);
			return new RetrieveInventoryItemAndUpdateAsIssuedResponse(e);
		}
	}

	/**
	 * This method saves or updates the complete domain object and its children.
	 * 
	 * @param request
	 *            Request object containing the domain object to be saved
	 * 
	 * @return Response containing the saved domain object and its response
	 */
	public SaveOrUpdateBusinessObjectResponse execute(
			SaveOrUpdateBusinessObjectRequest request) {
		try {
			IBusinessObject domainObject = request.getBusinessObject();
			executeSaveOrUpdateBusinessObject(domainObject);
			return new SaveOrUpdateBusinessObjectResponse();
		}
		catch (Exception e) {
			LOGGER.error(e);
			return new SaveOrUpdateBusinessObjectResponse(e);
		}
	}

	/**
	 * Deletes a business object
	 * 
	 * @param domainObject
	 *            the domain object
	 */
	protected void executeDeleteBusinessObject(IBusinessObject domainObject) {
		beginTransaction();
		try {
			getSessionFactory().getCurrentSession().delete(domainObject);
			commitTransaction();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Deletes business objects
	 * 
	 * @param List of domainObjects
	 *            the domain objects
	 */
	private void executeMultiDeleteBusinessObjects(
			List <IBusinessObject> domainObjects) {
		beginTransaction();
		try {
			for (IBusinessObject domainObject : domainObjects) {
				getSessionFactory().getCurrentSession().delete(domainObject);
			}
			commitTransaction();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Saves business objects or updates already saved business
	 * objects
	 * 
	 * @param List of domainObjects
	 *            the domain objects
	 */
	private void executeMultiInsertOrUpdateBusinessObjects(
			List <IBusinessObject> domainObjects) {
		beginTransaction();
		try {
			for (IBusinessObject domainObject : domainObjects) {
				getSessionFactory().getCurrentSession().saveOrUpdate(
						domainObject);
			}
			commitTransaction();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Purges a table for a class
	 * 
	 * @param class the table class
	 * @param optional create date
	 * @return affectedRows
	 */
	protected int executePurgeTable(Class <?> tableClass, Date createdBefore) {
		int affectedRows = 0;
		beginTransaction();
		try {
			String query = "DELETE FROM " + tableClass.getName();
			if (createdBefore != null) {
				query += " WHERE createdDate < ?";
			}
			Query purgeQuery = getSessionFactory().getCurrentSession()
					.createQuery(query);
			if (createdBefore != null) {
				purgeQuery.setTimestamp(0, createdBefore);
			}
			affectedRows = purgeQuery.executeUpdate();
			commitTransaction();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
		return affectedRows;
	}

	/**
	 * Saves a transient business object or update an already saved business
	 * object
	 * 
	 * @param domainObject
	 *            the domain object
	 */
	protected void executeSaveOrUpdateBusinessObject(
			IBusinessObject domainObject) {
		beginTransaction();
		try {
			getSessionFactory().getCurrentSession().saveOrUpdate(domainObject);
			commitTransaction();
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * @return the sessionFactory
	 */
	public SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			if (EaseApplicationContext.getApplicationContext() == null) {
				setSessionFactory(createSessionFactoryFromConfig());
			}
			else {
				setSessionFactory((SessionFactory) EaseApplicationContext
						.getApplicationContext().getBean("sessionFactory"));
			}
		}
		return sessionFactory;
	}

	/**
	 * Retrieve business object from the database based on the request object
	 * This method uses Query by example pattern of hibernate
	 * 
	 * @param Obj
	 *            the obj
	 * 
	 * @return the list
	 */
	@SuppressWarnings("unchecked")
	private List <IBusinessObject> retrieveBusinessObject(IBusinessObject Obj) {
		beginTransaction();
		try {
			Criteria criteria = getSessionFactory().getCurrentSession()
					.createCriteria(Obj.getClass()).setResultTransformer(
							CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			criteria.add(Example.create(Obj));
			List <IBusinessObject> aList = criteria.list();
			commitTransaction();
			return aList;
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Retrieve business objects from the database based on the request objects
	 * This method uses Query by example pattern of hibernate
	 * 
	 * @param List <IBusinessObject>
	 *            the objects
	 * 
	 * @return the list
	 */
	@SuppressWarnings("unchecked")
	private List <IBusinessObject> retrieveMultipleBusinessObjects(
			List <IBusinessObject> objects) {
		beginTransaction();
		try {
			List <IBusinessObject> aList = new ArrayList <IBusinessObject>();
			for (IBusinessObject object : objects) {
				Criteria criteria = getSessionFactory().getCurrentSession()
						.createCriteria(object.getClass())
						.setResultTransformer(
								CriteriaSpecification.DISTINCT_ROOT_ENTITY);
				criteria.add(Example.create(object));
				aList.addAll(criteria.list());
			}
			commitTransaction();
			return aList;
		}
		catch (HibernateException e) {
			LOGGER.error(e);
			rollbackTransaction();
			throw new ApplicationException(e);
		}
	}

	/**
	 * Rolls back the transaction
	 */
	public void rollbackTransaction() {
		getSessionFactory().getCurrentSession().getTransaction().rollback();
	}

	/**
	 * @param sessionFactory the sessionFactory to set
	 */
	public void setSessionFactory(SessionFactory aFactory) {
		//Spring injection only
		sessionFactory = aFactory;
	}
}
/**
 * Modification History:
 * 
 * $Log: PersistenceService.java,v $
 * Revision 1.2  2012/10/23 23:39:07  mwkfh
 * added execute(PurgeTableRequest)
 *
 * Revision 1.1  2012/10/01 02:57:32  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.44  2012/08/15 23:17:42  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.43  2012/08/14 20:34:39  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.42  2012/08/08 20:08:55  mwkfh
 * removed execute(CurrentDateRequest)
 *
 * Revision 1.41  2012/03/13 02:06:53  mwkkc
 * Clean up - Defect 7295 and 7296
 *
 * Revision 1.40  2012/03/05 22:16:13  mwkkc
 * work around
 *
 * Revision 1.39  2012/01/03 17:50:18  mwhys
 * Updated execute(CurrentDateRequest) to return null in production and
 * 11/15/11 in test environment. (Defect 1123)
 *
 * Revision 1.38  2011/10/12 20:58:12  mwkkc
 * Performance Merge
 *
 * Revision 1.37.8.3  2011/09/27 23:59:37  mwpxp2
 * Fixed execute on CurrentDateRequest to use usercontext in the request
 *
 * Revision 1.37.8.2  2011/09/26 23:33:53  mwpxp2
 * Javadoc/comments cleanup
 *
 * Revision 1.37.8.1  2011/09/26 05:25:04  mwpxp2
 * Added static getInstance/0
 *
 * Revision 1.37  2011/07/01 23:57:09  mwkfh
 * refactored executeDeleteBusinessObject and made a couple methods protected for use in LocalPersistenceService
 *
 * Revision 1.36  2010/12/28 21:32:17  mwkfh
 * updated RetrieveCriteriaObjectRequest to handle transaction outside of persistence service
 *
 * Revision 1.35  2010/12/28 19:32:52  mwkfh
 * enabled rollback in RetrieveCriteriaObjectRequest
 *
 * Revision 1.34  2010/12/28 19:31:56  mwkfh
 * removed commit and rollback from criteria request
 *
 * Revision 1.33  2010/12/28 19:18:17  mwkfh
 * added/verified commits and rollbacks for every transactions
 *
 * Revision 1.32  2010/12/28 19:02:16  mwkfh
 * removed begin transaction from execute(RetrieveCriteriaObjectRequest)
 *
 * Revision 1.31  2010/12/23 06:10:40  mwkkc
 * Merged Production code from Branch
 *
 * Revision 1.27.2.2  2010/12/23 01:29:49  mwkkc
 * Rebase from head - Arch
 *
 * Revision 1.30  2010/12/22 21:58:57  mwuxb
 * Updated work date in CurrentDateResponse execute(CurrentDateRequest currentDateRequest)
 *
 * Revision 1.29  2010/12/22 02:00:26  mwuxb
 * Updated stub for CurrentDateResponse execute(CurrentDateRequest currentDateRequest) to provide future system date.
 *
 * Revision 1.28  2010/12/22 01:12:25  mwuxb
 * Updated stub for CurrentDateResponse execute(CurrentDateRequest currentDateRequest) to provide future system date for testing purpose.
 *
 * Revision 1.27  2010/12/16 19:49:58  mwpxp2
 * Added stub for CurrentDateResponse execute(CurrentDateRequest currentDateRequest)
 *
 * Revision 1.26  2010/12/15 03:02:34  mwpxp2
 * Added execute on CashierTransactionIdRequest - not finished
 *
 * Revision 1.25  2010/10/13 17:13:26  mwpxp2
 * Modified to include the affected item count in multiple insert or update response
 *
 * Revision 1.24  2010/10/06 16:32:42  mwkfh
 * added MultipleRetrieveBusinessObject...
 *
 * Revision 1.23  2010/09/23 16:27:10  mwkfh
 * cleaned up merge messed up comments
 *
 * Revision 1.22  2010/09/22 19:12:29  mwkfh
 * removed executeDeleteMultipleBusinessObjects
 *
 * Revision 1.21  2010/09/21 21:37:38  mwpxr4
 * Removed duplicate method deleting multiple business objects.
 *
 * Revision 1.20  2010/09/21 18:55:51  mwpxr4
 * Merged branch mwkkc_ecs_persistance into HEAD.
 *
 * Revision 1.19  2010/09/15 18:04:03  mwkfh
 * added MultipleDeleteBusinessObjects
 *
 * Revision 1.18  2010/09/14 00:40:33  mwkfh
 * made persistenceService non-static
 *
 * Revision 1.17.4.2  2010/09/14 17:39:14  mwpxr4
 * Added code to delete the processed payloads for a promise.
 *
 * Revision 1.17.4.1  2010/09/14 16:15:04  mwpxr4
 * Removed compilation errors from branch by taking latest from head
 *
 * Revision 1.18  2010/09/14 00:40:33  mwkfh
 * made persistenceService non-static
 *
 * Revision 1.17  2010/09/13 16:52:15  mwkfh
 * removed SeedPersistence for inventory
 *
 * Revision 1.16  2010/09/13 04:39:47  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.15  2010/09/10 22:06:12  mwkfh
 * updated SeedPersistence
 *
 * Revision 1.14  2010/09/09 22:04:56  mwkfh
 * finished MultipleInsertOrUpdateRequest and updated response
 *
 * Revision 1.13  2010/09/01 20:01:21  mwpxp2
 * Added stubs  for SeedPersistenceRequest and MultipleInsertOrUpdateRequest
 *
 * Revision 1.12  2010/09/01 19:07:00  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.11  2010/07/23 23:11:57  mwkfh
 * removed outdated ProcessContext persistence
 *
 * Revision 1.10  2010/07/23 20:59:00  mwkfh
 * updated RetrieveCriteriaObjectResponse() to catch and add the exception to the response.
 *
 * Revision 1.9  2010/07/08 02:04:41  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.8  2010/05/10 18:01:41  mwakg
 * Logging exceptions from PersistenceService
 *
 * Revision 1.7  2010/04/22 19:27:03  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.6  2010/03/27 23:58:13  mwakg
 * Removed usage of HibernateSessionFactory and setting sessionfactory from spring
 *
 * Revision 1.5  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.4  2010/03/24 16:47:39  mwyxg1
 * add retrieve criteria object support
 *
 * Revision 1.3  2010/03/23 21:14:55  mwyxg1
 * add criteria support
 *
 * Revision 1.2  2010/03/22 23:39:08  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.38  2009/10/07 21:09:31  mwrsk
 * Deleted LoggingRequest.java
 *
 * Revision 1.37  2009/10/03 21:32:49  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.36  2009/09/03 22:49:29  mwrsk
 * Delete save business object request
 *
 * Revision 1.35  2009/09/03 21:57:34  mwrsk
 * RestoreProcessContextRequest now takes a byte array instead of IProcessContext
 *
 * Revision 1.34  2009/09/03 21:25:03  mwrsk
 * SaveProcessContextRequest now takes a byte array instead of IProcessContext
 *
 * Revision 1.33  2009/09/03 18:20:04  mwrsk
 * Added the missing commit
 *
 * Revision 1.32  2009/09/03 18:18:08  mwrsk
 * Added the missing commit
 *
 * Revision 1.31  2009/08/31 17:08:26  mwbxp5
 * Added history to the issued inventory:
 * Revision 1.30 2009/08/31 01:23:53 mwrsk
 * Added SaveBusinessObject functionality
 * 
 * Revision 1.29 2009/08/29 00:21:31 mwrsk Remove compile errors
 * 
 * Revision 1.28 2009/08/29 00:06:04 mwrsk Refactor SaveBusinessObject request
 * to SaveOrUpdate....
 * 
 * Revision 1.27 2009/08/28 23:34:44 mwrsk Refactor SaveBusinessObject request
 * to SaveOrUpdate
 * 
 * Revision 1.26 2009/08/27 20:49:08 mwsmg6 corrected exception type
 * 
 * Revision 1.25 2009/08/27 06:29:25 mwpxp2 Fixed imports for fw migration to
 * compile; bulk cleanup
 * 
 * Revision 1.24 2009/08/27 03:42:08 mwsmg6 moved framework-related classes to
 * the Framework project
 * 
 * Revision 1.23 2009/08/27 00:20:26 mwrsk Persistence Service API's now always
 * return a response (even when an exception happens)
 * 
 * Revision 1.22 2009/08/26 23:12:59 mwrsk DeleteBusinessObjectResponse ()
 * implements error collector
 * 
 * Revision 1.21 2009/08/26 22:32:13 mwrsk Code cleanup
 * 
 * Revision 1.20 2009/08/26 21:00:51 mwrsk Renamed the response class to match
 * the request
 * 
 * Revision 1.19 2009/08/25 18:26:49 mwsmg6 replaced getSessionContext with
 * getRootContext
 * 
 * Revision 1.18 2009/08/25 16:34:20 mwrsk Changed the request name to
 * RetrieveInventoryItemAndUpdateAsIssuedRequest
 * 
 * Revision 1.17 2009/08/25 16:10:46 mwrsk cleanup imports
 * 
 * Revision 1.16 2009/08/25 16:05:40 mwrsk Updated to retrieve anyInventoryItem
 * 
 * Revision 1.15 2009/08/25 01:56:33 mwrsk Added new API for retrieving DL
 * Inventory Item
 * 
 * Revision 1.14 2009/08/21 01:32:53 mwrsk Implemented save & retrieve process
 * context related methods
 * 
 * Revision 1.13 2009/08/21 00:47:35 mwsxd10 execute() method added for
 * processing LoggingRequest.
 * 
 * Revision 1.12 2009/08/18 00:46:34 mwrsk Do rollback when exception occurs
 * 
 * Revision 1.11 2009/08/18 00:34:06 mwrsk Wrap DeleteBusinessObject in a
 * transaction
 * 
 * Revision 1.10 2009/08/17 23:37:30 mwrsk Added DISTINCT_ROOT_ENTITY
 * CriteriaSpecification
 * 
 * Revision 1.9 2009/08/13 03:22:36 mwrsk Remove transaction service related
 * request
 * 
 * Revision 1.8 2009/08/11 20:16:33 mwrsk Suppress warnings
 * 
 * Revision 1.7 2009/08/10 15:54:22 mwrsk Added DISTINCT_ROOT_ENTITY to
 * retrieveAllBusinessObjectsResponse()
 * 
 * Revision 1.6 2009/08/06 21:28:57 mwakg Merging from
 * MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 * 
 * Revision 1.5.2.1 2009/08/06 16:25:17 mwakg Changed the design of
 * PersistenceService. Instead of working with BusinessObject PersistenceService
 * is now working with IBusinessObject
 * 
 * Revision 1.5 2009/08/05 20:39:54 mwrsk Refactored code to make persistence
 * service work
 * 
 * Revision 1.4 2009/07/30 17:17:11 mwakg Refactored all setter methods in
 * responses of the PersistenceService to private methods.
 * 
 * Revision 1.3 2009/07/29 16:57:00 mwakg Changed the design of persistence
 * service hence refractored code accordingly
 * 
 * Revision 1.2 2009/07/21 21:45:35 mwpxp2 Bulk cleanup
 * 
 * Revision 1.1 2009/07/15 00:59:44 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.2 2009-07-12 18:18:12 mwpxp2 Lost superclass
 * 
 * Revision 1.1 2009-07-11 17:32:52 mwpxp2 Moved to .impl package; cleaned up
 * comments and javadoc; added todos
 * 
 * Revision 1.1 2009-07-10 07:13:57 mwpxp2 Synch Revision 1.1 Apr 30, 2009
 * 10:25:03 AM MWAKG Initial commit
 * 
 */
