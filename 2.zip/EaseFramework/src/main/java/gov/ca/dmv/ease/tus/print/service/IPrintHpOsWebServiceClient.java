/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.service;

import gov.ca.dmv.ease.bo.app.impl.Location;

/**
 * Description: This is interface to Web Service for HP Output Server.
 * This interface provides various Printing related methods. 
 * File: IPrintHpOsWebServiceClient.java
 * Module:  gov.ca.dmv.ease.tus.print.service
 * Created: May 4, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPrintHpOsWebServiceClient {
	/**
	 * This method cancels the Print Job on HP Output Server.
	 * 
	 * @param jobClientId the Job Client Id
	 * 
	 * @return the Cancel Print Job Status
	 */
	String cancelPrintJob(String jobClientId);

	/**
	 * This method delivers a single document with job attributes and document attributes
	 * in a single Web Service request to HP Output Server to Print.
	 * 
	 * @param printDocument the print document
	 * @param printerInfo the Printer Information
	 * 
	 * @return the string
	 */
	String deliverPrintJob(byte[] printDocument, Location printerInfo);

	/**
	 * This method pauses a single document in a single Web Service Request to HP Output Server.
	 * 
	 * @param jobClientId the Job Client Id
	 * 
	 * @return the Pause Print Job Status
	 */
	String pausePrintJob(String jobClientId);

	/**
	 * This method fetches the Print Job Status from HP Output Server.
	 * 
	 * @param jobClientId the Job Client Id
	 * 
	 * @return the Print Job Status
	 */
	String queryPrintJob(String jobClientId);

	/**
	 * This method checks if the printer is mapped to the User
	 * 
	 * @param jobClientId the Job Client Id
	 * @param printerInfo the Printer Information
	 * 
	 * @return the Printer Availability/Mapping Status
	 */
	String checkPrinterStatus(String jobClientId, Location printerInfo);

	/**
	 * This method resubmits the Print Job to HP Output Server.
	 * 
	 * @param jobClientId the Job Client Id
	 * @param printerInfo the Printer Information
	 * 
	 * @return the Print Job Status
	 */
	String resubmitPrintJob(String jobClientId, Location printerInfo);

	/**
	 * Alternative print job.
	 *
	 * @param jobClientId the job client id
	 * @param printerInfo the printer info
	 * @return the string
	 */
	String alternativePrintJob(String jobClientId, Location printerInfo);
}
/**
 *  Modification History:
 * 
 *  $Log: IPrintHpOsWebServiceClient.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/06/02 17:23:44  mwrka1
 *  added alternative printer functionalty
 *
 *  Revision 1.7  2010/10/28 21:32:09  mwjxa11
 *  Added checkPrinterStatus method
 *
 *  Revision 1.6  2010/07/22 23:11:29  mwhxa2
 *  Implemented Resubmit Print Job
 *
 *  Revision 1.5  2010/06/29 18:21:45  mwhxa2
 *  Print now uses data from User Context to find the printer
 *
 *  Revision 1.4  2010/06/21 23:00:47  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.6.2  2010/06/20 18:06:58  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 17:43:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/06/02 20:46:45  mwtjc1
 *  sending byte array to HPOS webservice client instead of file object
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 *  Revision 1.1  2010/05/05 23:40:03  mwhxa2
 *  interface to Web Service for HP Output Server
 *
*/
