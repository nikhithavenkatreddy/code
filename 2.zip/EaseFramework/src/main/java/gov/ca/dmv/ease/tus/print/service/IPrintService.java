/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.service;

import gov.ca.dmv.ease.tus.print.request.impl.CancelPrintJobRequest;
import gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest;
import gov.ca.dmv.ease.tus.print.request.impl.QueryPrintJobRequest;
import gov.ca.dmv.ease.tus.print.request.impl.ResubmitPrintJobRequest;
import gov.ca.dmv.ease.tus.print.response.IPrintServiceResponse;
import gov.ca.dmv.ease.tus.print.response.impl.CancelPrintJobResponse;
import gov.ca.dmv.ease.tus.print.response.impl.QueryPrintJobResponse;
import gov.ca.dmv.ease.tus.print.response.impl.ResubmitPrintJobResponse;

/**
 * Description: This interface exposes all the functionality for Printing.
 * File: IPrintService.java
 * Module:  gov.ca.dmv.ease.tus.print.service
 * Created: May 3, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPrintService {
	/**
	 * This method cancels the Print Job to HP OS.
	 * 
	 * @param request the Cancel Print Job Request
	 * 
	 * @return Response containing Client Job Id and Print Status
	 */
	CancelPrintJobResponse execute(CancelPrintJobRequest request);

	/**
	 * This method creates the Print Job and sends it to HP OS for Printing.
	 * 
	 * @param request the Deliver Job Request
	 * 
	 * @return Response containing Client Job Id and Print Status
	 */
	IPrintServiceResponse execute(PrintServiceRequest request);

	/**
	 * This method fetches the Print Job Status from HP OS.
	 * 
	 * @param request the Query Job Request
	 * 
	 * @return Response containing Client Job Id and Print Status
	 */
	QueryPrintJobResponse execute(QueryPrintJobRequest request);

	/**
	 * This method resubmits the Print Job Status from HP OS.
	 * 
	 * @param request the Resubmit Job Request
	 * 
	 * @return Response containing Client Job Id and Print Status
	 */
	ResubmitPrintJobResponse execute(ResubmitPrintJobRequest request);
}
/**
 *  Modification History:
 * 
 *  $Log: IPrintService.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/08/25 17:57:48  mwpxp2
 *  Fixed to use IPrintServiceResponse rather than implementation
 *
 *  Revision 1.3  2010/06/21 23:00:47  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.6.2  2010/06/20 18:06:58  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/07 17:43:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
*/
