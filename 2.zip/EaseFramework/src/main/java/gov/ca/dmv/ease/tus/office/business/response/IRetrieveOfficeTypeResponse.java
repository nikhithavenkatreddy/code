/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response;

import java.util.List;

/**
 * Description: I am an IRetrieveOfficeTypeResponse interface
 * 
 * File: IRetrieveOfficeTypeResponse.java
 * Module:  gov.ca.dmv.ease.tus.office.business.response
 * Created: Jan 11, 2010 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveOfficeTypeResponse extends
		IOfficeBusinessServiceResponse {
	/**
	 * Get office type list.
	 * @return
	 */
	List<String> getOfficeTypeList();
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
