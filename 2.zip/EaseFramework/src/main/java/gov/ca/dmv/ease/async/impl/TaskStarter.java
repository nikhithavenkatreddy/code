/**
 * 
 */
package gov.ca.dmv.ease.async.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.task.TaskExecutor;
/**
 * Description: A generic task starter class that uses a Spring-based TaskExecutor to start
 * a task. The task is just a class that implements the Runnable interface.
 * 
 * File: TaskStarter.java Module: gov.ca.dmv.ease.async.impl
 * Created: Dec 18, 2012
 * 
 * @author MWSEC2
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ 
 * Last Changed By: $Author: mwsec2 $
 */
public class TaskStarter {
	
	private static final Log LOGGER = LogFactory
			.getLog(TaskStarter.class);
	
	private TaskExecutor taskExecutor;
	private Runnable task;

	/**
	 * @param taskExecutor
	 * @param task
	 */
	public TaskStarter(TaskExecutor taskExecutor, Runnable task) {
		this.taskExecutor = taskExecutor;
		this.task = task;
	}

	/**
	 * Starts the task. Intended to be called as an init-method
	 */
	public void startTask() {
		LOGGER.info("TaskStarter is starting a task: Task class: "
				+ task.getClass().getName() + ", Executor class: "
				+ taskExecutor.getClass().getName());
		taskExecutor.execute(task);
	}
}

/**
 *  Modification History:
 *
 *  $Log: TaskStarter.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2013/01/15 19:45:19  mwsec2
 *  committing async logging classes and associated config file changes
 *
 */