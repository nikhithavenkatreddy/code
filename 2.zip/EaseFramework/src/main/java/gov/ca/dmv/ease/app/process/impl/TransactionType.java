/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.process.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am an encapsulation of a transaction type (TTC)
 * File: TransactionType.java
 * Module:  gov.ca.dmv.ease.app.config.impl
 * Created: Aug 31, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class TransactionType {
	/** The name of the business process for this transaction type  */
	private String businessProcessName;
	/** The tcode for this transaction type */
	private String tcode;
	/** The list of security roles authorized for this transaction type */
	private List <String> securityRoles;

	/**
	 * Gets the name of the business process for this transaction type
	 * 
	 * @return
	 */
	public String getBusinessProcessName() {
		return businessProcessName;
	}

	/**
	 * Returns the list of security roles for this transaction type
	 * @return the securityRoles
	 */
	public List <String> getSecurityRoles() {
		if (securityRoles == null) {
			securityRoles = new ArrayList <String>();
		}
		return securityRoles;
	}

	/**
	 * Adds a security role for this transaction type
	 * 
	 * @param role
	 */
	public void addSecurityRole(String role) {
		if (!getSecurityRoles().contains(role)) {
			getSecurityRoles().add(role);
		}
	}

	/**
	 * Returns whether a given role is authorized for this transaction type
	 * 
	 * @param role
	 * @return
	 */
	public boolean isRoleAuthorized(String role) {
		return getSecurityRoles().contains(role);
	}

	/**
	 * Sets the name of the business process for this transaction type
	 * 
	 * @param businessProcessName
	 */
	public void setBusinessProcessName(String businessProcessName) {
		this.businessProcessName = businessProcessName;
	}

	/**
	 * Gets the tcode
	 *
	 * @return the tcode
	 */
	public String getTcode() {
		return tcode;
	}

	/**
	 * Sets the tcode
	 *
	 * @param tcode the tcode to set
	 */
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return tcode;
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransactionType.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/09 17:04:21  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/09/14 18:15:07  mwhys
 *  Changed to non-serializable as it contains the list of security roles, which should not be serialized.
 *
 *  Revision 1.2  2010/09/14 00:40:00  mwkfh
 *  made Serializable
 *
 *  Revision 1.1  2010/09/03 16:37:58  mwsec2
 *  initial check in
 *
 */
