/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.PurgeTableResponse;

import java.util.Date;

/**
 * Description: I represent a request to delete records from a table
 * File: PurgeTableRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Oct 23, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/23 23:38:12 $
 * Last Changed By: $Author: mwkfh $
 */
public class PurgeTableRequest extends PersistenceServiceRequest {
	/** The serialVersionUID */
	private static final long serialVersionUID = -5056001221958801998L;
	/** The class to purge */
	private Class <?> classToPurge;
	/** The optional create timestamp */
	private Date createdBefore;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public PurgeTableRequest(IUserContext userContext, Class <?> classToPurge) {
		super(userContext);
		setClassToPurge(classToPurge);
	}

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 * @param createdBefore the date to delete all record before
	 */
	public PurgeTableRequest(IUserContext userContext, Class <?> classToPurge,
			Date createdBefore) {
		super(userContext);
		setClassToPurge(classToPurge);
		setCreatedBefore(createdBefore);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public PurgeTableResponse execute() {
		return getPersistenceService().execute(this);
	}

	/**
	 * @return the classToPurge
	 */
	public Class <?> getClassToPurge() {
		return classToPurge;
	}

	/**
	 * @return the createdBefore
	 */
	public Date getCreatedBefore() {
		return createdBefore;
	}

	/**
	 * @param classToPurge the classToPurge to set
	 */
	private void setClassToPurge(Class <?> classToPurge) {
		this.classToPurge = classToPurge;
	}

	/**
	 * @param createdBefore the createdBefore to set
	 */
	private void setCreatedBefore(Date createdBefore) {
		this.createdBefore = createdBefore;
	}
}
/**
 *  Modification History:
 *
 *  $Log: PurgeTableRequest.java,v $
 *  Revision 1.1  2012/10/23 23:38:12  mwkfh
 *  Initial
 *
 */
