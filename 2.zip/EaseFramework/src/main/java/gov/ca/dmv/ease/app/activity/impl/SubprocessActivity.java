/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessage;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am the abstract class that represents a group of activities.
 * 
 * File: SubprocessActivity.java
 * Module:  gov.ca.dmv.ease.handler.process.activity.impl
 * Created: Mar 20, 2009
 * 
 * @author mwrsk
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class SubprocessActivity extends TransientActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(SubprocessActivity.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8381028665130704512L;
	/** The Name of the business process that needs to be executed. */
	private String childProcessName;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext processContext) {
		ProcessContext subprocessContext = getChildProcessContext(processContext);
		subprocessContext.setCurrentInteractionActivity(processContext
				.getCurrentInteractionActivity());
		preSubprocessExecute(processContext, subprocessContext);
		subprocessContext.setSelectedAction(processContext.getSelectedAction());
		LOGGER.info("Switching from parent process " + processContext.getProcessId() 
				+ " to subprocess " + subprocessContext.getProcessId());
		executeSubprocess((ChildContext) processContext,
				(ChildContext) subprocessContext);
	}

	/**
	 * This method executes the sub business process
	 * @param parentProcessContext the current business process context
	 * @param childProcessContext the business process context to be executed
	 */
	protected abstract void executeSubprocess(
			ChildContext parentProcessContext, ChildContext childProcessContext);

	/**
	 * This method retuns the child process context to which it has to switch
	 * @param processContext
	 * @return
	 */
	protected ProcessContext getChildProcessContext(
			ProcessContext processContext) {
		return getProcessRegistry().getProcess(getChildProcessName())
				.getProcessContext();
	}

	/**
	 * @return the childProcessName
	 */
	public String getChildProcessName() {
		return childProcessName;
	}

	/**
	  * Copies error messages from process to process
	  * @param srcContext
	  * @param destContext
	*/
	protected void moveErrorMessages(ProcessContext srcContext,
			ProcessContext destContext) {
		ErrorMessageCollector srcErrorMessageCollector = srcContext
				.getMessageCollector();
		ErrorMessageCollector destErrorMessageCollector = destContext
				.getMessageCollector();
		if (!EaseUtil.isNullOrBlank(srcErrorMessageCollector)) {
			Map <String, ErrorMessage> errorMap = srcErrorMessageCollector
					.getValidationMessages();
			for (String key : errorMap.keySet()) {
				destErrorMessageCollector.addValidationMessage(key, errorMap
						.get(key));
			}
		}
		srcErrorMessageCollector.getValidationMessages().clear();
	}

	/**
	 * This method populates the sub business process context values from the parent business process context,
	 * assuming the property names are identical. Override this method if necessary.  
	 * @param processContext Process Context instance from which child context needs to be created0
	 * @param childProcessContext Business Process Context that needs to be executed
	 */
	protected void preSubprocessExecute(ProcessContext processContext,
			ProcessContext childProcessContext) {
		LOGGER
				.info("Copying properties from parent process context to subprocess context");
		childProcessContext.copyPropertiesFrom(processContext);
	}

	/**
	 * @param childProcessName the childProcessName to set
	 */
	public void setChildProcessName(String childProcessName) {
		this.childProcessName = childProcessName;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SubprocessActivity.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/04/30 16:48:31  mwsec2
 *  added logging statement
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.24  2010/12/02 00:14:59  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.23  2010/11/09 03:19:29  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.22  2010/10/20 21:33:44  mwyxg1
 *  add move error message to ContinuationSubprocessActivity
 *
 *  Revision 1.21  2010/10/20 21:05:51  mwsec2
 *  ContextCopyUtil removed. Context objects now have their own copyPropertiesFrom(context) method
 *
 *  Revision 1.20  2010/08/20 21:55:38  mwcsj3
 *  Updated executeAuthorized method, setting current interaction activity to sub process context
 *
 *  Revision 1.19  2010/08/20 18:32:23  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.18  2010/08/16 21:59:26  mwsec2
 *  getChildProcessContext changed to take the process context as an arg
 *
 *  Revision 1.17  2010/08/06 21:05:35  mwsec2
 *  Modifications to support sub-to-sub process fallbacks
 *
 *  Revision 1.16  2010/08/03 21:20:06  mwsec2
 *  syncPoint enhancements
 *
 *  Revision 1.15  2010/07/30 22:44:56  mwakg
 *  Activities now register syncpoint activity and the processContext
 *
 *  Revision 1.14  2010/07/30 20:15:53  mwakg
 *  Merged from Fallback_branch
 *
 *  Revision 1.13  2010/07/30 00:01:53  mwsec2
 *  changed log statement text
 *
 *  Revision 1.12  2010/07/29 22:10:59  mwsec2
 *  providing default implementation of pre/postSubprocessExecute methods that copies properties from one context to another. Also adding logger
 *
 *  Revision 1.11  2010/07/23 14:49:47  mwakg
 *  Merged from Fallback_branch
 *
 *  Revision 1.10  2010/07/08 02:00:55  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2010/06/23 01:41:12  mwakg
 *  *) Changed getSubProcess to getSubprocess.
 *  *) Moved postSubprocessExecute to only InclusionSubprocessActivity
 *  *) Renamed businessProcessName variable to childProcessName in SubProcessActivity class
 *
 *  Revision 1.8  2010/06/21 23:00:41  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.7.10.10  2010/06/20 20:20:13  mwakg
 *  Moved name of the subprocess to spring configuration files
 *
 *  Revision 1.7.10.9  2010/06/20 18:44:06  mwakg
 *  Fixed API and updated java docs
 *
 *  Revision 1.7.10.8  2010/06/20 18:06:54  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.7.10.7  2010/06/16 19:51:24  mwakg
 *  Added ContinuationSubprocess and InclusionSubprocessActivity to divided SubprocesActivity responsibility
 *
 *  Revision 1.7.10.6  2010/06/13 20:52:52  mwakg
 *  Updated copyProcessContext method and moved it from ProcessContext
 *
 *  Revision 1.7.10.5  2010/06/08 22:55:49  mwcsj3
 *  Deleted unused variable
 *
 *  Revision 1.7.10.4  2010/06/08 03:09:30  mwakg
 *  Added support for 07Q to test process switching
 *
 *  Revision 1.7.10.3  2010/06/08 01:18:26  mwakg
 *  Added Transitions to SubBusinessProcess
 *
 *  Revision 1.7.10.2  2010/06/01 21:53:27  mwcsj3
 *  Updated setupProcess() signature
 *
 *  Revision 1.7.10.1  2010/05/29 23:41:31  mwcsj3
 *  Added helper methods
 *
 *  Revision 1.7  2010/04/22 22:27:25  mwcsj3
 *  Fixed FIX ME
 *
 *  Revision 1.6  2010/04/22 18:40:26  mwpxp2
 *  Added todo
 *
 *  Revision 1.5  2010/04/14 15:38:59  mwakg
 *  Made activities authorizedExecute protected
 *
 *  Revision 1.4  2010/04/13 23:24:19  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.3  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.2  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.2  2010/02/26 19:09:54  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/07 19:16:21  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:57:17  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.8  2009/10/03 20:05:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2009/09/22 23:49:23  mwsmg6
 *  cleanup
 *
 *  Revision 1.6  2009/08/27 18:24:57  mwsmg6
 *  formatting
 *
 *  Revision 1.5  2009/08/10 23:30:08  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
