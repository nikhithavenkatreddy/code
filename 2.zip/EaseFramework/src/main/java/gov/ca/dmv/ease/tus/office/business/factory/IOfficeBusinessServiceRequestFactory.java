/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.factory;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveAuthorizedTtcsRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeBusinessProcessingAllowedRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest;

/**
 * Description: I define the interface to the IOfficeBusinessServiceRequestFactory.
 * 
 * File: IOfficeBusinessServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.office.business.factory
 * Created: Jan 10, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeBusinessServiceRequestFactory {
	/**
	 * create Retrieve Office Business Processing Allowed Request.
	 * 
	 * @return RetrieveOfficeBusinessProcessingAllowedRequest
	 */
	RetrieveOfficeBusinessProcessingAllowedRequest createRetrieveOfficeBusinessProcessingAllowedRequest(
			IUserContext userContext, String officeId );
	
	/**
	 * Create Office Type Request.
	 * 
	 * @return RetrieveOfficeTypeRequest
	 */
	RetrieveOfficeTypeRequest createRetrieveOfficeTypeRequest(
			IUserContext userContext, String officeId );
	
	/**
	 * Create Office Type Request.
	 * 
	 * @return RetrieveOfficeTypeRequest
	 */
	RetrieveAuthorizedTtcsRequest createRetrieveAuthorizedTtcsRequest(
			IUserContext userContext, String officeId );
	
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeBusinessServiceRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/01/12 21:05:16  mwxxw
 *  Add new API in OfficeBusinessService: IRetrieveAuthorizedTtcsResponse execute(RetrieveAuthorizedTtcsRequest request).
 *
 *  Revision 1.1  2011/01/12 01:26:55  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 */
