/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.ecs.IEcsService;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: Abstract superclass for concrete implementations of specific requests.
 * 
 *  //TODO - replace IEcsService ecsService inst cvar by a static call to EcsService.getIstance();
 *  
 * File: AbstractEcsRequest.java
 * Module: gov.ca.dmv.ease.service.request.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractEcsRequest extends AbstractRequest implements
		IEcsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4802471291524734514L;
	/** The ECS Service. */
	//TODO - remove
	private transient IEcsService ecsService;
	/** The persistable. */
	private final boolean isPersistable = false;
	/** The converter */
	private IMessageConverter messageConverter;
	/** The request id. */
	private String requestId;
	
	/**
	 * Instantiates a new abstract request.
	 */
	protected AbstractEcsRequest() {
		super();
	}
	
	/**
	 * Instantiates a new abstract request with IUserContext instance.
	 * 
	 * @param aContext userContext of the request
	 */
	public AbstractEcsRequest(IUserContext aContext) {
		super(aContext);
	}
	
	/**
	 * Instantiates a new abstract request.
	 * 
	 * @param anId the an id
	 */
	public AbstractEcsRequest(String anId) {
		super();
		setRequestId(anId);
	}
	
	/**
	 * Instantiates a new abstract request with an ID and IUserContext instance.
	 * 
	 * @param anId Id of the request
	 * @param aContext userContext of the request
	 */
	public AbstractEcsRequest(String anId, IUserContext aContext) {
		super(aContext);
		setRequestId(anId);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AbstractEcsRequest other = (AbstractEcsRequest) obj;
		if (isPersistable != other.isPersistable) {
			return false;
		}
		if (requestId == null) {
			if (other.requestId != null) {
				return false;
			}
		}
		else if (!requestId.equals(other.requestId)) {
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#getBusinessObjectNamed(java.lang.String)
	 */
	public BusinessObject getBusinessObjectNamed(String propertyName) {
		return null;
	}
	
	/**
	 * Gets the ECS service.
	 * 
	 * @return the ecsService
	 */
	public IEcsService getEcsService() {
		return ecsService;
	}
	
	/**
	 * Get the message converter.
	 * 
	 * @return the message converter
	 */
	public IMessageConverter getMessageConverter() {
		return messageConverter;
	}
	
	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#getObjectValueNamed(java.lang.String)
	 */
	public Object getObjectValueNamed(String propertyName) {
		return null;
	}
	
	public String getCorrelationId() {
		return getRequestId();
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#getRequestId()
	 */
	public String getRequestId() {
		return requestId;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#hasChildren()
	 */
	public boolean hasChildren() {
		//only composites can have children
		return false;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (isPersistable ? 1231 : 1237);
		result = prime * result
				+ ((requestId == null) ? 0 : requestId.hashCode());
		return result;
	}
	
	/**
	 * Checks if is asynchronous request.
	 * 
	 * @return true, if is asynchronous request
	 */
	public boolean isAsynchronousRequest() {
		// subclasses may override
		return false;
	}
	
	/**
	 * Checks if is fire and forget request.
	 * 
	 * @return true, if is fire and forget request
	 */
	public boolean isFireAndForgetRequest() {
		// subclasses may override
		return false;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#isPersistable()
	 */
	public boolean isPersistable() {
		return isPersistable;
	}
	
	/**
	 * Checks if is synchronous request.
	 * 
	 * @return true, if is synchronous request
	 */
	public boolean isSynchronousRequest() {
		// subclasses may override
		return false;
	}
	
	/**
	 * Sets the ECS service.
	 * 
	 * @param ecsService the ecsService to set
	 */
	public void setEcsService(IEcsService ecsService) {
		this.ecsService = ecsService;
	}
	
	/**
	 * Set MessageConverter for the ECS request. 
	 * @param aMessageConverter the converter
	 */
	protected void setMessageConverter(IMessageConverter aMessageConverter) {
		this.messageConverter = aMessageConverter;
	}
	
	/**
	 * Sets the request id.
	 * 
	 * @param anId the an ID
	 */
	protected void setRequestId(String anId) {
		requestId = anId;
	}
	
	/**
	 * Sets the correlation id.
	 * 
	 * @param anId the new correlation id
	 */
	protected void setCorrelationId(String anId) {
		requestId = anId;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractEcsRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2011/10/25 23:47:35  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.12  2010/12/12 17:57:43  mwpxp2
 *  Added explicitly named getCorrelationId
 *
 *  Revision 1.11  2010/09/22 18:02:45  mwpxp2
 *  Added todos
 *
 *  Revision 1.10  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
 *  Revision 1.9  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.8  2010/09/01 19:01:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/08/31 17:57:33  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.6  2010/07/21 18:38:16  mwpxp2
 *  Modified validateUsing/1 to avoid it having to be overriden in subclasses
 *
 *  Revision 1.5  2010/04/22 19:22:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/04/13 21:37:07  mwvkm
 *  Reverted the change. Made the access modifier of setMessageConverter method back to protected.
 *
 *  Revision 1.3  2010/04/09 01:34:07  mwvkm
 *  Changed the access modifier for the method, setMessageConverter from protected to public as I would like to set the messageConverter property from the CashPromiseRequest for asynchronous response.
 *
 *  Revision 1.2  2010/03/23 17:08:37  mwhxb3
 *  Added setter and getter for converter.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/14 20:47:07  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.6  2009/10/13 20:57:25  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/10/07 14:33:29  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.4  2009/10/07 03:33:42  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:56:47  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:53:04  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:41:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.10.2.1  2009/10/06 20:28:40  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.10  2009/10/03 21:23:36  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.9  2009/08/27 02:33:54  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.8  2009/08/22 20:24:44  mwpxp2
 *  Added getMessageConverter/0 with exception
 *
 *  Revision 1.7  2009/08/17 23:42:25  mwpxp2
 *  Removed getValidator/0 and validate/0 defined in super
 *
 *  Revision 1.6  2009/08/10 23:05:45  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.5  2009/07/27 17:46:46  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.4  2009/07/23 01:12:35  mwpxm2
 *  refactor
 *
 *  Revision 1.3  2009/07/21 01:49:15  mwpzs3
 *  Spring based jms ecs service classes
 *
 *  Revision 1.2  2009/07/17 00:20:51  mwakg
 *  Added IUserContext as a parameter to request classes of ECS's converters
 *
 *  Revision 1.1  2009/07/16 02:15:35  mwpxp2
 *  Renamed and extended AbstractRequest to take care of userContext
 *
 *  Revision 1.3  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.7  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.6  2009-05-17 05:22:28  ppalacz
 *  Added support for composite requests
 *
 *  Revision 1.5  2009-05-15 13:14:34  ppalacz
 *  REmoved implementation of validate/0
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 17:45:21  mwpxp2
 *  Moved in
 *
 *  Revision 1.3  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.2  2009-05-11 07:31:48  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
