/**
 * 
 */
package gov.ca.dmv.ease.fw.validate.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.validate.IValidatable;

/**
 * Description: I am default validator for request classes
 * I can only validate if the request is null or not
 * I can only be used as a default for request validation until specific validator for a request is done
 * 
 * File: DefaultRequestValidator.java
 * Module:  gov.ca.dmv.ease.fw.validate.impl
 * Created: Aug 17, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DefaultRequestValidator extends AbstractBaseValidator {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5635991325439879849L;

	/**
	 * Instantiates a new default request validator.
	 */
	public DefaultRequestValidator() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.impl.AbstractBaseValidator#validateValidatable(gov.ca.dmv.ease.fw.validate.IValidatable, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public static void validateValidatable(IValidatable validatable,
			IErrorCollector collector) {
		// TODO Auto-generated method stub
	}
}
/**
 *  Modification History:
 *
 *  $Log: DefaultRequestValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/23 17:19:49  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.2  2009/10/11 22:51:34  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.1  2009/10/03 20:28:49  mwpxp2
 *  Moved into fw.validate.impl
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/08/17 21:25:23  mwpxp2
 *  Initial
 *
 */
