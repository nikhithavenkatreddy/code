/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import static gov.ca.dmv.ease.fw.constants.IEaseErrorCodeConstants.PRINTER_ERROR_CODE;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.DocumentGeneratorException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsResponseIsNullException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;

import java.io.UnsupportedEncodingException;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

/**
 * Description: I am the Jms Message Converter for Document Generation.
 * //FIXME - this class does not belong to ecs.convert.impl package - move to a more appropriate one
 * File: DocumentGenerationJmsMessageConverter.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: May 18, 2009 
 * @author MWTJC1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DocumentGenerationJmsMessageConverter extends
		AbstractJmsMessageConverter {
	//FIXME - the class is needlessly stateful
	/** Request for which this Message creator is used for */
	private IEcsRequest request = null;

	/**
	 * Constructor - Instantiates a new converter.
	 * @param aRequest a request.
	 */
	public DocumentGenerationJmsMessageConverter(IEcsRequest aRequest) {
		request = aRequest;
	}

	/**
	 * Bytes msg to string.
	 * 
	 * @param retValue the ret value
	 * @param recvBytes the recv bytes
	 * 
	 * @throws JMSException the JMS exception
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	private void bytesMsgToString(StringBuilder retValue, BytesMessage recvBytes)
			throws JMSException, UnsupportedEncodingException {
		byte[] byteMsg = new byte[new Long(recvBytes.getBodyLength())
				.intValue()];
		recvBytes.readBytes(byteMsg);
		String tranMsg = new String(new String(byteMsg).getBytes());
		retValue.append(tranMsg);
	}

	/**
	 * This function calls the createResponse of the converter associated with the request.
	 * It returns the IEcsResponse thus obtained or throws a MessageConversionException.
	 * @param receivedMessageObject
	 * @return ecsResponse an ecs response.
	 */
	@Override
	public IEcsResponse convert(Message aMessage) {
		//message already validated as not null
		StringBuilder aBuilder = new StringBuilder();
		handlePayload(aBuilder, aMessage);
		String aPayload = aBuilder.toString();
		validatePayload(aPayload);
		String responsePayload = aPayload.substring(RESPONSE_HEADER_LENGTH);
		if (!isNotNull(responsePayload) || responsePayload.length() < 1) {// If payload is null then Error Code sent by Document Generation 
			throw new DocumentGeneratorException(PRINTER_ERROR_CODE);//responsePayload);
		}
		//String header = aPayload.substring(0, RESPONSE_HEADER_LENGTH); 
		String returnCode = responsePayload.substring(0, 1);
		responsePayload = responsePayload.substring(1); // Error message or good response
		if ("1".equals(returnCode)) {// Error Code sent by Document Generation 
			throw new DocumentGeneratorException(responsePayload);
		}
		IMessageConverter convertor = request.getMessageConverter();
		IEcsResponse ecsResponse = convertor.createResponse(responsePayload);
		return ecsResponse;
	}

	/**
	 * Handles payload.
	 * Updates the provided string buffer with the string representation of the in-bound jms Message.
	 * 
	 * @param aStringBuilder the return value
	 * @param inboundMessageObject the inbound message object
	 */
	private void handlePayload(StringBuilder aStringBuilder,
			javax.jms.Message inboundMessageObject) {
		BytesMessage inboundByteMessage;
		try {
			if (inboundMessageObject == null) {
				throw new EcsResponseIsNullException(
						"No inboundMessageObject recieved from the CAMV");
			}
			else {
				if (inboundMessageObject instanceof javax.jms.BytesMessage) {
					inboundByteMessage = (javax.jms.BytesMessage) inboundMessageObject;
					bytesMsgToString(aStringBuilder, inboundByteMessage);
				}
			}
		}
		catch (Exception e) {
			throw new EcsMessageConversionException(e);
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	@Override
	public Message toMessage(Object arg0, Session arg1)
			throws JMSException,
			org.springframework.jms.support.converter.MessageConversionException {
		// We are using message creator in place of this!
		return null;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DocumentGenerationJmsMessageConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2012/09/27 23:17:33  mwrrv3
 *  Checked in on behalf of Prabhu Rajendran (mwpxr5)
 *  size check added.
 *
 *  Revision 1.10  2012/09/27 23:17:14  mwrrv3
 *  Checked in on behalf of Prabhu Rajendran (mwpxr5)
 *  size check added.
 *
 *  Revision 1.9  2012/09/27 22:11:36  mwrrv3
 *  Checked in on behalf of Prabhu Rajendran (mwpxr5)
 *  Null check added.
 *
 *  Revision 1.8  2011/06/10 21:40:40  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2010/11/09 04:57:20  mwpxp2
 *  Added package-related fixme
 *
 *  Revision 1.6  2010/10/29 00:18:44  mwyxg1
 *  fix nullpointer
 *
 *  Revision 1.5  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.4  2010/05/26 17:23:16  mwtjc1
 *  DocumentGeneratorException is thrown in case of Document Generation exception
 *
 *  Revision 1.3  2010/05/26 16:37:18  mwtjc1
 *  error handling mechanism is added for catching the exceptions created by document generation
 *
 *  Revision 1.2  2010/05/26 01:56:16  mwpxp2
 *  Refactoring
 *
 *  Revision 1.1  2010/05/26 01:21:51  mwpxp2
 *  Moved in from improper package
 *
 *  Revision 1.4  2010/05/25 22:10:13  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.3  2010/05/25 21:56:30  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.2  2010/05/25 18:15:45  mwtjc1
 *  convert method is changed to extract out header part from response message
 *
 *  Revision 1.1  2010/05/18 21:02:30  mwtjc1
 *  JmsMessageConverter for Document Generation
 *
 *  Revision 1.2  2010/03/22 23:22:43  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/30 19:10:45  mwpzs3
 *  removing redundant ResponseIsNull condition
 *
 *  Revision 1.8  2009/10/30 19:08:38  mwpzs3
 *  null converter handled by EaseValidationException
 *
 *  Revision 1.7  2009/10/13 18:11:10  mwhxb3
 *  updated comments.
 *
 *  Revision 1.6  2009/10/07 18:18:48  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.5  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.4  2009/10/06 21:50:56  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.2.2  2009/10/06 20:41:53  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.2.1  2009/10/06 20:28:41  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/09/25 18:56:55  mwpzs3
 *  Update comments
 *
 *  Revision 1.1  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
 *  Revision 1.1  2009/09/10 00:35:09  mwpzs3
 *  Move to JMS 1.2
 *
 */
