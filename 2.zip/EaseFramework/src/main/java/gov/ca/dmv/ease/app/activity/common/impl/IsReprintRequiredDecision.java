/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.common.impl;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.activity.impl.DecisionActivity;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: This activity checks if the user has requested for re-print or not.
 * File: IsReprintRequiredDecision.java
 * Module:  gov.ca.dmv.ease.app.activity.dl.decision.impl
 * Created: 2009 
 * @author MWSYK1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class IsReprintRequiredDecision extends DecisionActivity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 475683408509431615L;

	/**
	 * This method evaluates if there is request for re-print.
	 * If there is a request it returns true, if not returns false.
	 * 
	 * @param context the context
	 * 
	 * @return the string
	 */
	@Override
	protected String evaluate(ProcessContext context) {
		Action action = context.getSelectedAction();
		if (action.getName().equalsIgnoreCase("Reprint")) {
			return "yes";
		}
		else {
			return "no";
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: IsReprintRequiredDecision.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2010/03/22 22:55:11  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.6  2010/03/21 00:09:51  mwakg
 *  Refactored Action class
 *
 *  Revision 1.5  2010/03/18 17:00:37  mwakg
 *  Removed instances of action classes and using generic Action class
 *
 *  Revision 1.4  2010/03/11 22:20:26  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.3.2.1  2010/02/26 18:00:06  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.3  2009/12/10 23:35:13  mwrka1
 *  removed unused imports
 *
 *  Revision 1.2  2009/12/10 23:34:49  mwrka1
 *  evaluate Updated
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/14 17:21:50  mwrrv2
 *  Cleaned FIXME.
 *
 *  Revision 1.2  2009/10/07 19:16:32  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:57:25  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.5  2009/08/27 08:25:02  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.4  2009/08/20 16:54:34  mwsmg6
 *  enhanced logging of various activities
 *
 *  Revision 1.3  2009/08/19 22:43:29  mwsmg6
 *  corrected class hierarchy and resulting inherited methods
 *
 *  Revision 1.2  2009/08/10 23:57:51  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.1  2009/08/10 18:38:36  mwrrv2
 *  Moved from Dl decision activity package to common activity package.
 *
 *  Revision 1.5  2009/08/05 17:00:42  mwsmg6
 *  moved ProcessContext to ...context package
 *
 *  Revision 1.4  2009/07/26 16:14:04  mwcsj3
 *  Added modification log
 *
 *
 *
 */
