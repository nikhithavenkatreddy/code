/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.impl;

import gov.ca.dmv.ease.app.session.ISessionDataBinaryConverter;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * Description: I am abstract implementation of ISessionDataBinaryConverter
 * File: AbstractSessionDataBinaryConverter.java
 * Module:  gov.ca.dmv.ease.app.session.impl
 * Created: Sep 18, 2012
 * @author mwpxp2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/22 18:24:59 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractSessionDataBinaryConverter implements
		ISessionDataBinaryConverter {
	protected static int DEFAULT_OUTPUT_STREAM_SIZE = 4000;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3187740920849081594L;

	/**
	 * Instantiates a new abstract session data binary converter.
	 */
	protected AbstractSessionDataBinaryConverter() {
		super();
	}

	/**
	 * Creates the input stream.
	 *
	 * @param aByteArr the a byte arr
	 * @return the byte array input stream
	 */
	protected ByteArrayInputStream createInputStream(byte[] aByteArr) {
		return new ByteArrayInputStream(aByteArr);
	}

	/**
	 * Creates the output stream.
	 *
	 * @return the output stream
	 */
	protected ByteArrayOutputStream createOutputStream() {
		return new ByteArrayOutputStream(getOutputStreamInitialSize());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.ISessionDataBinaryConverter#fromByteArray(byte[])
	 */
	public SessionData fromByteArray(byte[] aByteArray) {
		validate(aByteArray);
		return fromValidatedByteArray(aByteArray);
	}

	/**
	 * From validated byte array.
	 *
	 * @param aByteArray the a byte array
	 * @return the session data
	 */
	protected abstract SessionData fromValidatedByteArray(byte[] aByteArray);

	/**
	 * Gets the output stream initial size.
	 *
	 * @return the output stream initial size
	 */
	protected int getOutputStreamInitialSize() {
		return DEFAULT_OUTPUT_STREAM_SIZE;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.session.ISessionDataBinaryConverter#toByteArray(gov.ca.dmv.ease.app.session.impl.SessionData)
	 */
	public byte[] toByteArray(SessionData data) {
		validate(data);
		return toByteArrayValidated(data);
	}

	/**
	 * To byte array validated.
	 *
	 * @param data the data
	 * @return the byte[]
	 */
	protected abstract byte[] toByteArrayValidated(SessionData data);

	/**
	 * Validate.
	 *
	 * @param aByteArray the a byte array
	 */
	protected void validate(byte[] aByteArray) {
		if (aByteArray == null) {
			throw new EaseValidationException("null byte array in " + this);
		}
		if (aByteArray.length == 0) {
			throw new EaseValidationException("zero length byte array in "
					+ this);
		}
	}

	/**
	 * Validate.
	 *
	 * @param data the data
	 */
	protected void validate(SessionData data) {
		if (data == null) {
			throw new EaseValidationException("null data in " + this);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractSessionDataBinaryConverter.java,v $
 *  Revision 1.2  2012/10/22 18:24:59  mwpxp2
 *  Added common methods for input and output stream creation with a default byte arr size
 *
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/09/18 18:19:55  mwpxp2
 *  Initial
 *
 */
