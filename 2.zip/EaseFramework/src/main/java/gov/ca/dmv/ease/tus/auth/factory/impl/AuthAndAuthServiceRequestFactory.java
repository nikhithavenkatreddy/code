/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.factory.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory;
import gov.ca.dmv.ease.tus.auth.request.impl.AuthorizeApproverRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.LocationEnforcementRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsListRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveAuthorizedTtcsMapRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveOperationalModesRequest;
import gov.ca.dmv.ease.tus.auth.request.impl.RetrieveUserAuthorizedRolesRequest;

import java.util.List;

/**
 * Description: I define the AuthAndAuth requests
 * 
 * File: AuthAndAuthServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.auth.factory.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuthAndAuthServiceRequestFactory implements
		IAuthAndAuthServiceRequestFactory {
	/** The SINGLETON. */
	private static IAuthAndAuthServiceRequestFactory SINGLETON = new AuthAndAuthServiceRequestFactory();

	/**
	 * Gets the instance of IAuthAndAuthServiceRequestFactory.
	 * 
	 * @return instance of IAuthAndAuthServiceRequestFactory
	 */
	public static IAuthAndAuthServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		if (SINGLETON == null) {
			SINGLETON = new AuthAndAuthServiceRequestFactory();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createAuthAndAuthServiceRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public AuthorizeApproverRequest createAuthorizeApproverRequest(
			IUserContext userContext, String userName, String password,
			String approverRole) {
		return new AuthorizeApproverRequest(userContext, userName, password,
				approverRole);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createAuthAndAuthServiceRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public AuthorizeApproverRequest createAuthorizeApproverRequest(
			IUserContext userContext, String userName, String password,
			String approverRole, String officeId) {
		return new AuthorizeApproverRequest(userContext, userName, password,
				approverRole, officeId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createRetrieveAuthorizedTtcsListRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public RetrieveAuthorizedTtcsListRequest createRetrieveAuthorizedTtcsListRequest(
			IUserContext userContext, List <String> roleList) {
		return new RetrieveAuthorizedTtcsListRequest(userContext, roleList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createRetrieveAuthorizedTtcsMapRequest(gov.ca.dmv.ease.fw.process.IUserContext)
	 */
	public RetrieveAuthorizedTtcsMapRequest createRetrieveAuthorizedTtcsMapRequest(
			IUserContext userContext, List <String> roleList) {
		return new RetrieveAuthorizedTtcsMapRequest(userContext, roleList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createRetrieveOperationalModesRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveOperationalModesRequest createRetrieveOperationalModesRequest(
			IUserContext userContext, String officeId) {
		return new RetrieveOperationalModesRequest(userContext, officeId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.factory.IAuthAndAuthServiceRequestFactory#createRetrieveUserAuthorizedRolesRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveUserAuthorizedRolesRequest createRetrieveUserAuthorizedRolesRequest(
			IUserContext userContext) {
		return new RetrieveUserAuthorizedRolesRequest(userContext);
	}

	public LocationEnforcementRequest createLocationEnforcementRequest(
			IUserContext userContext, String ipAddress, String officeId,
			String remoteOfficeId) {
		return new LocationEnforcementRequest(userContext, ipAddress, officeId,
				remoteOfficeId);
	}
		
}
/**
 *  Modification History:
 *
 *  $Log: AuthAndAuthServiceRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2011/01/18 19:50:53  mwxxw
 *  Move office business related logic from AuthAndAuthService to OfficeBusinessService.
 *
 *  Revision 1.6  2010/12/09 00:30:26  mwxxw
 *  Add new service to AuthAndAuthService for Office Business.
 *
 *  Revision 1.5  2010/12/01 21:29:34  mwkfh
 *  fixed createAuthorizeApproverRequest
 *
 *  Revision 1.4  2010/11/30 23:10:50  mwxxw
 *  Add new interface createLocationEnforcementRequest() for location enforcement service.
 *
 *  Revision 1.3  2010/11/22 22:07:41  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 *  Revision 1.2  2010/10/04 23:40:19  mwkfh
 *  swapped role and officeId in createAuthorizeApproverRequest to match constructor
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
