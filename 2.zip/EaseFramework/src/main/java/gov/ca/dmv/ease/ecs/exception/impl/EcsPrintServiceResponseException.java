/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: This class represents Print Service Response Exception.
 * File: EcsPrintServiceResponseException.java
 * Module:  gov.ca.dmv.ease.ecs.msg
 * Created: Mar 17, 2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsPrintServiceResponseException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6758987647459241692L;

	/**
	 * Instantiates a new Print Service Response exception.
	 */
	public EcsPrintServiceResponseException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message.
	 * 
	 * @param message the message
	 */
	public EcsPrintServiceResponseException(String message) {
		super(message);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * 
	 * @param message the message
	 * @param cause the Throwable cause
	 */
	public EcsPrintServiceResponseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public EcsPrintServiceResponseException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsPrintServiceResponseException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/25 22:09:42  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.1  2010/05/05 18:27:35  mwhxa2
 *  Print Service Response Exception
 *
 *
*/
