/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;
import gov.ca.dmv.ease.tus.print.response.IPrintServiceResponse;

import java.util.Date;

/**
 * Description: This is abstract class to encapsulate Print Service Request Functionality 
 * File: AbstractPrintServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: Aug 05, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractPrintServiceRequest extends AbstractRequest
		implements IPrintServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5861947504503214485L;
	/** The Constant DRT. */
	private static final String DRT = "DRT";
	/** The Constant IRT. */
	private static final String IRT = "IRT";
	/** The Constant CDA. */
	private static final String CDA = "CDA";
	
	/**
	 * Instantiates a new Print Service request.
	 * 
	 * @param aContext the a context
	 */
	public AbstractPrintServiceRequest(IUserContext aContext) {
		super(aContext);
	}
	
	/**
	 * This method invokes the Print Service.
	 * 
	 * @return <code>PrintServiceResponse</code> the Print Job Response
	 */
	public abstract IPrintServiceResponse execute();
	
	//	/* (non-Javadoc)
	//	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#getValidator()
	//	 */
	//	@Override
	//	abstract protected IValidator getValidator();
	//	/* (non-Javadoc)
	//	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	//	 */
	//	@Override
	//	public void validateUsing(IErrorCollector aCollector) {
	//		super.validateUsing(aCollector);
	//		if (getValidator() != null) {
	//			getValidator().validate(this, aCollector);
	//		}
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		//NOTE: For DRT and IRT ttcs, work date is _not_ required.
		if (!EaseUtil.isNullOrBlank(getUserContext())
				&& !ArrayUtils.contains(getUserContext().getTtc(), DRT, IRT,
						CDA)) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *	
 *  $Log: AbstractPrintServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2012/08/25 17:53:51  mwpxp2
 *  Fixed to use IPrintServiceResponse rather than implementation
 *
 *  Revision 1.10  2011/10/25 23:47:35  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.9  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.8  2010/09/01 19:07:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/08/31 17:58:05  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.6  2010/07/21 18:16:50  mwpxp2
 *  Removed unnecessary override of validate; modified validateUsing to call super
 *
 *  Revision 1.5  2010/07/12 23:03:48  mwhxa2
 *  fixed TODO
 *
 *  Revision 1.4  2010/06/21 23:00:43  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.6.2  2010/06/20 18:06:55  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 17:13:00  mwpxp2
 *  Added fixme; removed unnecessary t!his.es; bulk cleanup
 *
 *  Revision 1.2  2010/05/17 22:04:55  mwhxb3
 *  getting print service from EaseApplicationContext : Temporary solution
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 */
