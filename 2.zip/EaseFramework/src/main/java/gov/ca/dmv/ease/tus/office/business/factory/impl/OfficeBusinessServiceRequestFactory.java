/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.factory.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.office.business.factory.IOfficeBusinessServiceRequestFactory;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveAuthorizedTtcsRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeBusinessProcessingAllowedRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest;

/**
 * Description: I define the Office Business Service requests
 * 
 * File: OfficeBusinessServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.office.business.factory.impl
 * Created: Jan 11, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class OfficeBusinessServiceRequestFactory implements
		IOfficeBusinessServiceRequestFactory {
	/** The SINGLETON. */
	private static IOfficeBusinessServiceRequestFactory SINGLETON = new OfficeBusinessServiceRequestFactory();

	/**
	 * Gets the instance of IAuthAndAuthServiceRequestFactory.
	 * 
	 * @return instance of IAuthAndAuthServiceRequestFactory
	 */
	public static IOfficeBusinessServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		if (SINGLETON == null) {
			SINGLETON = new OfficeBusinessServiceRequestFactory();
		}
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.factory.IOfficeBusinessServiceRequestFactory#createRetrieveOfficeBusinessProcessingAllowedRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveOfficeBusinessProcessingAllowedRequest createRetrieveOfficeBusinessProcessingAllowedRequest(
			IUserContext userContext, String officeId) {
		
		return new RetrieveOfficeBusinessProcessingAllowedRequest(userContext, officeId);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.factory.IOfficeBusinessServiceRequestFactory#createRetrieveOfficeTypeRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveOfficeTypeRequest createRetrieveOfficeTypeRequest(
			IUserContext userContext, String officeId) {
		return new RetrieveOfficeTypeRequest(userContext, officeId);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.factory.IOfficeBusinessServiceRequestFactory#createRetrieveAuthorizedTtcsRequest(gov.ca.dmv.ease.fw.process.IUserContext, java.lang.String)
	 */
	public RetrieveAuthorizedTtcsRequest createRetrieveAuthorizedTtcsRequest(
			IUserContext userContext, String officeId) {
		return new RetrieveAuthorizedTtcsRequest(userContext, officeId);
	}
	
}
/**
 *  Modification History:
 *
 *  $Log: OfficeBusinessServiceRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/01/18 19:50:53  mwxxw
 *  Move office business related logic from AuthAndAuthService to OfficeBusinessService.
 *
 *  Revision 1.3  2011/01/12 21:05:17  mwxxw
 *  Add new API in OfficeBusinessService: IRetrieveAuthorizedTtcsResponse execute(RetrieveAuthorizedTtcsRequest request).
 *
 *  Revision 1.2  2011/01/12 02:04:19  mwxxw
 *  Remove unused test case.
 *
 *  Revision 1.1  2011/01/12 01:26:56  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *  
 */
