/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.bridge;

/**
 * Description: I define common constants for EASE-> Bridge converters
 * 
 * File: IBridgeConverterConstants.java
 * Module:  gov.ca.dmv.ease.ecs.convert.bridge
 * Created: Dec 6, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IBridgeConverterConstants {
	/** The Constant ACTION_TYPE_LENGTH = 2. */
	int ACTION_TYPE_LENGTH = 2;
	/** The Constant AUTHORITY_SECTION_LENGTH = 7. */
	int AUTHORITY_SECTION_LENGTH = 7;
	String BCTR = "BCTR"; //TODO correct to use a descriptive name
	/** The BPRS. */
	String BPRS = "BPRS";//TODO correct to use a descriptive name
	/** The Constant BDRV. */
	String BDRV = "BDRV";//TODO correct to use a descriptive name
	/** The Constant CODE_WAIVED_LENGTH = 1. */
	int CODE_WAIVED_LENGTH = 1;
	/** The Constant CONVICTION_OR_EFFECTIVE_DATE_LENGTH = 8. */
	int CONVICTION_OR_EFFECTIVE_DATE_LENGTH = 8;
	/** The Constant COURT_CODE_LENGTH = 5. */
	int COURT_CODE_LENGTH = 5;
	/** The Constant DEFAULT_PROCESSOR_MNEMONIC. - the value is temporary for DL only */
	String DEFAULT_PROCESSOR_MNEMONIC = "@@";
	/** The Constant DISPOSITION_CODES_LENGTH = 9. */
	int DISPOSITION_CODES_LENGTH = 9;
	/** The Constant DL_REVIEW_RECORD_TCODE = "BDRV". */
	String DL_REVIEW_RECORD_TCODE = "BDRV";
	/** The Constant DL_REVIEW_RECORD_TCODE_LENGTH = 4. */
	int DL_REVIEW_RECORD_TCODE_LENGTH = 4;
	/** The Constant DOCKET_OR_CITATION_NUMBER_LENGTH = 7. */
	int DOCKET_OR_CITATION_NUMBER_LENGTH = 7;
	/** The Constant DRIVER_LICENSE_NUMBER_LENGTH = 8. */
	int DRIVER_LICENSE_NUMBER_LENGTH = 8;
	/** The Constant START_CODE_WAIVED_IX = 49. */
	String DUPLICATE_PHOTO_ACTION_CODE = "DP";
	/** The Constant END_NBR_OF_REVIEW_ACTIONS_IX = 33. (begin with index = 0) */
	int END_NBR_OF_REVIEW_ACTIONS_IX = 33;
	/** The Constant FEE_MARKER. */
	char FEE_MARKER = 'F';
	String FEE_WAIVED_ACTION_CODE = "FW";
	/** The Constant FIRST_3_OF_LAST_NAME_LENGTH = 3. */
	int FIRST_3_OF_LAST_NAME_LENGTH = 3;
	/** The Constant INVENTORY_MARKER. */
	char INVENTORY_MARKER = 'I';
	/** The Constant KEYER_S_ID_LENGTH = 2. */
	int KEYER_S_ID_LENGTH = 2;
	/** The Constant NO. */
	char NO = 'N';
	/** The Constant PAYMENT_MARKER. */
	char PAYMENT_MARKER = 'P';
	/** The Constant REFUND_MARKER. */
	char REFUND_MARKER = 'R';
	/** The Constant SPACE. */
	char SPACE = ' ';
	/** The Constant TX_MARKER. */
	char TX_MARKER = 'T';
	/** The Constant UNKNOWN. */
	char UNKNOWN = '?';
	/** The Constant YES. */
	char YES = 'Y';
	/** The Constant ZERO. */
	char ZERO = '0';
	/** The Constant string SPACE. */
	String SPACE_STRING = " ";
	/** The String double zeroes.*/
	String DOUBLE_ZEROES = "00";
	/** The TTC 04M. */
	String TTC_04M = "04M";
	/** The TTC 20M. */
	String TTC_20M = "20M";
	/** The TTC FCP. */
	String TTC_FCP = "FCP";
	/** The TTC SRX. */
	String TTC_SRX = "SRX";
	/** The TTC SPO. */
	String TTC_SPO = "SPO";
	/** The TTC_DLA. */
	String TTC_DLA = "DLA";
	/** The TTC DLC. */
	String TTC_DLC = "DLC";
	/** The TTC IDC. */
	String TTC_IDC = "IDC";
	/** The TTC SPC. */
	String TTC_SPC = "SPC";
	/** The TTC DLD.*/
	String TTC_DLD = "DLD";
	/** The TTC SPD.*/
	String TTC_SPD = "SPD";
	/** The TTC DLE. */
	String TTC_DLE = "DLE";
	/** The TTC DLP. */
	String TTC_DLP = "DLP";
	/** The TTC IDP. */
	String TTC_IDP = "IDP";
	/** The TTC SPR. */
	String TTC_SPR = "SPR";
	/** The TTC IDS. */
	String TTC_IDS = "IDS";
	/** The TTC DRT. */
	String TTC_DRT = "DRT";
	/** The TTC IRT. */
	String TTC_IRT = "IRT";
	/** The TTC SRT. */
	String TTC_SRT = "SRT";
	/** The TTC 06M. */
	String TTC_06M = "06M";
	/** The TTC 07M. */
	String TTC_07M = "07M";
	/** The TTC 12M. */
	String TTC_12M = "12M";
	/** The TTC 13M. */
	String TTC_13M = "13M";
	/** The TTC 14M. */
	String TTC_14M = "14M";
	/** The TTC 92M. */
	String TTC_92M = "92M";
	/** The TTC 98M. */
	String TTC_98M = "98M";
	/** The TTC DIR. */
	String TTC_DIR = "DIR";
	/** The Print class codes. */
	String DL_APP_MISC_RECEIPT_PRINT_CLASS_CODE = "64";
	/** Waiver Reason Code H: Reduced fee id. */
	String WAIVER_REASON_CODE_H = "H";
}
/**
 *  Modification History:
 *
 *  $Log: IBridgeConverterConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2011/06/23 18:29:38  mwhys
 *  Added DIR.
 *
 *  Revision 1.9  2011/06/02 22:58:25  mwxxw
 *  Add SPACE_STRING.
 *
 *  Revision 1.8  2011/04/22 22:47:59  mwxxw
 *  Add new constant: WAIVER_REASON_CODE_H.
 *
 *  Revision 1.7  2011/01/14 18:49:23  mwpxr4
 *  Added new TTC constants.
 *
 *  Revision 1.6  2011/01/03 01:26:28  mwpxr4
 *  More TTC constants added.
 *
 *  Revision 1.5  2010/12/24 19:43:06  mwpxr4
 *  Added FCP.
 *
 *  Revision 1.4  2010/12/24 04:51:53  mwpxr4
 *  Added 20M
 *
 *  Revision 1.3  2010/12/16 20:54:34  mwpxr4
 *  Added new constant.
 *
 *  Revision 1.2  2010/12/15 20:49:02  mwpxr4
 *  Added new contant.
 *
 *  Revision 1.1  2010/12/10 03:22:53  mwpxp2
 *  Moved in from DL
 *
 *  Revision 1.2  2010/12/06 21:42:44  mwpxp2
 *  Added entries from AbstractBridgeConverter
 *
 *  Revision 1.1  2010/12/06 21:41:22  mwpxp2
 *  Initial - extracted from implementation classes
 *
 */
