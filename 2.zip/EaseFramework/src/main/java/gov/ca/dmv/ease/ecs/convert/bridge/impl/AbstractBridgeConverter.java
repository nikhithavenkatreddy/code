/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.bridge.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageBridgeConverter;
import gov.ca.dmv.ease.ecs.convert.bridge.IBridgeConverterConstants;
import gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsNoResponseExpectedException;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.reader.IMessageFormatReader;
import gov.ca.dmv.ease.fw.format.reader.impl.MessageFormatReader;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Description: I am abstract superclass for converters applicable to outgoing messages to the DMVA bridge
 * File: AbstractBridgeConverter.java
 * Module:  gov.ca.dmv.ease.ecs.convert.bridge.impl
 * Created: Dec 2, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractBridgeConverter extends
		AbstractEcsMessageConverter implements IBridgeConverterConstants,
		IMessageBridgeConverter {
	/** The Constant CURRENCY_FORMAT. */
	protected static final NumberFormat CURRENCY_FORMAT = NumberFormat
			.getCurrencyInstance(Locale.US);
	protected static final SimpleDateFormat DATE_FORMAT6 = new SimpleDateFormat(
			"MMddyy");
	protected static final SimpleDateFormat DATE_FORMAT8 = new SimpleDateFormat(
			"MMddyyyy");
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3228095504932509213L;

	/**
	 * As currency amount no dollar prefix.
	 * 
	 * @param anAmount 
	 * 
	 * @return the string
	 */
	public static String asCurrencyAmountNoDollarPrefix(BigDecimal anAmount) {
		validateNotNull(anAmount, "BigDecimal amount");
		String withPrefix = CURRENCY_FORMAT.format(anAmount.abs());
		return withPrefix.substring(1);
	}

	/**
	 * Output.
	 * 
	 * @param aChar 
	 * @param aCount 
	 * @param aBuilder 
	 */
	protected static void output(char aChar, int aCount, StringBuilder aBuilder) {
		for (int i = 0; i < aCount; i++) {
			aBuilder.append(aChar);
		}
	}

	/**
	 * Output alpha.
	 * 
	 * @param aValue 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputAlpha(String aValue, int fieldSize,
			StringBuilder aBuilder) {
		if (aValue == null) {			
			for (int i = 0; i < fieldSize; i++) {
				aBuilder.append(SPACE);
			}
			return;
		}
		int aSize = aValue.length();
		if (aSize > fieldSize) {
			throw new EaseValidationException("Expected input with "
					+ fieldSize + " characters; got: \"" + aValue + "\"");
		}
		aBuilder.append(aValue);
		for (int i = 0; i < fieldSize - aSize; i++) {
			aBuilder.append(SPACE);
		}
	}

	/**
	 * Output alpha trimmed.
	 * 
	 * @param aValue 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputAlphaTrimmed(String aValue, int fieldSize,
			StringBuilder aBuilder) {
		if (aValue == null) {			
			for (int i = 0; i < fieldSize; i++) {
				aBuilder.append(SPACE);
			}
			return;
		}
		int aSize = aValue.length();
		String aTrimmedValue = aValue;
		if (aSize > fieldSize) {
			aTrimmedValue = aValue.substring(0, fieldSize);
		}
		outputAlpha(aTrimmedValue, fieldSize, aBuilder);
	}

	/**
	 * Output amount.
	 * 
	 * @param amount 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputAmount(BigDecimal amount, int fieldSize,
			StringBuilder aBuilder) {
		//$$$$$$.��
		if (amount == null) {
			outputNumber("0.00", fieldSize, aBuilder);
		}
		else {
			String aValue = asCurrencyAmountNoDollarPrefix(amount);
			if (aValue.contains(",")) {
				aValue = aValue.replace(",", "");
			}
			outputNumber(aValue, fieldSize, aBuilder);
		}
	}

	/**
	 * Output char.
	 * 
	 * @param aChar 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputChar(char aChar, int fieldSize,
			StringBuilder aBuilder) {
		aBuilder.append(aChar);
		for (int i = 0; i < fieldSize - 1; i++) {
			aBuilder.append(SPACE);
		}
	}

	/**
	 * Output date.
	 * 
	 * @param aDate 
	 * @param aFieldSize 
	 * @param aBuilder 
	 */
	protected static void outputDate(Date aDate, int aFieldSize,
			StringBuilder aBuilder) {
		validateNotNull(aDate, "date");
		if (aFieldSize == 6) {
			String aDateStr = DATE_FORMAT6.format(aDate);
			outputAlpha(aDateStr, 6, aBuilder);
		}
		else if (aFieldSize == 8) {
			String aDateStr = DATE_FORMAT8.format(aDate);
			outputAlpha(aDateStr, 8, aBuilder);
		}
		else {
			throw new EaseValidationException(
					"I can only process dates with field length of 6 or 8; got: "
							+ aFieldSize);
		}
	}

	/**
	 * Output date.
	 * 
	 * @param aBuilder 
	 * @param aDate 
	 */
	protected static void outputDate(Date aDate, StringBuilder aBuilder)
			throws EaseValidationException {
		validateNotNull(aDate, "date");
		String aDateStr = DATE_FORMAT8.format(aDate);
		outputAlpha(aDateStr, 8, aBuilder);
	}

	/**
	 * Output number.
	 * 
	 * @param anIntValue 
	 * @param aFieldSize 
	 * @param prefixFiller 
	 * @param aBuilder 
	 */
	protected static void outputNumber(int anIntValue, int aFieldSize,
			char prefixFiller, StringBuilder aBuilder) {
		String aValue = Integer.toString(anIntValue);
		int aSize = aValue.length();
		for (int i = 0; i < aFieldSize - aSize; i++) {
			aBuilder.append(prefixFiller);
		}
		aBuilder.append(aValue);
	}

	/**
	 * Output number.
	 * 
	 * @param anIntValue 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputNumber(int anIntValue, int fieldSize,
			StringBuilder aBuilder) {
		String aValue = Integer.toString(anIntValue);
		outputNumber(aValue, fieldSize, aBuilder);
	}

	/**
	 * Output number.
	 * 
	 * @param aValue 
	 * @param fieldSize 
	 * @param aBuilder 
	 */
	protected static void outputNumber(String aValue, int fieldSize,
			StringBuilder aBuilder) {
		int aSize = aValue.length();
		for (int i = 0; i < fieldSize - aSize; i++) {
			aBuilder.append(SPACE);
		}
		aBuilder.append(aValue);
	}

	/**
	 * Validate not null.
	 * 
	 * @param anObject 
	 * @param aMsg 
	 */
	protected static void validateNotNull(Object anObject, String aMsg) {
		if (anObject == null) {
			throw new EaseValidationException("not null value expected " + aMsg);
		}
	}

	/**
	 * Instantiates a new abstract bridge converter.
	 */
	public AbstractBridgeConverter() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter#createResponse(java.lang.String)
	 */
	@Override
	public IEcsResponse createResponse(String anInboundMessagePayload) {
		throw new EcsNoResponseExpectedException(
				"No response can be possibly provided in " + this);
	}

	/**
	 * Gets the message format.
	 * 
	 * @return the message format
	 */
	public IMessageFormat getMessageFormat() {
		String aFormatString = getMessageFormatString();
		if (aFormatString == null) {
			return null;
		}
		else {
			return getMessageFormatReader().readFrom(aFormatString);
		}
	}

	/**
	 * Gets the message format reader.
	 * 
	 * @return the message format reader
	 */
	private IMessageFormatReader getMessageFormatReader() {
		return new MessageFormatReader();
	}

	protected String getMessageFormatString() {
		return null; //this is default - subs may override
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.IMessageConverter#getMessageTcode()
	 */
	@Override
	public String getMessageTcode() {
		throw new EaseValidationException(
				"provide concreate implementation of getMessageTcode() in "
						+ this);
	}

	/**
	 * This method validates syntax of the  incoming Bridge Message payload. If the incoming
	 * message is invalid, an EaseBridgeMessageException is thrown.
	 * 
	 * @param bridgeMessage The String value of the DL bridge message.
	 * 
	 * @return void.
	 */
	public IErrorCollector validateBridgeMessage(String aPayload) {
		IMessageFormat aFormat = getMessageFormat();
		if (aFormat != null) {
			return aFormat.validate(aPayload);
		}
		else {
			return null;
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractBridgeConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2012/02/24 03:02:52  mwxxw
 *  Cleanup
 *
 *  Revision 1.12  2011/06/10 21:33:22  mwyxg1
 *  clean up
 *
 *  Revision 1.11  2011/01/15 00:32:49  mwhxb3
 *  outputDate throws EaseValidationException.
 *
 *  Revision 1.10  2011/01/11 02:28:16  mwpxr4
 *  Corrected code to remove comma from amounts.
 *
 *  Revision 1.9  2011/01/06 03:38:27  mwpxr4
 *  removed , from amts
 *
 *  Revision 1.8  2010/12/29 00:56:16  mwpxr4
 *  Corrected outputAlpha method - when string is null.
 *
 *  Revision 1.7  2010/12/23 06:10:40  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.6.2.2  2010/12/23 01:29:49  mwkkc
 *  Rebase from head - Arch
 *
 *  Revision 1.6  2010/12/16 20:25:32  mwpxp2
 *  Removed dead code
 *
 *  Revision 1.5  2010/12/14 04:46:59  mwpxr4
 *  Replaced UNKNOWN with SPACE
 *
 *  Revision 1.4  2010/12/13 20:02:32  mwpxp2
 *  Added getMessageTcode/0 throwing exception
 *
 *  Revision 1.3  2010/12/12 08:25:42  mwpxp2
 *  Added support for message format-based payload validation
 *
 *  Revision 1.2  2010/12/10 23:54:18  mwpxp2
 *  Added outputDate/3
 *
 *  Revision 1.1  2010/12/10 03:23:10  mwpxp2
 *  Moved in from DL
 *
 *  Revision 1.10  2010/12/09 02:17:38  mwpxp2
 *  Added DATE_FORMAT
 *
 *  Revision 1.9  2010/12/09 00:05:30  mwpxp2
 *  Added numberformat-based amount rendering
 *
 *  Revision 1.8  2010/12/08 19:33:13  mwpxp2
 *  Added throw EcsNoResponseExpectedException on createResponse/1
 *
 *  Revision 1.7  2010/12/06 21:43:23  mwpxp2
 *  Implemented IBridgeConverterConstants; moved constants to IBridgeConverterConstants
 *
 *  Revision 1.6  2010/12/06 20:34:06  mwpxp2
 *  Added DEFAULT_PROCESSOR_MNEMONIC; default createResponse/1
 *
 *  Revision 1.5  2010/12/04 00:41:33  mwpxp2
 *  Added a const
 *
 *  Revision 1.4  2010/12/03 22:35:33  mwpxp2
 *  Added outputAlphaTrimmed/3
 *
 *  Revision 1.3  2010/12/03 03:36:13  mwpxp2
 *  Added output for big decimal
 *
 *  Revision 1.2  2010/12/03 01:54:44  mwpxp2
 *  Cleanup
 *
 *  Revision 1.1  2010/12/03 01:52:04  mwpxp2
 *  Initial
 *
 */
