package gov.ca.dmv.ease.fw.service;

import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.io.Serializable;

/**
 * Description: I am a minimal  interface for all requests  
 * File: IRequest.java
 * Module:  gov.ca.dmv.ease.fw.request
 * Created: Jul 9, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRequest extends IWithUserContext, Serializable, IValidatable {
}
/**
 *  Modification History:
 * 
 *  $Log: IRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:24:35  mwpxp2
 *  Moved into fw.service; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/17 21:25:07  mwpxp2
 *  Extended IValidatable
 *
 *  Revision 1.3  2009/07/14 23:44:42  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 01:55:43  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-12 15:52:20  ppalacz
 *  Initial
 *
 */
