/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.util.impl;

import java.io.UnsupportedEncodingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I decode a 3270 stream, I take input in EBCIDIC format.
 * File: Decoder3270.java
 * Module:  gov.ca.dmv.ease.ecs.util.impl
 * Created: Aug 31, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Decoder3270 {
	/** The constant ATTR_DISP_HIDE. */
	private static final char ATTR_DISP_HIDE = 0x0C;
	/** The constant ATTR_DISP_HIGH. */
	private static final char ATTR_DISP_HIGH = 0x08;
	/** The constant ATTR_DISP_NORM. */
	private static final char ATTR_DISP_NORM = 0x04;
	/** The constant ATTR_MASK_A_N. */
	private static final char ATTR_MASK_A_N = 0x10;
	/** The constant ATTR_MASK_DISP. */
	private static final char ATTR_MASK_DISP = 0x0C;
	/** The constant ATTR_MASK_U_P. */
	private static final char ATTR_MASK_U_P = 0x20;
	/** Logger for this class. */
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(Decoder3270.class);
	/** The constant ORDER_ETX. */
	private static final char ORDER_ETX = 0x03;
	/** The constant ORDER_IC. */
	private static final char ORDER_IC = 0x13;
	/** The constant ORDER_RTF. */
	private static final char ORDER_RTF = 0x3C;
	/** The constant ORDER_SBA. */
	private static final char ORDER_SBA = 0x11;
	/** The constant ORDER_SF. */
	private static final char ORDER_SF = 0x1D;
	/** The constant ORDER_STX. */
	private static final char ORDER_STX = 0x02;
	/** The Constant STRIP_SIGN_MASK. */
	private static final int STRIP_SIGN_MASK = 0xFF; // to strip off leading sign bits
	/** The E2A_ARRAY. */
	private static char[] E2A_ARRAY;
	
	/**
	 * Decodes the input string.
	 * @param input the input string
	 * @return result the result string
	 */
	public static String decode(String input) {
		StringBuilder strBuilder = new StringBuilder();
		String line = null;
		String result = null;
		int position = 1;
		int repPosition = 0;
		int newPosition = 0;
		boolean firstSba = true;
		byte storeChar;
		byte currentAttribute = 1; // 0 = non-display, 1 = normal, 2 = bold
		int positionHigh, positionLow = 0;
		int ic = 0;
		int i = 0;
		int j = 0;
		int bufStart = 0;
		int bufEnd = 0;
		byte[] screenText = new byte[1920];
		byte[] attribute = new byte[1920];
		StringBuilder blankLine = new StringBuilder();
		//Create blank line 
		for (i = 0; i < 80; i++) {
			blankLine.append(' ');
		}
		// Clear Full Screen and Attributes
		for (i = 0; i < 1920; i++) {
			screenText[i] = 0x40;
			attribute[i] = 1;
		}
		/*
		// Bypass initial WCC found on some ECS responses
		// 0xC5 0x40 0x11
		if ((input.charAt(0) == -59) && (input.charAt(1) == 64)
				&& (input.charAt(2) == 29)) {
			buf_start = 2;
		}
		*/
		// Bypass initial WCC found on some ECS responses
		// 0x## 0x## 0x1D 
		if ((input.charAt(2) & 0x00FF) == 0x1D) {
			bufStart = 2;
			position = 0;
		}
		bufEnd = input.length();
		// Begin Parsing 3270 Buffer
		for (i = bufStart; i < bufEnd; i++) {
			// Toss record if a bad position is calculated
			if (position >= 1920) {
				break;
			}
			// If we get beyond Position 10 without an SBA, assume we got one
			if (firstSba && position > 9) {
				firstSba = false;
			}
			switch (input.charAt(i) & 0x00FF) {
			case ORDER_SBA:
				//ORDER_SBA  
				// 3 bytes (ORDER_SBA Position1 Position2)
				// Decode Row-Col from Position1 & Position2 values
				positionHigh = input.charAt(++i) & 0x3f;
				positionLow = input.charAt(++i) & 0x3f;
				newPosition = positionHigh * 64 + positionLow;
				//System.err.println("SBA:"+NewPosition+" Current:"+Position);
				/*
				// If Position moves back more than 10 after first SBA, we will assume
				// it's time to stop.                           
				if (!(newPosition - position < -10) || firstSBA) {
					position = newPosition;
				}
				else {
					i = buf_end;
				}
				*/
				// If Position moves to less than 10, we will assume
				// it's time to stop unless IC follows SBA.                             
				if (!firstSba && (input.charAt(i + 1) & 0x00FF) != 0x13) {
					if (newPosition < 9) {
						i = bufEnd;
					}
					else {
						position = newPosition;
					}
				}
				firstSba = false;
				break;
			case ORDER_SF:
				//ORDER_SF
				// 2 bytes (ORDER_SF ATTR)
				i++;
				// Store ATTR bits  
				// Don�t do anything with them here, just store them
				// DMVA ECS Inquiry ignores the ATRIBUTE bytes
				switch (input.charAt(i) & 0x0C) {
				case 0:
					currentAttribute = 1; // Display
					break;
				case 4:
					currentAttribute = 1; // Display
					break;
				case 8:
					currentAttribute = 2; // Bold Display
					break;
				case 10:
					currentAttribute = 0; // Non-Display
					break;
				default:
					currentAttribute = 1; // Display
					break;
				}
				screenText[position] = 0x40;
				attribute[position++] = currentAttribute;
				break;
			case ORDER_IC:
				// ORDER_IC
				// One byte (ORDER_IC)
				// Show where cursor is positioned (Equivalent to setting the focus)
				// Just ignore them.
				ic = position;
				break;
			case ORDER_ETX:
				// ORDER_ETX
				// One byte (ORDER_ETX)
				// ETX - End-of-Text mark, message complete
				// ETX may appear before MsgLen, ETX takes precedence
				// If Field Len non-zero, complete field accumulation
				//*******************************************************
				//* Some ECS Responses contain 0x03 embedded in the middle
				//* of the response. We just ignore them.
				//*******************************************************                     
				//i= buf_end; // Force End
				//System.err.println("ETX");
				break;
			case ORDER_RTF:
				//ORDER_RTF
				// Three byte (ORDER_RTF) - Repeat to Field
				// 2 bytes of Repeat to Address, 1 byte Repeated Character
				positionHigh = input.charAt(++i) & 0x3f;
				positionLow = input.charAt(++i) & 0x3f;
				repPosition = positionHigh * 64 + positionLow;
				storeChar = (byte) input.charAt(++i);
				if (storeChar == 0) {
					storeChar = 0x40;
				}
				for (j = position; j < repPosition; j++) {
					screenText[position++] = storeChar;
				}
				break;
			default:
				// Place EBCDIC Text in the Screen Text Buffer
				if (i < bufEnd) {
					storeChar = (byte) input.charAt(i);
					if (storeChar == 0) {
						storeChar = 0x40;
					}
					if (storeChar == 0x6F) {
						storeChar = 0x40;
					}
					attribute[position] = currentAttribute;
					screenText[position++] = storeChar;
				}
				break;
			}
		}
		// Convert EBCDIC to ASCII
		/*try {
			//The String constructor with character set "Cp1047" does not work
			//Hence, using custom converter 
			line = new String(screenText, "Cp1047");
			
		}
		catch (UnsupportedEncodingException e) {
			throw new EaseValidationException(e);
		}*/
		line = getEbcdicByteArrayAsString(screenText);
		// Replace MORE with blank line
		for (i = 0; i < 24; i++) {
			// End when we hit "** MORE **" in the output string
			if ((line.substring(i * 80, i * 80 + 80).contains("** MORE **"))
					|| (line.substring(i * 80, i * 80 + 80)
							.contains("** M O R E **"))
					|| (line.substring(i * 80, i * 80 + 80)
							.contains("* * MORE * *"))
					|| (line.substring(i * 80, i * 80 + 80)
							.contains(" MORE                                               "))
					|| (line.substring(i * 80, i * 80 + 80)
							.contains("MORE RECORDS MATCH CRITERIA"))) {
				strBuilder.append(blankLine.toString());
			}
			else {
				strBuilder.append(line.substring(i * 80, i * 80 + 80));
			}
			//System.out.println(line.substring(i*80,i*80+80));
		}
		result = strBuilder.toString();
		LOGGER.debug("decode(String) - LENGTH OF SCREEN = " + result.length()
				+ " LENGTH OF LINE = " + line.length());
		return result;
	}
	
	/**
	 * Decodes (Version1) the input string.
	 * @param input the input string
	 * @return result the result string
	 */
	public static String decodeVersion1(String input) {
		char[] screenText = new char[1920];
		int position = 0;
		int positionHigh = 0;
		int positionLow = 0;
		char ch;
		for (int i = 0; i < 1920; i++) {
			screenText[i] = ' ';
		}
		for (int i = 0; i < input.length(); i++) {
			if (position > 1920) {
				// Toss record if a bad position is calculated	
				break;
			}
			else {
				switch (input.charAt(i)) {
				case ORDER_SBA:
					// 3 bytes (ORDER_SBA Position1 Position2)
					// Decode Row-Col from Position1 & Position2 values
					positionHigh = input.charAt(++i) & 0x3f;
					positionLow = input.charAt(++i) & 0x3f;
					position = positionHigh * 64 + positionLow;
					break;
				case ORDER_SF:
					// 2 bytes (ORDER_SF ATTR)
					i++;
					// Store ATTR bits  (I don�t do anything with them here, just store them)
					//What to do with attributes
					//Attribute[Position]=E3270Binary[i];
					break;
				case ORDER_IC:
					// One byte (ORDER_IC)
					// Show where cursor is positioned (Equivalent to setting the focus)
					// You probably won�t see these in DCS INQUIRY responses, and if you do, just ignore them.
					//What to do with cursor
					//IC = Position;
					break;
				case ORDER_ETX:
					// One byte (ORDER_ETX)
					// ETX - End-of-Text mark, message complete
					// ETX may appear before MsgLen, ETX takes precedence
					// If Field Len non-zero, complete field accumulation
					i = input.length() + 1; // Force End
					break;
				case ORDER_RTF:
					// Three byte (ORDER_RTF) - Repeat to Field
					i = input.length() + 1; // Force End
					// Ignore this ORDER for now. It only appears to be used
					// to null the end of an error output line.
					i += 2;
					break;
				default:
					// Place EBCDIC Text in the Screen Text Buffer
					ch = toAscii(input.charAt(i));
					if (ch == 'n') {
						ch = ' ';
					}
					screenText[position++] = ch;
					break;
				}
			}
		}
		String screen = new String(screenText);
		return screen;
	}
	
	/**
	 * Formats the input screen message.
	 * @param screen the screen string
	 * @return the formatted screen
	 */
	public static String formatScreen(String screen) {
		StringBuilder sBuilder = new StringBuilder();
		for (int i = 0; i < 1920; i++) {
			if ((i + 1) % 80 != 0) {
				sBuilder.append(screen.charAt(i));
			}
			else {
				sBuilder.append("\n");
			}
		}
		return sBuilder.toString();
	}
	
	/**
	 * Gets the ebcdic to ascii array.
	 *
	 * @return the ebcdic to ascii array
	 */
	private static char[] getEbcdicToAsciiArray() {
		if (E2A_ARRAY == null) {
			initEbcdicToAsciiArray();
		}
		return E2A_ARRAY;
	}
	
	/**
	 * Inits the ebcdic to ascii array.
	 */
	private static void initEbcdicToAsciiArray() {
		E2A_ARRAY = new char[] { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				' ', ' ', ' ', ' ', ' ', ' ', ' ', /* 00 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				' ', ' ', ' ', ' ', /* 10 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				' ', ' ', ' ', ' ', /* 20 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				' ', ' ', ' ', ' ', /* 30 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.',
				'<', '(', '+', '|', /* 40 */
				'&', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '!', '$',
				'*', ')', ';', '~', /* 50 */
				'-', '/', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '|', ',',
				'%', '_', '>', '?', /* 60 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ':', '#',
				'@', '\'', '=', '"', /* 70 */
				' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', ' ', ' ',
				' ', ' ', ' ', ' ', /* 80 */
				' ', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', ' ', ' ',
				' ', ' ', ' ', ' ', /* 90 */
				' ', '~', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ' ', ' ',
				' ', ' ', ' ', ' ', /* a0 */
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				' ', ' ', ' ', ' ', /* b0 */
				'{', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', ' ', ' ',
				' ', ' ', ' ', ' ', /* c0 */
				'}', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', ' ', ' ',
				' ', ' ', ' ', ' ', /* d0 */
				'\\', ' ', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', ' ',
				' ', ' ', ' ', ' ', /* e0 */
				'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', ' ',
				' ', ' ', ' ', ' ' };/* f0 */
	}
	
	/**
	 * Gets the ebcdic byte array as string.
	 *
	 * @param ebcdic the ebcdic
	 * @return the string
	 */
	public static String getEbcdicByteArrayAsString(byte[] ebcdic) {
		StringBuffer sb = new StringBuffer(ebcdic.length);
		for (int i = 0; i < ebcdic.length; i++) {
			sb.append(getEbcdicToAsciiArray()[ebcdic[i] & STRIP_SIGN_MASK]);
		}
		return sb.toString();
	}
	
	/**
	 * Converts to ASCII.
	 * @param txt the character text
	 * @return the converted character text
	 */
	private static char toAscii(char txt) {
		byte[] byteMsg = new byte[1];
		byteMsg[0] = (byte) txt;
		String tranMsg = null;
		try {
			tranMsg = new String(new String(byteMsg, "Cp1047")
					.getBytes("8859_1"));
		}
		catch (UnsupportedEncodingException e) {
			LOGGER.error("toAscii(char)", e);
		}
		return tranMsg.charAt(0);
	}
	
	/**
	 * Converts the input message string to ASCII.
	 * @param inputMsg the input message
	 * @return the converted message
	 */
	private static char toAscii(String inputMsg) {
		byte[] byteMsg = inputMsg.getBytes();
		String tranMsg = null;
		try {
			tranMsg = new String(new String(byteMsg, "Cp1047")
					.getBytes("8859_1"));
		}
		catch (UnsupportedEncodingException e) {
			LOGGER.error("toAscii(String)", e);
		}
		return tranMsg.charAt(0);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Decoder3270.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2012/08/15 23:17:41  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.9  2011/11/04 23:03:28  mwhys
 *  Use custom converter to convert a byte from EBCDIC to ASCII (instead of Cp1047). (UAT Defect 1070)
 *
 *  Revision 1.8  2011/03/23 23:46:57  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.7  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.6  2010/03/22 23:27:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/01/14 18:31:23  mwpzs3
 *  move to JCL logging
 *
 *  Revision 1.4  2009/12/14 23:47:40  mwrrv3
 *  As per Prakash and Paula, I have checked-in the code to fix the IT defect# 1042 (formatting issue) and UAT defect# 11 (remove special character).
 *
 *  Revision 1.3  2009/12/09 19:36:43  mwpxp2
 *  Replaced system.outs with logging
 *
 *  Revision 1.2  2009/12/02 00:52:36  mwrrv3
 *  Added code to handle new MORE message from response.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/14 21:02:07  mwhxb3
 *  updated comments
 *
 *  Revision 1.7  2009/10/14 17:14:13  mwhxb3
 *  updated comments
 *
 *  Revision 1.6  2009/10/14 01:28:28  mwrrv3
 *  Checked in the changes on behalf of Prakash.
 *
 *  Revision 1.5  2009/10/08 18:17:13  mwcsj3
 *  Cleaned todo's
 *
 *  Revision 1.4  2009/10/03 21:23:41  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/15 00:47:52  mwpzs3
 *  Another version of more removed
 *
 *  Revision 1.2  2009/09/08 22:21:21  mwpzs3
 *  Update on decoder, handling attributes, WCC,ETX and  MORE
 *
 *  Revision 1.1  2009/09/01 00:30:48  mwpzs3
 *  3270 Convertor initial version
 *
 */
