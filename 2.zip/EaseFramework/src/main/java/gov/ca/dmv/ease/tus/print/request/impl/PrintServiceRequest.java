/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.print.converter.IDocumentConverter;
import gov.ca.dmv.ease.tus.print.request.IPrintServiceRequest;
import gov.ca.dmv.ease.tus.print.response.impl.PrintServiceResponse;
import gov.ca.dmv.ease.tus.print.service.impl.PrintService;

/**
 * Description: This is abstract class to encapsulate Print Service Request Functionality 
 * File: PrintServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: Aug 05, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class PrintServiceRequest extends AbstractPrintServiceRequest
		implements IPrintServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3308222089537613395L;
	/** The Document Converter. */
	private IDocumentConverter documentConverter;

	/**
	 * Instantiates a new Print Service request.
	 * 
	 * @param aContext the a context
	 */
	public PrintServiceRequest(IUserContext aContext) {
		super(aContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest#execute()
	 */
	@Override
	public PrintServiceResponse execute() {
		return PrintService.execute(this);
	}

	/**
	 * Gets the Document Converter.
	 * 
	 * @return the documentConverter
	 */
	public IDocumentConverter getDocumentConverter() {
		return documentConverter;
	}
//
//	/* (non-Javadoc)
//	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#getValidator()
//	 */
//	@Override
//	abstract protected IValidator getValidator();

	/**
	 * Sets the Document Converter.
	 * 
	 * @param documentConverter the Document Converter
	 */
	public void setDocumentConverter(IDocumentConverter aConverter) {
		documentConverter = aConverter;
	}
}
/**
 *  Modification History:
 *	
 *  $Log: PrintServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.18  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.17  2010/07/22 23:11:08  mwhxa2
 *  Changes to implement Resubmit Print Job
 *
 *  Revision 1.16  2010/07/21 18:17:50  mwpxp2
 *  Removed unnecessary override of validate
 *
 *  Revision 1.15  2010/06/29 18:21:45  mwhxa2
 *  Print now uses data from User Context to find the printer
 *
 *  Revision 1.14  2010/06/21 23:00:43  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.12.6.2  2010/06/20 18:06:55  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.13  2010/06/07 17:14:10  mwpxp2
 *  Added fixme; removed unnecessary t!his.es; bulk cleanup
 *
 *  Revision 1.12  2010/05/07 18:12:26  mwhxa2
 *  Print Service changes
 *
 *  Revision 1.10  2010/05/03 16:17:10  mwrsk
 *  Changed from convertToDocument to convertToDocumentBinding
 *
 *  Revision 1.9  2010/04/27 18:04:35  mwrsk
 *  Changes related to DocumentConverters extending from AbstractDocumentConverter
 *
 *  Revision 1.8  2010/04/26 17:58:27  mwrsk
 *  Add skeleton to suit the printing with HP Output server
 *
 *  Revision 1.7  2010/03/22 23:39:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/02/10 18:26:54  mwhxa2
 *  Added validator
 *
 *  Revision 1.5  2010/02/09 19:07:19  mwhxa2
 *  Updated Composite Print Request Functionality
 *
 *  Revision 1.4  2010/02/09 00:58:04  mwhxa2
 *  Added executePreprocessForCompositeRequest()
 *
 *  Revision 1.3  2010/02/08 17:42:35  mwrrv2
 *  Now extends Synchronous ECS Request
 *
 *  Revision 1.2  2010/02/04 22:51:00  mwhxa2
 *  Updated Print Service Request
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/14 01:30:27  mwjxa11
 *  Refactored
 *
 *  Revision 1.6  2009/10/03 21:32:41  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/09/01 01:02:48  mwjxa11
 *  Removed the unused constructor and its respective getter methods.
 *
 *  Revision 1.4  2009/08/27 03:33:21  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/27 01:41:48  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.2  2009/08/26 00:56:37  mwjxa11
 *  Removed the setter methods from this request class.
 *
 *  Revision 1.1  2009/08/10 21:10:00  mwjxa11
 *  Updated with the DocumentToken, Primary and Alternate printer details.
 *
 */
