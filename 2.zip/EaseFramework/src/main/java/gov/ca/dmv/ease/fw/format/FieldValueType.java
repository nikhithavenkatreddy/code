/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.format.impl.PayloadSampleProducer;

import java.util.List;

/**
 * Description: I list available (one char) indications of  field type
 * File: FieldValueType.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum FieldValueType {
	/** The ALPHA. */
	ALPHA,
	/** The ALPHANUM. */
	ALPHANUM,
	/** The ANY. */
	ANY,
	/** The NUMERIC. */
	NUMERIC,
	/** The SPACE. */
	SPACE,
	/** The UNKNOWN. */
	UNKNOWN;
	/**
	 * Char for type.
	 * 
	 * @param aType 
	 * 
	 * @return the char
	 */
	public static char charForType(FieldValueType aType) {
		if (aType == UNKNOWN) {
			return '?';
		}
		if (aType == ALPHA) {
			return 'A';
		}
		if (aType == NUMERIC) {
			return 'N';
		}
		if (aType == SPACE) {
			return 'Z';
		}
		if (aType == ANY) {
			return 'Y';
		}
		return '?';
	}

	/**
	 * Gets the field type form allowed value.
	 * 
	 * @param anAllowedValue 
	 * 
	 * @return the field type form allowed value
	 */
	public static FieldValueType getFieldTypeFormAllowedValue(
			String anAllowedValue) {
		if (anAllowedValue == null) {
			return UNKNOWN;
		}
		if (anAllowedValue.length() == 0) {
			return UNKNOWN;
		}
		if (hasWhitespaceOnly(anAllowedValue)) {
			return SPACE;
		}
		if (hasAlphaOnly(anAllowedValue)) {
			return ALPHA;
		}
		if (hasDigitsOnly(anAllowedValue)) {
			return NUMERIC;
		}
		if (hasAlphaAndDigitsOnly(anAllowedValue)) {
			return ALPHANUM;
		}
		return ANY;
	}

	public static FieldValueType getFieldTypeFormAllowedValues(
			List <String> valueList) {
		// TODO Auto-generated method stub
		return null;
	}

	public static FieldValueType getFieldTypeFormAllowedValues(String[] valueArr) {
		if (valueArr == null) {
			return UNKNOWN;
		}
		if (valueArr.length == 0) {
			return UNKNOWN;
		}
		if (hasWhitespaceOnly(valueArr)) {
			return SPACE;
		}
		if (hasAlphaOnly(valueArr)) {
			return ALPHA;
		}
		if (hasDigitsOnly(valueArr)) {
			return NUMERIC;
		}
		if (hasAlphaAndDigitsOnly(valueArr)) {
			return ALPHANUM;
		}
		return ANY;
	}

	public static String getRandomCorrectSample(int nextRandom,
			FieldValueType targetType, int aSize) {
		return PayloadSampleProducer.getRandomCorrectSample(targetType, aSize);
	}

	public static String getRandomIncorrectSample(int nextRandom,
			FieldValueType excluded, int aSize) {
		if (excluded == ANY) {
			throw new EaseValidationException(
					"Not possible to provide incorrect sample for ANY");
		}
		if (excluded == UNKNOWN) {
			throw new EaseValidationException(
					"Not possible to provide incorrect sample for UNKNOWN");
		}
		if (excluded == ALPHA) {
			return getRandomCorrectSample(nextRandom, NUMERIC, aSize);
		}
		if (excluded == NUMERIC) {
			return getRandomCorrectSample(nextRandom, ALPHA, aSize);
		}
		if (excluded == ALPHANUM) {
			return getRandomCorrectSample(nextRandom, SPACE, aSize);
		}
		throw new EaseValidationException("Unrecognized type: " + excluded);
	}

	protected static int getTypeCount() {
		return getTypesArr().length;
	}

	protected static FieldValueType[] getTypesArr() {
		//adjust when adding /removing to the enum
		return new FieldValueType[] { ALPHA, ALPHANUM, ANY, NUMERIC, SPACE,
				UNKNOWN };
	}

	/**
	 * Checks for alpha and digits only.
	 * 
	 * @param anAllowedValue 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasAlphaAndDigitsOnly(String anAllowedValue) {
		int size = anAllowedValue.length();
		char aChar;
		for (int i = 0; i < size; i++) {
			aChar = anAllowedValue.charAt(i);
			if (!Character.isLetter(aChar) && !Character.isDigit(aChar)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for alpha and digits only.
	 * 
	 * @param valueArr 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasAlphaAndDigitsOnly(String[] valueArr) {
		for (int i = 0; i < valueArr.length; i++) {
			if (!hasAlphaAndDigitsOnly(valueArr[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for alpha only.
	 * 
	 * @param anAllowedValue 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasAlphaOnly(String anAllowedValue) {
		int size = anAllowedValue.length();
		char aChar;
		for (int i = 0; i < size; i++) {
			aChar = anAllowedValue.charAt(i);
			if (!Character.isLetter(aChar)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for alpha only.
	 * 
	 * @param valueArr 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasAlphaOnly(String[] valueArr) {
		for (int i = 0; i < valueArr.length; i++) {
			if (!hasAlphaOnly(valueArr[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for digits only.
	 * 
	 * @param anAllowedValue 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasDigitsOnly(String anAllowedValue) {
		int size = anAllowedValue.length();
		char aChar;
		for (int i = 0; i < size; i++) {
			aChar = anAllowedValue.charAt(i);
			if (!Character.isDigit(aChar)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for digits only.
	 * 
	 * @param valueArr 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasDigitsOnly(String[] valueArr) {
		for (int i = 0; i < valueArr.length; i++) {
			if (!hasDigitsOnly(valueArr[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for whitespace only.
	 * 
	 * @param anAllowedValue 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasWhitespaceOnly(String anAllowedValue) {
		int size = anAllowedValue.length();
		char aChar;
		for (int i = 0; i < size; i++) {
			aChar = anAllowedValue.charAt(i);
			if (!Character.isWhitespace(aChar)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for whitespace only.
	 * 
	 * @param valueArr 
	 * 
	 * @return true, if successful
	 */
	private static boolean hasWhitespaceOnly(String[] valueArr) {
		for (int i = 0; i < valueArr.length; i++) {
			if (!hasDigitsOnly(valueArr[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Type for char.
	 * 
	 * @param aChar 
	 * 
	 * @return the field value type
	 */
	public static FieldValueType typeForChar(char aChar) {
		char toUpper = Character.toUpperCase(aChar);
		if (toUpper == '?') {
			return UNKNOWN;
		}
		if (toUpper == 'A') {
			return ALPHA;
		}
		if (toUpper == 'N') {
			return NUMERIC;
		}
		if (toUpper == 'Z') {
			return SPACE;
		}
		if (toUpper == 'Y') {
			return ANY;
		}
		return UNKNOWN;
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldValueType.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2010/12/01 01:50:55  mwpxp2
 *  Adjusted imports for rename
 *
 *  Revision 1.5  2010/11/29 07:42:18  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.4  2010/11/25 00:52:03  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.3  2010/11/24 20:38:49  mwpxp2
 *  Added utility conversion methods
 *
 *  Revision 1.2  2010/11/20 22:50:42  mwpxp2
 *  modified charForType to use upper case
 *
 *  Revision 1.1  2010/11/20 21:20:17  mwpxp2
 *  Initial
 *
 */
