/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.constants;

/**
 * Description: I specify constants used in exceptions and validations.
 * File: IErrorMessageConstants.java
 * Module:  gov.ca.dmv.ease.service.exception
 * Created: 07/05/2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IErrorMessageConstants {
	/** The CLIENT_REQUEST_MSG. */
	String CLIENT_REQUEST_MSG = "Client Request";
	/** The EXPECTED_ARG_TYPE. */
	String EXPECTED_ARG_TYPE = "Unexpected type; expected: ";
	/** The INCOMING_MSG. */
	String INCOMING_MSG = "Incoming JMS Message";
	/** The OUTCOMING_MSG. */
	String OUTCOMING_MSG = "Outgoing JMS Message";
	/** The RESPONSE_TO_CLIENT_MSG. */
	String RESPONSE_TO_CLIENT_MSG = "Response to Client";
}
/**
 *  Modification History:
 * 
 *  $Log: IErrorMessageConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/13 18:20:29  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/07/16 01:49:55  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/07/16 01:04:46  mwpxp2
 *  Bulk cleanup, including imports
 *
 *  Revision 1.3  2009/07/14 23:58:53  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:07:44  ppalacz
 *  Javadoc
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.5  2009-05-11 19:43:32  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.2  2009-05-10 19:39:09  mwpxp2
 *  Added EXPECTED_ARG_TYPE
 *
 *  Revision 1.1  2009-05-08 05:44:08  mwpxp2
 *  synch
 *
*/
