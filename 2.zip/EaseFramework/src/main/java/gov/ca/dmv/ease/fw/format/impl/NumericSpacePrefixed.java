/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

/**
 * Description: I represent fields containing digits only, potentially prefixed with spaces
 * File: NumericSpacePrefixed.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 28, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class NumericSpacePrefixed extends PatternedFieldFormat {
	/**
	 * @param startPos
	 * @param len
	 * @param typeChar
	 */
	public NumericSpacePrefixed(int startPos, int len, char typeChar) {
		super(startPos, len, typeChar);
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 301921600900617136L;

	/**
	 * Instantiates a new numeric space prefixed.
	 * 
	 * @param repCount 
	 */
	public NumericSpacePrefixed(int repCount) {
		super(UNDEF_POS, repCount);
	}

	/**
	 * 
	 * 
	 * @param startPos 
	 * @param len 
	 */
	public NumericSpacePrefixed(int startPos, int len) {
		super(startPos, len);
	}

	/**
	 * Instantiates a new numeric space prefixed.
	 * 
	 * @param startPos 
	 * @param repCount 
	 * @param aName 
	 */
	public NumericSpacePrefixed(int startPos, int repCount, String aName) {
		super(startPos, repCount, aName);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample(int)
	 */
	@Override
	public String getRandomCorrectSample(int aRandom) {
		int len = getLength();
		StringBuffer aBuffer = new StringBuffer(len);
		char aChar = getRandomDigit(aRandom);
		for (int i = 0; i < len; i++) {
			aBuffer.append(aChar);
		}
		return aBuffer.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample(int)
	 */
	@Override
	public String getRandomIncorrectSample(int random) {
		int len = getLength();
		StringBuffer aBuffer = new StringBuffer(len);
		char aChar = getRandomUpperCaseChar(random);
		for (int i = 0; i < len; i++) {
			aBuffer.append(aChar);
		}
		return aBuffer.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: NumericSpacePrefixed.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/12/16 03:18:28  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.2  2010/12/14 02:46:32  mwpxp2
 *  Added code for valid and invalid value generation
 *
 *  Revision 1.1  2010/11/29 07:42:48  mwpxp2
 *  Initial
 *
 */
