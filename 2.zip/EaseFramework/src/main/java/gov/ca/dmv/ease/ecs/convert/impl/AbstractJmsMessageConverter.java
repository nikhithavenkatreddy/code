/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import gov.ca.dmv.ease.ecs.constants.IEcsConstants;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsResponseIsNullException;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.fw.exception.impl.EasePreconditionViolationException;

import java.io.UnsupportedEncodingException;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

/**
 * Description: I am an abstract converter.
 * File: AbstractJmsMessageConverter.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Sep 10, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/09/03 18:02:29 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class AbstractJmsMessageConverter implements MessageConverter,
		IEcsConstants {
	/** correlaton id in hexadecimal starts with [ID:] so ignoring first 3 characters. */
	protected static final int BEGIN = 3;
	/** The length of the header in the response */
	protected static final int RESPONSE_HEADER_LENGTH = 248;

	/**
	 * Bytes message to ebcidic string.
	 * This utility function helps creating an EBCIDIC buffer of an in-bound BytesMessage
	 * 
	 * @param retValue the ret value
	 * @param recvBytes the recv bytes
	 * 
	 * @throws JMSException the JMS exception
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	public static void bytesMessageToEbcidicString(StringBuilder retValue,
			BytesMessage recvBytes) throws JMSException,
			UnsupportedEncodingException {
		long foo = recvBytes.getBodyLength();
		Long foo2 = new Long(foo);
		byte[] byteMsg = new byte[foo2.intValue()];
		recvBytes.readBytes(byteMsg);
		int cnt = 0;
		for (byte bitMsg : byteMsg) {
			if (bitMsg == 0) {
				byteMsg[cnt] = 64;
			}
			cnt++;
		}
		String tranMsg = new String(byteMsg, "Cp1047");
		//.getBytes("8859_1"));
		retValue.append(tranMsg);
	}

	/**
	 * Bytes message to string.
	 * This utility function helps creating an ASCII buffer of an in-bound BytesMessage
	 * 
	 * @param retValue the ret value
	 * @param recvBytes the recv bytes
	 * 
	 * @throws JMSException the JMS exception
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	public static void bytesMessageToString(StringBuilder retValue,
			BytesMessage recvBytes) throws JMSException,
			UnsupportedEncodingException {
		long foo = recvBytes.getBodyLength();
		Long foo2 = new Long(foo);
		byte[] byteMsg = new byte[foo2.intValue()];
		recvBytes.readBytes(byteMsg);
		int cnt = 0;
		for (byte bitMsg : byteMsg) {
			if (bitMsg == 0) {
				byteMsg[cnt] = 64;
			}
			cnt++;
		}
		String tranMsg = new String(new String(byteMsg, "Cp1047")
				.getBytes("8859_1"));
		retValue.append(tranMsg);
	}

	/**
	 * The Constructor- instantiates a new converter.
	 */
	public AbstractJmsMessageConverter() {
		super();
	}

	/**
	 * Convert.
	 * 
	 * @param aMessage the a message
	 * 
	 * @return the i ecs response
	 */
	protected abstract IEcsResponse convert(Message aMessage);

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#fromMessage(javax.jms.Message)
	 */
	public IEcsResponse fromMessage(Message aMessage) {
		validateReceivedMessage(aMessage);
		try {
			return convert(aMessage);
		}
		catch (MessageConversionException ee) {
			throw new EcsMessageConversionException(ee);
		}
	}

	/**
	 * Text message to string.
	 * This utility function helps creating an ASCII buffer of an in-bound TextMessage
	 * 
	 * @param retValue the ret value
	 * @param receivedMessage the received message
	 * 
	 * @throws JMSException the JMS exception
	 */
	public void textMessageToString(StringBuilder aBuffer,
			TextMessage receivedMessage) throws JMSException {
		aBuffer.append(receivedMessage.getText().toString());
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	public Message toMessage(Object arg0, Session arg1) throws JMSException,
			MessageConversionException {
		throw new EasePreconditionViolationException(
				"Should not call this method - the concrete subclass must provide implementation.");
		// We are using message creator in place of this!
		//return null;
	}

	/**
	 * Validate payload.
	 * 
	 * @param aPayload the a payload
	 */
	protected void validatePayload(String aPayload) {
		if (aPayload == null) {
			throw new EcsResponseIsNullException("null response in " + this);
		}
		if (aPayload.length() == 0) {
			throw new EcsResponseIsNullException("empty response in " + this);
		}
		if (aPayload.trim().equals("")) {
			throw new EcsResponseIsNullException("blank response in " + this);
		}
	}

	/**
	 * Validate payload.
	 * 
	 * @param aPayload the a payload
	 */
	protected void validateReceivedMessage(Message aMessage) {
		if (aMessage == null) {
			throw new EcsResponseIsNullException("null message in " + this);
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AbstractJmsMessageConverter.java,v $
 *  Revision 1.2  2013/09/03 18:02:29  mwsec2
 *  import clean up
 *
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2012/03/22 23:41:10  mwkkc
 *  Cleanup - so that CNA condition would be generated instead.
 *
 *  Revision 1.8  2011/06/10 21:34:30  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2010/11/08 23:18:09  mwjxa11
 *  Replaced hex nulls with spaces - Pramod.
 *
 *  Revision 1.6  2010/10/30 20:42:31  mwpxr4
 *  Recheckin of previous verson.
 *
 *  Revision 1.4  2010/10/22 16:44:40  mwpxr4
 *  Replace nulls with spaces in the byte stream received from backend.
 *
 *  Revision 1.3  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/05/26 01:56:16  mwpxp2
 *  Refactoring
 *
 *  Revision 1.1  2010/05/26 01:21:51  mwpxp2
 *  Moved in from improper package
 *
 *  Revision 1.2  2010/05/25 21:55:37  mwpxp2
 *  Added exceptions thrown rather than null return
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/29 22:40:43  mwpzs3
 *  protected methods public
 *
 *  Revision 1.6  2009/10/13 18:02:59  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/10/07 15:23:04  mwhxb3
 *  Replaced todo
 *
 *  Revision 1.4  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.3  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/09/25 18:42:22  mwpzs3
 *  Update comments
 *
 *  Revision 1.1  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
 */
