/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response.impl;

import gov.ca.dmv.ease.tus.auth.response.ILocationEnforcementResponse;

import java.util.List;

/**
 * Description: I am an AuthAndAuth response
 * 
 * File: AuthorizeApproverResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LocationEnforcementResponse extends AuthAndAuthServiceResponse
		implements ILocationEnforcementResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3207128083864114066L;
	/** The authorized. */
	private boolean locationAuthorized = false;
	/** Authorized office id */
	private List<String> authOfficeIdList;

	/**
	 * The Constructor.
	 * 
	 * @param authorized
	 *            the authorized
	 */
	public LocationEnforcementResponse(boolean locationAuthorized, List<String> authOfficeIdList ) {
		super();
		setLocationAuthorized(locationAuthorized);
		setAuthOfficeIdList(authOfficeIdList);
	}	

	/**
	 * Checks if is location enforced.
	 * 
	 * @return the location enforced
	 */
	public boolean isLocationAuthorized() {
		return locationAuthorized;
	}

	/**
	 * Sets the location enforced..
	 * 
	 * @param location enforced.
	 *            
	 */
	private void setLocationAuthorized(boolean locationAuthorized) {
		this.locationAuthorized = locationAuthorized;
	}

	public List <String> getAuthOfficeIdList() {
		return authOfficeIdList;
	}

	public void setAuthOfficeIdList(List <String> authOfficeIdList) {
		this.authOfficeIdList = authOfficeIdList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: LocationEnforcementResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/01/10 19:34:58  mwxxw
 *  Display AuthOfficeIdList on location enforcement page.
 *
 *  Revision 1.3  2010/12/07 20:20:09  mwxxw
 *  Add authOfficeId to the service response.
 *
 *  Revision 1.2  2010/11/30 23:11:54  mwxxw
 *  Updated logic for location enforcement service.
 *
 *  Revision 1.1  2010/11/30 19:18:23  mwxxw
 *  New response class created for location enforcement service.
 *
 *  Revision 1.1  2010/10/04 21:39:26  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
