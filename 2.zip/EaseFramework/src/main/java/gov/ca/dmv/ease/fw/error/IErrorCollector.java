/**
 * 
 */
package gov.ca.dmv.ease.fw.error;

import gov.ca.dmv.ease.bo.ITreePrintable;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I am interface for an object collecting multiple errors (typically, exceptions)
 * as resulting (typically) from validation
 * File: IErrorCollector.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Jul 30, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IErrorCollector extends IErrorCollectorQuery, ITreePrintable, Serializable {
	/**
	 * Adds new entries to the current entries.
	 * 
	 * @param aList the new entries
	 */
	void addEntries(List <IErrorCollectorEntry> aList);

	/**
	 * 
	 *
	 * @param anotherCollector 
	 */
	void addEntriesFrom(IErrorCollector anotherCollector);

	/**
	 * Gets the entries.
	 * 
	 * @return the entries
	 */
	List <IErrorCollectorEntry> getEntries();

	/**
	 * Checks for entry with message including.
	 *
	 * @param aMessage the a message
	 * @return true, if successful
	 */
	boolean hasEntryWithMessageIncluding(String aMessage);

	/**
	 * Checks for errors.
	 * 
	 * @return true, if successful
	 */
	boolean hasErrors();

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if is empty
	 */
	boolean isEmpty();

	/**
	 * Register.
	 * 
	 * @param e the e
	 */
	void register(Throwable e);

	/**
	 * Register.
	 * 
	 * @param e the e
	 * @param messageParameters the message parameters
	 */
	void register(Throwable e, String[] messageParameters);

	/**
	 * Register error with parameters and field.
	 * @param e
	 * @param messageParameters
	 * @param errorFieldToFocus
	 */
	void register(Throwable e, String[] messageParameters,
			String errorFieldToFocus);
}
/**
 *  Modification History:
 *
 *  $Log: IErrorCollector.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2011/02/04 01:20:12  mwpxp2
 *  Extended ITreePrintable
 *
 *  Revision 1.8  2011/01/21 02:57:09  mwpxp2
 *  Added hasEntryWithMessageIncluding/1
 *
 *  Revision 1.7  2011/01/20 03:47:30  mwpxp2
 *  Added addEntriesFrom another collector
 *
 *  Revision 1.6  2010/12/03 21:02:06  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.5  2010/10/12 21:10:19  mwkfh
 *  added addEntries(List)
 *
 *  Revision 1.4  2010/10/12 18:32:18  mwpxp2
 *  Extended IErrorCollectorQuery
 *
 *  Revision 1.3  2010/09/29 20:27:39  mwtjc1
 *  Object[] parameters is replaced with String[] messageParameters
 *
 *  Revision 1.2  2010/09/28 18:06:03  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:16:41  mwpxp2
 *  Moved to fw.error; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/26 22:57:00  mwpxp2
 *  Modified to register Throwable
 *
 *  Revision 1.1  2009/07/30 21:24:45  mwpxp2
 *  Initial
 *
 */
