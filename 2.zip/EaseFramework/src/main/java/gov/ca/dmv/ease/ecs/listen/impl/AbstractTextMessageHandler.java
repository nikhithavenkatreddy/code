/**
 * 
 */
package gov.ca.dmv.ease.ecs.listen.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bus.service.ILogMessageProcessor;
import gov.ca.dmv.ease.listeners.bridge.handler.impl.EaseBridgeMessageException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;


/**
 * Description: Abstract message handler for JMS TextMessage messages. 
 * File: AbstractTextMessageHandler.java
 * Module:  gov.ca.dmv.ease.ecs.listen.impl
 * Created: Oct 19, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractTextMessageHandler extends AbstractMessageHandler {
	
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(AbstractTextMessageHandler.class);
		
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.listen.impl.AbstractMessageHandler#convert(javax.jms.Message)
	 */
	@Override
	protected BusinessObject convert(Message message) {
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			String messageString = getMessageString(textMessage);
			if (messageString == null) {
				throw new EaseBridgeMessageException("JMS text message was null");
			} else if (messageString.length() == 0) {
				throw new EaseBridgeMessageException("JMS text message was empty");
			} else if (logEnabled()) {
				logMessage(messageString);
			}
			return convert(messageString);
		} else {
			throw new EaseBridgeMessageException("non-TextMessage received: " 
					+ message.getClass()
						.getSimpleName());
		}
	}

	protected String createLogMessage(String payload) {
		return null;
	}
	
	/**
	 * @param textMessage
	 * @return
	 * @throws JMSException
	 */
	private String getMessageString(TextMessage textMessage) {
		String text = null;
		try {
			text = textMessage.getText();
			LOGGER.info("Message string received: " + text);
		}
		catch (JMSException e) {
			throw new EaseBridgeMessageException(
					"error occurred when accessing the message text", e);
		}
		return text;
	}

	protected abstract BusinessObject convert(String messageString);
	
	/**
	 * Controls whether the incoming message is logged (e.g. to the audit table).
	 * Concrete classes can override this method to toggle logging.
	 * 
	 * @return
	 */
	protected boolean logEnabled() {
		return true;
	}

	protected void logMessage(String payload) {
		String logMessage = createLogMessage(payload);
		if (logMessage != null) {
			ApplicationContext applicationContext = EaseApplicationContext.getApplicationContext();
			if (applicationContext != null) {
				ILogMessageProcessor logProcessor = 
					(ILogMessageProcessor) applicationContext.getBean("logMessageProcessor");
				try {
					logProcessor.execute(logMessage);
				} catch (Exception e) {
					LOGGER.error("Error while logging incoming message: " + e.getMessage());
				}
			}
		}
	}
}


/**
 *  Modification History:
 *
 *  $Log: AbstractTextMessageHandler.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/05/29 23:58:29  mwsec2
 *  added logging support for incoming text messages
 *
 *  Revision 1.2  2012/04/17 22:26:38  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/03/21 22:27:33  mwsec2
 *  added null check validation
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:09  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */
