/** *
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.service.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.IEcsService;
import gov.ca.dmv.ease.ecs.exception.impl.DocumentGeneratorException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsPrintServiceResponseException;
import gov.ca.dmv.ease.ecs.impl.EcsService;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.print.exception.impl.PrinterNotFoundException;
import gov.ca.dmv.ease.tus.print.request.impl.AlternativePrintJobRequest;
import gov.ca.dmv.ease.tus.print.request.impl.CancelPrintJobRequest;
import gov.ca.dmv.ease.tus.print.request.impl.GenerateDocumentRequest;
import gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest;
import gov.ca.dmv.ease.tus.print.request.impl.QueryPrintJobRequest;
import gov.ca.dmv.ease.tus.print.request.impl.ResubmitPrintJobRequest;
import gov.ca.dmv.ease.tus.print.response.impl.AlternativePrintJobResponse;
import gov.ca.dmv.ease.tus.print.response.impl.CancelPrintJobResponse;
import gov.ca.dmv.ease.tus.print.response.impl.GenerateDocumentResponse;
import gov.ca.dmv.ease.tus.print.response.impl.PrintServiceResponse;
import gov.ca.dmv.ease.tus.print.response.impl.QueryPrintJobResponse;
import gov.ca.dmv.ease.tus.print.response.impl.ResubmitPrintJobResponse;
import gov.ca.dmv.ease.tus.print.service.IPrintHpOsWebServiceClient;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Implementation class for Short Term Print service.
 * File: PrintService.java
 * Module:  gov.ca.dmv.ease.tus.print.service.impl
 * Created: 2009
 * @author MWJXA11
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2013/09/03 17:53:20 $
 * Last Changed By: $Author: mwsec2 $
 */
public class PrintService implements Serializable {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(PrintService.class);
	
	private static final long RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS = 5;
	
	/**
	 * The constant serialVersionUID
	 */
	private static final long serialVersionUID = -4726660605369914654L;
	
	/**
	 * Create PersistenceServiceRequestFactory bean from Application context.
	 * 
	 * @return
	 */
	private static IEcsService getEcsService() {
		return EcsService.getInstance();
	}
	
	/**
	 * Create PersistenceServiceRequestFactory bean from Application context.
	 * 
	 * @return
	 */
	private static PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return PersistenceServiceRequestFactory.getInstance();
	}
	
	/**
	 * Create PersistenceServiceRequestFactory bean from Application context.
	 * 
	 * @return
	 */
	private static IPrintHpOsWebServiceClient getPrintHpOsWebServiceClient() {
		//TODO despringify
		return (IPrintHpOsWebServiceClient) EaseApplicationContext
				.getApplicationContext().getBean("printHpOsWebServiceClient");
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.service.IPrintService#
	 * execute(gov.ca.dmv.ease.tus.print.request.impl.CancelPrintJobRequest)
	 */
	public static CancelPrintJobResponse execute(CancelPrintJobRequest request) {
		CancelPrintJobResponse response = null;
		IErrorCollector collector = null;
		try {
			//Validate the Print Service Request
			collector = request.validate();
			//Check if validation errors exist
			if (!collector.hasErrors()) {
				//Job Client Id
				String jobClientId = request.getClientJobId();
				//Invoke HPOS Web Service Proxy and get Response
				long startTimeStamp = (new Date()).getTime();
				String cancelPrintJobStatus = getPrintHpOsWebServiceClient()
						.cancelPrintJob(jobClientId);
				long endTimeStamp = (new Date()).getTime();
				double totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
				LOGGER.info("Cancel print job request delivered to HPOS in " + totalTime + " seconds");
				if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
					LOGGER.warn("cancelPrintJob call to HPOS took " + totalTime + " seconds");
				}
				//Set the Response
				response = new CancelPrintJobResponse(jobClientId,
						cancelPrintJobStatus);
			}
			else {
				//Errors exist
				response = new CancelPrintJobResponse(collector);
			}
		}
		catch (EcsPrintServiceResponseException psre) {
			//Instantiate the Response with Error Collector
			response = new CancelPrintJobResponse(psre);
		}
		return response;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.service.IPrintService#
	 * execute(gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest)
	 */
	public static PrintServiceResponse execute(PrintServiceRequest request) {
		PrintServiceResponse response = null;
		IErrorCollector collector = null;
		try {
			//Validate the Print Service Request
			collector = request.validate();
			//Check if validation errors exist
			if (!collector.hasErrors()) {
				//			if (true) { //FIXME remove this after the build
				//Invoke Converter
				String xmlData = request.getDocumentConverter()
						.convertToCompleteDocumentBinding(request);
				GenerateDocumentRequest docRequest = new GenerateDocumentRequest(
						request.getUserContext(), xmlData);
				docRequest.setEcsService(getEcsService());
				long startTimeStamp = (new Date()).getTime();
				GenerateDocumentResponse generateDocumentResponse = docRequest
						.execute();
				long endTimeStamp = (new Date()).getTime();
				double totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
				LOGGER.info("Generate document call took " + totalTime + " seconds");
				if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
					LOGGER.warn("Generate document call took " + totalTime + " seconds");
				}
				if (generateDocumentResponse != null) {
					String documentContent = generateDocumentResponse.getData();
					if (documentContent != null && documentContent.length() > 0) {
						//Invoke Persistence Service to fetch Printer Information based on User Context
						Location printerInfo = fetchPrinterInfo(request
								.getUserContext());
						LOGGER
								.info("Response document data:"
										+ documentContent);
						//Invoke HPOS Web Service Proxy and get Response
						startTimeStamp = (new Date()).getTime();
						String jobClientId = getPrintHpOsWebServiceClient()
								.deliverPrintJob(documentContent.getBytes(),
										printerInfo);
						endTimeStamp = (new Date()).getTime();
						totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
						LOGGER.info("Print job delivered to HPOS in " + totalTime + " seconds");
						if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
							LOGGER.warn("deliverPrintJob call to HPOS took " + totalTime + " seconds");
						}
						LOGGER.info("jobClientId:" + jobClientId);
						//Set the Response
						response = new PrintServiceResponse(jobClientId,
								new Date());
					}
					else {
						LOGGER.error("Generated document is empty");
						throw new DocumentGeneratorException(
								"Generated document is empty");
					}
				}
				else {
					LOGGER.error("Document is not generated properly");
					throw new DocumentGeneratorException(
							"Document is not generated properly");
				}
			}
			else {
				response = new PrintServiceResponse(collector);
			}
		}
		catch (Exception psre) {
			LOGGER.error(psre.getMessage(), psre);
			//Instantiate the Response with Error Collector
			response = new PrintServiceResponse(psre);
		}
		return response;
	}


	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.service.IPrintService#
	 * execute(gov.ca.dmv.ease.tus.print.request.impl.QueryPrintJobRequest)
	 */
	public static QueryPrintJobResponse execute(QueryPrintJobRequest request) {
		QueryPrintJobResponse response = null;
		IErrorCollector collector = null;
		try {
			//Validate the Print Service Request
			collector = request.validate();
			//Check if validation errors exist
			if (!collector.hasErrors()) {
				//Job Client Id
				String jobClientId = request.getClientJobId();
				//Invoke HPOS Web Service Proxy and get Response
				long startTimeStamp = (new Date()).getTime();
				String queryPrintJobStatus = getPrintHpOsWebServiceClient()
						.queryPrintJob(jobClientId);
				long endTimeStamp = (new Date()).getTime();
				double totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
				LOGGER.info("Print job status query delivered to HPOS in " + totalTime + " seconds");
				if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
					LOGGER.warn("queryPrintJob call to HPOS took " + totalTime + " seconds");
				}
				//Set the Response
				response = new QueryPrintJobResponse(jobClientId,
						queryPrintJobStatus);
			}
			else {
				//Errors exist
				response = new QueryPrintJobResponse(collector);
			}
		}
		catch (EcsPrintServiceResponseException psre) {
			//Instantiate the Response with Error Collector
			response = new QueryPrintJobResponse(psre);
		}
		return response;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.service.IPrintService#
	 * execute(gov.ca.dmv.ease.tus.print.request.impl.ResubmitPrintJobRequest)
	 */
	public static ResubmitPrintJobResponse execute(
			ResubmitPrintJobRequest request) {
		ResubmitPrintJobResponse response = null;
		IErrorCollector collector = null;
		try {
			//Validate the Print Service Request
			collector = request.validate();
			//Check if validation errors exist
			if (!collector.hasErrors()) {
				//Job Client Id
				String jobClientId = request.getClientJobId();
				//Invoke Persistence Service to fetch Printer Information based on User Context
				Location printerInfo = fetchPrinterInfo(request
						.getUserContext());
				//Invoke HPOS Web Service Proxy and get Response
				long startTimeStamp = (new Date()).getTime();
				String resubmitPrintJobStatus = getPrintHpOsWebServiceClient()
						.resubmitPrintJob(jobClientId, printerInfo);
				long endTimeStamp = (new Date()).getTime();
				double totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
				LOGGER.info("Print job redelivered to HPOS in " + totalTime + " seconds");
				if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
					LOGGER.warn("resubmitPrintJob call to HPOS took " + totalTime + " seconds");
				}
				LOGGER.info("jobClientId:" + jobClientId);
				//Set the Response
				response = new ResubmitPrintJobResponse(jobClientId,
						resubmitPrintJobStatus);
			}
			else {
				//Errors exist
				response = new ResubmitPrintJobResponse(collector);
			}
		}
		catch (EcsPrintServiceResponseException psre) {
			//Instantiate the Response with Error Collector
			response = new ResubmitPrintJobResponse(psre);
		}
		return response;
	}
	
	/**
	 * This method fetches the matching Printer Information for an input User Context.
	 * 
	 * @param userContext the User Context Information
	 * 
	 * @return <code>Location</code> containing the Printer Information
	 */
	private static Location fetchPrinterInfo(IUserContext userContext) {
		Location printerLocation = new Location();
		if (EaseUtil.isNullOrBlank(userContext.getLocation())
				|| EaseUtil.isNullOrBlank(userContext.getLocation()
						.getStation())
				|| EaseUtil.isNullOrBlank(userContext.getLocation()
						.getStation().getPrimaryPrinterId())) {
			try {
				LOGGER.info("Print request from IP Address: "
						+ userContext.getIpAddress());
				LOGGER.info("Print request for OfficeId: "
						+ userContext.getOfficeId());
				printerLocation.setIpAddress(userContext.getIpAddress());
				printerLocation.setOfficeId(userContext.getOfficeId());
				IPersistenceServiceRequest request = getPersistenceServiceRequestFactory()
						.createRetrieveBusinessObjectRequest(userContext,
								printerLocation);
				RetrieveBusinessObjectResponse response = (RetrieveBusinessObjectResponse) request
						.execute();
				if ((response.hasErrors())
						|| (response.getResults().size() == 0)) {
					throw new PrinterNotFoundException(
							"NO MATCHING PRINTER INFORMATION FOUND");
				}
				else {
					printerLocation = (Location) response.getResults().get(0);
					((UserContext) userContext).setLocation(printerLocation);
					LOGGER.info("Primary printer: "
							+ printerLocation.getStation()
									.getPrimaryPrinterId());
					LOGGER.info("Alternate printer: "
							+ printerLocation.getStation()
									.getAlternatePrinterId());
				}
			}
			catch (Exception e) {
				throw new EcsPrintServiceResponseException(e);
			}
		}
		else {
			printerLocation = userContext.getLocation();
		}
		return printerLocation;
	}
	
	public static PrintServiceResponse execute(
			AlternativePrintJobRequest request) {
		AlternativePrintJobResponse response = null;
		IErrorCollector collector = null;
		try {
			//Validate the Print Service Request
			collector = request.validate();
			//Check if validation errors exist
			if (!collector.hasErrors()) {
				//Job Client Id
				String jobClientId = request.getClientJobId();
				//Invoke Persistence Service to fetch Printer Information based on User Context
				Location printerInfo = fetchPrinterInfo(request
						.getUserContext());
				//Invoke HPOS Web Service Proxy and get Response
				long startTimeStamp = (new Date()).getTime();
				String alternativeJobClientId = getPrintHpOsWebServiceClient()
						.alternativePrintJob(jobClientId, printerInfo);
				long endTimeStamp = (new Date()).getTime();
				double totalTime = (endTimeStamp - startTimeStamp) / 1000.0;
				LOGGER.info("Alternative print job delivered to HPOS in " + totalTime + " seconds");
				if (totalTime > RESPONSE_TIME_LOGGING_THRESHOLD_IN_SECS) {
					LOGGER.warn("alternativePrintJob call to HPOS took " + totalTime + " seconds");
				}
				LOGGER.info("alternativeJobClientId:" + alternativeJobClientId);
				//Set the Response
				response = new AlternativePrintJobResponse(
						alternativeJobClientId);
			}
			else {
				//Errors exist
				response = new AlternativePrintJobResponse(collector);
			}
		}
		catch (EcsPrintServiceResponseException psre) {
			//Instantiate the Response with Error Collector
			response = new AlternativePrintJobResponse(psre);
		}
		return response;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: PrintService.java,v $
 *  Revision 1.4  2013/09/03 17:53:20  mwsec2
 *  removed printStackTrace call
 *
 *  Revision 1.3  2012/10/08 21:31:49  mwsec2
 *  removed getDocumentGenerator method to fix compilation
 *
 *  Revision 1.2  2012/10/08 20:25:40  mwsec2
 *  added warning message for slow service call responses
 *
 *  Revision 1.45  2011/10/12 20:58:11  mwkkc
 *  Performance Merge
 *
 *  Revision 1.44.8.3  2011/09/28 02:48:22  mwpxp2
 *  Added de-springification todos
 *
 *  Revision 1.44.8.2  2011/09/28 02:23:27  mwpxp2
 *  Fixed access to PersistenceServiceRequestFactory instance
 *
 *  Revision 1.44.8.1  2011/09/26 23:46:51  mwhys
 *  Use instance of EcsService.
 *
 *  Revision 1.44  2011/06/15 21:21:13  mwrka1
 *  update alternative printer functionalty
 *
 *  Revision 1.43  2011/06/03 02:44:47  mwrka1
 *  refactored varible name
 *
 *  Revision 1.42  2011/06/02 18:07:46  mwrka1
 *  added alternative printer functionalty
 *
 *  Revision 1.41  2011/05/06 17:34:14  mwkfh
 *  updated fetchPrinterInfo to retrieve from the user context if it has it.
 *
 *  Revision 1.40  2011/03/18 01:30:56  mwhys
 *  Print stack trace during an exception to debug print issues.
 *
 *  Revision 1.39  2010/11/04 21:18:57  mwjxa11
 *  Updated with valid log messages
 *
 *  Revision 1.38  2010/10/15 00:06:19  mwjxa11
 *  enabling the document generator validation
 *
 *  Revision 1.37  2010/09/14 21:25:24  mwkfh
 *  fixed ecsService injections
 *
 *  Revision 1.36  2010/09/13 04:39:49  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.35  2010/09/01 19:06:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.34  2010/08/31 17:58:18  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.33  2010/08/27 17:56:35  mwcsj3
 *  Moved PrintingNotFoundException from FW to TUS folder
 *
 *  Revision 1.32  2010/08/24 19:09:35  mwlft1
 *  Added log statements for exceptions
 *
 *  Revision 1.31  2010/08/24 01:45:09  mwrsk
 *  Add log statement
 *
 *  Revision 1.30  2010/08/17 18:31:44  mwyxg1
 *  add Serializable
 *
 *  Revision 1.29  2010/08/06 02:06:15  mwrsk
 *  Add log info
 *
 *  Revision 1.28  2010/08/06 00:06:23  mwcsj3
 *  Updated fetchPrinterInfo method to throw PrinterNotFoundException
 *
 *  Revision 1.27  2010/07/22 23:11:28  mwhxa2
 *  Implemented Resubmit Print Job
 *
 *  Revision 1.26  2010/07/19 21:59:29  mwrsk
 *  commented print validations
 *
 *  Revision 1.25  2010/07/12 18:54:05  mwrsk
 *  Add capability for composite request
 *
 *  Revision 1.24  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.23  2010/07/06 17:34:16  mwrsk
 *  Added some logging info
 *
 *  Revision 1.22  2010/07/01 18:35:10  mwrsk
 *  updated fetchPrinterInfo()
 *
 *  Revision 1.21  2010/06/30 00:27:01  mwhxa2
 *  Updated Print Service for Resubmit job
 *
 *  Revision 1.20  2010/06/29 18:21:45  mwhxa2
 *  Print now uses data from User Context to find the printer
 *
 *  Revision 1.19  2010/06/21 23:00:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.12.2.2  2010/06/20 18:06:57  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.18  2010/06/15 16:50:08  mwtjc1
 *  fixme is resolved for what to do if error collector is not empty
 *
 *  Revision 1.17  2010/06/07 17:47:31  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.16  2010/06/02 20:46:45  mwtjc1
 *  sending byte array to HPOS webservice client instead of file object
 *
 *  Revision 1.15  2010/06/01 23:08:59  mwtjc1
 *  system property file.separator is used in getTargetFileName to decide the location of document creation
 *
 *  Revision 1.14  2010/06/01 21:23:35  mwtjc1
 *  HPOS web service is integrated with document generation
 *
 *  Revision 1.12  2010/05/25 22:10:50  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.11  2010/05/25 18:45:47  mwtjc1
 *  EcsService is changed to IEcsService
 *
 *  Revision 1.10  2010/05/18 21:10:15  mwtjc1
 *  Document Generation code is added
 *
 *  Revision 1.9  2010/05/17 21:49:07  mwhxb3
 *  Added ECS service to printService to support doc generation.
 *
 *  Revision 1.8  2010/05/11 17:57:27  mwrsk
 *  Removed IdocumentGeneratorService
 *
 *  Revision 1.7  2010/05/11 01:00:18  mwhxa2
 *  Added call to Document Service
 *
 *  Revision 1.6  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 *  Revision 1.5  2010/03/22 23:40:34  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/02/04 22:51:35  mwhxa2
 *  Code needs to be refactored
 *
 *  Revision 1.3  2010/01/15 04:20:50  mwkkc
 *  Support for JCL
 *
 *  Revision 1.2  2010/01/11 22:36:34  mwhxa2
 *  Fixed compilation issues
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.22  2009/10/22 21:15:35  mwjxa11
 *  Added a logger statements
 *
 *  Revision 1.21  2009/10/22 18:17:01  mwjxa11
 *  Added a logger statement
 *
 *  Revision 1.20  2009/10/16 00:55:11  mwjxa11
 *  Refactored
 *
 *  Revision 1.19  2009/10/14 00:28:42  mwjxa11
 *  Refactored
 *
 *  Revision 1.18  2009/10/12 19:53:02  mwjxa11
 *  Improved the code coverage
 *
 *  Revision 1.17  2009/10/03 21:32:49  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.16  2009/09/30 17:25:04  mwjxa11
 *  Fixed the printing issue on z/OS environment
 *
 *  Revision 1.15  2009/09/24 18:46:15  mwjxa11
 *  added log statements
 *
 *  Revision 1.14  2009/09/15 20:33:25  mwjxa11
 *  Changed the lpr script for was/z environment.
 *
 *  Revision 1.13  2009/09/01 01:05:56  mwjxa11
 *  Fixed a null exception causing from testPrintServiceWithTokenNull() test case of PrintServiceTest class.
 *
 *  Revision 1.12  2009/08/28 21:24:09  mwjxa11
 *  Added a validation check for Document Token File
 *
 *  Revision 1.11  2009/08/27 20:13:03  mwjxa11
 *  Fixed the functionality issues introduced during code refactoring.
 *
 *  Revision 1.10  2009/08/27 07:06:24  mwpxp2
 *  Removed printResponse.setMessage(ERROR_PRINT_FAILURE) - use hasErrors() instead
 *
 *  Revision 1.9  2009/08/27 04:00:31  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.8  2009/08/27 02:51:40  mwpxp2
 *  Refactored
 *
 *  Revision 1.7  2009/08/27 00:55:09  mwpxp2
 *  Replaced PrintServiceConstants with IPrintServiceConstants
 *
 *  Revision 1.6  2009/08/26 00:15:08  mwjxa11
 *  Added the LOGGER statements.
 *
 *  Revision 1.5  2009/08/12 22:48:32  mwjxa11
 *  Minor update of setting the printResponse before deleting the generated document.
 *
 *  Revision 1.4  2009/08/12 01:42:29  mwjxa11
 *  Updated with RequestValidation scenarios.
 *
 *  Revision 1.3  2009/08/11 01:42:49  mwjxa11
 *  Updated the validatePrintRequest method.
 *
 *  Revision 1.2  2009/08/10 21:12:39  mwjxa11
 *  Added printDocument, checkDocumentAvailability, deleteDocument and validatePrintRequest methods.
 *  Updated execute method.
 *	
 *  Revision 1.2  2009-08-06 16:00:25  jarise
 *  provided the implementation for print service
 *
 *  Revision 1.1  2009   MWRRV2
 *  Moved to .impl package; added file decorations, todos
 *
 */
