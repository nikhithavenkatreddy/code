/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.docs.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseServiceLayerException;

/**
 * Description: All the document service specific exceptions extends this class
 * 
 * File: DocumentServiceException.java 
 * Module: gov.ca.dmv.ease.tus.docs.exception.impl
 * Created: August 19, 2009
 * 
 * @author MWJXA11
 * @version $Revision: 1.1 $ 
 * Last Changed: Aug 19, 2009 9:26:48 AM 
 * Last Changed  By: MWJXA11
 */
public class DocumentServiceException extends EaseServiceLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8404271909270488121L;

	/**
	 * Instantiates a document service exception.
	 */
	public DocumentServiceException() {
		super();
	}

	/**
	 * Instantiates a document service exception.
	 * 
	 * @param message the message
	 */
	public DocumentServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a document service exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public DocumentServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a document service exception.
	 * 
	 * @param cause the cause
	 */
	public DocumentServiceException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DocumentServiceException.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/03/23 20:32:44  mwpxp2
 *  Exception imports adjusted per exception tree mods
 *
 *  Revision 1.2  2010/03/22 23:37:24  mwpxp2
 *  Inherits from EaseServiceLayerException not EaseException
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/03 21:32:48  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/08/27 06:29:25  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 04:40:27  mwpxp2
 *  Moved in from documetn service project and package-restructured
 *
 *  Revision 1.2  2009/08/26 22:02:19  mwpxp2
 *  Changed super to serialVersionUID; regenerated serialVersionUID
 *
 *  Revision 1.1  2009/08/20 02:42:41  mwjxa11
 *  Added a new document service exception class
 *
 *  Revision 1.1  2009-09-19 07:32:58  mwjxa11
 *  Added a new document service exception class
 *
 */
