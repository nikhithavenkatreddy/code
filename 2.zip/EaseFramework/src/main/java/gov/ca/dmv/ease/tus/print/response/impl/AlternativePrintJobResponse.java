/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: //TODO - provide description!
 * File: AlternativePrintJobResponse.java
 * Module:  gov.ca.dmv.ease.tus.print.response.impl
 * Created: Jun 2, 2011 
 * @author MWRKA1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AlternativePrintJobResponse extends PrintServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3161961667816803636L;

	/**
	 * Instantiates a new alternative print job response.
	 *
	 * @param errorCollector the error collector
	 */
	public AlternativePrintJobResponse(IErrorCollector errorCollector) {
		super(errorCollector);
	}

	/**
	 * Instantiates a new alternative print job response.
	 *
	 * @param clientJobId the client job id
	 * @param printExecutionStatus the print execution status
	 */
	public AlternativePrintJobResponse(String clientJobId) {
		super(clientJobId);
	}

	/**
	 * Instantiates a new alternative print job response.
	 *
	 * @param e the e
	 */
	public AlternativePrintJobResponse(Throwable e) {
		super(e);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AlternativePrintJobResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/08/25 17:57:28  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2011/06/03 02:44:35  mwrka1
 *  changed constructor parameters
 *
 *  Revision 1.1  2011/06/02 18:07:46  mwrka1
 *  added alternative printer functionalty
 *
 */
