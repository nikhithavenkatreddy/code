/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.impl;

import com.ibm.websphere.security.auth.callback.WSCallbackHandlerImpl;

/**
 * Description: Call back handler used in the login context
 * File: AuthenticationCallbackHandler.java
 * Module:  gov.ca.dmv.ease.tus.auth.impl
 * Created: Apr 16, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuthenticationCallbackHandler extends WSCallbackHandlerImpl {
	/**
	 * Instantiates a new authentication callback handler.
	 * 
	 * @param userId the user id
	 * @param password the password
	 */
	public AuthenticationCallbackHandler(String userId, String password) {
		super(userId, password);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AuthenticationCallbackHandler.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:36:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/20 21:16:03  mwrsk
 *  Added disclaimer
 *
 *  Revision 1.8  2009/10/20 21:15:03  mwrsk
 *  Removed unused code
 *
 *  Revision 1.7  2009/10/20 17:05:48  mwkkc
 *  Business Transaction Level Authorization
 *
 *  Revision 1.6  2009/10/14 02:48:36  mwkkc
 *  I1 Close Down - Code Review
 *
 *  Revision 1.5  2009/10/12 18:15:41  mwkkc
 *  Approval Authorization and JAAS implementation.
 *
 *  Revision 1.4  2009/10/03 21:31:02  mwpxp2
 *  Adjusted imports for fw refactorings; added javadoc
 *
 *  Revision 1.3  2009/09/22 22:23:27  mwkkc
 *  Reflection Update Design Doc
 *
 *  Revision 1.2  2009/07/21 21:18:36  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/07/15 00:59:44  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-11 17:21:08  mwpxp2
 *  Moved to .impl package; changed visibility of fields to private; added accessors; cleaned up comments and javadoc; added todos
 *
 *  Revision 1.1  2009-07-10 07:13:57  mwpxp2
 *  Synch
 *
 */
