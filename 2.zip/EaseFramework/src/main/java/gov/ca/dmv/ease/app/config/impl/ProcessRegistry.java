/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.config.impl;

import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.exception.impl.ProcessStateInvalidException;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.app.process.impl.TransactionType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Description: Registry holding all business processes along with the process key
 * File: ProcessRegistry.java
 * Module:  gov.ca.dmv.ease.app.config.impl
 * Created: Mar 22, 2010 
 * @author mwrsk  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProcessRegistry implements IProcessRegistry, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6315368658857903190L;
	/** The registry map. */
	private transient Map <String, BusinessProcess> registryMap;
	/** The mapping of transaction types to their business process. */
	private transient Map <String, String> transToProcessMap;

	/**
	 * Add business process.
	 * 
	 * @param businessProcess the business process
	 */
	public void addProcess(BusinessProcess businessProcess) {
		getRegistryMap().put(businessProcess.getId(), businessProcess);
		if (businessProcess.getTransactionTypes() != null) {
			for (TransactionType transactionType : businessProcess
					.getTransactionTypes()) {
				String tcode = transactionType.getTcode();
				if (!getTransToProcessMap().containsKey(tcode)) {
					getTransToProcessMap().put(tcode, businessProcess.getId());
				}
				else {
					throw new ProcessStateInvalidException(
							"Attempting to associate tcode '" + tcode
									+ "' with two business processes: '"
									+ businessProcess.getId() + "' and '"
									+ getTransToProcessMap().get(tcode) + "'");
				}
			}
		}
	}

	/**
	 * Gets the BusinessProcess object based on id.
	 * 
	 * @param businessProcessId the business process id
	 * 
	 * @return BusinessProcess
	 */
	public BusinessProcess getProcess(String businessProcessId) {
		return getRegistryMap().get(businessProcessId);
	}

	/**
	 * Gets the registry map.
	 * 
	 * @return the registry map
	 */
	private Map <String, BusinessProcess> getRegistryMap() {
		if (registryMap == null) {
			setRegistryMap(new HashMap <String, BusinessProcess>());
		}
		return registryMap;
	}

	/**
	 * @return the tcode-to-process map
	 */
	private Map <String, String> getTransToProcessMap() {
		if (transToProcessMap == null) {
			setTransToProcessMap(new HashMap <String, String>());
		}
		return transToProcessMap;
	}

	/**
	 * Remove business process.
	 * 
	 * @param key the key
	 */
	public void removeProcess(String key) {
		getRegistryMap().remove(key);
		// remove the process from the TCodeToProcessMap
		if (getTransToProcessMap().containsValue(key)) {
			Set <String> keys = getTransToProcessMap().keySet();
			List <String> keysToRemove = new ArrayList <String>();
			for (String k : keys) {
				if (getTransToProcessMap().get(k).equals(key)) {
					keysToRemove.add(k);
				}
			}
			for (String k : keysToRemove) {
				getTransToProcessMap().remove(k);
			}
		}
	}

	/**
	 * Sets the registry map.
	 * 
	 * @param aMap the a map
	 */
	private void setRegistryMap(Map <String, BusinessProcess> aMap) {
		registryMap = aMap;
	}

	/**
	 * Sets the tcode-to-process map
	 * @param codeToProcessMap
	 */
	private void setTransToProcessMap(Map <String, String> aMap) {
		transToProcessMap = aMap;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.config.IProcessRegistry#getProcessForTransaction(java.lang.String)
	 */
	public BusinessProcess getProcessForTransaction(String tcode) {
		if (!getTransToProcessMap().containsKey(tcode)) {
			throw new ProcessStateInvalidException("No business process found for tcode " + tcode);
		}
		return getProcess(getTransToProcessMap().get(tcode));
	}
}
/**
 *  Modification History:
 *
 *  $Log: ProcessRegistry.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.19  2011/06/10 20:27:46  mwyxg1
 *  clean up
 *
 *  Revision 1.18  2011/06/09 17:04:19  mwyxg1
 *  clean up
 *
 *  Revision 1.17  2010/09/28 23:29:46  mwsec2
 *  removed security roles from business process
 *
 *  Revision 1.16  2010/09/23 18:11:51  mwsyk1
 *  remove getProcessByTtc
 *
 *  Revision 1.15  2010/09/23 16:12:51  mwyxg1
 *  change DRT, IRT constant names
 *
 *  Revision 1.14  2010/09/23 16:00:25  mwyxg1
 *  add getProcessByTtc
 *
 *  Revision 1.13  2010/09/03 17:01:36  mwsec2
 *  enhanced to allow a BP to be accessed via an associated tcode
 *
 *  Revision 1.12  2010/08/20 17:57:39  mwpxp2
 *  Added lazy initialization of registryMap and internal access using the getter; added javadoc; cleaned up
 *
 *  Revision 1.11  2010/05/05 02:15:59  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.10  2010/05/04 00:17:26  mwvkm
 *  Serializable is added in the implements section.
 *
 *  Revision 1.9  2010/04/22 19:09:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.8  2010/04/01 00:11:44  mwakg
 *  Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 *  Revision 1.7  2010/03/22 23:01:55  mwpxp2
 *  Added file decorations, todo
 *
 */
