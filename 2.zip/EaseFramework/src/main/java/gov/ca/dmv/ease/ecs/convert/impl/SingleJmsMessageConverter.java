/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import gov.ca.dmv.ease.ecs.adaptor.impl.SpringBasedJmsAdaptor;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsResponseIsNullException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.jst.jsp.core.internal.Logger;
import org.springframework.jms.support.converter.MessageConversionException;

/**
 * Description: I am jms message converter that converts incoming payload object to response.
 * File: SingleJmsMessageConverter.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Sep 9, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/09/03 18:01:39 $
 * Last Changed By: $Author: mwsec2 $
 */
public class SingleJmsMessageConverter extends AbstractJmsMessageConverter {
	/** the logger */
	private static final Log LOGGER = LogFactory.getLog(SingleJmsMessageConverter.class);
	
	//FIXME - the class is needlessly stateful
	/** Request for which this Message creator is used for */
	private IEcsRequest request = null;

	/**
	 * Constructor - Instantiates a new converter.
	 * @param aRequest a request.
	 */
	public SingleJmsMessageConverter(IEcsRequest aRequest) {
		request = aRequest;
	}

	/**
	 * This function calls the createResponse of the converter associated with the request.
	 * It returns the IEcsResponse thus obtained or throws a MessageConversionException.
	 * @param receivedMessageObject
	 * @return ecsResponse an ecs response.
	 */
	@Override
	public IEcsResponse convert(Message receivedMessageObject) {
		StringBuilder aBuilder = new StringBuilder();
		handlePayload(aBuilder, receivedMessageObject);
		String aPayload = aBuilder.toString();
		validateHeader(aPayload);
		String responseAfterHeader = aPayload.substring(RESPONSE_HEADER_LENGTH);
		validatePayloadAfterHeader(responseAfterHeader);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Payload without header: [" + responseAfterHeader + "]");
		}
		IMessageConverter convertor = request.getMessageConverter();
		IEcsResponse ecsResponse = convertor
				.createResponse(responseAfterHeader);
		return ecsResponse;
	}

	/**
	 * Handles payload.
	 * Updates the provided string buffer with the string representation of the in-bound jms Message.
	 * 
	 * @param aStringBuilder the return value
	 * @param inboundMessageObject the inbound message object
	 */
	private void handlePayload(StringBuilder aStringBuilder,
			Message inboundMessageObject) {
		// TextMessage inboundTextMessage;
		BytesMessage inboundByteMessage;
		try {
			/** We are not currently getting any TextMessages from CAMV, so commenting out this section that handles TextMessages
			if (inboundMessageObject instanceof javax.jms.TextMessage) {
				inboundTextMessage = (javax.jms.TextMessage) inboundMessageObject;
				if (inboundTextMessage == null) {
					throw new EcsResponseIsNullException(
							"No inboundMessageObject recieved from the CAMV");
				}
				else {
					textMessageToString(aStringBuilder, inboundTextMessage);
				}
				String hexCorrId = inboundTextMessage.getJMSCorrelationID();
				String corrId = Hex2ByteTransformer.transform(hexCorrId
						.substring(BEGIN));
				String messageId = inboundTextMessage.getJMSMessageID();
			}
			 **/
			if (inboundMessageObject instanceof javax.jms.BytesMessage) {
				inboundByteMessage = (BytesMessage) inboundMessageObject;
				bytesMessageToString(aStringBuilder, inboundByteMessage);
			}
		}
		catch (Exception e) {
			throw new EcsMessageConversionException(e);
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	@Override
	public Message toMessage(Object arg0, Session arg1) throws JMSException,
			MessageConversionException {
		// We are using message creator in place of this!
		return null;
	}
	
	/**
	 * Validate payload.
	 * 
	 * @param aPayload the a payload
	 */
	protected void validateHeader(String aPayload) {
		if (aPayload == null) {
			throw new EcsResponseIsNullException("CAMV response is null (not even a CAMV header)");
		}
		if (aPayload.length() == 0) {
			throw new EcsResponseIsNullException("CAMV response is empty (not even a CAMV header)");
		}
		if (aPayload.trim().equals("")) {
			throw new EcsResponseIsNullException("CAMV response is just " + aPayload.length() + 
					" blank spaces (not even a CAMV header)");
		}
		if (aPayload.length() < RESPONSE_HEADER_LENGTH) {
			throw new EcsResponseIsNullException("CAMV response including header is just " + 
					aPayload.length() + " bytes");
		}
	}
	
	/**
	 * Validate payload without CAMV header.
	 * 
	 * @param aPayload the a payload
	 */
	protected void validatePayloadAfterHeader(String aPayload) {
		if (aPayload.length() == 0) {
			throw new EcsResponseIsNullException("empty response body from CAMV");
		}
		if (aPayload.trim().equals("")) {
			throw new EcsResponseIsNullException("response body from CAMV is just " + aPayload.length() + 
					" blank spaces");
		}
		if (isBadResponseMessage(aPayload)) {
			throw new EcsResponseIsNullException("error code received in payload: " + aPayload);
		}
	}
	
	/**
	 * Returns true if the message string starts with one of the known 'bad response' messages.
	 * 
	 * @param message
	 * @return
	 */
	private boolean isBadResponseMessage(String message) {
		for (String errorMessage : BAD_RESPONSE_MSGS) {
			if (message.startsWith(errorMessage)) {
				return true;
			}
		}
		return false;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SingleJmsMessageConverter.java,v $
 *  Revision 1.2  2013/09/03 18:01:39  mwsec2
 *  enhanced the checking and handling of 'bad' responses
 *
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/10 21:45:07  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/05/26 01:56:17  mwpxp2
 *  Refactoring
 *
 *  Revision 1.1  2010/05/26 01:21:51  mwpxp2
 *  Moved in from improper package
 *
 *  Revision 1.4  2010/05/25 22:10:14  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.3  2010/05/25 21:57:39  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.2  2010/03/22 23:22:43  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/30 19:10:45  mwpzs3
 *  removing redundant ResponseIsNull condition
 *
 *  Revision 1.8  2009/10/30 19:08:38  mwpzs3
 *  null converter handled by EaseValidationException
 *
 *  Revision 1.7  2009/10/13 18:11:10  mwhxb3
 *  updated comments.
 *
 *  Revision 1.6  2009/10/07 18:18:48  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.5  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.4  2009/10/06 21:50:56  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.2.2  2009/10/06 20:41:53  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3.2.1  2009/10/06 20:28:41  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.3  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/09/25 18:56:55  mwpzs3
 *  Update comments
 *
 *  Revision 1.1  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
 *  Revision 1.1  2009/09/10 00:35:09  mwpzs3
 *  Move to JMS 1.2
 *
 */
