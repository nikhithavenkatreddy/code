/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import java.util.List;

/**
 * Description: I am the response for RetrieveBusinessObject Request
 *  //TODO - remove unused constructors, starting with the default
 * File: RetrieveDomainObjectResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: May 8, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveBusinessObjectResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -553545446454495318L;
	/** The domain object. */
	private List <IBusinessObject> businessObjects;

	/**
	 * 
	 */
	public RetrieveBusinessObjectResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public RetrieveBusinessObjectResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new retrieve business object response.
	 * 
	 * @param ex the exception
	 */
	public RetrieveBusinessObjectResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public RetrieveBusinessObjectResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public RetrieveBusinessObjectResponse(IErrorCollector collector,
			int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public RetrieveBusinessObjectResponse(int anItemCount) {
		super(anItemCount);
	}

	/**
	 * Instantiates a new retrieve business object response.
	 * 
	 * @param businessObjects the business objects
	 */
	public RetrieveBusinessObjectResponse(List <IBusinessObject> businessObjects) {
		setResults(businessObjects);
	}

	/**
	 * This method returns the results of the retrieve business object function in persistence service.
	 * 
	 * @return the domainObject
	 */
	public List <IBusinessObject> getResults() {
		super.throwExceptionIfErrorFound();
		return businessObjects;
	}

	/**
	 * Checks for results.
	 * 
	 * @return true, if successful
	 */
	public boolean hasResults() {
		return businessObjects != null && !businessObjects.isEmpty();
	}

	/**
	 * This method sets the results to this response object.
	 * 
	 * @param businessObject the domainObject to set
	 */
	private void setResults(List <IBusinessObject> businessObject) {
		this.businessObjects = businessObject;
	}
}
/**
 * Modification History:
 * 
 * $Log: RetrieveBusinessObjectResponse.java,v $
 * Revision 1.1  2012/10/01 02:57:16  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.3  2010/11/24 07:43:33  mwpxp2
 * Added hasResults/0
 *
 * Revision 1.2  2010/10/13 00:58:05  mwpxp2
 * Added constructors from super; added todo
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.9  2009/10/13 23:18:03  mwrsk
 * Moved PersistenceServiceResponse to impl package
 *
 * Revision 1.8  2009/10/03 21:32:42  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.7  2009/09/11 00:12:39  mwrsk
 * added throwExceptionIfErrorFound();
 *
 * Revision 1.6  2009/08/27 06:29:19  mwpxp2
 * Fixed imports for fw migration to compile; bulk cleanup
 *
 * Revision 1.5  2009/08/27 03:39:32  mwsmg6
 * moved framework-related classes to the Framework project
 *
 * Revision 1.4  2009/08/26 23:47:14  mwrsk
 * Added a new constructor which takes exception as an argument
 *
 * Revision 1.3  2009/08/06 21:28:56  mwakg
 * Merging from MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 *
 * Revision 1.2.2.1  2009/08/06 16:25:16  mwakg
 * Changed the design of PersistenceService. Instead of working with BusinessObject PersistenceService is now working with IBusinessObject
 *
 * Revision 1.2  2009/07/30 17:17:11  mwakg
 * Refactored all setter methods in responses of the PersistenceService to private methods.
 *
 * Revision 1.1  2009/07/29 16:56:58  mwakg
 * Changed the design of persistence service hence refractored code accordingly
 *
 * Revision 1.2  2009/07/21 21:48:03  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.1  2009/07/15 00:59:39  mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.2  2009-07-12 18:18:00  mwpxp2
 * Imports adjusted
 *
 * Revision 1.1  2009-07-11 17:18:10  mwpxp2
 * Moved to .impl package; changed superclass; cleaned up comments and javadoc; added todos
 *
 * Revision 1.1  2009-07-10 07:13:56  mwpxp2
 * Synch
 * Revision 1.1 May 6, 2009 4:34:13
 * PM MWAKG Initial commit
 * 
 */
