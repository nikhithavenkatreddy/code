/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.error.impl;

import gov.ca.dmv.ease.fw.error.IErrorMessage;

import java.io.Serializable;

/**
 * Description: This class represents Error Message.
 * File: ErrorMessage.java
 * Module:  gov.ca.dmv.ease.fw.error.impl
 * Created: Jul 22, 2009
 * 
 * @author MWHXA2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ErrorMessage implements IErrorMessage, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2530895562165340743L;
	/** Holds Error Code. */
	private String errorCode;
	/** Holds Error Text. */
	private String errorText;
	/** The message parameters. */
	private String[] messageParameters;
	/** Holds Error Text. */
	private String errorType;
	/** Holds Error Field Name */
	private String errorField;
	/**
	 * Overridden Constructor.
	 * Takes Error Code as an Input Parameter.
	 * 
	 * @param errorCode The Error Code
	 */
	public ErrorMessage(String errorCode) {
		this.errorCode = errorCode;
	}
	
	/**
	 * Overridden Constructor.
	 * Takes Error Code and Error Text as Input Parameters.
	 * 
	 * @param errorCode The Error Code
	 * @param errorText The Error Text
	 * @param messageParameters the message parameters
	 */
	public ErrorMessage(String errorCode, String errorText,
			String[] messageParameters) {
		this.errorCode = errorCode;
		this.errorText = errorText;
		this.messageParameters = messageParameters;
	}
	
	/**
	 * Overridden Constructor.
	 * Takes Error Code and Error Text as Input Parameters.
	 * 
	 * @param errorCode The Error Code
	 * @param errorText The Error Text
	 * @param messageParameters the message parameters
	 */
	public ErrorMessage(String errorCode, String errorText,
			String[] messageParameters, String errorField) {
		this.errorCode = errorCode;
		this.errorText = errorText;
		this.messageParameters = messageParameters;
		this.errorField = errorField;
	}

	/**
	 * Gets the Error Code.
	 * 
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * Gets the Error Text.
	 * 
	 * @return the errorText
	 */
	public String getErrorText() {
		return this.errorText;
	}

	/**
	 * Sets the Error Code.
	 * 
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Sets the Error Text.
	 * 
	 * @param errorText the errorText to set
	 */
	public void setErrorMessage(String errorText) {
		this.errorText = errorText;
	}


	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorMessage#getMessageParameters()
	 */
	public String[] getMessageParameters() {
		return messageParameters;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(64);
		aBuilder.append("Error: ").append(this.errorCode).append(" \"").append(
				this.errorText).append("\";");
		return aBuilder.toString();
	}

	/**
	 * @param errorType the errorType to set
	 */
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	/**
	 * @return the errorType
	 */
	public String getErrorType() {
		return errorType;
	}

	/**
	 * @param errorField the errorField to set
	 */
	public void setErrorField(String errorField) {
		this.errorField = errorField;
	}

	/**
	 * @return the errorField
	 */
	public String getErrorField() {
		return errorField;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ErrorMessage.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2011/03/03 20:01:02  mwsyk1
 *  Reverted to version 1.8
 *
 *  Revision 1.7  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.6  2010/11/17 21:38:45  mwnrk
 *  Code added for Informational Messages.
 *
 *  Revision 1.5  2010/09/29 20:32:34  mwtjc1
 *  data type of messageParameters is changed to String[]
 *
 *  Revision 1.4  2010/09/28 18:06:13  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.3  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/05/05 02:16:00  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/23 17:11:23  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.3  2009/10/06 18:45:56  mwpxp2
 *  Removed obsolete todo
 *
 *  Revision 1.2  2009/10/04 00:56:20  mwpxp2
 *  Added toString
 *
 *  Revision 1.1  2009/10/03 20:17:07  mwpxp2
 *  Moved to fw.error.impl ; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/07/23 18:44:40  mwhxa2
 *  Adding Error Message class
 *
*/
