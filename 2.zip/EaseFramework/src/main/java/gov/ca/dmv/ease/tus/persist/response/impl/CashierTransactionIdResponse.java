/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: I am response to CashierTransactionIdRequest carrying incremented cashier transaction id
 * File: CashierTransactionIdResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Dec 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CashierTransactionIdResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5490526120031274964L;
	/** The incremented id. */
	private Integer incrementedId;

	/**
	 * 
	 * 
	 * @param ex 
	 */
	public CashierTransactionIdResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * 
	 * 
	 * @param collector 
	 */
	public CashierTransactionIdResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new cashier transaction id response.
	 * 
	 * @param aValue 
	 */
	public CashierTransactionIdResponse(int aValue) {
		super();
		setIncrementedId(aValue);
	}

	/**
	 * 
	 * 
	 * @return the incrementedId
	 */
	public int getIncrementedId() {
		if (incrementedId == null) {
			throw new EaseValidationException(
					"null cashier transaction id value in: " + this);
		}
		return incrementedId.intValue();
	}

	/**
	 * 
	 * 
	 * @param anInt 
	 */
	protected void setIncrementedId(int anInt) {
		incrementedId = Integer.valueOf(anInt);
		setAffectedItemsCount(1);
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("incrementedId", incrementedId, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: CashierTransactionIdResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/15 02:22:20  mwpxp2
 *  Initial
 *
 */
