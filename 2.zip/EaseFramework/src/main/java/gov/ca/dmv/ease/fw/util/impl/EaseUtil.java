/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.util.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am Utility Class. I provide common utilities
 * File: EaseUtil.java
 * Module:  gov.ca.dmv.ease.fw.util
 * Created: Oct 11, 2009
 * @author MWAKG
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2017/05/30 15:09:52 $
 * Last Changed By: $Author: mwskh1 $
 */
public class EaseUtil {
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory.getLog(EaseUtil.class);

	/**
	 * Gets the codes from code elements.
	 *
	 * @param codeSetElements the code set elements
	 * @return the codes from code elements
	 */
	public static List <String> getCodesFromCodeElements(
			List <CodeSetElement> codeSetElements) {
		//FIXME this method belongs to gov.ca.dmv.ease.bo.code.impl.CodeSet
		//TODO move and provide redirection
		List <String> codeSetElementCodes = new ArrayList <String>();
		if (EaseUtil.isNotNull(codeSetElements)) {
			for (CodeSetElement codeSetElement : codeSetElements) {
				if (EaseUtil.isNotNull(codeSetElement)) {
					codeSetElementCodes.add(codeSetElement.getCode());
				}
			}
		}
		return codeSetElementCodes;
	}

	/**
	 * Checks if is code found in code set elements.
	 *
	 * @param codeSetElements the code set elements
	 * @param code the code
	 * @return true, if successful
	 */
	public static boolean isCodeFoundInCodeSetElements(
			List <CodeSetElement> codeSetElements, String code) {
		List <String> codeSetElementCodes = getCodesFromCodeElements(codeSetElements);
		return codeSetElementCodes.contains(code);
	}

	/**
	 * Checks if is not blank.
	 *
	 * @param aString
	 *            the a string
	 *
	 * @return true, if is not blank
	 */
	public static boolean isNotBlank(String aString) {
		return aString != null && aString.trim().length() > 0;
	}

	/**
	 * Checks if is not null.
	 *
	 * @param anObject
	 *            the input object
	 *
	 * @return true, if is not null
	 */
	public static boolean isNotNull(Object anObject) {
		return anObject != null;
	}

	/**
	 * Checks if is not null and is true.
	 *
	 * @param varBoolean the var boolean
	 * @return true, if is not null and is true
	 */
	public static boolean isNotNullAndIsTrue(Boolean varBoolean) {
		if (varBoolean != null && varBoolean) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if is null or blank.
	 *
	 * @param codeSetElement the code set element
	 * @return true, if is null or blank
	 */
	public static boolean isNullOrBlank(CodeSetElement codeSetElement) {
		if (codeSetElement == null) {
			return true;
		}
		return isNullOrBlank(codeSetElement.getCode()) ? true : false;
	}

	/**
	 * Checks if is null or blank.
	 *
	 * @param collection the collection
	 * @return true, if is null or blank
	 */
	public static boolean isNullOrBlank(Collection <?> collection) {
		if (collection == null) {
			return true;
		}
		return (collection.size() == 0) ? true : false;
	}

	/**
	 * Check if Input Object is Null or Blank.
	 *
	 * @param anObject the an object
	 * @return true, if null or blank
	 */
	public static boolean isNullOrBlank(Object anObject) {
		if (anObject == null) {
			return true;
		}
		return false;
	}

	/**
	 * Check if Input Object is Null or Blank.
	 *
	 * @param anObject the an object
	 * @return true, if null or blank
	 */
	public static boolean isNullOrBlank(String aString) {
		if (aString == null) {
			return true;
		}
		return (aString.trim().equals("")) ? true : false;
	}

	/**
	 * Check for string is numeric or not.
	 * @param str
	 * @return true if number otherwise false.
	 */
	public static boolean isNumeric(String str) {
		try {
			Integer.parseInt(str);
		}
		catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	/**
	 * This method finds if the two dates is the same or not.
	 *
	 * @param compareDate the compare date
	 * @param compareToDate the compare to date
	 * @return true if compareDate and compareToDate are the same date.
	 */
	public static final boolean isSameDate(Date compareDate, Date compareToDate) {
		boolean isSameDate = false;
		if (compareDate == null && compareToDate == null) {
			isSameDate = true;
		}
		else if (compareDate != null && compareToDate != null) {
			//TODO why not use java.util.Date.equals(Object)?
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String compareString = dateFormat.format(compareDate);
			String compareToString = dateFormat.format(compareToDate);
			if (compareString.equals(compareToString)) {
				isSameDate = true;
			}
		}
		return isSameDate;
	}
	
	public static final <T> void removeElementsFromHead(int numberToRemove, List<T> list) {
		int end = list.size();
		if (end > numberToRemove) {
			end = numberToRemove;
		}	
		list.subList(0, end).clear();
	}
	
	/**
     * convert from blank to null.
     *
     * @param aString
     *            the a string
     *
     * @return null, if is blank
     */
     public static String convertBlankToNull(String aString) {
           if (aString != null && "".equals(aString.trim())) {
                 return null;
           }
           return aString;
     }
     
     /**
      * convert from zero to null.
      *
      * @param aNumber the a string
      *
      * @return null, if is zero
      */
     public static Integer convertZeroToNull(Integer aNumber){
    	 final int ZERO = 0;
    	 if (isNotNull(aNumber)){
             if (aNumber.compareTo(Integer.valueOf(ZERO)) == 0){
            	 aNumber = null;
             }  
    	 }
    	 return aNumber; 
     }
}
/**
 * Modification History:
 *
 * $Log: EaseUtil.java,v $
 * Revision 1.4  2017/05/30 15:09:52  mwskh1
 * WAS 8.5.5, Java 7 setting changes
 *
 * Revision 1.2.18.2  2017/05/25 20:44:37  mwjmf6
 * Add convertZeroToNull() - to prevent backing beans from passing null values in Integer fields as zero
 *
 * Revision 1.3  2017/05/11 16:26:48  mwskh1
 * WAS 8.5.5, Java 7 setting changes
 *
 * Revision 1.2.18.1  2017/02/27 19:40:00  mwjmf6
 * Add convertBlankToNull method to check for blank fields in backing beans and convert them to null.
 *
 * Revision 1.2  2013/06/26 21:59:50  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/01/31 17:59:51  mwsec2
 * added removeElementsFromHead and test method
 *
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.16  2012/08/16 18:30:33  mwkfh
 * removed getEaseEnv
 *
 * Revision 1.15  2012/08/15 23:10:26  mwpxp2
 * Soreted members; added fixmes and todos
 *
 * Revision 1.14  2012/01/30 23:53:42  mwsec2
 * FODI integration code merged to HEAD
 *
 * Revision 1.13  2011/06/09 18:00:40  mwyxg1
 * clean up
 *
 * Revision 1.12  2011/06/01 00:31:43  mwkfh
 * removed isNotNullAndIsFalse
 *
 * Revision 1.11  2011/05/31 21:29:14  mwtjc1
 * isNotNullAndIsTrue and isNotNullAndIsFalse added
 *
 * Revision 1.10  2011/05/10 21:59:49  mwrrv3
 * Added new method isNumeric for checking numeric or not.
 *
 * Revision 1.9  2011/03/03 18:32:43  mwtjc1
 * isCodeFoundInCodeSetElements added
 *
 * Revision 1.8  2011/03/03 18:30:01  mwtjc1
 * getCodesFromCodeElements added
 *
 * Revision 1.7  2011/01/27 01:22:28  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * logger info statements added
 *
 * Revision 1.6  2011/01/22 19:14:36  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * getEASEEnv method modified
 *
 * Revision 1.5  2010/12/27 21:39:38  mwxxw
 * Updated to use standard LOGGER.
 *
 * Revision 1.4  2010/12/17 17:53:35  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * getEASEEnv cleanUp
 *
 * Revision 1.3  2010/12/16 19:57:48  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * getEASEEnv method added.
 *
 * Revision 1.2  2010/12/02 00:50:11  mwhys
 * Updated
 *
 * Revision 1.1  2010/12/02 00:13:52  mwhys
 * Fixed and moved EaseUtil to .impl package.
 *
 * Revision 1.9  2010/08/20 18:22:13  mwpxp2
 * Fixed class header; added todos and fixmes
 *
 * Revision 1.8  2010/07/21 18:00:37  mwpxp2
 * Added todo
 *
 * Revision 1.7  2010/07/08 02:04:40  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.6  2010/06/21 23:00:41  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.3.16.2  2010/06/20 18:06:53  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.5  2010/06/02 15:37:02  mwbxp5
 * *** empty log message ***
 * Revision 1.4 2010/06/02 15:35:57 mwbxp5 Added util
 * for IPromise Revision 1.3 2010/04/12 20:06:57 mwtjc1 isNullOrBlank method is
 * updated
 *
 * Revision 1.2 2010/03/22 23:34:42 mwpxp2 Bulk cleanup
 *
 * Revision 1.1 2009/11/23 16:22:52 mwrsk Intial commit
 *
 * Revision 1.2 2009/11/02 17:10:52 mwhxa2 Updated Java Docs
 *
 * Revision 1.1 2009/10/11 22:51:35 mwakg Refactored validation framework and
 * its implementing code
 *
 *
 */
