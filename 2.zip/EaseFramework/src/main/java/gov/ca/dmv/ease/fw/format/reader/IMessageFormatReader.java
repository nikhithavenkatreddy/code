/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.reader;

import gov.ca.dmv.ease.fw.format.IFormatConstants;
import gov.ca.dmv.ease.fw.format.IMessageFormat;

/**
 * Description: I am interface for a class producing instances of IMessageFormat from string representations of them
 * File: IMessageFormatReader.java
 * Module:  gov.ca.dmv.ease.fw.format.reader
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageFormatReader extends IFormatReaderConstants {
	/**
	 * Read from.
	 * 
	 * @param aString 
	 * 
	 * @return the i message format
	 */
	IMessageFormat readFrom(String aString);
}
/**
 *  Modification History:
 *
 *  $Log: IMessageFormatReader.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/01 01:29:27  mwpxp2
 *  Adjusted super interfaces
 *
 *  Revision 1.4  2010/12/01 01:23:13  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.3  2010/11/29 07:44:38  mwpxp2
 *  Deleted obsolete stuff
 *
 *  Revision 1.2  2010/11/25 00:58:05  mwpxp2
 *  Cleanup
 *
 *  Revision 1.1  2010/11/24 20:41:06  mwpxp2
 *  Initial
 *
 */
