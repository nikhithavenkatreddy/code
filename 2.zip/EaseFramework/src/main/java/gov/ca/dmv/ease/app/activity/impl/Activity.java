/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.action.impl.ActionsRegistry;
import gov.ca.dmv.ease.app.activity.IActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.context.impl.ExecutionSyncPoint;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessExecutionException;
import gov.ca.dmv.ease.app.session.factory.impl.SessionServiceRequestFactory;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.app.session.request.ISessionServiceRequest;
import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.app.session.response.impl.DeleteSessionResponse;
import gov.ca.dmv.ease.app.session.response.impl.StoreSessionResponse;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.IErrorCollectorEntry;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessage;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.IResponse;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.validator.IValidationRule;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am implementation of activity - a step in business process
 * File: Activity.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created: Mar 20, 2009
 * @author mwrsk  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class Activity implements IActivity, Serializable {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(Activity.class);
	/** controls output of memory state from runtime; should be false most of the time. */
	protected static final boolean PRINT_MEMORY_INFO = false;
	/** controls session management. */
	//Note: This is not 'final' because, we want to turn session mgmt off for unit test.
	private static boolean SESSION_MANAGEMENT_ENABLED = true;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1919670959493886163L;

	/**
	 * Gets the prints the memory info.
	 *
	 * @return the prints the memory info
	 */
	protected static String getPrintMemoryInfo() {
		Runtime aRuntime = Runtime.getRuntime();
		StringBuilder aBuilder = new StringBuilder(64);
		long aTotal = aRuntime.totalMemory();
		long aFree = aRuntime.freeMemory();
		aBuilder.append("\ttotal:\t").append(aTotal);
		aBuilder.append("\tfree:\t").append(aFree);
		aBuilder.append("\tused:\t").append(aTotal - aFree);
		return aBuilder.toString();
	}

	/**
	 * Prints the memory info.
	 *
	 * @param aMessage the a message
	 */
	protected static void printMemoryInfo(String aMessage) {
		LOGGER.info(aMessage + getPrintMemoryInfo());
	}

	/** The action registry. */
	private transient ActionsRegistry actionsRegistry;
	/** The name. */
	protected String activityName;
	/** indicates if activity is a sync point (a fallback destination). */
	private boolean isSyncPoint = false;
	/** indicates if activity is a save point (session save/restore point). */
	private boolean savePoint;
	/** Post condition validation rules. */
	private transient List <IValidationRule> postConditionValidationRules;
	/** Pre condition validation rules. */
	private transient List <IValidationRule> preConditionValidationRules;
	/** The process registry. */
	private transient IProcessRegistry processRegistry;
	/** The transaction type registry. */
	private transient ITransactionTypeRegistry transactionTypeRegistry;

	/**
	 * Process rule results.
	 * 
	 * @param rules the rules
	 * @param context the context
	 */
	private void applyValidationRules(List <IValidationRule> rules,
			ProcessContext context) {
		if (rules != null) {
			IErrorCollector aCollector = new ErrorCollector();
			for (IValidationRule rule : rules) {
				rule.validate(context, aCollector);
				populateErrorMessages(context, aCollector);
			}
		}
	}

	/**
	 * Creates a save point for the session data.
	 *
	 * @param processContext the process context
	 */
	protected void createSavePoint(ProcessContext processContext) {
		if (isSessionManagementEnabled()) {
			LOGGER.info("Creating save point for " + getActivityName());
			storeApplicationState(processContext);
		}
	}

	/**
	 * Delete save point.
	 *
	 * @param sessionContext the session context
	 */
	protected void deleteSavePoint(SessionContext sessionContext) {
		if (isSessionManagementEnabled()) {
			IUserContext userContext = sessionContext.getUserContext();
			ISessionServiceRequest deleteRequest = SessionServiceRequestFactory
					.getInstance().createDeleteSessionRequest(userContext);
			ISessionServiceResponse deleteResponse = (DeleteSessionResponse) deleteRequest
					.execute();
			if (deleteResponse.hasErrors()) {
				LOGGER.error("Error deleting session state for user '"
						+ userContext.getUserName() + "'. Reason: "
						+ deleteResponse.getErrorCollector());
			}
			else {
				sessionContext.setSessionSysId(null);
				LOGGER.info("Session state is deleted for user '"
						+ userContext.getUserName() + "'.");
			}
		}
	}

	/**
	 * Disable session management.
	 */
	public static void disableSessionManagement() {
		SESSION_MANAGEMENT_ENABLED = false;
	}

	/**
	 * Enable session management enabled.
	 */
	public static void enableSessionManagementEnabled() {
		SESSION_MANAGEMENT_ENABLED = true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.IActivity#execute(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public void execute(ProcessContext processContext) {
		if (PRINT_MEMORY_INFO) {
			printMemoryInfo(getClass().getSimpleName() + "::execute\tstart: ");
		}
		if (!processContext.getMessageCollector().hasValidationErrors()) {
			processContext.setCurrentActivity(this);
			LOGGER.info(processContext.getProcessId() + " is executing :: " + activityName);
			preCondition(processContext);
			executeAuthorized(processContext);
			if (PRINT_MEMORY_INFO) {
				printMemoryInfo(getClass().getSimpleName() + "::execute\tend: ");
			}
		}
		else {
			if (PRINT_MEMORY_INFO) {
				printMemoryInfo(getClass().getSimpleName()
						+ "::execute\terror: ");
			}
			if (LOGGER.isErrorEnabled()) {
				// If any business or data validation errors occurred then log
				// them in the log file with error codes.
				StringBuilder errorCodes = new StringBuilder();
				if (processContext.getMessageCollector() != null) {
					Map<String, ErrorMessage> errorMsgMap = processContext
							.getMessageCollector().getValidationMessages();
					if (errorMsgMap != null && errorMsgMap.keySet() != null) {
						Iterator<String> keys = errorMsgMap.keySet().iterator();
						while (keys.hasNext()) {
							errorCodes.append(keys.next()).append(" ");
						}
					}
				}
				LOGGER
						.error("Activity: Business/Validation errors occurred, error codes: "
								+ errorCodes.toString()
								+ " TTC: "
								+ processContext.getUserContext().getTtc());
			}
		}
	}

	/**
	 * Execute an activity that has been authorized. This should be a protected call
	 * 
	 * @param context the context
	 */
	protected abstract void executeAuthorized(ProcessContext context);

	/**
	 * Gets the actions registry. 
	 *
	 * @return the actionRegistry
	 */
	public ActionsRegistry getActionsRegistry() {
		return actionsRegistry;
	}

	/**
	 * Gets the activity name.
	 * 
	 * @return the activity name
	 */
	public final String getActivityName() {
		return activityName;
	}

	/**
	 * Gets the post condition validation rules.
	 *
	 * @return the postConditionValidationRules
	 */
	public List <IValidationRule> getPostConditionValidationRules() {
		return postConditionValidationRules;
	}

	/**
	 * Gets the pre condition validation rules.
	 *
	 * @return the preConditionValidationRules
	 */
	public List <IValidationRule> getPreConditionValidationRules() {
		return preConditionValidationRules;
	}

	/**
	 * Gets the process registry.
	 *
	 * @return the processRegistry
	 */
	public IProcessRegistry getProcessRegistry() {
		return processRegistry;
	}

	/**
	 * Gets the TransactionType registry.
	 *
	 * @return the transaction type registry
	 */
	public ITransactionTypeRegistry getTransactionTypeRegistry() {
		return transactionTypeRegistry;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.IActivity#isNamed(java.lang.String)
	 */
	public final boolean isNamed(String aName) {
		if (aName == null) {
			return getActivityName() == null;
		}
		else {
			return aName.equalsIgnoreCase(getActivityName());
		}
	}

	/**
	 * Return true if the action is not empty or byPass validations.
	 *
	 * @param context the context
	 * @return true, if is not by pass validations
	 */
	//TODO: Remove when architecture is done
	protected boolean isNotByPassValidations(ProcessContext context) {
		//TODO - what does this mean!?
		boolean isNotByPassValidations = false;
		if (context.getSelectedAction() != null
				&& !context.getSelectedAction().isByPassValidations()) {
			isNotByPassValidations = true;
		}
		return isNotByPassValidations;
	}

	/**
	 * Return true if the action is not empty or cancel or restart action.
	 *
	 * @param context the context
	 * @return true, if is not empty or cancel or restart
	 */
	//TODO: Remove when architecture is done
	protected boolean isNotEmptyOrCancelOrRestart(ProcessContext context) {
		boolean isNotEmptyOrCancelOrRestart = false;
		Action selectedAction = context.getSelectedAction();
		if (selectedAction != null) {
			if (!selectedAction.equals(getActionsRegistry().getAction(
					IActionNamesConstants.RESTART_ACTION))
					&& !selectedAction.equals(getActionsRegistry().getAction(
							IActionNamesConstants.CANCEL_ACTION))) {
				isNotEmptyOrCancelOrRestart = true;
			}
		}
		return isNotEmptyOrCancelOrRestart;
	}

	/**
	 * Checks if is save point.
	 *
	 * @return the save point indicator
	 */
	protected boolean isSavePoint() {
		return savePoint;
	}

	/**
	 * Checks if is session management enabled.
	 *
	 * @return true, if is session management enabled
	 */
	public static boolean isSessionManagementEnabled() {
		return SESSION_MANAGEMENT_ENABLED;
	}

	/**
	 * Checks if is sync point.
	 *
	 * @return the syncPoint
	 */
	public boolean isSyncPoint() {
		return isSyncPoint;
	}

	/**
	 * Not done yet.
	 * 
	 * @param aMsg the a msg
	 */
	protected void notDoneYet(String aMsg) {
		if (aMsg != null) {
			LOGGER.debug(aMsg + "not done in " + getClass().getCanonicalName());
		}
	}

	/**
	 * Populate error messages.
	 * 
	 * @param aContext the a context
	 * @param aCollector the a collector
	 */
	protected void populateErrorMessages(IProcessContext aContext,
			IErrorCollector aCollector) {
		if (aCollector != null && !(aCollector.isEmpty())) {
			for (IErrorCollectorEntry anEntry : aCollector.getEntries()) {
				aContext.getMessageCollector().addValidationMessage(
						anEntry.getExceptionMessage(),
						new ErrorMessage(anEntry.getExceptionClassName(),
								anEntry.getExceptionMessage(), anEntry
										.getMessageParameters(), anEntry
										.getErrorFieldToFocus()));
			}
		}
	}

	/**
	 * Populates context's ErrorMessageCollector using IErrorCollector from CourtInquiryResponseTs.
	 * 
	 * @param aContext the a context
	 * @param aResponse the a response
	 */
	protected void populateErrorMessages(IProcessContext aContext,
			IResponse aResponse) {
		if (aResponse.hasErrors()) {
			populateErrorMessages(aContext, aResponse.getErrorCollector());
		}
	}

	/**
	 * Provide hooks for doing some post processing after an activity is executed.
	 * 
	 * @param context the context
	 */
	protected void postCondition(ProcessContext context) {
		//NOTE this method is to validate postconditions after execution of the activity
		//by examining the process context
		//postconditions violations - which mean that the activity did not perform as expected -
		//are expected to be signaled by EaseException subclasses
		if (context.getSelectedAction() != null) {
			if (!context.getSelectedAction().isByPassValidations()) {
				applyValidationRules(getPostConditionValidationRules(), context);
			}
		}
	}

	/**
	 * Provide hooks for doing some pre processing before an activity is executed.
	 * 
	 * @param context the context
	 */
	protected void preCondition(ProcessContext context) {
		//NOTE this method is to validate preconditions for execution of the activity
		//by examining the process context
		//precondition violations are expected to be signaled by EaseException subclasses
		if (context.getSelectedAction() != null
				&& !context.getSelectedAction().isByPassValidations()) {
			applyValidationRules(getPreConditionValidationRules(), context);
		}
	}

	/**
	 * Set the properties from application context during serialization.
	 *
	 * @param objectInputStream the object input stream
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ClassNotFoundException the class not found exception
	 */
	private void readObject(ObjectInputStream objectInputStream)
			throws IOException, ClassNotFoundException {
		actionsRegistry = EaseApplicationContext.getActionsRegistry();
		processRegistry = EaseApplicationContext.getProcessRegistry();
		transactionTypeRegistry = EaseApplicationContext
				.getTransactionTypeRegistry();
		objectInputStream.defaultReadObject();
	}

	/**
	 * Sets the actions registry.
	 *
	 * @param aRegistry the new actions registry
	 */
	public void setActionsRegistry(ActionsRegistry aRegistry) {
		actionsRegistry = aRegistry;
	}

	/**
	 * Gets the activity name.
	 *
	 * @param aName the new activity name
	 * @return the activity name
	 */
	public void setActivityName(String aName) {
		activityName = aName;
	}

	/**
	 * Sets the post condition validation rules.
	 *
	 * @param ruleList the new post condition validation rules
	 */
	public void setPostConditionValidationRules(List <IValidationRule> ruleList) {
		postConditionValidationRules = ruleList;
	}

	/**
	 * Sets the pre condition validation rules.
	 *
	 * @param ruleList the new pre condition validation rules
	 */
	public void setPreConditionValidationRules(List <IValidationRule> ruleList) {
		preConditionValidationRules = ruleList;
	}

	/**
	 * Sets the process registry.
	 *
	 * @param aRegistry the new process registry
	 */
	public void setProcessRegistry(IProcessRegistry aRegistry) {
		processRegistry = aRegistry;
	}

	/**
	 * Sets the save point.
	 *
	 * @param aFlag the new save point
	 */
	public void setSavePoint(boolean aFlag) {
		savePoint = aFlag;
	}

	/**
	 * Sets the sync point.
	 *
	 * @param aFlag the new sync point
	 */
	public void setSyncPoint(boolean aFlag) {
		isSyncPoint = aFlag;
	}

	/**
	 * Sets the transaction type registry.
	 *
	 * @param transactionTypeRegistry the new transaction type registry
	 */
	public void setTransactionTypeRegistry(
			ITransactionTypeRegistry transactionTypeRegistry) {
		this.transactionTypeRegistry = transactionTypeRegistry;
	}

	/**
	 * Signal invalid next activity for.
	 *
	 * @param processContext the process context
	 */
	protected final void signalInvalidNextActivityFor(
			ProcessContext processContext) {
		String msg = "TRANSITION KEY ERROR, transition key for next activity undefined or defined incorrectly in activity:  "
				+ getActivityName()
				+ " current interaction activity: "
				+ processContext.getCurrentInteractionActivity()
				+ " in process id: " + processContext.getProcessId();
		LOGGER.info(msg);
		throw new ProcessExecutionException(msg);
	}

	/**
	 * Store application state.
	 *
	 * @param processContext the process context
	 */
	@SuppressWarnings("unchecked")
	private void storeApplicationState(ProcessContext processContext) {
		/* Session scoped session-context from the spring configuration */
		ISessionContext sessionContext = processContext.getRootContext();
		IUserContext userContext = (IUserContext) EaseProxyUtils
				.getProxyObject(sessionContext.getUserContext());
		Stack <ExecutionSyncPoint> executionSyncPoints = (Stack <ExecutionSyncPoint>) EaseProxyUtils
				.getProxyObject(sessionContext.getExecutionSyncPoints());
		IProcessContext rollbackProcessContext = sessionContext
				.getRollbackProcessContext();
		SubprocessActivity rollbackSubprocessActivity = sessionContext
				.getRollbackSubprocessActivity();
		String rollbackSubprocessActivityName = null;
		if (!EaseUtil.isNullOrBlank(rollbackSubprocessActivity)) {
			rollbackSubprocessActivityName = rollbackSubprocessActivity
					.getClass().getSimpleName();
		}
		SessionData sessionData = new SessionData(sessionContext
				.getCurrentProcessContext(), userContext, executionSyncPoints,
				rollbackProcessContext, rollbackSubprocessActivityName);
		try {
			Session sessionToStore = new Session(userContext);
			//Set the SYS_ID of the session that was initially created.
			if (!EaseUtil.isNullOrBlank(sessionContext.getSessionSysId())
					&& sessionContext.getSessionSysId() != 0) {
				sessionToStore.setId(sessionContext.getSessionSysId());
			}
			ISessionServiceRequest storeRequest = SessionServiceRequestFactory
					.getInstance().createStoreSessionRequest(userContext,
							sessionToStore, sessionData);
			ISessionServiceResponse storeResponse = (StoreSessionResponse) storeRequest
					.execute();
			
			if (storeResponse.hasErrors()) {
				LOGGER.error("Error storing session state for user '"
						+ userContext.getUserName() + "'. Reason: "
						+ storeResponse.getErrorCollector());
			}
			else {
				LOGGER.info("Session state is stored for user '"
						+ userContext.getUserName() + "'.");
				//For the very first time, when a session is saved in DB2, 
				//a new SYS_ID is assigned by hibernate (save it in the context).
				if (EaseUtil.isNullOrBlank(sessionContext.getSessionSysId())) {
					((SessionContext) sessionContext)
							.setSessionSysId(sessionToStore.getId());
				}
			}
			LOGGER.info("Last Interaction Activity Name :"
					+ sessionData.getPreviousInteractionActivityName());
			LOGGER.info("Next Interaction Activity Name :"
					+ sessionData.getCurrentInteractionActivityName());
		}
		catch (EaseValidationException e) {
			LOGGER.info(e.toString());
		}
	}

	/**
	 * Validate context.
	 *
	 * @param processContext the process context
	 */
	protected void validateContext(ProcessContext processContext) {
		//subclasses may redefine/extend
		if (processContext == null) {
			throw new EaseValidationException(
					"the process context must not be null in " + this);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: Activity.java,v $
 *  Revision 1.7  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.3.2.5  2013/04/30 16:49:40  mwsec2
 *  adjusted logging statements
 *
 *  Revision 1.3.2.4  2013/02/28 19:57:01  mwsec2
 *  rebase from HEAD
 *
 *  Revision 1.6  2013/01/11 23:35:36  mwrrv3
 *  Updated execute() to put the proper information in the log after any validation errors occurred.
 *
 *  Revision 1.5  2012/12/13 00:28:40  mwhys
 *  Updated storeApplicationState to save and use SYS_ID of the session from the session context.
 *
 *  Revision 1.4  2012/10/19 21:08:34  mwhys
 *  Refactored access modifiers of session mgmt field from 'public static final' to 'private static'
 *  and added methods to enable/disable session mgmt.
 *
 *  Revision 1.3  2012/10/02 23:51:10  mwkfh
 *  enabled session management
 *
 *  Revision 1.2  2012/10/02 23:48:15  mwkfh
 *  disabled session management
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.74  2012/09/25 20:37:29  mwkfh
 *  enabled session management
 *
 *  Revision 1.73  2012/09/25 20:34:23  mwkfh
 *  disabled session management
 *
 *  Revision 1.72  2012/09/12 00:33:02  mwhys
 *  Save rollbackSubprocessActivityName as part of session data. (Defect 7189)
 *
 *  Revision 1.71  2012/08/16 21:04:34  mwkzn
 *  Using Loggers in place of SOP.
 *
 *  Revision 1.70  2012/08/14 20:25:39  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.69  2012/06/05 21:46:54  mwhys
 *  Enabled session management for the current build.
 *
 *  Revision 1.68  2012/06/04 17:24:48  mwhys
 *  Disabled session management for the current build.
 *
 *  Revision 1.67  2012/06/01 21:19:41  mwhys
 *  Updated storeApplicationState() to store rollbackProcessContext. (Session Management)
 *
 *  Revision 1.66  2012/05/22 17:45:41  mwhys
 *  Enable session management.
 *
 *  Revision 1.65  2012/05/10 21:03:19  mwhys
 *  Added a boolean flag to turn on/off session management.
 *
 *  Revision 1.64  2012/05/08 00:03:01  mwhys
 *  Implemented createSavePoint() and added deleteSavePoint() for Session Management.
 *
 *  Revision 1.63  2012/05/07 23:59:47  mwhys
 *  Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 *  Revision 1.62.4.1  2012/02/21 21:15:01  mwsec2
 *  save point support added
 *
 *  Revision 1.62  2011/12/01 04:30:15  mwpxp2
 *  Added isNamed/1
 *
 *  Revision 1.61  2011/11/15 22:35:32  mwkkc
 *  Production Cleanup
 *
 *  Revision 1.60  2011/10/21 20:44:55  mwpxp2
 *  Added signalInvalidNextActivityFor on ProcessContext for uniform treatment of problems with determination of next activity;  throwing of ProcessExecutionException to include information about activity, process, current interaction activity
 *
 *  Revision 1.59  2011/10/12 20:54:54  mwkkc
 *  Performance Merge
 *
 *  Revision 1.55.8.2  2011/09/28 22:54:08  mwpxp2
 *  Added   code in execute to print out ram info and a static flag to control the output - from HEAD 1.57, 1.58.
 *
 *  Revision 1.55.8.1  2011/09/28 02:45:47  mwpxp2
 *  Re-routed named spring calls to a EaseApplicationContext method
 *
 *  Revision 1.55  2011/06/10 20:25:26  mwyxg1
 *  clean up
 *
 *  Revision 1.54  2011/03/01 22:02:34  mwpxp2
 *  Added protected validateContext/1 to be used in internal argument validation
 *
 *  Revision 1.53  2010/12/16 21:15:04  mwsec2
 *  TODO replaced with explanatory comment
 *
 *  Revision 1.52  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.51  2010/11/09 03:19:29  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.50  2010/11/09 03:17:08  mwpxp2
 *  Renamed processRuleResults to applyValidationRules; adjusted for mods in IValidationRule to allows passing of an error collector rather than using some global error collector in the process context
 *
 *  Revision 1.49  2010/09/28 18:05:33  mwtjc1
 *  populateErrorMessages is changed to support a modified constructor of ErrorMessage class
 *
 *  Revision 1.48  2010/09/23 18:53:14  mwhys
 *  Used readObject method to restore the references to transient objects, from the application context.
 *
 *  Revision 1.47  2010/09/14 17:14:10  mwhys
 *  getProcessRegistry and getTransactionTypeRegistry: Obtain reference to the SINGLETON objects present in the Application context. Used during Session Management.
 *
 *  Revision 1.46  2010/09/04 17:22:04  mwhys
 *  Marked Validation Rules as transient.
 *
 *  Revision 1.45  2010/09/03 16:55:15  mwsec2
 *  TransactionTypeRegistry added as new property, with setter/getter
 *
 *  Revision 1.44  2010/08/27 17:47:25  mwpxp2
 *  Added notDoneYet/1
 *
 *  Revision 1.43  2010/08/20 18:12:01  mwpxp2
 *  Added todos and fixmes; removed spurious this.~es; fixed javadoc
 *
 *  Revision 1.42  2010/08/14 21:50:17  mwyxg1
 *  change valiation to unknown
 *
 *  Revision 1.41  2010/08/10 23:03:02  mwakg
 *  Removed getCurrentBusinessProcess() from ProcessContext
 *
 *  Revision 1.40  2010/07/30 21:24:04  mwyxg1
 *  add isNotEmptyOrCancelOrRestart
 *
 *  Revision 1.39  2010/07/30 18:32:12  mwyxg1
 *  fix isNotByPassValidations
 *
 *  Revision 1.38  2010/07/30 18:01:58  mwyxg1
 *  add isNotByPassValidations
 *
 *  Revision 1.37  2010/07/30 17:17:40  mwakg
 *  Executing validations only when the selected action byPassValidation is false
 *
 *  Revision 1.36  2010/07/30 17:10:14  mwyxg1
 *  add null pointer check
 *
 *  Revision 1.35  2010/07/30 00:17:27  mwakg
 *  Executing validations only when the selected action byPassValidation is false
 *
 *  Revision 1.34  2010/07/23 14:49:47  mwakg
 *  Merged from Fallback_branch
 *
 *  Revision 1.30.4.1  2010/06/27 01:42:19  mwakg
 *  Added syncPoint
 *
 *  Revision 1.33  2010/07/14 20:34:53  mwcsj3
 *  Reverted back to version 1.31
 *
 *  Revision 1.32  2010/07/14 17:15:06  mwcsj3
 *  Updated execute method to handle validation error and exception conditions
 *
 *  Revision 1.31  2010/06/27 19:10:09  mwcsj3
 *  Updated populateErrorMessages(), checking for null before populating error messages
 *
 *  Revision 1.30  2010/05/20 18:41:57  mwcsj3
 *  Updated error message in execute method
 *
 *  Revision 1.29  2010/05/18 22:24:01  mwbxp5
 *  Added null check for error collector
 *
 *  Revision 1.28  2010/05/09 18:01:59  mwakg
 *  Moved postCondition to sub classes
 *
 *  Revision 1.27  2010/05/05 19:55:03  mwakg
 *  Stopping the execution if there are any errors in errorCollector
 *
 *  Revision 1.26  2010/05/04 20:44:10  mwakg
 *  Changed the logic of using postCondition in InteractionActivity
 *
 *  Revision 1.25  2010/05/04 18:12:45  mwakg
 *  Fixed fix me
 *
 *  Revision 1.24  2010/05/04 00:59:24  mwpxp2
 *  Added fixme
 *
 *  Revision 1.23  2010/04/29 17:55:01  mwcsj3
 *  Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 *  Revision 1.22  2010/04/27 20:59:25  mwcsj3
 *  Added condition for postValidate method call in execute method
 *
 *  Revision 1.21  2010/04/22 19:08:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.20  2010/04/22 19:02:34  mwpxp2
 *  Added comments to ~Validate and fixmes
 *
 *  Revision 1.19  2010/04/08 23:46:27  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.18  2010/04/07 22:19:16  mwcsj3
 *  Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 *  Revision 1.17  2010/04/05 00:31:46  mwakg
 *  Fixed injection issue
 *
 *  Revision 1.16  2010/04/04 23:32:00  mwakg
 *  Removed ProcessContext from Activity class as it is invalid and not used by anyone
 *
 *  Revision 1.15  2010/04/04 23:29:34  mwakg
 *  Changed ProcessRegistry variable to private and made a getter method for it
 *
 *  Revision 1.14  2010/04/04 23:15:32  mwakg
 *  Removed usage for isNullOrEmpty from activity class as it does not belong there
 *
 *  Revision 1.13  2010/04/04 22:48:18  mwakg
 *  As beans should not be aware of the container I have removed support for ApplicationContextAware for all activities
 *
 *  Revision 1.12  2010/04/04 22:44:35  mwakg
 *  Added ActionsRegistry entry for all activity
 *
 *  Revision 1.11  2010/04/01 00:11:44  mwakg
 *  Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 *  Revision 1.10  2010/03/29 18:30:36  mwcsj3
 *  Formatted and cleaned TO DO's
 *
 *  Revision 1.9  2010/03/25 17:27:05  mwbxp5
 *  changing the method names from preProcess and postProcess to preValidate and postValidate
 *
 *  Revision 1.8  2010/03/24 18:09:03  mwyxg1
 *  catch exception  in verifyAuthorization
 *
 *  Revision 1.7  2010/03/23 00:23:41  mwpxp2
 *  Simplified populateErrorMessages
 *
 *  Revision 1.6  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.5  2010/03/21 00:07:10  mwakg
 *  Made all the activities ApplicationContextAware
 *
 *  Revision 1.4  2010/03/17 19:23:03  mwcsj3
 *  Fixed issue with setting activity name
 *
 *  Revision 1.3  2010/03/15 18:47:43  mwrka1
 *  isNullorEmpty () updated
 *
 *  Revision 1.2  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.2  2010/02/26 19:34:20  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/02 21:20:53  mwsmg6
 *  Serailizable
 *
 *  Revision 1.3  2009/10/07 19:41:16  mwsmg6
 *  added interface to facilitate design specification
 *
 *  Revision 1.2  2009/10/07 19:16:21  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:57:17  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.11  2009/10/03 19:57:31  mwpxp2
 *  moved in isNullorEmpty/1 from an util class; adjusted imports; added javadoc
 *
 *  Revision 1.10  2009/09/22 23:42:17  mwsmg6
 *  added the relationship to process context
 *
 *  Revision 1.9  2009/09/21 23:06:38  mwpxp2
 *  Split populateErrorMessages/2 into two calls
 *
 *  Revision 1.8  2009/09/03 21:12:49  mwpxp2
 *  Added populateErrorMessages/2
 *
 *  Revision 1.7  2009/08/27 08:25:00  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.6  2009/08/11 15:59:57  mwjjl7
 *  relocate to interaction activity base class
 *
 *  Revision 1.5  2009/08/11 02:20:01  mwpxp2
 *  Added logging; bulk cleanup; added javadoc,  fixed class header
 *
 *  Revision 1.4  2009/08/11 01:59:01  mwjjl7
 *  Add logic that UI can collaborate with.
 *
 *  Revision 1.3  2009/08/10 23:30:07  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
