/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.print.response.impl.QueryPrintJobResponse;
import gov.ca.dmv.ease.tus.print.service.impl.PrintService;

/**
 * Description: This class will invoke HP OS to Query the Status of the Print.
 * File: QueryPrintJobRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: May 3, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class QueryPrintJobRequest extends AbstractPrintServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3247030743643351977L;
	/** The HP OS Print Job Id. */
	private String clientJobId;

	/**
	 * Instantiates a new Query Job request.
	 * 
	 * @param clientJobId the Client Job Id
	 * @param aContext the User Context
	 */
	public QueryPrintJobRequest(String clientJobId, IUserContext aContext) {
		super(aContext);
		setClientJobId(clientJobId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest#execute()
	 */
	@Override
	public QueryPrintJobResponse execute() {
		return PrintService.execute(this);
	}

	/**
	 * Gets the Client Job Id.
	 * 
	 * @return the clientJobId
	 */
	public String getClientJobId() {
		return clientJobId;
	}

//	/* (non-Javadoc)
//	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#getValidator()
//	 */
//	@Override
//	public IValidator getValidator() {
//		return new QueryPrintJobRequestValidator();
//	}

	/**
	 * Sets the Client Job Id.
	 * 
	 * @param anId the clientJobId to set
	 */
	public void setClientJobId(String anId) {
		clientJobId = anId;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: QueryPrintJobRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/07/07 22:50:03  mwhxa2
 *  removing this usage
 *
 *  Revision 1.4  2010/06/30 00:24:26  mwhxa2
 *  Updated Print Request to handle validations
 *
 *  Revision 1.3  2010/06/21 23:00:44  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.6.2  2010/06/20 18:06:55  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/07 17:15:04  mwpxp2
 *  Removed unnecessary t!his.es; bulk cleanup
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
*/
