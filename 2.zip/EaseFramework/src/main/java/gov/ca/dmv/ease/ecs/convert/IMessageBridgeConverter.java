/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.format.IMessageFormat;

/**
 * Description: I am interface for DMVA-bridge specific converters
 * I add facilities to validate fixed - length payloads using textual spec
 * 
 * File: IMessageBridgeConverter.java
 * Module:  gov.ca.dmv.ease.ecs.convert
 * Created: Dec 11, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageBridgeConverter extends IMessageConverter {
	/**
	 * Validate bridge message.
	 * 
	 * @param aPayload 
	 */
	public IErrorCollector validateBridgeMessage(String aPayload);

	/**
	 * Gets the message format.
	 * 
	 * @return the message format
	 */
	public IMessageFormat getMessageFormat();
}
/**
 *  Modification History:
 *
 *  $Log: IMessageBridgeConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 08:24:52  mwpxp2
 *  Changed validate return from void to IErrorCollector
 *
 *  Revision 1.1  2010/12/12 07:01:13  mwpxp2
 *  Initial
 *
 */
