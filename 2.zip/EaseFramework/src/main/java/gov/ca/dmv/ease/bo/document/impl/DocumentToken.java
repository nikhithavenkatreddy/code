/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import java.io.File;

/** 
 * Description: This Business Object is required for Task Services to pass it in their request
 * object while requesting the Short Term Print services for printing a document.
 * File: DocumentToken.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Aug 05, 2009
 * @author MWJXA11
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DocumentToken extends PrintDocument {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2311945592426142246L;
	/** The UNKNOW n_ do c_ type. */
	//private static String UNKNOWN_DOC_TYPE = ".some";
	/** The document type. */
	private String documentType;
	/** The token. */
	private String token;

	/** Default Constructor */
	public DocumentToken() {
		super();
	}

	/**
	 * Gets the document type.
	 * 
	 * @return the documentType
	 */
	public String getDocType() {
		return documentType;
	}

	/**
	 * Gets the document filename.
	 * 
	 * @return the document filename
	 */
	public String getDocumentFilename() {
		// currently, the token property has the full pathname of the file
		return getToken();
	}

	/**
	 * Gets the file extension from doc type.
	 * 
	 * @return the file extension from doc type
	 */
	public String getFileExtensionFromDocType() {
		if (documentType == null) {
			return ".some";
		}
		else {
			if (documentType.charAt(0) == '.') {
				return documentType;
			}
			else {
				return "." + documentType;
			}
		}
	}

	/**
	 * Gets the token.
	 * 
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Gets the token file.
	 * 
	 * @return the token file
	 */
	public File getTokenFile() {
		return new File(getToken());
	}

	/**
	 * Sets the document type.
	 * 
	 * @param documentType the documentType to set
	 */
	public void setDocType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * Sets the token.
	 * 
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DocumentToken [" + "documentType=" + documentType + " token="
				+ token + "]";
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("documentType", documentType, anIndent, aBuilder);
		outputKeyValue("token", token, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 	
 *  $Log: DocumentToken.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2010/12/07 22:07:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 02:52:09  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.4  2010/03/22 23:18:10  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.2  2010/01/11 21:41:20  mwhxa2
 *  Updated constructor
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/15 17:31:05  mwrka1
 *  Commented unused private variables
 *
 *  Revision 1.7  2009/08/27 00:48:11  mwpxp2
 *  Added getDocumentFilename/0
 *
 *  Revision 1.6  2009/08/26 23:11:53  mwpxp2
 *  Added getFileExtensionFromDocType/0
 *
 *  Revision 1.5  2009/08/26 22:32:10  mwpxp2
 *  Removed hardcoded adding of file extension in getFileToken/0
 *
 *  Revision 1.4  2009/08/22 21:21:42  mwjxa11
 *  Updated the getTokenfile() to return the file instance with File Name and File Type aswell.
 *
 *  Revision 1.3  2009/08/21 01:06:16  mwpxp2
 *  Added getTokenFile/0
 *
 *  Revision 1.2  2009/08/20 22:45:45  mwpxp2
 *  Added toString
 *
 *  Revision 1.1  2009/08/10 18:11:15  mwjxa11
 *  Created a new domain object java class to represent the token in Document Generation.
 *
 *  
 */
