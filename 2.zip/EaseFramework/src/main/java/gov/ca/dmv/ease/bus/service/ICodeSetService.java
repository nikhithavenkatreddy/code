/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.service;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am an interface for CodeSetService.
 * File: ICodeSetService.java
 * Module:  gov.ca.dmv.ease.bus.service
 * Created: Aug 4, 2009
 * @author MWBXP5
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:50 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface ICodeSetService {
	/**
	 * Retrieve all code sets.
	 * 
	 * @param userContext the user context
	 * 
	 * @return the list< i code set>
	 */
	List <ICodeSet> getAllCodeSets(IUserContext userContext);

	/**
	 * Gets the code set named.
	 * 
	 * @param aName the a name
	 * @param userContext the user context
	 * 
	 * @return the code set named
	 */
	ICodeSet getCodeSetNamed(String aName, IUserContext userContext);
	
	/**
	 * Reloads the code sets from the database
	 */
	void reloadCodeSetRegistry();
}
/**
 *  Modification History:
 *
 *  $Log: ICodeSetService.java,v $
 *  Revision 1.2  2013/06/26 21:59:50  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/01/03 17:36:58  mwsec2
 *  Adding support for reloading CodeSet registry via a JMX call
 *
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/03 21:19:29  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/10/01 18:42:36  mwsxd10
 *  Class level JAVA DOC provided.
 *
 *  Revision 1.4  2009/08/27 06:01:39  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2009/08/27 04:25:45  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/06 17:50:38  mwpxp2
 *  Simplified to use List return type for get all code sets, and a single code set retrieval using string name
 *
 *  Revision 1.1  2009/08/05 00:05:44  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 */
