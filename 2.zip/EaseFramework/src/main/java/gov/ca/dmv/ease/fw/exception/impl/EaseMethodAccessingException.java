/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am to be used when accessing a method of an class fails
 * File: EaseMethodAccessingException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010
 * 
 * @author MWTJC1
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseMethodAccessingException extends EaseOperationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3803906998252299565L;

	/**
	 * Instantiates a new ease property accessing exception.
	 */
	public EaseMethodAccessingException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseMethodAccessingException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseMethodAccessingException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseMethodAccessingException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseMethodAccessingException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/01 20:22:34  mwtjc1
 *  I am to be used when accessing a method of an class fails
 *
 */
