/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request;

import gov.ca.dmv.ease.fw.service.IRequest;
import gov.ca.dmv.ease.fw.validate.IValidatable;
import gov.ca.dmv.ease.tus.print.response.IPrintServiceResponse;

/**
 * Description: This is the Print Service Request Interface
 * File: IPrintServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request
 * Created: May 3, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPrintServiceRequest extends IValidatable, IRequest {
	/**
	 * Abstract method which all the Print Service request classes should override
	 * for executing the corresponding method in Print Service.
	 * 
	 * @return the persistence service response
	 */
	IPrintServiceResponse execute();
}
/**
 *  Modification History:
 * 
 *  $Log: IPrintServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/08/25 17:53:33  mwpxp2
 *  Fixed to use IPrintServiceResponse rather than implementation
 *
 *  Revision 1.2  2010/05/11 01:00:05  mwhxa2
 *  updated Print Service Request
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
*/
