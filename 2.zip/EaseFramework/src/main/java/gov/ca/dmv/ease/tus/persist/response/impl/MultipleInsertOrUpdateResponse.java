/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response for MultipleInsertOrUpdateBusinessObject response
 *  //TODO - remove unused constructors, starting with the default
 * 
 * File: MultipleInsertOrUpdateResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Sep 9, 2009
 * 
 * @author MWKFH
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleInsertOrUpdateResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2894766410563391486L;

	/**
	 * Instantiates a new multi-save business object response.
	 * 
	 */
	public MultipleInsertOrUpdateResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public MultipleInsertOrUpdateResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new multi-save business object response.
	 * 
	 * @param ex the ex
	 */
	public MultipleInsertOrUpdateResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * @param collector
	 */
	public MultipleInsertOrUpdateResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public MultipleInsertOrUpdateResponse(IErrorCollector collector,
			int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public MultipleInsertOrUpdateResponse(int anItemCount) {
		super(anItemCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleInsertOrUpdateResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/13 00:58:05  mwpxp2
 *  Added constructors from super; added todo
 *
 *  Revision 1.1  2010/09/09 22:04:02  mwkfh
 *  new response objects
 *
 */
