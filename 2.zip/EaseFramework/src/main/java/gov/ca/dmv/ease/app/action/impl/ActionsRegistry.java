/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.app.action.impl;

import gov.ca.dmv.ease.app.action.IActionsRegistry;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am a registry containing all the available actions in EASE FW.
 * File: ActionsRegistry.java
 * Module:  gov.ca.dmv.ease.app.action.impl
 * Created: Mar 20, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ActionsRegistry implements IActionsRegistry {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6883854593895268054L;
	/** The actions. */
	private List <Action> actions;

	public void addAction(Action anAction) {
		getActions().add(anAction);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ActionsRegistry other = (ActionsRegistry) obj;
		if (actions == null) {
			if (other.getActions() != null) {
				return false;
			}
		}
		else if (!actions.equals(other.getActions())) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the action.
	 * 
	 * @param actionKey the action key
	 * 
	 * @return the action
	 */
	public Action getAction(String actionKey) {
		for (Action action : getActions()) {
			if (action.getKey().equalsIgnoreCase((actionKey))) {
				return action;
			}
		}
		return null;
	}

	/**
	 * Gets the actions.
	 * 
	 * @return the actions
	 */
	public List <Action> getActions() {
		if (actions == null) {
			setActions(new ArrayList <Action>());
		}
		return actions;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actions == null) ? 0 : actions.hashCode());
		return result;
	}

	/**
	 * Sets the actions.
	 * 
	 * @param actions the actions to set
	 */
	public void setActions(List <Action> aList) {
		actions = aList;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ActionsRegistry.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/01/15 02:00:18  mwpxp2
 *  Cleanup
 *
 *  Revision 1.7  2010/09/17 20:46:36  mwpxp2
 *  Removed implementation of Serializable- already covered by the interface
 *
 *  Revision 1.6  2010/09/01 18:55:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/08/31 17:54:58  mwhys
 *  Overrided equals and hashCode methods.
 *
 *  Revision 1.4  2010/05/04 00:17:17  mwvkm
 *  Serializable is added in the implements section.
 *
 *  Revision 1.3  2010/04/29 17:55:01  mwcsj3
 *  Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 *  Revision 1.2.6.1  2010/04/15 22:14:12  mwakg
 *  Removed super class
 *
 *  Revision 1.2  2010/03/22 23:15:42  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2010/03/21 00:03:34  mwakg
 *  Class holding actions defined in spring configuration.
 *
 *
*/
