/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request;


/**
 * Description: Interface for an object knowing how to validate a given request instance.
 * Concrete implementations are request-type specific.
 * File: IRequestValidator.java
 * Module:  gov.ca.dmv.ease.service.request
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRequestValidator {
}
/**
 *  Modification History:
 *
 *  $Log: IRequestValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/09/13 04:39:50  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/10/13 20:26:28  mwhxb3
 *  updated comments.
 *
 *  Revision 1.8  2009/10/03 21:23:43  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.7  2009/08/27 05:54:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/08/27 02:34:03  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.5  2009/08/18 03:12:32  mwpxp2
 *  Removed validate/1 - super takes over
 *
 *  Revision 1.4  2009/08/17 23:41:20  mwpxp2
 *  Extended IValidator
 *
 *  Revision 1.3  2009/07/14 23:58:52  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:19  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.4  2009-05-18 16:24:50  ppalacz
 *  Javadoc update
 *
 *  Revision 1.3  2009-05-12 06:28:24  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
