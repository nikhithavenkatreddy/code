package gov.ca.dmv.ease.fw.process;

import gov.ca.dmv.ease.app.activity.impl.SubprocessActivity;
import gov.ca.dmv.ease.app.context.impl.ExecutionSyncPoint;

import java.util.Stack;

/**
 * Description: I am minimal interface for Session Context
 * I allow for accessing of the current process context plus what I inherit
 * File: ISessionContext.java
 * Module:  gov.ca.dmv.ease.fw.process
 * Created: Aug 19, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:37:27 $
 * Last Changed By: $Author: mwhys $
 */
public interface ISessionContext extends IProcessContext {
	/**
	 * Gets the current process context.
	 * 
	 * @return the current process context
	 */
	IProcessContext getCurrentProcessContext();

	/**
	 * Gets the stack of execution sync points.
	 * 
	 * @return the stack of execution sync points.
	 */
	Stack <ExecutionSyncPoint> getExecutionSyncPoints();

	/**
	 * Gets the rollback process context.
	 *
	 * @return the rollback process context
	 */
	IProcessContext getRollbackProcessContext();

	/**
	 * Gets the rollback subprocess activity.
	 *
	 * @return the rollback subprocess activity
	 */
	SubprocessActivity getRollbackSubprocessActivity();
	
	/**
	 * Gets the session sys id.
	 *
	 * @return the session sys id
	 */
	Long getSessionSysId();
}
/**
 *  Modification History:
 *
 *  $Log: ISessionContext.java,v $
 *  Revision 1.2  2012/12/13 00:37:27  mwhys
 *  Added getSessionSysId
 *
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/09/19 16:46:50  mwkfh
 *  removed unneeded "public" keyword
 *
 *  Revision 1.6  2012/09/12 00:27:44  mwhys
 *  Added getRollbackSubprocessActivity(). (Defect 7189)
 *
 *  Revision 1.5  2012/06/01 21:39:53  mwhys
 *  Added getRollbackProcessContext(). (Session Management)
 *
 *  Revision 1.4  2012/03/23 21:32:48  mwxxw
 *  Remove destroy() interface.
 *
 *  Revision 1.3  2011/05/26 18:00:31  mwsec2
 *  added destroy method to the interface
 *
 *  Revision 1.2  2010/09/24 00:24:45  mwhys
 *  Added getExecutionSyncPoints method.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/23 17:13:59  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.1  2009/10/03 20:23:26  mwpxp2
 *  Moved into fw.process; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/19 21:40:41  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.1  2009/08/19 21:40:12  mwpxp2
 *  Initial - placeholder for future work
 *
 */
