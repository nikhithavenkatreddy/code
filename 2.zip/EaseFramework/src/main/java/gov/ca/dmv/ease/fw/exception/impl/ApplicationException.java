/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: All the application specific exceptions extends this class.
 *  //TODO - rename
 *  
 * File: ApplicationException.java 
 * Module: gov.ca.dmv.ease.ex 
 * Created: May 20,  2009
 * 
 * @author MWAKG
 * @version $Revision: 1.1 $ 
 * Last Changed: May 20, 2009 9:26:48 AM 
 * Last Changed  By: MWAKG
 */
public class ApplicationException extends EaseBusinessLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 709886137354769541L;

	/**
	 * Instantiates a new application exception.
	 */
	public ApplicationException() {
		super();
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param message the message
	 */
	public ApplicationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param cause the cause
	 */
	public ApplicationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ApplicationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/03/23 20:32:24  mwpxp2
 *  Comment/inheritance mods
 *
 *  Revision 1.2  2010/03/22 23:31:05  mwpxp2
 *  Inherits from EaseException not ItmException
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/08/27 20:51:42  mwsmg6
 *  corrected exception type
 *
 *  Revision 1.3  2009/07/27 17:11:02  mwpxm2
 *  Exception refactoring
 *
 *  Revision 1.1  2009/07/14 23:44:29  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-11 07:32:58  ppalacz
 *  Moved to .impl package; cleaned up comments and javadoc
 *
 */
