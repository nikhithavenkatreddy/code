/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.service.impl;

import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.exception.impl.EasePersistenceServiceException;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.service.impl.PersistenceService;
import gov.ca.dmv.ease.tus.session.persist.request.impl.DeleteSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.impl.UpdateSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.response.impl.DeleteSessionPersistenceResponse;
import gov.ca.dmv.ease.tus.session.persist.response.impl.UpdateSessionPersistenceResponse;
import gov.ca.dmv.ease.tus.session.persist.service.ISessionPersistenceService;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Query;

/**
 * Description: I provide methods that used to save, retrieve, update and delete
 * session objects to/from the persistence store.
 * File: SessionPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service.impl
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:12:54 $
 * Last Changed By: $Author: mwhys $
 */
public class SessionPersistenceService extends PersistenceService implements
		ISessionPersistenceService {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(SessionPersistenceService.class);

	/**
	 * Gets the single instance of SessionPersistenceService.
	 *
	 * @return single instance of SessionPersistenceService
	 */
	public static SessionPersistenceService getInstance() {
		return new SessionPersistenceService();
	}

	/**
	 * Instantiates a new session persistence service.
	 */
	protected SessionPersistenceService() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.session.persist.service.ISessionPersistenceService#execute(gov.ca.dmv.ease.tus.session.persist.request.impl.DeleteSessionPersistenceRequest)
	 */
	public DeleteSessionPersistenceResponse execute(
			DeleteSessionPersistenceRequest request) {
		try {
			Session sessionCriteria = request.getSession();
			if (sessionCriteria.hasId()) {
				super.executeDeleteBusinessObject(sessionCriteria);
				return new DeleteSessionPersistenceResponse(1);
			}
			else if (sessionCriteria.hasKeyFields()) {
				int recsUpdated = executeDeleteSession(sessionCriteria);
				return new DeleteSessionPersistenceResponse(recsUpdated);
			}
			else if (sessionCriteria.hasSessionId()) {
				int recsUpdated = executeDeleteSession(sessionCriteria
						.getSessionId());
				return new DeleteSessionPersistenceResponse(recsUpdated);
			}
			else {
				return new DeleteSessionPersistenceResponse(
						new EaseValidationException("UNKNOWN SESSION TO DELETE"));
			}
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new DeleteSessionPersistenceResponse(
					new EasePersistenceServiceException(ex));
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.session.persist.service.ISessionPersistenceService#execute(gov.ca.dmv.ease.tus.session.persist.request.impl.UpdateSessionPersistenceRequest)
	 */
	public UpdateSessionPersistenceResponse execute(
			UpdateSessionPersistenceRequest request) {
		try {
			Session sessionCriteria = request.getSession();
			if (sessionCriteria.hasId()) {
				int recsUpdated = executeUpdateSession(sessionCriteria);
				return new UpdateSessionPersistenceResponse(recsUpdated);
			}
			else {
				return new UpdateSessionPersistenceResponse(
						new EaseValidationException("UNKNOWN SESSION TO UPDATE"));
			}
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			return new UpdateSessionPersistenceResponse(
					new EasePersistenceServiceException(ex));
		}
	}

	/**
	 * Deletes the passed in session object.
	 *
	 * @param sessionObject the session object
	 * @return the int
	 */
	private int executeDeleteSession(Session sessionObject) {
		int recordsUpdated = 0;
		if (!EaseUtil.isNullOrBlank(sessionObject.getOfficeId())
				&& !EaseUtil.isNullOrBlank(sessionObject.getTechId())
				&& !EaseUtil.isNullOrBlank(sessionObject.getUserName())) {
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				String queryString = "DELETE FROM "
						+ sessionObject.getClass().getName();
				queryString += " WHERE officeId = :office_id";
				queryString += " AND techId = :tech_id";
				queryString += " AND userName = :user_name";
				Query query = getSessionFactory().getCurrentSession()
						.createQuery(queryString.toString());
				query.setString("office_id", sessionObject.getOfficeId());
				query.setString("tech_id", sessionObject.getTechId());
				query.setString("user_name", sessionObject.getUserName());
				recordsUpdated = query.executeUpdate();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
			}
			catch (HibernateException e) {
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new EasePersistenceServiceException(e);
			}
		}
		else {
			throw new EaseValidationException("CANNOT DELETE SESSION");
		}
		return recordsUpdated;
	}

	/**
	 * Deletes the passed in session object.
	 *
	 * @param sessionId the session id
	 * @return the int
	 */
	private int executeDeleteSession(String sessionId) {
		int recordsUpdated = 0;
		if (!EaseUtil.isNullOrBlank(sessionId)) {
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				String queryString = "DELETE FROM " + Session.class.getName();
				queryString += " WHERE sessionId = :session_id";
				Query query = getSessionFactory().getCurrentSession()
						.createQuery(queryString.toString());
				query.setString("session_id", sessionId);
				recordsUpdated = query.executeUpdate();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
			}
			catch (HibernateException e) {
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new EasePersistenceServiceException(e);
			}
		}
		else {
			throw new EaseValidationException(
					"CANNOT DELETE SESSION USING SESSION ID = '" + sessionId
							+ "'");
		}
		return recordsUpdated;
	}

	/**
	 * Execute update session.
	 *
	 * @param sessionObject the session object
	 * @return the int
	 */
	private int executeUpdateSession(Session sessionObject) {
		Long sysId = sessionObject.getId();
		int recordsUpdated = 0;
		if (!EaseUtil.isNullOrBlank(sysId)) {
			getSessionFactory().getCurrentSession().beginTransaction();
			try {
				String queryString = "UPDATE " + Session.class.getName();
				queryString += " SET sessionData = :sessionData ";
				queryString += ", modifiedDate = :modifiedDate ";
				queryString += " WHERE id = :sys_id";
				Query query = getSessionFactory().getCurrentSession()
						.createQuery(queryString.toString());
				query.setParameter("sessionData", sessionObject
						.getSessionData());
				query.setTimestamp("modifiedDate", new Date());
				query.setLong("sys_id", sysId);
				recordsUpdated = query.executeUpdate();
				getSessionFactory().getCurrentSession().getTransaction()
						.commit();
			}
			catch (HibernateException e) {
				getSessionFactory().getCurrentSession().getTransaction()
						.rollback();
				throw new EasePersistenceServiceException(e);
			}
		}
		else {
			throw new EaseValidationException(
					"CANNOT UPDATE SESSION USING SYSID = '" + sysId + "'");
		}
		return recordsUpdated;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionPersistenceService.java,v $
 *  Revision 1.2  2012/12/13 00:12:54  mwhys
 *  Added execute(UpdateSessionPersistenceRequest)
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/05/08 00:23:37  mwhys
 *  Updated to handle sessions without a session ID (Session Management).
 *
 *  Revision 1.2  2012/01/10 23:42:31  mwkfh
 *  updated execute Delete to use hasId
 *
 *  Revision 1.1  2012/01/06 19:34:49  mwkfh
 *  Initial
 *
 */
