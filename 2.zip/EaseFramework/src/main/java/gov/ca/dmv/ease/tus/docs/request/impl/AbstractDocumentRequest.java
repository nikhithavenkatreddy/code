/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.docs.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: I am abstract superclass for document service requests
 * File: AbstractDocumentRequest.java
 * Module:  gov.ca.dmv.ease.tus.docs.request.impl
 * Created: Aug 26, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AbstractDocumentRequest extends AbstractRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8759096930181374734L;
	
	/**
	 * Instantiates a new abstract document request.
	 * 
	 * @param context the context
	 */
	public AbstractDocumentRequest(IUserContext context) {
		super(context);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector collector) {
		super.validateUsing(collector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				collector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractDocumentRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/10/25 23:47:35  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/08 23:56:58  mwjxa11
 *  Added the class header and removed the unused default constructor
 *
 *  Revision 1.3  2009/10/03 21:32:46  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.2  2009/08/27 06:29:24  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 04:40:27  mwpxp2
 *  Moved in from documetn service project and package-restructured
 *
 */
