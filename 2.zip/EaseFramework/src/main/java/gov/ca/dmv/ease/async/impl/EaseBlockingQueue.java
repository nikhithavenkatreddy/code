/**
 * 
 */
package gov.ca.dmv.ease.async.impl;

import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Description: A thread-safe blocking queue, intended for queuing log messages but
 * can be used for other cases where multiple threads need to produce and consume messages.
 *  
 * File: EaseBlockingQueue.java
 * Module:  gov.ca.dmv.ease.async.impl
 * Created: Jan 9, 2013 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 * @param <E>
 */
public class EaseBlockingQueue<E> extends LinkedBlockingQueue <E> {

	/* for serialization */
	private static final long serialVersionUID = -4620060839996011910L;

	/* The logger for this class  */
	private static final Log LOGGER = LogFactory
			.getLog(EaseBlockingQueue.class);
	
	/**
	 * @param capacity
	 */
	public EaseBlockingQueue() {
		super(); 
		LOGGER.info("EaseBlockingQueue intialized with no capacity specified");
	}
	
	/**
	 * @param capacity
	 */
	public EaseBlockingQueue(int capacity) {
		super(capacity); 
		LOGGER.info("EaseBlockingQueue intialized with capacity of " + capacity);
	}
	
	public void shutdown() {
		LOGGER.info("Queue shutting down with " + size() + " unprocessed messages.");
	}
	
}


/**
 *  Modification History:
 *
 *  $Log: EaseBlockingQueue.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.2  2013/01/17 17:26:50  mwsec2
 *  refinements
 *
 *  Revision 1.1.2.1  2013/01/15 19:45:19  mwsec2
 *  committing async logging classes and associated config file changes
 *
 */