/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.context.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.SubprocessActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessLoader;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Iterator;
import java.util.Stack;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I implement ISessionContext and hold session related information.
 * and current process context.
 * File: SessionContext.java
 * Module:  gov.ca.dmv.ease.app.context.impl
 * Created: Nov 23, 2009 
 * @author MWRSK  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2013/09/12 21:13:52 $
 * Last Changed By: $Author: mwsec2 $
 */
public class SessionContext extends ProcessContext implements ISessionContext {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(SessionContext.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5738054884029161819L;
	/** The current process context. */
	private transient ProcessContext currentProcessContext = this;
	/** The stack of execution sync points. */
	private transient Stack <ExecutionSyncPoint> executionSyncPoints;
	/** The user context. */
	private transient IUserContext userContext;
	/** The rollback process context. */
	private transient IProcessContext rollbackProcessContext;
	/** The rollback subprocess activity. */
	private transient SubprocessActivity rollbackSubprocessActivity;
	/** The session sys id. */
	private Long sessionSysId;

	/* Serializable properties must be manually added to the writeObject and readObject methods! */
	/**
	 * Instantiates a new session context.
	 */
	public SessionContext() {
		executionSyncPoints = new Stack <ExecutionSyncPoint>();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.ProcessContext#end()
	 */
	@Override
	public void end() {
		//TODO Implementation will provided based on the requirements.
	}

	/**
	 * Gets the current process context.
	 * 
	 * @return the current process context
	 */
	public ProcessContext getCurrentProcessContext() {
		return currentProcessContext;
	}

	/**
	 * Gets the stack of execution sync points.
	 *
	 * @return the execution sync points
	 */
	public Stack <ExecutionSyncPoint> getExecutionSyncPoints() {
		return executionSyncPoints;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.ProcessContext#getRootContext()
	 */
	@Override
	public SessionContext getRootContext() {
		return this;
	}

	/**
	 * This method returns the user context.
	 * 
	 * @return the user context
	 */
	@Override
	public IUserContext getUserContext() {
		return userContext;
	}

	/**
	 * My init.
	 */
	public void myInit() {
		BusinessProcess topBusinessProcess = getProcessRegistry().getProcess(
				IProcessRegistry.TOP_BUSINESS_PROCESS);
		LOGGER.info("Business Process :: " + topBusinessProcess.getId());
		setProcessId(topBusinessProcess.getId());
		setCurrentActivity(topBusinessProcess.getStartingActivity());
		getCurrentActivity().execute(this);
	}

	/**
	 * Used during session management to Restore the activities within
	 * the execution sync points.
	 *
	 * @param execSyncPoints the exec sync points
	 */
	public void restore(Stack <ExecutionSyncPoint> execSyncPoints) {
		setExecutionSyncPoints(execSyncPoints);
		if (isNotNull(getExecutionSyncPoints())) {
			ProcessLoader processLoader = EaseApplicationContext
					.getProcessLoader();
			Iterator <ExecutionSyncPoint> syncPointIterator = getExecutionSyncPoints()
					.iterator();
			//Iterate the stack
			while (syncPointIterator.hasNext()) {
				ExecutionSyncPoint executionSyncPoint = (ExecutionSyncPoint) syncPointIterator
						.next();
				String executionSyncPointActivityName = null;
				if (isNotNull(executionSyncPoint
						.getExecutionSyncPointActivity())) {
					executionSyncPointActivityName = executionSyncPoint
							.getExecutionSyncPointActivity().getActivityName();
				}
				String businessProcessId = executionSyncPoint
						.getExecutionSyncPointContext().getProcessId();
				//Get the reference to the original ExecutionSyncPointActivity from the Process Loader
				Activity originalSyncPointActivity = processLoader
						.getActivityReference(businessProcessId,
								executionSyncPointActivityName);
				executionSyncPoint
						.setExecutionSyncPoint(originalSyncPointActivity);
				//Restore the process context
				if (isNotNull(executionSyncPoint.getExecutionSyncPointContext())) {
					executionSyncPoint.getExecutionSyncPointContext().restore();
				}
			}
		}
	}

	//	/**
	//	 * Set the properties from serialization
	//	 * 
	//	 * @param ObjectInputStream input stream
	//	 */
	//	@SuppressWarnings("unchecked")
	//	private void readObject(ObjectInputStream in) throws IOException,
	//			ClassNotFoundException {
	//		currentProcessContext = (ProcessContext) in.readObject();
	//		userContext = (IUserContext) in.readObject();
	//		executionSyncPoints = (Stack <ExecutionSyncPoint>) in.readObject();
	//		in.defaultReadObject();
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.impl.ProcessContext#resume(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	public void resume(ProcessContext aProcessContext) {
		// The inherited resume method tries to resume an interaction activity. Since the top/session-level process
		// does not contain interaction activities, we override the method with a do-nothing version
		LOGGER.warn("Attempting to resume top-level process");
	}

	/**
	 * Sets the current process context.
	 *
	 * @param aCtx the new current process context
	 */
	public void setCurrentProcessContext(ProcessContext aCtx) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(this);
		}
		currentProcessContext = aCtx;
		//((ChildContext) currentProcessContext).setRootContext(this);
	}

	/**
	 * Sets the stack of execution sync points.
	 *
	 * @param executionSyncPoints the new execution sync points
	 */
	public void setExecutionSyncPoints(
			Stack <ExecutionSyncPoint> executionSyncPoints) {
		this.executionSyncPoints = executionSyncPoints;
	}

	/**
	 * Set the user context to the process context.
	 * 
	 * @param anUuserContext the an uuser context
	 */
	public void setUserContext(IUserContext anUuserContext) {
		if (anUuserContext != null) {
			LOGGER.debug(anUuserContext.toString());
		}
		userContext = anUuserContext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.context.ProcessContext#toString()
	 */
	@Override
	public String toString() {
		return " userContext=" + userContext;
	}

	//	/**
	//	 * Serialize specific properties
	//	 * 
	//	 * @param ObjectOutputStream output stream
	//	 */
	//	private void writeObject(ObjectOutputStream out) throws IOException {
	//		out.writeObject(EaseProxyUtils.getProxyObject(currentProcessContext));
	//		out.writeObject(EaseProxyUtils.getProxyObject(userContext));
	//		out.writeObject(EaseProxyUtils.getProxyObject(executionSyncPoints));
	//		out.defaultWriteObject();
	//	}
	/**
	 * Sets the rollback process context.
	 *
	 * @param rollbackProcessContext the rollbackProcessContext to set
	 */
	public void setRollbackProcessContext(IProcessContext rollbackProcessContext) {
		this.rollbackProcessContext = rollbackProcessContext;
	}

	/**
	 * Sets the rollback subprocess activity.
	 *
	 * @param rollbackSubprocessActivity the rollbackSubprocessActivity to set
	 */
	public void setRollbackSubprocessActivity(
			SubprocessActivity rollbackSubprocessActivity) {
		this.rollbackSubprocessActivity = rollbackSubprocessActivity;
	}

	/**
	 * Sets the session sys id.
	 *
	 * @param sessionSysId the new session sys id
	 */
	public void setSessionSysId(Long sessionSysId) {
		this.sessionSysId = sessionSysId;
	}

	/**
	 * Gets the rollback process context.
	 *
	 * @return the rollbackProcessContext
	 */
	public IProcessContext getRollbackProcessContext() {
		return rollbackProcessContext;
	}

	/**
	 * Gets the rollback subprocess activity.
	 *
	 * @return the rollbackSubprocessActivity
	 */
	public SubprocessActivity getRollbackSubprocessActivity() {
		return rollbackSubprocessActivity;
	}

	/**
	 * Gets the session sys id.
	 *
	 * @return the session sys id
	 */
	public Long getSessionSysId() {
		return sessionSysId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionContext.java,v $
 *  Revision 1.4  2013/09/12 21:13:52  mwsec2
 *  put expensive log statements inside isDebugEnabled block
 *
 *  Revision 1.3  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.4  2013/04/30 16:44:38  mwsec2
 *  adjusted logging levels
 *
 *  Revision 1.1.4.3  2013/02/28 19:57:01  mwsec2
 *  rebase from HEAD
 *
 *  Revision 1.2  2012/12/13 00:38:00  mwhys
 *  Added property sessionSysId
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.29  2012/09/12 00:29:24  mwhys
 *  Added a transient field rollbackSubprocessActivity. (Defect 7189)
 *
 *  Revision 1.28  2012/08/25 18:18:58  mwpxp2
 *  Fixed suppression of warnings frfom unchecked to rawtypes were applicable
 *
 *  Revision 1.27  2012/06/01 21:38:31  mwhys
 *  Added property rollbackProcessContext. (Session Management)
 *
 *  Revision 1.26  2012/03/23 21:25:59  mwxxw
 *  Change function name from init() to myInit() to avoid key word.
 *
 *  Revision 1.25  2011/10/12 20:54:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.24.8.1  2011/09/28 02:46:54  mwpxp2
 *  Added de-springification todos
 *
 *  Revision 1.24  2011/06/10 21:00:44  mwyxg1
 *  clean up
 *
 *  Revision 1.23  2011/01/20 19:47:52  mwpxp2
 *  Imports and javadoc cleanup
 *
 *  Revision 1.22  2011/01/07 19:28:13  mwnrk
 *  Fixed null exception.
 *
 *  Revision 1.21  2010/12/02 00:14:56  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.20  2010/10/01 20:54:03  mwhys
 *  Added an argument to the restore method.
 *
 *  Revision 1.19  2010/09/24 00:23:14  mwhys
 *  Added restore method for session management.
 *
 *  Revision 1.18  2010/09/13 20:43:17  mwkfh
 *  updated read & writeObject
 *
 *  Revision 1.17  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.16  2010/09/08 18:38:17  mwkfh
 *  updated writeObject and added readObject
 *
 *  Revision 1.15  2010/09/03 16:50:02  mwsec2
 *  moved initialization of sync point stack from init method to constructor, for better unit testability
 *
 *  Revision 1.14  2010/09/01 18:56:22  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2010/08/31 22:31:48  mwhys
 *  Made SessionContext Serializable.
 *
 *  Revision 1.12  2010/08/23 20:41:54  mwsec2
 *  a do-nothing implementation of resume() added
 *
 *  Revision 1.11  2010/08/10 17:23:11  mwpxp2
 *  Removed unproductive this.~es
 *
 *  Revision 1.10  2010/08/03 21:27:58  mwsec2
 *  syncPoint enhancements
 *
 *  Revision 1.9  2010/06/21 23:00:41  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.8.6.2  2010/06/13 20:52:53  mwakg
 *  Updated copyProcessContext method and moved it from ProcessContext
 *
 *  Revision 1.8.6.1  2010/06/08 01:32:50  mwakg
 *  Provided hook method for ProcessContext to copy another ProcessContext. This hook method will be used for switching PCs
 *
 *  Revision 1.8  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.7  2010/05/05 02:16:00  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.6  2010/04/22 19:09:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/04/10 23:20:11  mwcsj3
 *  Updated logging
 *
 *  Revision 1.4  2010/04/08 23:46:27  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.3  2010/04/08 18:24:23  mwcsj3
 *  Cleaned up, removed all unused and redundant methods
 *
 *  Revision 1.2  2010/04/01 00:11:44  mwakg
 *  Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/09 17:21:23  mwakg
 *  Removed creation of UserContext from SessionContext. Its created in the filter.
 *  CodeSetService loads all the codeset data in EaseContextListener instead of in every process
 *
 *  Revision 1.3  2009/10/29 01:07:35  mwakg
 *  Added UserContext default values
 *
 *  Revision 1.2  2009/10/13 03:05:58  mwrrv2
 *  Cleaned to do.
 *
 *  Revision 1.1  2009/10/03 20:55:32  mwpxp2
 *  Moved to .impl
 *
 *  Revision 1.18  2009/09/30 21:53:47  mwsmg6
 *  undo of MockCodesetService removal
 *
 *  Revision 1.16  2009/09/13 20:39:19  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.15.2.2  2009/09/13 01:34:31  mwakg
 *  Reading data from Database instead of XML for CodeSetService
 *
 *  Revision 1.15.2.1  2009/09/12 19:09:23  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.15  2009/08/27 08:25:01  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 *  Revision 1.14  2009/08/25 18:24:21  mwsmg6
 *  removed getSessionContext
 *
 *  Revision 1.13  2009/08/21 01:37:50  mwakg
 *  *** empty log message ***
 *
 *  Revision 1.12  2009/08/20 22:23:26  mwakg
 *  Loading Codeset values when Sessioncontext loads
 *
 *  Revision 1.11  2009/08/20 22:03:32  mwpxp2
 *  Added getSessionContext and serialVersionUID, toString
 *
 *  Revision 1.9  2009/08/19 20:34:39  mwakg
 *  Added default RacID and UserName when the SessionContext is created
 *
 *  Revision 1.8  2009/08/11 02:17:46  mwpxp2
 *  Added javadoc and  file decorations
 *
 */
