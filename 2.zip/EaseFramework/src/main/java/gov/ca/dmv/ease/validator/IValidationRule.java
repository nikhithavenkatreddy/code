/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.validator;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.io.Serializable;

/**
 * Description: I am interface for validation rules
 * File: IValidateRules.java
 * Module:  gov.ca.dmv.ease.validator
 * Created: Apr 26, 2010
 * @author MWCSJ3
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IValidationRule extends Serializable {
	/**
	 * validate
	 *
	 * @param processContext
	 */
	public IErrorCollector validate(ProcessContext processContext);

	/**
	 * Validate.
	 *
	 * @param processContext the process context
	 * @param aCollector the a collector
	 */
	public void validate(ProcessContext processContext,
			IErrorCollector aCollector);
}
/**
 *  Modification History:
 *
 *  $Log: IValidationRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2011/01/21 22:34:07  mwpxp2
 *  Removed previously deprecated getErrorCollector/0
 *
 *  Revision 1.9  2010/11/09 03:18:21  mwpxp2
 *  Deprecated getErrorCollector/0 as fundamentally faulty; added validate/2 to allow validation results to be registered in an instance of an error collector passed in.
 *
 */
