/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.response;

import gov.ca.dmv.ease.tus.persist.response.IPersistenceServiceResponse;

/**
 * Description: I am the interface for the SessionPersistenceResponse class.
 * File: ISessionPersistenceResponse.java
 * Module:  gov.ca.dmv.ease.tus.session.persist.response
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionPersistenceResponse extends
		IPersistenceServiceResponse {
}
/**
 *  Modification History:
 *
 *  $Log: ISessionPersistenceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/06 19:34:49  mwkfh
 *  Initial
 *
 */
