/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.PrintingServiceException;

/**
 * Description: I am printer not found exception
 * File: PrinterNotFoundException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Aug 5, 2010 
 * @author MWCSJ3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PrinterNotFoundException extends PrintingServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2106528725031243390L;

	/**
	 * Default constructor.
	 */
	public PrinterNotFoundException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public PrinterNotFoundException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public PrinterNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public PrinterNotFoundException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: PrinterNotFoundException.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/09/01 19:06:59  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/08/27 17:05:03  mwcsj3
 *  Moved PrintingNotFoundException from FW to TUS folder
 *
 *  Revision 1.2  2010/08/27 16:52:30  mwpxp2
 *  Added fixmes; javadoc
 *
 *  Revision 1.1  2010/08/06 00:04:54  mwcsj3
 *  Initial version
 *
 *  
 */
