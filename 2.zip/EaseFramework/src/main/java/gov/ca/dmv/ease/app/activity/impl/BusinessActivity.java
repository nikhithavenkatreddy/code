/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.action.IActionNamesConstants;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am abstract superclass for business activities 
 * 
 * File:BusinessActivity.java 
 * Module: gov.ca.dmv.ease.app.activity 
 * Created: Aug 10,2009
 * 
 * @author MWPXP2
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ 
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class BusinessActivity extends TransientActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(BusinessActivity.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2374446063485569540L;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected final void executeAuthorized(ProcessContext context) {
		invokeService(context);
		postCondition(context);
		if (isRestartOrCancelAction(context)) {
			context.clearExecutionSyncPoints();
		}
		else {
			context.registerSyncPoint(this);
		}
		LOGGER.debug("executeAuthorized() :: " + getActivityName());
		if (!context.hasValidationErrors() && isSavePoint()) {
			createSavePoint(context);
		}
		Activity nextActivity = getNextActivity();
		if (nextActivity != null) {
			LOGGER.debug("Next Activity :: " + nextActivity.getActivityName());
			nextActivity.execute(context);
		}
		else {
			signalInvalidNextActivityFor(context); //throws ProcessExecutionException 
		}
	}
	
	/**
	 * Invoke service.
	 * 
	 * @param context the context
	 */
	protected abstract void invokeService(ProcessContext context);
	
	/**
	 * Checks whether the user action is either 'cancel' or 'restart'.
	 *
	 * @param context the context
	 * @return true, if is restart or cancel action
	 */
	private boolean isRestartOrCancelAction(ProcessContext context) {
		return context.getSelectedAction() != null
				&& context.getSelectedAction().getKey() != null
				&& (context.getSelectedAction().getKey().equalsIgnoreCase(
						IActionNamesConstants.CANCEL_ACTION) || context
						.getSelectedAction().getKey().equalsIgnoreCase(
								IActionNamesConstants.RESTART_ACTION));
	}
}
/**
 * Modification History:
 * 
 * $Log: BusinessActivity.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/04/30 16:49:13  mwsec2
 * adjusted logging levels
 *
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.23  2012/09/11 00:04:45  mwhys
 * Added a check for valiadtion errors before creating the save point.
 *
 * Revision 1.22  2012/05/08 00:11:43  mwhys
 * Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 * Revision 1.21.4.1  2012/02/21 21:15:01  mwsec2
 * save point support added
 *
 * Revision 1.21  2011/10/21 20:48:49  mwpxp2
 * Modified to use signalInvalidNextActivityFor for handling of invalid next activity
 *
 * Revision 1.20  2011/10/21 20:38:37  mwpxp2
 * Modified throwing of ProcessExecutionException to include information about activity, process, current interaction activity
 *
 * Revision 1.19  2010/12/16 17:44:20  mwsec2
 * exception type changed to be more specific
 *
 * Revision 1.18  2010/11/09 03:19:29  mwpxp2
 * Imports cleanup
 *
 * Revision 1.17  2010/08/27 16:06:42  mwyxg1
 * remove actionable activity
 *
 * Revision 1.16  2010/08/20 18:13:33  mwpxp2
 * Added fixme; source cleanup
 *
 * Revision 1.15  2010/08/03 21:16:30  mwsec2
 * syncPoint enhancements
 *
 * Revision 1.14  2010/07/30 22:44:56  mwakg
 * Activities now register syncpoint activity and the processContext
 *
 * Revision 1.13  2010/07/30 20:15:53  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.12  2010/05/09 18:02:07  mwakg
 * Moved postCondition to sub classes
 *
 * Revision 1.11  2010/04/22 22:27:25  mwcsj3
 * Fixed FIX ME
 *
 * Revision 1.10  2010/04/22 19:08:54  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.9  2010/04/22 18:27:12  mwpxp2
 * Added fixme in executeAuthorized
 *
 * Revision 1.8  2010/04/14 15:38:59  mwakg
 * Made activities authorizedExecute protected
 *
 * Revision 1.7  2010/04/13 23:24:19  mwpxp2
 * Added fixmes
 *
 * Revision 1.6  2010/04/08 23:46:27  mwcsj3
 * Added logging for easy debugging
 *
 * Revision 1.5  2010/04/07 22:19:16  mwcsj3
 * Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 * Revision 1.4  2010/03/27 01:06:51  mwsxd10
 * Not calling execute() method if the next activity is InteractionAactivity.
 *
 * Revision 1.3  2010/03/22 22:58:11  mwpxp2
 * Javadoc/cleanup
 *
 * Revision 1.2  2010/03/11 22:20:04  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.3  2010/02/26 19:09:12  mwyxg1
 * process multi process transition, update documentation
 *
 * Revision 1.1.2.2  2010/02/26 19:07:57  mwyxg1
 * process multi process transition, update documentation
 *
 * Revision 1.1.2.1  2010/02/26 17:34:00  mwyxg1
 * process multi process transition
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.4  2009/10/07 19:16:21  mwbxp5
 * Removed LOGGER
 *
 * Revision 1.3  2009/10/06 19:32:34  mwrrv2
 * fixed formatting issues.
 *
 * Revision 1.2  2009/10/06 18:31:54  mwrrv2
 * checking for null on getNextActivity()---Balaji
 * Revision 1.1 2009/10/03 20:57:17 mwpxp2 Moved
 * into .impl; adjusted imports
 * 
 * Revision 1.12 2009/10/03 20:04:57 mwpxp2 Adjusted imports for fw package
 * moves
 * 
 * Revision 1.11 2009/09/21 23:18:09 mwpxp2 Modified execute/1 to invoke
 * doesRequireAuthorization/1; added invokeAuthorizationService/1,
 * authorizedExecute/1 and processAuthorizationFailure/1
 * 
 * Revision 1.10 2009/09/03 00:54:39 mwsmg6 refactoring ations
 * 
 * Revision 1.9 2009/09/02 20:51:59 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.8 2009/09/02 20:44:13 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.7 2009/08/27 08:25:00 mwpxp2 Fixed imports to reflect fw
 * migration; bulk cleanup
 * 
 * Revision 1.6 2009/08/20 16:54:33 mwsmg6 enhanced logging of various
 * activities
 * 
 * Revision 1.5 2009/08/20 16:12:42 mwsmg6 provided more detailed logging of
 * activities
 * 
 * Revision 1.4 2009/08/19 22:43:29 mwsmg6 corrected class hierarchy and
 * resulting inherited methods
 * 
 * Revision 1.3 2009/08/10 23:30:07 mwpxp2 Added logging; bulk cleanup; added
 * file decorations where missing
 * 
 */
