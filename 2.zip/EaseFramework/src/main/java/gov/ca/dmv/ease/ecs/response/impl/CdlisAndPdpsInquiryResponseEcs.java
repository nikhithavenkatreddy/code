/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;

/**
 * Description: I am the CDLIS and PDPS ECS response.
 * File: CdlisAndPdpsInquiryResponseEcs.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: Jul 27, 2009 
 * @author MWBXP5  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CdlisAndPdpsInquiryResponseEcs extends
		AbstractAsynchronousResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5578623222397099517L;
	/** The promise. */
	private AsynchronousResponsePromise promise;

	/**
	 * The Constructor instantiates the CdlisAndPdpsInquiryResponseEcs response using a error collector.
	 * 
	 * @param validationErrors the validation errors
	 */
	public CdlisAndPdpsInquiryResponseEcs(ErrorMessageCollector validationErrors) {
		setValidationMessageObject(validationErrors);
	}

	/**
	 * Returns the promise object.
	 * @return promise the AsynchronousResponsePromise promise
	 */
	public AsynchronousResponsePromise getPromise() {
		return promise;
	}

	/**
	 * Sets the promise.
	 * @param promise the promise to set
	 */
	public void setPromise(AsynchronousResponsePromise promise) {
		this.promise = promise;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("promise", promise, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: CdlisAndPdpsInquiryResponseEcs.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 05:51:05  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.13  2009/10/14 18:10:59  mwhxb3
 *  updated comments
 *
 *  Revision 1.12  2009/10/03 21:23:42  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/08/27 05:54:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2009/08/27 02:34:02  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.9  2009/08/25 01:07:00  mwcsj3
 *  Updated response type
 *
 *  Revision 1.8  2009/08/05 01:41:29  mwpxp2
 *  Refactored with super; added fixmes
 *
 */
