/**
 * 
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;


/**
 * Description: Message creator class for AKTS messages
 * File: AktsMessageCreator.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Jan 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AktsMessageCreator implements MessageCreator {
	
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(AktsMessageCreator.class);
	
	/** Request for which this Message creator is used for **/
	private IEcsRequest request;
	
	/**
	 * @param aRequest
	 */
	public AktsMessageCreator (IEcsRequest aRequest) {
		request = aRequest;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String msgCreatedByConverter = convertor.createMessage(request);
		TextMessage textMessage = session.createTextMessage(msgCreatedByConverter);
		return textMessage;
	}
}


/**
 *  Modification History:
 *
 *  $Log: AktsMessageCreator.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/04/17 22:26:37  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.1  2012/02/15 19:35:08  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */