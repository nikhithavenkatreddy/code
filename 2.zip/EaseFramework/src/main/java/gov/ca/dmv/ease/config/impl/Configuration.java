/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.config.impl;

import gov.ca.dmv.ease.config.IConfiguration;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * Description: I am singleton concrete implementation of IConfiguration.
 * File: Configuration.java
 * Module:  gov.ca.dmv.ease.config.impl
 * Created: Aug 15, 2012
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Configuration implements IConfiguration {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1334985191320967770L;
	/** The SINGLETON. */
	private static IConfiguration SINGLETON;

	/**
	 * Gets the single instance of Configuration.
	 *
	 * @return single instance of Configuration
	 */
	public static IConfiguration getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new Configuration();
		}
		return SINGLETON;
	}

	/** The mode. */
	private String mode = UNKNOWN;

	/**
	 * Instantiates a new configuration.
	 */
	protected Configuration() {
		super();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Configuration)) {
			return false;
		}
		Configuration other = (Configuration) obj;
		//mode is never null
		if (!mode.equals(other.mode)) {
			return false;
		}
		return true;
	}

	/**
	 * Returns the Environment type 

	 * @return String 
	 */
	private String getEaseEnv() {
		Context initCtx;
		try {
			initCtx = new InitialContext();
			return (String) initCtx.lookup(EASE_ENVIRONMENT);
		}
		catch (NamingException e) {
			return DEV;
		}
	}

	/**
	 * Gets the mode.
	 *
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#getOperateMode()
	 */
	public String getOperateMode() {
		if (isInProductionMode()) {
			return OPERATE_MODE_P;
		}
		else {
			return OPERATE_MODE_T;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mode.hashCode();
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#initialize()
	 */
	public void initialize() {
		if (isInUnknownMode()) {
			read();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInDevelopmentMode()
	 */
	public boolean isInDevelopmentMode() {
		return APPDEV.equals(getMode()) || DEV.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInIntegrationTestMode()
	 */
	public boolean isInIntegrationTestMode() {
		return INTEGRATION.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInProductionMode()
	 */
	public boolean isInProductionMode() {
		return PRODUCTION.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInSystemTestMode()
	 */
	public boolean isInSystemTestMode() {
		return SYSTEM_TEST.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInTestingMode()
	 */
	public boolean isInTestingMode() {
		return !isInProductionMode() && !isInTrainingMode();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInTrainingMode()
	 */
	public boolean isInTrainingMode() {
		return TRAINING.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInUnknownMode()
	 */
	public boolean isInUnknownMode() {
		return UNKNOWN.equals(getMode())
				|| !(isInDevelopmentMode() || isInTestingMode()
						|| isInTrainingMode() || isInProductionMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#isInUserAcceptanceTestMode()
	 */
	public boolean isInUserAcceptanceTestMode() {
		return USER_ACCEPTANCE_TEST.equals(getMode());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.config.IConfiguration#read()
	 */
	public void read() {
		setMode(getEaseEnv());
	}

	/**
	 * Sets the mode.
	 *
	 * @param mode the mode to set
	 */
	protected void setMode(String mode) {
		if (mode == null) {
			mode = UNKNOWN;
		}
		else {
			this.mode = mode;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Configuration [mode=" + mode + "]";
	}
}
/**
 *  Modification History:
 *
 *  $Log: Configuration.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/09/25 20:33:05  mwrrv3
 *  Updated protected to public to access in UI.
 *
 *  Revision 1.15  2012/08/17 15:49:44  mwkfh
 *  updated equals
 *
 *  Revision 1.14  2012/08/17 15:43:42  mwkfh
 *  Changed getEaseEnv to return DEV is not able to find context
 *
 *  Revision 1.13  2012/08/16 21:42:24  mwhys
 *  Fixed PMD issue with naming of singleton.
 *
 *  Revision 1.12  2012/08/16 21:35:53  mwhys
 *  Updated isInDevelopmentMode().
 *
 *  Revision 1.11  2012/08/16 20:17:37  mwhys
 *  Updated isInTestingMode().
 *
 *  Revision 1.10  2012/08/16 19:50:07  mwkfh
 *  added initialize
 *
 *  Revision 1.9  2012/08/16 18:19:14  mwkfh
 *  updated getOperateMode
 *
 *  Revision 1.8  2012/08/16 18:11:37  mwkfh
 *  clean up
 *
 *  Revision 1.7  2012/08/16 18:11:03  mwkfh
 *  fixed access
 *
 *  Revision 1.6  2012/08/16 18:10:37  mwkfh
 *  added getOperateMode
 *
 *  Revision 1.5  2012/08/16 16:51:55  mwkfh
 *  added read
 *
 *  Revision 1.4  2012/08/16 15:48:05  mwkfh
 *  Completed implementation
 *
 *  Revision 1.3  2012/08/16 01:23:46  mwpxp2
 *  Added isInDevelopmentMode/0; implemented read of was context
 *
 *  Revision 1.2  2012/08/16 00:56:12  mwpxp2
 *  Implemented to read WAS context
 *
 *  Revision 1.1  2012/08/15 17:46:35  mwpxp2
 *  Initial - requires implementation of processProperties/0
 *
 */
