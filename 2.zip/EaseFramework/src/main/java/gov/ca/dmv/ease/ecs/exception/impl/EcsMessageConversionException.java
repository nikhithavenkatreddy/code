/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am to be used to signal conversion problems.
 * File: EcsMessageConversionException.java
 * Module:  gov.ca.dmv.ease.ecs.convert
 * Created: Mar 17, 2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsMessageConversionException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5692660753225478970L;

	/**
	 * Instantiates a new conversion exception.
	 */
	public EcsMessageConversionException() {
		super();
	}

	/**
	 * The Constructor instantiates the exception using a message.
	 * 
	 * @param arg0 the arg0
	 */
	public EcsMessageConversionException(String arg0) {
		super(arg0);
	}

	/**
	 * The Constructor instantiates the exception using a message and Throwable.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EcsMessageConversionException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor instantiates the exception using a Throwable.
	 * 
	 * @param cause the cause
	 */
	public EcsMessageConversionException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsMessageConversionException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/25 22:09:42  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.2  2010/03/22 23:23:40  mwpxp2
 *  Inherits from EcsServiceException now
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/13 19:51:11  mwhxb3
 *  updated comments.
 *
 *  Revision 1.1  2009/07/14 23:58:49  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-13 02:08:25  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.2  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.1  2009-05-08 05:44:08  mwpxp2
 *  synch
 *
 *  Revision 1.3  2009-04-26 17:08:33  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-04-26 07:34:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
