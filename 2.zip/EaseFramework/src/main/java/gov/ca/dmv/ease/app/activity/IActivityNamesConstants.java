/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity;

/**
 * Description: 
 * File: $ IActivityNamesConstants.java $
 * Module:  gov.ca.dmv.ease.app.activity
 * Created: Nov 4, 2010
 * @author MWOXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $ MWOXW $
 */
public interface IActivityNamesConstants {
	/**/
	String DAF_MAINTAINANCE_ACTIVITY = "DafMaintenanceActivity";
	/**/
	String COLLECT_DAF_RECORD_ACTIVITY = "CollectDafRecordActivity";
	/**/
	String BROWSE_DAILY_APP_FILE_ACTIVITY = "BrowseDailyAppFileActivity";
	/**/
	String DISPLAY_OF_DLAPP_DATA_ACTIVITY = "DisplayOfDlApplicationDataActivity";
	/**/
	String COLLECT_CDA_DATA_ACTIVITY = "CollectCdaDataActivity";
	/**/
	String COLLECT_SSN_DATA_ACTIVITY = "CollectSsnDataActivity";
}
/**
 *  Modification History:
 * 
 *  $Log: IActivityNamesConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/10 20:22:59  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2011/02/28 22:48:58  mwyxg1
 *  remove Serializable
 *
 *  Revision 1.2  2011/02/28 19:48:29  mwyxg1
 *  add COLLECT_SSN_DATA_ACTIVITY
 *
 *  Revision 1.1  2010/11/04 21:42:10  mwoxw
 *  Created
 *
 */
