/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.impl;

import gov.ca.dmv.ease.fw.validate.IValidatable;

/**
 * Description: I am Base Business Object.
 *  //FIXME - this class is superfluous and should be removed
 *  //FIXME - children of this class should interit from BusinessObject
 * File: BaseBusinessObject.java
 * Module:  gov.ca.dmv.dcs.bo.impl
 * Created: Sep 23, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class BaseBusinessObject extends BusinessObject implements
		IValidatable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4232324256897999734L;
}
/**
 *  Modification History:
 * 
 *  $Log: BaseBusinessObject.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/06/10 21:25:43  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2011/04/07 04:04:40  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.6.2.1  2011/04/02 20:50:47  mwhys
 *  (1) Generated hashCode() and equals() methods.
 *  (2) Added a copy method.
 *
 *  Revision 1.6  2011/03/25 21:02:02  mwtjc1
 *  reverted back to previous version
 *
 *  Revision 1.4  2010/10/11 17:55:24  mwpxp2
 *  Removed commented out code (validation is handled in superclass); added fixmes
 *
 *  Revision 1.3  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/03 21:04:59  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.1  2009/09/24 02:25:54  mwhxa2
 *  Created BaseBusinessObject to implement IValidatable
 *
*/
