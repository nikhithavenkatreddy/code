/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;

/**
 * Description: I am a jms message creator for Bridge code.
 * File: BridgeMessageCreator.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: June 28, 2010 
 * @author MWTJC1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BridgeMessageCreator implements MessageCreator {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(BridgeMessageCreator.class);
	/** Request for which this Message creator is used for **/
	private String corrId = null;
	/** Request for which this Message creator is used for **/
	private IEcsRequest request = null;

	/**
	 * Constructor - Instantiates a new creator.
	 * @param aRequest a request
	 * @param corrId a correlation id.
	 */
	public BridgeMessageCreator(IEcsRequest aRequest, String corrId) {
		request = aRequest;
		this.corrId = corrId;
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String msgCreatedByConverter = convertor.createMessage(request);
		TextMessage textMessage = session
				.createTextMessage(msgCreatedByConverter);
		textMessage.setJMSCorrelationID(corrId);
		LOGGER.info(" correlation id: " + corrId + " in: " + this);
		return textMessage;
	}
}
/**
 *  Modification History:
 *
 *  $Log: BridgeMessageCreator.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2012/08/16 20:37:09  mwkzn
 *  Renamed instance variable appropriately.
 *
 *  Revision 1.5  2010/12/12 17:50:27  mwpxp2
 *  Added logging of correlationId;
 *
 *  Revision 1.4  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/07/02 18:49:44  mwtjc1
 *  reverting back to accept corrid set by SpringBasedJmsAdaptor
 *
 *  Revision 1.2  2010/07/02 17:54:43  mwtjc1
 *  As expected by DMVA system, correlation id is hardcoded to office id 130
 *
 *  Revision 1.1  2010/06/28 20:49:51  mwtjc1
 *  first commit
 *
 */
