package gov.ca.dmv.ease.ecs.persist.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

public class Payload extends BusinessObject {

	/** The constant serial version id. */
	private static final long serialVersionUID = 5611489343471709460L;
	/** The id */
	private Long id;
	/** The correlation id. */
	private String correlationId;
	/** The sequence number of the payload. */
	private Integer seqNum;
	/** The payload string. */
	private String payload; 
	/** The absolute timestamp. */
	private Long absoluteExpirationTimestamp;
	/** The segment indicator. */
	private String segmentIndicator;
	
	/**
	 * Gets the correlation id.
	 * @return
	 */
	public String getCorrelationId() {
		return correlationId;
	}
	
	/**
	 * Sets the correlation id.
	 * @param correlationId
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	
	/**
	 * Gets the sequence number of the payload.
	 * @return
	 */
	public Integer getSeqNum() {
		return seqNum;
	}
	
	/**
	 * Sets the sequence number of the payload.
	 * @param seqNum
	 */
	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}
	
	/**
	 * Gets the payload string.
	 * @return
	 */
	public String getPayload() {
		return payload;
	}
	
	/**
	 * Sets the payload string.
	 * @param payload
	 */
	public void setPayload(String payload) {
		this.payload = payload;
	}
	
	/**
	 * Gets the Id
	 * @return
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Sets the id
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Gets the absolute timestamp.
	 * @return
	 */
	public Long getAbsoluteTimestamp() {
		return absoluteExpirationTimestamp;
	}
	
	/**
	 * Sets the absolute Timestamp
	 * @param absoluteTimestamp
	 */
	public void setAbsoluteTimestamp(Long absoluteTimestamp) {
		this.absoluteExpirationTimestamp = absoluteTimestamp;
	}
	
	/**
	 * Gets the segment indicator
	 * @return segment indicator
	 */
	public String getSegmentIndicator() {
		return segmentIndicator;
	}

	/**
	 * Sets the segment indicator
	 * @param segmentIndicator
	 */
	public void setSegmentIndicator(String segmentIndicator) {
		this.segmentIndicator = segmentIndicator;
	}

}
