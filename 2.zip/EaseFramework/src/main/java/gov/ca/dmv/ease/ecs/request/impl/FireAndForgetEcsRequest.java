/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;

/**
 * Description: I am a "null" response to a fire and forget request.
 * File: FireAndForgetEcsRequest.java
 * Module:  gov.ca.dmv.ease.service.impl
 * Created: 26/04/2009
 * @author mwpxp2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2016/02/18 20:17:49 $
 * Last Changed By: $Author: mwskh1 $
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2016/02/18 20:17:49 $
 * Last Changed By: $Author: mwskh1 $
 */
public class FireAndForgetEcsRequest extends AbstractEcsRequest implements
		IEcsConverterConstants {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9003394361288081854L;

	/**
	 * Instantiates a new no response request.
	 */
	public FireAndForgetEcsRequest() {
		super();
	}

	/**
	 * Instantiates a new no response request user context.
	 * 
	 * @param anId Id of the request
	 * @param userContext UserContext instance
	 */
	public FireAndForgetEcsRequest(IUserContext userContext) {
		super(userContext);
	}

	/**
	 * Instantiates a new fire and forget ECS request.
	 * 
	 * @param anId the ID
	 */
	public FireAndForgetEcsRequest(String anId) {
		super(anId);
	}

	/**
	 * Instantiates a new no response request with an ID and user context.
	 * 
	 * @param anId Id of the request
	 * @param userContext UserContext instance
	 */
	public FireAndForgetEcsRequest(String anId, IUserContext userContext) {
		super(anId, userContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public FireAndForgetReceipt execute() throws EcsServiceException {
		FireAndForgetReceipt returnFireAndForgetReceipt = null;
		//try {
		returnFireAndForgetReceipt = (FireAndForgetReceipt) getEcsService()
				.processRequest(this);
		//}
		//		catch (SystemException sysEx) {
		//			returnFireAndForgetReceipt.getErrorCollector().register(
		//					new EaseValidationException(RESOURCE_PROBLEM_MESSAGE));
		//		}
		return returnFireAndForgetReceipt;
	}

	public boolean isAktsRequest() {
		return false;
	}

	/**
	 * Checks if this is a voter reg request
	 * 
	 * @return true, if is voter reg request
	 */
	public boolean isVoterRegRequest() {
		return false;
	}

	/**
	 * Checks if is bridge request.
	 * 
	 * @return true, if is log request
	 */
	public boolean isBridgeRequest() {
		return false;
	}

	/**
	 * Checks if this is a DocScan request
	 * 
	 * @return
	 */
	public boolean isDocScanRequest() {
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#isFireAndForgetRequest()
	 */
	@Override
	public final boolean isFireAndForgetRequest() {
		return true;
	}

	/**
	 * Checks if is log request.
	 * 
	 * @return true, if is log request
	 */
	public boolean isLogRequest() {
		return false;
	}

	/**
	 * Checks if is Image Capture System request.
	 * 
	 * @return true, if is Image Capture System request
	 */
	public boolean isIcsRequest() {
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validate()
	 */
	@Override
	public IErrorCollector validate() {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		if (getUserContext().isDlNoUpdate()) {
			String[] updateTcodeArray = { TCODE_ELB, TCODE_EL1, TCODE_EL2,
					TCODE_EL3, TCODE_EL4, TCODE_EN2, TCODE_DQ1, TCODE_DUH,
					TCODE_DUK, TCODE_DUP, TCODE_DPR, TCODE_DPS, TCODE_DCA,
					TCODE_DCF, TCODE_DFA, TCODE_DFP, TCODE_DL5, TCODE_DL6,
					TCODE_DL7, TCODE_DLS, };
			IMessageConverter converter = getMessageConverter();
			if (converter != null
					&& ArrayUtils.contains(converter.getMessageTcode(),
							updateTcodeArray)) {
				aCollector.register(new EaseValidationException(
						"Do not allow to update CAMV."));
			}
		}
		return aCollector;
	}
}
/**
 *  Modification History:
 *
 *  $Log: FireAndForgetEcsRequest.java,v $
 *  Revision 1.2  2016/02/18 20:17:49  mwskh1
 *  Motor Voter - merge to head
 *
 *  Revision 1.1.16.2  2016/01/25 19:47:09  mwskh1
 *  Motor Voter -changes isVoterRegRequest to return false
 *
 *  Revision 1.1.16.1  2016/01/21 19:45:42  mwskh1
 *  Motor Voter - Add new subprocess and ECS message with queue settings
 *
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/04/17 22:26:39  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.15.2.1  2012/02/15 19:35:10  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 *  Revision 1.15  2012/01/30 23:53:43  mwsec2
 *  FODI integration code merged to HEAD
 *
 *  Revision 1.14  2011/07/23 20:28:46  mwkkc
 *  C78 is not update tcode
 *
 *  Revision 1.13  2011/07/16 00:54:02  mwxxw
 *  Add new override method : validate().
 *
 *  Revision 1.12  2010/11/05 22:16:57  mwtjc1
 *  try-catch block commented in execute method
 *
 *  Revision 1.11  2010/10/27 00:50:14  mwhys
 *  Added try-catch block around getEcsService().processRequest(this) call.
 *
 *  Revision 1.10  2010/10/14 21:12:49  mwpxr4
 *  Updates related to L1 Server JMS configuration.
 *
 *  Revision 1.9  2010/09/22 18:04:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.8  2010/09/21 18:52:01  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< FireAndForgetEcsRequest.java
 *  Revision 1.7  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
=======
 *  Revision 1.6.4.2  2010/09/18 23:08:21  mwpxr4
 *  Typecasted concrete classes
 *
 *  Revision 1.6.4.1  2010/09/14 22:13:09  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.7  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
>>>>>>> 1.6.4.2
 *  Revision 1.6  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.5  2010/04/22 19:23:20  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/04/12 02:33:54  mwpzs3
 *  update for bridge code communication
 *
 *  Revision 1.3  2010/04/01 16:57:58  mwhxb3
 *  Added a new Constructor with UserContext as a parameter.
 *
 *  Revision 1.2  2010/03/22 23:27:18  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.9  2009/11/03 02:04:15  mwpxp2
 *  Added isLogRequest/0; fixme
 *
 *  Revision 1.8  2009/10/14 20:47:08  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.7  2009/10/13 21:07:34  mwhxb3
 *  updated comments.
 *
 *  Revision 1.6  2009/10/07 19:29:07  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.5  2009/10/07 15:44:56  mwhxb3
 *  Replaced todo
 *
 *  Revision 1.4  2009/10/07 03:33:43  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:56:49  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:53:05  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:51  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:39  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.5  2009/10/03 21:23:35  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/08/27 02:33:53  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/22 20:29:55  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2009/08/10 23:05:46  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.1  2009/07/27 18:48:38  mwpxp2
 *  Renamed to insert "Dcs" into the name
 *
 *  Revision 1.4  2009/07/27 17:46:49  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.3  2009/07/17 00:20:51  mwakg
 *  Added IUserContext as a parameter to request classes of ECS's converters
 *
 *  Revision 1.2  2009/07/16 02:17:52  mwpxp2
 *  Removed empty getUserContext method
 *
 *  Revision 1.1  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.8  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.7  2009-05-13 20:28:52  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.6  2009-05-13 02:21:19  ppalacz
 *  Fixed return of execute declaration
 *
 *  Revision 1.5  2009-05-11 19:43:32  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.4  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 17:45:21  mwpxp2
 *  Moved in
 *
 *  Revision 1.2  2009-05-11 08:10:45  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-05-09 07:32:42  mwpxp2
 *  Moved in
 *
 *  Revision 1.3  2009-04-26 17:08:33  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-04-26 07:34:24  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
