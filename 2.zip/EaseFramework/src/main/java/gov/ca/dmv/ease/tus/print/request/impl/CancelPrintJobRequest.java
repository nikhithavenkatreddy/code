/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.validate.IValidator;
import gov.ca.dmv.ease.tus.print.request.validator.impl.CancelPrintJobRequestValidator;
import gov.ca.dmv.ease.tus.print.response.impl.CancelPrintJobResponse;
import gov.ca.dmv.ease.tus.print.service.impl.PrintService;

/**
 * Description: This class will invoke HP OS to Cancel Print Job.
 * File: CancelPrintJobRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: May 3, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CancelPrintJobRequest extends AbstractPrintServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8278798654917385509L;
	/** The HP OS Print Job Id. */
	private String clientJobId;

	/**
	 * Instantiates a new Cancel Print Job request.
	 * 
	 * @param aContext the a context
	 */
	public CancelPrintJobRequest(IUserContext aContext) {
		super(aContext);
	}

	/**
	 * Instantiates a new Cancel Print Job request.
	 * 
	 * @param clientJobId the Client Job Id
	 * @param aContext the User Context
	 */
	public CancelPrintJobRequest(String clientJobId, IUserContext aContext) {
		super(aContext);
		this.setClientJobId(clientJobId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest#execute()
	 */
	@Override
	public CancelPrintJobResponse execute() {
		return PrintService.execute(this);
	}

	/**
	 * Gets the Client Job Id.
	 * 
	 * @return the clientJobId
	 */
	public String getClientJobId() {
		return clientJobId;
	}

//	/* (non-Javadoc)
//	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#getValidator()
//	 */
//	@Override
//	public IValidator getValidator() {
//		return new CancelPrintJobRequestValidator();
//	}

	/**
	 * Sets the Client Job Id.
	 * 
	 * @param anJobId the clientJobId to set
	 */
	public void setClientJobId(String anJobId) {
		clientJobId = anJobId;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CancelPrintJobRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.4  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/07/07 22:50:03  mwhxa2
 *  removing this usage
 *
 *  Revision 1.2  2010/06/30 00:24:26  mwhxa2
 *  Updated Print Request to handle validations
 *
 *  Revision 1.1  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
*/
