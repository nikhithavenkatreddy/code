/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.reader.impl;

import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;

/**
 * Description: I am abstract superclass for format string readers
 * File: AbstractFormatReader.java
 * Module:  gov.ca.dmv.ease.fw.format.reader.impl
 * Created: Nov 28, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AbstractFormatReader {
	/**
	 * Instantiates a new abstract format reader.
	 */
	public AbstractFormatReader() {
		super();
	}

	/**
	 * Read up to.
	 * 
	 * @param aStopChar 
	 * @param aString 
	 * 
	 * @return the string
	 */
	protected String readUpTo(char aStopChar, String aString) {
		return readUpTo(aStopChar, aString, 0);
	}

	/**
	 * Read up to.
	 * 
	 * @param aStopChar 
	 * @param aString 
	 * @param aStartIndex 
	 * 
	 * @return the string
	 */
	protected String readUpTo(char aStopChar, String aString, int aStartIndex) {
		return readUpTo(aStopChar, aString, aStartIndex, true);
	}

	/**
	 * Read up to.
	 * 
	 * @param aStopChar 
	 * @param aString 
	 * @param aStartIndex 
	 * @param isStrict 
	 * 
	 * @return the string
	 */
	protected String readUpTo(char aStopChar, String aString, int aStartIndex,
			boolean isStrict) {
		//return all from a String up to but excluding the stop char - all if none
		int aSize = aString.length();
		StringBuilder aBuilder = new StringBuilder(aSize);
		char aChar;
		for (int i = aStartIndex; i < aSize; i++) {
			aChar = aString.charAt(i);
			if (aChar == aStopChar) {
				return aBuilder.toString();
			}
			else {
				aBuilder.append(aChar);
			}
		}
		if (isStrict) {
			throw new FormatValidationException('\''
					+ Character.toString(aStopChar) + "\' not found in \""
					+ aString + "\" starting at: " + aStartIndex);
		}
		else {
			return aBuilder.toString();
		}
	}

	/**
	 * Validate not empty.
	 * 
	 * @param aString 
	 */
	protected void validateNotEmpty(String aString) {
		if (aString.length() == 0) {
			throw new FormatValidationException("non-empty string expected");
		}
	}

	/**
	 * Validate not null.
	 * 
	 * @param aString 
	 */
	protected void validateNotNull(String aString) {
		if (aString == null) {
			throw new FormatValidationException("non-null string expected");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractFormatReader.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/11/29 07:44:50  mwpxp2
 *  Initial
 *
 */
