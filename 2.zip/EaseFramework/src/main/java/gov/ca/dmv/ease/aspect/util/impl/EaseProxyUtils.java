/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.aspect.util.impl;

import gov.ca.dmv.ease.fw.exception.impl.EasePropertyAccessingException;

import org.springframework.aop.TargetSource;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;

/**
 * Description: The purpose of this class to define the utility methods for the proxies.
 * File: EaseProxyUtils.java
 * Module:  gov.ca.dmv.ease.aspect.util.impl
 * Created: May 4, 2010 
 * @author MWVKM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseProxyUtils {
	/**
	 * The purpose of this method is to get the proxy object.
	 * 
	 * @param Object the object
	 * @return Object the proxy object
	 * @throws Exception 
	 */
	public static Object getProxyObject(Object obj) {
		Object target = obj;
		if (target instanceof Advised) {
			TargetSource targetSource = ((Advised) obj).getTargetSource();
			try {
				target = targetSource.getTarget();
			}
			catch (Exception e) {
				throw new EasePropertyAccessingException(e);
			}
		}
		return target;
	}

	/*
	 * Gets the user context.
	 * 
	 * @param processContext the process context
	 * 
	 * @return the user context
	 *
	public static IUserContext getUserContext(IProcessContext processContext) {
		return (IUserContext) EaseProxyUtils.getProxyObject(EaseProxyUtils
				.getProxyObject(processContext.getUserContext()));
	}
	*/
	/**
	* The purpose of this method is to get the name of the proxy object.
	* 
	* @param object the object
	* @return the entity name
	*/
	public static String getEntityName(Object object) {
		//TODO - not used - remove?
		String name = "";
		Class <?> targetClass = AopUtils.getTargetClass(object);
		if (targetClass != null) {
			name = targetClass.getName();
		}
		return name;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseProxyUtils.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/06/10 21:21:01  mwyxg1
 *  clean up
 *
 *  Revision 1.5  2010/09/30 22:53:54  mwkfh
 *  changed EaseException to EasePropertyAccessingException
 *
 *  Revision 1.4  2010/08/27 16:25:01  mwkfh
 *  clean-up
 *
 *  Revision 1.3  2010/07/16 15:31:40  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.1.2.2  2010/07/13 20:39:21  mwkfh
 *  update location in comments
 *
 *  Revision 1.1.2.1  2010/07/12 21:26:59  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.1.4.2  2010/06/28 23:29:29  mwvkm
 *  A bug with session restore is fixed.
 *
 *  Revision 1.1.4.1  2010/05/20 00:32:47  mwvkm
 *  Changes/Updates are made for Session Restore functionality POC.
 *
 *  Revision 1.1  2010/05/04 23:29:29  mwvkm
 *  Utility class for proxy classes
 *
 */
