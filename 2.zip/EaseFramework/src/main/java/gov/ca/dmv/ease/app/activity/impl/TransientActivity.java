/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am abstract superclass for activities executed in a process
 * File: TransientActivity.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created:  2009 
 * @author NN  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class TransientActivity extends Activity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(TransientActivity.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5099295817465101424L;
	/** The transitions key. */
	private String transitionKey;
	/** The transitions map. */
	private TransitionsMap transitions;

	/**
	 * Gets the next activity, the next activity will be determined based on the transition key 
	 * returned by the activity and the transitions defined in the BP definition file.
	 * 
	 * @return the next activity
	 */
	public Activity getNextActivity() {
		if (getTransitions().getTransition(getTransitionKey()) != null) {
			LOGGER.trace(getTransitions().getTransition(getTransitionKey())
					.getActivityName());
		}
		return getTransitions().getTransition(getTransitionKey());
	}

	/**
	 * @return the transitionKey
	 */
	public String getTransitionKey() {
		return transitionKey;
	}

	/**
	 * @return the transitions
	 */
	public TransitionsMap getTransitions() {
		return transitions;
	}

	/**
	 * @param transitionKey the transitionKey to set
	 */
	public void setTransitionKey(String transitionKey) {
		this.transitionKey = transitionKey;
	}

	/**
	 * @param transitions the transitions to set
	 */
	public void setTransitions(TransitionsMap transitions) {
		this.transitions = transitions;
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransientActivity.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/04/30 16:48:45  mwsec2
 *  adjusted logging levels
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2010/08/11 21:46:01  mwyxg1
 *  add null pointer check
 *
 *  Revision 1.7  2010/04/22 19:08:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/04/08 23:46:27  mwcsj3
 *  Added logging for easy debugging
 *
 *  Revision 1.5  2010/04/08 01:55:37  mwcsj3
 *  Cleaned up, removed all unused and redundant methods
 *
 *  Revision 1.4  2010/04/07 22:19:16  mwcsj3
 *  Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 *  Revision 1.3  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.2  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.3  2010/03/10 00:22:32  mwcsj3
 *  Referenced DEFAULT_TRANSITION_KEY from IProcessLoader interface
 *
 *  Revision 1.1.2.2  2010/02/26 19:42:25  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:57:17  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.5  2009/10/03 20:03:56  mwpxp2
 *  Added class comment, javadoc
 *
 *  Revision 1.4  2009/09/23 00:01:54  mwsmg6
 *  added clone
 *
 *  Revision 1.3  2009/08/10 23:30:08  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
