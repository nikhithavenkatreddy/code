/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.incrementer.impl;

import gov.ca.dmv.ease.tus.persist.incrementer.ISpringJdbcSequenceMaxValueIncrementer;

import javax.sql.DataSource;

import org.springframework.jdbc.support.incrementer.DB2SequenceMaxValueIncrementer;

/**
 * Purpose of this class is to retrieve the db table sequence number from the DB2
 * File: SpringJdbcSequenceMaxValueIncrementer.java
 * Module:  gov.ca.dmv.ease.tus.persist.util.impl
 * Created: September 08, 2010 
 * @author MWSZM12 
 * @version $Revision: 1.1 $
 */
public class SpringJdbcSequenceMaxValueIncrementer extends
		DB2SequenceMaxValueIncrementer implements
		ISpringJdbcSequenceMaxValueIncrementer {
	/**
	 * Instantiates a new spring jdbc sequence max value incrementer.
	 * 
	 * @param ds the ds
	 * @param incrementerName the incrementer name
	 */
	public SpringJdbcSequenceMaxValueIncrementer(DataSource ds,
			String incrementerName) {
		super(ds, incrementerName);
	}

	/**
	 * Gets the dB next long value.
	 * 
	 * @return the dB next long value
	 */
	public long getDbNextLongValue() {
		return getNextKey();
	}

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.support.incrementer.DB2SequenceMaxValueIncrementer#getSequenceQuery()
	 */
	public String getSequenceQuery() {
		return "select next value for " + getIncrementerName()
				+ " from sysibm.sysdummy1;";
	}

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.support.incrementer.AbstractDataFieldMaxValueIncrementer#getIncrementerName()
	 */
	public String getIncrementerName() {
		return super.getIncrementerName();
	}
}
/**
 *  Modification History:
 *
 *  $Log: SpringJdbcSequenceMaxValueIncrementer.java,v $
 *  Revision 1.1  2012/10/01 02:57:20  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/09 18:06:10  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/11/18 20:02:28  mwkfh
 *  moved incrementer to new package
 *
 *  Revision 1.3  2010/11/18 18:36:36  mwkfh
 *  added implements ISpringJdbcSequenceMaxValueIncrementer
 *
 *  Revision 1.2  2010/09/13 17:06:08  mwpxp2
 *  Added file footer, javadoc
 *
 */
