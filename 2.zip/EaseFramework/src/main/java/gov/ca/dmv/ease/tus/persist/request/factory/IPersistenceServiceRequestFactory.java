/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * Description: Interface for an object producing service requests. This factory
 * is to be called by Persistence service clients. The requests produces by the
 * factory follow the Command Pattern and they can be executed directly.
 * 
 * File: IPersistenceServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.print.request.factory
 * Created: Jul 26, 2009
 * 
 * @author MWAKG
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:53 $
 * Last Changed By: $Author: mwkfh $
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/23 23:39:53 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IPersistenceServiceRequestFactory extends Serializable {
	/**
	 * Creates an instance of DeleteBusinessObjectRequest instance.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createDeleteBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject);

	/**
	 * Creates an instance of MultipleDeleteBusinessObjectRequest instance.
	 * 
	 * @param userContext the user context
	 * @param aBoColl the a bo coll
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createMultipleDeleteBusinessObjectRequest(
			IUserContext userContext, Collection <IBusinessObject> aBoColl);

	/**
	 * Creates a new IPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param aBoColl the a bo coll
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createMultipleInsertOrUpdateRequest(
			IUserContext userContext, Collection <IBusinessObject> aBoColl);

	/**
	 * Creates a new IPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param aBoColl the a bo coll
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createMultipleRetrieveBusinessObjectRequest(
			IUserContext userContext, Collection <IBusinessObject> aBoColl);

	/**
	 * Creates a new IPersistenceServiceRequest object.
	 * 
	 * @param userContext
	 * @param classToPurge
	 * @return PurgeTableRequest
	 */
	IPersistenceServiceRequest createPurgeTableRequest(
			IUserContext userContext, Class <?> classToPurge);

	/**
	 * Creates a new IPersistenceServiceRequest object.
	 * 
	 * @param userContext
	 * @param classToPurge
	 * @param createdBefore
	 * @return PurgeTableRequest
	 */
	IPersistenceServiceRequest createPurgeTableRequest(
			IUserContext userContext, Class <?> classToPurge, Date createdBefore);

	/**
	 * Creates an instance of RetrieveAllBusinessObjectsRequest instance.
	 * 
	 * @param userContext the user context
	 * @param className the class name
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createRetrieveAllBusinessObjectsRequest(
			IUserContext userContext,
			Class <? extends IBusinessObject> className);

	/**
	 * Creates an instance of RetrieveBusinessObjectRequest instance.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createRetrieveBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject);

	/**
	 * Creates a new IPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param businessObjectClass the business object class
	 * 
	 * @return the i persistence service request
	 */
	IPersistenceServiceRequest createRetrieveCriteriaObjectRequest(
			IUserContext userContext,
			Class <? extends IBusinessObject> businessObjectClass);

	/**
	 * Retrieve inventory item request and update issued to true.
	 * 
	 * @param userContext the user context
	 * @param aItem	an inventory item
	 * 
	 * @return the persistence service request
	 */
	IPersistenceServiceRequest createRetrieveInventoryItemAndUpdateAsIssuedRequest(
			IUserContext userContext, IInventoryItemRetrievable aItem);

	/**
	 * Creates an instance of SaveOrUpdateBusinessObjectRequest instance.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 * 
	 * @return the save business object request
	 */
	IPersistenceServiceRequest createSaveOrUpdateBusinessObjectRequest(
			IUserContext userContext, IBusinessObject businessObject);
}
/**
 *  Modification History:
 *
 *  $Log: IPersistenceServiceRequestFactory.java,v $
 *  Revision 1.2  2012/10/23 23:39:53  mwkfh
 *  added createPurgeTableRequest
 *
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.19  2012/08/08 20:06:25  mwkfh
 *  removed createCurrentDateRequest
 *
 *  Revision 1.18  2011/10/12 20:58:11  mwkkc
 *  Performance Merge
 *
 *  Revision 1.17.14.1  2011/09/27 23:50:55  mwpxp2
 *  Corrected createCurrentDateRequest to use user context
 *
 *  Revision 1.17  2010/12/16 20:07:08  mwpxp2
 *  Added createCurrentDateRequest/0
 *
 *  Revision 1.16  2010/10/06 16:32:41  mwkfh
 *  added MultipleRetrieveBusinessObject...
 *
 *  Revision 1.15  2010/09/21 21:36:57  mwpxr4
 *  Removed duplicate method deleting multiple business objects.
 *
 *  Revision 1.14  2010/09/21 18:52:58  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< IPersistenceServiceRequestFactory.java
 *  Revision 1.13  2010/09/15 18:04:02  mwkfh
 *  added MultipleDeleteBusinessObjects
 *
 *  Revision 1.12  2010/09/13 20:26:17  mwkfh
 *  added extends Serializable
 *
=======
 *  Revision 1.11.2.1  2010/09/14 17:37:19  mwpxr4
 *  Added code to delete the processed payloads for a promise.
 *
>>>>>>> 1.11.2.1
 *  Revision 1.11  2010/09/13 16:52:15  mwkfh
 *  removed SeedPersistence for inventory
 *
 *  Revision 1.10  2010/09/10 22:05:17  mwkfh
 *  updated createSeedPersistenceRequest
 *
 *  Revision 1.9  2010/09/01 20:19:52  mwpxp2
 *  Added missing createRetrieveCriteriaObjectRequest
 *
 *  Revision 1.8  2010/09/01 20:09:24  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.7  2010/09/01 20:08:48  mwpxp2
 *  Added support for SeedPersistenceRequest and MultipleInsertOrUpdateRequest
 *
 *  Revision 1.6  2010/09/01 19:04:53  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.5  2010/08/18 20:51:33  mwkfh
 *  moved serialization methods to Serializer class
 *
 *  Revision 1.4  2010/08/16 20:32:15  mwkfh
 *  added isRecursivelySerializable() and isSerializable()
 *
 *  Revision 1.3  2010/08/11 00:43:59  mwkfh
 *  BlobFromObject and ObjectFromBlob have been moved to the PersistenceServiceRequestFactory
 *
 *  Revision 1.2  2010/07/23 23:11:56  mwkfh
 *  removed outdated ProcessContext persistence
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.25  2009/10/13 20:58:35  mwrsk
 *  Remove access modifiers
 *
 *  Revision 1.24  2009/10/03 21:32:49  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.23  2009/09/30 00:42:08  mwrsk
 *  Remove unused methods
 *
 *  Revision 1.22  2009/09/03 22:50:42  mwrsk
 *  code cleanup
 *
 *  Revision 1.21  2009/09/03 22:32:29  mwrsk
 *  Use interface instead of a concrete class
 *
 *  Revision 1.20  2009/09/03 22:26:55  mwrsk
 *  Use IPersistenseSeriveRequest interface instead of the abstract class
 *
 *  Revision 1.19  2009/09/03 22:18:15  mwrsk
 *  Changed the return types to concrete types
 *
 *  Revision 1.18  2009/09/03 21:25:03  mwrsk
 *  SaveProcessContextRequest now takes a byte array instead of IProcessContext
 *
 *  Revision 1.17  2009/08/31 03:28:04  mwrsk
 *  Comment SaveBusinessObject for now
 *
 *  Revision 1.16  2009/08/31 01:23:54  mwrsk
 *  Added SaveBusinessObject functionality
 *
 *  Revision 1.15  2009/08/28 23:43:24  mwrsk
 *  Refactor SaveBusinessObject request to SaveOrUpdate
 *
 *  Revision 1.14  2009/08/28 23:33:58  mwrsk
 *  Refactor SaveBusinessObject request to SaveOrUpdate
 *
 *  Revision 1.13  2009/08/27 06:29:26  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.12  2009/08/27 03:46:17  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.11  2009/08/25 16:36:49  mwrsk
 *  Changed the request name to RetrieveInventoryItemAndUpdateAsIssuedRequest
 *
 *  Revision 1.10  2009/08/25 16:05:41  mwrsk
 *  Updated to retrieve anyInventoryItem
 *
 *  Revision 1.9  2009/08/25 01:56:34  mwrsk
 *  Added new API for retrieving DL Inventory Item
 *
 *  Revision 1.8  2009/08/21 00:45:34  mwsxd10
 *  Factory method created for creating LogRequest objects.
 *
 *  Revision 1.7  2009/08/13 03:19:25  mwrsk
 *  Remove createSaveAllTransformationsRequest
 *
 *  Revision 1.6  2009/08/12 20:09:01  mwpxp2
 *  modified return type of createSaveBusinessObjectRequest; added fixme
 *
 *  Revision 1.5  2009/08/06 21:28:57  mwakg
 *  Merging from MWAKG_ECS_PERSISTENCE-SERVICE-DESIGN-CHANGES_BRANCH_20090806
 *
 *  Revision 1.4.2.1  2009/08/06 16:25:16  mwakg
 *  Changed the design of PersistenceService. Instead of working with BusinessObject PersistenceService is now working with IBusinessObject
 *
 *  Revision 1.4  2009/08/05 20:40:19  mwrsk
 *  Refactored code to make persistence service work
 *
 *  Revision 1.3  2009/07/30 16:54:30  mwakg
 *  Removed Employee from RestoreProcessContextRequest as we can can pull the same information from UserContext
 *
 *  Revision 1.2  2009/07/30 16:35:35  mwakg
 *  Removed Employee from SaveProcessContextRequest class
 *
 *  Revision 1.1  2009/07/29 16:57:00  mwakg
 *  Changed the design of persistence service hence refractored code accordingly
 *
 */
