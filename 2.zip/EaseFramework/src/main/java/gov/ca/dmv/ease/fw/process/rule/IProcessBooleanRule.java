/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process.rule;

import gov.ca.dmv.ease.fw.process.IProcessContext;

import java.io.Serializable;

/**
 * Description: I am interface for all rules operating on an instance of process context, and producing a boolean
 * File: IProcessBooleanRule.java
 * Module:  gov.ca.dmv.ease.fw.process.rule
 * Created: Jan 21, 2011
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IProcessBooleanRule extends IProcessRuleValidation,
		Serializable {
	/**
	 * Evaluate.
	 *
	 * @param aCtx the a ctx
	 * @return true, if successful
	 */
	boolean evaluate(IProcessContext aCtx);
}
/**
 *  Modification History:
 *
 *  $Log: IProcessBooleanRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/01/21 23:36:45  mwpxp2
 *  Parameter/imports cleanup for passing collector and context by interface
 *
 *  Revision 1.1  2011/01/21 23:08:23  mwpxp2
 *  Initial
 *
 */
