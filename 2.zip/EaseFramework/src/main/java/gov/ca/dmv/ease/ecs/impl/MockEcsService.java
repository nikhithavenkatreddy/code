/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.impl;

import gov.ca.dmv.ease.ecs.adaptor.IJmsAdaptor;
import gov.ca.dmv.ease.ecs.adaptor.impl.MockSpringBasedJmsAdaptor;

/**
 * Description: I a mock version of my superclass - to be used in unit testing
 * I operate on mock jms adaptor
 * I am not a singleton
 * 
 *  //TODO finish implementation to make it useful
 *  
 * File: MockEcsService.java
 * Module:  gov.ca.dmv.ease.ecs.impl
 * Created: Oct 19, 2011 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MockEcsService extends EcsService {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.impl.EcsService#getJmsAdaptor()
	 */
	protected IJmsAdaptor getJmsAdaptor() {
		return MockSpringBasedJmsAdaptor.getInstance();
	}

	/**
	 * Gets the single instance of MockEcsService.
	 *
	 * @return single instance of MockEcsService
	 */
	public static MockEcsService getInstance() {
		return new MockEcsService();
	}

	/**
	 * Instantiates a new mock ecs service.
	 */
	protected MockEcsService() {
		super();
	}
}
/**
 *  Modification History:
 *
 *  $Log: MockEcsService.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/10/19 19:03:40  mwpxp2
 *  Initial
 *
 */
