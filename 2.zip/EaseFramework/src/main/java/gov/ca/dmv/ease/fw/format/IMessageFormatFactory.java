/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format;

/**
 * Description: I am factory for format objects
 * File: IMessageFormatFactory.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IMessageFormatFactory {
	/**
	 * Creates a new IMessageFormat object.
	 * 
	 * @param aFieldValue 
	 * @param aStart 
	 * 
	 * @return 
	 */
	IFieldFormat createFieldFormatUsing(String aFieldValue, int aStart);

	/**
	 * Creates a new IMessageFormat object.
	 * 
	 * @param aString 
	 * @param aPos 
	 * @param aTypeChar 
	 * 
	 * @return 
	 */
	IFieldFormat createFieldFormatUsing(String aString, int aPos, char aTypeChar);

	/**
	 * Creates a new IMessageFormat object.
	 * 
	 * @param aString 
	 * @param aPos 
	 * @param aType 
	 * 
	 * @return 
	 */
	IFieldFormat createFieldFormatUsing(String aString, int aPos,
			FieldValueType aType);

	/**
	 * Creates a new IMessageFormat object.
	 * 
	 * @param aString 
	 * 
	 * @return 
	 */
	IMessageFormat createMessageFormatUsing(String... aString);
}
/**
 *  Modification History:
 *
 *  $Log: IMessageFormatFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/11/20 22:47:35  mwpxp2
 *  Added createFieldFormatUsing/2
 *
 *  Revision 1.1  2010/11/20 21:20:17  mwpxp2
 *  Initial
 *
 */
