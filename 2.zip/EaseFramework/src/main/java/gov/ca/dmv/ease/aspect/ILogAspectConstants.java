/**
 * 
 */
package gov.ca.dmv.ease.aspect;

/**
 * Description: This interface declared constants for aspects
 * File: IAuditLogAspectConstants.java
 * Module:  gov.ca.dmv.aspects
 * Created: Sep 19, 2009
 * 
 * @author MWSXD10
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ILogAspectConstants {
	/** The Constant LEFT_PAR. */
	static final String LEFT_PAR = "(";
	/** The Constant RIGHT_PAR. */
	static final String RIGHT_PAR = ")";
	/** The Constant COMPLETION_CODE_C . */
	static final String COMPLETION_CODE_C = "C";
	/** The Constant COMPLETION_CODE_E . */
	static final String COMPLETION_CODE_E = "E";
	/** The Constant COMPLETION_CODE_N . */
	static final String COMPLETION_CODE_N = "N";
	/** The Constant COMPLETION_CODE_O . */
	static final String COMPLETION_CODE_O = "O";
	/** The Constant SignOn ttc. */
	static final String SON_TTC = "SON";
	/** The Constant SignOff ttc. */
	static final String SOF_TTC = "SOF";
	/** The Constant CDA ttc. */
	static final String CDA_TTC = "CDA";
	/** The Constant COMPLETION_CODE_1 . */
	static final String COMPLETION_CODE_1 = "1";
	/** The Constant COMPLETION_CODE_2 . */
	static final String COMPLETION_CODE_2 = "2";
	/** The Constant COMPLETION_CODE_3 . */
	static final String COMPLETION_CODE_3 = "3";
	/** The Constant COMPLETION_CODE_4 . */
	static final String COMPLETION_CODE_4 = "4";
	/** The Constant COMPLETION_CODE_5 . */
	static final String COMPLETION_CODE_5 = "5";
	/** The Constant COMPLETION_CODE_6 . */
	static final String COMPLETION_CODE_6 = "6";
	/** The Constant COMPLETION_CODE_7 . */
	static final String COMPLETION_CODE_7 = "7";
	/** The Constant COMPLETION_CODE_8 . */
	static final String COMPLETION_CODE_8 = "8";
	static final String TTC_FOR_DRIVER_TEST_RESULT = "DTR";

}
/**
 * Modification History:
 * 
 * $Log: ILogAspectConstants.java,v $
 * Revision 1.1  2012/10/01 02:57:38  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.7  2012/03/01 05:59:00  mwkkc
 * Cleanup
 *
 * Revision 1.6  2011/03/14 16:36:10  mwyxg1
 * add complete code 1 - 8
 *
 * Revision 1.5  2011/01/10 23:52:33  mwxxw
 * Remove the Remove constant: DELIMITER. Use FIELD_DELIMITER instead.
 *
 * Revision 1.4  2010/12/13 02:54:01  mwpxr4
 * New constants added for production statistics and system management aspect.
 *
 * Revision 1.3  2010/03/22 23:17:12  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2010/03/22 23:06:04  mwpxp2
 * Javadoc/cleanup
 *
 * Revision 1.1  2009/11/24 01:51:35  mwrsk
 * Move classes from EASELogging
 *
 * Revision 1.3  2009/09/19 21:48:11  mwsxd10
 * Javadoc updated.
 *
 * Revision 1.2  2009/09/19 21:46:57  mwsxd10
 * code comments updated.
 *
 */
