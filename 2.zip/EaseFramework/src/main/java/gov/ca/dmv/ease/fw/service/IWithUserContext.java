/**
 * 
 */
package gov.ca.dmv.ease.fw.service;

import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am interface for an object capable of providing UserContext
 * 
 * File: IWithContextProvider.java
 * Module:  gov.ca.dmv.ease.fw.user
 * Created: Jul 9, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithUserContext {
	/**
	 * Gets the user context.
	 * 
	 * @return the user context
	 */
	public IUserContext getUserContext();
}
/**
 *  Modification History:
 * 
 *  $Log: IWithUserContext.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:24:35  mwpxp2
 *  Moved into fw.service; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/07/14 23:44:29  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 16:11:22  ppalacz
 *  Renamed from IUserContextProvider
 *
 *  Revision 1.1  2009-07-12 15:52:20  ppalacz
 *  Initial
 *
 *  Revision 1.1  2009-07-10 07:13:08  ppalacz
 *  Synch
 *
*/
