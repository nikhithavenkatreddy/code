/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: Constants for identifying EASE environments.
 * File: $ IEaseEnvironmentConstants.java $
 * Module:  gov.ca.dmv.ease.fw.constants
 * Created: Dec 27, 2011
 * @author MWHYS  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $ MWHYS $
 */
public interface IEaseEnvironmentConstants {
	String DEV = "DEV";
	String APPDEV = "APPDEV";
	String EASE_ENVIRONMENT = "EASE_ENV";
	String INTEGRATION = "IT";
	String OPERATE_MODE_P = "P";
	String OPERATE_MODE_T = "T";
	String PRODUCTION = "PROD";
	String SYSTEM_TEST = "ST";
	String TRAINING = "TRAIN";
	String UNKNOWN = "UNKNOWN";
	String USER_ACCEPTANCE_TEST = "UAT";
}
/**
 *  Modification History:
 * 
 *  $Log: IEaseEnvironmentConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2012/08/16 21:35:37  mwhys
 *  Added DEV.
 *
 *  Revision 1.5  2012/08/16 20:17:22  mwhys
 *  Remvoed the list "TESTING".
 *
 *  Revision 1.4  2012/08/16 18:18:30  mwkfh
 *  added OPERATE_MODE
 *
 *  Revision 1.3  2012/08/16 15:47:01  mwkfh
 *  fixed typo
 *
 *  Revision 1.2  2012/08/16 15:26:09  mwkfh
 *  added constants
 *
 *  Revision 1.1  2012/01/03 17:48:52  mwhys
 *  Initial. (Defect 1123)
 *
 */
