/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.factory.impl;

import gov.ca.dmv.ease.ecs.IEcsService;
import gov.ca.dmv.ease.ecs.impl.EcsService;
import gov.ca.dmv.ease.ecs.request.factory.ILogRequestFactory;
import gov.ca.dmv.ease.ecs.request.log.impl.AuditLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.SystemManagementLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.TechnicalLogRequest;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Calendar;

/**
 * Description: I am implementation of ILogRequestFactory.
 * File: LogRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.log.request.factory
 * Created: 19/07/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LogRequestFactory implements ILogRequestFactory {
	/** Default office id if not set in user context. */
	private static final String DEFAULT_OFFICE_ID = "O20";
	/** Default tech id if not set in user context. */
	private static final String DEFAULT_TECH_ID = "T2";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6612752907541727469L;
	/** The SINGLETON. */
	private static LogRequestFactory SINGLETON;
	/** the ECS Service */
	private IEcsService ecsService;

	/**
	 * Extracts Timestamp.
	 * @param calender a Calender object
	 * @return a String
	 */
	protected static String extractTimestamp(Calendar calender) {
		return ljustify(calender.get(java.util.Calendar.YEAR), 4)
				+ ljustify(calender.get(java.util.Calendar.MONTH) + 1, 2)
				+ ljustify(calender.get(java.util.Calendar.DATE), 2)
				+ ljustify(calender.get(java.util.Calendar.HOUR), 2)
				+ ljustify(calender.get(java.util.Calendar.MINUTE), 2)
				+ ljustify(calender.get(java.util.Calendar.SECOND), 2)
				+ ljustify(calender.get(java.util.Calendar.MILLISECOND), 5);
	}

	/**
	 * Gets the single instance of LogRequestFactory.
	 *
	 * @return single instance of LogRequestFactory
	 */
	public static LogRequestFactory getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new LogRequestFactory();
		}
		return SINGLETON;
	}

	/**
	 * Left justify.
	 * 
	 * @param number the number
	 * @param stringLength the string length
	 * 
	 * @return preJust the string
	 */
	public static String ljustify(int number, int stringLength) {
		String preJust = Integer.toString(number);
		for (int j = preJust.length(); j < stringLength; j++) {
			preJust = "0" + preJust;
		}
		return preJust;
	}

	/**
	 * Instantiates a new log request factory.
	 */
	protected LogRequestFactory() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.factory.ILogRequestFactory#createAuditLogRequest(java.lang.String, gov.ca.dmv.ease.bo.user.IUserContext)
	 */
	public AuditLogRequest createAuditLogRequest(String logEntry,
			IUserContext userContext) {
		String anId = this.generateUniqueId(userContext);
		AuditLogRequest auditLogRequest = new AuditLogRequest(anId,
				userContext, logEntry);
		auditLogRequest.setEcsService(getEcsService());
		return auditLogRequest;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.factory.ILogRequestFactory#createSystemManagementLogRequest(java.lang.String, gov.ca.dmv.ease.bo.user.IUserContext)
	 */
	public SystemManagementLogRequest createSystemManagementLogRequest(
			String logEntry, IUserContext userContext) {
		String anId = this.generateUniqueId(userContext);
		SystemManagementLogRequest systemManagementLogRequest = new SystemManagementLogRequest(
				anId, userContext, logEntry);
		systemManagementLogRequest.setEcsService(getEcsService());
		return systemManagementLogRequest;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.factory.ILogRequestFactory#createTechLogRequest(java.lang.String, gov.ca.dmv.ease.bo.user.IUserContext)
	 */
	public TechnicalLogRequest createTechLogRequest(String logEntry,
			IUserContext userContext) {
		String anId = this.generateUniqueId(userContext);
		TechnicalLogRequest technicalLogRequest = new TechnicalLogRequest(anId,
				userContext, logEntry);
		technicalLogRequest.setEcsService(getEcsService());
		return technicalLogRequest;
	}

	/**
	 * Generates unique id.
	 * 
	 * @param userContext a UserContext
	 * 
	 * @return id an unique id
	 */
	public String generateUniqueId(IUserContext userContext) {
		String uniqueId = null;
		String officeId = userContext.getOfficeId();
		String techId = userContext.getTechId();
		StringBuilder stringBuilder = new StringBuilder();
		if ((userContext.getOfficeId() == null)
				|| userContext.getOfficeId().equalsIgnoreCase("")) {
			officeId = DEFAULT_OFFICE_ID;
		}
		if ((userContext.getTechId() == null)
				|| userContext.getTechId().equalsIgnoreCase("")) {
			techId = DEFAULT_TECH_ID;
		}
		stringBuilder.append(officeId + techId);
		Calendar calender = Calendar.getInstance();
		stringBuilder.append(LogRequestFactory.extractTimestamp(calender));
		uniqueId = stringBuilder.toString();
		return uniqueId;
	}

	/**
	 * Simple getter for the ecsService.
	 * 
	 * @return the ecsService
	 */
	public IEcsService getEcsService() {
		if (ecsService == null) {
			return EcsService.getInstance();
		}
		else {
			return ecsService;
		}
	}

	/**
	 * Simple setter for the ecsService.
	 * 
	 * @param ecsService the ecsService to set
	 */
	public void setEcsService(IEcsService mockEcsService) {
		this.ecsService = mockEcsService;
	}
}
/**
 *  Modification History:
 *
 *  $Log: LogRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2012/08/30 15:50:34  mwkfh
 *  updated EcsService methods
 *
 *  Revision 1.12  2012/03/13 02:06:53  mwkkc
 *  Clean up - Defect 7295 and 7296
 *
 *  Revision 1.11  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.10.8.1  2011/09/26 23:21:56  mwpxp2
 *  Modified for singleton factories and services
 *
 *  Revision 1.10  2011/06/10 21:50:13  mwyxg1
 *  clean up
 *
 *  Revision 1.9  2010/09/21 18:50:06  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< LogRequestFactory.java
 *  Revision 1.8  2010/09/14 21:25:23  mwkfh
 *  fixed ecsService injections
 *
=======
 *  Revision 1.7.4.2  2010/09/20 22:31:08  mwpxr4
 *  Corrected code.
 *
 *  Revision 1.7.4.1  2010/09/14 22:22:38  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.8  2010/09/14 21:25:23  mwkfh
 *  fixed ecsService injections
 *
>>>>>>> 1.7.4.2
 *  Revision 1.7  2010/09/13 04:39:50  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.6  2010/08/31 17:57:26  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.5  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.4  2010/05/26 01:22:21  mwpxp2
 *  Cleanup
 *
 *  Revision 1.3  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.2  2010/03/22 23:26:27  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.19  2009/10/14 20:33:20  mwhxb3
 *  updated comments
 *
 *  Revision 1.18  2009/10/08 20:26:47  mwpzs3
 *  cpd refactor
 *
 *  Revision 1.17  2009/10/07 14:34:24  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.16  2009/10/07 03:33:29  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.15  2009/10/07 02:56:29  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.14  2009/10/06 21:52:46  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.13.2.2  2009/10/06 20:41:54  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.13.2.1  2009/10/06 20:28:47  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.13  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.12  2009/09/18 00:24:54  mwsxd10
 *  EcsService is set instead of SpringJms102EcsSerivice.
 *
 *  Revision 1.11  2009/08/27 05:54:46  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2009/08/27 02:33:58  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.9  2009/08/22 20:34:08  mwpxp2
 *  Adjsuted imports
 *
 *  Revision 1.8  2009/08/18 20:38:34  mwvkk1
 *  updated the createSystemManagementLogRequest and createTechLogRequest
 *
 *  Revision 1.7  2009/08/18 18:51:05  mwvkk1
 *  updated createAuditLogRequest
 *
 *  Revision 1.6  2009/08/10 22:49:53  mwpxp2
 *  Added logging, missing javadoc
 *
 *  Revision 1.5  2009/07/27 17:46:10  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/07/23 01:13:29  mwpxm2
 *  refactor
 *
 *  Revision 1.2  2009/07/22 16:36:03  mwaxb1
 *  Refactor logging stubs by moving code related to ECS call to ECS project
 *
 *  Revision 1.1  2009/07/21 21:15:33  mwpxp2
 *  Implementation stub
 *
 *  Revision 1.1  2009-07-20 13:25:35  mwpxp2
 *  Initial
 *
 */
