/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.factory.impl;

import gov.ca.dmv.ease.ecs.IEcsService;
import gov.ca.dmv.ease.ecs.bridge.request.impl.BridgeRequest;
import gov.ca.dmv.ease.ecs.bridge.request.impl.ProductionStatisticRequestEcs;
import gov.ca.dmv.ease.ecs.impl.EcsService;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Calendar;

/**
 * Description: I am factory of requests related to sending messages to the DMVA bridge
 * File: BridgeRequestFactory.java
 * Module:  gov.ca.dmv.ease.ecs.request.factory.impl
 * Created: Apr 10, 2010 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BridgeRequestFactory {
	/** Default office id if not set in user context. */
	private static final String DEFAULT_OFFICE_ID = "O20";
	/** Default tech id if not set in user context. */
	private static final String DEFAULT_TECH_ID = "T2";
	/** The SINGLETON. */
	private static BridgeRequestFactory SINGLETON;

	/**
	 * Extracts Timestamp.
	 * 
	 * @param calender a Calender object
	 * 
	 * @return a String
	 */
	private static String extractTimestamp(Calendar calender) {
		return ljustify(calender.get(java.util.Calendar.YEAR), 4)
				+ ljustify(calender.get(java.util.Calendar.MONTH) + 1, 2)
				+ ljustify(calender.get(java.util.Calendar.DATE), 2)
				+ ljustify(calender.get(java.util.Calendar.HOUR), 2)
				+ ljustify(calender.get(java.util.Calendar.MINUTE), 2)
				+ ljustify(calender.get(java.util.Calendar.SECOND), 2)
				+ ljustify(calender.get(java.util.Calendar.MILLISECOND), 5);
	}

	/**
	 * Generates unique id.
	 * 
	 * @param userContext a UserContext
	 * 
	 * @return id an unique id
	 */
	private static String generateUniqueId(IUserContext userContext) {
		String uniqueId = null;
		String officeId = userContext.getOfficeId();
		String techId = userContext.getTechId();
		StringBuilder stringBuilder = new StringBuilder();
		if ((userContext.getOfficeId() == null)
				|| userContext.getOfficeId().equalsIgnoreCase("")) {
			officeId = DEFAULT_OFFICE_ID;
		}
		if ((userContext.getTechId() == null)
				|| userContext.getTechId().equalsIgnoreCase("")) {
			techId = DEFAULT_TECH_ID;
		}
		stringBuilder.append(officeId + techId);
		Calendar calender = Calendar.getInstance();
		stringBuilder.append(extractTimestamp(calender));
		uniqueId = stringBuilder.toString();
		return uniqueId;
	}

	/**
	 * Gets the single instance of BridgeRequestFactory.
	 *
	 * @return single instance of BridgeRequestFactory
	 */
	public static BridgeRequestFactory getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new BridgeRequestFactory();
		}
		return SINGLETON;
	}

	/**
	 * Left justify.
	 * 
	 * @param number the number
	 * @param stringLength the string length
	 * 
	 * @return preJust the string
	 */
	private static String ljustify(int number, int stringLength) {
		String preJust = Integer.toString(number);
		for (int j = preJust.length(); j < stringLength; j++) {
			preJust = "0" + preJust;
		}
		return preJust;
	}

	/**
	 * Instantiates a new bridge request factory.
	 */
	protected BridgeRequestFactory() {
		super();
	}

	/**
	 * Creates a new BridgeRequest object.
	 * 
	 * @param msg the msg
	 * @param userContext the user context
	 * 
	 * @return the bridge request
	 */
	public BridgeRequest createBridgeRequest(String msg,
			IUserContext userContext) {
		String anId = generateUniqueId(userContext);
		BridgeRequest bridgeRequest = new BridgeRequest(anId, userContext, msg);
		bridgeRequest.setEcsService(getEcsService());
		return bridgeRequest;
	}

	/**
	 * Creates a new BridgeRequest object.
	 * 
	 * @param userContext 
	 * @param completionCode 
	 * @param cashierSequenceNbr 
	 * @param dlOrIdIndicator 
	 * @param ttc 
	 * 
	 * @return 
	 */
	public ProductionStatisticRequestEcs createProductionStatisticRequestEcs(
			IUserContext userContext, String completionCode,
			String cashierSequenceNbr, String dlOrIdIndicator, String ttc) {
		ProductionStatisticRequestEcs aRequest = new ProductionStatisticRequestEcs(
				userContext, completionCode, cashierSequenceNbr,
				dlOrIdIndicator, ttc);
		aRequest.setEcsService(getEcsService());
		return aRequest;
	}

	/**
	 * Creates a new ProductionStatisticRequestEcs object.
	 * 
	 * @param msg the msg
	 * @param userContext the user context
	 * 
	 * @return the bridge request
	 */
	public ProductionStatisticRequestEcs createProductionStatisticRequestEcs(
			String msg, IUserContext userContext) {
		String anId = generateUniqueId(userContext);
		ProductionStatisticRequestEcs productionStatBridgeRequest = new ProductionStatisticRequestEcs(
				anId, userContext, msg);
		productionStatBridgeRequest.setEcsService(getEcsService());
		return productionStatBridgeRequest;
	}

	/**
	 * Get the ECS service.
	 * 
	 * @return returnIEcsService the ECS service
	 */
	public IEcsService getEcsService() {
		return EcsService.getInstance();
	}

	/**
	 * Set the instance of the ECS Service.
	 * 
	 * @param ecsService the ecs service
	 */
	public void setEcsService(IEcsService ecsService) {
		
		//TODO - remove
	}
}
/**
 *  Modification History:
 * 
 *  $Log: BridgeRequestFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/03/13 02:06:53  mwkkc
 *  Clean up - Defect 7295 and 7296
 *
 *  Revision 1.15  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.14.8.1  2011/09/26 23:21:46  mwpxp2
 *  Modified for singleton factories and services
 *
 *  Revision 1.14  2011/06/10 21:47:16  mwyxg1
 *  clean up
 *
 *  Revision 1.13  2010/12/10 02:56:50  mwpxp2
 *  Added singleton
 *
 *  Revision 1.12  2010/12/10 02:50:27  mwpxp2
 *  Added createProductionStatisticRequestEcs/5
 *
 *  Revision 1.11  2010/09/22 18:19:34  mwpxp2
 *  Adjusted imports for bridge-related request class move
 *
 *  Revision 1.10  2010/09/21 18:49:40  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< BridgeRequestFactory.java
 *  Revision 1.9  2010/09/14 21:25:24  mwkfh
 *  fixed ecsService injections
 *
=======
 *  Revision 1.8.4.2  2010/09/20 22:31:08  mwpxr4
 *  Corrected code.
 *
 *  Revision 1.8.4.1  2010/09/14 22:22:38  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.9  2010/09/14 21:25:24  mwkfh
 *  fixed ecsService injections
 *
>>>>>>> 1.8.4.2
 *  Revision 1.8  2010/09/13 04:39:50  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.7  2010/08/31 17:57:19  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.6  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.5  2010/07/31 00:13:13  mwkkc
 *  Auditing and Logging Work
 *
 *  Revision 1.4  2010/05/26 01:22:21  mwpxp2
 *  Cleanup
 *
 *  Revision 1.3  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.2  2010/04/22 19:21:55  mwpxp2
 *  Bulk cleanup - added missing javadoc
 *
 *  Revision 1.1  2010/04/12 02:34:04  mwpzs3
 *  update for bridge code communication
 *
 */
