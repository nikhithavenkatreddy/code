/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.rule.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EasePreconditionViolationException;

/**
 * Description: I am exception to be used when passed arguments
 * for rule evaluation are in themselves valid, but the rule _does not_ apply in this case.
 * File: RuleNotApplicableException.java
 * Module:  gov.ca.dmv.ease.fw.rule.exception.impl
 * Created: Jan 21, 2011
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RuleNotApplicableException extends
		EasePreconditionViolationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3819822359756958096L;

	/**
	 * Instantiates a new rule not applicable exception.
	 */
	public RuleNotApplicableException() {
	}

	/**
	 * Instantiates a new rule not applicable exception.
	 *
	 * @param message the message
	 */
	public RuleNotApplicableException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new rule not applicable exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public RuleNotApplicableException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new rule not applicable exception.
	 *
	 * @param cause the cause
	 */
	public RuleNotApplicableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: RuleNotApplicableException.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/01/21 23:06:34  mwpxp2
 *  Initial
 *
 */
