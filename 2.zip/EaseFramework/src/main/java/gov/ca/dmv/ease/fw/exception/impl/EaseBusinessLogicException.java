/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am abstract superclass for exceptions to be used in business logic.
 * 
 * File: EaseBusinessLogicException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Oct 30, 2010 
 * @author MWTJC1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EaseBusinessLogicException extends EaseLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8131220161093019236L;

	/**
	 * Instantiates a new ease service exception.
	 */
	public EaseBusinessLogicException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseBusinessLogicException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseBusinessLogicException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseBusinessLogicException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseBusinessLogicException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/10/30 18:46:37  mwtjc1
 *  first commit
 *
 */
