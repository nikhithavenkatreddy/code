/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.service;

import gov.ca.dmv.ease.app.session.request.impl.DeleteSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RestoreSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.RetrieveSessionRequest;
import gov.ca.dmv.ease.app.session.request.impl.StoreSessionRequest;
import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;

/**
 * Description: The purpose of this interface is to define the methods for the persistence store of session.
 * File: ISessionService.java
 * Module:  gov.ca.dmv.ease.app.session.service
 * Created: Apr 28, 2010 
 * @author MWVKM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISessionService {
	static final String INVALID_SESSION = "NOT A VALID SESSION";
	static final String OLD_SESSION_FOUND = "OLD SESSION FOUND AND REMOVED";
	static final String SESSION_NOT_FOUND = "SESSION NOT FOUND";

	/**
	 * The purpose of this method is to delete the session business object.
	 * 
	 * @param DeleteSessionRequest
	 * 
	 * @return ISessionServiceResponse
	 */
	ISessionServiceResponse execute(DeleteSessionRequest request);

	/**
	 * The purpose of this method is to retrieve the session business object and update with the new session id.
	 * 
	 * @param RestoreSessionRequest
	 * 
	 * @return ISessionServiceResponse
	 */
	ISessionServiceResponse execute(RestoreSessionRequest request);

	/**
	 * The purpose of this method is to retrieve the session business object.
	 * 
	 * @param RetrieveSessionRequest
	 * 
	 * @return ISessionServiceResponse
	 */
	ISessionServiceResponse execute(RetrieveSessionRequest request);

	/**
	 * The purpose of this method is to store the session business object.
	 * 
	 * @param StoreSessionRequest
	 * 
	 * @return ISessionServiceResponse
	 */
	ISessionServiceResponse execute(StoreSessionRequest request);
}
/**
 *  Modification History:
 *
 *  $Log: ISessionService.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/01/10 19:16:01  mwkfh
 *  added INVALID_SESSION
 *
 *  Revision 1.7  2010/10/12 18:40:08  mwkfh
 *  added constants used in session service
 *
 *  Revision 1.6  2010/09/30 21:24:41  mwkfh
 *  added RestoreSessionRequest
 *
 *  Revision 1.5  2010/09/30 17:49:55  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 *  Revision 1.4  2010/09/01 18:56:53  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/08/27 18:43:48  mwkfh
 *  removed unneeded setters
 *
 *  Revision 1.2  2010/08/03 16:58:08  mwkfh
 *  added a couple methods
 *
 *  Revision 1.1  2010/07/30 22:07:57  mwkfh
 *  refactored and merge session store and restore
 *
 *  Revision 1.2  2010/07/29 17:53:16  mwkfh
 *  added fetchSessionId()
 *
 *  Revision 1.1  2010/07/27 18:01:06  mwkfh
 *  updated and moved session services
 *
 *  Revision 1.3  2010/07/16 15:32:40  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.1.2.1  2010/07/12 21:26:58  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.3  2010/05/04 00:52:02  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/05/04 00:16:24  mwvkm
 *  New method is added for delete.
 *
 *  Revision 1.1  2010/05/02 17:56:38  mwkkc
 *  Clean up
 *
 *  Revision 1.1  2010/04/29 23:52:04  mwvkm
 *  Initial check-in for session restore in session management
 *
 */
