/** * 
* This source code contains State of California's confidential and trade secret information.
* Any use of this code other than for backup is strictly prohibited.
* Copyright State of California (c) 2009
* http://www.california.gov
*/
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.fw.process.IProcessContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am abstract Restart Activity from which concrete restart activities are expected to inherit
 * 
 * File: RestartActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Aug 26, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:36:52 $
 * Last Changed By: $Author: mwhys $
 */
public abstract class RestartActivity extends Activity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(RestartActivity.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2434419602690978522L;
	
	/**
	 * Instantiates a new restart activity.
	 */
	public RestartActivity() {
		super();
	}
	
	/**
	 * Creates the new child context.
	 *
	 * @param aCtx the a ctx
	 * @return the child context
	 */
	private ChildContext createNewChildContext(ProcessContext aCtx) {
		IProcessContext newContext = aCtx.getProcessRegistry().getProcess(
				aCtx.getProcessId()).getProcessContext();
		return (ChildContext) newContext;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.BusinessActivity#invokeService(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext aCtx) {
		preRestartCondition(aCtx);
		ChildContext currentChildContext = (ChildContext) aCtx;
		currentChildContext.clearExecutionSyncPoints();
		deleteSavePoint(aCtx.getRootContext());
		ChildContext newChildContext = createNewChildContext(currentChildContext);
		populateProperties(currentChildContext, newChildContext);
		try {
			newChildContext.startIn(currentChildContext
					.getParentProcessContext());
		}
		catch (Exception e) {
			LOGGER.info("Error starting the child process :: "
					+ newChildContext.getProcessId());
		}
	}
	
	/**
	 * populate properties from the old child process context to the new child process context.
	 *
	 * @param source the source
	 * @param target the target
	 */
	abstract protected void populateProperties(ProcessContext source,
			ProcessContext target);
	
	/**
	 * Override this method to process business before creating a new child process context.
	 *
	 * @param aCtx the a ctx
	 */
	protected void preRestartCondition(ProcessContext aCtx) {
	}
}
/**
 *  Modification History:
 *
 *  $Log: RestartActivity.java,v $
 *  Revision 1.2  2012/12/13 00:36:52  mwhys
 *  Updated call deleteSavePoint
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2012/05/08 00:08:31  mwhys
 *  Added call to deleteSavePoint() for Session Management.
 *
 *  Revision 1.10  2011/05/06 21:04:10  mwsec2
 *  fixed a defect that occurs on a fallback following a restart. Restart should clear the sync point stack.
 *
 *  Revision 1.9  2011/01/14 23:17:20  mwtjc1
 *  purgeDafRecord removed
 *
 *  Revision 1.8  2011/01/14 22:45:25  mwtjc1
 *  purgeDafRecord added
 *
 *  Revision 1.7  2010/11/09 03:19:30  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.6  2010/09/28 21:56:54  mwyxg1
 *  getProcessRegistry from current process context
 *
 *  Revision 1.5  2010/09/28 17:29:05  mwyxg1
 *  change oldChildContext to currentChildContext
 *
 *  Revision 1.4  2010/09/28 16:18:22  mwyxg1
 *  Modify generic restart activity, use startIn method.
 *
 *  Revision 1.3  2010/09/23 18:07:23  mwsyk1
 *  reverse back to getProcess
 *
 *  Revision 1.2  2010/09/23 16:06:08  mwyxg1
 *  change from getProcess to getProcessByTtc
 *
 *  Revision 1.1  2010/08/26 21:42:28  mwpxp2
 *  Initial
 *
 */
