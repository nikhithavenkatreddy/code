/**
 * 
 */
package gov.ca.dmv.ease.app.activity;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: This Interface allow any Activities class to support CNA. 
 * File: ICnaCapable.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created: Jul 16, 2010 
 * @author mwmrs8  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICnaCapable {
	/**
	 * Checks if is cna action allowed.
	 * 
	 * @param processContext the process context
	 * 
	 * @return true, if is cna action allowed
	 */
	boolean isCnaActionAllowed(ProcessContext processContext);
}
/**
 *  Modification History:
 *
 *  $Log: ICnaCapable.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/08/20 18:04:20  mwpxp2
 *  Added javadoc, formatted
 *
 *  Revision 1.1  2010/07/29 14:51:18  mwakg
 *  Added support for Cna. Merged code from Mike Seatris
 *
 */
