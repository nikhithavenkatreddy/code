package gov.ca.dmv.ease.tus.print.service;

/**
 * Description:  This interface provides the printing error constants/codes 
 * File: IPrintServiceConstants.java
 * Module:  gov.ca.dmv.ease.tus.print.service
 * Created: Aug 11, 2009 
 * @author MWJXA11  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPrintServiceConstants {
	/** The Document Printed is deleted. */
	String DOCUMENT_PRINTED_DELETED = "Document printed successfully and document deleted from repository";
	/** The Document Printed is not deleted. */
	String DOCUMENT_PRINTED_NOT_DELETED = "Document printed successfully, but document is not deleted from repository";
	/** The Document unavailable for printing error. */
	String ERROR_DOCUMENT_UNAVAILABLE = "Document Unavailable for printing";
	/** The Document printing failed and not deleted. */
	String ERROR_PRINT_FAILURE = "Document printing failed and so document is not deleted from repository";
	/** The invalid Document token. */
	String INVALID_DOCUMENT_TOKEN = "Invalid Document Token";
	/** The invalid Document type. */
	String INVALID_DOCUMENT_TYPE = "Invalid Document Type";
	/** The invalid Printer Details. */
	String INVALID_PRINTERS = "Invalid Primary and Alternate Printer Details";
	/** The invalid Token request. */
	String INVALID_TOKEN_REQUEST = "Invalid Print Request";
}
/**
 *  Modification History:
 *
 *  $Log: IPrintServiceConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/16 01:38:40  mwhxa2
 *  Added valid comments
 *
 *  Revision 1.1  2009/08/27 00:52:32  mwpxp2
 *  Replacement for PrintServiceConstants
 *
 */
