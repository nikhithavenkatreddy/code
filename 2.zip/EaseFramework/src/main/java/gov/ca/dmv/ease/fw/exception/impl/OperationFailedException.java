/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am the exception raised when operation fails related to UI
 * 
 * File: OperationFailedException.java
 * Module:  gov.ca.dmv.itm.ex
 * Created: Apr 3, 2009
 * @obsolete
 * @author mwakg
 * @version $Revision: 1.1 $
 * Last Changed: Apr 3, 2009 2:26:33 PM
 * Last Changed By: mwakg
 */
public class OperationFailedException extends EaseObsoletedException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2067756558709507205L;

	/**
	 * Instantiates a new operation failed exception.
	 */
	public OperationFailedException() {
		super();
	}

	/**
	 * Instantiates a new operation failed exception.
	 * 
	 * @param message the message
	 */
	public OperationFailedException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new operation failed exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public OperationFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new operation failed exception.
	 * 
	 * @param cause the cause
	 */
	public OperationFailedException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OperationFailedException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/03/23 20:32:24  mwpxp2
 *  Comment/inheritance mods
 *
 *  Revision 1.2  2010/03/22 23:31:52  mwpxp2
 *  Inherits from EaseException not ApplicationException
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/04 02:12:59  mwpxp2
 *  Added constructors
 *
 *  Revision 1.5  2009/10/03 20:20:50  mwpxp2
 *  Moved into fw.exception.impl; bulk cleanup
 *
 *  Revision 1.4  2009/08/27 20:50:10  mwsmg6
 *  corrected exception type
 *
 *  Revision 1.3  2009/07/27 17:11:02  mwpxm2
 *  Exception refactoring
 *
 *  Revision 1.3  2009/07/16 00:48:28  mwpxm2
 *  Updated by UI
 *
 *  Revision 1.1  2009/04/03 2:26:33 PM  mwakg
 *  Initial commit
 *
*/
