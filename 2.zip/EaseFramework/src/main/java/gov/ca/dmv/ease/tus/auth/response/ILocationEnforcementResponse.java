/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response;

import java.util.List;

/**
 * Description: I am an LocationEnforcementResponse interface
 * 
 * File: ILocationEnforcementResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response
 * Created: Nov 29, 2010 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: 
 * Last Changed By: 
 */
public interface ILocationEnforcementResponse extends IAuthAndAuthServiceResponse {
	/**
	 * Checks if is location enforced.
	 * 
	 * @return the LocationEnforced
	 */
	boolean isLocationAuthorized();
	
	/**
	 * Get Authorized Office Id List.
	 * @return Authorized Office Id list
	 */
	List <String> getAuthOfficeIdList();		
}
