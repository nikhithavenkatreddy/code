/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.service.impl;

import gov.ca.dmv.ease.fw.util.SpringUtils;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveAuthorizedTtcsRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeBusinessProcessingAllowedRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveAuthorizedTtcsResponse;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeBusinessProcessingAllowedResponse;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeTypeResponse;
import gov.ca.dmv.ease.tus.office.business.response.impl.RetrieveAuthorizedTtcsResponse;
import gov.ca.dmv.ease.tus.office.business.response.impl.RetrieveOfficeBusinessProcessingAllowedResponse;
import gov.ca.dmv.ease.tus.office.business.response.impl.RetrieveOfficeTypeResponse;
import gov.ca.dmv.ease.tus.office.business.service.IOfficeBusinessService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

/**
 * Description: I am an AuthAndAuthServiceImpl class to provide 
 * the implementation of both Authentication and Authorization services
 * I check authentication using JAAS, i provide Approval Authorization and i provide the authorization.
 * File: AuthAndAuthService.java
 * Module:  gov.ca.dmv.ease.service.tech.auth.impl
 * Created: Apr 16, 2009
 * @author MWJXA11
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/07/29 22:14:07 $
 */
public class OfficeBusinessService implements IOfficeBusinessService {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(OfficeBusinessService.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7038440652653814011L;
	/** The SINGLETON. */
	private static OfficeBusinessService SINGLETON;

	/**
	 * Gets the single instance of OfficeBusinessService.
	 *
	 * @return single instance of OfficeBusinessService
	 */
	public static OfficeBusinessService getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new OfficeBusinessService();
		}
		return SINGLETON;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.service.IOfficeBusinessService#execute(gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveAuthorizedTtcsRequest)
	 */
	public IRetrieveAuthorizedTtcsResponse execute(
			RetrieveAuthorizedTtcsRequest request) {
		List <String> authTtcList = getAuthTtcs("OID_" + request.getOfficeId());
		return new RetrieveAuthorizedTtcsResponse(authTtcList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.service.IOfficeBusinessService#execute(gov.ca.dmv.ease.tus.office.business.request.impl.OfficeBusinessProcessingAllowedRequest)
	 */
	public IRetrieveOfficeBusinessProcessingAllowedResponse execute(
			RetrieveOfficeBusinessProcessingAllowedRequest request) {
		List <String> processingAllowedList = getItemsFromContext("OID_PROCESSING_ALLOWED_"
				+ request.getOfficeId());
		return new RetrieveOfficeBusinessProcessingAllowedResponse(
				processingAllowedList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.office.business.service.IOfficeBusinessService#execute(gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest)
	 */
	public IRetrieveOfficeTypeResponse execute(RetrieveOfficeTypeRequest request) {
		List <String> officeTypeList = getItemsFromContext("OID_TYPE_"
				+ request.getOfficeId());
		return new RetrieveOfficeTypeResponse(officeTypeList);
	}

	/**
	 * Get auth
	 * 
	 * @param beanName
	 * @return retrieving items
	 */
	private List <String> getAuthTtcs(String officeId) {
		List <String> ttcList = new ArrayList <String>();
		if (officeId != null) {
			try { //trap invalid item name
				Map <String, String> beanMap = SpringUtils.getBean(officeId);
				if (!beanMap.isEmpty()) {
					for (String item : beanMap.values()) {
						ttcList.addAll(Arrays
								.asList(item.toString().split(",")));
					}
				}
			}
			catch (NoSuchBeanDefinitionException be) {
				LOGGER.warn("Bean name '" + officeId
						+ "' does not have a map in application context.");
			}
		}
		return ttcList;
	}

	/**
	 * Get Items From Context
	 * 
	 * @param beanName
	 * @return retrieving items
	 */
	private List <String> getItemsFromContext(String beanName) {
		List <String> itemList = new ArrayList <String>();
		if (beanName != null) {
			try { //trap invalid item name
				Map <String, String> beanMap = SpringUtils.getBean(beanName);
				if (!beanMap.isEmpty()) {
					for (String item : beanMap.values()) {
						itemList.add(item);
					}
				}
			}
			catch (NoSuchBeanDefinitionException be) {
				LOGGER.info("Bean name '" + beanName
						+ "' does not have a map in application context.");
			}
		}
		return itemList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: OfficeBusinessService.java,v $
 *  Revision 1.2  2013/07/29 22:14:07  mwsec2
 *  logging refinements
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2011/10/12 20:58:11  mwkkc
 *  Performance Merge
 *
 *  Revision 1.2.12.1  2011/09/28 01:52:57  mwpxp2
 *  Removed named spring bean access for  getInstance()
 *
 *  Revision 1.2  2011/01/12 21:05:16  mwxxw
 *  Add new API in OfficeBusinessService: IRetrieveAuthorizedTtcsResponse execute(RetrieveAuthorizedTtcsRequest request).
 *
 *  Revision 1.1  2011/01/12 01:26:54  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *  
 */
