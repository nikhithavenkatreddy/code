/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsInvalidResponseException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsUnrecognizedResponseException;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.support.converter.MessageConversionException;

/**
 * Description: I am the converter used for handling multiple payloads scenario.
 * File: MultipleJmsMessageConverter.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Sep 10, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleJmsMessageConverter extends AbstractJmsMessageConverter {
	/** The RESPONSE_HEADER_LEN constant. */
	protected static final int RESPONSE_HEADER_LEN = 150;
	protected static final int SEQ_FLAG_HEADER_POS = 149;
	/** Concatenated response */
	private StringBuilder finalResponse = new StringBuilder();
	/** Request for which this Message creator is used for **/
	private IEcsRequest request = null;
	/** List of responses for the request */
	private List <String> responses = new ArrayList <String>();

	/**
	 * Constructor - Instantiates a new converter.
	 * @param aRequest the request.
	 */
	public MultipleJmsMessageConverter(IEcsRequest aRequest) {
		request = aRequest;
	}

	/**
	 * This function calls the createResponseFromMultiplePayloads of the converter associated with the request
	 * It returns the IEcsResponse thus obtained or throws a MessageConversionException
	 * @return ecsResponse the response.
	 */
	@Override
	public IEcsResponse convert(Message aMessage) {
		IMessageConverter convertor = request.getMessageConverter();
		IEcsResponse ecsResponse = convertor
				.createResponseFromMultiplePayloads(responses);
		return ecsResponse;
	}

	/**
	 * Handle multiple payloads. Updates the provided string buffer with the string representation of the in-bound jms Message
	 * 
	 * @param aStringBuilder the ret value
	 * @param aMessage the inbound message object
	 */
	private void handleMultiplePayloads(StringBuilder aStringBuilder,
			Message aMessage) {
		//message already validated as not null
		TextMessage inboundTextMessage;
		BytesMessage inboundByteMessage;
		try {
			/** We are not currently getting any TextMessages from CAMV, so commenting out this section that handles TextMessages
			if (inboundMessageObject instanceof javax.jms.TextMessage) {
				inboundTextMessage = (javax.jms.TextMessage) inboundMessageObject;
				if (inboundTextMessage == null) {
					throw new EcsResponseIsNullException(
							"The resposne received from the CAMV is null. For LegalPresenceVerificationRequestEcs, the mock response will be set by converter");
				}
				else {
					textMessageToString(aStringBuilder, inboundTextMessage);
				}
				String hexCorrId = inboundTextMessage.getJMSCorrelationID();
				String corrId = Hex2ByteTransformer.transform(hexCorrId
						.substring(BEGIN));
				String messageId = inboundTextMessage.getJMSMessageID();
			}
			 **/
			if (aMessage instanceof BytesMessage) {
				inboundByteMessage = (BytesMessage) aMessage;
				bytesMessageToEbcidicString(aStringBuilder, inboundByteMessage);
			}
		}
		catch (Exception e) {
			throw new EcsMessageConversionException(e);
		}
	}

	/**
	 * Utility method used to check if any additional segments are to follow the current segment payload
	 * Segment flag in the in-bound payload indicates this information using codes O, B, M, F
	 * O - only segment
	 * B - beginning segment
	 * M - middle segment
	 * F - final segment
	 * 
	 * In-bound payload is in EBCIDIC format
	 * @param receivedMessageObject
	 * @return hasMore returns a boolean value.
	 */
	public boolean hasMorePayloads(Message receivedMessageObject) {
		StringBuilder aBuilder = new StringBuilder();
		handleMultiplePayloads(aBuilder, receivedMessageObject);
		String aPayload = aBuilder.toString();
		String tranMsgAscii = null;
		validatePayload(aPayload);
		//		if (tranMsg == null || tranMsg.equals("") || tranMsg.trim().equals("")
		//				|| tranMsg.length() < 150) {
		//			throw new EcsResponseIsNullException(
		//					"CAMV has responded with an empty response with no header, probably the system is down!");
		//		}
		try {
			tranMsgAscii = new String(aPayload.getBytes(), DEFAULT_ENCODING);
		}
		catch (UnsupportedEncodingException e) {
			throw new EcsUnrecognizedResponseException(
					"Expected EBCIDIC response from the CAMV", e);
		}
		String aHeader = tranMsgAscii.substring(RESPONSE_HEADER_LENGTH);
		String segFlag = aPayload.substring(SEQ_FLAG_HEADER_POS,
				RESPONSE_HEADER_LEN);
		boolean hasMore = true;
		if (segFlag.equals("O") | segFlag.equals("B")) {
			//responses.add(tranMsg.substring(RESPONSE_HEADER_LENGTH));
			responses.add(aHeader);
			finalResponse.append(aHeader);
		}
		if (segFlag.equals("M") | segFlag.equals("F")) {
			//responses.add(tranMsg.substring(RESPONSE_HEADER_LENGTH));
			responses.add(aHeader);
			finalResponse.append(aHeader);
		}
		if (segFlag.equals("O") | segFlag.equals("F")) {
			hasMore = false;
		}
		return hasMore;
	}

	/* (non-Javadoc)
	 * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object, javax.jms.Session)
	 */
	@Override
	public Message toMessage(Object arg0, Session arg1) throws JMSException,
			MessageConversionException {
		// We are using message creator in place of this!
		return null;
	}

	/**
	 * Validate payload.
	 * 
	 * @param aPayload the a payload
	 */
	@Override
	protected void validatePayload(String aPayload) {
		super.validatePayload(aPayload);
		if (aPayload.length() < RESPONSE_HEADER_LEN) {
			throw new EcsInvalidResponseException(
					" The message payload size is less than expected  "
							+ RESPONSE_HEADER_LEN + " in " + this);
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: MultipleJmsMessageConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2012/08/14 20:31:29  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.4  2011/06/10 21:42:24  mwyxg1
 *  clean up
 *
 *  Revision 1.3  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/05/26 01:56:16  mwpxp2
 *  Refactoring
 *
 *  Revision 1.1  2010/05/26 01:21:51  mwpxp2
 *  Moved in from improper package
 *
 *  Revision 1.4  2010/05/25 22:10:13  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.3  2010/05/25 21:56:43  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.2  2010/03/22 23:20:58  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/10/30 19:14:50  mwpzs3
 *  removing redundant ResponseIsNull condition
 *
 *  Revision 1.9  2009/10/30 19:13:36  mwpzs3
 *  null converter handled by EaseValidationException
 *
 *  Revision 1.8  2009/10/13 18:07:15  mwhxb3
 *  updated comments.
 *
 *  Revision 1.7  2009/10/07 18:18:48  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.6  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.5  2009/10/06 21:50:57  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.2  2009/10/06 20:41:53  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4.2.1  2009/10/06 20:28:41  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.4  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.3  2009/09/25 18:54:08  mwpzs3
 *  Update comments
 *
 *  Revision 1.2  2009/09/15 18:08:30  mwpzs3
 *  Update jms1.1 for ws3
 *
 *  Revision 1.1  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
 */
