/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import static gov.ca.dmv.ease.fw.constants.IEaseErrorCodeConstants.PRINTER_ERROR_CODE;
import gov.ca.dmv.ease.ecs.adaptor.IAdaptorConfiguration;
import gov.ca.dmv.ease.ecs.adaptor.IJmsAdaptor;
import gov.ca.dmv.ease.ecs.bridge.request.impl.BridgeRequest;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.convert.impl.DocumentGenerationJmsMessageConverter;
import gov.ca.dmv.ease.ecs.convert.impl.MultipleJmsMessageConverter;
import gov.ca.dmv.ease.ecs.convert.impl.SingleJmsMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsJmsException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageConversionException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsMessageCreationException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsNoResponseYetException;
import gov.ca.dmv.ease.ecs.exception.impl.EcsResponseIsNullException;
import gov.ca.dmv.ease.ecs.ics.request.impl.AbstractEcsImageCaptureSystemRequest;
import gov.ca.dmv.ease.ecs.persist.impl.Promise;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.AbstractEcsLogRequest;
import gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.AsynchronousEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest;
import gov.ca.dmv.ease.ecs.request.impl.SynchronousEcsRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.AuditLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.SystemManagementLogRequest;
import gov.ca.dmv.ease.ecs.request.log.impl.TechnicalLogRequest;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponse;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponsePromise;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.ecs.response.impl.SynchronousResponse;
import gov.ca.dmv.ease.ecs.util.impl.Hex2ByteTransformer;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.IResponsePromise;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.print.request.impl.GenerateDocumentRequest;

import java.util.Calendar;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Description: Implementation of IJmsAdaptor for ECS using Spring (some of) capabilities.
 * I use jms template for sending messages and for synch receiving.
 * I use message converter instances to create text messages from requests and 
 * to create response instances from inbound messages.
 * 
 *  //TODO - operating on correlation id is inconsistent across request types and misplaced - should be done in ecs request factory
 *  //TODO - creation of messages is inconsistent across request types - should be unified
 *  
 * File: SpringBasedJmsAdaptor.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Mar 19, 2009
 * @author mwpxp2
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2018/05/25 16:34:25 $
 * Last Changed By: $Author: mwskh1 $
 */
public class SpringBasedJmsAdaptor implements IJmsAdaptor {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(SpringBasedJmsAdaptor.class);
	
	/**
	 * Gets the single instance of SpringBasedJmsAdaptor.
	 *
	 * @return single instance of SpringBasedJmsAdaptor
	 */
	public static IJmsAdaptor getInstance() {
		return new SpringBasedJmsAdaptor();
	}
	
	/**
	 * Utility method used for padding zeroes to a number.
	 * 
	 * @param number the number
	 * @param stringLength the string length
	 * 
	 * @return the string
	 */
	public static String ljustify(int number, int stringLength) {
		String preJust = Integer.toString(number);
		for (int j = preJust.length(); j < stringLength; j++) {
			preJust = "0" + preJust;
		}
		return preJust;
	}
	
	//	/** The default container. */
	//	public static DefaultMessageListenerContainer DEFAULT_CONTAINER = null;
	/** Default office id if not set in user context. **/
	private final String defaultOfficeId = "O20";
	/** Default tech id if not set in user context. **/
	private final String defaultTechId = "T2";
	/** The incoming destination name. */
	private String incomingDestinationName;
	/** All the jms templates. Keys are defined in interface*/
	private Map <String, JmsTemplate> jmsTemplates;
	//	/**
	//	 * utility method to test is the container is running.
	//	 */
	//	public static void checkMessageListener() {
	//		int attempts = 0;
	//		while (DEFAULT_CONTAINER == null && attempts <= 15) {
	//			try {
	//				DEFAULT_CONTAINER = (DefaultMessageListenerContainer) ctx
	//						.getBean("jmsContainer");
	//				attempts++;
	//			}
	//			catch (Exception e) {
	//			}
	//		}
	//		if (DEFAULT_CONTAINER == null) {
	//			throw new SystemException("Unable to create JMS Container!");
	//		}
	//		else {
	//		}
	//		DEFAULT_CONTAINER.getActiveConsumerCount();
	//		DEFAULT_CONTAINER.getScheduledConsumerCount();
	//		DEFAULT_CONTAINER.getMessageSelector();
	//	}
	/** The message converter. */
	private MessageConverter messageConverter;
	/** The message creator. */
	private MessageCreator messageCreator;
	/** The outgoingDestinationName. */
	private String outgoingDestinationName;
	
	/**
	 * Instantiates a new ECS JMS adaptor.
	 */
	public SpringBasedJmsAdaptor() {
		super();
	}
	
	/**
	 * Convert and send.
	 * 
	 * @param anImageCaptureRequest 
	 * 
	 * @return the fire and forget receipt
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSend(
			AbstractEcsImageCaptureSystemRequest anImageCaptureRequest) {
		IMessageConverter converter = anImageCaptureRequest
				.getMessageConverter();
		if (converter != null) {
			try {
				//ICS request needs ICS header.
				jmsTemplates.get(DLID_L1_SEND_JMS_TEMPLATE).send(
						new IcsMessageCreator(anImageCaptureRequest));
			}
			catch (JmsException e) {
				LOGGER.error(
						"convertAndSend(AbstractEcsImageCaptureSystemRequest)",
						e);
				throw new EcsJmsException(e);
			}
		}
		return createReceiptFor(anImageCaptureRequest);
	}
	
	/**
	 * Convert and send.
	 * 
	 * @param request 
	 * 
	 * @return the fire and forget receipt
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSend(AbstractEcsLogRequest request) {
		String aPayload = request.getLogEntry();
		String aCorrelationId = request.getCorrelationId();
		LOGGER.info(" correlation id in convertAndSend of SystemManagementLogRequest request "
						+ aCorrelationId);
		sendMessage(aPayload,
				jmsTemplates.get(LOG_PERSISTENT_SEND_JMS_TEMPLATE),
				aCorrelationId);
		FireAndForgetReceipt returnFireAndForgetReceipt = createReceiptFor(
				request, aCorrelationId);
		return returnFireAndForgetReceipt;
	}
	
	/**
	 * Converts and sends AsynchronousEcsRequest.
	 * 
	 * @param asynchRequest the asynch request
	 * 
	 * @return the asynchronous response promise
	 */
	protected AsynchronousResponsePromise convertAndSend(
			AsynchronousEcsRequest asynchRequest) {
		IMessageConverter convertor = asynchRequest.getMessageConverter();
		String aCorrelationId = generateUniqueId(asynchRequest.getUserContext());
		if (convertor != null) {
			//getJmsTemplate().convertAndSend(getDestinationFor(synchRequest),synchRequest);
			jmsTemplates.get(ASYNC_PERSISTENT_SEND_JMS_TEMPLATE).send(
					new EcsMessageCreator(asynchRequest, aCorrelationId));
		}
		else {
			throw new EcsMessageCreationException(
					"No convertor available to convert the request");
		}
		LOGGER.info(" correlation id in convertAndSend of async request "
				+ aCorrelationId);
		AsynchronousResponsePromise asynchronousResponsePromise = new AsynchronousResponsePromise(
				asynchRequest, aCorrelationId);
		Promise promise = new Promise(asynchRequest.getRequestId(),
				aCorrelationId, asynchRequest.getAbsoluteExpirationTime());
		//		promise.setAbsoluteTimestamp(asynchRequest.getAbsoluteExpirationTime());
		//		promise.setCorrelationId(aCorrelationId);
		//		promise.setRequestId(asynchRequest.getRequestId());
		LOGGER.info(" Before calling persistence for storing promise for request id"
						+ promise.getRequestId());
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createSaveOrUpdateBusinessObjectRequest(
						asynchRequest.getUserContext(), promise);
		PersistenceServiceResponse aPersistenceResponse = aPersistenceRequest
				.execute();
		if (aPersistenceResponse.hasErrors()) {
			IErrorCollector errorCollector = aPersistenceResponse
					.getErrorCollector();
			LOGGER.info("Error has occurred while persisting promise to database "
							+ errorCollector.toString());
			return new AsynchronousResponsePromise(errorCollector);
		}
		else {
			return asynchronousResponsePromise;
		}
		//getPersistenceService().persist(asynchronousResponsePromise);
	}
	
	/**
	 * Convert and send.
	 * 
	 * @param aBridgeReq 
	 * 
	 * @return the fire and forget receipt
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSend(BridgeRequest aBridgeReq) {
		IMessageConverter convertor = aBridgeReq.getMessageConverter();
		String aCorrelationId = null;
		// DMVA listener expects office id as correlation id.
		if (EaseUtil.isNullOrBlank(aBridgeReq.getUserContext()
				.getHostOfficeId())) {
			aCorrelationId = aBridgeReq.getUserContext().getOfficeId();
		}
		else {
			aCorrelationId = aBridgeReq.getUserContext().getHostOfficeId();
		}
		if (aBridgeReq.getMessage() != null) {
			sendMessage(aBridgeReq.getMessage(),
					jmsTemplates.get(BRIDGE_DMVA_SEND_JMS_TEMPLATE),
					aCorrelationId);
		}
		else if (convertor != null) {// TODO: To make TUS Bridge code work, it is commented temporarily 
			try {
				jmsTemplates.get(BRIDGE_DMVA_SEND_JMS_TEMPLATE).send(
						new BridgeMessageCreator(aBridgeReq, aCorrelationId));
			}
			catch (JmsException e) {
				throw new EcsJmsException(e);
			}
			// TODO: To make TUS Bridge code work, below code is commented temporarily
		}
		else {
			throw new EcsMessageCreationException(
					"No convertor available to convert the request");
		}
		LOGGER.info(" correlation id in convertAndSend of BridgeRequest request: "
						+ aCorrelationId);
		FireAndForgetReceipt returnFireAndForgetReceipt = createReceiptFor(
				aBridgeReq, aCorrelationId);
		return returnFireAndForgetReceipt;
	}
	
	/**
	 * Converts and sends FireAndForgetEcsRequest.
	 * 
	 * @param request 
	 * 
	 * @return the fire and forget resceipt
	 */
	protected FireAndForgetReceipt convertAndSend(
			FireAndForgetEcsRequest request) {
		if ((request instanceof SystemManagementLogRequest)
				|| (request instanceof TechnicalLogRequest)
				|| (request instanceof AuditLogRequest)) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSend((AbstractEcsLogRequest) request);
			return returnFireAndForgetReceipt;
		}
		else if (request.isBridgeRequest()) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSend((BridgeRequest) request);
			return returnFireAndForgetReceipt;
		}
		else if (request.isIcsRequest()) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSend((AbstractEcsImageCaptureSystemRequest) request);
			return returnFireAndForgetReceipt;
		}
		else if (request.isDocScanRequest()) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSendDocScanRequest(request);
			return returnFireAndForgetReceipt;
		}
		else if (request.isAktsRequest()) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSendAktsRequest(request);
			return returnFireAndForgetReceipt;
		}
		else if (request.isVoterRegRequest()) {
			FireAndForgetReceipt returnFireAndForgetReceipt = convertAndSendVoterRegRequest(request);
			return returnFireAndForgetReceipt;
		}
		else {
			IMessageConverter convertor = request.getMessageConverter();
			String corrId = request.getRequestId();
			if (convertor != null) {
				try {
					jmsTemplates.get(ASYNC_PERSISTENT_SEND_JMS_TEMPLATE).send(
							new EcsMessageCreator(request, corrId));
					FireAndForgetReceipt returnFireAndForgetReceipt = createReceiptFor(request);
					return returnFireAndForgetReceipt;
				}
				catch (JmsException e) {
					throw new EcsJmsException(e);
				}
			}
			else {
				throw new EcsMessageCreationException(
						"No convertor available to convert the request");
			}
		}
	}
	
	/**
	 * Converts and sends SynchronousEcsRequest.
	 * 
	 * @param synchRequest the synch request
	 * 
	 * @return 
	 */
	protected String convertAndSend(SynchronousEcsRequest synchRequest) {
		IMessageConverter convertor = synchRequest.getMessageConverter();
		String aCorrelationId = generateUniqueId(synchRequest.getUserContext());
		JmsTemplate sendJmsTemplate = null;
		if (synchRequest instanceof GenerateDocumentRequest) {
			sendJmsTemplate = jmsTemplates
					.get(SYNC_DOC_GENERATION_PERSISTENT_SEND_JMS_TEMPLATE);
		}
		else {
			sendJmsTemplate = jmsTemplates
					.get(SYNC_NONPERSISTENT_SEND_JMS_TEMPLATE);
		}
		if (convertor != null) {
			sendToMq(synchRequest, sendJmsTemplate, aCorrelationId);
		}
		else {
			throw new EcsMessageCreationException(
					"No convertor available to convert the request");
		}
		return aCorrelationId;
	}
	
	/**
	 * @param request
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSendDocScanRequest(
			FireAndForgetEcsRequest request) {
		IMessageConverter converter = request.getMessageConverter();
		if (converter != null) {
			if (!jmsTemplates.containsKey(FODI_SEND_JMS_TEMPLATE)) {
				throw new EcsMessageConversionException("missing template: "
						+ FODI_SEND_JMS_TEMPLATE);
			}
			try {
				jmsTemplates.get(FODI_SEND_JMS_TEMPLATE).send(
						new DocScanMessageCreator(request));
			}
			catch (JmsException e) {
				LOGGER.error(e);
				throw new EcsJmsException(e);
			}
		}
		return createReceiptFor(request);
	}
	
	/**
	 * Send message to AKTS MQ or AKTE MQ depending on which AKT the office runs.
	 * @param request
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSendAktsRequest(
			FireAndForgetEcsRequest request) {
		IMessageConverter converter = request.getMessageConverter();
		IUserContext userContext = request.getUserContext();
		if (converter != null) {
			if (userContext.isAkteEnabled()) {
				if (!jmsTemplates.containsKey(AKTE_SEND_JMS_TEMPLATE)) {
					throw new EcsMessageConversionException("missing template: "
							+ AKTE_SEND_JMS_TEMPLATE);
				}
				try {
					jmsTemplates.get(AKTE_SEND_JMS_TEMPLATE).send(
							new AktsMessageCreator(request));
				}
				catch (JmsException e) {
					LOGGER.error(e);
					throw new EcsJmsException(e);
				}				
			}
		}
		return createReceiptFor(request);
	}

	/**
	 * Send message to VTR MQ.
	 * @param request
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected FireAndForgetReceipt convertAndSendVoterRegRequest(
			FireAndForgetEcsRequest request) {
		IMessageConverter converter = request.getMessageConverter();
		if (converter != null) {
			if (!jmsTemplates.containsKey(VTR_SEND_JMS_TEMPLATE)) {
				throw new EcsMessageConversionException("missing template: "
						+ VTR_SEND_JMS_TEMPLATE);
			}
			try {
				jmsTemplates.get(VTR_SEND_JMS_TEMPLATE).send(
						new VoterRegMessageCreator(request));
			}
			catch (JmsException e) {
				LOGGER.error(e);
				throw new EcsJmsException(e);
			}
		}
		return createReceiptFor(request);
	}

	
	/**
	 * Creates the promise for AsynchronousEcsRequest.
	 * 
	 * @param asynchRequest the asynch request
	 * 
	 * @return the asynchronous response promise
	 */
	private AsynchronousResponsePromise createPromiseFor(
			AsynchronousEcsRequest asynchRequest) {
		AsynchronousResponsePromise returnAsynchronousResponsePromise = new AsynchronousResponsePromise(
				asynchRequest);
		return returnAsynchronousResponsePromise;
	}
	
	/**
	 * Creates the receipt for FireAndForgetEcsRequest.
	 * 
	 * @param fireAndForgetRequest the fire and forget request
	 * 
	 * @return the fire and forget resceipt
	 */
	private FireAndForgetReceipt createReceiptFor(
			FireAndForgetEcsRequest fireAndForgetRequest) {
		return createReceiptFor(fireAndForgetRequest, null);
	}
	
	/**
	 * Creates the receipt for.
	 * 
	 * @param fireAndForgetRequest 
	 * @param aRequestId 
	 * 
	 * @return the fire and forget receipt
	 */
	private FireAndForgetReceipt createReceiptFor(
			FireAndForgetEcsRequest fireAndForgetRequest, String aRequestId) {
		return new FireAndForgetReceipt(fireAndForgetRequest, aRequestId);
	}
	
	/**
	 * Extracts the time stamp.
	 * @param calender
	 * @return a String
	 */
	private String extractTimestamp(Calendar calender) {
		return ljustify(calender.get(java.util.Calendar.YEAR), 4)
				+ ljustify(calender.get(java.util.Calendar.MONTH) + 1, 2)
				+ ljustify(calender.get(java.util.Calendar.DATE), 2)
				+ ljustify(calender.get(java.util.Calendar.HOUR), 2)
				+ ljustify(calender.get(java.util.Calendar.MINUTE), 2)
				+ ljustify(calender.get(java.util.Calendar.SECOND), 2)
				+ ljustify(calender.get(java.util.Calendar.MILLISECOND), 5);
	}
	
	/**
	 * Generates the unique id. 
	 * Uses the Office Id and Tech Id from the UserContext
	 * Also uses current timestamp 
	 * 
	 * @param userContext a UserContext
	 * 
	 * @return id an unique id
	 */
	public String generateUniqueId(IUserContext userContext) {
		String id = null, officeId = null, techId = null;
		StringBuilder sb = new StringBuilder();
		if (userContext == null || userContext.getOfficeId() == null
				|| userContext.getOfficeId().equalsIgnoreCase("")) {
			officeId = defaultOfficeId;
		}
		else {
			officeId = userContext.getOfficeId();
		}
		if (userContext == null || userContext.getTechId() == null
				|| userContext.getTechId().equalsIgnoreCase("")) {
			techId = defaultTechId;
		}
		else {
			techId = userContext.getTechId();
		}
		sb.append(officeId + techId);
		Calendar calender = Calendar.getInstance();
		sb.append(extractTimestamp(calender));
		id = sb.toString();
		return id;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.adaptor.IJmsAdaptor#getConfiguration()
	 */
	public IAdaptorConfiguration getConfiguration() {
		return null;
	}
	
	/**
	 * Gets the configuration for the request.
	 * 
	 * @param request the request
	 * 
	 * @return the configuration for
	 */
	private IAdaptorConfiguration getConfigurationFor(IEcsRequest request) {
		return null;
	}
	
	/**
	 * Gets the outgoingDestinationName for the request.
	 * 
	 * @param asynchRequest the asynch request
	 * 
	 * @return the outgoingDestinationName for
	 */
	private String getDestinationFor(IEcsRequest asynchRequest) {
		return null;
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	private javax.jms.Message getFromMq(JmsTemplate recvJmsTemplate,
			String newId) {
		LOGGER.debug("Start getFromMQ RecvRequestId : " + newId);
		javax.jms.Message receivedMessageObject = receiveMessage(
				recvJmsTemplate, newId);
		LOGGER.debug("End getFromMQ RecvRequestId : " + newId);
		return receivedMessageObject;
	}
	
	/**
	 * Gets the incoming destination name.
	 * 
	 * @return the incoming destination name
	 */
	public String getIncomingDestinationName() {
		return incomingDestinationName;
	}
	
	/**
	 * Gets the jms templates.
	 * 
	 * @return the jms templates
	 */
	public Map <String, JmsTemplate> getJmsTemplates() {
		return jmsTemplates;
	}
	
	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	public MessageConverter getMessageConverter() {
		return messageConverter;
	}
	
	/**
	 * Gets the message creator.
	 * 
	 * @return the message creator
	 */
	public MessageCreator getMessageCreator() {
		return messageCreator;
	}
	
	/**
	 * Gets the outgoingDestinationName.
	 * 
	 * @return the outgoingDestinationName
	 */
	public String getOutgoingDestinationName() {
		return outgoingDestinationName;
	}
	
	/**
	 * Gets the persistence service request factory.
	 *
	 * @return the persistence service request factory
	 */
	public PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return PersistenceServiceRequestFactory.getInstance();
	}
	
	/**
	 * Checks if  response for the promise is available.
	 * 
	 * @param promise the promise
	 * 
	 * @return true, if successful
	 */
	private boolean hasResponseFor(IResponsePromise promise) {
		return false;
	}
	
	/**
	 * Initializes for.the IAdaptorConfiguration
	 * 
	 * @param aConfig the a config
	 */
	private void initializeFor(IAdaptorConfiguration aConfig) {
		setIncomingDestinationName(aConfig.getIncomingDestinationName());
		//setJmsTemplate(aConfig.getJmsTemplate());
		setMessageConverter(aConfig.getMessageConverter());
		setMessageCreator(aConfig.getMessageCreator());
		setOutgoingDestinationName(aConfig.getOutgoingDestinationName());
	}
	
	/**
	 * Initializes the spring context and updates the templates used for communication
	 * 
	 * @param aRequest the a request
	 */
	private void initializeFor(IEcsRequest aRequest) {
		//initializeFor(getConfigurationFor(aRequest));
		if (aRequest instanceof SynchronousEcsRequest) {
			// For Document Generation Synchronous Requests
			if (aRequest instanceof GenerateDocumentRequest) {
				//				sendJmsTemplate = jmsTemplates
				//						.get(SYNC_DOC_GENERATION_PERSISTENT_SEND_JMS_TEMPLATE);
				//				recvJmsTemplate = jmsTemplates
				//						.get(SYNC_DOC_GENERATION_PERSISTENT_RECV_JMS_TEMPLATE);
				//FIXME - converters should be stateless
				setMessageConverter(new DocumentGenerationJmsMessageConverter(
						aRequest));
			}
			else {// For CAMV related Synchronous Requests
				//				sendJmsTemplate = jmsTemplates
				//						.get(SYNC_NONPERSISTENT_SEND_JMS_TEMPLATE);
				//				recvJmsTemplate = jmsTemplates
				//						.get(SYNC_NONPERSISTENT_RECV_JMS_TEMPLATE);
				if (((SynchronousEcsRequest) aRequest).isMultiSegment()) {
					//FIXME - converters should be stateless
					setMessageConverter(new MultipleJmsMessageConverter(
							aRequest));
				}
				else {
					//FIXME - converters should be stateless
					setMessageConverter(new SingleJmsMessageConverter(aRequest));
				}
			}
		}
		//		if (aRequest instanceof AsynchronousEcsRequest) {
		//			sendJmsTemplate = jmsTemplates
		//					.get(ASYNC_PERSISTENT_SEND_JMS_TEMPLATE);
		//			recvJmsTemplate = jmsTemplates
		//					.get(ASYNC_PERSISTENT_RECV_JMS_TEMPLATE);
		//			/**
		//			if (((SynchronousEcsRequest) aRequest).isMultiSegment()) {
		//				setMessageConverter(new MultipleJmsMessageConverter(aRequest));
		//			} else {
		//				setMessageConverter(new SingleJmsMessageConverter(aRequest));	
		//			}
		//			 **/
		//		}
		//		if (aRequest instanceof FireAndForgetEcsRequest) {
		//			if (((FireAndForgetEcsRequest) aRequest).isBridgeRequest()) {
		//				sendJmsTemplate = jmsTemplates
		//						.get(BRIDGE_DMVA_SEND_JMS_TEMPLATE);
		//			}
		//			else if (((FireAndForgetEcsRequest) aRequest).isIcsRequest()) {
		//				sendJmsTemplate = jmsTemplates.get(DLID_L1_SEND_JMS_TEMPLATE);
		//			}
		//			else {
		//				if ((aRequest instanceof TechnicalLogRequest)
		//						|| (aRequest instanceof SystemManagementLogRequest)
		//						|| (aRequest instanceof AuditLogRequest)) {
		//					sendJmsTemplate = jmsTemplates
		//							.get(FIRE_AND_FORGET_PERSISTENT_SEND_JMS_TEMPLATE);
		//				}
		//				else {
		//					sendJmsTemplate = jmsTemplates
		//							.get(ASYNC_PERSISTENT_SEND_JMS_TEMPLATE);
		//					//					sendJmsTemplate = jmsTemplates
		//					//					.get(SYNC_NONPERSISTENT_SEND_JMS_TEMPLATE);
		//					//					recvJmsTemplate = jmsTemplates
		//					//					.get(SYNC_NONPERSISTENT_RECV_JMS_TEMPLATE);
		//				}
		//			}
		//		}
	}
	
	/**
	 * Checks if response above size threshold.requiring response to be persisted.
	 * 
	 * @param response the response
	 * 
	 * @return true, if is above size threshold
	 */
	private boolean isAboveSizeThreshold(SynchronousResponse response) {
		return false;
	}
	
	/**
	 * Persists SynchronousResponseand return PersistedTokenResponse.
	 * //TODO - Add implementation if required.
	 * @param response the response
	 * 
	 * @return the synchronous response
	 */
	//	private PersistedTokenResponse persistAndReturnToken(
	//			SynchronousResponse response) {
	//		String anIdentifier = getPersistenceService().persist(response);
	//		PersistedTokenResponse returnPersistedTokenResponse = new PersistedTokenResponse(
	//				anIdentifier, response.getClass().getName(), response
	//						.getObjectCount());
	//		return returnPersistedTokenResponse;
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IRequestDispatcher#processAsynchronous(gov.ca.dmv.ease.ecs.impl.AsynchronousRequest)
	 */
	public AsynchronousResponsePromise processAsynchronous(
			IEcsRequest asynchRequest) {
		//initializeFor(asynchRequest);
		AsynchronousResponsePromise returnAsynchronousResponsePromise = convertAndSend((AsynchronousEcsRequest) asynchRequest);
		return returnAsynchronousResponsePromise;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IRequestDispatcher#processFireAndForget(gov.ca.dmv.ease.ecs.impl.FireAndForgetRequest)
	 */
	public FireAndForgetReceipt processFireAndForget(
			IEcsRequest fireAndForgetRequest) {
		//initializeFor(fireAndForgetRequest);
		return convertAndSend((FireAndForgetEcsRequest) fireAndForgetRequest);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IRequestDispatcher#processPromise(gov.ca.dmv.ease.ecs.response.IEcsResponsePromise)
	 */
	public AsynchronousResponse processPromise(IResponsePromise aPromise) {
		if (hasResponseFor(aPromise)) {
			AsynchronousResponse returnAsynchronousResponse = retrieveResponseFor(aPromise);
			return returnAsynchronousResponse;
		}
		else {
			throw new EcsNoResponseYetException(aPromise.toString());
		}
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.IRequestDispatcher#processSynchronous(gov.ca.dmv.ease.ecs.impl.SynchronousRequest)
	 */
	public SynchronousResponse processSynchronous(IEcsRequest synchRequest) {
		//initializeFor(synchRequest);
		SynchronousResponse returnSynchronousResponse = sendAndReceive((SynchronousEcsRequest) synchRequest);
		return returnSynchronousResponse;
	}
	
	/**
	 * This function is used to receive response from the receive queue for a particular request.
	 * This method uses the HEX version of the corelation Id.
	 * @param jmsTemplate the JMS template
	 * @param correlationId the correlation id to correlate the request and responses.
	 * @return receivedMessageObject a JMS message
	 */
	private javax.jms.Message receiveMessage(JmsTemplate jmsTemplate,
			String correlationId) {
		String hexCorr = Hex2ByteTransformer.asciiToHex(correlationId);
		String messageSelector = "JMSCorrelationID = 'ID:" + hexCorr + "'";
		//Object receivedMessageObject = jmsTemplate.receive();
		javax.jms.Message receivedMessageObject = jmsTemplate
				.receiveSelected(messageSelector);
		/**
		StringBuilder aBuffer = new StringBuilder();
		handlePayload(aBuffer, receivedMessageObject);
		 **/
		return receivedMessageObject;
		//return aBuffer.toString();
	}
	
	/**
	 * Receives synchronous response and convert.
	 * Depending on whether the request will evoke a multi-segment response the appropriate converters are used
	 * For multi-segment resopnses the queues are polled until all segments are received.
	 * 
	 * @return mock the synchronous response
	 */
	private SynchronousResponse receiveSynchronousResponseAndConvert(
			SynchronousEcsRequest request, String newId) {
		//SynchronousResponse aResponse = (SynchronousResponse) getJmsTemplate().receiveAndConvert();
		SynchronousResponse mock = null;
		JmsTemplate recvJmsTemplate = null;
		MessageConverter messageConverter = null;
		if (request instanceof GenerateDocumentRequest) {
			recvJmsTemplate = jmsTemplates
					.get(SYNC_DOC_GENERATION_PERSISTENT_RECV_JMS_TEMPLATE);
			messageConverter = new DocumentGenerationJmsMessageConverter(
					request);
		}
		else {
			recvJmsTemplate = jmsTemplates
					.get(SYNC_NONPERSISTENT_RECV_JMS_TEMPLATE);
			if (request.isMultiSegment()) {
				messageConverter = new MultipleJmsMessageConverter(request);
			}
			else {
				messageConverter = new SingleJmsMessageConverter(request);
			}
		}
		if (!request.isMultiSegment()) {
			javax.jms.Message receivedMessageObject = getFromMq(
					recvJmsTemplate, newId);
			if (receivedMessageObject == null) {
				if (request instanceof GenerateDocumentRequest) {
					throw new EcsResponseIsNullException(PRINTER_ERROR_CODE);
					/*throw new EcsResponseIsNullException(
							"Print Server Unavailable. Contact System Support.");*/
				}
				else {
					throw new EcsResponseIsNullException(
							"No inboundMessageObject received from the CAMV.");
				}
			}
			else {
				try {
					mock = (SynchronousResponse) messageConverter
							.fromMessage(receivedMessageObject);
				}
				catch (EcsResponseIsNullException e) {
					LOGGER.error("ECS request type "
							+ request.getClass().getSimpleName()
							+ " receieved bad response: " + e.getMessage()
							+ "\nUser context: "
							+ request.getUserContext().logSummary());
					throw e; // the caller classes are programmed to handle this exception. Here we just log.
				}
				catch (MessageConversionException e) {
					throw new EcsMessageConversionException(e);
				}
				catch (JMSException e) {
					throw new EcsJmsException(e);
				}
			}
		}
		else {
			MultipleJmsMessageConverter mJms = (MultipleJmsMessageConverter) messageConverter;
			javax.jms.Message receivedMessageObject = null;
			while (true) {
				receivedMessageObject = getFromMq(recvJmsTemplate, newId);
				boolean more = mJms.hasMorePayloads(receivedMessageObject);
				if (!more) {
					break;
				}
			}
			try {
				mock = (SynchronousResponse) mJms
						.fromMessage(receivedMessageObject);
			}
			catch (MessageConversionException e) {
				throw new EcsMessageConversionException(e);
			}
		}
		/**
		if (isAboveSizeThreshold(aResponse)) {
			SynchronousResponse returnSynchronousResponse = persistAndReturnToken(aResponse);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("receiveSynchronousResponseAndConvert() - end");
			}
			return returnSynchronousResponse;
		}
		else {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("receiveSynchronousResponseAndConvert() - end");
			}
			return aResponse;
		}
		 **/
		return mock;
	}
	
	/**
	 * Retrieves response for a promise.
	 * Using the promise, the Persistence Service is called to obtain the response
	 * //TODO - Add implementation if required.
	 * @param promise the promise
	 * 
	 * @return returnAsynchronousResponse the Asynchronous response
	 */
	private AsynchronousResponse retrieveResponseFor(IResponsePromise promise) {
		//		AsynchronousResponse returnAsynchronousResponse ; 
		//			(AsynchronousResponse) getPersistenceService()
		//				.retrieveResponse(promise.getSentRequestId(),
		//						promise.getResponseClassName());
		return null;
	}
	
	/**
	 * Sends synchRequest and receives synch response.
	 * 
	 * @param synchRequest the synch request
	 * 
	 * @return the synchronous response
	 */
	protected SynchronousResponse sendAndReceive(
			SynchronousEcsRequest synchRequest) {
		String correlationId = convertAndSend(synchRequest);
		SynchronousResponse returnSynchronousResponse = receiveSynchronousResponseAndConvert(
				synchRequest, correlationId);
		return returnSynchronousResponse;
	}
	
	/**
	 * Sends message.
	 * 
	 * @param message the message
	 * @param jmsTemplate the jms template
	 * @param correlationID the correlation id
	 */
	private void sendMessage(String message, JmsTemplate jmsTemplate,
			String correlationId) {
		final String tmpMessage = message;
		final String corrId = correlationId;
		//myMessageCreator mMC = new myMessageCreator(correlator,message);
		MessageCreator creator = new MessageCreator() {
			public Message createMessage(Session session) {
				TextMessage message = null;
				try {
					message = session.createTextMessage(tmpMessage);
					message.setJMSCorrelationID(corrId);
				}
				catch (JMSException e) {
					LOGGER.error("createMessage(Session)", e);
					throw new EcsJmsException(e);
				}
				return message;
			}
		};
		jmsTemplate.send(creator);
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	private void sendToMq(AbstractEcsRequest ecsRequest,
			JmsTemplate sendJmsTemplate, String corrId) {
		LOGGER.debug("Start sendToMQ SendRequestId : " + corrId);
		try {
			sendJmsTemplate.send(new EcsMessageCreator(ecsRequest, corrId));
		}
		catch (JmsException e) {
			LOGGER.error("JMSException in  SpringBasedJmsAdaptor.sendToMQ: ", e);
			throw new EcsJmsException(e);
		}
		LOGGER.debug("End sendToMQ SendRequestId : " + corrId);
	}
	
	/**
	 * Sets the incoming destination name.
	 * 
	 * @param incomingDestinationName the new incoming destination name
	 */
	public void setIncomingDestinationName(String aName) {
		incomingDestinationName = aName;
	}
	
	/**
	 * Sets the jms templates.
	 * 
	 * @param jmsTemplates the jms templates
	 */
	public void setJmsTemplates(Map <String, JmsTemplate> templates) {
		jmsTemplates = templates;
	}
	
	/**
	 * Sets the message converter.
	 * 
	 * @param aConverter the a converter
	 */
	public void setMessageConverter(MessageConverter aConverter) {
		messageConverter = aConverter;
	}
	
	/**
	 * Sets the message creator.
	 * 
	 * @param aCreator the a creator
	 */
	public void setMessageCreator(MessageCreator aCreator) {
		messageCreator = aCreator;
	}
	
	/**
	 * Sets the outgoing destination name.
	 * 
	 * @param anOutgoingName the new outgoing destination name
	 */
	public void setOutgoingDestinationName(String anOutgoingName) {
		outgoingDestinationName = anOutgoingName;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SpringBasedJmsAdaptor.java,v $
 *  Revision 1.8  2018/05/25 16:34:25  mwskh1
 *  merging eDL44_2_8_1_9 (eDL44 project) and EASE_2_8_1_9_branch (Real ID, M&O and AKTE defects) to head
 *
 *  Revision 1.7.20.1  2018/05/11 17:21:29  mwwwc
 *  Merge defect 468 fix into BRANCH_EASE_2_8_3_1 Branch.
 *
 *  Revision 1.7.14.1  2018/03/06 21:48:06  mwwwc
 *  Defect 468: Remove reference to AKT Stockton Plus MQ and message relate.
 *
 *  Revision 1.7  2017/08/07 16:56:15  mwwwc
 *  Merge AKTE changes from branch to Head.
 *
 *  Revision 1.6.6.1  2017/05/24 17:01:18  mwwwc
 *  Added back AKTE changes
 *
 *  Revision 1.6  2016/02/18 20:17:49  mwskh1
 *  Motor Voter - merge to head
 *
 *  
 *  Revision 1.4.2.2  2016/02/09 22:01:16  mwskh1
 *  Motor Voter - synch to EASE_2_5_3_1_AKTE_BKOUT (EASE_2_5_3_1 was backed out at management's request to roll back AKTE)
 *
 *  Revision 1.4.2.1  2016/01/21 19:45:42  mwskh1
 *  Motor Voter - Add new subprocess and ECS message with queue settings
 *  
 *  Revision 1.5  2016/01/21 23:42:56  mwwwc
 *  Remove AKTE changes from HEAD.
 *  
 *  Revision 1.2.8.1  2015/10/20 19:11:37  mwwwc
 *  AKTE Change: Allow message sent to different MQ to support AKTE Phases approach.
 *
 *  Revision 1.2  2013/09/03 18:05:15  mwsec2
 *  added catch block to log bad response messages
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.61  2012/07/16 19:58:03  mwhys
 *  Updated receiveSynchronousResponseAndConvert() to register error EASE009 in the event of print error.
 *
 *  Revision 1.60  2012/04/24 00:21:23  mwxxw
 *  Set the aCorrelationId to hostOfficeId if the login office is a satellite office for bridge message only.
 *
 *  Revision 1.59  2012/04/17 22:26:37  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.58.2.1  2012/02/15 19:35:07  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 *  Revision 1.58  2012/01/30 23:53:42  mwsec2
 *  FODI integration code merged to HEAD
 *
 *  Revision 1.56  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.55.8.2  2011/09/26 23:45:37  mwhys
 *  Use instance of PersistenceServiceRequestFactory.
 *
 *  Revision 1.55.8.1  2011/09/26 05:23:58  mwpxp2
 *  Added static getInstance/0
 *
 *  Revision 1.55  2011/06/10 20:26:50  mwxxw
 *  Add @Transactional for bridge and image request.
 *
 *  Revision 1.54  2011/06/09 17:32:40  mwyxg1
 *  clean up
 *
 *  Revision 1.53  2011/06/09 17:00:07  mwyxg1
 *  clean up
 *
 *  Revision 1.52  2011/06/03 23:41:41  mwxxw
 *  Add @Transactional annotation to convertAndSend(AbstractEcsLogRequest request).
 *
 *  Revision 1.51  2011/06/02 20:51:02  mwxxw
 *  Add @Transactional back for sendToMQ() and getFromMQ() function for performance tuning.
 *
 *  Revision 1.50  2011/03/23 23:47:33  mwhxb3
 *  Removed conditional logger statements.
 *
 *  Revision 1.49  2011/03/23 23:42:36  mwhxb3
 *  Removed conditional logger statements.
 *
 *  Revision 1.48  2011/03/23 21:49:39  mwhxb3
 *  No method call in logger statement.
 *
 *  Revision 1.47  2011/03/23 17:18:50  mwtjc1
 *  error message for null Doc Gen response is updated as per Subbarao's request
 *
 *  Revision 1.46  2011/01/16 00:36:47  mwpxr4
 *  Removed class level jmsTemplates.
 *
 *  Revision 1.45  2011/01/11 02:29:58  mwpxr4
 *  Removed dependency on initializeFor method for setting message converter templates. It is a probable fix for untransformed messages shown in UI.
 *
 *  Revision 1.44  2011/01/08 01:13:05  mwpxr4
 *  Removed dependency on initializeFor method for setting send and receive templates. It is a probable fix for bad messages going to bridge and l1 queues.
 *
 *  Revision 1.43  2011/01/07 22:11:49  mwpxr4
 *  InitializeFor made synchronized to verify wrong messages going to Bridge/L1 queues.
 *
 *  Revision 1.42  2010/12/24 23:32:50  mwpxr4
 *  Commented out transactional annotation, to verify incorrect msgs going to bridge.
 *
 *  Revision 1.41  2010/12/12 17:48:37  mwpxp2
 *  Added logging of correlationId; added todos on the topic; assigned correlation id to the response where feasible
 *
 *  Revision 1.40  2010/12/12 05:54:54  mwpxp2
 *  Refactored convertAndSend/F&F into multiple methods
 *
 *  Revision 1.39  2010/12/11 23:05:46  mwpxr4
 *  Fixed Bridge related JMS call, this is  to make all Bridge TCodes to send messages to DMVA.
 *
 *  Revision 1.37  2010/12/02 18:22:27  mwpxr4
 *  Added transactional annotations for jms send and receive methods for ecs synchronous calls.
 *
 *  Revision 1.36  2010/11/05 20:53:06  mwpxr4
 *  Updated code for fire and forget requests which should go to CAMV. Early the requests are wrongly sent to Journal Q.
 *
 *  Revision 1.35  2010/10/14 21:11:39  mwpxr4
 *  Updates related to L1 Server JMS configuration.
 *
 *  Revision 1.34  2010/09/24 00:20:40  mwpxr4
 *  corrected exception handling
 *
 *  Revision 1.33  2010/09/22 20:42:16  mwpxr4
 *  Updated import.
 *
 *  Revision 1.32  2010/09/22 20:30:41  mwpxr4
 *  Organized imports.
 *
 *  Revision 1.31  2010/09/22 18:19:34  mwpxp2
 *  Adjusted imports for bridge-related request class move
 *
 *  Revision 1.30  2010/09/21 18:47:58  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.29.4.2  2010/09/18 23:03:45  mwpxr4
 *  Removed concrete classes usage from interface. Typecasted concrete classes in the private methods.
 *
 *  Revision 1.29.4.1  2010/09/14 16:08:05  mwpxr4
 *  Removed Simple Persistence dependency for Asynchronous type of ECS communication.
 *
 *  Revision 1.29  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.28  2010/09/03 22:50:07  mwpxr4
 *  Added loggers.
 *
 *  Revision 1.27  2010/08/31 17:56:55  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.26  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.25  2010/07/31 00:13:12  mwkkc
 *  Auditing and Logging Work
 *
 *  Revision 1.24  2010/07/08 21:17:51  mwtjc1
 *  code is  FireAndForgetReceipt convertAndSend(FireAndForgetEcsRequest request) is temporarily commented to make TUS Bridge code work
 *
 *  Revision 1.23  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.22  2010/07/06 16:48:22  mwhxb3
 *  Removed commented code for the mocked LPV response.
 *
 *  Revision 1.21  2010/07/02 18:50:26  mwtjc1
 *  for bridge requests correlation id is set to office id
 *
 *  Revision 1.20  2010/06/28 20:51:49  mwtjc1
 *  FireAndForgetReceipt convertAndSend method for bridge request changed to use BridgeMessageCreator
 *
 *  Revision 1.19  2010/05/26 18:44:54  mwhxb3
 *  Send receivedMessageObject instead of null.
 *
 *  Revision 1.18  2010/05/26 01:55:42  mwpxp2
 *  Exception refactoring
 *
 *  Revision 1.17  2010/05/26 01:21:29  mwpxp2
 *  Adjusted imports for class package moves
 *
 *  Revision 1.16  2010/05/25 22:10:12  mwpxp2
 *  Adjusted imports for exception class renames
 *
 *  Revision 1.15  2010/05/25 21:57:50  mwpxp2
 *  Fixed instance var naming and unnecessary "t~his-es"
 *
 *  Revision 1.14  2010/05/18 21:03:42  mwtjc1
 *  initializeFor method is updated to support document generation
 *
 *  Revision 1.13  2010/05/18 01:01:03  mwhxb3
 *  Changed template names.
 *
 *  Revision 1.12  2010/05/17 22:00:51  mwhxb3
 *  Added DOC generation related send/receive templates.
 *
 *  Revision 1.11  2010/04/22 19:13:01  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2010/04/12 02:34:39  mwpzs3
 *  update for bridge code communication
 *
 *  Revision 1.9  2010/04/06 01:29:19  mwpzs3
 *  move to non-persistent
 *
 *  Revision 1.8  2010/04/01 23:26:29  mwakg
 *  Removed initialization of jmsTemplates variable
 *
 *  Revision 1.7  2010/04/01 18:33:42  mwhxb3
 *  convertAndSend(fireAndForgetRequest) is updated and can be used for ECS requests that has no actual response but returns the fire and forget receipt.
 *
 *  Revision 1.6  2010/04/01 18:16:47  mwtjc1
 *  getJmsTemplates and setJmsTemplates methods are added
 *
 *  Revision 1.5  2010/04/01 17:03:26  mwakg
 *  Moved life cycle management for ECS related classes into spring
 *
 *  Revision 1.4  2010/03/30 02:23:40  mwvkm
 *  application context spring configuration file is fixed in order to read from the application projects.
 *
 *  Revision 1.3  2010/03/22 23:22:21  mwpxp2
 *  Replaced refs to ease "systemexception" by ease exceptions, e.g. EcsJmsException
 *
 *  Revision 1.2  2009/12/15 18:12:43  mwpzs3
 *  Commenting out JMS Listener for Court and DCS Inquiry purposes
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.31  2009/10/29 16:18:05  mwhxb3
 *  Removed - returning the mock response for LegalPresenceVerificationRequestEcs
 *
 *  Revision 1.30  2009/10/14 18:54:54  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.29  2009/10/13 18:18:40  mwhxb3
 *  updated comments.
 *
 *  Revision 1.28  2009/10/08 20:26:41  mwpzs3
 *  cpd refactor
 *
 *  Revision 1.27  2009/10/07 14:40:01  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.26  2009/10/07 02:55:15  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.25  2009/10/06 21:50:56  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.24.2.2  2009/10/06 20:41:53  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.24.2.1  2009/10/06 20:28:42  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.24  2009/10/03 21:23:39  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.23  2009/09/30 20:47:57  mwrrv3
 *  Added Try/Catch block for convertAndSend method for SynchronousEcsRequest.
 *
 *  Revision 1.22  2009/09/25 19:04:57  mwpzs3
 *  Update comments
 *
 *  Revision 1.21  2009/09/21 17:47:16  mwpxp2
 *  Renamed statics to be readable
 *
 *  Revision 1.20  2009/09/18 00:23:38  mwsxd10
 *  Logging related queues and Connection Factories are added.
 *
 *  Revision 1.19  2009/09/15 18:52:39  mwhxb3
 *  Returning the mock response for LegalPresenceVerificationRequestEcs.
 *
 *  Revision 1.18  2009/09/15 18:22:42  mwpzs3
 *  Update jms1.1 for jms container initialize
 *
 *  Revision 1.17  2009/09/15 18:08:11  mwpzs3
 *  Update jms1.1 for ASYNC
 *
 *  Revision 1.16  2009/09/15 02:23:48  mwpzs3
 *  Update jms1.1 for ASYNC
 *
 *  Revision 1.15  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
 *  Revision 1.14  2009/09/10 00:35:10  mwpzs3
 *  Move to JMS 1.2
 *
 *  Revision 1.13  2009/09/08 02:00:56  mwpzs3
 *  Move to JMS 1.1
 *
 *  Revision 1.12  2009/08/27 05:54:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.11  2009/08/27 02:33:58  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.10  2009/08/26 01:58:42  mwpxp2
 *  Replaced IEcsResponsePromise with IResponsePromise
 *
 *  Revision 1.9  2009/08/18 23:48:20  mwpxp2
 *  Added more logging; bulk cleanup
 *
 *  Revision 1.8  2009/08/10 22:39:28  mwpxp2
 *  Added logging, missing javadoc; removed explicit log4j initialization
 *
 *  Revision 1.7  2009/08/04 22:00:04  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2009/07/30 01:26:05  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.5  2009/07/28 22:34:16  mwpxp2
 *  Fixed processRequest for asynch to return AsynchronousResponsePromise
 *
 *  Revision 1.4  2009/07/27 18:47:56  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.3  2009/07/16 01:49:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/07/16 01:04:46  mwpxp2
 *  Bulk cleanup, including imports
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
 */
