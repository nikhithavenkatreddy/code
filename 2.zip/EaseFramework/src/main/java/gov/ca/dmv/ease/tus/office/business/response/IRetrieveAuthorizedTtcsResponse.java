/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response;

import java.util.List;

/**
 * Description: I am an IRetrieveAuthorizedTtcsResponse interface
 * 
 * File: IRetrieveAuthorizedTtcsResponse.java
 * Module:  gov.ca.dmv.ease.tus.office.business.response
 * Created: Jan 12, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveAuthorizedTtcsResponse extends
		IOfficeBusinessServiceResponse {
	/**
	 * Get TTCs for this office.
	 * @return
	 */
	List<String> getAuthTtcs();
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
