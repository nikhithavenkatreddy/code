/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleDeleteBusinessObjectResponse;

import java.util.Collection;

/**
 * Description: I represent the request to delete business object from the 
 * persistent store
 * 
 * File: MultipleDeleteBusinessObjectRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request
 * Created: Sept 15, 2010
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MultipleDeleteBusinessObjectRequest extends
		MultiObjectPersistenceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8849502671953308172L;

	/** The persistence service. */
	//private IInventoryPersistenceService inventoryPersistenceService;
	/**
	 * @param userContext
	 * @param objectList
	 */
	public MultipleDeleteBusinessObjectRequest(IUserContext userContext,
			Collection <IBusinessObject> objectList) {
		super(userContext, objectList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public MultipleDeleteBusinessObjectResponse execute() {
		return getPersistenceService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MultipleDeleteBusinessObjectRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/15 18:04:02  mwkfh
 *  added MultipleDeleteBusinessObjects
 *
 */
