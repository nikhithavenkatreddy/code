/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.app.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.sql.Blob;

/**
 * Description: The purpose of this class is to serialize the session data in order to maintain the state of the application.
 * File: Session.java
 * Module:  gov.ca.dmv.ease.bo.app.impl
 * Created: Apr 26, 2010 
 * @author MWVKM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Session extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4892179410711085213L;
	/** The data stream. */
	private String dataStream;
	/** The office id. */
	private String officeId;
	/** The Session context. */
	private Blob sessionData;
	/** The session id. */
	private String sessionId;
	/** The tech id. */
	private String techId;
	/** The racf id. */
	private String racfId;
	/** The user name. */
	private String userName;
	
	/**
	 * Instantiates a new session.
	 */
	public Session() {
		super();
	}
	
	/**
	 * Instantiates a new session - build constructor.
	 * 
	 * @param userContext the data to copy
	 */
	public Session(IUserContext userContext) {
		super();
		setOfficeId(userContext.getOfficeId());
		setTechId(userContext.getTechId());
		setRacfId(userContext.getRacfId());
		setUserName(userContext.getUserName());
		setSessionId(" ");
	}
	
	/**
	 * Instantiates a new session - build constructor.
	 * 
	 * @param userContext the data to copy
	 * @param sessionId
	 */
	public Session(IUserContext userContext, String sessionId) {
		super();
		setOfficeId(userContext.getOfficeId());
		setTechId(userContext.getTechId());
		setRacfId(userContext.getRacfId());
		setUserName(userContext.getUserName());
		setSessionId(sessionId);
	}
	
	/**
	 * Instantiates a new session - build constructor.
	 * 
	 * @param anOfficeId the office id
	 * @param aTechId the tech id
	 * @param aUserName the user name
	 */
	public Session(String anOfficeId, String aTechId, String aUserName) {
		super();
		setOfficeId(anOfficeId);
		setTechId(aTechId);
		setUserName(aUserName);
	}
	
	/**
	 * Instantiates a new session from another session.
	 * 
	 * @param dataToCopy
	 */
	public Session(Session dataToCopy) {
		super();
		if (dataToCopy == null) {
			throw new EaseValidationException("OBJECT TO COPY CANNOT BE NULL");
		}
		copy(dataToCopy);
	}
	
	/**
	 * This method is to copy Session Object.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(Session dataToCopy) {
		super.copy(dataToCopy);
		setDataStream(dataToCopy.getDataStream());
		setOfficeId(dataToCopy.getOfficeId());
		setRacfId(dataToCopy.getRacfId());
		setSessionData(dataToCopy.getSessionData());
		setSessionId(dataToCopy.getSessionId());
		setTechId(dataToCopy.getTechId());
		setUserName(dataToCopy.getUserName());
	}
	
	/**
	 * Simple getter for the dataStream.
	 * 
	 * @return the dataStream
	 */
	public String getDataStream() {
		return dataStream;
	}
	
	/**
	 * Simple getter for the officeId.
	 * 
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}
	
	/**
	 * Simple getter for the racfId.
	 * 
	 * @return the racfId
	 */
	public String getRacfId() {
		return racfId;
	}
	
	/**
	 * Simple getter for the sessionData.
	 * 
	 * @return the sessionData
	 */
	public Blob getSessionData() {
		return sessionData;
	}
	
	/**
	 * Simple getter for the sessionId.
	 * 
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}
	
	/**
	 * Simple getter for the techId.
	 * 
	 * @return the techId
	 */
	public String getTechId() {
		return techId;
	}
	
	/**
	 * Simple getter for the userName.
	 * 
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * checks for valid data in key related fields.
	 * 
	 * @return true if has data in key fields
	 */
	public boolean hasKeyFields() {
		return !EaseUtil.isNullOrBlank(getOfficeId())
				&& !EaseUtil.isNullOrBlank(getTechId())
				&& !EaseUtil.isNullOrBlank(getUserName());
	}
	
	/**
	 * Checks for data in the session id.
	 * 
	 * @return true if has data in the session id
	 */
	public boolean hasSessionId() {
		return !EaseUtil.isNullOrBlank(getSessionId());
	}
	
	/**
	 * Simple setter for the dataStream.
	 * 
	 * @param dataStream the dataStream to set
	 */
	public void setDataStream(String dataStream) {
		this.dataStream = dataStream;
	}
	
	/**
	 * Simple setter for the officeId.
	 * 
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
	
	/**
	 * Simple setter for the racfId.
	 * 
	 * @param racfId the racfId to set
	 */
	public void setRacfId(String racfId) {
		this.racfId = racfId;
	}
	
	/**
	 * Simple setter for the sessionData.
	 * 
	 * @param sessionData the sessionData to set
	 */
	public void setSessionData(Blob sessionData) {
		this.sessionData = sessionData;
	}
	
	/**
	 * Simple setter for the sessionId.
	 * 
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	/**
	 * Simple setter for the techId.
	 * 
	 * @param techId the techId to set
	 */
	public void setTechId(String techId) {
		this.techId = techId;
	}
	
	/**
	 * Simple setter for the userName.
	 * 
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.IValidatable#validateUsing(gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public void validateUsing(IErrorCollector aCollector) {
		if (!hasId() && !hasKeyFields()) {
			aCollector.register(new EaseValidationException(
					"Required data missing from " + this));
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: Session.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2012/05/08 00:25:38  mwhys
 *  Updated constructor and validateUsing() for Session Management.
 *
 *  Revision 1.12  2012/01/11 18:59:49  mwkfh
 *  updated copy
 *
 *  Revision 1.11  2012/01/11 18:49:18  mwkfh
 *  added copy constructor
 *
 *  Revision 1.10  2012/01/10 18:09:31  mwkfh
 *  removed updated of create and modified
 *
 *  Revision 1.9  2012/01/06 19:37:18  mwkfh
 *  added "has" and "validate" methods
 *
 *  Revision 1.8  2010/10/26 22:20:05  mwkfh
 *  added racfId and updated userName
 *
 *  Revision 1.7  2010/09/30 17:48:41  mwkfh
 *  added constructor for just user context
 *
 *  Revision 1.6  2010/09/01 18:58:23  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/08/11 23:53:17  mwkfh
 *  added constructors
 *
 *  Revision 1.4  2010/07/16 15:29:57  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.3  2010/06/24 17:39:31  mwvkm
 *  Java Docs are updated
 *
 *  Revision 1.2  2010/05/04 00:54:37  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/04/29 23:52:04  mwvkm
 *  Initial check-in for session restore in session management
 *
 */
