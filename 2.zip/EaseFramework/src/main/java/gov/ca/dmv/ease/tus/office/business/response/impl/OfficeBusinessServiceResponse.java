/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.response.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;
import gov.ca.dmv.ease.tus.office.business.response.IOfficeBusinessServiceResponse;

public abstract class OfficeBusinessServiceResponse extends AbstractResponse
		implements IOfficeBusinessServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4248155268875993513L;

	/**
	 * Throws ITM exception if errors are found
	 */
	protected void throwExceptionIfErrorFound() {
		if (hasErrors()) {
			throw new EaseException("Office Business Response has errors");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: OfficeBusinessServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/01/12 01:26:53  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *
 */
