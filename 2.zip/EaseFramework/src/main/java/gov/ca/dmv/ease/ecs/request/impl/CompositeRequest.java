/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.request.ICompositeRequest;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.ICompositeResponse;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.impl.CompositeResponse;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: This is a Composite request class.
 * File: CompositeRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request.impl
 * Created: 16/05/2009
 * @author pxp
<<<<<<< CompositeRequest.java
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
=======
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
>>>>>>> 1.5.4.2
 */
public class CompositeRequest extends AbstractEcsRequest implements
		ICompositeRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4584984131696526509L;
	/** The children. */
	private List <IEcsRequest> children = new ArrayList <IEcsRequest>();

	/**
	 * Instantiates a new composite request.
	 */
	public CompositeRequest() {
		super();
	}

	/**
	 * Instantiates a new composite request.
	 * 
	 * @param requestList the request list
	 */
	public CompositeRequest(List <IEcsRequest> requestList) {
		super();
		addAll(requestList);
	}

	/**
	 * Instantiates a new composite request.
	 * 
	 * @param anId the an id
	 */
	public CompositeRequest(String anId) {
		super(anId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.ICompositeRequest#add(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	public void add(IEcsRequest request) {
		getChildren().add(request);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.ICompositeRequest#addAll(java.util.List)
	 */
	public void addAll(List <IEcsRequest> requestList) {
		getChildren().addAll(requestList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public IEcsResponse execute() throws EcsServiceException {
		ICompositeResponse res = (CompositeResponse) getEcsService()
				.processRequest(this);
		return res;
	}

	/**
	 * Gets the children.
	 * 
	 * @return children the children
	 */
	protected List <IEcsRequest> getChildren() {
		/** Children can never be null
		if (children == null) {
			setChildren(new ArrayList <IEcsRequest>());
		}
		 **/
		return children;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.ICompositeRequest#getChildrenSize()
	 */
	public int getChildrenSize() {
		/**Children can never be null**/
		int returnint = children.size();
		return returnint;
	}

	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	@Override
	public IMessageConverter getMessageConverter() {
		throw new EaseValidationException("use this call for children");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.ICompositeRequest#getRequests()
	 */
	public List <IEcsRequest> getRequests() {
		List <IEcsRequest> returnList = getChildren();
		return returnList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#hasChildren()
	 */
	@Override
	public boolean hasChildren() {
		/**Children can never be null**/
		return !children.isEmpty();
	}

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if is empty
	 */
	public boolean isEmpty() {
		return !hasChildren();
	}

	/**
	 * Sets the children.
	 * 
	 * @param aList the new children
	 */
	public void setChildren(List <IEcsRequest> aList) {
		children = aList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CompositeRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2011/01/17 01:45:47  mwpxp2
 *  Fixed add/1
 *
 *  Revision 1.8  2010/09/22 18:03:54  mwpxp2
 *  Simplified hasChildren, isEmpty
 *
 *  Revision 1.7  2010/09/21 18:51:49  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< CompositeRequest.java
 *  Revision 1.6  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
=======
 *  Revision 1.5.4.2  2010/09/18 23:08:09  mwpxr4
 *  Typecasted concrete classes
 *
 *  Revision 1.5.4.1  2010/09/14 22:13:09  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.6  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
>>>>>>> 1.5.4.2
 *  Revision 1.5  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.4  2010/08/31 17:57:40  mwhys
 *  Marked Service(s) as transient.
 *
 *  Revision 1.3  2010/07/21 18:17:15  mwpxp2
 *  Made ecsService private
 *
 *  Revision 1.2  2010/03/22 23:27:11  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.19  2009/10/14 20:47:08  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.18  2009/10/13 21:04:44  mwhxb3
 *  updated comments.
 *
 *  Revision 1.17  2009/10/07 23:25:34  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.16  2009/10/07 19:55:00  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.15  2009/10/07 19:28:55  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.14  2009/10/07 18:19:18  mwpzs3
 *  Unit tests update
 *
 *  Revision 1.13  2009/10/07 14:31:27  mwcsj3
 *  Cleaned todo Auto-generated method stub
 *
 *  Revision 1.12  2009/10/07 03:33:43  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.11  2009/10/07 02:56:48  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.10  2009/10/06 21:53:02  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9.2.2  2009/10/06 20:41:47  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9.2.1  2009/10/06 20:28:38  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.9  2009/10/03 21:23:35  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.8  2009/08/27 02:33:53  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.7  2009/08/22 20:26:24  mwpxp2
 *  Added getMessageConverter/0 implementation
 *
 *  Revision 1.6  2009/08/10 23:05:46  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.5  2009/07/27 18:28:59  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.4  2009/07/16 02:17:52  mwpxp2
 *  Removed empty getUserContext method
 *
 *  Revision 1.3  2009/07/14 23:58:47  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:09:39  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.2  2009-05-18 18:39:03  ppalacz
 *  Added 1-arg constructor on request id
 *
 *  Revision 1.1  2009-05-17 05:22:18  ppalacz
 *  Initial
 *
 */
