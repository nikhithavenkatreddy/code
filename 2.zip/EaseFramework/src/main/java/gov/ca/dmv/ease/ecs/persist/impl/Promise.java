package gov.ca.dmv.ease.ecs.persist.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: I am implementation of Promise - a synch response for asynch requests
 * File: Promise.java
 * Module:  gov.ca.dmv.ease.ecs.persist.impl
 * Created: 2009 
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class Promise extends BusinessObject {
	/** The constant serial version id. */
	private static final long serialVersionUID = -4955725437724525521L;
	/** The absolute timestamp. */
	private Long absoluteExpirationTimestamp;
	/** The correlation id. */
	private String correlationId;
	/** The id. */
	private Long id;
	/** The request id. */
	private String requestId;

	/**
	 * Instantiates a new promise.
	 */
	public Promise() {
		super();
	}

	/**
	 * Instantiates a new promise.
	 * 
	 * @param aCorrelationId 
	 */
	public Promise(String aCorrelationId) {
		super();
		setCorrelationId(aCorrelationId);
	}

	/**
	 * Instantiates a new promise.
	 * 
	 * @param aRequestId 
	 * @param aCorrelationId 
	 * @param anExpirationStamp 
	 */
	public Promise(String aRequestId, String aCorrelationId,
			Long anExpirationStamp) {
		super();
		setCorrelationId(aCorrelationId);
		setRequestId(aRequestId);
		setAbsoluteTimestamp(anExpirationStamp);
	}

	/**
	 * Gets the absolute timestamp.
	 * 
	 * @return 
	 */
	public Long getAbsoluteTimestamp() {
		return absoluteExpirationTimestamp;
	}

	/**
	 * Gets the correlation id.
	 * 
	 * @return 
	 */
	public String getCorrelationId() {
		return this.correlationId;
	}

	/**
	 * Gets the Id.
	 * 
	 * @return 
	 */
	@Override
	public Long getId() {
		return id;
	}

	/**
	 * Gets the request id.
	 * 
	 * @return 
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * Sets the absolute Timestamp.
	 * 
	 * @param absoluteTimestamp 
	 */
	protected void setAbsoluteTimestamp(Long absoluteTimestamp) {
		this.absoluteExpirationTimestamp = absoluteTimestamp;
	}

	/**
	 * Sets the correlation id.
	 * 
	 * @param correlationId 
	 */
	protected void setCorrelationId(String anId) {
		correlationId = anId;
	}

	/**
	 * Sets the id.
	 * 
	 * @param id 
	 */
	@Override
	public void setId(Long anId) {
		id = anId;
	}

	/**
	 * Sets the request id.
	 * 
	 * @param requestId 
	 */
	protected void setRequestId(String anId) {
		requestId = anId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: Promise.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/12/12 17:43:17  mwpxp2
 *  Added constructors; made most setters non-public; added class header and footer; cleaned up
 *
 */
