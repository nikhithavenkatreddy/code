/**
 * 
 */
package gov.ca.dmv.ease.fw;

import gov.ca.dmv.ease.bo.IBusinessObject;

/**
 * Description: Interface for objects requiring access to their components by (property) name
 * File: IWithPropertyAccess.java
 * Module:  gov.ca.dmv.ease.fw
 * Created: 12/07/2009 
 * @author pxp  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithPropertyAccess {
	/**
	 * Gets the business object named.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the business object named
	 */
	IBusinessObject getBusinessObjectNamed(String aPropertyName);

	/**
	 * Gets the integer value named.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the integer value named
	 */
	Integer getIntegerValueNamed(String aPropertyName);

	/**
	 * Gets the object named.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the object named
	 */
	Object getObjectNamed(String aPropertyName);

	/**
	 * Gets the string value named.
	 * 
	 * @param aPropertyName the a property name
	 * 
	 * @return the string value named
	 */
	String getStringValueNamed(String aPropertyName);
}
/**
 *  Modification History:
 * 
 *  $Log: IWithPropertyAccess.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/23 17:17:39  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.2  2009/10/03 20:15:09  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/07/14 23:44:24  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 16:05:43  ppalacz
 *  Initial
 *
*/
