/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code.impl;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: I am implementation of ICodeSet
 * File: CodeSet.java
 * Module: gov.ca.dmv.ease.bo.code.impl
 * Created: Aug 4, 2009
 * @author MWBXP5
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CodeSet extends BusinessObject implements ICodeSet {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3388980578634346664L;
	/** The code set elements. */
	private List <ICodeSetElement> codeSetElements;
	/** The code set name. */
	private String codeSetName;
	/** The a code set impl. */
	/** The effective date. */
	private Date effectiveDate;
	/** The end date. */
	private Date endDate;

	/**
	 * Instantiates a new code set.
	 */
	public CodeSet() {
		super();
	}

	/**
	 * Instantiates a new code set.
	 * 
	 * @param aName the a name
	 */
	public CodeSet(String aName) {
		super();
		setCodeSetName(aName);
		effectiveDate = new Date();
	}

	/**
	 * Instantiates a new code set impl.
	 * 
	 * @param aCodesetName the a codeset name
	 * @param aCodeSetElemenstCollection the a code set elemenst collection
	 * @param anEffectiveDate the an effective date
	 * @param anEndDate the an end date
	 */
	public CodeSet(String aCodesetName,
			List <ICodeSetElement> aCodeSetElemenstCollection,
			Date anEffectiveDate, Date anEndDate) {
		this(aCodesetName);
		codeSetElements = aCodeSetElemenstCollection;
		effectiveDate = anEffectiveDate;
		endDate = anEndDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#add(gov.ca.dmv.ease.bo.code.ICodeSetElement)
	 */
	public ICodeSet add(ICodeSetElement anElem) {
		if (codeSetElements == null) {
			setCodeSetElements(new ArrayList <ICodeSetElement>());
		}
		codeSetElements.add(anElem);
		return this;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CodeSet other = (CodeSet) obj;
		if (codeSetElements == null) {
			if (other.codeSetElements != null) {
				return false;
			}
		}
		else if (!codeSetElements.equals(other.codeSetElements)) {
			return false;
		}
		if (codeSetName == null) {
			if (other.codeSetName != null) {
				return false;
			}
		}
		else if (!codeSetName.equals(other.codeSetName)) {
			return false;
		}
		if (effectiveDate == null) {
			if (other.effectiveDate != null) {
				return false;
			}
		}
		else if (!effectiveDate.equals(other.effectiveDate)) {
			return false;
		}
		if (endDate == null) {
			if (other.endDate != null) {
				return false;
			}
		}
		else if (!endDate.equals(other.endDate)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	* @see gov.ca.dmv.ease.bo.code.ICodeSet#getElements()
	*/
	public List <ICodeSetElement> getCodeSetElements() {
		return codeSetElements;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getCodeSetName()
	 */
	public String getCodeSetName() {
		return codeSetName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#getEffectiveDate()
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getElementNamed(java.lang.String)
	 */
	public ICodeSetElement getElementNamed(String aName) {
		for (ICodeSetElement elem : getCodeSetElements()) {
			if (elem.getName().equals(aName)) {
				return elem;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getElementsEffectiveNow()
	 */
	public List <ICodeSetElement> getElementsEffectiveNow() {
		return getElementsEffectiveOn(new Date());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getElementsEffectiveOn(java.util.Date)
	 */
	public List <ICodeSetElement> getElementsEffectiveOn(Date aDate) {
		List <ICodeSetElement> elems = new ArrayList <ICodeSetElement>();
		for (ICodeSetElement elem : getCodeSetElements()) {
			if (elem.isEffectiveOn(aDate)) {
				elems.add(elem);
			}
		}
		return elems;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getElementWithCode(java.lang.String)
	 */
	public ICodeSetElement getElementWithCode(String aCodeValue) {
		for (ICodeSetElement elem : getCodeSetElements()) {
			if ((aCodeValue != null) && aCodeValue.equals(elem.getCode())) { //GD: defect UAT 234
				return elem;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#getEndDate()
	 */
	public Date getEndDate() {
		return endDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasElement(gov.ca.dmv.ease.bo.code.ICodeSetElement)
	 */
	public boolean hasElement(ICodeSetElement anElem) {
		return codeSetElements.contains(anElem);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasElementNamed(java.lang.String)
	 */
	public boolean hasElementNamed(String codeSetElementName) {
		for (ICodeSetElement element : getCodeSetElements()) {
			if (element.getName().equals(codeSetElementName)) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasElementWithCodeEqualTo(java.lang.String)
	 */
	public boolean hasElementWithCodeEqualTo(String aCode) {
		if (isEmpty()) {
			return false;
		}
		for (ICodeSetElement elem : codeSetElements) {
			if (elem.hasCodeEqualTo(aCode)) {
				//note: ignorecase equality
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasElementWithCodeEqualToAnyOf(java.lang.String[])
	 */
	public boolean hasElementWithCodeEqualToAnyOf(String... codeArr) {
		if (isEmpty()) {
			return false;
		}
		for (ICodeSetElement elem : codeSetElements) {
			if (elem.hasCodeEqualToAnyOf(codeArr)) {
				//note: ignorecase equality
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((codeSetElements == null) ? 0 : codeSetElements.hashCode());
		result = prime * result
				+ ((codeSetName == null) ? 0 : codeSetName.hashCode());
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasNoElementWithCodeEqualTo(java.lang.String)
	 */
	public boolean hasNoElementWithCodeEqualTo(String aCode) {
		if (isEmpty()) {
			return false;
		}
		for (ICodeSetElement elem : codeSetElements) {
			if (elem.hasCodeEqualTo(aCode)) {
				//note: ignorecase equality
				return false;
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#hasNoElementWithCodeEqualToAnyOf(java.lang.String[])
	 */
	public boolean hasNoElementWithCodeEqualToAnyOf(String... codeArr) {
		if (isEmpty()) {
			return false;
		}
		for (ICodeSetElement elem : codeSetElements) {
			if (elem.hasCodeEqualToAnyOf(codeArr)) {
				//note: ignorecase equality
				return false;
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#isEffectiveNow()
	 */
	public boolean isEffectiveNow() {
		return isEffectiveOn(new Date());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#isEffectiveOn(java.util.Date)
	 */
	public boolean isEffectiveOn(Date aDate) {
		return getEffectiveDate().before(aDate) && getEndDate().after(aDate);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#isEmpty()
	 */
	public boolean isEmpty() {
		return codeSetElements == null || codeSetElements.isEmpty();
	}

	/**
	 * Sets the code set elements.
	 * 
	 * @param aList the a list
	 */
	protected void setCodeSetElements(List <ICodeSetElement> aList) {
		codeSetElements = aList;
	}

	/**
	 * Sets the code set name.
	 * 
	 * @param aName the a name
	 */
	public void setCodeSetName(String aName) {
		codeSetName = aName;
	}

	/**
	 * Constructs a <code>String</code> with all attributes
	 * in name = value format.
	 * 
	 * @return a <code>String</code> representation
	 * of this object.
	 */
	@Override
	public String toString() {
		StringBuilder aBuff = new StringBuilder(
				64 + (codeSetElements.size() * 32));
		aBuff.append(getClass().getSimpleName()).append(" [ ");
		aBuff.append("codeSetName: ").append(codeSetName).append(COMMA);
		aBuff.append(" effectiveDate: ").append(effectiveDate).append(COMMA);
		aBuff.append(" endDate: ").append(endDate).append(COMMA);
		aBuff.append(" elements: ");
		if (isEmpty()) {
			aBuff.append("[ empty ]");
		}
		else {
			aBuff.append("[");
			for (ICodeSetElement elem : codeSetElements) {
				aBuff.append(CRTAB).append(elem);
			}
			aBuff.append("]");
		}
		return aBuff.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: CodeSet.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2011/01/29 00:00:34  mwgxd3
 *  defect 234
 *
 *  Revision 1.9  2010/10/19 17:43:22  mwyxg1
 *  update getElementWithCode
 *
 *  Revision 1.8  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.7  2010/05/27 00:48:03  mwpxp2
 *  Fixed toString/0 to use string buffer rather than multiple concatenations
 *
 *  Revision 1.6  2010/05/27 00:27:41  mwpxp2
 *  Unit tested ok  additions in 1.5
 *
 *  Revision 1.5  2010/05/26 00:34:20  mwpxp2
 *  Added a handful of has~ utility test methods
 *
 *  Revision 1.4  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.3  2010/02/11 17:45:17  mwpxp2
 *  Fixed javadoc; bulk cleanup; added todo for toString
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.18  2009/10/12 18:45:13  mwtjc1
 *  local variable TAB of toString() is changed to tab to resolve PMD reported issue '[SEVERITY 2] Local Variable name 'TAB' should start with a lowercase character.'
 *
 *  Revision 1.17  2009/10/11 16:41:19  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.16  2009/10/07 01:18:09  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.15  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.14  2009/09/13 20:45:36  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.13.2.1  2009/09/13 01:34:28  mwakg
 *  Reading data from Database instead of XML for CodeSetService
 *
 *  Revision 1.13  2009/08/28 01:24:51  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.12  2009/08/27 05:39:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.11  2009/08/22 23:19:32  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.10  2009/08/20 00:20:34  mwrrv3
 *  Uncommented the annotation for code set elements.
 *
 *  Revision 1.9  2009/08/19 23:39:11  mwrrv3
 *  Initial version of DCS inquiry.
 *
 *  Revision 1.8  2009/08/19 18:41:31  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.7  2009/08/11 00:03:04  mwrsk
 *  Added ManyToMany mapping to codeSetElements
 *
 *  Revision 1.6  2009/08/10 21:39:18  mwpxp2
 *  Adding logging
 *
 *  Revision 1.5  2009/08/10 18:32:31  mwpxp2
 *  Added getElementWithCode/1; included eager annotation on codeSetElements
 *
 *  Revision 1.3  2009/08/06 23:10:27  mwpxp2
 *  Added constructor on name, toString, lazy initialization of internal storage
 *
 *  Revision 1.2  2009/08/06 21:53:23  mwrsk
 *  Added Hibernate Annotations
 *
 *  Revision 1.1  2009/08/06 00:59:58  mwpxp2
 *  Renamed to remove the Impl part
 *
 *  Revision 1.2  2009/08/06 00:48:05  mwpxp2
 *  Added implementation of three methods - getElement~; fixed class decorations
 *
 *  Revision 1.1  2009/08/05 00:04:46  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 */
