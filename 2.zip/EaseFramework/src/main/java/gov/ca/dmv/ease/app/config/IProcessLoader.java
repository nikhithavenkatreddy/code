/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.config;

/**
 * Description: ProcessLoader interface
 * File: IProcessLoader.java
 * Module:  gov.ca.dmv.ease.app.config.impl
 * Created: Feb 23, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IProcessLoader {
	/** The BUSINES s_ process. */
	String BUSINESS_PROCESS = "businessprocess";
	/** The BUSINES s_ proces s_ bea n_ name. */
	String BUSINESS_PROCESS_BEAN_NAME = "BusinessProcess";
	/** The BUSINES s_ proces s_ contex t_ class. */
	String BUSINESS_PROCESS_CONTEXT_CLASS = "contextclass";
	/** The BUSINES s_ proces s_ name. */
	String BUSINESS_PROCESS_NAME = "name";
	/** The BUSINES s_ proces s_ securit y_ roles. */
	String BUSINESS_PROCESS_SECURITY_ROLES = "securityroles";
	/** The BUSINES s_ proces s_ star t_ activity. */
	String BUSINESS_PROCESS_START_ACTIVITY = "startactivity";
	/** The DEFAUL t_ transitio n_ key. */
	String DEFAULT_TRANSITION_KEY = "DEFAULT_TRANSITION_KEY";
	/** The evaluation criteria rule */
	String EVALUATION_CRITERIA = "evaluation_criteria";
	/** The post condition rules */
	String POST_CONDITION_RULES = "post_condition_rules";
	/** The Pre condition rules */
	String PRE_CONDITION_RULES = "pre_condition_rules";
	/** The security role */
	String SECURITY_ROLE = "securityrole";
	/** The SEPERATOR. */
	String SEPERATOR = ",";
	/** The STEP. */
	String STEP = "step";
	/** The STE p_ name. */
	String STEP_NAME = "name";
	/** The transaction type */
	String TRANSACTION_TYPE = "transactiontype";
	/** The transaction type bean name */
	String TRANSACTION_TYPE_BEAN_NAME = "transactionType";
	/** the save point attribute */
	String SAVE_POINT = "save_point";
	/** The SYNC_POINT. */
	String SYNC_POINT = "sync_point";
	/** The TRANSITION. */
	String TRANSITION = "transition";
	/** The TRANSITIO n_ on. */
	String TRANSITION_ON = "on";
	/** The TRANSITIO n_ to. */
	String TRANSITION_TO = "to";
	/** The TCODE */
	String TCODE = "tcode";
}
/**
 * Modification History:
 * 
 * $Log: IProcessLoader.java,v $
 * Revision 1.1  2012/10/01 02:57:34  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.5  2012/05/08 00:12:30  mwhys
 * Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 * Revision 1.4.34.1  2012/02/21 21:15:02  mwsec2
 * save point support added
 *
 * Revision 1.4  2010/09/03 16:58:44  mwsec2
 * transactiontype and securityrole constants added
 *
 * Revision 1.3  2010/09/01 18:56:22  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2010/07/23 14:49:47  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.1.8.1  2010/06/27 01:44:59  mwakg
 * Updated process loader to read the sync_point
 *
 * Revision 1.1  2010/05/04 00:49:48  mwpxp2
 * Moved in from .impl package
 *
 * Revision 1.6  2010/04/29 17:55:01  mwcsj3
 * Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 * Revision 1.5  2010/04/22 19:09:31  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.4  2010/03/23 20:30:18  mwpxp2
 * Exception imports adjusted per exception tree mods
 *
 * Revision 1.3  2010/03/22 23:19:59  mwpxp2
 * Javadoc/cleanup
 *
 * Revision 1.2  2010/03/11 22:19:29  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.4  2010/02/26 23:13:01  mwyxg1
 * process multi process transition, update documentation
 *
 * Revision 1.1.2.3  2010/02/26 18:54:48  mwcsj3
 * Added constants
 *
 * Revision 1.1.2.2  2010/02/26 18:37:53  mwcsj3
 * Changed constants
 *
 * Revision 1.1.2.1  2010/02/26 18:20:59  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * 
 */
