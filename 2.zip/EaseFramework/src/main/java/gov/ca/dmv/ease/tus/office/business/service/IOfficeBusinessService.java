/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.service;

import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveAuthorizedTtcsRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeBusinessProcessingAllowedRequest;
import gov.ca.dmv.ease.tus.office.business.request.impl.RetrieveOfficeTypeRequest;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveAuthorizedTtcsResponse;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeBusinessProcessingAllowedResponse;
import gov.ca.dmv.ease.tus.office.business.response.IRetrieveOfficeTypeResponse;

import java.io.Serializable;

/**
 * Description: I am an Interface class to define the office business services 
 * File: IOfficeBusinessService.java
 * Module:  gov.ca.dmv.ease.tus.office.business.service
 * Created: Jan 10, 2011
 * 
 * @author MWXXW
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeBusinessService extends Serializable {
	/**
	 * Get a list of office business processing allowed for request office id.  
	 * 
	 * @param RetrieveOfficeBusinessProcessingAllowedRequest
	 * 
	 * @return IOfficeBusinessProcessingAllowedResponse
	 */
	IRetrieveOfficeBusinessProcessingAllowedResponse execute(RetrieveOfficeBusinessProcessingAllowedRequest request);
	
	/**
	 * Get a list of office type for request office id.  
	 * 
	 * @param RetrieveOfficeTypeRequest
	 * 
	 * @return IRetrieveOfficeTypeResponse
	 */
	IRetrieveOfficeTypeResponse execute(RetrieveOfficeTypeRequest request);
	
	/**
	 * Get a list of office type for request office id.  
	 * 
	 * @param RetrieveOfficeTypeRequest
	 * 
	 * @return IRetrieveOfficeTypeResponse
	 */
	IRetrieveAuthorizedTtcsResponse execute(RetrieveAuthorizedTtcsRequest request);
		
}
/**
 *  Modification History:
 * 
 *  $Log: IOfficeBusinessService.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/01/12 21:05:17  mwxxw
 *  Add new API in OfficeBusinessService: IRetrieveAuthorizedTtcsResponse execute(RetrieveAuthorizedTtcsRequest request).
 *
 *  Revision 1.1  2011/01/12 01:26:56  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *  
 */
