/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.impl;

import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.ecs.bridge.request.impl.ProductionStatisticRequestEcs;
import gov.ca.dmv.ease.ecs.convert.bridge.impl.AbstractBridgeConverter;
import gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The purpose of this class is to define the behavior of constructing the
 * message for production statistics message.
 * //FIXME - this class does not belong to ecs.convert.impl package - move to a more appriopriate one
 * File: ProdStatisticsConverter.java
 * Module:  gov.ca.dmv.ease.ecs.convert.impl
 * Created: July 17, 2010
 * 
 * @author MWSZM12
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProductionStatisticsConverter extends AbstractBridgeConverter {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter#createMessage(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	private static final Log LOGGER = LogFactory
			.getLog(ProductionStatisticsConverter.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3586075666278982116L;
	/** The SINGLETON. */
	private static ProductionStatisticsConverter SINGLETON;

	/**
	 * Gets the single instance of ProductionStatisticsConverter.
	 *
	 * @return single instance of ProductionStatisticsConverter
	 */
	public static ProductionStatisticsConverter getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new ProductionStatisticsConverter();
		}
		return SINGLETON;
	}

	/**
	 * Instantiates a new production statistics converter.
	 */
	protected ProductionStatisticsConverter() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter#createMessage(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	@Override
	public String createMessage(IEcsRequest aRequest) {
		LOGGER.debug("createMessage(IEcsRequest aRequest=" + aRequest
				+ ") - start");
		validateNotNull(aRequest, "request");
		if (aRequest instanceof ProductionStatisticRequestEcs) {
			ProductionStatisticRequestEcs aProdRequest = (ProductionStatisticRequestEcs) aRequest;
			String returnString = createMessageFrom(aProdRequest);
			LOGGER.debug("createMessage(IEcsRequest=" + aRequest
					+ ") - end - return value=" + returnString);
			return returnString;
		}
		else {
			throw new EaseValidationException(
					"Request of class ProductionStatisticRequestEcs expected; got "
							+ aRequest);
		}
	}

	/**
	 * The purpose of this method is to create the message for the production
	 * statistics in order to send it across bridge service.
	 * 
	 * @param completionCode the completion code
	 * @param currentUserContext 
	 * @param cashierSequenceNbr 
	 * @param dlOrIdIndicator 
	 * @param ttc 
	 * 
	 * @return the string
	 */
	private String createMessage(IUserContext currentUserContext,
			String completionCode, String cashierSequenceNbr,
			String dlOrIdIndicator, String ttc) {
		validateNotNull(currentUserContext, "user context in request");
		List <Object> objectList = new ArrayList <Object>(0);
		/* TCODE */
		objectList.add(filler("BPRS", 4));
		/* DL/ID Indicator */
		objectList.add(filler(dlOrIdIndicator, 1));
		/* System Date */
		objectList.add(filler(convertDateToString(CurrentDateProvider
				.getInstance().getCurrentDate(),
				EcsConverterHelper.FORMATTER_MM_DD_YYCC), 8));
		/* System Time Started */
		String startedTime = convertDateToString(currentUserContext
				.getSystemStartDateForTtc(),
				EcsConverterHelper.FORMATTER_HH_MM_SS);
		objectList.add(filler(startedTime, 6));
		/* System Time Ended */
		String endTime = convertDateToString(CurrentDateProvider.getInstance()
				.getCurrentDate(), EcsConverterHelper.FORMATTER_HH_MM_SS);
		objectList.add(filler(endTime, 6));
		/* Keyed By */
		objectList.add(filler(currentUserContext.getTechId(), 2));
		/* Work Date */
		objectList.add(filler(convertDateToString(currentUserContext
				.getWorkDate(), EcsConverterHelper.FORMATTER_MM_DD_YYCC), 8));
		/* Cashiering Sequence # */
		objectList.add(filler(cashierSequenceNbr, 4));
		/* OFFICE ID */
		objectList.add(filler(currentUserContext.getOfficeId(), 3));
		/* TYPE TRANSACTION CODE */
		objectList.add(filler(ttc, 3));
		/* Mode Indicator */
		String modeIndicator = "";
		if (currentUserContext.getOperationalMode() != null) {
			modeIndicator = currentUserContext.getOperationalMode().getCode();
			StringBuilder stringBuilder = new StringBuilder("P");
			stringBuilder.append(modeIndicator);
			stringBuilder.append("DS");
			modeIndicator = stringBuilder.toString();
		}
		objectList.add(filler(modeIndicator, 4));
		/* Completion Code */
		objectList.add(filler(completionCode, 1));
		/* Station Id */
		objectList.add(filler(currentUserContext.getStationId(), 3));
		/* Set to I */
		objectList.add(filler("I", 1));
		/* Mag Stripe Stat Code */
		//		if (EaseUtil.isNullOrBlank(ttc) && ttc.startsWith("CAU")) {//TODO - Verify with Louise/Paula about this condition
		//			String magStripeStatusCode = "";
		//			objectList.add(filler(magStripeStatusCode, 1));
		//		}
		objectList.add(filler("", 1));
		LOGGER.info("--> " + objectList.toString());
		return StringUtils.join(objectList.toArray());
	}

	/**
	 * Creates the message from.
	 * 
	 * @param prodRequest 
	 * 
	 * @return the string
	 */
	private String createMessageFrom(ProductionStatisticRequestEcs prodRequest) {
		return createMessage(prodRequest.getUserContext(), prodRequest
				.getCompletionCode(), prodRequest.getCashierSequenceNbr(),
				prodRequest.getDlOrIdIndicator(), prodRequest.getTtc());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.bridge.impl.AbstractBridgeConverter#getMessageFormatString()
	 */
	@Override
	protected String getMessageFormatString() {
		//		EDL Name	Off	Len	Description	Format	Content
		//		n/a	0	4	TCODE 'BPRS'	A	BPRS'
		//		PAADLIN 	4	1	DL/ID# INDICATOR        A	"Not Used by DL, Set to blank"
		//		PAASYSDT	5	8	SYSTEM DATE (MMDDYYYY)                 	MMDDYYYY	VCSCSXDT
		//		PAATIMST	13	6	SYSTEM TIME STARTED (HHMMSS)         	HHMMSS	VCSTIMST
		//		PAATIMED	19	6	SYSTEM TIME ENDED (HHMMSS)           	HHMMSS	VCSTIMEN
		//		PAAKEYBY	25	2	KEYED BY                          	A	VCSKEYBY
		//		PAADTWRK	27	8	WORK DATE (MMDDYYYY)                   	MMDDYYYY	VCSWKSDT
		//		PAACASEQ	35	4	CASHIERING SEQUENCE # (IF ANY)       	AN	VCSCASQ#
		//		PAAOFFID	39	3	OFFICE ID                       	A	VCSOFFID
		//		PAATTC   	42	3	TTC                         	A	"if ( VCSTTC == ""DCS"" ) 
		//		PAAMDEIN	45	4	MODE INDICATOR                       	A	"VCSCMSET
		//		4 Character Session MODE:
		//		Char[0] = { P | T } 
		//		Char[1] = { C | M | P | T }
		//		Char[2] = D
		//		Char[3] = S"
		//		PAACOMCD	49	1	"COMPLETION CODE:	A	See Note 1
		//		PAASTAID	50	3	STATION ID	A	VCSSTAID
		//		PAAPRCID	53	1	Set to "I"	A	Set to 'I'
		//		PAAMSTAT	54	1	 
		//		Length	55		
		return "(BPRS) A D T T A{2} D A{4} A{3} A{3} A{4} A A{3} (I) A";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.IMessageConverter#getMessageTcode()
	 */
	@Override
	public String getMessageTcode() {
		return "BPRS"; //TODO use a static
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.IMessageConverter#getLogId(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	public String getLogId(IEcsRequest request) {
		return null;
	}
}
/**
 * Modification History:
 *
 *  $Log: ProductionStatisticsConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.19  2012/02/29 01:00:27  mwxxw
 *  Implement new interface getLogId().
 *
 *  Revision 1.18  2011/10/12 20:56:52  mwkkc
 *  Performance Merge
 *
 *  Revision 1.17.8.1  2011/09/26 23:19:02  mwpxp2
 *  Made singleton
 *
 *  Revision 1.17  2011/06/10 21:43:49  mwyxg1
 *  clean up
 *
 *  Revision 1.16  2011/06/06 23:14:15  mwxxw
 *  Use CurrentDateProvider.getInstance().getCurrentDate() to replace new Date().
 *
 *  Revision 1.15  2011/03/23 23:46:57  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.14  2010/12/15 19:43:47  mwpxp2
 *  Added logging to createMessage/1
 *
 *  Revision 1.13  2010/12/13 20:10:30  mwpxp2
 *  Added getMessageTcode/0
 *
 *  Revision 1.12  2010/12/12 08:26:02  mwpxp2
 *  Added getMessageFormatString/0
 *
 *  Revision 1.11  2010/12/10 23:37:23  mwpxr4
 *  Commented code for mag stripe stat code.
 *
 *  Revision 1.10  2010/12/10 21:59:13  mwpxr4
 *  Added TODO for CAU-Mag stripe stat code.
 *
 *  Revision 1.9  2010/12/10 18:56:02  mwpxr4
 *  Corrected length of dlIdIndicator field.
 *
 *  Revision 1.8  2010/12/10 03:33:23  mwpxp2
 *  Changed super to AbstractBridgeConverter; added non-null validations
 *
 *  Revision 1.7  2010/12/10 03:04:47  mwpxp2
 *  Cleaned up imports
 *
 *  Revision 1.6  2010/12/10 02:22:38  mwpxp2
 *  Modified to use ProductionStatisticRequestEcs rather than ProductionStatisticRequest
 *
 *  Revision 1.5  2010/12/09 20:25:12  mwpxp2
 *  Standardized public behavior as per converter API
 *
 *  Revision 1.4  2010/11/09 04:56:05  mwpxp2
 *  Added package-related fixme
 *
 *  Revision 1.3  2010/11/08 20:17:29  mwpxp2
 *  Added class footer; added fixmes
 *
 */
