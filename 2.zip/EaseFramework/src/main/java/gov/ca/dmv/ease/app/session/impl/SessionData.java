/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.impl;

import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.app.context.impl.ExecutionSyncPoint;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.Serializable;
import java.util.Stack;

/**
 * Description: The purpose of this class is to encapsulate the session data.
 * File: SessionData.java
 * Module:  gov.ca.dmv.ease.app.http.listener.impl
 * Created: Apr 28, 2010 
 * @author MWVKM  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SessionData implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5325221675727765842L;
	/** The current process context. */
	private IProcessContext currentProcessContext;
	/** The Session Timeout State. */
	private boolean sessionTimeout = true;
	/** The user context. */
	private IUserContext userContext;
	/** The stack of execution sync points. */
	private Stack <ExecutionSyncPoint> executionSyncPoints;
	/** The rollback process context. */
	private IProcessContext rollbackProcessContext;
	/** The rollback subprocess activity name. */
	private String rollbackSubprocessActivityName;
	
	/**
	 * Instantiates a new session data.
	 */
	public SessionData() {
		super();
	}
	
	/**
	 * Instantiates a new session data - build constructor.
	 *
	 * @param processContext the process context
	 * @param userCtx the user ctx
	 * @param executionSyncPoints the execution sync points
	 * @param rollbackProcessContext the rollback process context
	 * @param rollbackSubprocessActivityName the rollback subprocess activity name
	 */
	public SessionData(IProcessContext processContext, IUserContext userCtx,
			Stack <ExecutionSyncPoint> executionSyncPoints,
			IProcessContext rollbackProcessContext,
			String rollbackSubprocessActivityName) {
		super();
		setCurrentProcessContext(processContext);
		setUserContext(userCtx);
		setExecutionSyncPoints(executionSyncPoints);
		setRollbackProcessContext(rollbackProcessContext);
		setRollbackSubprocessActivityName(rollbackSubprocessActivityName);
	}
	
	/**
	 * Instantiates a new session data - copy constructor.
	 * 
	 * @param dataTocopy the data to copy
	 */
	public SessionData(SessionData dataTocopy) {
		super();
		copy(dataTocopy);
	}
	
	/**
	 * The purpose of this method is to copy the session data.
	 * 
	 * @param sessionData the session data
	 */
	public void copy(SessionData sessionData) {
		setCurrentProcessContext(sessionData.getCurrentProcessContext());
		this.setUserContext(sessionData.getUserContext());
		setExecutionSyncPoints(sessionData.getExecutionSyncPoints());
		setSessionTimeout(sessionData.isSessionTimeout());
		setRollbackProcessContext(sessionData.getRollbackProcessContext());
		setRollbackSubprocessActivityName(sessionData
				.getRollbackSubprocessActivityName());
	}
	
	/**
	 * Gets the current process context.
	 * 
	 * @return the current process context
	 */
	public IProcessContext getCurrentProcessContext() {
		return currentProcessContext;
	}
	
	/**
	 * Gets the current activity.
	 *
	 * @return the current activity
	 */
	public Activity getCurrentActivity() {
		if (getCurrentProcessContext() == null) {
			return null;
		}
		return getCurrentProcessContext().getCurrentActivity();
	}
	
	/**
	 * The purpose of this method is to find the current activity name of the process context.
	 * 
	 * @return the string
	 */
	public String getCurrentInteractionActivityName() {
		if (getCurrentProcessContext() == null) {
			//throw new EaseValidationException("null process context");
			return "NULL";
		}
		InteractionActivity anActivity = getCurrentProcessContext()
				.getCurrentInteractionActivity();
		if (anActivity == null) {
			//throw new EaseValidationException(
			//		"process context with null current interaction activity");
			return "NULL";
		}
		return anActivity.getClass().getSimpleName();
	}
	
	/**
	 * The purpose of this method is to find the previous activity name of the process context.
	 * 
	 * @return the string
	 */
	public String getPreviousInteractionActivityName() {
		if (getCurrentProcessContext() == null) {
			//throw new EaseValidationException("null process context");
			return "NULL";
		}
		Activity anActivity = getCurrentProcessContext()
				.getPreviousInteractionActivity();
		if (anActivity == null) {
			//throw new EaseValidationException(
			//		"process context with null previous interaction activity");
			return "NULL";
		}
		return anActivity.getClass().getSimpleName();
	}
	
	/**
	 * Gets the user context.
	 * 
	 * @return the user context
	 */
	public IUserContext getUserContext() {
		return userContext;
	}
	
	/**
	 * Checks if required properties have been set.
	 * 
	 * @return true, if required properties are not set
	 */
	public boolean hasRequiredData() {
		return (EaseUtil.isNotNull(currentProcessContext) && EaseUtil
				.isNotNull(userContext));
	}
	
	/**
	 * Checks if is session timeout.
	 * 
	 * @return true, if is session timeout
	 */
	public boolean isSessionTimeout() {
		return sessionTimeout;
	}
	
	/**
	 * Sets the current process context.
	 * 
	 * @param aCtx the new current process context
	 */
	public void setCurrentProcessContext(IProcessContext aCtx) {
		currentProcessContext = aCtx;
	}
	
	/**
	 * Sets the session timeout.
	 * 
	 * @param aTimeout the new session timeout
	 */
	public void setSessionTimeout(boolean aTimeout) {
		sessionTimeout = aTimeout;
	}
	
	/**
	 * Sets the user context.
	 * 
	 * @param aCtx the new user context
	 */
	public void setUserContext(IUserContext aCtx) {
		userContext = aCtx;
	}
	
	/**
	 * Sets the executionSyncPoints.
	 *
	 * @param aExecutionSyncPoints the new execution sync points
	 */
	public void setExecutionSyncPoints(
			Stack <ExecutionSyncPoint> aExecutionSyncPoints) {
		executionSyncPoints = aExecutionSyncPoints;
	}
	
	/**
	 * Gets the executionSyncPoints.
	 * 
	 * @return Stack <ExecutionSyncPoint>
	 */
	public Stack <ExecutionSyncPoint> getExecutionSyncPoints() {
		return executionSyncPoints;
	}
	
	/**
	 * Sets the rollback process context.
	 *
	 * @param rollbackProcessContext the rollbackProcessContext to set
	 */
	public void setRollbackProcessContext(IProcessContext rollbackProcessContext) {
		this.rollbackProcessContext = rollbackProcessContext;
	}
	
	/**
	 * Sets the rollback subprocess activity name.
	 *
	 * @param rollbackSubprocessActivityName the rollbackSubprocessActivityName to set
	 */
	public void setRollbackSubprocessActivityName(
			String rollbackSubprocessActivityName) {
		this.rollbackSubprocessActivityName = rollbackSubprocessActivityName;
	}
	
	/**
	 * Gets the rollback process context.
	 *
	 * @return the rollbackProcessContext
	 */
	public IProcessContext getRollbackProcessContext() {
		return rollbackProcessContext;
	}
	
	/**
	 * Gets the rollback subprocess activity name.
	 *
	 * @return the rollbackSubprocessActivityName
	 */
	public String getRollbackSubprocessActivityName() {
		return rollbackSubprocessActivityName;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionData.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.23  2012/09/12 00:28:32  mwhys
 *  Added a field rollbackSubprocessActivityName. (Defect 7189)
 *
 *  Revision 1.22  2012/06/01 21:39:05  mwhys
 *  Added property rollbackProcessContext. (Session Management)
 *
 *  Revision 1.21  2012/05/09 00:10:30  mwhys
 *  Added getCurrentActivity().
 *
 *  Revision 1.20  2012/05/08 00:28:29  mwhys
 *  Refactored getters for current and previous activities.
 *
 *  Revision 1.19  2012/01/09 23:36:07  mwkfh
 *  updated getLastInteractionActivityName and added getNextInteractionActivityName
 *
 *  Revision 1.18  2010/12/02 00:14:59  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.17  2010/09/24 00:24:22  mwhys
 *  Added executionSyncPoints field.
 *
 *  Revision 1.16  2010/09/01 18:56:53  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.15  2010/08/31 22:45:11  mwkfh
 *  removed errorCollector
 *
 *  Revision 1.14  2010/08/30 19:03:55  mwkfh
 *  made ProcessContext not transient
 *
 *  Revision 1.13  2010/08/30 18:51:58  mwkfh
 *  updated constructor and copy
 *
 *  Revision 1.12  2010/08/30 18:20:51  mwkfh
 *  removed transient setting from process context
 *
 *  Revision 1.11  2010/08/30 18:18:22  mwkfh
 *  added UserContext and ErrorCollector
 *
 *  Revision 1.10  2010/08/23 16:23:36  mwkfh
 *  added use of EaseUtil.isNotNull()
 *
 *  Revision 1.9  2010/08/17 15:54:30  mwkfh
 *  changed currentProcessContext to non-transient
 *
 *  Revision 1.8  2010/08/13 20:12:16  mwpxp2
 *  Re-wrote getLastInteractionActivityName to use exceptions
 *
 *  Revision 1.7  2010/08/11 23:54:25  mwkfh
 *  removed unneeded properties
 *
 *  Revision 1.6  2010/08/11 17:44:59  mwkfh
 *  added default constructor
 *
 *  Revision 1.5  2010/08/11 15:42:27  mwpxp2
 *  Added copy constructor; cleaned up
 *
 *  Revision 1.4  2010/07/30 22:07:57  mwkfh
 *  refactored and merge session store and restore
 *
 *  Revision 1.3  2010/07/29 17:58:43  mwkfh
 *  added currentProcessContext which will be non-transient in the future
 *
 *  Revision 1.2  2010/07/28 21:00:43  mwskd2
 *  sessionTimeout property is added
 *
 *  Revision 1.1  2010/07/27 18:01:06  mwkfh
 *  updated and moved session services
 *
 *  Revision 1.3  2010/07/16 15:30:56  mwkfh
 *  merge from session_restore_poc
 *
 *  Revision 1.1.2.1  2010/07/12 21:26:59  mwkfh
 *  relocated session restore classes
 *
 *  Revision 1.4.2.1  2010/06/28 23:27:33  mwvkm
 *  a method called copy is added
 *
 *  Revision 1.4  2010/05/18 23:08:11  mwvkm
 *  Changes/Updates are made for Session Restore functionality POC.
 *
 *  Revision 1.3  2010/05/05 00:10:13  mwvkm
 *  Chnaged the sessionContext type to ISessionContext
 *
 *  Revision 1.2  2010/05/04 17:45:01  mwvkm
 *  sessionContext is added.
 *
 *  Revision 1.1  2010/04/29 23:52:04  mwvkm
 *  Initial check-in for session restore in session management
 *
 */
