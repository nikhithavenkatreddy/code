/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.bridge.request.impl;

import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am concrete request to DMVA bridge via ECS
 *  
 * File: BridgeRequest.java
 * Module:  gov.ca.dmv.ease.ecs.request.log.impl
 * Created: Apr 10, 2010 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BridgeRequest extends AbstractEcsBridgeRequest {
	/**
	 * @param anId
	 */
	public BridgeRequest(String anId) {
		super(anId);
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4376845053393023333L;
	/** The message. */
	private String message = null;

	/**
	 * Instantiates a new bridge request.
	 * 
	 * @param anId the an id
	 * @param context the context
	 */
	public BridgeRequest(String anId, IUserContext context) {
		super(anId, context);
	}

	/**
	 * The Constructor that instantiates the BridgeRequest.
	 * 
	 * @param anId
	 *            Id of the request
	 * @param context
	 *            the context
	 * @param mess
	 *            the mess
	 */
	public BridgeRequest(String anId, IUserContext context, String mess) {
		super(anId, context);
		message = mess;
	}

	/**
	 * Instantiates a new bridge request.
	 * 
	 * @param context 
	 */
	public BridgeRequest(IUserContext context) {
		super(context);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.ecs.request.impl.FireAndForgetEcsRequest#execute()
	 */
	@Override
	public FireAndForgetReceipt execute() throws EcsServiceException {
		FireAndForgetReceipt returnReceipt = super.execute();
		return returnReceipt;
	}

	/**
	 * Gets the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String aMessage) {
		message = aMessage;
	}
}
/**
 * Modification History:
 * 
 * $Log: BridgeRequest.java,v $
 * Revision 1.1  2012/10/01 02:57:23  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.3  2010/12/10 02:34:06  mwpxp2
 * Added constructor from super
 *
 * Revision 1.2  2010/12/06 20:13:28  mwpxp2
 * Added contstructor/1 on user context
 *
 * Revision 1.1  2010/09/22 18:17:53  mwpxp2
 * Moved in to bridge-specific package
 *
 * Revision 1.7  2010/09/22 18:09:24  mwpxp2
 * Fixed class header; added fixme
 *
 * Revision 1.6  2010/07/08 02:04:42  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.5  2010/06/29 00:12:00  mwtjc1
 * BridgeRequest(String anId, IUserContext context) constructor added
 *
 * Revision 1.4  2010/05/04 00:55:10  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/04/29 23:32:31  mwgrk
 * added public setMessage method to BridgeRequest class.
 * Revision 1.2 2010/04/22 19:05:47 mwpxp2 Bulk
 * cleanup - added todo
 * 
 * Revision 1.1 2010/04/12 02:33:39 mwpzs3 update for bridge code communication
 * 
 */
