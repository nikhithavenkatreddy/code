/**
 *
 */
package gov.ca.dmv.ease.fw;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: I am interface to be implemented by objects that require creation and modification stamping
 * File: IWithCreationModificationStamps.java
 * Module:  gov.ca.dmv.ease.fw.stamp
 * Created: 10/07/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithCreationModificationStamps extends Serializable {
	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	String getCreatedBy();

	/**
	 * Gets the creation date.
	 *
	 * @return the creation date
	 */
	Date getCreatedDate();

	/**
	 * Gets the modified by.
	 *
	 * @return the modified by
	 */
	String getModifiedBy();

	/**
	 * Gets the modification date.
	 *
	 * @return the modification date
	 */
	Date getModifiedDate();
}
/**
 *  Modification History:
 *
 *  $Log: IWithCreationModificationStamps.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/03 20:15:09  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/07/14 23:44:24  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.3  2009-07-12 15:49:22  ppalacz
 *  Renamed getters for dates to reflect prevalent usage
 *
 *  Revision 1.2  2009-07-12 15:45:42  ppalacz
 *  Moved in from FW
 *
 *  Revision 1.1  2009-07-11 06:57:55  ppalacz
 *  Initial
 *
*/
