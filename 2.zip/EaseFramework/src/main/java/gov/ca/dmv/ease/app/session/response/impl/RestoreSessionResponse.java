/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.response.impl;

import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.bo.app.impl.Session;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.tus.persist.util.impl.Serializer;

/**
 * Description: I define the interface to PersistenceServiceRequest
 * 
 * File: RestoreSessionResponse.java
 * Module:  gov.ca.dmv.ease.app.session.response.impl
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RestoreSessionResponse extends SessionServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7785070602121706601L;
	/** The business data object. */
	private Session sessionObject;

	/**
	 * Instantiates a new retrieve business object response.
	 */
	public RestoreSessionResponse(Session sessionObject) {
		super();
		this.sessionObject = sessionObject;
	}

	/**
	 * Instantiates a new retrieve business object response.
	 * 
	 * @param ex the exception
	 */
	public RestoreSessionResponse(Exception exception) {
		super();
		getErrorCollector().register(exception);
	}

	/**
	 * Instantiates a new retrieve business object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RestoreSessionResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * This method returns the retrieved domain object.
	 * 
	 * @return the domainObject retrieved domain object
	 */
	public Session getSessionObject() {
		return sessionObject;
	}

	/**
	 * This method returns the session data from the domain object.
	 * 
	 * @return the session data from the domainObject
	 */
	public SessionData getSessionDataObject() {
		if (sessionObject == null) {
			return null;
		}
		else {
			return (SessionData) Serializer.getInstance().getObjectFromBlob(
					sessionObject.getSessionData());
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: RestoreSessionResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/06/10 21:03:36  mwyxg1
 *  clean up
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
