/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.service;

import gov.ca.dmv.ease.tus.persist.service.IPersistenceService;
import gov.ca.dmv.ease.tus.session.persist.request.impl.DeleteSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.request.impl.UpdateSessionPersistenceRequest;
import gov.ca.dmv.ease.tus.session.persist.response.impl.DeleteSessionPersistenceResponse;
import gov.ca.dmv.ease.tus.session.persist.response.impl.UpdateSessionPersistenceResponse;

/**
 * Description: I am the interface to the session persistence service.
 * File: ISessionPersistenceService.java
 * Module:  gov.ca.dmv.ease.tus.persist.service
 * Created: Jan 3, 2012 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:35:52 $
 * Last Changed By: $Author: mwhys $
 */
public interface ISessionPersistenceService extends IPersistenceService {
	/**
	 * This method deletes the session object from the database.
	 * 
	 * @param request Request containing the session object to be deleted
	 * 
	 * @return Response containing status of the deletion operation
	 */
	DeleteSessionPersistenceResponse execute(
			DeleteSessionPersistenceRequest request);
	
	/**
	 * Execute.
	 *
	 * @param request the request
	 * @return the update session persistence response
	 */
	UpdateSessionPersistenceResponse execute(
			UpdateSessionPersistenceRequest request);
}
/**
 *  Modification History:
 *
 *  $Log: ISessionPersistenceService.java,v $
 *  Revision 1.2  2012/12/13 00:35:52  mwhys
 *  Added UpdateSessionPersistenceRequest.
 *
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/06 19:34:44  mwkfh
 *  Initial
 *
 */
