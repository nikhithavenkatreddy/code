/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process;

import java.util.List;

/**
 * Description: I am an interface that defines introspective context helper methods
 * 
 * File: IIntrospectiveContext.java
 * Module:  gov.ca.dmv.ease.fw.process
 * 
 * Created: Sep 29, 2009
 * 
 * @author MWSEC2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IIntrospectiveContext {
	
	/** The length of the prefix for getters */
	int GET_LEN = 3;
	/** The prefix for getters */
	String GET_PREFIX = "get";
	/** The length of the prefix for boolean/Boolean getters */
	int IS_LEN = 2;
	/** The prefix for boolean/Boolean getters */
	String IS_PREFIX = "is";
	/** The length of the prefix for setters */
	int SET_LEN = 3;
	/** The prefix for setters */
	String SET_PREFIX = "set";
	
	/**
	 * Copies the identically named properties from a source context object 
	 * into this context object, skipping properties inherited from 
	 * ProcessContext and ChildContext.
	 * @param source The source context object to copy from
	 */
	void copyPropertiesFrom(IIntrospectiveContext source);

	/**
	 * Returns the named property the expected type.  
	 * @param <T> 
	 * @param name the name of the property
	 * @param type the expected type
	 * @return
	 */
	<T> T getProperty(String name, Class <T> type);
	
	/**
	 * Returns true only if the class has public accessors (setter/getter)
	 * for the named property. The named property need not actually exist
	 * as a declared field, so long as the setter/getter exist.  
	 * @param name the name of the property
	 * @return
	 */
	boolean hasProperty(String name);
	
	/**
	 * Sets the named list property with the given list of elements
	 * of the specified type.
	 * @param <E>
	 * @param name
	 * @param list
	 * @param elementType
	 */
	<E> void setListProperty(String name, List<E> list, Class <E> elementType);
	
	/**
	 * Sets the named property with the given value
	 * @param name the name of the property
	 * @param value the given value 
	 */
	void setProperty(String name, Object value);
}


/**
 *  Modification History:
 *
 *  $Log: IIntrospectiveContext.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/19 17:19:40  mwsec2
 *  initial check-in
 *
 *  Revision 1.1.2.2  2010/10/07 23:15:21  mwsec2
 *  copyPropertiesFrom param changed to the interface
 *
 *  Revision 1.1.2.1  2010/10/05 21:26:01  mwsec2
 *  initial check in
 *
 */
