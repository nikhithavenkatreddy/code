/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.adaptor;

import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.IEcsResponsePromise;
import gov.ca.dmv.ease.fw.service.IResponsePromise;

/**
 * Description: Interface for an object adapting to jms communication channel,
 * This includes converting messages/payloads to and from response/erquest objects correspondingly.
 * 
 * File: IJmsAdaptor.java
 * Module:  gov.ca.dmv.ease.ecs
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2018/05/25 16:34:25 $
 * Last Changed By: $Author: mwskh1 $
 */
public interface IJmsAdaptor {
	/** The ASYN c_ persisten t_ rec v_ jm s_ template. */
	String ASYNC_PERSISTENT_RECV_JMS_TEMPLATE = "asyncPersistentRecvjmsTemplate";
	/** The ASYN c_ persisten t_ sen d_ jm s_ template. */
	String ASYNC_PERSISTENT_SEND_JMS_TEMPLATE = "asyncPersistentSendjmsTemplate";
	/** The BRIDG e_ dmv a_ sen d_ jm s_ template. */
	String BRIDGE_DMVA_SEND_JMS_TEMPLATE = "bridgeDmvaSendjmsTemplate";
	/** The BRIDG e_ eas e_ rec v_ jm s_ template. */
	String BRIDGE_EASE_RECV_JMS_TEMPLATE = "bridgeEaseRecvjmsTemplate";
	/** The FIR e_ an d_ forge t_ persisten t_ sen d_ jm s_ template. */
	String LOG_PERSISTENT_SEND_JMS_TEMPLATE = "logSendJmsTemplate";
	/** The constant SYNC_DOC_GENERATION_NONPERSISTENT_RECV_JMS_TEMPLATE */
	String SYNC_DOC_GENERATION_PERSISTENT_RECV_JMS_TEMPLATE = "syncDocGenerationPersistentRecvjmsTemplate";
	/** The constant SYNC_DOC_GENERATION_NONPERSISTENT_SEND_JMS_TEMPLATE */
	String SYNC_DOC_GENERATION_PERSISTENT_SEND_JMS_TEMPLATE = "syncDocGenerationPersistentSendjmsTemplate";
	/** The SYN c_ nonpersisten t_ rec v_ jm s_ template. */
	String SYNC_NONPERSISTENT_RECV_JMS_TEMPLATE = "syncNonPersistentRecvjmsTemplate";
	/** The SYN c_ nonpersisten t_ sen d_ jm s_ template. */
	String SYNC_NONPERSISTENT_SEND_JMS_TEMPLATE = "syncNonPersistentSendjmsTemplate";
	/** The SYN c_ persisten t_ rec v_ jm s_ template. */
	String SYNC_PERSISTENT_RECV_JMS_TEMPLATE = "syncPersistentRecvjmsTemplate";
	/** The SYN c_ persisten t_ sen d_ jm s_ template. */
	String SYNC_PERSISTENT_SEND_JMS_TEMPLATE = "syncPersistentSendjmsTemplate";
	String DLID_L1_SEND_JMS_TEMPLATE = "dlidL1SendjmsTemplate";
	/** The FODI JMS template. */
	String FODI_SEND_JMS_TEMPLATE = "fodiSendJmsTemplate";
	/** The AKTE JMS template. */
	String AKTE_SEND_JMS_TEMPLATE = "akteSendJmsTemplate";	
	/** The AKTE JMS template. */
	String VTR_SEND_JMS_TEMPLATE = "vtrSendJmsTemplate";

	/**
	 * Gets the configuration.
	 * 
	 * @return the configuration
	 */
	IAdaptorConfiguration getConfiguration();

	/**
	 * Gets the persistence service.
	 * 
	 * @return the persistence service
	 */
	//	IPersistenceService getPersistenceService();
	/**
	 * Process AsynchronousEcsRequest.
	 * 
	 * @param request the request
	 * 
	 * @return the asynchronous response promise
	 */
	IEcsResponsePromise processAsynchronous(IEcsRequest request);

	/**
	 * Process FireAndForgetEcsRequest.
	 * 
	 * @param request the request
	 * 
	 * @return the fire and forget resceipt
	 */
	IEcsResponse processFireAndForget(IEcsRequest request);

	/**
	 * Process promise.
	 * 
	 * @param promise the IEcsResponsePromise
	 * 
	 * @return the i response - can be either the promise or the actual asynch message, if available
	 */
	IEcsResponse processPromise(IResponsePromise promise);

	/**
	 * Process SynchronousEcsRequest.
	 * 
	 * @param request the request
	 * 
	 * @return the synchronous response
	 */
	IEcsResponse processSynchronous(IEcsRequest request);
}
/**
 *  Modification History:
 *  
 *  $Log: IJmsAdaptor.java,v $
 *  Revision 1.6  2018/05/25 16:34:25  mwskh1
 *  merging eDL44_2_8_1_9 (eDL44 project) and EASE_2_8_1_9_branch (Real ID, M&O and AKTE defects) to head
 *
 *  Revision 1.5.20.1  2018/05/11 17:21:29  mwwwc
 *  Merge defect 468 fix into BRANCH_EASE_2_8_3_1 Branch.
 *
 *  Revision 1.5.14.1  2018/03/06 21:48:05  mwwwc
 *  Defect 468: Remove reference to AKT Stockton Plus MQ and message relate.
 *
 *  Revision 1.5  2017/08/07 16:56:15  mwwwc
 *  Merge AKTE changes from branch to Head.
 *
 *  Revision 1.4.6.1  2017/05/24 17:01:18  mwwwc
 *  Added back AKTE changes
 *
 *  Revision 1.4  2016/02/18 20:17:49  mwskh1
 *  Motor Voter - merge to head
 *
 *  Revision 1.2.2.1  2016/01/21 19:45:42  mwskh1
 *  Motor Voter - Add new subprocess and ECS message with queue settings
 *  
 *  Revision 1.2  2015/12/03 17:46:37  mwwwc
 *  Merge AKTE Changes to HEAD
 *
 *  Revision 1.1.14.1  2015/10/20 19:02:11  mwwwc
 *  AKTE Change: Added ATE_SEND_JMS_TEMPLATE
 *
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
