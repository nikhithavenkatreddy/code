/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.persist;

import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.ecs.response.impl.AsynchronousResponsePromise;
import gov.ca.dmv.ease.fw.service.IResponsePromise;

import java.util.List;

/**
 * Description: I am interface for persistence service.
 * File: IPersistenceService.java
 * Module:  gov.ca.dmv.ease.ecs.persist
 * Created: 12/05/2009
 * @author pxp
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPersistenceService {
	/**
	 * Persists the AsynchronousResponsePromise.
	 * 
	 * @param aPromise the a promise
	 */
	void persist(AsynchronousResponsePromise aPromise);

	/**
	 * Persists the IEcsResponse.
	 * 
	 * @param aResponse the a response
	 * 
	 * @return the string identifier of the persisted response
	 */
	String persist(IEcsResponse aResponse);

	/**
	 * Persists the response payload.
	 * 
	 * @param aResponseObj is the a response object
	 * 
	 * @return the string
	 */
	void persistResponse(String aCorrelationId, String aResponse);

	/**
	 * Persists the response payload.
	 * @param aPayload the payload
	 * @param seqNum the sequence number
	 * 
	 * @return the string
	 */
	void persistResponsePayload(String aCorrelationId, String aPayload,
			int seqNum);

	/**
	 * Response has many parts.
	 * 
	 * @param aPromise the a promise
	 * 
	 * @return true, if successful
	 */
	boolean responseHasManyParts(IResponsePromise aPromise);

	/**
	 * Retrieve all responses for.
	 * 
	 * @param aPromise the a promise
	 * 
	 * @return the list< i ecs response>
	 */
	List <IEcsResponse> retrieveAllResponsesFor(IResponsePromise aPromise);

	/**
	 * Retrieves the response.
	 * 
	 * @param aPersistedResponseId a persisted response id
	 * @param aResponseClassName a response class name
	 * 
	 * @return the IEcsResponse
	 */
	IEcsResponse retrieveResponse(String aPersistedResponseId,
			String aResponseClassName);

	/**
	 * Retrieves response for a promise.
	 * 
	 * @param aPromise the a promise
	 * 
	 * @return the IEcsResponse
	 */
	String retrieveResponseFor(IResponsePromise aPromise);
}
/**
 *  Modification History:
 *
 *  $Log: IPersistenceService.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 22:34:46  mwpxp2
 *  Added support for persisting and retrieving multi-segmented messages: responseHasManyParts/1 and retrieveAllResponsesFor/1
 *
 *  Revision 1.2  2010/04/07 19:24:45  mwvkm
 *  Changed the asynchronous request approach for ecs and fixed the design issue with the framework.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.14  2009/10/13 20:17:46  mwhxb3
 *  updated comments.
 *
 *  Revision 1.13  2009/10/06 21:51:52  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.12.2.1  2009/10/06 20:28:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.12  2009/10/03 21:23:43  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.11  2009/08/27 05:54:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.10  2009/08/27 02:34:02  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.9  2009/08/26 01:58:51  mwpxp2
 *  Replaced IEcsResponsePromise with IResponsePromise
 *
 *  Revision 1.8  2009/08/18 02:11:47  mwpzs3
 *  change for asynchronous
 *
 *  Revision 1.7  2009/08/13 02:57:16  mwpzs3
 *  Asynchronous message handling
 *
 *  Revision 1.6  2009/08/06 01:44:48  mwpzs3
 *  Cahnges for Asnychronous Response retrieval
 *
 *  Revision 1.5  2009/08/05 01:35:06  mwpxp2
 *  Added retrieveResponseFor/1
 *
 *  Revision 1.4  2009/08/05 01:33:30  mwpxp2
 *  Added calls
 *
 *  Revision 1.3  2009/07/27 18:29:00  mwpxp2
 *  Adjusted imports for renames
 *
 *  Revision 1.2  2009/07/14 23:58:50  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.3  2009-05-13 21:25:10  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.2  2009-05-13 18:06:00  ppalacz
 *  Added persist of a response, retreiveResponse/2 calls
 *
 *  Revision 1.1  2009-05-12 22:07:27  ppalacz
 *  Initial
 *
*/
