/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.fw.http.request;

import java.util.Map;

/**
 * Description: I define the contract for extracting the required information from the request
 * File: IRequestHeaderExtractor.java
 * Module:  gov.ca.dmv.ease.fw.http.request
 * Created: Apr 4, 2010 
 * @author MWAKG  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/11/16 18:18:51 $
 * Last Changed By: $Author: mwskh1 $
 */
public interface IRequestHeaderExtractor {
	/** The SPACER. */
	String SPACER = "; ";

	/**
	 * Gets the ip address.
	 * 
	 * @return the ip address
	 */
	public String getIpAddress();

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId();

	/**
	 * Gets the original user.
	 * 
	 * @return the original user
	 */
	public String getOriginalUser();

	/**
	 * Gets the racf id.
	 * 
	 * @return the racf id
	 */
	public String getRacfId();

	/**
	 * Gets the tech id.
	 * 
	 * @return the tech id
	 */
	public String getTechId();

	/**
	 * Gets the username.
	 * 
	 * @return the username
	 */
	public String getUsername();

	/**
	 * Gets the remote office Id.
	 * 
	 * @return the remote office Id
	 */
	public String getRemoteOfficeId();

	/**
	 * Get issuance string.
	 * 
	 * @return the issuance string.
	 */
	public String getIssuanceStr();

	/**
	 * Sets the request attributes.
	 * 
	 */
	public void setRequestParameters();

	/**
	 * Sets the request attributes.  Pass null 
	 * to pull from the current request header.
	 * 
	 * @param Map requestParams 
	 */
	public void setRequestParameters(Map <String, String> requestParams);

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString();
}
/**
 * Modification History:
 * 
 * $Log: IRequestHeaderExtractor.java,v $
 * Revision 1.2  2012/11/16 18:18:51  mwskh1
 * exposed toString for logging in UserContext
 *
 * Revision 1.1  2012/10/01 02:57:38  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.9  2012/08/14 20:32:48  mwrrv3
 * Moved spacer to the interface.
 *
 * Revision 1.8  2012/05/17 23:37:39  mwxxw
 * Add new header name value pair: issuance.
 *
 * Revision 1.7  2010/11/29 23:04:36  mwxxw
 * Add new field remoteOfficeId for location enforcement service.
 *
 * Revision 1.6  2010/08/27 23:21:47  mwkfh
 * removed removeDuplicates from interface
 *
 * Revision 1.5  2010/07/08 02:04:43  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.4  2010/05/25 23:02:51  mwkkc
 * typed Map - mwkfh
 *
 * Revision 1.3  2010/05/25 22:03:17  mwkkc
 * updated to pull request header values - mwkfh
 *
 * Revision 1.2  2010/04/22 19:24:31  mwpxp2
 * Bulk cleanup - added missing javadoc
 *
 * Revision 1.1  2010/04/04 18:52:25  mwakg
 * Removed usage of username and using RequestHeaderExtractor
 *
 * 
 */
