/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request;

/**
 * Description: I define the interface to RetrieveCriteriaObjectRequest
 * File: IRetrieveCriteriaObjectRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request
 * Created: Dec 28, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveCriteriaObjectRequest extends
		IPersistenceServiceRequest {
	/**
	 * Starts the transaction
	 */
	void beginTransaction();

	/**
	 * Commits the transaction
	 */
	void commitTransaction();

	/**
	 * rolls back the transaction
	 */
	void rollbackTransaction();
}
/**
 *  Modification History:
 *
 *  $Log: IRetrieveCriteriaObjectRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/28 21:32:17  mwkfh
 *  updated RetrieveCriteriaObjectRequest to handle transaction outside of persistence service
 *
 */
