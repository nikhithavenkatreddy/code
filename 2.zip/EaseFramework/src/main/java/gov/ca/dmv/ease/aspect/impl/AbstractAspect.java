/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
/**
 *
 */
package gov.ca.dmv.ease.aspect.impl;

import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.aspect.ILogAspectConstants;
import gov.ca.dmv.ease.bus.service.ILogMessageProcessor;
import gov.ca.dmv.ease.ecs.request.factory.impl.BridgeRequestFactory;
import gov.ca.dmv.ease.ecs.request.factory.impl.LogRequestFactory;
import gov.ca.dmv.ease.ecs.request.log.impl.SystemManagementLogRequest;
import gov.ca.dmv.ease.ecs.response.impl.FireAndForgetReceipt;
import gov.ca.dmv.ease.fw.constants.IEaseLoggingConstants;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.ApplicationContext;

/**
 * Description: I am the abstract audit aspect class and I define the common behavior
 *
 * File: AbstractAspect.java
 * Module:  gov.ca.dmv.ease.aspect
 * Created: Sep 24, 2009
 *
 * @author MWRSK
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2013/09/12 21:42:01 $
 * Last Changed By: $Author: mwsec2 $
 */
@Aspect
public abstract class AbstractAspect implements ILogAspectConstants,
		IEaseLoggingConstants {
	/** The application context. */
	private static final ApplicationContext APPLICATION_CONTEXT;
	/** The bridge request factory. */
	protected final static BridgeRequestFactory BRIDGE_REQUEST_FACTORY;
	/** The ILogMessageProcessor */
	public final static ILogMessageProcessor LOG_PROCESSOR;
	/** The log request factory. */
	public final static LogRequestFactory LOG_REQUEST_FACTORY;
	/** The logger. */
	private static final Log LOGGER = LogFactory.getLog(AbstractAspect.class);
	/** Static Block */
	static {
		//FIXME - replace static block with standard getters
		APPLICATION_CONTEXT = EaseApplicationContext.getApplicationContext();
		LOG_REQUEST_FACTORY = (LogRequestFactory) APPLICATION_CONTEXT
				.getBean("logRequestFactory");
		BRIDGE_REQUEST_FACTORY = (BridgeRequestFactory) APPLICATION_CONTEXT
				.getBean("BRIDGE_REQUEST_FACTORY");
		LOG_PROCESSOR = (ILogMessageProcessor) APPLICATION_CONTEXT
				.getBean("logBatchProcessor"); 	// change to 'logMessageProcessor' to stop batching
	}										   	// change to 'logBatchProcessor' to start batching

	/**
	 * Checks if is valid.
	 *
	 * @param aProcessContext the a process context
	 * @return true, if is valid
	 */
	protected boolean isValid(ProcessContext aProcessContext) {
		return aProcessContext != null
				&& aProcessContext.getUserContext() != null;
	}

	/**
	 * Generate header section of the log.
	 *
	 * @param joinPoint the join point
	 *
	 * @return the string builder
	 */
	protected StringBuilder generateHeaderSection(JoinPoint joinPoint) {
		joinPoint.getTarget();
		String argsClass = "";
		if ((joinPoint.getArgs() != null) && (joinPoint.getArgs().length > 0)) {
			argsClass = joinPoint.getArgs()[0].getClass().getName();
		}
		StringBuilder logString = new StringBuilder();
		Signature sig = joinPoint.getSignature();
		logString.append(METHOD_CLASS_NAME + NAME_VALUE_SEPERATOR
				+ sig.getDeclaringTypeName() + LEFT_PAR + sig.getName()
				+ LEFT_PAR + argsClass + RIGHT_PAR + RIGHT_PAR
				+ FIELD_DELIMITER);
		logString.append(THREAD_ID + NAME_VALUE_SEPERATOR
				+ new Long(Thread.currentThread().getId()).toString()
				+ FIELD_DELIMITER);
		logString.append(LOG_TIMESTAMP + NAME_VALUE_SEPERATOR
				+ Calendar.getInstance().getTimeInMillis());
		logString.append(FIELD_DELIMITER);
		return logString;
	}

	/**
	 * Generate header section of the log.
	 *
	 * @param joinPoint the join point
	 * @param aProcessContext the process context
	 *
	 * @return the string builder
	 */
	protected StringBuilder generateHeaderSection(JoinPoint joinPoint,
			IProcessContext aProcessContext) {
		StringBuilder aBuilder = this.generateHeaderSection(joinPoint);
		if ((aProcessContext != null)
				&& (aProcessContext.getUserContext() != null)) {
			aBuilder.append(PRINCIPAL_ID
					+ NAME_VALUE_SEPERATOR
					+ aProcessContext.getUserContext().getUniqueIdentifier()
							.toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
			aBuilder.append(TECH_ID
					+ NAME_VALUE_SEPERATOR
					+ aProcessContext.getUserContext().getTechId()
							.toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
			aBuilder.append(OFFICE_ID
					+ NAME_VALUE_SEPERATOR
					+ aProcessContext.getUserContext().getOfficeId()
							.toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
		}
		return aBuilder;
	}

	/**
	 * Generate header section of the log.
	 *
	 * @param joinPoint the join point
	 * @param aUserContext the user context
	 *
	 * @return the string buffer
	 */
	protected StringBuilder generateHeaderSection(JoinPoint joinPoint,
			IUserContext aUserContext) {
		StringBuilder aBuilder = generateHeaderSection(joinPoint);
		if (aUserContext != null) {
			aBuilder.append(PRINCIPAL_ID).append(NAME_VALUE_SEPERATOR)
					.append(aUserContext.getUniqueIdentifier().toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
			aBuilder.append(TECH_ID + NAME_VALUE_SEPERATOR
					+ aUserContext.getTechId().toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
			aBuilder.append(OFFICE_ID + NAME_VALUE_SEPERATOR
					+ aUserContext.getOfficeId().toUpperCase());
			aBuilder.append(FIELD_DELIMITER);
		}
		return aBuilder;
	}

	/**
	 * In ease log appender execution.
	 */
	@Pointcut("cflow (execution(* gov.ca.dmv.ease.aspect.impl.*.*(..)))")
	public void inEaseLogExecution() {
	}

	@Pointcut("within(gov.ca.dmv.ease..test.*)")
	public void inTest() {
	}

	/**
	 * The purpose of this method is to process the audit log message.
	 *
	 * @param message the message
	 * @param userContext the user context
	 *
	 * @return the fire and forget receipt
	 */
	protected FireAndForgetReceipt processAuditLogRequestMessage(
			String message, IUserContext userContext) {
		StringBuilder aBuilder = new StringBuilder(AUDIT_PREFIX);
		aBuilder.append(FIELD_DELIMITER);
		aBuilder.append(message);
		LOG_PROCESSOR.execute(aBuilder.toString());
		return null;
	}

	/**
	 * The purpose of this method is to process the message.
	 *
	 * @param message the message
	 * @param userContext the user context
	 *
	 * @return the fire and forget receipt
	 */
	private FireAndForgetReceipt processRequest(String message,
			IUserContext userContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("processRequest(String message=" + message
					+ ", IUserContext userContext=" + userContext + ") - start");
		}
		FireAndForgetReceipt aReceipt = null;
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(message);
		}
		SystemManagementLogRequest systemManagementLogRequest = AbstractAspect.LOG_REQUEST_FACTORY
				.createSystemManagementLogRequest(message, userContext);
		aReceipt = systemManagementLogRequest.execute();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("processRequest(String=" + message + ", IUserContext="
					+ userContext + ") - end - return value=" + aReceipt);
		}
		return aReceipt;
	}

	/**
	 * The purpose of this method is to process the system log message.
	 *
	 * @param message the message
	 * @param userContext the user context
	 *
	 * @return the fire and forget receipt
	 */
	protected FireAndForgetReceipt processSystemLogRequestMessage(
			String message, IUserContext userContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("processSystemLogRequestMessage(String message=" + message
					+ ", IUserContext userContext=" + userContext + ") - start");
		}
		StringBuilder aBuf = new StringBuilder(SM_PREFIX);
		aBuf.append(FIELD_DELIMITER);
		aBuf.append(message);
		LOG_PROCESSOR.execute(aBuf.toString());
		/*
		FireAndForgetReceipt returnFireAndForgetReceipt = processRequest(aBuf
				.toString(), userContext);
		LOGGER.debug("processSystemLogRequestMessage(String=" + message
				+ ", IUserContext=" + userContext + ") - end - return value="
				+ returnFireAndForgetReceipt);  */
		return null;
	}

	/**
	 * The purpose of this method is to process the technical log message.
	 *
	 * @param message the message
	 * @param userContext the user context
	 *
	 * @return the fire and forget receipt
	 */
	protected FireAndForgetReceipt processTechnicalLogRequestMessage(
			String message, IUserContext userContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("processTechnicalLogRequestMessage(String message="
					+ message + ", IUserContext userContext=" + userContext
					+ ") - start");
		}
		StringBuilder aBuf = new StringBuilder(TECH_PREFIX);
		aBuf.append(FIELD_DELIMITER);
		aBuf.append(message);
		LOG_PROCESSOR.execute(aBuf.toString());
		/*
		FireAndForgetReceipt returnFireAndForgetReceipt = processRequest(aBuf
				.toString(), userContext);
		LOGGER.debug("processTechnicalLogRequestMessage(String=" + message
				+ ", IUserContext=" + userContext + ") - end - return value="
				+ returnFireAndForgetReceipt);  */
		return null;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractAspect.java,v $
 *  Revision 1.4  2013/09/12 21:42:01  mwsec2
 *  enable batch journaling
 *
 *  Revision 1.3  2013/07/29 22:16:37  mwsec2
 *  disabling batch logging until after WAS7 upgrade
 *
 *  Revision 1.2  2013/06/26 21:59:50  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.3  2013/02/27 17:23:42  mwsec2
 *  comment added
 *
 *  Revision 1.1.4.2  2013/01/31 17:56:19  mwsec2
 *  edited comment
 *
 *  Revision 1.1.4.1  2013/01/17 21:00:35  mwsec2
 *  rebase from HEAD
 *
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.29  2012/09/26 21:26:06  mwpxp2
 *  Moved isValid processContext from subclass
 *
 *  Revision 1.28  2012/09/26 21:21:18  mwpxp2
 *  Added fxme; formatted
 *
 *  Revision 1.27  2012/08/14 20:30:01  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.26  2012/02/15 21:21:58  mwxxw
 *  Add logging for additional fields: officeId, techId, dlNumber and partitionId.
 *
 *  Revision 1.25  2011/10/08 00:44:11  mwxxw
 *  Change Bean name from logProcessor to logMessageProcessor.
 *
 *  Revision 1.24  2011/09/26 18:19:01  mwxxw
 *  Updated to write the log message to DB instead of MQ for performance improvement.
 *
 *  Revision 1.23  2011/06/10 21:07:07  mwyxg1
 *  clean up
 *
 *  Revision 1.22  2011/06/09 16:51:11  mwyxg1
 *  clean up
 *
 *  Revision 1.21  2011/03/23 23:38:44  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.20  2011/01/10 23:52:32  mwxxw
 *  Remove the Remove constant: DELIMITER. Use FIELD_DELIMITER instead.
 *
 *  Revision 1.19  2010/12/12 20:38:23  mwpxp2
 *  Added logging
 *
 *  Revision 1.18  2010/12/10 03:32:17  mwpxp2
 *  Renamed static to BRIDGE_REQUEST_FACTORY
 *
 *  Revision 1.17  2010/11/01 19:36:45  mwkkc
 *  Cleanup
 *
 *  Revision 1.16  2010/10/30 01:27:21  mwkkc
 *  Auditing and Logging Cleanup
 *
 *  Revision 1.15  2010/10/21 01:49:20  mwkkc
 *  Disabled Weaving of both unit and integration test cases
 *
 *  Revision 1.14  2010/10/09 01:49:40  mwkkc
 *  Removed unnecessary logs.
 *
 *  Revision 1.13  2010/09/29 19:08:24  mwkkc
 *  Fixed the issue with creating the bean.
 *
 *  Revision 1.12  2010/09/27 21:31:18  mwjxa11
 *  Updated
 *
 *  Revision 1.11  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.10  2010/07/08 01:52:14  mwpxp2
 *  Added fixmes; cleaned up
 *
 *  Revision 1.9  2010/06/22 00:05:10  mwvkm
 *  Production statistics is updated with Sign and Sign Off.
 *
 *  Revision 1.7  2010/06/14 21:15:36  mwvkm
 *  Design for fraud protection is done. Spring-aop is removed and instead using the AspectJ
 *
 *  Revision 1.6  2010/06/08 16:48:27  mwvkm
 *  Bug is fixed for session restore
 *
 *  Revision 1.5  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.4  2010/03/22 23:07:07  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2009/12/04 00:52:36  mwkkc
 *  Changed the logging Principal ID from TechID to "OriginalID.OfficeID.TechID"
 *
 *  Revision 1.2  2009/12/04 00:14:06  mwkkc
 *  Changed the logging Principal ID from TechID to "OfficeID_TechID"
 *
 *  Revision 1.1  2009/11/24 01:51:35  mwrsk
 *  Move classes from EASELogging
 *
 *  Revision 1.4  2009/11/10 18:37:37  mwakg
 *  Hack to stop logging if UserContext or ProcessContext is not present
 *
 *  Revision 1.3  2009/10/15 02:19:03  mwrsk
 *  Added PRINCIPAL_ID support
 *
 *  Revision 1.2  2009/10/05 20:58:28  mwrsk
 *  Refactor bcoz interfaces have changed in FW project
 *
 *  Revision 1.1  2009/09/28 23:00:48  mwrsk
 *  refactor code..
 *
*/
