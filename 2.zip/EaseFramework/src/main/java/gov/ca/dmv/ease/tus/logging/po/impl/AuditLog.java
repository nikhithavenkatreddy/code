package gov.ca.dmv.ease.tus.logging.po.impl;

import java.util.Date;

/**
 * Description: Persistence object for audit log
 * File: AuditLog.java
 * Module:  gov.ca.dmv.ease.tus.logging.po.impl
 * Created: Aug 12, 2009
 * 
 * @author MWAXB1
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AuditLog extends AbstractLog {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5425332423725033758L;

	/**
	 * Instantiates a new audit log.
	 */
	public AuditLog() {
		super();
	}

	/**
	 * Instantiates a new audit log.
	 * 
	 * @param logEntry the log entry
	 * @param methodClassName the method class name
	 * @param threadId the thread id
	 * @param timeStamp the time stamp
	 * @param principalId the principal id
	 */
	public AuditLog(String logEntry, String methodClassName, String threadId,
			Date timeStamp, String principalId) {
		super(logEntry, methodClassName, threadId, timeStamp, principalId);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AuditLog.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/13 16:53:29  mwrsk
 *  Logging business objects moved to impl package
 *
 *  Revision 1.11  2009/10/03 21:32:45  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.10  2009/09/22 23:39:58  mwrsk
 *  Updated Primary Key sequence names
 *
 *  Revision 1.9  2009/09/16 02:17:59  mwrsk
 *  Updated to use sequence
 *
 *  Revision 1.8  2009/09/15 00:51:01  mwrsk
 *  Updated table annotations and code cleanup
 *
 *  Revision 1.7  2009/09/15 00:49:13  mwrsk
 *  updated table annotations
 *
 *  Revision 1.6  2009/09/10 20:48:06  mwpxp2
 *  Added javadoc; bulk cleanup
 *
 *  Revision 1.5  2009/08/31 21:25:20  mwsxd10
 *  Log objects updated. (UserContext is removed)
 *
 *  Revision 1.4  2009/08/31 21:24:33  mwsxd10
 *  Log objects updated. (UserContext is removed)
 *
 *  Revision 1.3  2009/08/27 06:29:20  mwpxp2
 *  Fixed imports for fw migration to compile; bulk cleanup
 *
 *  Revision 1.2  2009/08/21 01:39:43  mwsxd10
 *  Hibernate Annotations changed for maintaining inheritance.
 *
 *  Revision 1.1  2009/08/21 00:43:11  mwsxd10
 *  Class for logging information of Audit.
 *
 */
