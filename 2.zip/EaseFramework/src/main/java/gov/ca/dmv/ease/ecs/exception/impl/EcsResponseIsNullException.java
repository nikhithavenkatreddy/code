/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: Exception to be thrown when the response from the CAMV is null.
 * File: ResponseIsNullExcpetion.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: Aug 18, 2009 
 * @author MWHXB3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsResponseIsNullException extends EcsInvalidResponseException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2498182271134335326L;

	/**
	 * Instantiates a null response exception.
	 */
	public EcsResponseIsNullException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message
	 * 
	 * @param arg0 the message
	 */
	public EcsResponseIsNullException(String message) {
		super(message);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EcsResponseIsNullException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public EcsResponseIsNullException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsResponseIsNullException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/05/26 00:47:41  mwpxp2
 *  Changed superclass
 *
 *  Revision 1.1  2010/05/25 22:09:42  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.2  2010/03/22 23:25:11  mwpxp2
 *  Inherits from EcsServiceException
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/13 20:09:05  mwhxb3
 *  updated comments.
 *
 *  Revision 1.2  2009/10/13 20:04:01  mwhxb3
 *  updated comments.
 *
 *  Revision 1.1  2009/08/19 17:22:02  mwhxb3
 *  Exception to be thrown when the response from the CAMV is null
 *
 */
