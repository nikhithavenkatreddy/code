/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

/**
 * Description: I am exception raised when camv responds with invalid response
 * File: EcsUnrecognizedResponseException.java
 * Module:  gov.ca.dmv.ease.ecs.exception.impl
 * Created: Sep 10, 2009 
 * @author MWPZS3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EcsUnrecognizedResponseException extends EcsServiceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6060063437394276855L;

	/**
	 * Instantiates a unrecognized response exception.
	 */
	public EcsUnrecognizedResponseException() {
		super();
	}

	/**
	 * The Constructor - Instantiates a new exception using a message.
	 * 
	 * @param arg0 the message
	 */
	public EcsUnrecognizedResponseException(String message) {
		super(message);
	}

	/**
	 * The Constructor - Instantiates a new exception using a message and a cause.
	 * @param message the message
	 * @param cause the Throwable cause
	 */
	public EcsUnrecognizedResponseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor - Instantiates a new exception using a cause
	 * 
	 * @param cause the Throwable cause
	 */
	public EcsUnrecognizedResponseException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EcsUnrecognizedResponseException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/05/25 22:09:41  mwpxp2
 *  Prefixed class name with "Ecs" to disambiguate short class names
 *
 *  Revision 1.2  2010/03/22 23:25:31  mwpxp2
 *  Inherits from EcsServiceException
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/13 20:11:00  mwhxb3
 *  updated comments.
 *
 *  Revision 1.2  2009/10/03 21:23:44  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.1  2009/09/11 01:37:41  mwpzs3
 *  Refactor and handling multiple payloads
 *
*/
