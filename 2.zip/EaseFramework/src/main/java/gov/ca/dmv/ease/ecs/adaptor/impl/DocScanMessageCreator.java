/**
 * 
 */
package gov.ca.dmv.ease.ecs.adaptor.impl;

import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.core.MessageCreator;


/**
 * Description: Message creator class for doc scan (FODI) messages
 * File: DocScanMessageCreator.java
 * Module:  gov.ca.dmv.ease.ecs.adaptor.impl
 * Created: Aug 8, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DocScanMessageCreator implements MessageCreator {
	
	/** Logger for this class */
	private static final Log LOGGER = LogFactory
			.getLog(DocScanMessageCreator.class);
	
	/** Request for which this Message creator is used for **/
	private IEcsRequest request;
	
	public DocScanMessageCreator (IEcsRequest aRequest) {
		request = aRequest;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.jms.core.MessageCreator#createMessage(javax.jms.Session)
	 */
	public Message createMessage(Session session) throws JMSException {
		IMessageConverter convertor = request.getMessageConverter();
		String msgCreatedByConverter = convertor.createMessage(request);
		TextMessage textMessage = session.createTextMessage(msgCreatedByConverter);
		return textMessage;
	}
}


/**
 *  Modification History:
 *
 *  $Log: DocScanMessageCreator.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/01/30 23:53:42  mwsec2
 *  FODI integration code merged to HEAD
 *
 */
