/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: I define the constants used by the EASE logging appender
 * 
 * File: IEaseLoggingAppenderConstants.java
 * Module:  gov.ca.dmv.ease.tus.logging.appender
 * Created: Sep 15, 2009
 * 
 * @author MWSXD10
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEaseLoggingConstants {
	/** The AUDIT. */
	String AUDIT_LOGGER = "AUDIT_LOGGER";
	/** The AUDI t_ prefix. */
	String AUDIT_PREFIX = "LOGTYPE=AUDIT";
	/** The CREATEd_ by. */
	String CREATED_BY = "CREATED_BY";
	/** The CREATEd_ date. */
	String CREATED_DATE = "CREATED_DATE";
	/** The FIELd_ delimiter. */
	String FIELD_DELIMITER = ",";
	/** The LOg_ entry. */
	String LOG_ENTRY = "LOG_ENTRY";
	/** The TIM e_ stamp. */
	String LOG_TIMESTAMP = "LOG_TIMESTAMP";
	/** The METHOd_ class_ name. */
	String METHOD_CLASS_NAME = "METHOD_CLASS_NAME";
	/** The NAMe_ valu e_ seperator. */
	String NAME_VALUE_SEPERATOR = "=";
	/** The PRINCIPAl id. */
	String PRINCIPAL_ID = "PRINCIPAL_ID";
	/** The SYSTE m_ management. */
	String SM_LOGGER = "SM_LOGGER";
	/** The S m_ prefix. */
	String SM_PREFIX = "LOGTYPE=SM";
	/** The LO g_ prefix. */
	String TECH_PREFIX = "LOGTYPE=TECHNICAL";
	/** The LOG. */
	String TECHNICAL_LOGGER = "TECHNICAL_LOGGER";
	/** The THREAd_ id. */
	String THREAD_ID = "THREAD_ID";
	/** The String to indicate execution time around requests. **/
	String EXECUTION_TIME_NAME = "Execution Time (nanoseconds) : ";
	/** The with in value seperator. */
	String WITH_IN_VALUE_SEPERATOR = " ; ";
	/** The maximum log payload length **/
	int LOG_ENTRY_PAYLOAD_LENGTH = 30000;
	/** The maximum IPV4 length **/
	int IPV4_LENGTH = 15;	
	/** The office id. */
	String OFFICE_ID = "OFFICE_ID";
	/** The tech id. */
	String TECH_ID = "TECH_ID";
	/** The Dl or Id number. */
	String DL_NBR = "DL_NBR";
	/** The transaction date. */
	String TRANS_DT = "TRANS_DT";
}
