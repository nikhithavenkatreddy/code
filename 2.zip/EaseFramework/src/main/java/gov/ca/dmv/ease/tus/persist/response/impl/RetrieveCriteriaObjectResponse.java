/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import org.hibernate.Criteria;

/**
 * Description: I am the response for RetrieveCriteriaObjectRequest
 *  //TODO - remove unused constructors, starting with the default
 * File: RetrieveCriteriaObjectResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Mar 22, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveCriteriaObjectResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3687732252819092875L;
	/**
	 * criteria object
	 */
	private Criteria criteria;

	/**
	 * Creates an instance of RetrieveCriteriaObjectResponse
	 * @param criteria criteria instance
	 */
	public RetrieveCriteriaObjectResponse(Criteria criteria) {
		this.criteria = criteria;
	}

	/**
	 * @param ex
	 */
	public RetrieveCriteriaObjectResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new retrieve criteria object response.
	 * 
	 * @param ex the exception
	 */
	public RetrieveCriteriaObjectResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
		this.criteria = null;
	}

	/**
	 * @param collector
	 */
	public RetrieveCriteriaObjectResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * @param collector
	 * @param anItemCount
	 */
	public RetrieveCriteriaObjectResponse(IErrorCollector collector,
			int anItemCount) {
		super(collector, anItemCount);
	}

	/**
	 * @param anItemCount
	 */
	public RetrieveCriteriaObjectResponse(int anItemCount) {
		super(anItemCount);
	}

	/**
	 * This method returns the criteria instance 
	 * @return criteria instance
	 */
	public Criteria getCriteriaInstance() {
		return criteria;
	}
}
/**
 * Modification History:
 * 
 * $Log: RetrieveCriteriaObjectResponse.java,v $
 * Revision 1.1  2012/10/01 02:57:16  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.5  2010/10/13 00:58:06  mwpxp2
 * Added constructors from super; added todo
 *
 * Revision 1.4  2010/09/01 19:07:00  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.3  2010/07/23 20:59:31  mwkfh
 * added constructor for Exception
 *
 * Revision 1.2  2010/03/23 21:14:55  mwyxg1
 * add criteria support
 *
 * Revision 1.1.2.2  2010/03/23 20:56:55  mwyxg1
 * add The Constant serialVersionUID.
 *
 * Revision 1.1.2.1  2010/03/22 15:54:21  mwakg
 * Added support for retrieving objects based on hibernate frameworks criteria object
 *
 * 
 */
