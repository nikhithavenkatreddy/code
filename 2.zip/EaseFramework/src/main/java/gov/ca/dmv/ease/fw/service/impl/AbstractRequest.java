/**
 * 
 */
package gov.ca.dmv.ease.fw.service.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.IRequest;

/**
 * Description: I am default abstract implementation of IRequest
 * File: AbstractRequest.java
 * Module:  gov.ca.dmv.ease.fw.request.impl
 * Created: Jul 9, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractRequest implements IRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3974661844943644761L;
	/** The user context. */
	private IUserContext userContext;

	/**
	 * Instantiates a new abstract request.
	 */
	protected AbstractRequest() {
		super();
	}

	/**
	 * Instantiates a new abstract request.
	 * 
	 * @param aContext the a context
	 */
	public AbstractRequest(IUserContext aContext) {
		super();
		setUserContext(aContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.user.IUserContextProvider#getUserContext()
	 */
	public IUserContext getUserContext() {
		return userContext;
	}

	/**
	 * Sets the user context.
	 * 
	 * @param aContext the new user context
	 */
	protected void setUserContext(IUserContext aContext) {
		userContext = aContext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validate()
	 */
	public IErrorCollector validate() {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		return aCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void validateUsing(IErrorCollector aCollector) {
		if (getUserContext() == null) {
			aCollector
					.register(new EaseValidationException("null user context"));
		}
		else {
			userContext.validateUsing(aCollector);
			//getValidator().validate(this.getUserContext(), aCollector);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/11/19 22:12:44  mwpxp2
 *  Fixed validateUsing for null userContext
 *
 *  Revision 1.3  2010/09/13 04:39:49  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/21 18:15:55  mwpxp2
 *  Modified validateUsing to have usercontext validate itself
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/23 17:14:57  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.3  2009/10/05 23:24:55  mwpxp2
 *  Fixed validate/0
 *
 *  Revision 1.2  2009/10/05 23:08:30  mwpxp2
 *  Modified validate
 *
 *  Revision 1.1  2009/10/03 20:26:57  mwpxp2
 *  Moved into fw.service.impl; bulk cleanup
 *
 *  Revision 1.2  2009/08/27 05:48:16  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/17 21:25:48  mwpxp2
 *  Implemented validation methods using default validator
 *
 *  Revision 1.3  2009/08/05 22:20:04  mwpxp2
 *  Added file footer for cvs
 *
 */
