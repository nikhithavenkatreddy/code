/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.response;

import java.util.Map;

/**
 * Description: I am an RetrieveOperationalModesResponse interface
 * 
 * File: IRetrieveOperationalModesResponse.java
 * Module:  gov.ca.dmv.ease.tus.auth.response
 * Created: Nov 19, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IRetrieveOperationalModesResponse extends
		IAuthAndAuthServiceResponse {
	/**
	 * Gets the operational mode map.
	 * 
	 * @return the operational mode map
	 */
	Map <String, String> getOperationalModes();
}
/**
 *  Modification History:
 *
 *  $Log: IRetrieveOperationalModesResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/11/22 22:07:40  mwkfh
 *  added RetrieveOperationalModes request and response
 *
 */
