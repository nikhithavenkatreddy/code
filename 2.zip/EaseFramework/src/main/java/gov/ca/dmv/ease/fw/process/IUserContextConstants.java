/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process;

/**
 * Description: I define constants relevant to User Context
 * The objective is to keep them in one place, potentially for further refactoring
 * The specified values are arbitrary
 * File: IUserContextConstants.java
 * Module:  gov.ca.dmv.ease.fw
 * Created: Sep 10, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2015/06/12 22:22:46 $
 * Last Changed By: $Author: mwnxg5 $
 */
public interface IUserContextConstants {
	/** DUMMY_ISSUANCE_OFFICE_ID */
	String DUMMY_ISSUANCE_OFFICE_ID = "DM1";
	/** The ECS Office Id. */
	String ECS_OFFICE_ID = "130";
	/** INV ISSU OFFICE ID */
	String INV_OFFICE_ID = "319";
	/** The ECS Tech Id. */
	String ECS_TECH_ID = "T2";
	/** The ECS User Name. */
	String ECS_USER_NAME = "ECS";
	/** The JMS Office Id. */
	String JMS_OFFICE_ID = "JMS";
	/** The JMS Tech Id. */
	String JMS_TECH_ID = "JJ";
	/** The JMS User Name. */
	String JMS_USER_NAME = "JMS";
	/** The Logging Office Id. */
	String LOGGING_OFFICE_ID = "LOG";
	/** The Logging Tech Id. */
	String LOGGING_TECH_ID = "LL";
	/** The Logging TTC. */
	String LOGGING_TTC = "LOG";
	/** The Logging User Name. */
	String LOGGING_USER_NAME = "LOG";
	/** The camera role */
	String CAMERA_ROLE = "DL_CAMERA";
}
/**
 *  Modification History:
 *
 *  $Log: IUserContextConstants.java,v $
 *  Revision 1.2  2015/06/12 22:22:46  mwnxg5
 *  INV ISSU for EASE
 *
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/10/26 17:07:28  mwhys
 *  Moved ISSUANCE_ROLE_FOR_ISSUANCE_OFFICE to IAuthAndAuthConstants.
 *
 *  Revision 1.7  2011/09/02 00:50:20  mwxxw
 *  Add new constant: CAMERA_ROLE.
 *
 *  Revision 1.6  2011/01/07 18:52:31  mwxxw
 *  Add new constant: ISSUANCE_ROLE_FOR_ISSUANCE_OFFICE.
 *
 *  Revision 1.5  2010/11/09 20:24:34  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/09/21 18:52:35  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
 *  Revision 1.3.6.1  2010/09/16 20:43:33  mwpxr4
 *  Added constants related to Default JMS user context.
 *
 *  Revision 1.3  2010/09/01 19:03:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/07/10 00:36:26  mwhxb3
 *  Added DUMMY_ISSUANCE_OFFICE_ID.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/11/05 19:44:58  mwrrv3
 *  Changed the default office id value.
 *
 *  Revision 1.3  2009/11/04 18:27:21  mwrrv3
 *  Changed the default office id.
 *
 *  Revision 1.2  2009/10/16 01:31:28  mwhxa2
 *  Added valid comments
 *
 *  Revision 1.1  2009/10/03 20:23:26  mwpxp2
 *  Moved into fw.process; bulk cleanup
 *
 *  Revision 1.3  2009/09/10 21:43:29  mwpxp2
 *  Replaced "default" with "ecs" in constant names
 *
 *  Revision 1.2  2009/09/10 21:31:16  mwpxp2
 *  Added entries; copyright notice
 *
 *  Revision 1.1  2009/09/10 21:28:12  mwpxp2
 *  Initial
 *
 */
