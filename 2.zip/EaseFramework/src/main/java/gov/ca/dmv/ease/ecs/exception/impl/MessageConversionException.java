/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseConversionException;

/**
 * Description: The MessageConversionException class extends SystemException. The exception should be thrown if error occurs while message conversion process.
 * File: MessageConversionException.java
 * Module:  gov.ca.dmv.ease.ecs.exceptions
 * Created: Jul 8, 2009 
 * @author MWAZD1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MessageConversionException extends EaseConversionException {
	/** The serialVersionUID */
	private static final long serialVersionUID = -5625961830192858775L;

	/**
	 * The constructor instantiates this exception.
	 */
	public MessageConversionException() {
		super();
	}

	/**
	 * The constructor instantiates this exception.
	 * @param cause the exception cause.
	 */
	public MessageConversionException(Exception cause) {
		super(cause);
	}

	/**
	 * The constructor instantiates this exception using a message.
	 * @param message the String message.
	 */
	public MessageConversionException(String message) {
		super(message);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: MessageConversionException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/03/23 21:09:17  mwpxp2
 *  Changed super to EaseConversionException
 *
 *  Revision 1.2  2010/03/22 23:24:10  mwpxp2
 *  Inherits from EaseConverterException
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/13 19:55:50  mwhxb3
 *  updated comments.
 *
 *  Revision 1.4  2009/07/27 23:17:27  mwcsj3
 *  *** empty log message ***
 *
 *  Revision 1.3  2009/07/27 23:15:59  mwcsj3
 *  Updated SystemException package
 *
 *  Revision 1.2  2009/07/16 01:55:25  mwpxp2
 *  Bulk cleanup, incl javadoc
 *
 *  Revision 1.1  2009/07/14 23:58:49  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-13 02:08:25  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
*/
