/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am superclass for exceptions related to BOs
 * File: EaseBusinessObjectException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Sep 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseBusinessObjectException extends EaseLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7694478538079319807L;

	/**
	 * Instantiates a new ease business object exception.
	 */
	public EaseBusinessObjectException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseBusinessObjectException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseBusinessObjectException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseBusinessObjectException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseBusinessObjectException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/22 20:34:41  mwpxp2
 *  Initial
 *
 */
