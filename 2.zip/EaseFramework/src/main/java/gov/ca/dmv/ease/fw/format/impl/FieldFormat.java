/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.format.FieldValueType;
import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.IPayloadSampleProducer;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;

/**
 * Description: I am default implementation of IFieldFormat
 * File: FieldFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class FieldFormat implements IFieldFormat {
	/** The RANDOMIZER. */
	protected static IPayloadSampleProducer PRODUCER = new PayloadSampleProducer();
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2173114221164530979L;

	/**
	 * Gets the random char.
	 * 
	 * @param random 
	 * @param aStart 
	 * @param anEnd 
	 * 
	 * @return the random char
	 */
	protected static char getRandomChar(int random, int aStart, int anEnd) {
		int result = aStart + random;
		int delta = random;
		while (result > anEnd) {
			delta = delta / 2;
			result = aStart + delta;
		}
		return (char) result;
	}

	/**
	 * Gets the random digit.
	 * 
	 * @param random 
	 * 
	 * @return the random digit
	 */
	protected static char getRandomDigit(int random) {
		//48-57
		return getRandomChar(random, 48, 57);
	}

	/**
	 * Gets the random upper case char.
	 * 
	 * @param random 
	 * 
	 * @return the random upper case char
	 */
	protected static char getRandomUpperCaseChar(int random) {
		//65-90
		return getRandomChar(random, 65, 90);
	}

	/** The field name. */
	private String fieldName;
	/** The length. */
	private int length = -1;
	/** The start pos. */
	private int startPos = -1;

	/**
	 * Instantiates a new field format.
	 * 
	 * @param aStartPos 
	 * @param aLen 
	 */
	public FieldFormat(int aStartPos, int aLen) {
		super();
		setStartPos(aStartPos);
		setLength(aLen);
	}

	/**
	 * Instantiates a new field format.
	 * 
	 * @param aStartPos 
	 * @param aLen 
	 */
	public FieldFormat(int aStartPos, int aLen, String aName) {
		super();
		setStartPos(aStartPos);
		setLength(aLen);
		setFieldName(aName);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomCorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IFieldFormat)
	 */
	public String createRandomCorrectPayloadUsing(IFieldFormat aFormat) {
		return PRODUCER.createRandomCorrectPayloadUsing(aFormat);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomCorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IMessageFormat)
	 */
	public String createRandomCorrectPayloadUsing(IMessageFormat aFormat) {
		return PRODUCER.createRandomCorrectPayloadUsing(aFormat);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomIncorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IFieldFormat)
	 */
	public String createRandomIncorrectPayloadUsing(IFieldFormat aFormat) {
		return PRODUCER.createRandomIncorrectPayloadUsing(aFormat);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createRandomIncorrectPayloadUsing(gov.ca.dmv.ease.fw.format.IMessageFormat)
	 */
	public String createRandomIncorrectPayloadUsing(IMessageFormat aFormat) {
		return PRODUCER.createRandomIncorrectPayloadUsing(aFormat);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IPayloadSampleProducer#createStringNotEqualTo(java.lang.String)
	 */
	public String createStringNotEqualTo(String allowedValue) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Gets the size.
	 * 
	 * @return the size
	 */
	public int getEndPos() {
		if (startPos < 0 || length < 0) {
			return 0;
		}
		else {
			return startPos + length;
		}
	}

	/**
	 * 
	 * 
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getLength()
	 */
	public int getLength() {
		return length;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomCorrectSample()
	 */
	public String getRandomCorrectSample() {
		return PRODUCER.createRandomCorrectPayloadUsing(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getRandomIncorrectSample()
	 */
	public String getRandomIncorrectSample() {
		return PRODUCER.createRandomIncorrectPayloadUsing(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getStartPos()
	 */
	public int getStartPos() {
		return startPos;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#getType()
	 */
	public FieldValueType getType() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 
	 * 
	 * @param fieldName the fieldName to set
	 */
	protected void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * 
	 * 
	 * @param length the length to set
	 */
	protected void setLength(int length) {
		this.length = length;
	}

	/**
	 * 
	 * 
	 * @param aPos 
	 */
	protected void setStartPos(int aPos) {
		startPos = aPos;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		if (getFieldName() != null) {
			aBuilder.append(getFieldName()).append(": ");
		}
		aBuilder.append(getStartPos()).append(',');
		aBuilder.append(getLength()).append(',');
		if (getFieldName() != null) {
			aBuilder.append(',').append(getFieldName());
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#validate(java.lang.String)
	 */
	public IErrorCollector validate(String aField) {
		IErrorCollector aCollector = new ErrorCollector();
		validate(aField, aCollector);
		return aCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#validate(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void validate(String aField, IErrorCollector aCollector) {
		if (aField == null) {
			aCollector.register(new FormatValidationException(
					"null field value"));
			return;
		}
		int aSize = aField.length();
		if (aSize != getLength()) {
			aCollector.register(new FormatValidationException(
					"Unexpected field length; should be: " + getLength()
							+ " is: " + aSize));
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IFieldFormat#validateInMessage(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void validateInMessage(String aMessage, IErrorCollector aCollector) {
		int aSize = aMessage.length();
		if (aSize < getStartPos() + getLength()) {
			aCollector.register(new FormatValidationException(
					"Expected length of " + getStartPos() + getLength()
							+ " got: " + aSize + " in: " + this));
			return;
		}
		String aField = aMessage.substring(getStartPos(), getStartPos()
				+ getLength());
		validate(aField, aCollector);
	}

	/**
	 * Parses the payload.
	 * 
	 * @param aMessagePayload 
	 * @param aBuilder 
	 */
	public void parsePayload(String aMessagePayload, StringBuilder aBuilder) {
		String aFieldValue = aMessagePayload.substring(getStartPos(),
				getEndPos());
		aBuilder.append(this).append(": ").append(aFieldValue);
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2010/12/16 03:18:28  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.12  2010/12/14 02:45:46  mwpxp2
 *  Added static utilities for random output production
 *
 *  Revision 1.11  2010/12/12 08:26:55  mwpxp2
 *  Modified exception messages to inclue receiver
 *
 *  Revision 1.10  2010/12/01 02:37:40  mwpxp2
 *  Added constructors
 *
 *  Revision 1.9  2010/12/01 01:51:34  mwpxp2
 *  Adjusted refs to sample producer
 *
 *  Revision 1.8  2010/12/01 01:37:44  mwpxp2
 *  Added stubs for producing samples
 *
 *  Revision 1.7  2010/12/01 01:22:50  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.6  2010/11/25 01:32:50  mwpxp2
 *  Moved type-related methods to proper subclasss
 *
 *  Revision 1.5  2010/11/25 00:53:28  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.4  2010/11/24 20:40:17  mwpxp2
 *  Added fieldName, refactored type down
 *
 *  Revision 1.3  2010/11/20 23:07:57  mwpxp2
 *  Added getEndPos/0
 *
 *  Revision 1.2  2010/11/20 22:21:59  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.1  2010/11/20 21:32:12  mwpxp2
 *  Initial
 *
 */
