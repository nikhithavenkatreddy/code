/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.CashierTransactionIdResponse;

/**
 * Description: I am a request to obtain _incremented_ cashier transaction id
 * by using the information in the user context
 * File: CashierTransactionIdRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CashierTransactionIdRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -146841314762310719L;

	/**
	 * Gets the business object class name.
	 * 
	 * @return the business object class name
	 */
	public static String getBusinessObjectClassName() {
		//note: temporary
		// FIXME not good - the BO should be moved to Architecture!
		return "gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl";
	}

	/**
	 * 
	 * 
	 * @param userContext 
	 */
	public CashierTransactionIdRequest(IUserContext userContext) {
		super(userContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public CashierTransactionIdResponse execute() {
		return getPersistenceService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: CashierTransactionIdRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/03/21 20:54:44  mwsec2
 *  fixme added
 *
 *  Revision 1.1  2010/12/15 02:58:58  mwpxp2
 *  Initial
 *
 */
