/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.convert.util.impl;

import gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.fw.validate.impl.AbstractValidator;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.context.MessageSource;

/**
 * Description: I have helper methods used in ecs converters
 * File: ConverterHelper.java
 * Module: gov.ca.dmv.ease.ecs.convert.util.impl
 * Created: May 29, 2010
 * 
 * @author MWTJC1
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/05/29 16:49:10 $
 * Last Changed By: $Author: mwskh1 $
 */
public class EcsConverterHelper {
	/** The BLANK. */
	private static final String BLANK = "";
	/** The commercial license classes. */
	private static final List <String> COMML_LIC_CLASSES = Arrays.asList(
			"A", "B", "C");
	/** The driver license application ttc. */
	private static final List <String> DRIVER_LIC_APP_TTC = Arrays
			.asList("DLA", "DLD", "DLE", "DLC", "DLP", "DRT");
	/** The EMPTY_FILLER. */
	public static final char EMPTY_FILLER = ' ';
	/** The Fee Issue Indicator Values. */
	private static final List <String> FEE_ISSUE_IND = Arrays.asList("0", "1",
			"2", "3", "4", "5", "6", "7", "8", "9");
	/** The FORMATTER_CCYY_MM_DD. */
	public static final String FORMATTER_CCYY_MM_DD = "yyyyMMdd";
	/** The FORMATTER_DD_MMM_YY. */
	public static final String FORMATTER_DD_MMM_YY = "dd-MMM-yy";
	/** The FORMATTER_HH_mm. */
	public static final String FORMATTER_HH_COLON_MM = "HH:mm";
	/** The FORMATTER_HH_MM. */
	public static final String FORMATTER_HH_MM = "HHmm";
	/** The FORMATTER_HH_MM_SS. */
	public static final String FORMATTER_HH_MM_SS = "HHmmss";
	/** The FORMATTER_MM_DD. */
	public static final String FORMATTER_MM_DASH_DD = "MM-dd";
	/** The FORMATTER_MM_DD. */
	public static final String FORMATTER_MM_DD = "MMdd";
	/** The FORMATTER_MM_DD_YYYY. */
	public static final String FORMATTER_MM_DD_CCYY = "MM-dd-yyyy";
	/** The FORMATTER_MM_DD_YY. */
	public static final String FORMATTER_MM_DASH_DD_DASH_YY = "MM-dd-yy";
	/** The FORMATTER_MM_DD_YY. */
	public static final String FORMATTER_MM_DD_YY = "MMddyy";
	/** The FORMATTER_MM_DD_YYCC. */
	public static final String FORMATTER_MM_DD_YYCC = "MMddyyyy";
	/** The FORMATTER_MMDDYYYY_HHMMSS. */
	public static final String FORMATTER_MMDDYYYY_HHMMSS = "MMddyyyy HHmmss";
	/** The FORMATTER_MM_HYPHEN_DD_HYPHEN_CCYY. */
	public static final String FORMATTER_MM_HYPHEN_DD_HYPHEN_CCYY = "MM-dd-yyyy";
	/** The FORMATTER_MM_SLASH_DD_SLASH_CCYY. */
	public static final String FORMATTER_MM_SLASH_DD_SLASH_CCYY = "MM/dd/yyyy";
	/** The FORMATTER_MM_SLASH_DD_SLASH_YY. */
	public static final String FORMATTER_MM_SLASH_DD_SLASH_YY = "MM/dd/yy";
	/** The FORMATTER_MM_YY. */
	public static final String FORMATTER_MM_YY = "MMyy";
	/** The FORMATTER_YY. */
	public static final String FORMATTER_YY = "yy";
	/** The FORMATTER_YY_MM_DD. */
	public static final String FORMATTER_YY_MM_DD = "yyMMdd";
	/** The HYPEN. */
	public static final String HYPEN = "-";
	/** The identification card application ttc. */
	private static final List <String> ID_CARD_APPLICATION_TTC = Arrays.asList(
			"IDA", "IDS", "IDC", "IDP", "IRT");
	/** The non commercial license classes. */
	private static final List <String> NON_COMML_LIC_CLASSES = Arrays.asList(
			"D", "E", "F", "M");
	/** The EMPTY_PADDING. */
	public static final String PAD = " ";
	/** The PAD_LEFT. */
	public static final int PAD_LEFT = 01;
	/** The PAD_RIGHT. */
	public static final int PAD_RIGHT = 02;
	/** The RISU/LPVU Issuance office ids. */
	private static final List <String> RISU_LPV_ISSUANCE_OFFICE_IDS = Arrays
			.asList("225", "230");
	/** The salesperson license application. */
	private static final List <String> SP_LIC_APP_TTC = Arrays.asList("SPO",
			"SPR", "SRX", "SPD", "SPC");

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	public static String convertDateToString(Date date) {
		String returnString = convertDateToString(date, FORMATTER_MM_DD_YY);
		return returnString;
	}
	
	/**
	 * Converts date to string in a MM_DD_YYYY format.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	public static String convertDateToStringMM_DD_YYYY(Date date) {
		String returnString = convertDateToString(date, FORMATTER_MM_DD_YYCC);
		return returnString;
	}

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * @param format the format
	 * 
	 * @return the string
	 */
	public static String convertDateToString(Date date, String format) {
		if (date == null) {
			return BLANK;
		}
		DateFormat formatter = new SimpleDateFormat(format);
		StringBuilder sDate = new StringBuilder(formatter.format(date));
		String returnString = sDate.toString();
		return returnString;
	}

	/**
	 * This method formats the Endorsements.
	 * 
	 * @param endorsements the Existing Endorsements
	 * 
	 * @return formatted endorsements
	 */
	public static String convertEndorsements(List <CodeSetElement> endorsements) {
		String formattedEndorsements = BLANK;
		if (!EaseUtil.isNullOrBlank(endorsements)) {
			for (CodeSetElement endorsement : endorsements) {
				if (EaseUtil.isNullOrBlank(endorsement)) {
					formattedEndorsements += HYPEN;
				}
				else {
					formattedEndorsements += endorsement.getCode();
				}
			}
		}
		return formattedEndorsements;
	}

	/**
	 * Convert string to date.
	 * 
	 * @param date the date
	 * 
	 * @return the date
	 */
	public static Date convertStringToDate(String date) {
		return convertStringToDate(date, FORMATTER_MM_DD_YY);
	}

	/**
	 * Converts string to date.
	 * 
	 * @param date the date
	 * @param format the format
	 * 
	 * @return the date
	 */
	public static Date convertStringToDate(String date, String format) {
		if (isNullOrBlank(date) || (date = date.trim()).matches("[0]*")) {
			return null;
		}
		DateFormat formatter = new SimpleDateFormat(format);
		try {
			Date returnDate = formatter.parse(date);
			return returnDate;
		}
		catch (ParseException e) {
			return null;
		}
	}

	/**
	 * Convert string to integer.
	 * 
	 * @param str the str
	 * 
	 * @return the integer
	 */
	public static Integer convertStringToInteger(String str) {
		if (isNullOrBlank(str)) {
			return null;
		}
		try {
			return new Integer(str);
		}
		catch (NumberFormatException e) {
			return null;
		}
	}

	/**
	 * The Filler.
	 * 
	 * @param string the string
	 * @param expectedLength the expected length
	 * 
	 * @return returnString the string
	 */
	public static String filler(String string, int expectedLength) {
		if (string == null) {
			string = PAD;
		}
		String returnString = filler(string, expectedLength, EMPTY_FILLER);
		return returnString;
	}

	/**
	 * Pads a given string with spaces to generate a fixed length String.
	 * This method also removes the extra characters if the string length
	 * is greater the expected length.
	 * 
	 * @param expectedLength int specifying the length of the String
	 * @param replaceChar Character to be replaced
	 * @param inputString the input string
	 * 
	 * @return String padded string
	 */
	public static String filler(String inputString, int expectedLength,
			char replaceChar) {
		String returnString = filler(inputString, expectedLength, replaceChar,
				PAD_RIGHT);
		return returnString;
	}

	/**
	 * The Filler.
	 * 
	 * @param inputString the input string
	 * @param expectedLength the expected length
	 * @param replaceChar the replace char
	 * @param justification the justification
	 * 
	 * @return the string
	 */
	public static String filler(String inputString, int expectedLength,
			char replaceChar, int justification) {
		StringBuilder stringBuilder = null;
		if (inputString != null) {
			if (inputString.length() > expectedLength) {
				inputString = inputString.substring(0, expectedLength);
			}
		}
		else if (inputString == null) {
			inputString = BLANK;
		}
		int paddingNeeded = expectedLength - inputString.length();
		if (paddingNeeded <= 0) {
			return inputString;
		}
		char padding[] = new char[paddingNeeded];
		java.util.Arrays.fill(padding, replaceChar);
		stringBuilder = new StringBuilder(expectedLength);
		if (justification == PAD_LEFT) {
			stringBuilder.append(padding);
			stringBuilder.append(inputString);
		}
		else if (justification == PAD_RIGHT) {
			stringBuilder.append(inputString);
			stringBuilder.append(padding);
		}
		String returnString = stringBuilder.toString();
		return returnString;
	}

	/**
	 * Gets the code set element.
	 * 
	 * @param codeSetname the code set name
	 * @param codeSetElementCode the code set element code
	 * @param codeSetRegistrySingleton the code set registry singleton
	 * 
	 * @return the code set element
	 */
	public static CodeSetElement getCodeSetElement(String codeSetname,
			String codeSetElementCode,
			ICodeSetRegistrySingleton codeSetRegistrySingleton) {
		if (isNull(codeSetname)) {
			return null;
		}
		CodeSetElement codeSetElement = null;
		try {
			return (CodeSetElement) codeSetRegistrySingleton.getCodeSetElement(
					codeSetname, codeSetElementCode);
		}
		catch (EaseValidationException e) {// TODO: remove try-catch after all the codesets are added in database
			codeSetElement = null;
		}
		if (!isNullOrBlank(codeSetElementCode)) {// TODO: remove this if condition after all the codesets are added in database
			codeSetElement = new CodeSetElement(null,
					codeSetElementCode.trim(), null);
		}
		return codeSetElement;
	}

	/**
	 * Gets the message from resource bundle.
	 * 
	 * @param key the key
	 * @param ecsMessageSources the ecs message sources
	 * 
	 * @return the message from resource bundle
	 */
	public static String getMessageFromResourceBundle(
			MessageSource ecsMessageSources, String key) {
		return getMessageFromResourceBundleWithDefaultMessage(
				ecsMessageSources, key, BLANK).trim();
	}

	/**
	 * Gets the message from resource bundle with default message.
	 * 
	 * @param key the key
	 * @param defaultMsg the default msg
	 * @param ecsMessageSources the ecs message sources
	 * 
	 * @return the message from resource bundle with default message
	 */
	public static String getMessageFromResourceBundleWithDefaultMessage(
			MessageSource ecsMessageSources, String key, String defaultMsg) {
		return ecsMessageSources.getMessage(key, null, defaultMsg, null);
	}

	/**
	 * Gets the message from resource bundle with parameters and default message.
	 * 
	 * @param key the key
	 * @param parameter the parameter
	 * @param defaultMsg the default msg
	 * @param ecsMessageSources the ecs message sources
	 * 
	 * @return the message from resource bundle with parameters and default message
	 */
	public static String getMessageFromResourceBundleWithParametersAndDefaultMessage(
			MessageSource ecsMessageSources, String key, String[] parameter,
			String defaultMsg) {
		return ecsMessageSources.getMessage(key, parameter, defaultMsg, null);
	}

	/**
	 * Checks if a given list of license class has any commercial license class.
	 * 
	 * @param licenseClasses the license classes to check
	 * 
	 * @return true, if any class is a commercial license class
	 */
	public static boolean isAnyCommercialLicenseClassExist(
			List <CodeSetElement> licenseClasses) {
		if (!EaseUtil.isNullOrBlank(licenseClasses)) {
			for (CodeSetElement licenseClass : licenseClasses) {
				if (isComercialLicenseClass(licenseClass.getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if Applicant is below 18.
	 * 
	 * @param birthDate the Birth Date
	 * 
	 * @return true if below 18
	 */
	public static boolean isApplicantBelow18(Date birthDate) {
		return new Date().after(DateUtils.addYears(birthDate, 18)) ? true
				: false;
	}

	/**
	 * Checks if is blank.
	 * 
	 * @param str the str
	 * 
	 * @return true, if is blank
	 */
	public static boolean isBlank(String str) {
		boolean returnboolean = (str.trim().length() == 0);
		return returnboolean;
	}

	/**
	 * Checks if a given license class belongs to a commercial license class.
	 * 
	 * @param licenseClass the license class to check
	 * 
	 * @return true, if it is a commercial license class
	 */
	public static boolean isComercialLicenseClass(String licenseClass) {
		return (COMML_LIC_CLASSES.indexOf(licenseClass) >= 0) ? true
				: false;
	}

	/**
	 * Checks if a given TTC belongs to the driver license application type.
	 * 
	 * @param businessProcessCode the business process code
	 * 
	 * @return true, if given ttc belongs to the driver license application ttc.
	 */
	public static boolean isDriverLicenseApplicationTtc(
			String businessProcessCode) {
		return (DRIVER_LIC_APP_TTC.indexOf(businessProcessCode) >= 0) ? true
				: false;
	}

	/**
	 * Checks if a given fee indicator belongs to fee indicators.
	 * 
	 * @param indicator a fee indicator
	 * 
	 * @return true, if it is a fee indicator
	 */
	public static boolean isFeeIndicator(String indicator) {
		return (FEE_ISSUE_IND.indexOf(indicator) >= 0) ? true : false;
	}

	/**
	 * Checks if a given TTC belongs to the Identification card application type.
	 * 
	 * @param businessProcessCode the business process code
	 * 
	 * @return true, if given ttc belongs to the Identification card application ttc.
	 */
	public static boolean isIdentificationCardApplicationTtc(
			String businessProcessCode) {
		return (ID_CARD_APPLICATION_TTC
				.indexOf(businessProcessCode) >= 0) ? true : false;
	}

	/**
	 * Checks if a given license class belongs to a non commercial license class.
	 * 
	 * @param licenseClass the license class to check
	 * 
	 * @return true, if it is a non commercial license class
	 */
	public static boolean isNonComercialLicenseClass(String licenseClass) {
		return (NON_COMML_LIC_CLASSES.indexOf(licenseClass) >= 0) ? true
				: false;
	}

	/**
	 * Checks if object is null.
	 * 
	 * @param obj the obj
	 * 
	 * @return true, if is null
	 */
	public static boolean isNull(Object obj) {
		if (obj == null) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Checks if is null or blank.
	 * 
	 * @param anObject the an object
	 * 
	 * @return true, if is null or blank
	 */
	public static boolean isNullOrBlank(Object anObject) {
		return AbstractValidator.isNullOrBlank(anObject);
	}

	/**
	 * Checks if is numeric.
	 * 
	 * @param str the str
	 * 
	 * @return true, if is numeric
	 */
	public static boolean isNumeric(String str) {
		if (!isNullOrBlank(str) && StringUtils.isNumeric(str)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if is risu or lpv issuance office.
	 * 
	 * @param officeId the office id
	 * 
	 * @return true, if is risu or lpv issuance office
	 */
	public static boolean isRisuOrLpvIssuanceOffice(String officeId) {
		return (RISU_LPV_ISSUANCE_OFFICE_IDS.indexOf(officeId) >= 0) ? true
				: false;
	}

	/**
	 * Checks if a given TTC belongs to the Salesperson License application type.
	 * 
	 * @param businessProcessCode the business process code
	 * 
	 * @return true, if given ttc belongs to the Salesperson License application ttc.
	 */
	public static boolean isSalespersonLicenseApplicationTtc(
			String businessProcessCode) {
		return (SP_LIC_APP_TTC
				.indexOf(businessProcessCode) >= 0) ? true : false;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EcsConverterHelper.java,v $
 *  Revision 1.2  2013/05/29 16:49:10  mwskh1
 *  CDLIS 5.2 - Code merge into HEAD
 *
 *  Revision 1.1.6.1  2013/04/17 21:13:12  mwgxd3
 *  CDLIS - add MMDDYYYY formatting
 *
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.20  2012/08/14 20:32:00  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.19  2012/03/24 00:14:11  mwxxw
 *  Add FORMATTER_MMDDYYYY_HHMMSS.
 *
 *  Revision 1.18  2011/06/09 22:40:02  mwyxg1
 *  clean up
 *
 *  Revision 1.17  2011/06/08 23:51:00  mwyxg1
 *  PMD sev 2 fix, return inside catch
 *
 *  Revision 1.16  2010/12/10 19:33:57  mwhxb3
 *  Code to interface not implementation, used ICodeSetRegistrySingleton.
 *
 *  Revision 1.15  2010/12/02 00:14:58  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.14  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.13  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.12  2010/06/22 00:34:20  mwhxa2
 *  Added isApplicantBelow18()
 *
 *  Revision 1.11  2010/06/22 00:24:06  mwhxa2
 *  Added convertEndorsements()
 *
 *  Revision 1.10  2010/06/21 23:00:45  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.2.2  2010/06/20 18:06:56  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.9  2010/06/08 01:20:16  mwtjc1
 *  getCodeSetElement added
 *
 *  Revision 1.8  2010/06/07 21:49:15  mwtjc1
 *  isNullOrBlank modified
 *
 *  Revision 1.7  2010/06/07 21:48:25  mwtjc1
 *  isNullOrBlank modified
 *
 *  Revision 1.6  2010/06/07 18:47:23  mwtjc1
 *  made getMessageFromResource related methods static
 *
 *  Revision 1.5  2010/06/07 18:46:10  mwtjc1
 *   getMessageFromResource related methods are added
 *
 *  Revision 1.4  2010/06/03 20:18:40  mwtjc1
 *  FORMATTER_MM_HYPHEN_DD_HYPHEN_CCYY updated
 *
 *  Revision 1.3  2010/06/03 20:17:22  mwtjc1
 *  FORMATTER_MM_HYPHEN_DD_HYPHENCCYY added
 *
 *  Revision 1.2  2010/05/29 19:07:38  mwtjc1
 *  created date changed
 *
 *  Revision 1.1  2010/05/29 19:07:15  mwtjc1
 *  first commit
 *
 */
