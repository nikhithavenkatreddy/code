/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.response.impl;

import gov.ca.dmv.ease.ecs.ITimeoutCapable;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.util.Date;

/**
 * Description: Common superclass for asynchronous interaction results,
 * Groups commonalities of responses and promises.
 * File: AbstractAsynchronousResponse.java
 * Module:  gov.ca.dmv.ease.ecs.response.impl
 * Created: 09/05/2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractAsynchronousResponse extends AbstractEcsResponse
		implements ITimeoutCapable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2036663556147398070L;
	/** The expiration timestamp. */
	protected long absoluteExpirationTimestamp = UNDEF_EXPIRATION;
	/** The correlation id. */
	private String correlationId;

	/**
	 * Instantiates a new abstract asynchronous response.
	 */
	public AbstractAsynchronousResponse() {
		super();
	}

	/**
	 * Instantiates a new abstract asynchronous response.
	 */
	public AbstractAsynchronousResponse(IErrorCollector errorCollector) {
		super(errorCollector);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.ITimeoutCapable#getAbsoluteExpirationTimestamp()
	 */
	public long getAbsoluteExpirationTimestamp() {
		return absoluteExpirationTimestamp;
	}

	/**
	 * Gets the correlation id.
	 * 
	 * @return the correlation id
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * Checks for timed out.
	 * 
	 * @return true, if successful
	 */
	public boolean hasTimedOut() {
		boolean returnboolean = (new Date()).getTime() > getAbsoluteExpirationTimestamp();
		return returnboolean;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#isAsynchronousResponse()
	 */
	@Override
	public final boolean isAsynchronousResponse() {
		return true;
	}

	/**
	 * Sets the correlation id.
	 * 
	 * @param correlationId the new correlation id
	 */
	protected void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.response.impl.AbstractEcsResponse#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("correlationId", correlationId, anIndent, aBuilder);
		outputKeyValue("absoluteExpirationTimestamp",
				absoluteExpirationTimestamp, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractAsynchronousResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/12 05:50:41  mwpxp2
 *  Added toStringOn/2
 *
 *  Revision 1.3  2010/11/09 04:34:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/09/24 00:21:29  mwpxr4
 *  Added constructor with error collector
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.10  2009/10/14 18:03:20  mwhxb3
 *  updated comments
 *
 *  Revision 1.9  2009/10/07 03:34:19  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.8  2009/10/07 02:57:53  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.7  2009/10/06 21:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6.8.2  2009/10/06 20:54:07  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6.8.1  2009/10/06 20:28:49  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6  2009/08/21 01:17:09  mwpxp2
 *  Added correlationId property and accessors
 *
 *  Revision 1.5  2009/08/10 22:51:52  mwpxp2
 *  Added logging
 *
 *  Revision 1.4  2009/08/05 01:44:19  mwpxp2
 *  Used absoluteExpirationTimestamp rather than expirationTime
 *
 *  Revision 1.3  2009/08/05 01:25:42  mwpxp2
 *  Added getAbsoluteExpirationTimestamp
 *
 *  Revision 1.2  2009/07/27 18:30:38  mwpxp2
 *  Adjusted imports and super  for renames
 *
 *  Revision 1.1  2009/07/14 23:58:48  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-13 02:10:05  ppalacz
 *  Import cleanup
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.8  2009-05-18 21:00:01  ppalacz
 *  Added ITimeoutCapable
 *
 *  Revision 1.7  2009-05-18 20:29:34  ppalacz
 *  Bulk cleanup
 *
 *  Revision 1.6  2009-05-13 20:29:53  ppalacz
 *  Added isPersistedToken/0
 *
 *  Revision 1.5  2009-05-13 02:21:39  ppalacz
 *  Added isAsynchronousResponse
 *
 *  Revision 1.4  2009-05-12 22:21:49  ppalacz
 *  Bulk formatting
 *
 *  Revision 1.3  2009-05-11 19:43:32  ppalacz
 *  Javadoc cleanup
 *
 *  Revision 1.2  2009-05-11 17:56:37  ppalacz
 *  Cleanup
 *
 *  Revision 1.1  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
*/
