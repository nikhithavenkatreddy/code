/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.IBusinessObjectValueExtractor;
import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;

/** 
 * Description: Class BusinessObject is root of business objects hierarchy. 
 * Every business object class has BusinessObject as a superclass. All the common 
 * attributes of business objects like created by, created date, 
 * modified by and modified date are encapsulated in BusinessObjects.
 * 
 *  //TODO - move tree printing code to a dedicated printer class.
 *  
 * File: BusinessObject.java
 * Module: gov.ca.dmv.ease.bo.impl
 * Created: May 4, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:50 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class BusinessObject implements IBusinessObject {
	private static final String TRIPLE_DOTS = "...";
	/** The COMMA. */
	protected static final char COMMA = ',';
	/** The COMMACRTAB. */
	protected static final String COMMACRTAB = ",\n\t";
	/** The CRTAB. */
	protected static final String CRTAB = "\n\t";
	/** The Constant CURRENCY_FORMAT. */
	protected static final NumberFormat CURRENCY_FORMAT = NumberFormat
			.getCurrencyInstance(Locale.US);
	protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
			"MMddyyyy");
	/** The Constant INDENT. */
	private static final String INDENT = "  ";
	/** The Constant QUOTE. */
	private static final char QUOTE = '\"';
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1269068862938144044L;

	/**
	 * Gets the string prefix for.
	 * 
	 * @param index 
	 * 
	 * @return the string prefix for
	 */
	private static String getStringPrefixFor(int index) {
		return Integer.toString(index) + ". ";
	}

	/**
	 * Output collection.
	 * 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 * @param addCr 
	 */
	protected static void outputCollection(Collection <?> aValue, int anIndent,
			StringBuilder aBuilder, boolean addCr) {
		outputIndent(anIndent + 1, aBuilder, true);
		aBuilder.append(aValue.getClass().getSimpleName()).append(" {");
		if (aValue.isEmpty()) {
			aBuilder.append("}");
			return;
		}
		else {
			int index = 0;
			String aPrefixString;
			for (Object anElem : aValue) {
				if (anElem instanceof ITreePrintable) {
					outputIndent(anIndent + 1, aBuilder, true);
					aPrefixString = getStringPrefixFor(index);
					outputTreePrintable((ITreePrintable) anElem, anIndent + 1,
							aBuilder, true, aPrefixString);
				}
				else {
					if (anElem instanceof Collection <?>) {
						outputCollection((Collection <?>) anElem, anIndent + 1,
								aBuilder, addCr);
					}
					else {
						aBuilder.append(anElem);
					}
				}
				index++;
			}
		}
		outputIndent(anIndent + 1, aBuilder, true);
		aBuilder.append("}");
	}

	/**
	 * Output indent.
	 * 
	 * @param anIndent 
	 * @param aBuilder 
	 * @param addCr 
	 */
	protected static void outputIndent(int anIndent, StringBuilder aBuilder,
			boolean addCr) {
		if (anIndent > 0) {
			if (addCr) {
				aBuilder.append('\n');
			}
			for (int i = 0; i < anIndent; i++) {
				aBuilder.append(INDENT);
			}
		}
	}

	/**
	 * Output key value.
	 * 
	 * @param aKey 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 */
	public static void outputKeyValue(String aKey, Object aValue, int anIndent,
			StringBuilder aBuilder) {
		outputKeyValue(aKey, aValue, anIndent, aBuilder, true);
	}

	/**
	 * Output key value.
	 * 
	 * @param aKey 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 * @param addCr 
	 */
	public static void outputKeyValue(String aKey, Object aValue, int anIndent,
			StringBuilder aBuilder, boolean addCr) {
		outputIndent(anIndent, aBuilder, addCr);
		aBuilder.append(aKey).append(": ");
		if (aValue instanceof String) {
			aBuilder.append(QUOTE).append(aValue).append(QUOTE);
		}
		else {
			if (aValue instanceof ITreePrintable) {
				outputTreePrintable((ITreePrintable) aValue, anIndent,
						aBuilder, addCr, null);
			}
			else if (aValue instanceof Collection <?>) {
				outputCollection((Collection <?>) aValue, anIndent, aBuilder,
						addCr);
			}
			else if (aValue instanceof BigDecimal) {
				String formatted = CURRENCY_FORMAT.format(aValue);
				aBuilder.append(formatted);
			}
			else if (aValue instanceof Date) {
				String formatted = DATE_FORMAT.format(aValue);
				aBuilder.append(formatted);
			}
			else {
				aBuilder.append(aValue);
			}
		}
		aBuilder.append(" ");
	}

	/**
	 * Output tree printable.
	 * 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 * @param addCr 
	 */
	protected static void outputTreePrintable(ITreePrintable aValue,
			int anIndent, StringBuilder aBuilder, boolean addCr, String aPrefix) {
		outputIndent(anIndent + 1, aBuilder, true);
		if (aPrefix != null) {
			aBuilder.append(aPrefix);
		}
		aBuilder.append(aValue.getClass().getSimpleName()).append(" [");
		try {
			(aValue).toStringOn(aBuilder, anIndent + 2);
		}
		catch (Exception e) {
			aBuilder.append(TRIPLE_DOTS).append(e.getMessage()).append(
					TRIPLE_DOTS);
		}
		outputIndent(anIndent + 1, aBuilder, true);
		aBuilder.append("]");
	}

	/** The created by. */
	private String createdBy;
	/** This represents the created date. Normally it will be the system date. */
	private Date createdDate;
	/** This represents the id generated by Hibernate. */
	private Long id;
	/** The modified by. */
	private String modifiedBy;
	/** This represents the modified date. Normally it will be&nbsp;the system date. */
	private Date modifiedDate;

	/**
	 * This method is to copy BusinessObject.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(BusinessObject dataToCopy) {
		setCreatedBy(dataToCopy.getCreatedBy());
		if (EaseUtil.isNotNull(dataToCopy.getCreatedDate())) {
			setCreatedDate(new Date(dataToCopy.getCreatedDate().getTime()));
		}
		else {
			setCreatedDate(null);
		}
		setId(dataToCopy.getId());
		setModifiedBy(dataToCopy.getModifiedBy());
		if (EaseUtil.isNotNull(dataToCopy.getModifiedDate())) {
			setModifiedDate(new Date(dataToCopy.getModifiedDate().getTime()));
		}
		else {
			setModifiedDate(null);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	protected final Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Clone not supported");
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BusinessObject other = (BusinessObject) obj;
		if (createdBy == null) {
			if (other.createdBy != null) {
				return false;
			}
		}
		else if (!createdBy.equals(other.createdBy)) {
			return false;
		}
		if (createdDate == null) {
			if (other.createdDate != null) {
				return false;
			}
		}
		else if (!createdDate.equals(other.createdDate)) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		}
		else if (!id.equals(other.id)) {
			return false;
		}
		if (modifiedBy == null) {
			if (other.modifiedBy != null) {
				return false;
			}
		}
		else if (!modifiedBy.equals(other.modifiedBy)) {
			return false;
		}
		if (modifiedDate == null) {
			if (other.modifiedDate != null) {
				return false;
			}
		}
		else if (!modifiedDate.equals(other.modifiedDate)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the business object id.
	 * 
	 * @return the business object id
	 */
	public Long getBusinessObjectId() {
		return getId();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObject#getBusinessObjectNamed(java.lang.String)
	 */
	public IBusinessObject getBusinessObjectNamed(String aPropertyName) {
		return getValueExtractor().getBusinessObjectNamed(aPropertyName, this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithCreationModificationStamps#getCreatedBy()
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Gets the created date.
	 * 
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IBusinessObject#getId()
	 */
	public Long getId() {
		return id;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithPropertyAccess#getIntegerValueNamed(java.lang.String)
	 */
	public Integer getIntegerValueNamed(String aPropertyName) {
		return getValueExtractor().getIntegerValueNamed(aPropertyName, this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithCreationModificationStamps#getModifiedBy()
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * Gets the modified date.
	 * 
	 * @return the modified date
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithPropertyAccess#getObjectNamed(java.lang.String)
	 */
	public Object getObjectNamed(String aPropertyName) {
		return getValueExtractor().getObjectNamed(aPropertyName, this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithPropertyAccess#getStringValueNamed(java.lang.String)
	 */
	public String getStringValueNamed(String aPropertyName) {
		return getValueExtractor().getStringValueNamed(aPropertyName, this);
	}

	/**
	 * Gets the value extractor.
	 * 
	 * @return the value extractor
	 */
	protected IBusinessObjectValueExtractor getValueExtractor() {
		return new BusinessObjectValueExtractor();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((modifiedBy == null) ? 0 : modifiedBy.hashCode());
		result = prime * result
				+ ((modifiedDate == null) ? 0 : modifiedDate.hashCode());
		return result;
	}

	/**
	 * Checks for an object id.
	 * 
	 * @return true if has object id
	 */
	public boolean hasId() {
		return !EaseUtil.isNullOrBlank(getId()) && getId() >= 0;
	}

	/**
	 * Sets the business object id.
	 * 
	 * @param businessObjectId the businessObjectId to set
	 */
	public void setBusinessObjectId(Long businessObjectId) {
		setId(businessObjectId);
	}

	/**
	 * Sets the created by.
	 * 
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Sets the created date.
	 * 
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Sets the id.
	 * 
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Sets the modified by.
	 * 
	 * @param modifiedBy the new modified by
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * Sets the modified date.
	 * 
	 * @param modifiedDate the new modified date
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append(TRIPLE_DOTS).append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(1024);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append(TRIPLE_DOTS).append(e.getMessage()).append(
					TRIPLE_DOTS).append("]");
			return aBuilder.toString();
		}
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 */
	protected void toStringOn(StringBuilder aBuilder) {
		toStringOn(aBuilder, 0);
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		//System.out.println("this: " + this.simpleToString());
		outputKeyValue("createdBy", createdBy, anIndent, aBuilder);
		outputKeyValue("createdDate", createdDate, anIndent, aBuilder);
		outputKeyValue("id", id, anIndent, aBuilder);
		outputKeyValue("modifiedDate", modifiedDate, anIndent, aBuilder);
	}

	//	/**
	//	 * Gets the validator.
	//	 * 
	//	 * @return the validator
	//	 */
	//	protected abstract IValidator getValidator();
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.IValidatable#validate()
	 */
	public IErrorCollector validate() {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		return aCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.IValidatable#validateUsing(gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public void validateUsing(IErrorCollector aCollector) {
		//subclasses override
		aCollector.register(new EaseValidationException(
				"validateUsing not implemented for " + this));
		//getValidator().validate(this, aCollector);
	}
	/**
	 * Copy non code set element list.
	 *
	 * @param <T> the generic type
	 * @param listToCopy the list to copy
	 * @return the list
	 */
	/*protected <T> List <T> copyNonCodeSetElementList(List <T> listToCopy) {
		if (!EaseUtil.isNullOrBlank(listToCopy)) {
			List <T> newList = new ArrayList <T>();
			for (T codeToCopy : listToCopy) {
				if (!EaseUtil.isNullOrBlank(codeToCopy)) {
					newList.add(codeToCopy);
				}
				else {
					newList.add(null);
				}
			}
			if (newList.size() > 0) {
				return newList;
			}
		}
		return null;
	}*/
}
/**
 *  Modification History:
 * 
 *  $Log: BusinessObject.java,v $
 *  Revision 1.2  2013/06/26 21:59:50  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2013/02/27 17:24:16  mwsec2
 *  adjusted formatting of toString output
 *
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.29  2012/08/14 20:30:16  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.28  2012/01/06 19:15:52  mwkfh
 *  added hasId
 *
 *  Revision 1.27  2011/06/10 21:28:56  mwyxg1
 *  clean up
 *
 *  Revision 1.26  2011/04/12 16:40:21  mwkfh
 *  updated copy method
 *
 *  Revision 1.25  2011/04/07 04:04:40  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.24.2.1  2011/04/02 18:58:45  mwhys
 *  Added a protected copy method.
 *
 *  Revision 1.24  2011/03/30 20:04:54  mwtjc1
 *  copyCodeSetElementList is moved to CodeSetElement
 *
 *  Revision 1.23  2011/03/29 22:59:41  mwtjc1
 *  logger is added in copyCodeSetElementList method
 *
 *  Revision 1.22  2011/03/29 22:55:00  mwtjc1
 *  copyNonCodeSetElementList is commented for now. We can uncomment it when we need to use it.
 *
 *  Revision 1.21  2011/03/29 22:45:23  mwtjc1
 *  copyCodeSetElement is removed
 *
 *  Revision 1.20  2011/03/25 21:01:32  mwtjc1
 *  utility methods are added
 *
 *  Revision 1.19  2010/12/10 21:45:12  mwpxp2
 *  Added date formatting for toString()
 *
 *  Revision 1.18  2010/12/09 00:38:04  mwpxp2
 *  Added number format-based amount rendering
 *
 *  Revision 1.17  2010/12/08 19:48:26  mwpxp2
 *  Corrected defect in outputCollection/4
 *
 *  Revision 1.16  2010/12/08 19:16:16  mwyxg1
 *  comment out code for collection.
 *
 *  Revision 1.15  2010/12/07 23:52:08  mwpxp2
 *  Commented system outs
 *
 *  Revision 1.14  2010/12/07 23:50:28  mwpxp2
 *  Cleanup; added todo
 *
 *  Revision 1.13  2010/12/07 22:07:12  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.12  2010/12/07 04:15:44  mwpxp2
 *  Modified toStringOn/1
 *
 *  Revision 1.11  2010/12/07 03:53:54  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.10  2010/12/07 02:04:21  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.9  2010/10/11 17:55:48  mwpxp2
 *  Added default validation implementation
 *
 *  Revision 1.8  2010/07/08 02:00:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/06/21 23:00:47  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.5.2.2  2010/06/20 18:06:58  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6  2010/06/02 20:38:21  mwrsk
 *  Add clone()
 *
 *  Revision 1.5  2010/05/27 00:51:45  mwpxp2
 *  Added statics for toString printing
 *
 *  Revision 1.4  2010/03/22 23:18:27  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.24  2009/10/13 00:14:10  mwcsj3
 *  Updated class description
 *
 *  Revision 1.23  2009/10/11 16:41:25  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.22  2009/10/07 01:09:20  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.21  2009/10/03 21:06:30  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.20  2009/08/30 21:27:38  mwvxm6
 *  Use Hibernate Id Generator temporarily till DB2 sequence setup complete
 *
 *  Revision 1.19  2009/08/28 01:24:52  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.18  2009/08/27 05:39:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.17  2009/08/27 02:22:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.16  2009/08/22 23:21:48  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.15  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.14  2009/08/06 02:53:18  mwrsk
 *  Added length to column annotation
 *
 *  Revision 1.13  2009/08/05 00:44:55  mwrsk
 *  Updated the @Entity name
 *
 *  Revision 1.12  2009/08/05 00:39:38  mwrsk
 *  Changed DB mapping column names
 *
 *  Revision 1.11  2009/08/05 00:35:56  mwrsk
 *  Changed DB column name from BUSINESS_OBJECT_ID to ID
 *
 *  Revision 1.10  2009/08/04 20:36:32  mwpxp2
 *  Made abstract; added hash and equals implementations
 *
 *  Revision 1.9  2009/08/04 01:42:19  mwpxp2
 *  Implemented getExtractor
 *
 *  Revision 1.8  2009/08/03 23:48:56  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.7  2009/07/27 23:33:51  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.6  2009/07/22 00:34:35  mwrrv3
 *  Modified the package name in the javadoc comments.
 *
 *  Revision 1.5  2009/07/21 18:33:59  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.4  2009/07/14 23:44:39  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.3  2009-07-13 01:55:29  ppalacz
 *  Added IBusinessObjectValueExtractor
 *
 *  Revision 1.2  2009-07-12 15:46:09  ppalacz
 *  Implemented IBusinessObject
 *  
 *  $Revision 1.1  May 4, 2009 10:53:25 AM  MWCSJ3
 *  $Initial
 *  $
 */
