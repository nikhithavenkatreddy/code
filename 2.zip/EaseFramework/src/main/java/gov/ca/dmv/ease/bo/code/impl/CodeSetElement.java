/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code.impl;

import gov.ca.dmv.ease.bo.code.ICodeSet;
import gov.ca.dmv.ease.bo.code.ICodeSetElement;
import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: All code sets are persisted in a common table with a
 * discriminatory column identifying the code category.
 * File: CodeSetElement.java
 * Module:  gov.ca.dmv.ease.bo.code.impl
 * Created: May 4, 2009
 * @author MWRRV3
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2014/09/24 19:52:02 $
 * Last Changed By: $Author: mwskh1 $
 */
public class CodeSetElement extends BaseBusinessObject implements
		ICodeSetElement {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(CodeSetElement.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 245564919755569990L;

	/**
	 * Copy code set element list.
	 *
	 * @param listToCopy the list to copy
	 * @return the list
	 */
	public static List <CodeSetElement> copyCodeSetElementList(
			List <CodeSetElement> listToCopy) {
		if (EaseUtil.isNotNull(listToCopy)) {
			List <CodeSetElement> newList = new ArrayList <CodeSetElement>();
			for (CodeSetElement codeToCopy : listToCopy) {
				if (EaseUtil.isNotNull(codeToCopy)) {
					newList.add(codeToCopy.copy());
				}
				else {
					LOGGER
							.info("Null or Empty CodeSetElement found in the list:"
									+ listToCopy);
					newList.add(null);
				}
			}
			return newList;
		}
		return null;
	}

	/** The code. */
	private String code;
	/** The code category. */
	private String codeCategory;
	/** The code filter is used to filter the code set to be displayed, based on usage by Functional Area. */
	//private String codeFilter;
	/** the code set that this element belongs to */
	private transient ICodeSet codeSet;
	/** The description. */
	private String description;
	/** The effective date. */
	private Date effectiveDate;
	/** The end date. */
	private Date endDate;
	/** The name. */
	private String name;

	/**
	 * Instantiates a new code set element.
	 */
	public CodeSetElement() {
		super();
	}

	/**
	 * Instantiates a new code set element.
	 *
	 * @param another the another
	 */
	public CodeSetElement(CodeSetElement another) {
		super();
		if (another == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy constructor for "
							+ this);
		}
		copy(another);
	}

	/**
	 * Instantiates a new code set element.
	 *
	 * @param another the another
	 */
	public CodeSetElement(ICodeSetElement another) {
		super();
		setCode(another.getCode());
		setCodeSet(another.getCodeSet());
		setDescription(another.getDescription());
		setEffectiveDate(another.getEffectiveDate());
		setEndDate(another.getEndDate());
		setName(another.getName());
	}

	/**
	 * Instantiates a new code set element.
	 * 
	 * @param aName the a name
	 * @param aCodeValue the a code value
	 * @param aDescription the a description
	 */
	public CodeSetElement(String aName, String aCodeValue, String aDescription) {
		super();
		setName(aName);
		setCode(aCodeValue);
		setDescription(aDescription);
		setEffectiveDate(new Date());
	}

	/**
	 * Instantiates a new code set element.
	 * 
	 * @param aName the a name
	 * @param aDescription the a description
	 */
	public CodeSetElement(String aName, String aDescription) {
		super();
		setName(aName);
		setCode(aName);
		setDescription(aDescription);
		setEffectiveDate(new Date());
	}

	/**
	 * Instantiates a new code set element.
	 * 
	 * @param aName the a name
	 * @param aCodeValue the a code value
	 * @param aDescription the a description
	 * @param anEffective the an effective
	 * @param anEnd the an end
	 */
	public CodeSetElement(String aName, String aCodeValue, String aDescription,
			Date anEffective, Date anEnd) {
		super();
		setName(aName);
		setCode(aCodeValue);
		setDescription(aDescription);
		setEffectiveDate(anEffective);
		setEndDate(anEnd);
	}

	/**
	 * Instantiates a new code set element.
	 *
	 * @param aName the a name
	 * @param aCodeValue the a code value
	 * @param aDescription the a description
	 * @param codeSet the code set
	 */
	public CodeSetElement(String aName, String aCodeValue, String aDescription,
			ICodeSet codeSet) {
		super();
		setName(aName);
		setCode(aCodeValue);
		setDescription(aDescription);
		setEffectiveDate(new Date());
		setCodeSet(codeSet);
	}

	/**
	 * Copy.
	 *
	 * @return the code set element
	 */
	public CodeSetElement copy() {
		CodeSetElement codeSetElement = new CodeSetElement();
		codeSetElement.setCode(getCode());
		codeSetElement.setCodeCategory(getCodeCategory());
		codeSetElement.setCodeSet(getCodeSet());
		codeSetElement.setDescription(getDescription());
		codeSetElement.setEffectiveDate(getEffectiveDate());
		codeSetElement.setEndDate(getEndDate());
		codeSetElement.setName(getName());
		return codeSetElement;
	}

	/**
	 * Instantiates a new code set element.
	 *
	 * @param another the another
	 */
	protected void copy(CodeSetElement another) {
		if (!EaseUtil.isNullOrBlank(another)) {
			super.copy(another);
			setCode(another.getCode());
			setCodeCategory(another.getCodeCategory());
			setCodeSet(another.getCodeSet());
			setDescription(another.getDescription());
			setEffectiveDate(another.getEffectiveDate());
			setEndDate(another.getEndDate());
			setName(another.getName());
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		if (object == null) {
			return false;
		}
		if (!(object instanceof CodeSetElement)) {
			return false;
		}
		String strCode = ((CodeSetElement) object).getCode();
		if (strCode != null && !strCode.equals(this.getCode())) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Gets the Code Category.
	 * 
	 * @return the Code Category
	 */
	public String getCodeCategory() {
		return codeCategory;
	}

	/**
	 * Gets the code set.
	 *
	 * @return the codeFilter
	 */
	//	public String getCodeFilter() {
	//		return codeFilter;
	//	}
	/**
	 * Gets the code set
	 * 
	 * @return the codeSet
	 */
	public ICodeSet getCodeSet() {
		return codeSet;
	}

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Gets the effective date.
	 * 
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Gets the end date.
	 * 
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasCodeEqualTo(java.lang.String)
	 */
	public boolean hasCodeEqualTo(String aCode) {
		//TODO - this should be redirected either to hasNotNullCodeAndEqualTo or hasEqualToOrNull
		return code != null && code.equalsIgnoreCase(aCode);
	}

	/**
	 * This method checks an availability of a code element in the given String array of 
	 * code elements and return boolean value accordingly.
	 * 
	 * @param codeArray the code array
	 * 
	 * @return true, if successful
	 */
	public boolean hasCodeEqualToAnyOf(List <String> codeArray) {
		for (String element : codeArray) {
			if (hasCodeEqualTo(element)) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasCodeEqualToAnyOf(java.lang.String[])
	 */
	public boolean hasCodeEqualToAnyOf(String... codeArr) {
		for (String element : codeArr) {
			if (hasCodeEqualTo(element)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks for equal to or null.
	 *
	 * @param aCode the a code
	 * @return true, if successful
	 */
	public boolean hasCodeEqualToOrNull(String aCode) {
		if (code == null) {
			return aCode == null;
		}
		else {
			return code.equalsIgnoreCase(aCode);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasCodeNotEqualTo(java.lang.String)
	 */
	public boolean hasCodeNotEqualTo(String aCode) {
		return code != null && !code.equalsIgnoreCase(aCode);
	}

	/**
	 * This method checks an availability of a code element in the given String array of 
	 * code elements and return boolean value accordingly.
	 * 
	 * @param codeArray the code array
	 * 
	 * @return true, if successful
	 */
	public boolean hasCodeNotEqualToAnyOf(List <String> codeArray) {
		for (String element : codeArray) {
			if (hasCodeEqualTo(element)) {
				return false;
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasCodeNotEqualToAnyOf(java.lang.String[])
	 */
	public boolean hasCodeNotEqualToAnyOf(String... codeArr) {
		for (String element : codeArr) {
			if (hasCodeEqualTo(element)) {
				return false;
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasCodeNotEqualToAnyOf(java.lang.String[])
	 */
	public boolean hasCodeStartingWith(String start) {
		if (EaseUtil.isNotBlank(code)) {
			if (code.startsWith(start)) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetElement#hasNameEqualTo(java.lang.String)
	 */
	public boolean hasNameEqualTo(String aName) {
		return name != null && name.equalsIgnoreCase(aName);
	}

	/**
	 * Checks for not null code and equal to.
	 *
	 * @param aCode the a code
	 * @return true, if successful
	 */
	public boolean hasNotNullCodeAndEqualTo(String aCode) {
		return code != null && code.equalsIgnoreCase(aCode);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#isEffectiveNow()
	 */
	public boolean isEffectiveNow() {
		Date currenttime = new Date();
		return (getEffectiveDate().before(currenttime));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.IWithValidityPeriod#isEffectiveOn(java.util.Date)
	 */
	public boolean isEffectiveOn(Date date) {
		return (date.before(getEffectiveDate()));
	}

	/**
	 * Sets the code.
	 * 
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Sets the Code Category.
	 * 
	 * @param codeCategory the Code Category
	 */
	public void setCodeCategory(String codeCategory) {
		this.codeCategory = codeCategory;
	}

	/**
	 * Sets the code set.
	 *
	 * @param codeSet the new code set
	 */
	//	public void setCodeFilter(String codeFilter) {
	//		this.codeFilter = codeFilter;
	//	}
	/**
	 * Sets the code set
	 * 
	 * @param codeSet the code set to set
	 */
	public void setCodeSet(ICodeSet codeSet) {
		this.codeSet = codeSet;
	}

	/**
	 * Sets the description.
	 * 
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Sets the effective date.
	 * 
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Sets the end date.
	 * 
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	//	/**
	//	 * Constructs a <code>String</code> with all attributes
	//	 * in name = value format.
	//	 *
	//	 * @return a <code>String</code> representation 
	//	 * of this object.
	//	 */
	//	@Override
	//	public String toString() {
	//		StringBuilder aBuff = new StringBuilder(128);
	//		aBuff.append(getClass().getSimpleName()).append(" [");
	//		if (name == null) {
	//			aBuff.append(" name: ").append(name).append(",");
	//		}
	//		else {
	//			aBuff.append(" name: \"").append(name).append("\",");
	//		}
	//		if (code == null) {
	//			aBuff.append(" code: ").append(code).append(",");
	//		}
	//		else {
	//			aBuff.append(" code: \"").append(code).append("\",");
	//		}
	//		aBuff.append(" endDate: ").append(endDate).append("]");
	//		return aBuff.toString();
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("code", code, anIndent, aBuilder);
		outputKeyValue("codeCategory", codeCategory, anIndent, aBuilder);
		//outputKeyValue("codeSet", codeSet, anIndent, aBuilder); //WARNING! cycle
		outputKeyValue("description", description, anIndent, aBuilder);
		outputKeyValue("effectiveDate", effectiveDate, anIndent, aBuilder);
		outputKeyValue("endDate", endDate, anIndent, aBuilder);
		outputKeyValue("name", name, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CodeSetElement.java,v $
 *  Revision 1.2  2014/09/24 19:52:02  mwskh1
 *  AB60 Merge from AB60Branch to the Head
 *
 *  Revision 1.1.12.1  2014/06/03 22:11:49  mwgxd3
 *  AB60 -  added new constuctor to CodeSetElement class.
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.25  2011/07/29 23:02:43  mwhxb3
 *  Renamed a method.
 *
 *  Revision 1.24  2011/07/29 01:37:02  mwhxb3
 *  Added hasCodeStartsWith.
 *
 *  Revision 1.23  2011/07/16 01:26:12  mwrrv3
 *  Changed the ICodeSet to transient.
 *
 *  Revision 1.22  2011/07/09 21:07:40  mwpxp2
 *  Added two has~Equal~Code; a todo
 *
 *  Revision 1.21  2011/04/07 04:04:41  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.20.2.3  2011/04/04 22:35:16  mwkfh
 *  updated copyCodeSetElementList to return empty list instead of null when passed empty list
 *
 *  Revision 1.20.2.2  2011/04/04 20:57:05  mwkfh
 *  added copy method for copy constructor and null check
 *
 *  Revision 1.20.2.1  2011/04/02 00:44:44  mwrka1
 *  added null check for copy constructor
 *
 *  Revision 1.20  2011/03/30 20:01:50  mwtjc1
 *  copyCodeSetElementList is moved from BusinessObject
 *
 *  Revision 1.19  2011/03/29 17:11:36  mwtjc1
 *  copy method added
 *
 *  Revision 1.18  2011/03/16 22:09:31  mwrka1
 *  added copy constructor
 *
 *  Revision 1.17  2011/01/18 09:25:09  mwpxp2
 *  Added copy constructor to fix build breakage
 *
 *  Revision 1.16  2010/12/07 22:07:27  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.15  2010/12/07 03:53:36  mwpxp2
 *  Modified toString/0
 *
 *  Revision 1.14  2010/09/13 04:39:51  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.13  2010/09/01 18:58:23  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.12  2010/08/26 17:15:36  mwuxb
 *  Added helper method ' hasCodeNotEqualToAnyOf ' with argument type -  List <String>.
 *
 *  Revision 1.11  2010/08/26 17:09:14  mwuxb
 *  Added helper method ' hasCodeEqualToAnyOf ' with argument type -  List <String>.
 *
 *  Revision 1.10  2010/08/12 18:55:56  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.9  2010/07/20 16:02:22  mwrsk
 *  Remove code filter
 *
 *  Revision 1.8  2010/07/08 01:56:02  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/06/29 15:36:11  mwvxm6
 *  Added attribute codeFilter
 *
 *  Revision 1.6  2010/05/27 00:48:03  mwpxp2
 *  Fixed toString/0 to use string buffer rather than multiple concatenations
 *
 *  Revision 1.5  2010/05/25 23:54:50  mwpxp2
 *  Added a handful of convenience boolean methods
 *
 *  Revision 1.4  2010/03/22 23:17:53  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.2  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.32  2009/10/15 22:28:36  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.31  2009/10/12 19:54:55  mwtjc1
 *  local variable TAB of toString() is changed to tab to resolve PMD reported issue '[SEVERITY 2] Local Variable name 'TAB' should start with a lowercase character.'
 *
 *  Revision 1.30  2009/10/11 16:41:20  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.29  2009/10/07 01:18:10  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.28  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.27  2009/09/25 23:35:26  mwhxa2
 *  *** empty log message ***
 *
 *  Revision 1.26  2009/09/25 23:35:11  mwhxa2
 *  Now Extends BaseBusinessObject
 *
 *  Revision 1.25  2009/09/13 20:45:36  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.23.2.2  2009/09/13 01:34:28  mwakg
 *  Reading data from Database instead of XML for CodeSetService
 *
 *  Revision 1.23.2.1  2009/09/12 19:08:53  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.23  2009/09/10 20:34:50  mwpxm2
 *  CodeSet design change
 *
 *  Revision 1.22  2009/09/01 21:25:19  mwrrv3
 *  Added generated Serializable UID.
 *
 *  Revision 1.21  2009/08/27 05:39:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.20  2009/08/25 16:37:19  mwakg
 *  Fixed equals method
 *
 *  Revision 1.19  2009/08/24 23:24:16  mwakg
 *  Custom implementation of the equals method for codeset
 *
 *  Revision 1.18  2009/08/22 23:19:32  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.17  2009/08/19 18:41:31  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.16  2009/08/11 23:45:38  mwrsk
 *  Updated the @DiscriminatorColumn to CODE_CATEGORY
 *
 *  Revision 1.15  2009/08/11 18:18:08  mwrrv3
 *  Added checking null value for code.
 *
 *  Revision 1.14  2009/08/11 00:05:59  mwrsk
 *  Removed reverse mapping to CodeSet
 *
 *  Revision 1.13  2009/08/10 22:49:21  mwskd2
 *  equals method overridden
 *
 *  Revision 1.12  2009/08/10 21:39:19  mwpxp2
 *  Adding logging
 *
 *  Revision 1.11  2009/08/06 23:11:31  mwpxp2
 *  Added toString
 *
 *  Revision 1.10  2009/08/06 21:54:00  mwrsk
 *  Updated Hibernate Annotations
 *
 *  Revision 1.9  2009/08/06 17:28:33  mwpxp2
 *  Added constructors /3 and /5; /0 protected
 *
 *  Revision 1.6  2009/08/05 00:04:46  mwbxp5
 *  Added CodeSet and CodeSetElement--Initial
 *
 *  Revision 1.5  2009/07/28 01:59:49  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.4  2009/07/16 17:52:08  mwtjc1
 *  On behalf of Raghava Vaka I have changed the code set element code from Integer to String.
 *
 *  Revision 1.3  2009/07/14 23:44:40  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:27:06  ppalacz
 *  Bulk format
 *
 *  Revision 1.1  2009-07-12 01:00:26  ppalacz
 *  moved to .code.impl - to be revisited
 *
 *  Revision 1.1  2009-07-10 07:09:25  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 4:40:02 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 4:40:02 PM  MWCSJ3
 *  $Initial
 *  $
 */
