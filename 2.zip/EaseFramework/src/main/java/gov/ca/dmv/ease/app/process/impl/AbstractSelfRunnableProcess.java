/**
 * 
 */
package gov.ca.dmv.ease.app.process.impl;

import gov.ca.dmv.ease.app.config.impl.ProcessRegistry;
import gov.ca.dmv.ease.app.config.impl.TransactionTypeRegistry;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.context.impl.SessionlessRootContext;
import gov.ca.dmv.ease.app.process.ISelfRunnableProcess;
import gov.ca.dmv.ease.bo.user.impl.UserContext;

/**
 * Description: Abstract parent class for self-runnable process classes
 * File: AbstractSelfRunnableBusinessProcess.java
 * Module:  gov.ca.dmv.ease.app.process.impl
 * Created: May 31, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractSelfRunnableProcess implements
		ISelfRunnableProcess {
	private static final String PSEUDO_MENU_BP_NAME = "PSEUDO_MENU";
	
	/* the name of the BP to run */
	private String businessProcessName;
	/* the process context to be run */
	private ProcessContext processContext;
	/* the user context to run the process for */
	private UserContext userContext;

	/**
	 * @return the businessProcessName
	 */
	public String getBusinessProcessName() {
		return businessProcessName;
	}

	/**
	 * @return the processContext
	 */
	public ProcessContext getProcessContext() {
		return processContext;
	}

	/**
	 * returns the user context
	 * 
	 * @return
	 */
	public UserContext getUserContext() {
		return userContext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.process.ISelfRunnableProcess#run()
	 */
	public void run() {
		SessionlessRootContext rootContext = new SessionlessRootContext();
		ProcessRegistry processRegistry = (ProcessRegistry) EaseApplicationContext
				.getApplicationContext().getBean("processRegistry");
		rootContext.setProcessRegistry(processRegistry);
		TransactionTypeRegistry transactionTypeRegistry = (TransactionTypeRegistry) EaseApplicationContext
				.getApplicationContext().getBean("transactionTypeRegistry");
		rootContext.setTransactionTypeRegistry(transactionTypeRegistry);
		rootContext.setUserContext(userContext);
		rootContext.setTargetProcessName(getBusinessProcessName());
		rootContext.setProcessToRun(processContext);
		rootContext.setTtcToRunAs(userContext.getTtc());
		userContext.setTtc(PSEUDO_MENU_BP_NAME);
		rootContext.startProcess();
	}

	/**
	 * @param businessProcessName the businessProcessName to set
	 */
	public void setBusinessProcessName(String businessProcessName) {
		this.businessProcessName = businessProcessName;
	}

	/**
	 * @param processContext the processContext to set
	 */
	public void setProcessContext(ProcessContext processContext) {
		this.processContext = processContext;
	}

	/**
	 * sets the user context
	 * 
	 * @param userContext
	 */
	public void setUserContext(UserContext userContext) {
		this.userContext = userContext;
	}
}

/**
 *  Modification History:
 *
 *  $$Log: AbstractSelfRunnableProcess.java,v $
 *  $Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.3  2012/08/14 20:25:51  mwrrv3
 *  $Fixed PMD issues.
 *  $
 *  $Revision 1.2  2012/06/08 17:19:38  mwsec2
 *  $initial check-in of classes to support the running of business processes outside an HTTP session context
 *  $$
 */
