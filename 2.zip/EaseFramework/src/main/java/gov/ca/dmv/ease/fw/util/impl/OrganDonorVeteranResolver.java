package gov.ca.dmv.ease.fw.util.impl;

/**
 * @author mwnxg5
 *
 */
public class OrganDonorVeteranResolver {
	enum OrganDonorVeteranBundle {
		O, V, X, N
	};

	private Boolean organDonor;
	private Boolean veteran;

	public OrganDonorVeteranResolver() {
	}

	public OrganDonorVeteranResolver(String theFlag) {
		if (EaseUtil.isNullOrBlank(theFlag)) {
			setOrganDonor(false);
			setVeteran(false);
			return;
		}
		OrganDonorVeteranBundle theType = OrganDonorVeteranBundle
				.valueOf(theFlag);
		switch (theType) {
		case O:
			setOrganDonor(true);
			setVeteran(false);
			break;
		case V:
			setOrganDonor(false);
			setVeteran(true);
			break;
		case X:
			setOrganDonor(true);
			setVeteran(true);
			break;
		default:
			setOrganDonor(false);
			setVeteran(false);
			break;
		}
	}

	public String organDonorVeteranValuesToTheFlag(Boolean donor,
			Boolean veteran) {
		String retValue = null;
		if ((donor != null) && (veteran != null)) {
			if (donor && veteran) {
				retValue = OrganDonorVeteranBundle.X.name(); //BOTH
			}
			else if (donor) {
				retValue = OrganDonorVeteranBundle.O.name();
			}
			else if (veteran) {
				retValue = OrganDonorVeteranBundle.V.name();
			}
			else {
				retValue = OrganDonorVeteranBundle.N.name();
			}
		}
		else {
			retValue = null;
		}
		return retValue;
	}

	public Boolean isOrganDonor() {
		return organDonor;
	}

	public void setOrganDonor(Boolean organDonor) {
		this.organDonor = organDonor;
	}

	public Boolean isVeteran() {
		return veteran;
	}

	public void setVeteran(Boolean veteran) {
		this.veteran = veteran;
	}
}
/**
*  Modification History:
*
*  $Log: OrganDonorVeteranResolver.java,v $
*  Revision 1.1  2015/08/26 14:49:10  mwnxg5
*  VCH New Class
*
*/
