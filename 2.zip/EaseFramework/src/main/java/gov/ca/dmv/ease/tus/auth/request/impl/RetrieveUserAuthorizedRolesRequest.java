/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.auth.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.auth.response.IRetrieveUserAuthorizedRolesResponse;
import gov.ca.dmv.ease.tus.auth.service.impl.AuthAndAuthService;

/**
 * Description: I am an AuthAndAuth request
 * 
 * File: RetrieveUserAuthorizedRolesRequest.java
 * Module:  gov.ca.dmv.ease.tus.auth.request.impl
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveUserAuthorizedRolesRequest extends
		AuthAndAuthServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6244007514091366292L;
	/** Office id */
	private String officeId;

	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public RetrieveUserAuthorizedRolesRequest(IUserContext userContext) {
		super(userContext);
		officeId = userContext.getOfficeId();
	}

	public String getOfficeId() {
		return officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.impl.IAuthAndAuthServiceRequest#execute()
	 */
	@Override
	public IRetrieveUserAuthorizedRolesResponse execute() {
		return AuthAndAuthService.getInstance().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveUserAuthorizedRolesRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/06/15 17:38:16  mwxxw
 *  Add new field: officeId.
 *
 *  Revision 1.1  2010/10/04 21:39:25  mwkfh
 *  refactored AuthAndAuthService to use factory/request/response/execute
 *
 */
