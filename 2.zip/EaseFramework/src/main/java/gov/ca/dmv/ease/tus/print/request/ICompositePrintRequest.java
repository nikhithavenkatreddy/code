/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request;

import gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest;
import gov.ca.dmv.ease.tus.print.response.IPrintServiceResponse;

import java.util.List;

/**
 * Description: Interface for a composite request - a request consisting of a number of other requests.
 * File: ICompositePrintRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request
 * Created: 16/05/2009
 * @author MWHXA2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICompositePrintRequest extends IPrintServiceRequest {
	/**
	 * Registers a Print Service Request.
	 *
	 * @param aRequest the a request
	 */
	void add(PrintServiceRequest aRequest);

	/**
	 * Adds the all requests in the collection.
	 *
	 * @param aRequestList the a request list
	 */
	void addAll(List <PrintServiceRequest> aRequestList);

	/**
	 * This method performs execute functionality on composite Request.
	 * 
	 * @return a Print Service Response
	 */
	//FIXME - this is not a correct return type for a composite - should itself be a composite
	IPrintServiceResponse execute();

	/**
	 * Gets the requests contained.
	 *
	 * @return the request
	 */
	List <PrintServiceRequest> getRequests();
}
/**
 *  Modification History:
 *
 *  $Log: ICompositePrintRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/08/25 17:53:20  mwpxp2
 *  Fixed to use IPrintServiceResponse rather than implementation
 *
 *  Revision 1.6  2010/09/01 19:06:10  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.5  2010/07/13 00:25:17  mwhxa2
 *  Extends IPrintServiceRequest
 *
 *  Revision 1.4  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.16.2  2010/06/20 18:07:00  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 17:19:36  mwpxp2
 *  Added fixme
 *
 *  Revision 1.2  2010/03/22 23:39:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/02/09 00:57:22  mwhxa2
 *  Adding ICompositePrintRequest
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/13 20:25:35  mwhxb3
 *  updated comments.
 *
 *  Revision 1.3  2009/10/06 21:52:15  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.2.12.1  2009/10/06 20:28:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.2  2009/07/14 23:58:52  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-10 07:10:25  ppalacz
 *  Synch
 *
 *  Revision 1.2  2009-05-18 16:22:34  ppalacz
 *  Javadoc update
 *
 *  Revision 1.1  2009-05-17 05:22:07  ppalacz
 *  Initial
 *
*/
