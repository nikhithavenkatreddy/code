/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.fw.http.request.impl;

import gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor;

import java.io.Serializable;
import java.util.Map;

/**
 * Description: Mock implementation for IRequestHeaderExtractor. For use in development environment only
 * File: MockRequestHeaderExtractor.java
 * Module:  gov.ca.dmv.ease.fw.http.request.impl
 * Created: Apr 4, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MockRequestHeaderExtractor implements IRequestHeaderExtractor,
		Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6473274909670474655L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getIpAddress()
	 */
	public String getIpAddress() {
		return "165.153.2.99"; //"127.0.0.1";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getOffice()
	 */
	public String getOfficeId() {
		return "791"; //"130";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getOrigUser()
	 */
	public String getOriginalUser() {
		return "MWMRK2";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getRacf()
	 */
	public String getRacfId() {
		return "M2MRK2"; //"MWVXM6";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getTech()
	 */
	public String getTechId() {
		return "M2";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getUsername()
	 */
	public String getUsername() {
		return "Office791_TechMK"; //"Office130_TechM2";
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getUsername()
	 */
	public String getRemoteOfficeId() {
		return "131";
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getIssuanceStr()
	 */
	public String getIssuanceStr() {
		return "791-M2-M2MRK2";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#setRequestParameters()
	 */
	public void setRequestParameters() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#setRequestParameters(java.util.Map)
	 */
	public void setRequestParameters(Map <String, String> requestParams) {
	}
}
/**
 * Modification History:
 * 
 * $Log: MockRequestHeaderExtractor.java,v $
 * Revision 1.1  2012/10/01 02:57:31  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.11  2012/05/17 23:37:38  mwxxw
 * Add new header name value pair: issuance.
 *
 * Revision 1.10  2011/12/08 22:27:59  mwrrv3
 * Changed the tech id to M2.
 *
 * Revision 1.9  2011/02/02 00:03:36  mwxxw
 * Updated with tester's information.
 *
 * Revision 1.8  2010/11/29 23:04:36  mwxxw
 * Add new field remoteOfficeId for location enforcement service.
 *
 * Revision 1.7  2010/08/30 18:53:16  mwkfh
 * removed removeDuplicates()
 *
 * Revision 1.6  2010/07/08 02:04:41  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.5  2010/05/26 16:33:13  mwkkc
 * changed the original user - mwkfh
 *
 * Revision 1.4  2010/05/25 23:02:50  mwkkc
 * typed Map - mwkfh
 *
 * Revision 1.3  2010/05/25 22:03:17  mwkkc
 * updated to pull request header values - mwkfh
 *
 * Revision 1.2  2010/05/04 23:15:06  mwvkm
 * Made it Serializable
 *
 * Revision 1.1  2010/04/04 18:52:25  mwakg
 * Removed usage of username and using RequestHeaderExtractor
 *
 * 
 */
