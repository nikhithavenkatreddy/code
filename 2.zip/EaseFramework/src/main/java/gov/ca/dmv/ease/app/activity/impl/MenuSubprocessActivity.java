/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.config.IProcessLoader;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;

/**
 * Description: I am an abstract activity class for starting business processes chosen 
 * from a menu.
 * 
 * File: MenuSubprocessActivity.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Aug 16, 2010
 * 
 * @author mwsec2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class MenuSubprocessActivity extends
		InclusionSubprocessActivity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8589764058701800694L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.SubprocessActivity#getChildProcessContext(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected ProcessContext getChildProcessContext(
			ProcessContext processContext) {
		String menuSelection = processContext.getUserContext().getTtc();
		BusinessProcess businessProcess = getProcessRegistry()
				.getProcessForTransaction(menuSelection);
		return businessProcess.getProcessContext();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.app.activity.impl.InclusionSubprocessActivity#getTransitionKey(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected String getTransitionKey(ProcessContext processContext) {
		return IProcessLoader.DEFAULT_TRANSITION_KEY;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MenuSubprocessActivity.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/11/09 03:19:30  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.3  2010/09/03 16:57:16  mwsec2
 *  method by which the BP is got from BP registry changed to new 'getProcessForTransaction' method
 *
 *  Revision 1.2  2010/08/20 18:31:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/08/16 21:59:51  mwsec2
 *  initial check-in
 *
 */
