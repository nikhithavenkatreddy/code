/**
 * 
 */
package gov.ca.dmv.ease.fw.journaling.impl;

import gov.ca.dmv.ease.fw.exception.impl.ServiceRequestExecutionException;
import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;
import gov.ca.dmv.ease.tus.logging.po.impl.SysMgmtLog;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This log processor supports batch processing of log entries using the JDBC-based
 * (non-Hibernate) JdbcLogBatchPersistenceService, which uses batch (bulk) inserts. 
 * 
 * File: JdbcLogBatchProcessor.java
 * Module:  gov.ca.dmv.ease.fw.journaling.impl
 * Created: Dec 26, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class JdbcLogBatchProcessor extends AbstractLogBatchProcessor {
	
	/* The logger for this class (not used in batch processing) */
	private static final Log LOGGER = LogFactory
			.getLog(JdbcLogBatchProcessor.class);
	
	/* The JDBC-based persistence service for batch logging */
	private JdbcLogBatchPersistenceService jdbcLogBatchPersistenceService;
	
	/**
	 * Writes a batch of log messages to persistence
	 * 
	 * @param entries
	 */
	public void execute(List <AbstractLog> entries) {
		try {
			if (entries != null && entries.size() > 0 && entries.get(0) instanceof SysMgmtLog) {
				getJdbcLogBatchPersistenceService().insertSystemManagementBatch(entries);
			} else {
				// currently supports SysMgmtLog only
				LOGGER.error("Invalid or unsupported type of log entries passed for batching");
			}
		} catch (Exception e) {
			throw new ServiceRequestExecutionException(e);
		}
	}

	/**
	 * @return
	 */
	private JdbcLogBatchPersistenceService getJdbcLogBatchPersistenceService() {
		return jdbcLogBatchPersistenceService;
	}
	
	/**
	 * @param jdbcLogBatchPersistenceService
	 */
	public void setJdbcLogBatchPersistenceService(
			JdbcLogBatchPersistenceService jdbcLogBatchPersistenceService) {
		this.jdbcLogBatchPersistenceService = jdbcLogBatchPersistenceService;
	}
}
/**
 *  Modification History:
 *
 *  $Log: 
 *
 */
