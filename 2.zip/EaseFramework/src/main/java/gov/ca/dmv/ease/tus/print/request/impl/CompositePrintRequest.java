/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.print.request.ICompositePrintRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am Composite Print Request implementation.
 * File: CompositePrintRequest.java
 * Module:  gov.ca.dmv.ease.tus.print.request.impl
 * Created: Feb 4, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CompositePrintRequest extends PrintServiceRequest implements
		ICompositePrintRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8427792211394654042L;
	/** The children. */
	private List <PrintServiceRequest> children;

	/**
	 * Constructor.
	 * 
	 * @param userContext the User Context
	 */
	public CompositePrintRequest(IUserContext userContext) {
		super(userContext);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.ICompositePrintRequest#add(gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest)
	 */
	public void add(PrintServiceRequest request) {
		getChildren().add(request);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.ICompositePrintRequest#addAll(java.util.List)
	 */
	public void addAll(List <PrintServiceRequest> requestList) {
		getChildren().addAll(requestList);
	}

	/**
	 * Gets the children.
	 * 
	 * @return the children
	 */
	protected List <PrintServiceRequest> getChildren() {
		if (children == null) {
			//Initialize Child Requests
			children = new ArrayList <PrintServiceRequest>();
		}
		return children;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.request.ICompositePrintRequest#getRequests()
	 */
	public List <PrintServiceRequest> getRequests() {
		return getChildren();
	}

//	/* (non-Javadoc)
//	 * @see gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest#getValidator()
//	 */
//	@Override
//	protected IValidator getValidator() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#hasChildren()
	 */
	/**
	 * Checks for children.
	 * 
	 * @return true, if successful
	 */
	public boolean hasChildren() {
		//only composites can have children
		//FIXME - is that "can have children" -> return true or "does have children" -> return children != null && !children.isEmpty
		//return true;
		return children != null && !children.isEmpty();
	}

	/**
	 * Sets the children.
	 * 
	 * @param aList the new children
	 */
	protected void setChildren(List <PrintServiceRequest> aList) {
		children = aList;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		super.validateUsing(aCollector);
		//Validate Print Service Requests
		if (EaseUtil.isNullOrBlank(getRequests())) {
			aCollector.register(new EaseValidationException(
					"COMPOSITE CONTAINS NO PRINT REQUESTS"));
		}
		else {
			for (PrintServiceRequest request : getRequests()) {
				//Validate Print Service Request
				request.validateUsing(aCollector);
			}
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CompositePrintRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.14  2010/12/02 00:14:59  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.13  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.12  2010/09/01 19:06:25  mwpxp2
 *  Import cleanup
 *
 *  Revision 1.11  2010/07/21 18:19:42  mwpxp2
 *  Fixed use of this~; removed unnecessary methods; fixed validation
 *
 *  Revision 1.10  2010/07/20 23:05:28  mwhxa2
 *  Added Check for no Print Requests
 *
 *  Revision 1.9  2010/07/13 00:53:02  mwhxa2
 *  Updated User Context
 *
 *  Revision 1.8  2010/07/13 00:25:57  mwhxa2
 *  Changed validation logic
 *
 *  Revision 1.6  2010/07/12 18:54:05  mwrsk
 *  Add capability for composite request
 *
 *  Revision 1.5  2010/05/09 21:31:34  mwakg
 *  Sending PrintServiceResponse instance instead of null
 *
 *  Revision 1.4  2010/05/07 18:11:41  mwhxa2
 *  Print Service changes
 *
 *  Revision 1.3  2010/03/22 23:40:05  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.2  2010/02/09 19:07:19  mwhxa2
 *  Updated Composite Print Request Functionality
 *
 *  Revision 1.1  2010/02/09 00:57:45  mwhxa2
 *  Adding CompositePrintRequest
 *
*/
