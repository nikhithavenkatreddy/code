/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.request.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.service.impl.AbstractRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.office.business.request.IOfficeBusinessServiceRequest;
import gov.ca.dmv.ease.tus.office.business.response.IOfficeBusinessServiceResponse;

import java.util.Date;

/**
 * Description: I define the OfficeBusinessServiceRequest interface
 * 
 * File: OfficeBusinessServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.office.business.request.impl
 * Created: Jan 11, 2011 
 * @author MWXXW 
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class OfficeBusinessServiceRequest extends AbstractRequest
		implements IOfficeBusinessServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7061534909735756181L;
	
	/**
	 * The Constructor.
	 * 
	 * @param userContext the user context
	 */
	public OfficeBusinessServiceRequest(IUserContext userContext) {
		super(userContext);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.auth.request.IAuthAndAuthServiceRequest#execute()
	 */
	public abstract IOfficeBusinessServiceResponse execute();
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.impl.AbstractRequest#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		super.validateUsing(aCollector);
		if (!EaseUtil.isNullOrBlank(getUserContext())) {
			//Validating Work date
			Date workDate = getUserContext().getWorkDate();
			if (workDate == null) {
				aCollector.register(new EaseValidationException(
						"Invalid Work date"));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: OfficeBusinessServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/10/25 23:47:34  mwhys
 *  Override validateUsing() from AbstractRequest.
 *
 *  Revision 1.1  2011/01/12 01:26:54  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *
 */
