/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.config.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.TransientActivity;
import gov.ca.dmv.ease.app.activity.impl.TransitionsMap;
import gov.ca.dmv.ease.app.config.IProcessLoader;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.context.impl.EaseApplicationContext;
import gov.ca.dmv.ease.app.exception.impl.ProcessLoadException;
import gov.ca.dmv.ease.app.process.impl.BusinessProcess;
import gov.ca.dmv.ease.app.process.impl.TransactionType;
import gov.ca.dmv.ease.config.impl.Configuration;
import gov.ca.dmv.ease.validator.IValidationRule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Description: This class performs the following tasks, 
 * 1. Load all the business processes and sub-process activities from XML definitions. 
 * 2. Initialize all the activity classes and link them based on the flow.
 * 
 * File: ProcessLoader.java
 * Module:  gov.ca.dmv.ease.app.config.impl
 * Created: Feb 23, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProcessLoader implements IProcessLoader, ApplicationContextAware {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(ProcessLoader.class);

	/**
	 * Gets the attribute value.
	 * 
	 * @param nodeList the node list
	 * @param attributeName the attribute name
	 * 
	 * @return the attribute value
	 */
	private static String getAttributeValue(NodeList nodeList,
			String attributeName) {
		String attributeValue = null;
		if (nodeList.item(0).getAttributes().getNamedItem(attributeName) != null) {
			attributeValue = nodeList.item(0).getAttributes().getNamedItem(
					attributeName).getNodeValue();
		}
		return attributeValue;
	}

	/** The Spring application context. */
	private ApplicationContext applicationContext;
	/** Used to store BP ids with their cached activities. Used to restore activities during session management */
	private HashMap <String, HashMap <String, Activity>> bpActivitiesList;
	/** The business process file names. */
	private List <String> businessProcessFileNames;
	/** The process registry. */
	private IProcessRegistry processRegistry;

	/**
	 * Gets Activity instance by id.
	 * 
	 * @param activityId the activity id
	 * @param cachedActivities the cached activities
	 * 
	 * @return the Activity
	 */
	private Activity getActivity(String activityId,
			HashMap <String, Activity> cachedActivities) {
		if (cachedActivities != null
				&& cachedActivities.containsKey(activityId)) {
			return cachedActivities.get(activityId);
		}
		else {
			//TODO despringify
			Activity activity = (Activity) getApplicationContext().getBean(
					activityId);
			activity.setActivityName(activityId);
			return activity;
		}
	}

	/**
	 * Return the reference to the activity from the given
	 * business process.
	 *
	 * @param businessProcessId the business process id
	 * @param activityName the activity name
	 * @return Activity
	 */
	public Activity getActivityReference(String businessProcessId,
			String activityName) {
		if (isNotNull(activityName) && isNotNull(bpActivitiesList)) {
			HashMap <String, Activity> cachedActivities = bpActivitiesList
					.get(businessProcessId);
			if (isNotNull(cachedActivities)) {
				return cachedActivities.get(activityName);
			}
		}
		return null;
	}

	/**
	 * This method loads the rules instances from the node if any.
	 * 
	 * @param rulesNode The rules nodes
	 * 
	 * @return List of rules from the node that was passed
	 */
	private List <IValidationRule> getAllRuleInstances(Node rulesNode) {
		List <IValidationRule> ruleInstances = new ArrayList <IValidationRule>();
		if (rulesNode != null) {
			StringTokenizer tokenizer = new StringTokenizer(rulesNode
					.getNodeValue(), ",");
			while (tokenizer.hasMoreTokens()) {
				String ruleBeanName = tokenizer.nextToken();
				ruleInstances.add((IValidationRule) getApplicationContext()
						.getBean(ruleBeanName));
			}
		}
		return ruleInstances;
	}

	/**
	 * Gets the application context.
	 * 
	 * @return the application context
	 */
	private ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/**
	 * Loads the business processes.
	 * 
	 * @param document the document
	 * 
	 * @return the BusinessProcess object
	 */
	private BusinessProcess getBusinessProcess(Document document) {
		BusinessProcess businessProcess = getBusinessProcessInstance();
		try {
			NodeList rootNodes = document
					.getElementsByTagName(BUSINESS_PROCESS);
			businessProcess.setId(getBusinessProcessName(rootNodes));
			businessProcess
					.setContextClassName(getBusinessProcessContextClassName(rootNodes));
			//Set start activity to business process
			Activity startActivity = getStartActivity(rootNodes);
			businessProcess.setStartingActivity(startActivity);
			HashMap <String, Activity> cachedActivities = new LinkedHashMap <String, Activity>();
			loadAllBusinessProcessActivities(document, startActivity,
					cachedActivities);
			bpActivitiesList.put(businessProcess.getId(), cachedActivities);
			LOGGER.info(getBusinessProcessAsTree(cachedActivities,
					businessProcess));
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			throw new ProcessLoadException("ERROR GETTING BUSINESS PROCESS :: "
					+ businessProcess.getId(), ex);
		}
		return businessProcess;
	}

	/**
	 * Gets the business process as tree.
	 * 
	 * @param cachedActivities the cached activities
	 * @param businessProcess the business process
	 * 
	 * @return the business process as tree
	 */
	private String getBusinessProcessAsTree(
			HashMap <String, Activity> cachedActivities,
			BusinessProcess businessProcess) {
		StringBuilder strBpTree = new StringBuilder("\n");
		strBpTree
				.append("----------------------------------------------------\n");
		strBpTree.append("          " + businessProcess.getId()
				+ "           \n");
		strBpTree
				.append("----------------------------------------------------\n");
		Iterator <Map.Entry <String, Activity>> iterator = cachedActivities
				.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry <String, Activity> entry = iterator.next();
			strBpTree.append("-" + entry.getValue().getActivityName() + "\n");
			if (entry.getValue() instanceof TransientActivity) {
				TransientActivity transientActivity = (TransientActivity) entry
						.getValue();
				TransitionsMap transitionsMap = transientActivity
						.getTransitions();
				Iterator <Map.Entry <String, Activity>> transIterator = transitionsMap
						.getAllTransitions().iterator();
				while (transIterator.hasNext()) {
					Map.Entry <String, Activity> entryTrans = transIterator
							.next();
					String activityBeanName = null;
					if (entryTrans.getValue() != null) {
						activityBeanName = entryTrans.getValue()
								.getActivityName();
					}
					strBpTree.append("--(" + entryTrans.getKey() + " - "
							+ activityBeanName + ")\n");
				}
			}
		}
		strBpTree
				.append("----------------------------------------------------\n");
		return strBpTree.toString();
	}

	/**
	 * Gets the business process context class name.
	 * 
	 * @param rootNodes the root nodes
	 * 
	 * @return the business process context class name
	 */
	private String getBusinessProcessContextClassName(NodeList rootNodes) {
		return getAttributeValue(rootNodes, BUSINESS_PROCESS_CONTEXT_CLASS);
	}

	/**
	 * Load the business process.
	 * 
	 * @param aFilename , the business process xml file name
	 * 
	 * @return the business process document
	 */
	private Document getBusinessProcessDocument(String aFilename) {
		Document document = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(false);
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.parse(getClass().getResourceAsStream(aFilename));
		}
		catch (ParserConfigurationException pce) {
			LOGGER.error(pce);
			throw new ProcessLoadException(
					"Parser Configuration Exception when loading business process file :: "
							+ aFilename + "; " + pce.getMessage(), pce);
		}
		catch (Exception ex) {
			LOGGER.error(ex);
			throw new ProcessLoadException("Exception "
					+ ex.getClass().getName()
					+ " when loading business process file :: " + aFilename
					+ "; " + ex.getMessage(), ex);
		}
		return document;
	}

	/**
	 * Sets the business process file names.
	 * 
	 * @return the business process file names
	 */
	private List <String> getBusinessProcessFileNames() {
		return businessProcessFileNames;
	}

	/**
	 * Gets a new instance of BusinessProcess.
	 *
	 * @return a business process
	 */
	private BusinessProcess getBusinessProcessInstance() {
		//TODO despringify
		return (BusinessProcess) getApplicationContext().getBean(
				BUSINESS_PROCESS_BEAN_NAME);
	}

	/**
	 * Gets the business process name.
	 * 
	 * @param rootNodes the root nodes
	 * 
	 * @return the business process name
	 */
	private String getBusinessProcessName(NodeList rootNodes) {
		return getAttributeValue(rootNodes, BUSINESS_PROCESS_NAME);
	}

	/**
	 * Gets the process registry.
	 * 
	 * @return the processRegistry
	 */
	public IProcessRegistry getProcessRegistry() {
		return processRegistry;
	}

	/**
	 * Gets start activity from root nodes.
	 * 
	 * @param rootNodes the root nodes
	 * 
	 * @return the start activity
	 */
	private Activity getStartActivity(NodeList rootNodes) {
		String startStep = getStartStep(rootNodes);
		Activity startActivity = getActivity(startStep, null);
		return startActivity;
	}

	/**
	 * Gets the start step.
	 * 
	 * @param rootNodes the root nodes
	 * 
	 * @return the start step
	 */
	private String getStartStep(NodeList rootNodes) {
		return getAttributeValue(rootNodes, BUSINESS_PROCESS_START_ACTIVITY);
	}

	/**
	 * Given a step/node name the method returns the.
	 * 
	 * @param document the document
	 * @param stepName the step name
	 * 
	 * @return the step with name
	 */
	private Node getStepWithName(Document document, String stepName) {
		NodeList nodes = document.getElementsByTagName(STEP);
		for (int i = 0; i < nodes.getLength(); i++) {
			if (nodes.item(i).getAttributes().getNamedItem(STEP_NAME)
					.getNodeValue().toString().equalsIgnoreCase(stepName)) {
				return nodes.item(i);
			}
		}
		return null;
	}

	/**
	 * Builds a TransactionType object from a node.
	 *
	 * @param parentNode the parent node
	 * @return the transaction type
	 */
	private TransactionType getTransactionType(Node parentNode) {
		TransactionType transType = getTransactionTypeInstance();
		NodeList nodes = parentNode.getChildNodes();
		for (int i = 0; i < nodes.getLength(); ++i) {
			Node node = nodes.item(i);
			if (node.getNodeName().equals(TCODE)) {
				transType.setTcode(node.getTextContent());
			}
			else if (node.getNodeName().equals(SECURITY_ROLE)) {
				transType.addSecurityRole(node.getTextContent());
			}
		}
		return transType;
	}

	/**
	 * Gets a new instance of TransactionType.
	 * 
	 * @return the business process
	 */
	private TransactionType getTransactionTypeInstance() {
		//TODO despringify
		return (TransactionType) getApplicationContext().getBean(
				TRANSACTION_TYPE_BEAN_NAME);
	}

	/**
	 * Gets the transaction type registry.
	 *
	 * @return the transaction type registry
	 */
	public ITransactionTypeRegistry getTransactionTypeRegistry() {
		//TODO despringify
		return (ITransactionTypeRegistry) getApplicationContext().getBean(
				"transactionTypeRegistry");
	}

	/**
	 * Gets the transaction codes.
	 *
	 * @param document the document
	 * @return the transaction codes
	 */
	private List <TransactionType> getTransactionTypes(Document document) {
		NodeList nodes = document.getElementsByTagName(TRANSACTION_TYPE);
		List <TransactionType> transTypes = new ArrayList <TransactionType>();
		for (int i = 0; i < nodes.getLength(); ++i) {
			Node node = nodes.item(i);
			transTypes.add(getTransactionType(node));
		}
		if (transTypes.size() > 0) {
			setProcessNameToTransactions(transTypes, document);
			return transTypes;
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the transition map for activity.
	 * 
	 * @param activity the activity
	 * 
	 * @return the transition map for activity
	 */
	private TransitionsMap getTransitionMapForActivity(
			TransientActivity activity) {
		if (activity.getTransitions() == null) {
			TransitionsMap transitionsMap = new TransitionsMap();
			activity.setTransitions(transitionsMap);
		}
		return activity.getTransitions();
	}

	/**
	 * Initialize process registry based on the list of XML mapping files.
	 */
	public void initialize() {
		Configuration.getInstance().initialize();
		try {
			bpActivitiesList = new HashMap <String, HashMap <String, Activity>>();
			for (String aFilename : getBusinessProcessFileNames()) {
				Document businessProcessDocument = getBusinessProcessDocument(aFilename);
				BusinessProcess businessProcess = getBusinessProcess(businessProcessDocument);
				List <TransactionType> transTypes = getTransactionTypes(businessProcessDocument);
				registerTransactionTypes(transTypes);
				businessProcess.setTransactionTypes(transTypes);
				getProcessRegistry().addProcess(businessProcess);
			}
		}
		catch (Exception ex) {
			processRegistry = null;
			LOGGER.error(ex);
			throw new ProcessLoadException(
					"ERROR INITIALIZING BUSINESS PROCESSES", ex);
		}
	}

	/**
	 * Loads the business processes and sub-process activities from XML definitions, set TransitionsMap for each TransientActivity.
	 * 
	 * @param document the document
	 * @param activity the activity
	 * @param cachedActivities the cached activities
	 */
	private void loadAllBusinessProcessActivities(Document document,
			Activity activity, HashMap <String, Activity> cachedActivities) {
		try {
			if (activity != null && (activity instanceof TransientActivity)) {
				TransientActivity transientActivity = (TransientActivity) activity;
				TransitionsMap transitionsMap = getTransitionMapForActivity(transientActivity);
				// If the activity is already loaded load from the cache
				if (cachedActivities.containsKey(activity.getActivityName())) {
					transitionsMap.addTransitions(activity.getActivityName(),
							cachedActivities.get(activity.getActivityName()));
				}
				// Load the activity from the XML and cache it
				else {
					Node activityNode = getStepWithName(document, activity
							.getActivityName());
					loadSyncInformation(transientActivity, activityNode);
					loadSaveInformation(transientActivity, activityNode);
					//Load all the rules like pre, post and evaluation criteria
					loadRules(transientActivity, activityNode);
					if (((Element) activityNode) != null
							&& ((Element) activityNode)
									.getElementsByTagName(TRANSITION) != null) {
						NodeList childNodes = ((Element) activityNode)
								.getElementsByTagName(TRANSITION);
						for (int i = 0; i < childNodes.getLength(); i++) {
							Node childNode = childNodes.item(i);
							Node transitionToNode = childNode.getAttributes()
									.getNamedItem(TRANSITION_TO);
							Activity transistionToActivity = null;
							if (transitionToNode != null) {
								String transitionToActivityName = transitionToNode
										.getNodeValue();
								transistionToActivity = getActivity(
										transitionToActivityName,
										cachedActivities);
							}
							Node transitionOnNode = childNode.getAttributes()
									.getNamedItem(TRANSITION_ON);
							String transitionKey = DEFAULT_TRANSITION_KEY;
							if (transitionOnNode != null) {
								transitionKey = transitionOnNode.getNodeValue();
							}
							transitionsMap.addTransitions(transitionKey,
									transistionToActivity);
							cachedActivities.put(activity.getActivityName(),
									activity);
							loadAllBusinessProcessActivities(document,
									transistionToActivity, cachedActivities);
						}
					}
				}
			}
		}
		catch (Exception e) {
			LOGGER.error(e);
			//TODO throw an exeption - failure here is likely to be non-continuable
			e.printStackTrace();
		}
	}

	/**
	 * This method loads the post condition rules for an activity.
	 * 
	 * @param transientActivity the transientActivity
	 * @param activityNode the activityNode
	 */
	private void loadPostConditionValidationRules(
			TransientActivity transientActivity, Node activityNode) {
		if (activityNode != null
				&& activityNode.getAttributes() != null
				&& activityNode.getAttributes().getNamedItem(
						POST_CONDITION_RULES) != null) {
			transientActivity
					.setPostConditionValidationRules(getAllRuleInstances(activityNode
							.getAttributes().getNamedItem(POST_CONDITION_RULES)));
		}
	}

	/**
	 * This method loads the pre condition rules for an activity.
	 * 
	 * @param transientActivity the transientActivity
	 * @param activityNode the activityNode
	 */
	private void loadPreConditionValidationRules(
			TransientActivity transientActivity, Node activityNode) {
		if (activityNode != null
				&& activityNode.getAttributes() != null
				&& activityNode.getAttributes().getNamedItem(
						PRE_CONDITION_RULES) != null) {
			transientActivity
					.setPreConditionValidationRules(getAllRuleInstances(activityNode
							.getAttributes().getNamedItem(PRE_CONDITION_RULES)));
		}
	}

	/**
	 * This method loads the rules for a particular activity.
	 * 
	 * @param transientActivity the transient activity
	 * @param activityNode the activity node
	 */
	private void loadRules(TransientActivity transientActivity,
			Node activityNode) {
		// Precondition rules
		loadPreConditionValidationRules(transientActivity, activityNode);
		// Postcondition rules
		loadPostConditionValidationRules(transientActivity, activityNode);
	}

	/**
	 * Load sync information.
	 * 
	 * @param transientActivity the transient activity
	 * @param activityNode the activity node
	 */
	private void loadSyncInformation(TransientActivity transientActivity,
			Node activityNode) {
		if (activityNode != null
				&& activityNode.getAttributes() != null
				&& activityNode.getAttributes().getNamedItem(SYNC_POINT) != null) {
			String syncPoint = activityNode.getAttributes().getNamedItem(
					SYNC_POINT).getNodeValue();
			transientActivity.setSyncPoint(syncPoint.equalsIgnoreCase("true"));
		}
	}

	/**
	 * Load save point information.
	 * 
	 * @param transientActivity the transient activity
	 * @param activityNode the activity node
	 */
	private void loadSaveInformation(TransientActivity transientActivity,
			Node activityNode) {
		if (activityNode != null
				&& activityNode.getAttributes() != null
				&& activityNode.getAttributes().getNamedItem(SAVE_POINT) != null) {
			String savePoint = activityNode.getAttributes().getNamedItem(
					SAVE_POINT).getNodeValue();
			transientActivity.setSavePoint(savePoint.equalsIgnoreCase("true"));
		}
	}

	/**
	 * Adds the TransactionType list to the TransactionType registry.
	 *
	 * @param transTypes the trans types
	 */
	private void registerTransactionTypes(List <TransactionType> transTypes) {
		if (transTypes != null) {
			for (TransactionType trans : transTypes) {
				getTransactionTypeRegistry().addTransactionType(trans);
			}
		}
	}

	/**
	 * Setter to allow Spring to inject the application context.
	 *
	 * @param applicationContext the new application context
	 */
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
		LOGGER.info(this + "::setApplicationContext("
				+ applicationContext + ")");
		// temporary fix 
		new EaseApplicationContext().setApplicationContext(applicationContext); //TODO - temporary fix
	}

	/**
	 * Sets the business process file names.
	 * 
	 * @param businessProcessFileNames the businessProcessFileNames to set
	 */
	public void setBusinessProcessFileNames(
			List <String> businessProcessFileNames) {
		this.businessProcessFileNames = businessProcessFileNames;
	}

	/**
	 * Sets the business process name into each transaction type.
	 *
	 * @param transTypes the trans types
	 * @param document the document
	 */
	private void setProcessNameToTransactions(
			List <TransactionType> transTypes, Document document) {
		NodeList rootNodes = document.getElementsByTagName(BUSINESS_PROCESS);
		String processName = getBusinessProcessName(rootNodes);
		for (TransactionType trans : transTypes) {
			trans.setBusinessProcessName(processName);
		}
	}

	/**
	 * Sets the process registry.
	 * 
	 * @param processRegistry the processRegistry to set
	 */
	public void setProcessRegistry(IProcessRegistry processRegistry) {
		this.processRegistry = processRegistry;
	}
}
/**
 * Modification History:
 * 
 * $Log: ProcessLoader.java,v $
 * Revision 1.1  2012/10/01 02:57:23  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.31  2012/08/16 20:42:51  mwkzn
 * Using Loggers in place of SOP.
 *
 * Revision 1.30  2012/08/16 19:51:13  mwkfh
 * change Configuration to initialize
 *
 * Revision 1.29  2012/08/16 18:23:21  mwkfh
 * added Configuration read
 *
 * Revision 1.28  2012/05/08 00:13:28  mwhys
 * Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 * Revision 1.27.4.1  2012/02/21 21:15:02  mwsec2
 * save point support added
 *
 * Revision 1.27  2011/10/12 20:54:54  mwkkc
 * Performance Merge
 *
 * Revision 1.26.8.2  2011/09/28 02:46:01  mwpxp2
 * Added de-springification todos
 *
 * Revision 1.26.8.1  2011/09/27 23:43:52  mwpxp2
 * Added temp fix for setting process context instance
 *
 * Revision 1.26  2011/06/09 17:04:20  mwyxg1
 * clean up
 *
 * Revision 1.25  2010/12/28 19:32:11  mwsec2
 * cleaned up after previous change whereby the transactionTypeRegistry is taken directly from app context rather than via Spring DI
 *
 * Revision 1.24  2010/12/02 00:14:57  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.23  2010/09/28 23:29:46  mwsec2
 * removed security roles from business process
 *
 * Revision 1.22  2010/09/23 19:42:14  mwhys
 * Session management:
 * (1) Introduced an instance variable to hold the cached activities for all the business processes.
 * (2) Added a method to obtain reference to a specified activity with a given business process.
 *
 * Revision 1.21  2010/09/14 17:11:37  mwhys
 * (1) Changed the access modifier of the getProcessRegistry() method to public, so that AuthorizeTransactionActivity can access it during process restore.
 * (2) getTransactionTypeRegistry: Obtain reference to the SINGLETON object present in the Application context.
 *
 * Revision 1.20  2010/09/03 17:04:08  mwsec2
 * enhanced to support multiple TTCs per BP XML; some refactor and clean up
 *
 * Revision 1.19  2010/08/20 18:03:28  mwpxp2
 * Added todo, javadoc
 *
 * Revision 1.18  2010/08/12 18:55:57  mwcsj3
 * Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 * Revision 1.17  2010/08/05 00:12:25  mwcsj3
 * Added some NULL checks
 *
 * Revision 1.16  2010/07/30 21:56:18  mwakg
 * Added debug statements and also added support for transitions without any targets
 *
 * Revision 1.15  2010/07/23 14:49:47  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.13.2.1  2010/06/27 01:44:59  mwakg
 * Updated process loader to read the sync_point
 *
 * Revision 1.14  2010/07/08 02:00:56  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.13  2010/06/21 23:00:49  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.12.2.2  2010/06/08 22:58:00  mwcsj3
 * Updated getAttributeValue method to fix NULL pointer exception
 *
 * Revision 1.12.2.1  2010/06/08 01:32:08  mwakg
 * Removed Security roles from Sub business Process.
 *
 * Revision 1.12  2010/05/20 00:29:37  mwpxp2
 * Modified logging of exceptions in getBusinessProcessDocument
 *
 * Revision 1.11  2010/05/04 00:51:06  mwpxp2
 * Imports adjusted for interface move to non-impl package
 *
 * Revision 1.10  2010/04/29 22:48:37  mwcsj3
 * Removed method that loads evaluation criteria
 *
 * Revision 1.9  2010/04/29 17:55:01  mwcsj3
 * Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 * Revision 1.8  2010/04/28 16:28:48  mwakg
 * Logging the complete exception instead of the exception message
 *
 * Revision 1.7  2010/04/22 19:09:31  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.6  2010/04/08 01:55:37  mwcsj3
 * Cleaned up, removed all unused and redundant methods
 *
 * Revision 1.5  2010/04/01 00:11:44  mwakg
 * Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 * Revision 1.4  2010/03/31 19:42:27  mwakg
 * Added Debug statements.
 * Stopping process loading when there are exceptions
 *
 * Revision 1.3  2010/03/26 21:19:10  mwcsj3
 * Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 * Revision 1.2  2010/03/22 23:03:12  mwpxp2
 * Javadoc/cleanup
 *
 * Revision 1.1  2010/03/18 18:42:16  mwcsj3
 * Renamed ProcessLoaderImpl to ProcessLoader
 *
 * Revision 1.3  2010/03/17 19:22:50  mwcsj3
 * Fixed issue with setting activity name
 *
 * Revision 1.2  2010/03/11 22:19:29  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.1.2.6  2010/03/11 19:00:38  mwcsj3
 * Fixed loading issue for multiple transitions/multiple entries in XML file
 *
 * Revision 1.1.2.5  2010/03/08 19:44:29  mwcsj3
 * Commented System.out.println()
 *
 * Revision 1.1.2.4  2010/03/04 03:09:58  mwcsj3
 * Made changes to get process registry from application context
 *
 * Revision 1.1.2.3  2010/02/26 23:32:14  mwyxg1
 * process multi process transition, update documentation
 *
 * Revision 1.1.2.2  2010/02/26 18:54:48  mwcsj3
 * Added constants
 *
 * Revision 1.1.2.1  2010/02/26 18:20:59  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * 
 */
