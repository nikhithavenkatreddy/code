/**
 * 
 */
package gov.ca.dmv.ease.app.context.impl;


/**
 * Description: process context class for the 'pseudo menu' process (used for executing business processes
 * outside the web container)
 * 
 * File: PseudoMenuProcessContext.java
 * Module:  gov.ca.dmv.ease.app.context.impl
 * Created: May 31, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PseudoMenuProcessContext extends ChildContext {
	private static final long serialVersionUID = -5418370476678729710L;
}

/**
 *  Modification History:
 *
 *  $$Log: PseudoMenuProcessContext.java,v $
 *  $Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.2  2012/06/08 17:19:37  mwsec2
 *  $initial check-in of classes to support the running of business processes outside an HTTP session context
 *  $$
 */
