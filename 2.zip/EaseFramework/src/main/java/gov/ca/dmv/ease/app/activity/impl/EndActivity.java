/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ChildContext;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;

/**
 * Description: I represent the final activity in a process
 * File: EndActivity.java
 * Module:  gov.ca.dmv.ease.app.activity
 * Created:   2009 
 * @author mwsmg6  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/12/13 00:36:33 $
 * Last Changed By: $Author: mwhys $
 */
public final class EndActivity extends Activity {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5308055221627595093L;
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.activity.Activity#execute(gov.ca.dmv.ease.app.context.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext processContext) {
		//		processContext.record(this);
		if ((processContext instanceof ChildContext)
				&& ((ChildContext) processContext).isMainBusinessProcess()) {
			deleteSavePoint(processContext.getRootContext());
		}
		processContext.end();
	}
}
/**
 *  Modification History:
 *
 *  $Log: EndActivity.java,v $
 *  Revision 1.2  2012/12/13 00:36:33  mwhys
 *  Updated call deleteSavePoint
 *
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/05/08 00:07:36  mwhys
 *  Added call to deleteSavePoint() for Session Management.
 *
 *  Revision 1.7  2010/06/21 23:00:41  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.6.6.1  2010/06/20 18:06:53  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.5  2010/04/14 15:38:59  mwakg
 *  Made activities authorizedExecute protected
 *
 *  Revision 1.4  2010/04/13 23:24:19  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.3  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.2.2.1  2010/02/26 17:34:00  mwyxg1
 *  process multi process transition
 *
 *  Revision 1.2  2009/12/09 19:19:03  mwbxp5
 *  Adding serial Version UID
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/07 19:16:21  mwbxp5
 *  Removed LOGGER
 *
 *  Revision 1.1  2009/10/03 20:57:17  mwpxp2
 *  Moved into .impl; adjusted imports
 *
 *  Revision 1.6  2009/10/03 20:05:25  mwpxp2
 *  Added class comment, javadoc
 *
 *  Revision 1.5  2009/08/10 23:30:08  mwpxp2
 *  Added logging; bulk cleanup; added file decorations where missing
 *
 */
