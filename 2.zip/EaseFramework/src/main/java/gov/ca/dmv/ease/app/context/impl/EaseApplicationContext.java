/**
 * 
 */
package gov.ca.dmv.ease.app.context.impl;

import gov.ca.dmv.ease.app.action.impl.ActionsRegistry;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.config.ITransactionTypeRegistry;
import gov.ca.dmv.ease.app.config.impl.ProcessLoader;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.process.IUserContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * Description: This class provides Spring application context. We can access 
 * the Spring-ApplicationContext from everywhere in EASE application without
 * making the class implement ApplicationContextAware interface.
 * 
 * File: EaseApplicationContext.java
 * Module:  gov.ca.dmv.ease.app.context.impl
 * Created: Mar 25, 2010 
 * @author MWCSJ3  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2013/09/12 21:13:52 $
 * Last Changed By: $Author: mwsec2 $
 */
// FIXME - this is a general purpose util class that needs to be moved to a util package. It is not a process context.
public class EaseApplicationContext implements ApplicationContextAware {
	/** Holds Spring application Context. */
	private static ApplicationContext APPLICATION_CONTEXT;
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(EaseApplicationContext.class);
	
	/**
	 * Gets the actions registry.
	 *
	 * @return the actions registry
	 */
	public static ActionsRegistry getActionsRegistry() {
		return (ActionsRegistry) getApplicationContext().getBean(
				"actionsRegistry");
	}
	
	/**
	 * Retuns Spring application context.
	 *
	 * @return ApplicationContext
	 */
	public static ApplicationContext getApplicationContext() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("gov.ca.dmv.ease.app.context.impl.EaseApplicationContext::getApplicationContext = "
							+ APPLICATION_CONTEXT);
		}
		return EaseApplicationContext.APPLICATION_CONTEXT;
	}
	
	/**
	 * Gets the code set registry singleton.
	 *
	 * @return the code set registry singleton
	 */
	public static CodeSetRegistrySingleton getCodeSetRegistrySingleton() {
		return (CodeSetRegistrySingleton) getApplicationContext().getBean(
				"codeSetRegistrySingleton");
	}
	
	/**
	 * Gets the error collector.
	 *
	 * @return the error collector
	 */
	public static IErrorCollector getErrorCollector() {
		return (IErrorCollector) getApplicationContext().getBean(
				"errorCollector");
	}
	
	/**
	 * Gets the process registry.
	 *
	 * @return the process registry
	 */
	public static IProcessRegistry getProcessRegistry() {
		return (IProcessRegistry) getApplicationContext().getBean(
				"processRegistry");
	}
	
	/**
	 * Gets the process loader.
	 *
	 * @return the process loader
	 */
	public static ProcessLoader getProcessLoader() {
		return (ProcessLoader) getApplicationContext().getBean("processLoader");
	}
	
	/**
	 * Gets the transaction type registry.
	 *
	 * @return the transaction type registry
	 */
	public static ITransactionTypeRegistry getTransactionTypeRegistry() {
		return (ITransactionTypeRegistry) getApplicationContext().getBean(
				"transactionTypeRegistry");
	}
	
	/**
	 * Gets the user context.
	 *
	 * @return the user context
	 */
	public static IUserContext getUserContext() {
		return (IUserContext) getApplicationContext().getBean("userContext");
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		LOGGER.info(this + "::setApplicationContext(" + applicationContext
				+ ")");
		EaseApplicationContext.APPLICATION_CONTEXT = applicationContext;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseApplicationContext.java,v $
 *  Revision 1.3  2013/09/12 21:13:52  mwsec2
 *  put expensive log statements inside isDebugEnabled block
 *
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.4.1  2012/11/28 22:11:30  mwsec2
 *  changed logging statement to debug
 *
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/06/01 21:35:03  mwhys
 *  Added getProcessLoader(). (Session Management)
 *
 *  Revision 1.7  2011/11/15 22:35:32  mwkkc
 *  Production Cleanup
 *
 *  Revision 1.6  2011/10/12 20:54:53  mwkkc
 *  Performance Merge
 *
 *  Revision 1.5.8.7  2011/09/30 21:37:22  mwpxp2
 *  Added getUserContext/0 to encapsulate application context access via bean name
 *
 *  Revision 1.5.8.6  2011/09/29 21:49:42  mwpxp2
 *  Fixed getActionsRegistry
 *
 *  Revision 1.5.8.5  2011/09/29 00:27:16  mwpxp2
 *  Fixed unintended find/replace mistake resulting in stack overflow
 *
 *  Revision 1.5.8.4  2011/09/28 02:46:41  mwpxp2
 *  Added static calls enapsulating named bean calls
 *
 *  Revision 1.5.8.3  2011/09/27 23:23:56  mwpxp2
 *  Reverted to the original syntax on suspicion of Spring breakage
 *
 *  Revision 1.5.8.2  2011/09/27 00:43:38  mwpxp2
 *  Debug added
 *
 *  Revision 1.5.8.1  2011/09/26 05:22:12  mwpxp2
 *  Corrected static assignment in set application context
 *
 *  Revision 1.5  2011/06/09 16:38:58  mwyxg1
 *  clean up
 *
 *  Revision 1.4  2010/09/20 17:24:33  mwsec2
 *  added fixme
 *
 *  Revision 1.3  2010/08/10 17:23:54  mwpxp2
 *  Added file footer
 *
 */
