/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.session.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: Persistence service response to update the session object.
 * File: UpdateSessionPersistenceResponse.java 
 * Module: gov.ca.dmv.ease.tus.session.persist.response.impl 
 * Created: Dec 12, 2012
 * @author MWHYS
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/12/13 00:08:21 $ 
 * Last Changed By: $Author: mwhys $
 */
public class UpdateSessionPersistenceResponse extends
		SessionPersistenceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8272483893504741925L;

	/**
	 * Instantiates a new update session persistence response.
	 */
	public UpdateSessionPersistenceResponse() {
		super();
	}

	/**
	 * Instantiates a new update session persistence response.
	 *
	 * @param ex the ex
	 */
	public UpdateSessionPersistenceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new update session persistence response.
	 *
	 * @param collector the collector
	 */
	public UpdateSessionPersistenceResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new update session persistence response.
	 *
	 * @param aCollector the a collector
	 * @param anItemCount the an item count
	 */
	public UpdateSessionPersistenceResponse(IErrorCollector aCollector,
			Integer anItemCount) {
		super(aCollector, anItemCount);
	}

	/**
	 * Instantiates a new update session persistence response.
	 *
	 * @param anItemCount the an item count
	 */
	public UpdateSessionPersistenceResponse(Integer anItemCount) {
		super(anItemCount);
	}
}

/**
 *  Modification History:
 *
 *  $Log: UpdateSessionPersistenceResponse.java,v $
 *  Revision 1.1  2012/12/13 00:08:21  mwhys
 *  Initial.
 *
 *
 */