/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.logging;

/**
 * Description: Interface that needs to be implemented by the object that needs to be audited
 * when passed to a method
 *   
 * File: IAuditable.java
 * Module:  gov.ca.dmv.ease.fw
 * Created: Sep 28, 2009 
 * @author MWRSK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IAuditable {
	/**
	 * Implementor of the class needs to append the audit information to the StringBuilder.
	 * 
	 * @param aStringBuilder the a string buffer
	 */
	public void outputAuditLog(StringBuilder aStringBuilder);
}
/**
 *  Modification History:
 *
 *  $Log: IAuditable.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.2  2010/03/22 23:32:37  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:22:48  mwpxp2
 *  Moved into fw.logging; added class footer
 *
 */
