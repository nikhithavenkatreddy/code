/** *
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.aspect.impl;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ecs.bridge.request.impl.ProductionStatisticRequestEcs;

import javax.servlet.http.HttpSessionEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 * Description: The purpose of this class is to define the advisors for the being and end of session.
 * //FIXME - replace the hardcoded values (typically, Strings) by constants
 * File: SignInSignOffAspect.java
 * Module:  gov.ca.dmv.ease.aspect.impl
 * Created: Apr 10, 2010
 * @author MWPZS3
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/11/28 21:22:50 $
 * Last Changed By: $Author: mwkfh $
 */
@Aspect
public class SignInSignOffAspect extends AbstractProdStatisticsAspect {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(SignInSignOffAspect.class);

	/**
	 * @return
	 */
	private ProcessContext buildProcessContext(HttpSessionEvent event) {
		ProcessContext processContext = null;
		SessionContext sessionContext = new SessionContext();
		UserContext userContext = (UserContext) event.getSession()
				.getAttribute("userContext");
		sessionContext.setUserContext(userContext);
		processContext = sessionContext;
		return processContext;
	}

	/**
	 * The purpose of this method is to define the aspect for the behavior at the end of session.
	 *
	 * @param joinPoint the joinPoint
	 */
	@Before("execution(* gov.ca.dmv.ease.ui.listener.impl.EaseHttpSessionListener.sessionDestroyed(..)) && args(event)")
	public void endSession(JoinPoint joinPoint, HttpSessionEvent event) {
		processLogSessionContextMessage(joinPoint, SOF_TTC, event);
		processProductionStatistics(joinPoint, SOF_TTC, event);
	}

	/**
	 * Process log session context message.
	 *
	 * @param processContext the processContext
	 * @param completionCode the completion code
	 */
	private void processLogSessionContextMessage(JoinPoint joinPoint,
			String ttc, HttpSessionEvent event) {
		ProcessContext processContext = null;
		if (event != null) {
			processContext = buildProcessContext(event);
		}
		else {
			processContext = (ProcessContext) EaseProxyUtils
					.getProxyObject(joinPoint.getTarget());
		}
		if (!isValid(processContext)) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("Invalid process context: " + processContext
						+ " in " + this);
			}
			return;
		}
		/* Cachiering Sequence # */
		String cachieringSeqNumber = "";
		/* DL/ID Indicator */
		String dlOrIdIndicator = "";
		String bridgeMessage = super.processProductionStatistics(
				processContext, COMPLETION_CODE_N, cachieringSeqNumber,
				dlOrIdIndicator, ttc);
		super
				.logSessionContextMessage(joinPoint, processContext,
						bridgeMessage);
	}

	/**
	 * Process production statistics.
	 *
	 * @param processContext the processContext
	 * @param completionCode the completion code
	 */
	private void processProductionStatistics(JoinPoint joinPoint, String ttc,
			HttpSessionEvent event) {
		ProcessContext processContext = null;
		if (event != null) {
			processContext = buildProcessContext(event);
		}
		else {
			processContext = (ProcessContext) EaseProxyUtils
					.getProxyObject(joinPoint.getTarget());
		}
		if (!isValid(processContext)) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("Invalid process context: " + processContext
						+ " in " + this);
			}
			return;
		}
		/* Cachiering Sequence # */
		String cachieringSeqNumber = "";
		/* DL/ID Indicator */
		String dlOrIdIndicator = "";
		ProductionStatisticRequestEcs aRequest = BRIDGE_REQUEST_FACTORY
				.createProductionStatisticRequestEcs(processContext
						.getUserContext(), COMPLETION_CODE_N,
						cachieringSeqNumber, dlOrIdIndicator, ttc);
		aRequest.execute();
	}

	/**
	 * The purpose of this method is to define the aspect for the behavior at the begin of session.
	 *
	 * @param joinPoint the joinPoint
	 */
	@After("execution(* gov.ca.dmv.ease.app.context.impl.SessionContext.myInit())")
	public void startSession(JoinPoint joinPoint) {
		processLogSessionContextMessage(joinPoint, SON_TTC, null);
		processProductionStatistics(joinPoint, SON_TTC, null);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SignInSignOffAspect.java,v $
 *  Revision 1.3  2012/11/28 21:22:50  mwkfh
 *  changed isValid to !isValid in check in processProdStat
 *
 *  Revision 1.2  2012/11/07 23:57:31  mwkfh
 *  changed isValid to !isValid in check
 *
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.19  2012/09/26 21:22:16  mwpxp2
 *  Added validation of process context; formatted; added logger
 *
 *  Revision 1.18  2012/08/16 22:05:03  mwkzn
 *  Cascading changes for renaming EASEHttpSessionListener to EaseHttpSessionListener
 *
 *  Revision 1.17  2012/03/23 21:27:07  mwxxw
 *  Change the pointcut to EASEHttpSessionListener.sessionDestroyed(..).
 *
 *  Revision 1.16  2011/11/02 22:32:30  mwxxw
 *  Stop sending BPRS message if the office id is not exist.
 *
 *  Revision 1.15  2011/06/10 21:14:27  mwyxg1
 *  clean up
 *
 *  Revision 1.14  2011/05/26 01:09:28  mwxxw
 *  Fix the loggoff bridge message.
 *
 *  Revision 1.13  2010/12/23 06:10:39  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.12.2.2  2010/12/23 01:29:47  mwkkc
 *  Rebase from head - Arch
 *
 *  Revision 1.12  2010/12/13 02:55:24  mwpxr4
 *  added logs, constants and corrected call for production statistics converter for BPRS Bridge TCode.
 *
 *  Revision 1.10  2010/07/31 00:13:13  mwkkc
 *  Auditing and Logging Work
 *
 *  Revision 1.9  2010/07/13 17:11:02  mwkfh
 *  relocated session restore packages
 *
 *  Revision 1.8  2010/07/08 01:52:14  mwpxp2
 *  Added fixmes; cleaned up
 *
 *  Revision 1.7  2010/06/24 16:59:17  mwvkm
 *  Problem fixed with ClassCastException
 *
 *  Revision 1.6  2010/06/22 00:05:10  mwvkm
 *  Production statistics is updated with Sign and Sign Off.
 *
 *  Revision 1.4  2010/06/14 21:15:36  mwvkm
 *  Design for fraud protection is done. Spring-aop is removed and instead using the AspectJ
 *
 *  Revision 1.3  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.2  2010/04/22 19:09:31  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/04/12 02:35:04  mwpzs3
 *  update for production statistics
 *
 */
