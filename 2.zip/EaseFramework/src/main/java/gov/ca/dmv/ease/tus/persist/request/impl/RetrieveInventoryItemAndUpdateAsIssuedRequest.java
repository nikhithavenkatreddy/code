/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.IInventoryItemRetrievable;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;

/**
 * Description: I am the request for retrieving a Driver License number
 * 
 * File: RetrieveDlNumberRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Aug 24, 2009
 * 
 * @author MWRSK
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RetrieveInventoryItemAndUpdateAsIssuedRequest extends
		PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8651356590952092520L;
	private IInventoryItemRetrievable inventoryItem;

	/**
	 * Instantiates a new retrieve dl number request.
	 * 
	 * @param aUserContext the a user context
	 * @param anInventoryItem the an inventory item
	 */
	public RetrieveInventoryItemAndUpdateAsIssuedRequest(
			IUserContext aUserContext, IInventoryItemRetrievable anInventoryItem) {
		super(aUserContext);
		this.inventoryItem = anInventoryItem;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public PersistenceServiceResponse execute() {
		return getPersistenceService().execute(this);
	}

	/**
	 * Gets the an inventory item.
	 * 
	 * @return the an inventory item
	 */
	public IInventoryItemRetrievable getInventoryItem() {
		return inventoryItem;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: RetrieveInventoryItemAndUpdateAsIssuedRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/09/14 00:40:33  mwkfh
 *  made persistenceService non-static
 *
 *  Revision 1.2  2010/09/13 04:39:46  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/13 23:18:06  mwrsk
 *  Moved PersistenceServiceResponse to impl package
 *
 *  Revision 1.5  2009/10/03 21:32:44  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/09/03 22:35:02  mwrsk
 *  refactor code
 *
 *  Revision 1.3  2009/08/27 03:45:06  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/26 00:07:57  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/08/25 16:34:21  mwrsk
 *  Changed the request name to RetrieveInventoryItemAndUpdateAsIssuedRequest
 *
 *  Revision 1.1  2009/08/25 16:08:39  mwrsk
 *  Updated to retrieve anyInventoryItem
 *
 *  Revision 1.1  2009/08/25 01:56:34  mwrsk
 *  Added new API for retrieving DL Inventory Item
 *
*/
