/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.listeners.bridge.handler.impl;

/**
 * Description: I am exception to be used in case of problems with message format
 * File: EaseBridgeMessageFormatValidationException.java
 * Module:  gov.ca.dmv.ease.listeners.bridge.handler.impl
 * Created: Nov 18, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseBridgeMessageFormatValidationException extends
		EaseBridgeMessageException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9082036689705913794L;

	/**
	 * Instantiates a new ease brdige message format validation exception.
	 */
	public EaseBridgeMessageFormatValidationException() {
		super();
	}

	/**
	 * 
	 * 
	 * @param message 
	 */
	public EaseBridgeMessageFormatValidationException(String message) {
		super(message);
	}

	/**
	 * 
	 * 
	 * @param message 
	 * @param cause 
	 */
	public EaseBridgeMessageFormatValidationException(String message,
			Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * 
	 * @param cause 
	 */
	public EaseBridgeMessageFormatValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseBridgeMessageFormatValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/11/18 18:50:07  mwpxp2
 *  Class name spelling corrected
 *
 *  Revision 1.1  2010/11/18 18:48:38  mwpxp2
 *  Initial
 *
 */
