/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.code;

/**
 * Description: Interface containing CodeSet name constants
 * File:ICodeSetNameConstants.java
 * Module: gov.ca.dmv.ease.bo.code
 * Created: Aug 12,2009
 * 
 * @author MWKXK4
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2018/05/25 16:34:25 $
 * Last Changed By: $Author: mwskh1 $
 */
public interface ICodeSetNameConstants {
	/** The ABSEN t_ paren t_ indicator. */
	String ABSENT_PARENT_INDICATOR = "AbsentParentIndicator";
	/** Verified Address codes. */
	String ADDRESS_SERVICE_VERIF_CODE = "ADDRESS_SERVICE_VERIF_CODE";
	/** The APPLICATIO n_ hel d_ pendin g_ code. */
	String APPLICATION_HELD_PENDING_CODE = "ApplicationHeldPendingCode";
	/** The Application Pending Codes. */
	String APPLICATION_PENDING_CODE = "APPPLICATION_PENDING_CODE";
	/** The APPLICATIO n_ pendin g_ indicator. */
	String APPLICATION_PENDING_INDICATOR = "ApplicationPendingIndicator";
	/** The APPLICATIO n_ subrecor d_ missin g_ messag e_ code. */
	String APPLICATION_SUBRECORD_MISSING_MESSAGE_CODE = "ApplicationSubRecordMissingMessageCode";
	/** The Application_Type_Code. */
	String APPLICATION_TYPE_CODE = "ApplicationTypeCode";
	/** The Attachment Code. */
	String ATTACHMENT_CODE = "AttachmentCode";
	/** The Background check indicator. */
	String BACKGROUND_CHECK_INDICATOR = "BackgroundCheckIndicator";
	/** The Bdlp Verification code. */
	String BDLP_VERIFICATION_CODE = "BIRTH_LEGAL_PRESENCE_VERIF";
	/** The BIRTHDAT e_ no t_ verified. */
	String BIRTHDATE_NOT_VERIFIED = "BirthDateNotVerified";
	/** The CDLI s_ notificatio n_ type. */
	String CDLIS_NOTIFICATION_TYPE = "CdlisNotificationCode";
	/** The CDLI s_ transfe r_ type. */
	String CDLIS_TRANSFER_TYPE = "CdlisTransferCode";
	/** The CER t_1_ acciden t_ code. */
	String CERT_1_ACCIDENT_CODE = "Cert1AccidentCode";
	/** The CER t_1_ convictio n_ code. */
	String CERT_1_CONVICTION_CODE = "Cert1ConvictionCode";
	/** The CER t_1_ negligen t_ operato r_ code. */
	String CERT_1_NEGLIGENT_OPERATOR_CODE = "Cert1NegligentOperatorCode";
	/** The CER t_1_ outstandin g_ hearin g_ code. */
	String CERT_1_OUTSTANDING_HEARING_CODE = "Cert1OutstandingHearingCode";
	/** The CER t_1_ prio r_ actio n_ code. */
	String CERT_1_PRIOR_ACTION_CODE = "Cert1PriorActionCode";
	/** The CER t_2_ acciden t_ code. */
	String CERT_2_ACCIDENT_CODE = "Cert2AccidentCode";
	/** The CER t_2_ convictio n_ code. */
	String CERT_2_CONVICTION_CODE = "Cert2ConvictionCode";
	/** The CER t_2_ prio r_ actio n_ code. */
	String CERT_2_PRIOR_ACTION_CODE = "Cert2PriorActionCode";
	/** The CER t_3_ convictio n_ code. */
	String CERT_3_CONVICTION_CODE = "Cert3ConvictionCode";
	/** The CER t_3_ prio r_ actio n_ code. */
	String CERT_3_PRIOR_ACTION_CODE = "Cert3PriorActionCode";
	/** The CER t_4_ prio r_ actio n_ code. */
	String CERT_4_PRIOR_ACTION_CODE = "Cert4PriorActionCode";
	/** The Certificate Code. */
	String CERTIFICATE_CODE = "CertificateCode";
	/** the City Codes. */
	String CITY_CODES = "CITY CODES";
	/** The CIVI l_ judgemen t_ code. */
	String CIVIL_JUDGEMENT_CODE = "CivilJudgementCode";
	/** The COUN t_ ordere d_ li c_ delay. */
	String COUNT_ORDERED_LIC_DELAY = "CountOrderedLicDelay";
	/** The COUR t_ suspension. */
	String COURT_SUSPENSION = "CourtSuspension";
	/** The DECEASE d_ code. */
	String DECEASED_CODE = "DeceasedCode";
	/** The Desingnate_Action_Code. */
	String DESIGNATE_ACTION_CODE = "DesignateActionCode";
	/** The DISCRETIONAR y_ sus p_ o r_ revacation. */
	String DISCRETIONARY_SUSP_OR_REVACATION = "DiscretionarySuspensionOrRevocation";
	/** The DISHONORE d_ checks. */
	String DISHONORED_CHECKS = "DishonoredChecks";
	/** The DISQUALIFIE d_ fo r_ a_ cdl. */
	String DISQUALIFIED_FOR_A_CDL = "DisqualifiedForACdl";
	/** The D l_103_ plu s_15_ du i_ fe e_ require d_ code. */
	String DL_103_PLUS_15_DUI_FEE_REQUIRED_CODE = "Dl103Plus15DuiFeeRequiredCode";
	/** The D l_ car d_ reques t_ i n_ process. */
	String DL_CARD_REQUEST_IN_PROCESS = "DlCardRequestInProgress";
	/** The D l_ renewa l_ messag e_ code. */
	String DL_RENEWAL_MESSAGE_CODE = "DlRenewalMessageCode";
	/** The DL Return Code. */
	String DL_RETURN_CODE = "DlReturnCode";
	/** The DL m_ retur n_ code. */
	String DLM_RETURN_CODE = "DlmReturnCode";
	/** The DL m_ segmen t_ indicator. */
	String DLM_SEGMENT_INDICATOR = "DlmSegmentIndicator";
	/** The DOUBL e_ recor d_ code. */
	String DOUBLE_RECORD_CODE = "DoubleRecordCode";
	/** The DRIVE r_ educatio n_ an d_ trainin g_ waiv e_ code. */
	String DRIVER_EDUCATION_AND_TRAINING_WAIVE_CODE = "DriverEducationAndTrainingWaiveCode";
	/** The Driver_ Education_Code. */
	String DRIVER_EDUCATION_CODE = "DRIVERS_EDUCATION";
	/** The Driver_ Training_ Code. */
	String DRIVER_TRAINING_CODE = "DRIVERS_TRAINING";
	/** The DS r_ reinstatemen t_ approva l_ neede d_ code. */
	String DSR_REINSTATEMENT_APPROVAL_NEEDED_CODE = "DsrReinstatementApprovalNeededCode";
	/** The DU i_ completio n_ require d_ code. */
	String DUI_COMPLETION_REQUIRED_CODE = "DuiCompletionRequiredCode";
	/** The DUPLICAT e_ wit h_ previou s_ phot o_ i n_ progres s_ indicator. */
	String DUPLICATE_WITH_PREVIOUS_PHOTO_IN_PROGRESS_INDICATOR = "DuplicateWithPreviousPhotoInProgressIndicator";
	/** The Eli_Action_Code. */
	String ELI_ACTION_CODE = "EliActionCode";
	/** The ELI record error code. */
	String ELI_RECORD_ERROR_CODE = "EliRecordErrorCode";
	/** The EL i_ retur n_ code. */
	String ELI_RETURN_CODE = "EliReturnCode";
	/** The EL i_ segmen t_ indicator. */
	String ELI_SEGMENT_INDICATOR = "EliSegmentIndicator";
	/** The ELIGIBL e_ fo r_ earl y_ cd l_ renewal. */
	String ELIGIBLE_FOR_EARLY_CDL_RENEWAL = "EligibleForEarlyCdlRenewal";
	/** The ELIGIBL e_ fo r_ rest r_04. */
	String ELIGIBLE_FOR_RESTR_04 = "EligibleForRestr04";
	/** The Endorsement_Code. */
	String ENDORSEMENT_CODE = "ENDORSEMENTS";
	/** The Eye_Color_Code. */
	String EYE_COLOR_CODE = "EYE_COLOR";
	/** The FAILUR e_ t o_ appear. */
	String FAILURE_TO_APPEAR = "FailureToAppear";
	/** The FAILUR e_ t o_ pay. */
	String FAILURE_TO_PAY = "FailureToPay";
	/** The Fee_Action_Code. */
	String FEE_ACTION_CODE = "FeeActionCode";
	/** The Fee required reason code. */
	String FEE_REQUIRED_REASON_CODE = "NO_FEE_REASON_CODE";
	/** The FINANCIA l_ responsibility. */
	String FINANCIAL_RESPONSIBILITY = "FinancialResponsibility";
	/** The Foreign_Language_Code. */
	String FOREIGN_LANGUAGE_TEST_RESULT_CODE = "ForeignLanguageTestResultCode";
	/** The F r_ penalt y_ fe e_ no t_ due. */
	String FR_PENALTY_FEE_NOT_DUE = "FrPenaltyFeeNotDue";
	/** The F r_ proo f_ no t_ o n_ file. */
	String FR_PROOF_NOT_ON_FILE = "FrProofNotOnFile";
	/** The F r_ proo f_ o n_ fil e_ code. */
	String FR_PROOF_ON_FILE_CODE = "FrProofOnFileCode";
	/** The Hair_Color_Code. */
	String HAIR_COLOR_CODE = "HAIR_COLOR";
	/** The HQ Error Code. */
	String HQ_ERROR_CODE = "HqErrorCode";
	/** The I d_ car d_ reques t_ i n_ process. */
	String ID_CARD_REQUEST_IN_PROCESS = "IdCardRequestInProgress";
	/** The I d_ phot o_ retake. */
	String ID_PHOTO_RETAKE = "IdPhotoRetake";
	/** The I d_ renewa l_ messag e_ code. */
	String ID_RENEWAL_MESSAGE_CODE = "IdRenewalMessageCode";
	/** The IDCAR d_ returne d_ unclaimed. */
	String IDCARD_RETURNED_UNCLAIMED = "IdCardReturnedUnclaimed";
	/** The IDCAR d_ typ e_ indicato r_ code. */
	String IDCARD_TYPE_INDICATOR_CODE = "IdCardTypeIndicatorCode";
	/** The ID_class_Code. */
	String ID_CLASS_CODE = "ID_CLASS";
	/** The Incomplete application reason code. */
	String INCOMPLETE_APPLICATION_REASON_CODE = "INC_PENDING_APP_REASON";
	/** The INELI g_ r x_ proo f_ acceptabl e_ ind. */
	String INELIG_RX_PROOF_ACCEPTABLE_IND = "IneligibilityRxProofAcceptableIndicatorCode";
	/** The INELIGIBL e_ fo r_ to w_ truc k_ cer t_ code. */
	String INELIGIBLE_FOR_TOW_TRUCK_CERT_CODE = "IneligibleForTowTruckCertCode";
	/** The INELIGIBL e_ t o_ rene w_ b y_ mail. */
	String INELIGIBLE_TO_RENEW_BY_MAIL = "IneligibleToRenewByMail";
	/** The Ins Document Type Code. */
	String INS_DOCUMENT_TYPE_CODE = "InsDocumentTypeCode";
	/** The INVALI d_ clas s_ change. */
	String INVALID_CLASS_CHANGE = "InvalidClassChange";
	/** The Legal Presence Inquiry ind. */
	String LEGAL_PRESENCE_INQUIRY_IND = "DESIGNATE_LEGAL_PRESENCE_INQ_R";
	/** The License_Category_Code. */
	String LICENSE_CATEGORY_CODE = "LicenseCategoryCode";
	/** The License_class_Code. */
	String LICENSE_CLASS_CODE = "CLASS_LICENSE";
	/** The LICENS e_ extensio n_ code. */
	String LICENSE_EXTENSION_CODE = "LicenseExtensionCode";
	/** The LICENS e_ histor y_ actio n_ code. */
	String LICENSE_HISTORY_ACTION_CODE = "LicenseHistoryActionCode";
	/** The LICENS e_ locatio n_ an d_ reaso n_ code. */
	String LICENSE_LOCATION_AND_REASON_CODE = "LicenseLocationAndReasonCode";
	/** The License_Location_Code. */
	String LICENSE_LOCATION_CODE = "LICENSE_LOCATION";
	/** The License status code. */
	String LICENSE_STATUS_CODE = "LicenseStatusCode";
	/** The MANDANTOR y_ no n_ proo f_ actio n_ code. */
	String MANDANTORY_NON_PROOF_ACTION_CODE = "MandatoryNonProofActionCode";
	/** The MANDATOR y_ suspensio n_ o r_ revacation. */
	String MANDATORY_SUSPENSION_OR_REVACATION = "MandatorySuspensionOrRevocation";
	/** The Mc training code. */
	String MC_TRAINING_CODE = "McTrainingCode";
	/** The Military_code. */
	String MILITARY_CODE = "MilitaryCode";
	/** The Military duty code. */
	String MILITARY_DUTY_CODE = "MilitaryDutyCode";
	/** The Minor Code. */
	String MINOR_CODE = "MinorCode";
	/** The Minor guarantor code. */
	String MINOR_GUARANTOR_CODE = "MinorGuarantorCode";
	/** The Motorcycle_Training_Code. */
	String MOTOR_CYCLE_TRAINING_CODE = "MotorcycleTrainingCode";
	/** The ND r_ cd l_ o s_ withdrawa l_ action. */
	String NDR_CDL_OS_WITHDRAWAL_ACTION = "NdrCdlOsWithdrawalAction";
	/** The NO n_ commercia l_ driv e_ retes t_ fee. */
	String NON_COMMERCIAL_DRIVE_RETEST_FEE = "NonCommercialDriveRetestFee";
	/** The O l_ referra l_ documen t_ tt c_ code. */
	String OL_REFERRAL_DOCUMENT_TTC_CODE = "OlReferralTtcCode";
	/** The oral test result code. */
	String ORAL_TEST_RESULT_CODE = "OralTestResultCode";
	/** The OTHE r_ license. */
	String OTHER_LICENSE = "OtherLicense";
	/** The PENDIN g_ app. */
	String PENDING_APP = "PendingApp";
	/** The PHOT o_ retak e_ no t_ o k_ indicator. */
	String PHOTO_RETAKE_NOT_OK_INDICATOR = "PhotoRetakeNotOkIndicator";
	/** The PHOT o_ take n_ fo r_ thi s_ application. */
	String PHOTO_TAKEN_FOR_THIS_APPLICATION = "PhotoTakenForThisApplication";
	/** The PHOT o_ typ e_ o n_ file. */
	String PHOTO_TYPE_ON_FILE = "PhotoTypeOnFile";
	/** The PHYSICA l_ o r_ mental. */
	String PHYSICAL_OR_MENTAL = "PhysicalOrMental";
	/** The PHYSICA l_ o r_ menta l_ proble m_ code. */
	String PHYSICAL_OR_MENTAL_PROBLEM_CODE = "PhysicalOrMentalProblemCode";
	/** The PROBATION. */
	String PROBATION = "Probation";
	/** The PROCES s_ d l_ actio n_ terminatio n_ code. */
	String PROCESS_DL_ACTION_TERMINATION_CODE = "ProcessDlActionTerminationCode";
	/** The PROO f_ o n_ fil e_ code. */
	String PROOF_ON_FILE_CODE = "ProofOnFileCode";
	/** The RECOR d_ securit y_ fil e_ code. */
	String RECORD_SECURITY_FILE_CODE = "RecordSecurityFileCode";
	/** The REINSTATE d_ o n_ proo f_ code. */
	String REINSTATED_ON_PROOF_CODE = "ReinstatedOnProofCode";
	/** The REINSTATEMEN t_ i n_ progress. */
	String REINSTATEMENT_IN_PROGRESS = "ReinstatementInProgress";
	/** The REISSU e_ fe e_ due. */
	String REISSUE_FEE_DUE = "ReissueFeeDue";
	/** The REMOVA l_ o f_ restriction. */
	String REMOVAL_OF_RESTRICTION = "RemovalOfRestriction";
	/** The Restriction Code. */
	String RESTRICTION_CODE = "RESTRICTION";
	/** The ROUT e_ code. */
	String ROUTE_CODE = "RouteCode";
	/** The SERVIC e_ o f_ orde r_ needed. */
	String SERVICE_OF_ORDER_NEEDED = "ServiceOfOrderNeeded";
	/** The Sex_Code. */
	String SEX_CODE = "GENDER";
	/** The S r1 p_ o r_ s r22_ require d_ code. */
	String SR1P_OR_SR22_REQUIRED_CODE = "Sr1pOrSr22RequiredCode";
	/** The S r22_ re q_ qualif y_ fo r_ du i_ restrictio n_ code. */
	String SR22_REQ_QUALIFY_FOR_DUI_RESTRICTION_CODE = "Sr22ReqQualifyForDuiRestrictionCode";
	/** The S r22_ require d_ code. */
	String SR22_REQUIRED_CODE = "Sr22RequiredCode";
	/** The Ssn_Verification_Code. */
	String SSN_VERIFICATION_CODE = "SSN_VERIF";
	/** The State_Code. */
	String STATE_CODE = "StateCode";
	/** The PREV_LICENSE_STATE. */
	String PREV_LICENSE_STATE = "PREV_LICENSE_STATE";
	/** The SUSPENS e_ o r_ revok e_ o n_ fil e_ indicator. */
	String SUSPENSE_OR_REVOKE_ON_FILE_INDICATOR = "SuspenseOrRevokeOnFileIndicator";
	/** The TE n_ yea r_ histor y_ recor d_ check. */
	String TEN_YEAR_HISTORY_RECORD_CHECK = "TenYearHistoryRecordCheck";
	/** The TERMINAT e_ f r_ suspensio n_ code. */
	String TERMINATE_FR_SUSPENSION_CODE = "TerminateFrSuspensionCode";
	/** The Test result code. */
	String TEST_RESULT_CODE = "TestResultCode";
	/** The TT c_ text. */
	String TTC_CODE = "TtcCode";
	/** The TYP e_ applicatio n_ error. */
	String TYPE_APPLICATION_ERROR = "TypeApplicationError";
	/** The UNABL e_ t o_ calculat e_ eligibilit y_ code. */
	String UNABLE_TO_CALCULATE_ELIGIBILITY_CODE = "UnableToCalculateEligibilityCode";
	/** The user verified ssn code. */
	String USER_VERIFIED_SSN_CODE = "UserVerifiedSsnCode";
	/** The VALI d_ ss n_ code. */
	String VALID_SSN_CODE = "ValidSsnCode";
	/** The VISIO n_ tes t_ result. */
	String VISION_TEST_RESULT_CODE = "VisionTestResultCode";
	/** The Voter_Registration_Code. */
	String VOTER_REGISTRATION_CODE = "VoterRegistrationCode";
	/** The WITHEL d_ pendin g_ pdp s_ clearance. */
	String WITHELD_PENDING_PDPS_CLEARANCE = "WitheldPendingPdpsClearance";
	/** The WRITTE n_ driv e_ tes t_ indicator. */
	String WRITTEN_DRIVE_TEST_INDICATOR = "WrittenDriveTestIndicator";
	/** Code set value for 60U Service of Order Inquiry Response Action Messages. */
	String SERVICE_OF_ORDER_RESPONSE_ACTIONCODE = "SERVICE_OF_ORDER_ACTION_CODE";
	/** The SERVIC e_ o f_ orde r_ actio n_ reaso n_ code. */
	String SERVICE_OF_ORDER_ACTION_REASON_CODE = "SERVICE_OF_ORDER_ACTION_REASON_CODE";
	/** The STATE. */
	String STATE = "STATE";
	/** The STATE_TERRITORY. */
	String STATE_TERRITORY = "STATE_TERRITORY";
	/** The STATE_COUNTRY. */
	String STATE_COUNTRY = "STATE_COUNTRY";
	/** The STATE_CANADIAN_PROV. */
	String STATE_CANADIAN_PROV = "STATE_CANADIAN_PROV";
	/** The STATE_MILITARY. */
	String STATE_MILITARY = "STATE_MILITARY";
	/** The SSA_RESPONSE_CODE. */
	String SSA_RESPONSE_CODE = "SSA_RESPONSE_CODE";
	/** The SSN verif. */
	String SSN_VERIF = "SSN_VERIF";
	/** The SSN verif non issuance. */
	String SSN_VERIF_NON_ISSUANCE = "SSN_VERIF_NON_ISSUANCE";
	/** The DATE_CODE_CATEGORY. */
	String DATE_CODE_CATEGORY = "DATE";
	/** The FODI ENABLED OFFICE */
	String FODI_ENABLED_OFFICE = "FODI_ENABLED_OFFICE";
	/** AKTE ENABLED OFFICE */
	String AKTE_ENABLED_OFFICE = "AKTE_ENABLED_OFFICE";
	/** CDLIS_52_ENABLED */
	String CDLIS_52_ENABLED = "CDLIS_52_ENABLED";
	/** CDLIS_52_ENABLED */
	String CDLIS_52_10Q_ENABLED = "CDLIS_52_10Q_ENABLED";
	/** CDLIS_52_Med Cert and SCC ENABLED */
	String CDLIS_52_MED_ENABLED = "CDLIS_52_MED_ENABLED";
	/** BIRTH_LEGAL_PRESENCE_VERIF used to for BDLP codeset  */
	String BIRTH_LEGAL_PRESENCE_VERIF = "BIRTH_LEGAL_PRESENCE_VERIF";
	/** BIRTH_LEGAL_PRESENCE_VERIF used to for unverified BDLP codeset  */
	String BIRTH_LEGAL_PRESENCE_NOT_VERIF = "BIRTH_LEGAL_PRESENCE_NOT_VERIF";
	/** BIRTH_LEGAL_PRESENCE_VERIF used to for commercial BDLP codeset  */
	String BIRTH_LEGAL_PRESENCE_COMMERCIAL = "BIRTH_LEGAL_PRESENCE_COMMERCIAL";
	/** BIRTH_LEGAL_PRESENCE_VERIF used to for Real ID BDLP codeset  */
	String BIRTH_LEGAL_PRESENCE_RID = "BIRTH_LEGAL_PRESENCE_RID";
	/** BIRTH_LEGAL_PRESENCE_VERIF used to for Commercial Real ID BDLP codeset  */
	String BIRTH_LEGAL_PRESENCE_RID_CDL = "BIRTH_LEGAL_PRESENCE_RID_CDL";
}
/**
 * Modification History:
 * 
 * $Log: ICodeSetNameConstants.java,v $
 * Revision 1.10  2018/05/25 16:34:25  mwskh1
 * merging eDL44_2_8_1_9 (eDL44 project) and EASE_2_8_1_9_branch (Real ID, M&O and AKTE defects) to head
 *
 * Revision 1.9.20.1  2018/05/11 17:21:29  mwwwc
 * Merge defect 468 fix into BRANCH_EASE_2_8_3_1 Branch.
 *
 * Revision 1.9.14.1  2018/03/06 21:48:05  mwwwc
 * Defect 468: Remove reference to AKT Stockton Plus MQ and message relate.
 *
 * Revision 1.9  2017/11/09 16:31:05  mwskh1
 * Real ID - Merge to HEAD
 *
 * Revision 1.8  2017/08/07 16:56:15  mwwwc
 * Merge AKTE changes from branch to Head.
 *
 * Revision 1.7.8.1  2017/05/24 17:01:18  mwwwc
 * Added back AKTE changes
 *
 * Revision 1.7.10.2  2017/09/26 20:06:40  mwskh1
 * Real ID - added bdlp codesets
 *
 * Revision 1.7.10.1  2017/07/30 21:28:36  mwskh1
 * Real ID - added ID_CLASS
 *
 * Revision 1.7  2016/01/21 23:41:53  mwwwc
 * Remove AKTE changes from HEAD.
 *
 * Revision 1.5.6.1  2015/09/24 23:05:29  mwwwc
 * AKTE Changes: Add constant AKTE_ENABLED_OFFICE
 * 
 * Revision 1.5  2013/12/02 19:43:00  mwlcr1
 * AB91 cleanup
 *
 * Revision 1.4  2013/09/04 23:18:24  mwgxd3
 * AKTE II changes: add support for audio/video indicator and 2 new test result values.
 *
 * Revision 1.3  2013/05/29 16:49:10  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.2.2.2  2013/04/09 16:00:51  mwskh1
 * CDLIS 5.2 -added med cert
 *
 * Revision 1.2.2.1  2013/04/04 23:49:46  mwgxd3
 * CDLIS - enabled codeset.
 *
 * Revision 1.2  2012/11/06 16:40:20  mwgxd3
 * ab91 - add new codeset
 *
 * Revision 1.1  2012/10/01 02:57:17  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.118  2012/04/17 22:26:38  mwsec2
 * AKTS branch code merged to Head
 *
 * Revision 1.117.2.1  2012/02/23 00:30:20  mwsec2
 * added akts constant
 *
 * Revision 1.117  2012/02/08 00:17:49  mwxxw
 * Add FODI_ENABLED_OFFICE.
 *
 * Revision 1.116  2012/01/18 20:48:15  mwhys
 * Added DATE_CODE_CATEGORY.
 *
 * Revision 1.115  2011/12/03 02:25:35  mwrrv3
 * Updated the code to fix defect# 6930 (don't display SSN VERI code).
 *
 * Revision 1.114  2011/08/19 17:05:15  mwhys
 * Added constant SSA_RESPONSE_CODE.
 *
 * Revision 1.113  2011/03/21 22:06:31  mwhys
 * Added code set names for states.
 *
 * Revision 1.112  2011/02/18 18:44:04  mwhys
 * Used the correct codeset name for PREV_LICENSE_STATE. (Defect 4752)
 *
 * Revision 1.111  2011/02/15 00:50:33  mwuxb
 * Added entry ORAL_TEST_RESULT_CODE
 *
 * Revision 1.110  2011/02/09 22:31:11  mwhys
 * Updated driver education and training codeset names.
 *
 * Revision 1.109  2011/02/04 19:24:55  mwhys
 * Updated endorsements and license class codes.
 *
 * Revision 1.108  2011/02/04 00:32:03  mwhys
 * Updated few values.
 *
 * Revision 1.107  2011/02/03 01:19:23  mwhys
 * Updated with the correct value of BDLP_VERIFICATION_CODE stored in the database.
 *
 * Revision 1.106  2011/01/24 05:10:14  mwrrv3
 * Changed the value of SEX_CODE constant. Fix for defect 4406.
 *
 * Revision 1.105  2010/12/10 00:57:32  mwtjc1
 * SERVICE_OF_ORDER_ACTION_REASON_CODE added
 *
 * Revision 1.104  2010/11/29 19:31:23  mwsym2
 * Committed on behalf of Prabhu Rajendran mwpxr5
 * RESTRICTION_CODE modified to RESTRICTION.
 *
 * Revision 1.103  2010/11/19 19:07:56  mwtjc1
 * INCOMPLETE_APPLICATION_REASON_CODE changed
 *
 * Revision 1.102  2010/11/12 18:31:23  mwrrv3
 * Added new mock code set "SERVICE_OF_ORDER_ACTION_CODE" for 60U DataTable Action messages-- Amar
 *
 * Revision 1.101  2010/10/06 18:07:30  mwhys
 * Removed the field: TCODE_DS5_CODE.
 *
 * Revision 1.100  2010/09/01 18:58:23  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.99  2010/08/05 18:55:02  mwhxa2
 * Added APPLICATION_PENDING_CODE
 *
 * Revision 1.98  2010/08/04 17:09:34  mwcyl
 * added CITY CODES
 *
 * Revision 1.97  2010/07/28 00:42:32  mwcsj3
 * Added string constant ADDRESS_SERVICE_VERIF_CODE
 *
 * Revision 1.96  2010/07/09 00:26:46  mwhxa2
 * Adding HQ_ERROR_CODE
 *
 * Revision 1.95  2010/07/08 01:55:09  mwpxp2
 * Cleaned up
 *
 * Revision 1.94  2010/06/21 23:00:43  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.91.2.2  2010/06/20 18:06:55  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.93  2010/06/16 17:54:33  mwtjc1
 * OL_REFERRAL_DOCUMENT_TTC_CODE added
 *
 * Revision 1.92  2010/06/08 01:27:06  mwtjc1
 * TTC_CODE added
 *
 * Revision 1.91  2010/05/21 20:34:24  mwtjc1
 * value of PHYSICAL_OR_MENTAL_PROBLEM_CODE is changed
 *
 * Revision 1.90  2010/05/21 19:46:14  mwtjc1
 * value of IDCARD_TYPE_INDICATOR_CODE is changed
 *
 * Revision 1.89  2010/05/21 18:28:02  mwtjc1
 * ELI_SEGMENT is removed
 *
 * Revision 1.88  2010/05/21 18:24:54  mwtjc1
 * ELI_SEGMENT_INDICATOR and DLM_SEGMENT_INDICATOR are added
 *
 * Revision 1.87  2010/05/20 22:16:59  mwtjc1
 * ELI_RETURN_CODE is added
 *
 * Revision 1.86  2010/05/20 21:51:40  mwtjc1
 * DLM_RETURN_CODE is added
 *
 * Revision 1.85  2010/05/04 00:54:48  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.84  2010/04/30 17:20:05  mwhxb3
 * Added TCODE_DS5_CODE.
 *
 * Revision 1.83  2010/04/30 00:55:09  mwtjc1
 * INELIG_RX_PROOF_ACCEPTABLE_IND added
 *
 * Revision 1.82  2010/04/30 00:48:24  mwtjc1
 * DL_103_PLUS_15_DUI_FEE_REQUIRED_CODE added
 *
 * Revision 1.81  2010/04/30 00:32:23  mwtjc1
 * SR22_REQ_QUALIFY_FOR_DUI_RESTRICTION_CODE added
 *
 * Revision 1.80  2010/04/30 00:30:52  mwtjc1
 * CIVIL_JUDGEMENT_CODE added
 *
 * Revision 1.79  2010/04/30 00:26:17  mwtjc1
 * DUI_COMPLETION_REQUIRED_CODE added
 *
 * Revision 1.78  2010/04/30 00:24:23  mwtjc1
 * TERMINATE_FR_SUSPENSION_CODE added
 *
 * Revision 1.77  2010/04/30 00:22:33  mwtjc1
 * PROCESS_DL_ACTION_TERMINATION_CODE added
 *
 * Revision 1.76  2010/04/30 00:19:45  mwtjc1
 * MANDANTORY_NON_PROOF_ACTION_CODE added
 *
 * Revision 1.75  2010/04/30 00:16:32  mwtjc1
 * REINSTATED_ON_PROOF_CODE added
 *
 * Revision 1.74  2010/04/30 00:14:37  mwtjc1
 * PROOF_ON_FILE_CODE added
 *
 * Revision 1.73  2010/04/30 00:02:01  mwtjc1
 * FR_PROOF_ON_FILE_CODE added
 *
 * Revision 1.72  2010/04/29 23:27:22  mwtjc1
 * SR1P_OR_SR22_REQUIRED_CODE added
 *
 * Revision 1.71  2010/04/29 23:21:58  mwtjc1
 * SR22_REQUIRED_CODE added
 *
 * Revision 1.70  2010/04/29 23:15:27  mwtjc1
 * UNABLE_TO_CALCULATE_ELIGIBILITY_CODE added
 *
 * Revision 1.69  2010/04/29 23:12:34  mwtjc1
 * DSR_REINSTATEMENT_APPROVAL_NEEDED_CODE added
 *
 * Revision 1.68  2010/04/29 22:51:51  mwtjc1
 * updated
 *
 * Revision 1.67  2010/04/29 21:26:41  mwtjc1
 * LICENSE_LOCATION_AND_REASON_CODE added
 *
 * Revision 1.66  2010/04/29 21:20:00  mwtjc1
 * LICENSE_HISTORY_REASON_CODE added
 *
 * Revision 1.65  2010/04/29 18:18:53  mwtjc1
 * LICENSE_HISTORY_ACTION_CODE added
 *
 * Revision 1.64  2010/04/28 18:56:25  mwtjc1
 * FR_PROOF_NOT_ON_FILE added
 *
 * Revision 1.63  2010/04/28 18:29:23  mwtjc1
 * APPLICATION_SUBRECORD_MISSING_MESSAGE_CODE added
 *
 * Revision 1.62  2010/04/27 20:20:03  mwtjc1
 * INELIGIBLE_FOR_TOW_TRUCK_CERT_CODE added
 *
 * Revision 1.61  2010/04/27 20:15:14  mwtjc1
 * CERT_1_CONVICTION_CODE, CERT_2_CONVICTION_CODE, CERT_3_CONVICTION_CODE added
 *
 * Revision 1.60  2010/04/27 20:12:50  mwtjc1
 * CERT_3_PRIOR_ACTION_CODE and CERT_4_PRIOR_ACTION_CODE added
 *
 * Revision 1.59  2010/04/27 20:11:38  mwtjc1
 * CERT_2_PRIOR_ACTION_CODE added
 *
 * Revision 1.58  2010/04/27 20:10:51  mwtjc1
 * CERT_1_PRIOR_ACTION_CODE added
 *
 * Revision 1.57  2010/04/27 20:09:18  mwtjc1
 * CERT_2_ACCIDENT_CODE added
 *
 * Revision 1.56  2010/04/27 20:08:30  mwtjc1
 * CERT_1_ACCIDENT_CODE added
 *
 * Revision 1.55  2010/04/27 18:30:22  mwtjc1
 * CERT_1_NEGLIGENT_OPERATOR_CODE added
 *
 * Revision 1.54  2010/04/27 18:28:13  mwtjc1
 * CERT_1_OUTSTANDING_HEARING_CODE added
 *
 * Revision 1.53  2010/04/22 19:09:31  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.52  2010/04/21 17:54:39  mwhxa2
 * Added DL_RETURN_CODE
 *
 * Revision 1.51  2010/04/20 17:28:58  mwtjc1
 * ELI_SEGMENT is added
 *
 * Revision 1.50  2010/04/07 16:53:47  mwtjc1
 * updated
 *
 * Revision 1.49  2010/04/07 16:53:20  mwtjc1
 * updated
 *
 * Revision 1.48  2010/04/07 16:52:06  mwtjc1
 * updated
 *
 * Revision 1.47  2010/04/06 21:21:58  mwtjc1
 * updated
 *
 * Revision 1.46  2010/04/01 16:30:11  mwtjc1
 * updated
 *
 * Revision 1.45  2010/03/31 20:34:50  mwtjc1
 * updated
 *
 * Revision 1.44  2010/03/31 18:43:36  mwtjc1
 * updated
 *
 * Revision 1.43  2010/03/31 18:40:54  mwtjc1
 * updated
 *
 * Revision 1.42  2010/03/31 18:36:53  mwtjc1
 * updated
 *
 * Revision 1.41  2010/03/31 18:28:44  mwtjc1
 * updated
 *
 * Revision 1.40  2010/03/31 18:27:39  mwtjc1
 * updated
 *
 * Revision 1.39  2010/03/31 18:26:05  mwtjc1
 * updated
 *
 * Revision 1.38  2010/03/31 18:25:07  mwtjc1
 * updated
 *
 * Revision 1.37  2010/03/31 18:24:13  mwtjc1
 * updated
 *
 * Revision 1.36  2010/03/31 18:23:04  mwtjc1
 * updated
 *
 * Revision 1.35  2010/03/31 18:21:52  mwtjc1
 * updated
 *
 * Revision 1.34  2010/03/31 18:17:58  mwtjc1
 * updated
 *
 * Revision 1.33  2010/03/31 18:14:54  mwtjc1
 * updated
 *
 * Revision 1.32  2010/03/31 18:11:40  mwtjc1
 * updated
 *
 * Revision 1.31  2010/03/31 17:57:05  mwtjc1
 * updated
 *
 * Revision 1.30  2010/03/31 17:54:15  mwtjc1
 * updated
 *
 * Revision 1.29  2010/03/31 17:36:23  mwtjc1
 * updated
 *
 * Revision 1.28  2010/03/31 17:33:49  mwtjc1
 * updated
 *
 * Revision 1.27  2010/03/31 17:30:54  mwtjc1
 * updated
 *
 * Revision 1.26  2010/03/31 17:29:03  mwtjc1
 * updated
 *
 * Revision 1.25  2010/03/31 17:26:54  mwtjc1
 * updated
 *
 * Revision 1.24  2010/03/31 17:24:37  mwtjc1
 * updated
 *
 * Revision 1.23  2010/03/31 17:21:30  mwtjc1
 * updated
 *
 * Revision 1.22  2010/03/31 17:19:00  mwtjc1
 * updated
 *
 * Revision 1.21  2010/03/31 17:16:48  mwtjc1
 * updated
 *
 * Revision 1.20  2010/03/31 17:15:03  mwtjc1
 * updated
 *
 * Revision 1.19  2010/03/31 17:12:20  mwtjc1
 * updated
 *
 * Revision 1.18  2010/03/31 17:10:33  mwtjc1
 * updated
 *
 * Revision 1.17  2010/03/31 16:59:19  mwtjc1
 * updated
 *
 * Revision 1.16  2010/03/31 16:56:50  mwtjc1
 * updated
 *
 * Revision 1.15  2010/03/31 16:52:17  mwtjc1
 * updated
 *
 * Revision 1.14  2010/03/31 16:50:37  mwtjc1
 * updated
 *
 * Revision 1.13  2010/03/31 16:49:25  mwtjc1
 * updated
 *
 * Revision 1.12  2010/03/31 16:46:28  mwtjc1
 * updated
 *
 * Revision 1.11  2010/03/31 16:42:56  mwtjc1
 * updated
 *
 * Revision 1.10  2010/03/30 20:14:01  mwtjc1
 * updated
 *
 * Revision 1.9  2010/03/24 21:26:29  mwuxb
 * Corrected CodeSetName constants
 *
 * Revision 1.8  2010/03/22 23:17:36  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.7  2010/03/22 20:53:26  mwtjc1
 * MILITARY_DUTY_CODE is added
 *
 * Revision 1.6  2010/03/22 20:30:10  mwtjc1
 * LEGAL_PRESENCE_INQUIRY_IND added
 *
 * Revision 1.5  2010/03/22 20:22:08  mwtjc1
 * MC_TRAINING_CODE added
 *
 * Revision 1.4  2010/03/22 20:06:02  mwrsk
 * Added more constants
 *
 * Revision 1.3  2010/03/22 19:40:30  mwrsk
 * Added more constants
 *
 * Revision 1.2  2010/01/28 18:04:37  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.1  2009/11/23 16:22:53  mwrsk
 * Intial commit
 *
 * Revision 1.3  2009/08/27 05:39:59  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.2  2009/08/12 22:20:51  mwkxk4
 * Updated the  Header
 *
 * Revision 1.1  2009/08/12 21:08:07  mwkxk4
 * Added Interface for CodeSetName constant values
 *
 */
