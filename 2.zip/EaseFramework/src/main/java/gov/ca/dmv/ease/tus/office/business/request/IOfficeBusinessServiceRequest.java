/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.office.business.request;

import gov.ca.dmv.ease.fw.service.IRequest;
import gov.ca.dmv.ease.tus.office.business.response.IOfficeBusinessServiceResponse;

/**
 * Description: I am an AuthAndAuthRequest interface
 * 
 * File: IAuthAndAuthServiceRequest.java
 * Module:  gov.ca.dmv.ease.tus.auth.request
 * Created: Oct 1, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeBusinessServiceRequest extends IRequest {
	/**
	 * Abstract method which all the office business service request classes should override
	 * for executing the corresponding method in office business service.
	 * 
	 * @return the office business service response
	 */
	IOfficeBusinessServiceResponse execute();
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeBusinessServiceRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/01/12 01:26:56  mwxxw
 *  Add new OfficeBusinessService,  related classes and configuration files.
 *
 *
 */
