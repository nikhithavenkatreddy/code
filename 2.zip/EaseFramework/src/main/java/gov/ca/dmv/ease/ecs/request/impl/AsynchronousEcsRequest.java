/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request.impl;

import gov.ca.dmv.ease.ecs.ITimeoutCapable;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.impl.AbstractAsynchronousResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am abstract superclass for asynchronous requests.
 * File: AsynchronousEcsRequest.java
 * Module:  gov.ca.dmv.ease.service.request.impl
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AsynchronousEcsRequest extends AbstractEcsRequest
		implements ITimeoutCapable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1890783726249131556L;
	/** The UNDEF_TIME. */
	private static int UNDEF_TIME = -1;
	/** The absolute expiration time. */
	private long absoluteExpirationTime = UNDEF_TIME;

	/**
	 * Creates an instance of AsynchronousEcsRequest using IUserContext instance.
	 * 
	 * @param aContext the a context
	 */
	public AsynchronousEcsRequest(IUserContext aContext) {
		this(UNDEF_TIME, null, aContext);
	}

	//	/**
	//	 * Instantiates a new asynchronous request.
	//	 * 
	//	 * @param aMsecTime the a msec time
	//	 */
	//	public AsynchronousEcsRequest(long aMsecTime) {
	//		this(aMsecTime, null, null);
	//	}
	//
	//	/**
	//	 * Instantiates a new asynchronous request with expiration time and IUserContext instance.
	//	 * 
	//	 * @param aMsecTime Absolute expiration time
	//	 * @param aContext UserContext instance
	//	 */
	//	public AsynchronousEcsRequest(long aMsecTime, IUserContext aContext) {
	//		this(aMsecTime, null, aContext);
	//	}
	/**
	 * Instantiates a new asynchronous request with and expiration time, request ID and IUserContext instance.
	 * 
	 * @param aMsecTime the a msec time
	 * @param anId the an id
	 * @param aContext the a context
	 */
	public AsynchronousEcsRequest(long aMsecTime, String anId,
			IUserContext aContext) {
		super(anId, aContext);
		setAbsoluteExpirationTime(aMsecTime);
	}

	//	/**
	//	 * Instantiates a new asynchronous request.
	//	 * 
	//	 * @param anId the an id
	//	 */
	//	public AsynchronousEcsRequest(String anId) {
	//		this(UNDEF_TIME, anId, null);
	//	}
	//
	//	/**
	//	 * Instantiates a new asynchronous request with and request ID and IUserContext instance.
	//	 * 
	//	 * @param anId Request ID
	//	 * @param aContext UserContext instance
	//	 */
	//	public AsynchronousEcsRequest(String anId, IUserContext aContext) {
	//		this(UNDEF_TIME, anId, aContext);
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.IEcsRequest#execute()
	 */
	public AbstractAsynchronousResponse execute() throws EcsServiceException {
		AbstractAsynchronousResponse returnAbstractAsynchronousResponse = null;
		//try {
		returnAbstractAsynchronousResponse = (AbstractAsynchronousResponse) getEcsService()
				.processRequest(this);
		//		}
		//		catch (SystemException sysEx) {
		//			returnAbstractAsynchronousResponse.getErrorCollector().register(
		//					new EaseValidationException(RESOURCE_PROBLEM_MESSAGE));
		//		}
		return returnAbstractAsynchronousResponse;
	}

	/**
	 * Gets the absolute expiration time.
	 * 
	 * @return the absolute expiration time
	 */
	public long getAbsoluteExpirationTime() {
		return absoluteExpirationTime;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.request.impl.AbstractEcsRequest#isAsynchronousRequest()
	 */
	@Override
	public final boolean isAsynchronousRequest() {
		return true;
	}

	/**
	 * Sets the absolute expiration time.
	 * 
	 * @param aMsecTime the new absolute expiration time
	 */
	protected void setAbsoluteExpirationTime(long aMsecTime) {
		absoluteExpirationTime = aMsecTime;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AsynchronousEcsRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2010/11/05 22:17:33  mwtjc1
 *  try-catch block commented in execute method
 *
 *  Revision 1.8  2010/10/27 00:55:58  mwhys
 *  Removed CNA short term catch block as the response is asynchronous.
 *
 *  Revision 1.7  2010/10/27 00:50:21  mwhys
 *  Added try-catch block around getEcsService().processRequest(this) call.
 *
 *  Revision 1.6  2010/09/22 18:00:07  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2010/09/21 18:50:44  mwpxr4
 *  Merged branch mwkkc_ecs_persistance into HEAD.
 *
<<<<<<< AsynchronousEcsRequest.java
 *  Revision 1.4  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
=======
 *  Revision 1.3.4.2  2010/09/18 23:07:13  mwpxr4
 *  Typecasted concrete classes
 *
 *  Revision 1.3.4.1  2010/09/14 22:13:09  mwpxr4
 *  EcsService updates merged from HEAD version to fix application startup problems.
 *
 *  Revision 1.4  2010/09/14 18:29:09  mwkfh
 *  made EcsService non-static
 *
>>>>>>> 1.3.4.2
 *  Revision 1.3  2010/09/13 04:39:48  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/03/22 23:26:46  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/14 20:47:10  mwhxb3
 *  updated JavaDocs
 *
 *  Revision 1.6  2009/10/13 20:58:36  mwhxb3
 *  updated comments.
 *
 *  Revision 1.5  2009/10/08 20:27:07  mwpzs3
 *  comment out unused constructors
 *
 *  Revision 1.4  2009/10/07 03:33:43  mwhxb3
 *  imports cleanup
 *
 *  Revision 1.3  2009/10/07 02:56:50  mwhxb3
 *  removed log4j log statements
 *
 *  Revision 1.2  2009/10/06 21:53:05  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.2  2009/10/06 20:41:51  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:39  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.6  2009/10/03 21:23:37  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/08/27 02:33:54  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/10 23:05:47  mwpxp2
 *  Added logging; bulk cleanup
 *
 *  Revision 1.3  2009/08/04 22:58:34  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/04 22:43:34  mwpxp2
 *  Bulk cleanup; added UNDEF_TIME
 *
 *  Revision 1.1  2009/07/27 18:48:26  mwpxp2
 *  Renamed to insert "Dcs" into the name
 *
 *  Revision 1.8  2009/07/27 17:46:48  mwpxp2
 *  Bulk cleanup; javadoc
 *
 *  Revision 1.7  2009/07/21 15:29:55  mwakg
 *  Merging from branch MWAKG_ECS_CONVERTERS-CLEANING_BRANCH_20090720
 *
 *  Revision 1.6.2.1  2009/07/20 22:32:37  mwakg
 *  Fixed the constuctors and compilation errors in converters
 *
 *  Revision 1.6  2009/07/17 00:20:51  mwakg
 *  Added IUserContext as a parameter to request classes of ECS's converters
 *
 *  Revision 1.5  2009/07/16 02:16:48  mwpxp2
 *  Added footer
 *
 */
