/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.context.impl.ProcessContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I represent a decision in which a yes/no decision is made based
 * on the state of the process context.
 * File: DecisionActivity.java 
 * Module: gov.ca.dmv.ease.app.activity 
 * Created: Apr 2, 2009
 * @author mwsmg6
 * @version $Revision: 1.2 $ 
 * Last Changed: $Date: 2013/06/26 21:59:49 $ 
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class DecisionActivity extends TransientActivity {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(DecisionActivity.class);
	/** The Constant NO. */
	public static final String NO = "no";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7717241706749217352L;
	/** The Constant YES. */
	public static final String YES = "yes";
	
	/**
	 * Evaluate, allow multiple transitions for DecisionActivity.
	 * @param context the context
	 * @return transition key defined in the xml file
	 */
	protected abstract String evaluate(ProcessContext context);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.app.activity.impl.Activity#executeAuthorized(gov.ca.dmv
	 * .ease.app.context.impl.ProcessContext)
	 */
	@Override
	protected void executeAuthorized(ProcessContext context) {
		String key = evaluate(context);
		postCondition(context);
		LOGGER.info(activityName + ".evaluate() :: " + key);
		setTransitionKey(key);
		context.registerSyncPoint(this);
		if (isSavePoint()) {
			createSavePoint(context);
		}
		Activity nextActivity = getNextActivity();
		if (nextActivity != null) {
			LOGGER.debug("Next Activity :: " + nextActivity.getActivityName());
			nextActivity.execute(context);
		}
		else {
			signalInvalidNextActivityFor(context); //throws ProcessExecutionException
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: DecisionActivity.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.4.1  2013/04/30 16:49:40  mwsec2
 * adjusted logging statements
 *
 * Revision 1.1  2012/10/01 02:57:15  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.22  2012/05/08 00:10:57  mwhys
 * Merged SAVE_POINT_ENHANCEMENTS branch to HEAD.
 *
 * Revision 1.21.4.1  2012/02/21 21:15:02  mwsec2
 * save point support added
 *
 * Revision 1.21  2011/10/21 20:48:49  mwpxp2
 * Modified to use signalInvalidNextActivityFor for handling of invalid next activity
 *
 * Revision 1.20  2010/12/16 17:56:13  mwsec2
 * exception type changed to be more specific
 *
 * Revision 1.19  2010/08/31 17:55:57  mwhys
 * clean-up.
 *
 * Revision 1.18  2010/08/03 21:20:06  mwsec2
 * syncPoint enhancements
 *
 * Revision 1.17  2010/07/30 22:44:56  mwakg
 * Activities now register syncpoint activity and the processContext
 *
 * Revision 1.16  2010/07/30 20:15:53  mwakg
 * Merged from Fallback_branch
 *
 * Revision 1.15  2010/05/09 18:02:12  mwakg
 * Moved postCondition to sub classes
 *
 * Revision 1.14  2010/04/29 22:34:11  mwcsj3
 * Reverted back to version 1.12
 *
 * Revision 1.13  2010/04/29 17:55:01  mwcsj3
 * Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 * Revision 1.12  2010/04/22 22:27:25  mwcsj3
 * Fixed FIX ME
 *
 * Revision 1.11  2010/04/22 19:08:54  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.10  2010/04/22 19:02:43  mwpxp2
 * Added fixme
 *
 * Revision 1.9  2010/04/14 15:38:59  mwakg
 * Made activities authorizedExecute protected
 *
 * Revision 1.8  2010/04/13 23:24:19  mwpxp2
 * Added fixmes
 *
 * Revision 1.7  2010/04/08 23:46:27  mwcsj3
 * Added logging for easy debugging
 *
 * Revision 1.6  2010/04/07 22:19:16  mwcsj3
 * Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 * Revision 1.5  2010/03/27 01:06:51  mwsxd10
 * Not calling execute() method if the next activity is InteractionAactivity.
 * 
 * Revision 1.4 2010/03/22 22:58:11 mwpxp2
 * Javadoc/cleanup
 * 
 * Revision 1.3 2010/03/22 17:56:52 mwyxg1 change YES , NO to public for test
 * case
 * 
 * Revision 1.2 2010/03/11 22:20:04 mwcsj3 Made changes to accommodate multiple
 * transitions
 * 
 * Revision 1.1.2.3 2010/03/04 22:40:47 mwyxg1 add YES and NO constant
 * 
 * Revision 1.1.2.2 2010/02/26 19:37:48 mwyxg1 process multi process transition,
 * update documentation
 * 
 * Revision 1.1.2.1 2010/02/26 17:34:00 mwyxg1 process multi process transition
 * 
 * Revision 1.1 2009/11/23 16:22:52 mwrsk Intial commit
 * 
 * Revision 1.3 2009/10/07 20:18:29 mwsmg6 cleanup
 * 
 * Revision 1.2 2009/10/07 19:16:21 mwbxp5 Removed LOGGER
 * 
 * Revision 1.1 2009/10/03 20:57:17 mwpxp2 Moved into .impl; adjusted imports
 * 
 * Revision 1.10 2009/10/03 20:05:13 mwpxp2 Bulk cleanup
 * 
 * Revision 1.9 2009/09/23 00:02:26 mwsmg6 added clone
 * 
 * Revision 1.8 2009/09/02 20:44:13 mwsmg6 refactoring prepareResponse
 * 
 * Revision 1.7 2009/08/27 08:25:00 mwpxp2 Fixed imports to reflect fw
 * migration; bulk cleanup
 * 
 * Revision 1.6 2009/08/20 16:54:33 mwsmg6 enhanced logging of various
 * activities
 * 
 * Revision 1.5 2009/08/20 16:12:42 mwsmg6 provided more detailed logging of
 * activities
 * 
 * Revision 1.4 2009/08/19 22:43:28 mwsmg6 corrected class hierarchy and
 * resulting inherited methods
 * 
 * Revision 1.3 2009/08/10 23:30:09 mwpxp2 Added logging; bulk cleanup; added
 * file decorations where missing
 * 
 */
