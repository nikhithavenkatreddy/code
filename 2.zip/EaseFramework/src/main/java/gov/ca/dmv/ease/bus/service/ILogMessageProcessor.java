/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.service;

import gov.ca.dmv.ease.fw.constants.IEaseLoggingConstants;

/**
 * Description: //TODO - provide description!
 * File: LogMessageProcessor.java
 * Module:  gov.ca.dmv.ease.listeners.log.service
 * Created: Apr 30, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ILogMessageProcessor extends IEaseLoggingConstants {
	/**
	 * @param logMsg
	 */
	void execute(String logMsg);
}
/**
 * Modification History:
 * 
 * $Log: ILogMessageProcessor.java,v $
 * Revision 1.1  2012/10/01 02:57:19  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.1  2011/09/26 18:21:08  mwxxw
 * Updated to write the log message to DB instead of MQ for performance improvement.
 *
 */
