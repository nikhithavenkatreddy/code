/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: This represents the super class for all documents and
 * it has all the common attributes..
 * File: Document.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class Document extends BaseBusinessObject implements
		Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5768897269065199009L;
	/** The document holder name. */
	private String documentHolderName;
	/** The document id. */
	private String documentId;
	/** The effective date. */
	private Date effectiveDate;
	/** The expiration date. */
	private Date expirationDate;
	/** The issues date, issue date is different from effective date. */
	private Date issueDate;
	
	/**
	 * Default Constructor.
	 * 
	 */
	public Document() {
	}
	
	/**
	 * Copy Constructor
	 */
	public Document(Document document) {
		super();
		copy(document);
	}
	
	/**
	 * Copy.
	 *
	 * @param document the document
	 */
	protected void copy(Document document) {
		if (document == null) {
			throw new EaseValidationException(
					"non-null document argument expected in copy method in "
							+ this);
		}
		super.copy(document);
		//DocumentHolderName
		setDocumentHolderName(document.getDocumentHolderName());
		//DocumentId
		setDocumentId(document.getDocumentId());
		//EffectiveDate
		if (EaseUtil.isNotNull(document.getEffectiveDate())) {
			setEffectiveDate(new Date(document.getEffectiveDate().getTime()));
		}
		else {
			setEffectiveDate(null);
		}
		//ExpirationDate
		if (EaseUtil.isNotNull(document.getExpirationDate())) {
			setExpirationDate(new Date(document.getExpirationDate().getTime()));
		}
		else {
			setExpirationDate(null);
		}
		//IssueDate
		if (EaseUtil.isNotNull(document.getIssueDate())) {
			setIssueDate(new Date(document.getIssueDate().getTime()));
		}
		else {
			setIssueDate(null);
		}
	}
	
	/**
	 * Gets the document holder name.
	 * 
	 * @return the documentHolderName
	 */
	public String getDocumentHolderName() {
		return documentHolderName;
	}
	
	/**
	 * Gets the document id.
	 * 
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}
	
	/**
	 * Gets the effective date.
	 * 
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	
	/**
	 * Gets the expiration date.
	 * 
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}
	
	/**
	 * Gets the issue date.
	 * 
	 * @return the issue date
	 */
	public Date getIssueDate() {
		return issueDate;
	}
	
	/**
	 * Sets the document holder name.
	 * 
	 * @param documentHolderName the documentHolderName to set
	 */
	public void setDocumentHolderName(String documentHolderName) {
		this.documentHolderName = documentHolderName;
	}
	
	/**
	 * Sets the document id.
	 * 
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	
	/**
	 * Sets the effective date.
	 * 
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	/**
	 * Sets the expiration date.
	 * 
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	/**
	 * Sets the issue date.
	 * 
	 * @param issueDate the new issue date
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("documentHolderName", documentHolderName, anIndent,
				aBuilder);
		outputKeyValue("documentId", documentId, anIndent, aBuilder);
		outputKeyValue("effectiveDate", effectiveDate, anIndent, aBuilder);
		outputKeyValue("expirationDate", expirationDate, anIndent, aBuilder);
		outputKeyValue("issueDate", issueDate, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((documentHolderName == null) ? 0 : documentHolderName
						.hashCode());
		result = prime * result
				+ ((documentId == null) ? 0 : documentId.hashCode());
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime * result
				+ ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime * result
				+ ((issueDate == null) ? 0 : issueDate.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Document other = (Document) obj;
		if (documentHolderName == null) {
			if (other.documentHolderName != null)
				return false;
		}
		else if (!documentHolderName.equals(other.documentHolderName))
			return false;
		if (documentId == null) {
			if (other.documentId != null)
				return false;
		}
		else if (!documentId.equals(other.documentId))
			return false;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		}
		else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		}
		else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (issueDate == null) {
			if (other.issueDate != null)
				return false;
		}
		else if (!issueDate.equals(other.issueDate))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Document.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.12  2011/04/07 04:04:41  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.11.6.5  2011/04/05 22:52:18  mwsym2
 *  Committed on behalf of Prabhu Rajendran mwpxr5
 *  copy method modified for document id
 *
 *  Revision 1.11.6.4  2011/04/05 18:59:11  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.11.6.3  2011/04/05 17:42:33  mwhys
 *  Used isNotNull against !isNullOrBlank.
 *
 *  Revision 1.11.6.2  2011/04/05 16:42:55  mwhys
 *  (1) Regenerated hashCode() and equals() methods.
 *  (2) Modified copy constructor and method to include null checks and added explicit else blocks.
 *
 *  Revision 1.11.6.1  2011/04/02 01:40:24  mwrrv3
 *  Added copy constructor - Prabhu
 *
 *  Revision 1.11  2010/12/07 22:07:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.10  2010/12/07 02:52:09  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.9  2010/03/22 23:18:10  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.8  2010/02/23 23:28:08  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.7  2010/02/08 22:12:51  mwrsk
 *  Remove DocumentType Changes
 *
 *  Revision 1.6  2010/01/28 18:04:37  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.5  2010/01/12 01:05:43  mwhxa2
 *  Document Type Enum moved to different class
 *
 *  Revision 1.4  2010/01/11 21:28:20  mwhxa2
 *  Added Document Type as Enum
 *
 *  Revision 1.3  2010/01/11 21:25:23  mwhxa2
 *  Added Document Type as Enum
 *
 *  Revision 1.2  2010/01/11 21:14:18  mwhxa2
 *  Removed person from document
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/03 21:06:32  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/29 22:04:09  mwhxa2
 *  Extends BaseBusinessObject
 *
 *  Revision 1.5  2009/08/27 05:39:51  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/18 00:03:10  mwbxp5
 *  Added issue date.
 *
 *  Revision 1.3  2009/07/30 01:48:52  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:35  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
