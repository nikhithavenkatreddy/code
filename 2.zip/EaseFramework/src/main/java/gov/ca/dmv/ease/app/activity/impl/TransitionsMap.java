/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.activity.impl;

import gov.ca.dmv.ease.app.config.IProcessLoader;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * Description: This class is the transition map for activities.
 * File: TransitionsMap.java
 * Module:  gov.ca.dmv.ease.app.activity.impl
 * Created: Feb 23, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class TransitionsMap implements Serializable {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(TransitionsMap.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4187460275221902593L;
	/** Transitions Map */
	private transient Map <String, Activity> transitions;

	/**
	 * Add an element to the TransitionsMap.
	 * 
	 * @param key the key
	 * @param activity the activity
	 */
	public void addTransitions(String key, Activity activity) {
		getTransitions().put(key, activity);
	}

	/**
	 * Gets all the Transitions
	 * 
	 * @return set of all transitions
	 */
	public Set <Map.Entry <String, Activity>> getAllTransitions() {
		return getTransitions().entrySet();
	}

	/**
	 * Gets the Activity by key.
	 * 
	 * @param key the key
	 * 
	 * @return Activity
	 */
	public Activity getTransition(String key) {
		if ((key == null) || (key.trim().length() == 0)) {
			//TODO - isn't that too forgiving? 
			key = IProcessLoader.DEFAULT_TRANSITION_KEY;
		}
		Activity activity = getTransitions().get(key);
		if (activity == null) {
			LOGGER.error("Activity not found for key : " + key);
			//FIXME - throw exception instead
		}
		//FIXME - overloading of null value and masking of exception
		return activity;
	}

	/**
	 * Gets the TransitionsMap's keySet.
	 * 
	 * @return the keySet
	 */
	public Set <String> getTransitionKeys() {
		return getTransitions().keySet();
	}

	/**
	 * Gets the transitions.
	 * 
	 * @return the transitions
	 */
	protected Map <String, Activity> getTransitions() {
		if (transitions == null) {
			setTransitions(new LinkedHashMap <String, Activity>());
		}
		return transitions;
	}

	/**
	 * Remove activity.
	 * 
	 * @param key the key
	 */
	public void removeTransition(String key) {
		getTransitions().remove(key);
	}

	/**
	 * Sets the transitions.
	 * 
	 * @param aMap the a map
	 */
	protected void setTransitions(Map <String, Activity> aMap) {
		transitions = aMap;
	}
}
/**
 *  Modification History:
 *
 *  $Log: TransitionsMap.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.14  2010/09/23 18:55:34  mwhys
 *  Made transitions transient, which are restored during session restore.
 *
 *  Revision 1.13  2010/09/01 18:55:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.12  2010/08/20 18:47:34  mwpxp2
 *  Added lazy initialization of registry and internal access using the getter; added todos and fixmes
 *
 *  Revision 1.11  2010/06/21 23:00:41  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.10.6.1  2010/06/20 18:06:53  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.10  2010/05/05 02:16:00  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.9  2010/05/04 23:14:00  mwvkm
 *  Changed it to Serializable
 *
 *  Revision 1.8  2010/05/04 00:53:11  mwpxp2
 *  Imports adjusted for interface move to non-impl package
 *
 *  Revision 1.7  2010/04/22 19:08:54  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/04/08 01:55:37  mwcsj3
 *  Cleaned up, removed all unused and redundant methods
 *
 *  Revision 1.5  2010/03/22 22:58:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.4  2010/03/18 21:01:17  mwyxg1
 *  remove unused import
 *
 *  Revision 1.3  2010/03/18 21:00:56  mwyxg1
 *  use ordered map
 *
 *  Revision 1.2  2010/03/11 22:20:04  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1.2.3  2010/02/26 23:18:15  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.2  2010/02/26 19:44:10  mwyxg1
 *  process multi process transition, update documentation
 *
 *  Revision 1.1.2.1  2010/02/26 17:21:45  mwyxg1
 *  Add new
 *
 */
