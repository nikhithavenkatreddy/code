/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.print.converter.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.CodeSetRegistrySingleton;
import gov.ca.dmv.ease.bo.document.impl.DocumentToken;
import gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper;
import gov.ca.dmv.ease.ecs.exception.impl.MessageConversionException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.docs.exception.impl.DocumentServiceException;
import gov.ca.dmv.ease.tus.docs.template.impl.AbstractDocumentTemplate;
import gov.ca.dmv.ease.tus.print.converter.IDocumentConverter;
import gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * Description: Uses the corresponding templates to call the template the methods and provides the common repository for 
 * the variable value pair map
 * File: AbstractDocumentConverter.java
 * Module:  gov.ca.dmv.ease.tus.print.converter.impl
 * Created: Aug 12, 2009 
 * @author mwjzc8  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/03/06 23:12:16 $
 * Last Changed By: $Author: mwpxr5 $
 */
public abstract class AbstractDocumentConverter implements IDocumentConverter {
	/** The EMPTY_BLANK. */
	public static String BLANK = ""; // AbstractEcsMessageConverter.BLANK;
	/** The Entry Node. */
	public static final String ENTRY_NODE_BEGIN = "<entry>";
	/** The Entry Node. */
	public static final String ENTRY_NODE_END = "</entry>";
	/** The FORMATTE r_ ccy y_ m m_ dd. */
	public static String FORMATTER_CCYY_MM_DD = EcsConverterHelper.FORMATTER_CCYY_MM_DD;
	/** The FORMATTER_DD_MMM_YY. */
	public static String FORMATTER_DD_MMM_YY = EcsConverterHelper.FORMATTER_DD_MMM_YY;
	/** The FORMATTER_HH_mm. */
	public static String FORMATTER_HH_COLON_MM = EcsConverterHelper.FORMATTER_HH_COLON_MM;
	/** The FORMATTE r_ h h_ mm. */
	public static String FORMATTER_HH_MM = EcsConverterHelper.FORMATTER_HH_MM;
	/** The FORMATTER_HH_MM_SS. */
	public static String FORMATTER_HH_MM_SS = EcsConverterHelper.FORMATTER_HH_MM_SS;
	/** The FORMATTER_MM_DD. */
	public static String FORMATTER_MM_DASH_DD = EcsConverterHelper.FORMATTER_MM_DASH_DD;
	/** The FORMATTE r_ m m_ dd. */
	public static String FORMATTER_MM_DD = EcsConverterHelper.FORMATTER_MM_DD;
	/** The FORMATTER_MM_DD_YYYY. */
	public static String FORMATTER_MM_DD_CCYY = EcsConverterHelper.FORMATTER_MM_DD_CCYY;
	/** The FORMATTER_MM_DD_YY. */
	public static String FORMATTER_MM_DASH_DD_DASH_YY = EcsConverterHelper.FORMATTER_MM_DASH_DD_DASH_YY;
	/** The FORMATTER_MM_DD_YY. */
	public static String FORMATTER_MM_DD_YY = EcsConverterHelper.FORMATTER_MM_DD_YY;
	/** The FORMATTER_MM_DD_YYCC. */
	public static String FORMATTER_MM_DD_YYCC = EcsConverterHelper.FORMATTER_MM_DD_YYCC;
	/** The FORMATTER_MM_SLASH_DD_SLASH_CCYY. */
	public static String FORMATTER_MM_SLASH_DD_SLASH_CCYY = EcsConverterHelper.FORMATTER_MM_SLASH_DD_SLASH_CCYY;
	/** The FORMATTER_MM_SLASH_DD_SLASH_YY. */
	public static String FORMATTER_MM_SLASH_DD_SLASH_YY = EcsConverterHelper.FORMATTER_MM_SLASH_DD_SLASH_YY;
	/** The FORMATTER_MM_YY. */
	public static String FORMATTER_MM_YY = EcsConverterHelper.FORMATTER_MM_YY;
	/** The FORMATTE r_ yy. */
	public static String FORMATTER_YY = EcsConverterHelper.FORMATTER_YY;
	/** The FORMATTER_YY_MM_DD. */
	public static String FORMATTER_YY_MM_DD = EcsConverterHelper.FORMATTER_YY_MM_DD;
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory
			.getLog(AbstractDocumentConverter.class);
	/** The XML Header. */
	public static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	/**
	 * Convert date to string.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	protected static String convertDateToString(Date date) {
		return EcsConverterHelper.convertDateToString(date);
	}

	/**
	 * Converts date to string.
	 * 
	 * @param date the date
	 * @param format the format
	 * 
	 * @return the string
	 */
	public static String convertDateToString(Date date, String format) {
		return EcsConverterHelper.convertDateToString(date, format);
	}

	/**
	 * Gets the target document directory.
	 * 
	 * @return the target document directory
	 */
	public static File getTargetDocumentDirectory() {
		File aDocDir = new File(System.getProperty("java.io.tmpdir"));
		if (aDocDir.exists()) {
			if (!aDocDir.canWrite()) {
				throw new DocumentServiceException(
						"Cannot write to directory: \""
								+ aDocDir.getAbsolutePath() + "\"");
			}
		}
		//		else {
		//			aDocDir.mkdir();
		//			if (!aDocDir.exists()) {
		//				throw new DocumentServiceException(
		//						"failed creation of directory: \""
		//								+ aDocDir.getAbsolutePath() + "\"");
		//			}
		//		}
		return aDocDir;
	}

	/**
	 * Gets the target file for.
	 * 
	 * @param aToken the a token
	 * 
	 * @return the target file for
	 */
	public static File getTargetFileFor(DocumentToken aToken) {
		long time = (new Date()).getTime();
		File aTargetFile = null;
		try {
			aTargetFile = File.createTempFile(Long.toString(time), aToken
					.getFileExtensionFromDocType());
		}
		catch (IOException e) {
			LOGGER.error(e);
		}
		return aTargetFile;
	}

	/**
	 * Gets the target file name.
	 * 
	 * @param aToken the a token
	 * 
	 * @return the target file name
	 */
	public static String getTargetFileName(DocumentToken aToken) {
		return Long.toString((new Date()).getTime())
				+ aToken.getFileExtensionFromDocType();
	}

	/** The code set registry singleton. */
	protected CodeSetRegistrySingleton codeSetRegistrySingleton;// Injected by spring	
	/** The ecs message sources. */
	private ResourceBundleMessageSource ecsMessageSources;// Injected by spring
	/** The office name message sources. */
	private ResourceBundleMessageSource officeNameMessageSources;// Injected by spring
	/** The receipt var value map. */
	protected Map <String, String> receiptValue = new HashMap <String, String>();
	/** The template. */
	protected AbstractDocumentTemplate template;
	/** The user context. */
	//FIXME - user information has no place in a converter
	private IUserContext userContext;// Injected by spring	

	/**
	 * Adds the document prefix.
	 * 
	 * @param xmlString the xml string
	 * 
	 * @return the string
	 */
	private String addDocumentPrefix(String xmlString) {
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(XML_HEADER);
		sBuilder.append(ENTRY_NODE_BEGIN);
		sBuilder.append(xmlString);
		return sBuilder.toString();
	}

	/**
	 * Adds the document suffix.
	 * 
	 * @param xmlString the xml string
	 * 
	 * @return the string
	 */
	private String addDocumentSuffix(String xmlString) {
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(xmlString);
		sBuilder.append(ENTRY_NODE_END);
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.print.converter.IDocumentConverter#
	 * convertToCompleteDocumentBinding(gov.ca.dmv.ease.tus.print.request.impl.PrintServiceRequest)
	 */
	public final String convertToCompleteDocumentBinding(
			PrintServiceRequest request) {
		String buffer = convertToDocumentBinding(request);
		buffer = addDocumentPrefix(buffer);
		buffer = addDocumentSuffix(buffer);
		LOGGER.info(buffer);
		return buffer;
	}

	/**
	 * Generate exception.
	 * 
	 * @param errorMessage the error message
	 */
	protected void generateException(String errorMessage) {
		throw new MessageConversionException(errorMessage);
	}

	/**
	 * Generate file for.
	 * 
	 * @param aToken the a token
	 */
	public void generateFileFor(DocumentToken aToken) {
		File aTargetFile = getTargetFileFor(aToken);
		try {
			writeToTargetFile(aTargetFile);
			aToken.setToken(aTargetFile.getAbsolutePath());
		}
		catch (IOException e) {
			LOGGER.error(e);
			throw new DocumentServiceException(e);
		}
	}

	/**
	 * Gets the code set element.
	 * 
	 * @param codeSetname the code setname
	 * @param codeSetElementCode the code set element code
	 * 
	 * @return the code set element
	 */
	protected CodeSetElement getCodeSetElement(String codeSetname,
			String codeSetElementCode) {
		return EcsConverterHelper.getCodeSetElement(codeSetname,
				codeSetElementCode, this.codeSetRegistrySingleton);
	}

	/**
	 * Gets the ecs message sources.
	 * 
	 * @return the ecs message sources
	 */
	protected ResourceBundleMessageSource getEcsMessageSources() {
		return ecsMessageSources;
	}

	/**
	 * Gets the message from resource bundle.
	 * 
	 * @param key the key
	 * 
	 * @return the message from resource bundle
	 */
	protected String getMessageFromResourceBundle(String key) {
		return EcsConverterHelper.getMessageFromResourceBundle(
				ecsMessageSources, key);
	}

	/**
	 * Gets the message from resource bundle with default message.
	 * 
	 * @param key the key
	 * @param defaultMsg the default msg
	 * 
	 * @return the message from resource bundle with default message
	 */
	protected String getMessageFromResourceBundleWithDefaultMessage(String key,
			String defaultMsg) {
		return EcsConverterHelper
				.getMessageFromResourceBundleWithDefaultMessage(
						ecsMessageSources, key, defaultMsg);
	}

	/**
	 * Gets the message from resource bundle with parameters and default message.
	 * 
	 * @param key the key
	 * @param parameter the parameter
	 * @param defaultMsg the default msg
	 * 
	 * @return the message from resource bundle with parameters and default message
	 */
	protected String getMessageFromResourceBundleWithParametersAndDefaultMessage(
			String key, String[] parameter, String defaultMsg) {
		return EcsConverterHelper
				.getMessageFromResourceBundleWithParametersAndDefaultMessage(
						ecsMessageSources, key, parameter, defaultMsg);
	}

	/**
	 * Gets the office name message sources.
	 *
	 * @return the office name message sources
	 */
	protected ResourceBundleMessageSource getOfficeNameMessageSources() {
		return officeNameMessageSources;
	}

	/**
	 * Gets the message from office resource bundle.
	 *
	 * @param key the key
	 * @return the message from office resource bundle
	 */
	protected String getMessageFromOfficeResourceBundle(String key) {
		return officeNameMessageSources.getMessage(key, null, "", null);
	}

	/**
	 * Sets the office name message sources.
	 *
	 * @param ecsMessageSources the new office name message sources
	 */
	public void setOfficeNameMessageSources(// method for spring injection
			ResourceBundleMessageSource officeNameMessageSources) {
		this.officeNameMessageSources = officeNameMessageSources;
	}

	/**
	 * Gets the user context.
	 * 
	 * @return the user context
	 */
	protected IUserContext getUserContext() {
		return this.userContext;
	}

	/**
	 * Sets the code set registry singleton.
	 * 
	 * @param codeSetRegistrySingleton the new code set registry singleton
	 */
	public void setCodeSetRegistrySingleton(// method for spring injection
			CodeSetRegistrySingleton codeSetRegistrySingleton) {
		this.codeSetRegistrySingleton = codeSetRegistrySingleton;
	}

	/**
	 * Sets the ecs message sources.
	 * 
	 * @param ecsMessageSources the new ecs message sources
	 */
	public void setEcsMessageSources(// method for spring injection
			ResourceBundleMessageSource ecsMessageSources) {
		this.ecsMessageSources = ecsMessageSources;
	}

	/**
	 * Sets the template.
	 * 
	 * @param template the template
	 */
	public void setTemplate(AbstractDocumentTemplate template) {
		this.template = template;
	}

	/**
	 * Sets the user context.
	 * 
	 * @param userContext the new user context
	 */
	public void setUserContext(IUserContext userContext) {// method for spring injection
		this.userContext = userContext;
	}

	/**
	 * Validate client request.
	 * 
	 * @param requestFromClient the request from client
	 */
	protected void validateClientRequest(PrintServiceRequest requestFromClient) {
		if (EcsConverterHelper.isNull(requestFromClient)) {
			generateException(getMessageFromResourceBundle("NULL_REQUEST_FROM_CLIENT"));
		}
	}

	/**
	 * Write to target file.
	 * 
	 * @param aTargetFile the a target file
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void writeToTargetFile(File aTargetFile) throws IOException {
		//DriverLicenseReceiptFormatter formatter = new DriverLicenseReceiptFormatter();
		List <String> lines = AbstractDocumentTemplate
				.substituteVariables(receiptValue);
		LOGGER.debug("generateFile() - " + lines.toString());
		OutputStreamWriter outputStream;
		outputStream = new OutputStreamWriter(new FileOutputStream(aTargetFile));
		for (String line : lines) {
			StringTokenizer strTokenizer = new StringTokenizer(line, " ");
			int len = 0;
			while (strTokenizer.hasMoreTokens()) {
				String token = strTokenizer.nextToken();
				if (token.startsWith("@")) {
					int offset = Integer.parseInt(token.substring(1));
					int numberSpaces = offset - len;
					// if(numberSpaces < 0) numberSpaces = 1;
					for (int i = 0; i < numberSpaces; i++) {
						outputStream.write(" ", 0, 1);
					}
					len = offset;
				}
				else {
					outputStream.write(" ", 0, 1);
					outputStream.write(token, 0, token.length());
					len += token.length() + 1;
				}
			}
		}
		outputStream.flush();
		outputStream.close();
	}

	/**
	 * 
	 * @param aValue
	 * @param aRegex
	 * @return
	 */
	public static boolean checkValueAsPerRegex(String aValue, String aRegex) {
		Pattern p = Pattern.compile(aRegex);
		Matcher m = p.matcher(aValue);
		boolean matches = m.matches();
		return matches;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractDocumentConverter.java,v $
 *  Revision 1.2  2013/03/06 23:12:16  mwpxr5
 *  Fix for the defect 8674
 *
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.31  2011/10/12 20:58:12  mwkkc
 *  Performance Merge
 *
 *  Revision 1.29.8.1  2011/09/24 20:23:00  mwpxp2
 *  REmoved dep on AbstractEcsMessageConverter via BLANK
 *
 *  Revision 1.29  2011/06/09 22:58:03  mwyxg1
 *  clean up
 *
 *  Revision 1.28  2011/06/09 22:40:02  mwyxg1
 *  clean up
 *
 *  Revision 1.27  2011/03/23 23:46:59  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.26  2010/09/15 18:00:55  mwlft1
 *  Added resources for office name lookup
 *
 *  Revision 1.25  2010/09/01 19:07:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.24  2010/08/12 18:55:58  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.23  2010/07/13 18:26:23  mwlft1
 *  logging of xml data and removed extra xml entry
 *
 *  Revision 1.22  2010/07/12 23:02:13  mwjxa11
 *  Updated
 *
 *  Revision 1.21  2010/07/12 20:46:52  mwhxa2
 *  Added constants
 *
 *  Revision 1.20  2010/07/12 18:54:05  mwrsk
 *  Add capability for composite request
 *
 *  Revision 1.19  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.18  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.8.2.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.17  2010/06/09 18:29:56  mwtjc1
 *  methods place adjusted
 *
 *  Revision 1.16  2010/06/08 01:24:47  mwtjc1
 *  getCodeSetElement added
 *
 *  Revision 1.15  2010/06/08 01:16:49  mwtjc1
 *  codeSetRegistrySingleton added
 *
 *  Revision 1.14  2010/06/07 20:51:20  mwtjc1
 *  validateClientRequest added
 *
 *  Revision 1.13  2010/06/07 20:48:54  mwtjc1
 *  generateException added
 *
 *  Revision 1.12  2010/06/07 19:56:39  mwtjc1
 *  getMessageFromResourceBundle* method added
 *
 *  Revision 1.11  2010/06/07 17:54:05  mwtjc1
 *  convertDateToString added
 *
 *  Revision 1.10  2010/06/07 16:58:43  mwpxp2
 *  Added fixme; bulk cleanup
 *
 *  Revision 1.9  2010/06/03 02:33:25  mwuxb
 *  added user context and ecsMessageSources
 *
 *  Revision 1.8  2010/05/29 19:41:03  mwtjc1
 *  Instead of AbstractEcsMessageConverther, EcsConverterHelper is used
 *
 *  Revision 1.7  2010/05/11 01:12:47  mwjxa11
 *  Updated
 *
 *  Revision 1.6  2010/05/07 23:54:45  mwhxb3
 *  Removed methods of IMessageConverter.
 *
 *  Revision 1.5  2010/05/07 23:11:38  mwhxb3
 *  Added default impl for abstract methods.
 *
 *  Revision 1.4  2010/05/04 00:55:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/04/27 18:04:35  mwrsk
 *  Changes related to DocumentConverters extending from AbstractDocumentConverter
 *
 *  Revision 1.2  2010/03/22 23:39:47  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/02/09 21:22:24  mwhxa2
 *  Implements IDocumentConverter
 *
 *  Revision 1.2  2010/01/15 04:20:50  mwkkc
 *  Support for JCL
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/14 00:26:36  mwjxa11
 *  Refactored
 *
 *  Revision 1.4  2009/10/12 20:09:05  mwjxa11
 *  Improved the code coverage
 *
 *  Revision 1.3  2009/10/09 00:00:10  mwjxa11
 *  Removed unused method
 *
 *  Revision 1.2  2009/08/30 20:25:20  mwakg
 *  Using temporary file and temporary directory to create documents instead of absoulate path
 *
 *  Revision 1.1  2009/08/27 05:23:46  mwpxp2
 *  Renamed with Abstract prefix
 *
 *  Revision 1.1  2009/08/27 04:40:27  mwpxp2
 *  Moved in from documetn service project and package-restructured
 *
 *  Revision 1.3  2009/08/26 23:21:18  mwpxp2
 *  Replaced EaseValidationException references with DocumentServiceException refs
 *
 *  Revision 1.2  2009/08/26 22:25:28  mwpxp2
 *  Added javadoc and fixmes
 *
 *  Revision 1.1  2009/08/26 22:13:35  mwpxp2
 *  Moved into dedicated package
 *
 *  Revision 1.4  2009/08/26 21:54:04  mwpxp2
 *  Refactored writing of document file into separate methods; corrected error reporting in response
 *
 *  Revision 1.3  2009/08/26 18:11:13  mwpxp2
 *  Cleanup: added javadoc
 *
 *  Revision 1.2  2009/08/21 00:39:30  mwjxa11
 *  Used the resource bundle to retrieve the documents repository path.
 *
 *  Revision 1.1  2009/08/20 02:29:13  mwjxa11
 *  - Added with respective comments
 *  - Moved the implemenation classes to service.impl package from util package
 *  - Moved the creation of default state of an object to a method and called that method from default constructor
 *  - etc.
 *
 *  Revision 1.1  2009/08/16 00:31:58  mwjxa11
 *  Removed the hardcoded filePath from writeToFile, writeToFile2 methods. Also moved from gov.ca.dmv.ease.bus.util to gov.ca.dmv.ease.tus.docs.util
 *
 *  Revision 1.1  2009/08/15 17:10:11  mwjxa11
 *  Removed the hardcoded filePath from writeToFile, writeToFile2 methods. Also moved from gov.ca.dmv.ease.bus.util to gov.ca.dmv.ease.tus.docs.util
 *  
 *  Revision 1.4  2009/08/13 02:04:19  mwjxa11
 *  Removed the hardcoded filePath to store the generated document.
 *
 *  Revision 1.3  2009/08/13 00:51:00  mwpxp2
 *  Cleaned up; added logging and fixed system outs; added fixmes
 *
 */
