/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.session.response.impl;

import gov.ca.dmv.ease.app.session.response.ISessionServiceResponse;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

/**
 * Description: I define the interface to PersistenceServiceRequest
 * 
 * File: SessionServiceResponse.java
 * Module:  gov.ca.dmv.ease.app.session.response.impl
 * Created: Sep 29, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SessionServiceResponse extends AbstractResponse implements
		ISessionServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6467542351661828361L;

	/**
	 * The Default Constructor.
	 * 
	 */
	public SessionServiceResponse() {
	}

	/**
	 * Throws ITM exception if errors are found
	 */
	protected void throwExceptionIfErrorFound() {
		if (hasErrors()) {
			throw new EaseException("Session Response has errors");
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: SessionServiceResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:32  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/09/30 17:49:54  mwkfh
 *  refactored session mgmt into factory/request/response/service
 *
 */
