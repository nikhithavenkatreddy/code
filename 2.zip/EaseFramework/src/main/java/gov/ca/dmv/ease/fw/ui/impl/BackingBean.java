/*
 * 
 */
package gov.ca.dmv.ease.fw.ui.impl;

import gov.ca.dmv.ease.fw.ui.IBackingBean;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Description: I am default implementation of IBackingBean
 * File: BackingBean.java
 * Module:  gov.ca.dmv.ease.fw.ui.impl
 * Created:  2009 
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BackingBean implements IBackingBean {
	/** The properties. */
	private Map <String, Object> properties = new HashMap <String, Object>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.ui.IBackingBean#getNamedPropertiesUpdatedFromPage()
	 */
	public Set <String> getNamedPropertiesUpdatedFromPage() {
		return properties.keySet();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.ui.IBackingBean#getNamedProperty(java.lang.String)
	 */
	public Object getNamedProperty(String propertyName) {
		return properties.get(propertyName);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.ui.IBackingBean#setValueOfNamedProperty(java.lang.String,
	 * java.lang.Object)
	 */
	public void setValueOfNamedProperty(String key, Object value) {
		properties.put(key, value);
	}
}
/**
 *  Modification History:
 *
 *  $Log: BackingBean.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/06 02:12:44  mwpxp2
 *  Cleanup - added class footer, header
 *
 */
