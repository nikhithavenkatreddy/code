/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ecs.request;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.ecs.constants.IEcsConstants;
import gov.ca.dmv.ease.ecs.convert.IMessageConverter;
import gov.ca.dmv.ease.ecs.exception.impl.EcsServiceException;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.fw.exception.impl.EaseServiceLayerException;
import gov.ca.dmv.ease.fw.service.IRequest;
import gov.ca.dmv.ease.fw.validate.IValidatable;

/**
 * Description: Interface for a request submitted to the service.
 * The request is expected to follow the Command Pattern.
 * File: IRequest.java
 * Module:  gov.ca.dmv.ease.service
 * Created: Mar 17, 2009
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEcsRequest extends IEcsConstants, IValidatable, IRequest {
	/**
	 * Execute the request.
	 *
	 * @return the i response
	 *
	 * @throws EaseServiceLayerException the service exception
	 */
	IEcsResponse execute() throws EcsServiceException;

	/**
	 * Gets the business object using a named property.
	 *
	 * @param aPropertyName the a property name
	 *
	 * @return the business object named
	 */
	BusinessObject getBusinessObjectNamed(String aPropertyName);

	/**
	 * Gets the message converter.
	 * 
	 * @return the message converter
	 */
	IMessageConverter getMessageConverter();

	/**
	 * Gets the object value using a named property.
	 *
	 * @param aPropertyName the a property name
	 *
	 * @return the object value named
	 */
	Object getObjectValueNamed(String aPropertyName);

	/**
	 * Gets the request id. - this is correlation id
	 *
	 * @return the request id
	 */
	String getRequestId(); //TODO - redirect to getCorrelationId

	/**
	 * Gets the correlation id.
	 * 
	 * @return the correlation id
	 */
	String getCorrelationId();

	/**
	 * Checks for children.
	 *
	 * @return true, if successful
	 */
	boolean hasChildren();

	/**
	 * Checks if is persistable.
	 *
	 * @return true, if is persistable
	 */
	boolean isPersistable();
}
/**
 *  Modification History:
 *
 *  $Log: IEcsRequest.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2011/06/10 21:48:01  mwyxg1
 *  clean up
 *
 *  Revision 1.5  2010/12/12 17:57:16  mwpxp2
 *  Added explicitly named getCorrelationId
 *
 *  Revision 1.4  2010/09/13 04:39:50  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.3  2010/03/23 20:31:15  mwpxp2
 *  Exception imports adjusted per exception tree mods
 *
 *  Revision 1.2  2010/03/22 23:26:17  mwpxp2
 *  Adjusted imports for exception mods
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/14 21:59:37  mwhxb3
 *  updated comments
 *
 *  Revision 1.5  2009/10/14 20:09:46  mwhxb3
 *  changes due to renaming IDcsConstants to IEcsConstants.
 *
 *  Revision 1.4  2009/10/13 20:44:06  mwhxb3
 *  updated comments.
 *
 *  Revision 1.3  2009/10/11 22:51:42  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.2  2009/10/06 21:52:15  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.1.4.1  2009/10/06 20:28:50  mwhxb3
 *  refactoring from dcs to ecs
 *
 *  Revision 1.8  2009/10/03 21:23:43  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.7  2009/08/27 02:34:03  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.6  2009/08/22 20:23:55  mwpxp2
 *  Added getMessageConverter/0
 *
 *  Revision 1.5  2009/08/17 23:41:43  mwpxp2
 *  Removed validate/0 defined in super
 *
 *  Revision 1.4  2009/07/27 18:29:00  mwpxp2
 *  Adjusted imports for renames
 *
 *  Cleanup
 *
 *  Revision 1.3  2009-05-11 07:31:48  mwpxp2
 *  Synch
 *
 *  Revision 1.2  2009-05-10 06:11:02  mwpxp2
 *  Synch
 *
 *  Revision 1.1  2009-04-26 07:32:41  mwpxp2
 *  Initial
 *
*/
