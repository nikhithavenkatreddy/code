/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessLayerException;

/** 
 * Description: This class is an exception that is thrown when a process context
 * is detected to be in an invalid state.
 * File: ProcessStateInvalidException.java
 * Module:  gov.ca.dmv.ease.app.exception.impl
 * Created: Aug 18, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ProcessStateInvalidException extends EaseBusinessLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6956102320890907367L;

	/**
	 * Instantiates a new application exception.
	 */
	public ProcessStateInvalidException() {
		super();
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param message the message
	 */
	public ProcessStateInvalidException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public ProcessStateInvalidException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new application exception.
	 * 
	 * @param cause the cause
	 */
	public ProcessStateInvalidException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ProcessStateInvalidException.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/09/01 18:56:53  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/08/23 20:42:12  mwsec2
 *  initial check-in
 *
 */
