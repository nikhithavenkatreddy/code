/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.date;

import java.util.Date;

/**
 * Description: I am interface for the app-wide provider of "current date"
 * File: ICurrentDateProvider.java
 * Module:  gov.ca.dmv.ease.date
 * Created: Dec 1, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ICurrentDateProvider {
	/**
	 * Gets the current date.
	 * 
	 * @return the current date
	 */
	Date getCurrentDate();

	/**
	 * Gets the system date - as known to the executing JVM.
	 * 
	 * @return the system date
	 */
	Date getSystemDate();
}
/**
 *  Modification History:
 *
 *  $Log: ICurrentDateProvider.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2012/08/08 20:04:25  mwkfh
 *  removed getCurrentDateFromDb
 *
 *  Revision 1.3  2011/01/10 23:55:57  mwpxp2
 *  Added public getSystemDate/0
 *
 *  Revision 1.2  2010/12/16 20:15:52  mwpxp2
 *  Added getCurrentDateFromDb/0
 *
 *  Revision 1.1  2010/12/02 00:44:26  mwpxp2
 *  Initial
 *
 */
