/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo;

/**
 * Description: I am minimal interface for BOs that need to carry
 * information identifying inventory item: sequenceNo and item type code.
 * File: IWithInventoryItem.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Oct 19, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithInventoryItem {
	/**
	 * Gets the issued status.
	 * 
	 * @return the issued
	 */
	Boolean getInventoryItemIssued();

	/**
	 * Gets the inventory item sequence no.
	 * 
	 * @return the inventory item sequence no
	 */
	String getInventoryItemSequenceNo();

	/**
	 * Gets the inventory item type code.
	 * 
	 * @return the inventory item type code
	 */
	String getInventoryItemTypeCode();

	/**
	 * Sets the issued.
	 * 
	 * @param issued the new issued status
	 */
	void setInventoryItemIssued(Boolean issued);

	/**
	 * Sets the type transaction code.
	 * 
	 * @param aCode the new type transaction code
	 */
	void setInventoryItemTypeTransactionCode(String aCode);
}
/**
 *  Modification History:
 *
 *  $Log: IWithInventoryItem.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/22 22:18:30  mwkfh
 *  License no longer extends inv item but implements IWithInvItem
 *
 *  Revision 1.2  2010/10/19 21:51:06  mwpxp2
 *  Corrected spelling
 *
 *  Revision 1.1  2010/10/19 21:49:58  mwpxp2
 *  Initial
 *
 */
