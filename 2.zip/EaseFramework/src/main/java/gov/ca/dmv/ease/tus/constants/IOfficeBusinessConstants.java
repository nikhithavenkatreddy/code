/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.constants;

/**
 * Description: Office business service constants
 * File: IOfficeBusinessConstants.java
 * Module:  gov.ca.dmv.ease.tus.constants
 * Created: Jan 18, 2011 
 * @author MWXXW  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeBusinessConstants {
	/** PROCESS_ALLOWED for the office */
	static final String PROCESS_ALLOWED_DL_PROCESSING = "DL_PROCESSING";
	static final String PROCESS_ALLOWED_DL_STOP_CONDITION_OVERRIDE = "DL_STOP_CONDITION_OVERRIDE";
	static final String PROCESS_ALLOWED_DL_ANI_INQUIRY = "DL_ANI_INQUIRY";
	
	/** OFFICE_TYPE */
	static final String OFFICE_TYPE_DL_PROCESSING_OFFICE = "DL_PROCESSING_OFFICE";
	static final String OFFICE_TYPE_HQ_UNIT = "HQ_UNIT";
	static final String OFFICE_TYPE_DL_ISSUANCE_OFFICE = "DL_ISSUANCE_OFFICE";
	static final String OFFICE_TYPE_RISU = "RISU";
	static final String OFFICE_TYPE_LPVU = "LPVU";
	static final String OFFICE_TYPE_CENTRAL_PHONE_A_B_OFFICE = "CENTRAL_PHONE_A/B_OFFICE";
	static final String OFFICE_TYPE_TELEPHONE_SERVICE_CENTER = "TELEPHONE_SERVICE_CENTER";		
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeBusinessConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:38  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/01/18 22:59:37  mwxxw
 *  Initial version.
 *
 *
 */
