/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.app.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseBusinessLayerException;

/**
 * Description: I am be to thrown when a setter/getter method expects/returns
 * an object of a type other than what was provided/requested.
 * File: WrongTypeException.java
 * Module:  gov.ca.dmv.ease.app.exception.impl
 * Created: Sep 29, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class WrongTypeException extends EaseBusinessLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3359356035020671110L;

	/**
	 * Instantiates a new exception.
	 */
	public WrongTypeException() {
		super();
	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 */
	public WrongTypeException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new exception.
	 * @param cause
	 */
	public WrongTypeException(Throwable cause) {
		super(cause);
	}

	/**
	 * Instantiates a new exception.
	 * @param message
	 * @param cause
	 */
	public WrongTypeException(String message, Throwable cause) {
		super(message, cause);
	}
}


/**
 *  Modification History:
 *
 *  $Log: WrongTypeException.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/10/19 17:19:50  mwsec2
 *  initial check-in
 *
 *  Revision 1.1.2.2  2010/10/07 15:57:27  mwsec2
 *  clean up
 *
 *  Revision 1.1.2.1  2010/10/05 21:26:01  mwsec2
 *  initial check in
 *
 */
