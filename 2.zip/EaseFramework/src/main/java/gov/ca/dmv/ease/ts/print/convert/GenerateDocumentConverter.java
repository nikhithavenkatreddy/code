/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ts.print.convert;

import gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter;
import gov.ca.dmv.ease.ecs.request.IEcsRequest;
import gov.ca.dmv.ease.ecs.response.IEcsResponse;
import gov.ca.dmv.ease.tus.print.request.impl.GenerateDocumentRequest;
import gov.ca.dmv.ease.tus.print.response.impl.GenerateDocumentResponse;

/**
 * Description: I am the converter for Document Generation.
 * File: GenerateDocumentConverter.java
 * Module:  gov.ca.dmv.ease.ts.print.convert
 * Created: May 10, 2010 
 * @author MWHXB3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class GenerateDocumentConverter extends AbstractEcsMessageConverter {
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter#createMessage(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	@Override
	public String createMessage(IEcsRequest request) {
		return ((GenerateDocumentRequest) request).getXmlData();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.impl.AbstractEcsMessageConverter#createResponse(java.lang.String)
	 */
	@Override
	public IEcsResponse createResponse(String anInboundMessagePayload) {
		GenerateDocumentResponse response = new GenerateDocumentResponse();
		response.setData(anInboundMessagePayload);
		return response;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ecs.convert.IMessageConverter#getLogId(gov.ca.dmv.ease.ecs.request.IEcsRequest)
	 */
	public String getLogId(IEcsRequest request) {
		return null;
	}
}
/**
 *  Modification History:
 *
 *  $Log: GenerateDocumentConverter.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/02/29 01:00:54  mwxxw
 *  Implement new interface getLogId().
 *
 *  Revision 1.2  2010/05/18 21:04:04  mwtjc1
 *  proper class description is added
 *
 *  Revision 1.1  2010/05/17 21:59:17  mwhxb3
 *  The converter for document generation
 *
 */
