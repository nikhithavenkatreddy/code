/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.domain.entity;


import java.util.Date;

/**
 * Description: This represents the Office work date control details.
 * File: OfficeWorkdate.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Mar 12, 2010
 * @author mwvxm6
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/07/22 17:50:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class OfficeWorkdate  {
	private static final long serialVersionUID = 3410040368329578133L;
	/** The authorized work date for the office. */
	private Date authorizedWorkDate;
	/** The office for this workdate. */
	private Office office;
	/** The status of the workdate - Active/ Purge etc... */
	private String status;

	/** Default Constructor */
	public OfficeWorkdate() {
		super();
		initializeWorkDate();
		//office = new Office();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}
		OfficeWorkdate other = (OfficeWorkdate) obj;
		if (!getAuthorizedWorkDate().equals(other.getAuthorizedWorkDate())) {
			return false;
		}
		if (!getStatus().equals(other.getStatus())) {
			return false;
		}
		if (!getOffice().equals(other.getOffice())) {
			return false;
		}
		return true;
	}

	/**
	 * @return the authorizedWorkDate
	 */
	public Date getAuthorizedWorkDate() {
		return authorizedWorkDate;
	}

	/**
	 * @return the office
	 */
	public Office getOffice() {
		return office;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((authorizedWorkDate == null) ? 0 : authorizedWorkDate
						.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((office == null) ? 0 : office.hashCode());
		return result;
	}

	public void initializeWorkDate() {
	}

	/**
	 * Sets the Authorized Work Date.
	 * 
	 * @param authorizedWorkDate the authorizedWorkDate to set
	 */
	public void setAuthorizedWorkDate(Date authorizedWorkDate) {
		this.authorizedWorkDate = authorizedWorkDate;
	}

	/**
	 * Sets the Office.
	 * 
	 * @param office the office to set
	 */
	public void setOffice(Office office) {
		this.office = office;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
