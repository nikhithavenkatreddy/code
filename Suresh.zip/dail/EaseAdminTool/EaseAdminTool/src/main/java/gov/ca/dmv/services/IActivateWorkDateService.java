/**
 * 
 */
package gov.ca.dmv.services;

import java.util.List;

import gov.ca.dmv.domain.entity.EmployeeWorkdateControl;
import gov.ca.dmv.domain.entity.Office;
import gov.ca.dmv.domain.entity.OfficeWorkdate;
import gov.ca.dmv.model.ActiveWorkDateModel;

/**
 * @author Owner
 *	
 */
public interface IActivateWorkDateService {

	
	/**	
	 * Gets the all offices.
	 *
	 * @return the all offices
	 */
	public abstract List <Office> getAllOffices();	
	
	/**
	 * Gets the employee office details by office id.
	 *
	 * @param input the input
	 * @return the employee office details by office id
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetailsByOfficeId(
			ActiveWorkDateModel input);	
	
	
	/**
	 * Gets the employee office details.
	 *
	 * @param inputData the input data
	 * @return the employee office details
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetails(
			ActiveWorkDateModel	 inputData);
	
	/**
	 	* Update work date status.
	 *
	 * @param input the input
	 * @param updateBoth the update both
	 * @return the save work date status response
	 */
	public abstract String updateWorkDateStatus(
			List <EmployeeWorkdateControl> input, boolean updateBoth);
	
	public abstract String updateOfficeWorkDateStatus(
			List <OfficeWorkdate> input);

}
