/**
 * 
 */
package gov.ca.dmv.services.impl;

import java.util.List;

import gov.ca.dmv.domain.entity.EmployeeWorkdateControl;
import gov.ca.dmv.domain.entity.Office;
import gov.ca.dmv.domain.entity.OfficeWorkdate;
import gov.ca.dmv.model.ActiveWorkDateModel;
import gov.ca.dmv.services.IActivateWorkDateService;

/**
 * @author Owner
 *
 */
public class ActivateWorkDateService implements IActivateWorkDateService {

	/* (non-Javadoc)
	 * @see gov.ca.dmv.services.IActivateWorkDateService#getAllOffices()	
	 */
	@Override
	public List<Office> getAllOffices() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.services.IActivateWorkDateService#getEmployeeOfficeDetailsByOfficeId(gov.ca.dmv.model.ActiveWorkDateModel)
	 */
	@Override
	public List<EmployeeWorkdateControl> getEmployeeOfficeDetailsByOfficeId(ActiveWorkDateModel input) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.services.IActivateWorkDateService#getEmployeeOfficeDetails(gov.ca.dmv.model.ActiveWorkDateModel)
	 */
	@Override
	public List<EmployeeWorkdateControl> getEmployeeOfficeDetails(ActiveWorkDateModel inputData) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateWorkDateStatus(List<EmployeeWorkdateControl> input, boolean updateBoth) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateOfficeWorkDateStatus(List<OfficeWorkdate> input) {
		// TODO Auto-generated method stub
		return null;
	}

}
