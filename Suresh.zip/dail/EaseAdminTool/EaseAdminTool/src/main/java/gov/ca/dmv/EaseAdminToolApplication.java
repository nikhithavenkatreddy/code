package gov.ca.dmv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EaseAdminToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(EaseAdminToolApplication.class, args);
	}
}
