/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.domain.entity;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Description: Employee class encapsulates the attributes specific to 
 * DMV Employee who uses the system in the field office. 
 * This includes 1. Loaned and relief employees from other offices 
 * 2. Occupational Licensing personnel (inspectors).
 * File: Employee.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl	
 * Created: May 4, 2009
 * @author MWCSJ3
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2012/08/02 16:29:03 $
 * Last Changed By: $Author: mwkfh $
 */
@Entity
@Table(name = "VSSM026U_EMPLOYEE_A", schema = "")
@NamedQueries({
@NamedQuery(name = "Employee.findAll", query = "SELECT e FROM Employee e"),
@NamedQuery(name = "Employee.findDistinctList", query = "select distinct e.employeeTechId from Employee e	")
})	
public class Employee  {
	/** The Constant serialVersionUID. */	
	private static final long serialVersionUID = -2572349277938907675L;
	/** The employee technician id. */
	private String employeeTechId;
	/** The office id. */
	private String officeId;

	/** Default Constructor */
	public Employee() {
		super();
		/*		employeePrincipal = new EmployeePrincipal();
				employeeWorkdateControl = new EmployeeWorkdateControl();
				transactions = new ArrayList <Transaction>();*/
	}

	/**
	 * Constructor
	 * 
	 * @param officeId
	 * @param employeeTechId
	 */
	public Employee(String officeId, String employeeTechId) {
		super();
		setEmployeeTechId(employeeTechId);
		setOfficeId(officeId);
		/*		employeePrincipal = new EmployeePrincipal();
				employeeWorkdateControl = new EmployeeWorkdateControl();
				transactions = new ArrayList <Transaction>();*/
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		Employee other = (Employee) obj;
		if (employeeTechId == null) {
			if (other.employeeTechId != null) {
				return false;
			}
		}
		else if (!employeeTechId.equals(other.employeeTechId)) {
			return false;
		}
		if (officeId == null) {
			if (other.officeId != null) {
				return false;
			}
		}
		else if (!officeId.equals(other.officeId)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the employee tech id.
	 * 
	 * @return the employeeTechId
	 */
	public String getEmployeeTechId() {
		return employeeTechId;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((employeeTechId == null) ? 0 : employeeTechId.hashCode())
				+ ((officeId == null) ? 0 : officeId.hashCode());
		return result;
	}

	/**
	 * Sets the employee technician id.
	 * 
	 * @param employeeTechId the employeeTechId to set
	 */
	public void setEmployeeTechId(String employeeTechId) {
		this.employeeTechId = employeeTechId;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Employee.java,v $
 *  Revision 1.6  2012/08/02 16:29:03  mwkfh
 *  added office id to employee table - defect 1429
 *
 *  Revision 1.5  2011/11/15 19:24:12  mwkkc
 *  Performance Cleanup
 *
 *  Revision 1.4  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/07/08 21:01:00  mwvxm6
 *  Updated comments
 *
 *  Revision 1.2  2010/07/08 18:59:45  mwvxm6
 *  Updated per Bridge code database spec
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.4  2010/02/04 19:09:28  mwvxm6
 *  Removed Autowired and configured explicitly in spring context xml
 *
 *  Revision 1.3  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.18  2009/10/12 18:42:31  mwtjc1
 *  currentVRSequenceNumber variable of EmployeeWorkdateControl class is changed to currentVrSequenceNumber to satisfy camel casing requirement
 *
 *  Revision 1.17  2009/10/11 00:26:35  mwakg
 *  Fixed unit tests
 *
 *  Revision 1.16  2009/10/07 01:16:50  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.14  2009/10/03 21:06:30  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.13  2009/09/02 00:01:49  mwrsk
 *  Made associations to be fetched eagerly
 *
 *  Revision 1.12  2009/08/28 21:34:16  mwrsk
 *  Updated annotations
 *
 *  Revision 1.11  2009/08/28 01:24:52  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.10  2009/08/27 05:39:44  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2009/08/22 23:19:32  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.8  2009/08/19 18:41:31  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.7  2009/08/06 01:44:25  mwrrv2
 *  updated the table annotations
 *
 *  Revision 1.6  2009/08/05 05:05:46  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.5  2009/08/04 23:16:56  mwyxg1
 *  avoid circular initilization
 *
 *  Revision 1.4  2009/08/04 22:18:48  mwyxg1
 *  add constructor
 *
 *  Revision 1.3  2009/07/29 17:17:30  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:30  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 15:26:05  ppalacz
 *  Moved to .impl
 *
 *  Revision 1.1  2009-07-10 07:09:25  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 10:53:19 AM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 10:53:19 AM  MWCSJ3
 *  $Initial
 *  $
 */
