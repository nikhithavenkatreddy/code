/**
 * 
 */
package gov.ca.dmv.ease.fw.service;

import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.io.Serializable;

/**
 * Description: I am interface for all response implementations
 * File: IResponse.java
 * Module:  gov.ca.dmv.ease.fw.response
 * Created: Jul 9, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IResponse extends ITreePrintable, Serializable {
	/** Teh undefined int value */
	int UNDEF_INT = -1;
	/** The undefined long value. */
	long UNDEF_LONG = -1;

	/**
	 * Gets the error collector.
	 * 
	 * @return the error collector
	 */
	IErrorCollector getErrorCollector();

	/**
	 * Checks for errors.
	 * 
	 * @return true, if successful
	 */
	boolean hasErrors();

	/**
	 * Register.
	 * 
	 * @param e the e
	 */
	void register(Exception e);
}
/**
 *  Modification History:
 * 
 *  $Log: IResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/12 05:53:08  mwpxp2
 *  Extended ITreePrintable
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/05 21:14:48  mwpxp2
 *  Added undef long
 *
 *  Revision 1.1  2009/10/03 20:24:35  mwpxp2
 *  Moved into fw.service; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.5  2009/08/26 18:29:08  mwpxp2
 *  Added boolean hasErrors()
 *
 *  Revision 1.4  2009/08/22 21:20:37  mwpxp2
 *  Added getErrorCollector/0 and register/1 exception
 *
 *  Revision 1.3  2009/07/27 18:20:51  mwpxp2
 *  Added comment
 *
 *  Revision 1.2  2009/07/14 23:44:37  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 15:52:20  mwpxp2
 *  Initial
 *
 *  Revision 1.1  2009-07-10 07:13:09  mwpxp2
 *  Synch
 *
*/
