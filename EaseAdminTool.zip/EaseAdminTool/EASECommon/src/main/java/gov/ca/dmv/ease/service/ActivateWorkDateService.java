/**
 * 
 */
package gov.ca.dmv.ease.service;

import java.util.List;

import gov.ca.dmv.ease.domain.entity.EmployeeWorkdateControl;
import gov.ca.dmv.ease.domain.entity.Office;

/**
 * @author Owner
 *
 */
public interface ActivateWorkDateService {

	
	/**
	 * Gets the all offices.
	 *
	 * @return the all offices
	 */
	public abstract List <Office> getAllOffices();	
	
	/**
	 * Gets the employee office details by office id.
	 *
	 * @param input the input
	 * @return the employee office details by office id
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetailsByOfficeId(
			InputData input);	
	
	
	/**
	 * Gets the employee office details.
	 *
	 * @param inputData the input data
	 * @return the employee office details
	 */
	public abstract List <EmployeeWorkdateControl> getEmployeeOfficeDetails(
			InputData inputData);
	
	/**
	 * Update work date status.
	 *
	 * @param input the input
	 * @param updateBoth the update both
	 * @return the save work date status response
	 */
	public abstract SaveWorkDateStatusResponse updateWorkDateStatus(
			List <EmployeeWorkdateControl> input, boolean updateBoth);
	
	public abstract SaveWorkDateStatusResponse updateOfficeWorkDateStatus(
			List <OfficeWorkdate> input);

}
