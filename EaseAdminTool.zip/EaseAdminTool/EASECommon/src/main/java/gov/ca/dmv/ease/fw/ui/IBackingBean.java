/*
 * 
 */
package gov.ca.dmv.ease.fw.ui;

import java.util.Set;

/**
 * The Interface IBackingBean.
 */
public interface IBackingBean {
	/**
	 * Returns all the properties in the backing bean.
	 * 
	 * @return all the properties name
	 */
	Set <String> getNamedPropertiesUpdatedFromPage();

	/**
	 * Gets the named property.
	 * 
	 * @param string name of the property
	 * 
	 * @return value of the property
	 */
	Object getNamedProperty(String string);

	/**
	 * Sets the value to backing bean property.
	 * 
	 * @param key property key
	 * @param value property value
	 */
	void setValueOfNamedProperty(String key, Object value);
}