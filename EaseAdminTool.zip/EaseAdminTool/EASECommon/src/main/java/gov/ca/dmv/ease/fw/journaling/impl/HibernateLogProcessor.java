/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.journaling.impl;

import gov.ca.dmv.ease.bus.service.ILogMessageProcessor;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;
import gov.ca.dmv.ease.tus.logging.po.impl.AuditLog;
import gov.ca.dmv.ease.tus.logging.po.impl.SysMgmtLog;
import gov.ca.dmv.ease.tus.logging.po.impl.SystemLog;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;

import java.util.Date;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;

/**
 * Description: I am the logProcessor using hibernate as a framework for saving data into DB
 * File: HibernateLogProcessor.java
 * Module:  gov.ca.dmv.ease.fw.journaling.impl
 * Created: May 2, 2010 
 * @author MWAKG  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class HibernateLogProcessor implements ILogMessageProcessor {
	/**
	 * Creates the log entry.
	 * 
	 * @param logMessage 
	 * 
	 * @return the abstract log
	 */
	protected AbstractLog createLogEntry(String logMessage) {
		AbstractLog log = null;
		if (!EaseUtil.isNullOrBlank(logMessage)) {
			if (logMessage.startsWith(AUDIT_PREFIX)) {
				log = new AuditLog();
			}
			else if (logMessage.startsWith(SM_PREFIX)) {
				log = new SysMgmtLog();
			}
			else if (logMessage.startsWith(TECH_PREFIX)) {
				log = new SystemLog();
			}
			else {
				throw new ApplicationException(
						"Unknown prefix type - Message : " + logMessage);
			}
			int logEntryIndex = logMessage.indexOf(LOG_ENTRY);
			if (logEntryIndex != -1) {
				String aHeader = logMessage.substring(0, logEntryIndex);
				populateLogBusinessObject(log, aHeader);
				String aMessage = logMessage.substring(logEntryIndex
						+ LOG_ENTRY.length() + 1);
				log.setLogEntry(aMessage);
			}
		}
		return log;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.listeners.log.service.ILogProcessor#execute(java.lang.String)
	 */
	public void execute(String aMessage) {
		AbstractLog aLog = createLogEntry(aMessage);
		if (StringUtils.isNotBlank(aLog.getLogEntry())) {
			IPersistenceServiceRequest logRequest = getPersistenceServiceRequestFactory()
					.createSaveOrUpdateBusinessObjectRequest(null, aLog);
			PersistenceServiceResponse aResponse = logRequest.execute();
			if (aResponse.hasErrors()) {
				//FIXME - use proper exception class
				throw new ApplicationException(aResponse.getErrorCollector()
						.getEntries().get(0).getExceptionMessage());
			}
		}
	}

	/**
	 * Gets the persistence service request factory.
	 * 
	 * @return the persistence service request factory
	 */
	public PersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		return PersistenceServiceRequestFactory.getInstance();
	}

	/**
	 * Populate log business object.
	 * 
	 * @param log the log
	 * @param aHeader the a header part of the message
	 */
	private void populateLogBusinessObject(AbstractLog log, String aHeader) {
		StringTokenizer st = new StringTokenizer(aHeader, FIELD_DELIMITER);
		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			if (token.indexOf(CREATED_BY) >= 0) {
				log.setCreatedBy(token.substring(token
						.indexOf(NAME_VALUE_SEPERATOR) + 1));
			}
			else if (token.indexOf(METHOD_CLASS_NAME) >= 0) {
				log.setMethodClassName(token.substring(token
						.indexOf(NAME_VALUE_SEPERATOR) + 1));
			}
			else if (token.indexOf(THREAD_ID) >= 0) {
				log.setThreadId(token.substring(token
						.indexOf(NAME_VALUE_SEPERATOR) + 1));
			}
			else if (token.indexOf(LOG_TIMESTAMP) >= 0) {
				long dateInMillis = Long.valueOf(token.substring(token
						.indexOf(NAME_VALUE_SEPERATOR) + 1));
				log.setTimeStamp(new Date(dateInMillis));
			}
			else if (token.indexOf(PRINCIPAL_ID) >= 0) {
				log.setPrincipalId(token.substring(token
						.indexOf(NAME_VALUE_SEPERATOR) + 1));
			}
			
			if (log instanceof SysMgmtLog) {
				SysMgmtLog sysMgmtLog = (SysMgmtLog)log;
				if (token.indexOf(OFFICE_ID) >= 0) {
					sysMgmtLog.setOfficeId(token.substring(token
							.indexOf(NAME_VALUE_SEPERATOR) + 1));
				}
				else if (token.indexOf(TECH_ID) >= 0) {
					sysMgmtLog.setTechId(token.substring(token
							.indexOf(NAME_VALUE_SEPERATOR) + 1));
				}
				else if (token.indexOf(DL_NBR) >= 0) {
					sysMgmtLog.setDlOrIdNumber(token.substring(token
							.indexOf(NAME_VALUE_SEPERATOR) + 1));
				}
				else if (token.indexOf(TRANS_DT) >= 0) { 
					//sysMgmtLog.setTransactionDate(new Date(token.substring(token.indexOf(NAME_VALUE_SEPERATOR) + 1)));
				}
			}
		}
	}
	/**
	 * Sets the persistence service request factory.
	 * 
	 * @param aFactory the new persistence service request factory
	 */
	//	public void setPersistenceServiceRequestFactory(
	//			PersistenceServiceRequestFactory aFactory) {
	//		persistenceServiceRequestFactory = aFactory;
	//	}
}
/**
 * Modification History:
 * 
 * $Log: HibernateLogProcessor.java,v $
 * Revision 1.2  2013/06/26 21:59:49  mwsec2
 * WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 * Revision 1.1.2.1  2013/02/27 19:53:07  mwsec2
 * moved HibernateLogProcessor to journaling package
 *
 * Revision 1.1  2012/10/01 02:57:32  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.4  2012/08/08 20:20:39  mwxxw
 * Change from private to protected for createLogEntry().
 *
 * Revision 1.3  2012/02/15 21:26:30  mwxxw
 * Add logging for additional fields: officeId, techId, dlNumber and partitionId.
 *
 * Revision 1.2  2011/09/29 00:38:22  mwkfh
 * added null check
 *
 * Revision 1.1  2011/09/26 18:21:08  mwxxw
 * Updated to write the log message to DB instead of MQ for performance improvement.
 *
 * Revision 1.5  2010/11/24 23:20:47  mwkfh
 * updated getPersistenceServiceRequestFactory
 *
 * Revision 1.4  2010/11/18 02:22:11  mwpxp2
 * Imports cleanup
 *
 * Revision 1.3  2010/11/18 02:10:25  mwpxp2
 * Added fixmes; cleaned up
 *
 * Revision 1.2  2010/09/16 18:41:10  mwkkc
 * Removed *.Impl from all comments and the Test class name.
 *
 * Revision 1.1  2010/09/16 18:34:43  mwkkc
 * Removed *.impl from the class name and refactored.
 *
 * Revision 1.3  2010/08/31 17:59:53  mwhys
 * Marked Service(s) as transient.
 *
 * Revision 1.2  2010/07/09 21:22:51  mwkkc
 * Fixed the issue with processing not proper formatted JMS messages. StringIndexOutOfBoundsException was thrown while processing a message with index of -1.
 *
 * Revision 1.1  2010/05/03 01:48:50  mwakg
 * Added JDBC and Hibernate implementations for LogProcessor and also added moved business logic from MDB to POJOs
 *
 * 
 */
