/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.format.FieldValueType;
import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormatFactory;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;

/**
 * Description: I am default implementation of IMessageFormatFactory
 * File: MessageFormatFactory.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MessageFormatFactory implements IMessageFormatFactory {
	/**
	 * Instantiates a new message format factory.
	 */
	public MessageFormatFactory() {
		super();
	}

	/**
	 * Creates a new MessageFormat object.
	 * 
	 * @param aFieldValue 
	 * @param aStart 
	 * 
	 * @return 
	 */
	public IFieldFormat createFieldFormatUsing(String aFieldValue, int aStart) {
		int aSize = aFieldValue.length();
		if (aSize > 0) {
			char aTypeChar = aFieldValue.charAt(0);
			return createFieldFormatUsing(aFieldValue, aStart, aTypeChar);
		}
		else {
			throw new FormatValidationException(
					"non zero length string expected");
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormatFactory#createFieldFormatUsing(java.lang.String, int, char)
	 */
	public IFieldFormat createFieldFormatUsing(String string, int pos,
			char typeChar) {
		FieldValueType aType = FieldValueType.typeForChar(typeChar);
		return createFieldFormatUsing(string, pos, aType);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormatFactory#createFieldFormatUsing(java.lang.String, int, gov.ca.dmv.ease.fw.format.FieldValueType)
	 */
	public IFieldFormat createFieldFormatUsing(String string, int pos,
			FieldValueType type) {
		//return new PatternedFieldFormat(pos, string.length(), type);
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormatFactory#createMessageFormatUsing(java.lang.String[])
	 */
	public IMessageFormat createMessageFormatUsing(String... stringArr) {
		MessageFormat aFormat = new MessageFormat();
		IFieldFormat aField;
		int currPos = 0;
		for (String aFieldValue : stringArr) {
			aField = createFieldFormatUsing(aFieldValue, currPos);
			aFormat.add(aField);
			currPos += aFieldValue.length();
		}
		return aFormat;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MessageFormatFactory.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/11/29 18:17:04  mwpxp2
 *  Temp fix for abstract PatternedFieldFormat instantiation
 *
 *  Revision 1.3  2010/11/24 20:40:53  mwpxp2
 *  Adjusted for new PatternedFieldFormat
 *
 *  Revision 1.2  2010/11/20 22:48:10  mwpxp2
 *  Fixed createMessageFormatUsing/...
 *
 *  Revision 1.1  2010/11/20 21:32:13  mwpxp2
 *  Initial
 *
 */
