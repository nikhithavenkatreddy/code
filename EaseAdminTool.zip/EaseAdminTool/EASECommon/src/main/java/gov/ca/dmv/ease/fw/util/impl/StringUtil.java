/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.util.impl;

import java.io.Serializable;

/**
 * Description: I am a static utility class for String-related methods
 * File: StringUtil.java
 * Module:  gov.ca.dmv.ease.fw.util.impl
 * Created: Aug 15, 2012
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:34 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class StringUtil implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1783158432429287035L;

	/**
	 * Instantiates a new string util.
	 */
	protected StringUtil() {
	}

	/**
	 * This method returns the array of strings for a given string and delimiter.
	 *
	 * @param str the str
	 * @param separator the separator
	 *
	 * @return the string[]
	 */
	public static String[] splitShortString(String str, char separator) {
		//FIXME why in Array utils?
		int len;
		if (str == null || (len = str.length()) == 0) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}
		int lastTokenIndex = 0;
		// Step 1: how many substrings?
		//      We exchange double scan time for less memory allocation
		for (int pos = str.indexOf(separator); pos >= 0; pos = str.indexOf(
				separator, pos + 1)) {
			lastTokenIndex++;
		}
		// Step 2: allocate exact size array
		String[] list = new String[lastTokenIndex + 1];
		int oldPos = 0;
		// Step 3: retrieve substrings
		for (int pos = str.indexOf(separator), i = 0; pos >= 0; pos = str
				.indexOf(separator, (oldPos = (pos + 1)))) {
			list[i++] = substring(str, oldPos, pos);
		}
		list[lastTokenIndex] = substring(str, oldPos, len);
		return list;
	}

	/**
	 * This method returns the substring assuming the second parameter as the beginning index and the third parameter as ending index.
	 *
	 * @param str the str
	 * @param begin the begin
	 * @param end the end
	 *
	 * @return the string
	 */
	// TODO make this private
	public static String substring(String str, int begin, int end) {
		//FIXME how come this is in _Array_Util?
		//FIXME what if str is null or empty or end < begin?
		if (begin == end) {
			return "";
		}
		return str.substring(begin, end);
	}

	/**
	 * This method trims all the strings in the given array of strings.
	 *
	 * @param stringArr the string arr
	 * @return the string[]
	 */
	public static String[] trim(String[] stringArr) {
		//FIXME with the current return, this method should return a copy rather than change the argument
		if (stringArr == null) {
			return null;
		}
		for (int i = 0, len = stringArr.length; i < len; i++) {
			stringArr[i] = stringArr[i].trim();
		}
		return stringArr;
	}
}
/**
 *  Modification History:
 *
 *  $Log: StringUtil.java,v $
 *  Revision 1.1  2012/10/01 02:57:34  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/08/15 23:23:54  mwpxp2
 *  Initial
 *
 */
