/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: To be used in persistence layer
 * File: EasePersistenceServiceException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Sep 26, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EasePersistenceServiceException extends EaseServiceLayerException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2143070519733716082L;

	/**
	 * Instantiates a new ease persistence service exception.
	 */
	protected EasePersistenceServiceException() {
		super();
	}

	/**
	 * Instantiates a new ease persistence service exception.
	 *
	 * @param message the message
	 */
	public EasePersistenceServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new ease persistence service exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public EasePersistenceServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new ease persistence service exception.
	 *
	 * @param cause the cause
	 */
	public EasePersistenceServiceException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EasePersistenceServiceException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2011/10/12 20:57:19  mwkkc
 *  Performance Merge
 *
 *  Revision 1.1.2.1  2011/09/27 00:58:01  mwpxp2
 *  Initial
 *
 */
