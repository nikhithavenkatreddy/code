package gov.ca.dmv.ease.fw.process;

import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.activity.impl.Activity;
import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.app.config.IProcessRegistry;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;
import gov.ca.dmv.ease.fw.logging.IAuditable;

import java.io.Serializable;

/**
 * Description: I am minimal interface for Process Context
 * I support accessing the process id, root session context and user context.
 * 
 * File: IProcessContext.java
 * Module:  gov.ca.dmv.ease.fw.process
 * Created: Aug 19, 2009 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IProcessContext extends Serializable, IAuditable {
	boolean hasValidationErrors();

	/**
	 * Gets the current activity.
	 * 
	 * @return the current activity
	 */
	Activity getCurrentActivity();

	/**
	 * Gets the current interaction activity.
	 * 
	 * @return the currentInteractionActivity
	 */
	InteractionActivity getCurrentInteractionActivity();

	/**
	 * Gets the message collector.
	 * 
	 * @return the message collector
	 */
	ErrorMessageCollector getMessageCollector();

	/**
	 * Gets the next activity to be executed by the business process.
	 * 
	 * @return Next activity to execute
	 */
	Activity getNextActivity();

	/**
	 * Gets the previous interaction activity.
	 * 
	 * @return the previousInteractionActivity
	 */
	Activity getPreviousInteractionActivity();

	/**
	 * Gets the process id.
	 * 
	 * @return the process id
	 */
	public String getProcessId();

	/**
	 * Gets the process registry.
	 * 
	 * @return the processRegistry
	 */
	IProcessRegistry getProcessRegistry();

	/**
	 * Gets the session context.
	 * 
	 * @return the session context
	 */
	ISessionContext getRootContext();

	/**
	 * Gets the selected action.
	 * 
	 * @return the selectedAction
	 */
	Action getSelectedAction();

	/**
	 * Gets the user context.
	 * 
	 * @return the user context
	 */
	IUserContext getUserContext();

	/**
	 * Compares this process context to another, using a type comparison. 
	 * @param other
	 * @return boolean
	 */
	boolean isSameProcess(ProcessContext other);

	/**
	 * Sets the validation message object.
	 * 
	 * @param aCollector the new validation message object
	 */
	void setValidationMessageObject(ErrorMessageCollector aCollector);
}
/**
 *  Modification History:
 *
 *  $Log: IProcessContext.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2011/06/10 00:19:08  mwpxp2
 *  Added hasValidationErrors
 *
 *  Revision 1.7  2010/09/01 19:03:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/08/10 22:24:42  mwsec2
 *  isSameProcess method added
 *
 *  Revision 1.5  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/05 02:16:00  mwvkm
 *  Made bulk changes to make the spring's session scoped session-context class make serializable for session restore functionality.
 *
 *  Revision 1.3  2010/03/11 22:21:44  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/23 17:13:59  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.1  2009/10/03 20:23:26  mwpxp2
 *  Moved into fw.process; bulk cleanup
 *
 *  Revision 1.3  2009/09/28 21:23:24  mwrsk
 *  IAuditable & ILoggable moved to framework project
 *
 *  Revision 1.2  2009/09/03 21:09:22  mwpxp2
 *  Added accessors for ErrorMessageCollector
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.4  2009/08/25 18:28:40  mwsmg6
 *  replaced getSessionContext with getRootContext
 *
 *  Revision 1.3  2009/08/20 21:58:57  mwpxp2
 *  Added getSessionContext returning ISessionContext - for TxService
 *
 *  Revision 1.2  2009/08/19 21:39:44  mwpxp2
 *  Added calls to previous empty shell; class decorations
 *
 */
