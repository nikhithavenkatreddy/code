/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.service.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.service.IResponsePromise;

/**
 * Description: I am concrete implementation of IResponsePromise.
 * File: ResponsePromise.java
 * Module:  gov.ca.dmv.ease.fw.service.impl
 * Created: Jul 30, 2009 
 * @author MWYXG1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ResponsePromise implements IResponsePromise {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8448982452544294214L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(1024);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append("...").append(e.getMessage()).append("...").append(
					"]");
			return aBuilder.toString();
		}
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 */
	protected void toStringOn(StringBuilder aBuilder) {
		toStringOn(aBuilder, 0);
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("absoluteExpirationTimestamp",
				absoluteExpirationTimestamp, anIndent, aBuilder);
		outputKeyValue("correlationId", correlationId, anIndent, aBuilder);
		outputKeyValue("errorCollector", errorCollector, anIndent, aBuilder);
		outputKeyValue("expirationTime", expirationTime, anIndent, aBuilder);
		outputKeyValue("originalRequestId", originalRequestId, anIndent,
				aBuilder);
		outputKeyValue("responseClassName", responseClassName, anIndent,
				aBuilder);
		outputKeyValue("sentRequestId", sentRequestId, anIndent, aBuilder);
	}

	private void outputKeyValue(String aKey, Object aValue, int anIndent,
			StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/** Holds Absolute Expiration Timestamp. */
	private long absoluteExpirationTimestamp = UNDEF_LONG;
	/** The correlation id. */
	private String correlationId;
	/** The error collector. */
	private IErrorCollector errorCollector;
	/** Holds Expiration Time. */
	private long expirationTime = UNDEF_LONG;
	/** Holds Original Request Id. */
	private String originalRequestId;
	/** Holds Response Class Name. */
	private String responseClassName;
	/** Holds Sent Request Id. */
	private String sentRequestId;

	/**
	 * Instantiates a new Response Promise.
	 */
	public ResponsePromise() {
		//TODO - limit visibility, fix related tests
		super();
	}

	/**
	 * Instantiates a new Response promise.
	 * 
	 * @param aPromise Promise
	 */
	public ResponsePromise(IResponsePromise aPromise) {
		super();
		setResponseClassName(aPromise.getResponseClassName());
		setSentRequestId(aPromise.getSentRequestId());
		setExpirationTime(aPromise.getExpirationTime());
		setOriginalRequestId(aPromise.getOriginalRequestId());
		setAbsoluteExpirationTimestamp(aPromise
				.getAbsoluteExpirationTimestamp());
		setCorrelationId(aPromise.getCorrelationId());
	}

	/**
	 * Instantiates a new Response promise.
	 * 
	 * @param responseClassName the response class name
	 * @param sentRequestId the sent request id
	 * @param expirationTime the expiration time
	 * @param originalRequestId the original request id
	 * @param absoluteExpirationTimestamp the absolute expiration timestamp
	 */
	public ResponsePromise(String responseClassName, String sentRequestId,
			long expirationTime, String originalRequestId,
			long absoluteExpirationTimestamp) {
		super();
		setResponseClassName(responseClassName);
		setSentRequestId(sentRequestId);
		setExpirationTime(expirationTime);
		setOriginalRequestId(originalRequestId);
		setAbsoluteExpirationTimestamp(absoluteExpirationTimestamp);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getAbsoluteExpirationTimestamp()
	 */
	public long getAbsoluteExpirationTimestamp() {
		return absoluteExpirationTimestamp;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getCorrelationId()
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponse#getErrorCollector()
	 */
	public IErrorCollector getErrorCollector() {
		if (errorCollector == null) {
			setErrorCollector(new ErrorCollector());
		}
		return errorCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getExpirationTime()
	 */
	public long getExpirationTime() {
		return expirationTime;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getOriginalRequestId()
	 */
	public String getOriginalRequestId() {
		return originalRequestId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getResponseClassName()
	 */
	public String getResponseClassName() {
		return responseClassName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#getSentRequestId()
	 */
	public String getSentRequestId() {
		return sentRequestId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponse#hasErrors()
	 */
	public boolean hasErrors() {
		return (errorCollector != null && errorCollector.hasErrors());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponsePromise#hasExpirationStamp()
	 */
	public boolean hasExpirationStamp() {
		return expirationTime != UNDEF_LONG;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponse#register(java.lang.Exception)
	 */
	public void register(Exception e) {
		getErrorCollector().register(e);
	}

	/**
	 * Sets the Absolute Time stamp.
	 * 
	 * @param aStamp the a stamp
	 */
	protected void setAbsoluteExpirationTimestamp(long aStamp) {
		absoluteExpirationTimestamp = aStamp;
	}

	/**
	 * Sets the correlation id.
	 * 
	 * @param anId the new correlation id
	 */
	public void setCorrelationId(String anId) {
		correlationId = anId;
	}

	/**
	 * Sets the error collector.
	 * 
	 * @param errorCollector the new error collector
	 */
	public void setErrorCollector(IErrorCollector errorCollector) {
		this.errorCollector = errorCollector;
	}

	/**
	 * Sets the Expiration Time.
	 * 
	 * @param expirationTime the expirationTime to set
	 */
	protected void setExpirationTime(long expirationTime) {
		this.expirationTime = expirationTime;
	}

	/**
	 * Sets the Original Request Id.
	 * 
	 * @param originalRequestId the originalRequestId to set
	 */
	protected void setOriginalRequestId(String originalRequestId) {
		this.originalRequestId = originalRequestId;
	}

	/**
	 * Sets the Response Class Name.
	 * 
	 * @param responseClassName the responseClassName to set
	 */
	protected void setResponseClassName(String responseClassName) {
		this.responseClassName = responseClassName;
	}

	/**
	 * Sets the Sent Request Id.
	 * 
	 * @param sentRequestId the sentRequestId to set
	 */
	protected void setSentRequestId(String sentRequestId) {
		this.sentRequestId = sentRequestId;
	}

	/**
	 * Validate.
	 * 
	 * @return the i error collector
	 */
	public IErrorCollector validate() {
		IErrorCollector aCollector = new ErrorCollector();
		validateUsing(aCollector);
		return aCollector;
	}

	/**
	 * Validate using.
	 * 
	 * @param aCollector the a collector
	 */
	public void validateUsing(IErrorCollector aCollector) {
		if (absoluteExpirationTimestamp == UNDEF_LONG) {
			aCollector.register(new EaseValidationException(
					"absoluteExpirationTimestamp not set"));
		}
		if (expirationTime == UNDEF_LONG) {
			aCollector.register(new EaseValidationException(
					"expirationTime not set"));
		}
		if (originalRequestId == null) {
			aCollector.register(new EaseValidationException(
					"originalRequestId not set"));
		}
		if (sentRequestId == null) {
			aCollector.register(new EaseValidationException(
					"sentRequestId not set"));
		}
		if (responseClassName == null) {
			aCollector.register(new EaseValidationException(
					"responseClassName not set"));
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ResponsePromise.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/12 05:53:27  mwpxp2
 *  Extended ITreePrintable
 *
 *  Revision 1.4  2010/06/21 23:00:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.22.2  2010/06/20 18:06:57  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/01 20:17:54  mwpxp2
 *  Extended copy constructor to include correlation id; cleaned up
 *
 *  Revision 1.2  2010/06/01 20:14:44  mwpxp2
 *  Moved correlationId up from a subclass
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/23 17:16:57  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.2  2009/10/05 21:37:37  mwpxp2
 *  Unit test fixes
 *
 *  Revision 1.1  2009/10/03 20:26:57  mwpxp2
 *  Moved into fw.service.impl; bulk cleanup
 *
 *  Revision 1.2  2009/09/30 21:07:00  mwhxa2
 *  Implemented validate() and getValidator()
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.6  2009/08/26 18:32:46  mwpxp2
 *  Added boolean hasErrors()
 *
 *  Revision 1.5  2009/08/22 21:37:11  mwpxp2
 *  Added getErrorCollector/0 and register/1 exception
 *
 *  Revision 1.4  2009/08/03 22:08:05  mwhxa2
 *  Made the setters() to be protected.
 *
 *  Revision 1.3  2009/08/03 18:41:46  mwhxa2
 *  Update to include the following attributes expirationTime, originalRequestId, absoluteExpirationTimestamp.
 *
 *  Revision 1.2  2009/07/30 22:51:14  mwyxg1
 *  Added Constructor
 *
 *  Revision 1.1  2009/07/30 21:25:56  mwyxg1
 *  concrete class for IResponsePromise interface
 *
 */
