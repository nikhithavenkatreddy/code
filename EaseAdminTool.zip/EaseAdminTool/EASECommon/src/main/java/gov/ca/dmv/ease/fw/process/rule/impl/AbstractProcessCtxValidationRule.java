/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.process.rule.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.rule.IProcessCtxValidationRule;

/**
 * Description: I am abstract implementation of IProcessValidationRule
 * Concrete validation rule implementations are expected to inherit
 *
 * File: AbstractProcessValidationRule.java
 * Module:  gov.ca.dmv.ease.fw.process.rule.impl
 * Created: Jan 21, 2011
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractProcessCtxValidationRule extends AbstractProcessRule
		implements IProcessCtxValidationRule {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9002011282707276147L;

	/**
	 * Instantiates a new abstract process validation rule.
	 */
	public AbstractProcessCtxValidationRule() {
	}

	/**
	 * Local validate.
	 *
	 * @param processContext the process context
	 * @param aCollector the a collector
	 */
	protected abstract void localValidate(IProcessContext processContext,
			IErrorCollector aCollector);

	/**
	 * Validate.
	 *
	 * @param processContext the process context
	 * @return the i error collector
	 */
	public final IErrorCollector validate(IProcessContext processContext) {
		IErrorCollector aCollector = new ErrorCollector();
		validate(processContext, aCollector);
		return aCollector;
	}

	/**
	 * Validate.
	 *
	 * @param processContext the process context
	 * @param aCollector the a collector
	 */
	public final void validate(IProcessContext processContext,
			IErrorCollector aCollector) {
		validateArguments(processContext);
		validateIfApplicable(processContext);
		localValidate(processContext, aCollector);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractProcessCtxValidationRule.java,v $
 *  Revision 1.1  2012/10/01 02:57:20  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/02/02 03:15:57  mwpxp2
 *  Renamed
 *
 *  Revision 1.3  2011/01/21 23:41:20  mwpxp2
 *  Parameter/imports cleanup for passing collector and context by interface
 *
 *  Revision 1.2  2011/01/21 23:37:31  mwpxp2
 *  Added localValidate/2
 *
 *  Revision 1.1  2011/01/21 23:18:48  mwpxp2
 *  Initial
 *
 */
