/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.error.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Description: This class holds Processing Messages e.g. Validation Messages.
 * File: MessageObject.java
 * Module:  gov.ca.dmv.ease.fw.error.impl
 * Created: Jul 22, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ErrorMessageCollector implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1050417547635691783L;
	/** Holds Validation Messages. */
	private Map <String, ErrorMessage> validationMessageMap = null;
	
	/**
	 * Default Constructor.
	 */
	public ErrorMessageCollector() {
		super();
	}
	
	/**
	 * Instantiates a new error message collector.
	 *
	 * @param errorMessageCollector the error message collector
	 */
	public ErrorMessageCollector(ErrorMessageCollector errorMessageCollector) {
		super();
		copy(errorMessageCollector);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	private void copy(ErrorMessageCollector dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy constructor in " + this);
		}
		getValidationMessages().putAll(dataToCopy.getValidationMessages());
	}
	
	/**
	 * This method handles addition of Validation Message to the Validation Message Map.
	 * 
	 * @param validationAttribute Validated Attribute
	 * @param errorMessage Error Message
	 */
	public void addValidationMessage(String validationAttribute,
			ErrorMessage errorMessage) {
		getValidationMessages().put(validationAttribute, errorMessage);
	}
	
	/**
	 * Contains error.
	 *
	 * @param errorCode the error code
	 * @return true, if successful
	 */
	public boolean containsError(String errorCode) {
		if (validationMessageMap == null || validationMessageMap.isEmpty()) {
			return false;
		}
		else {
			return validationMessageMap.containsKey(errorCode);
		}
	}
	
	/**
	 * Gets the Validation Messages.
	 * Map containing Key as Attribute and value as <code>ErrorMessage</code> containing Error Code and Error Text.
	 * 
	 * @return the Map containing Validation Messages.
	 */
	public Map <String, ErrorMessage> getValidationMessages() {
		if (validationMessageMap == null) {
			setValidationMessages(new HashMap <String, ErrorMessage>());
		}
		return validationMessageMap;
	}
	
	/**
	 * Gets the Flag to Indicate if any Validation Messages Exist.
	 * 
	 * @return the boolean to Indicate if any Validation Messages Exist.
	 */
	public boolean hasValidationErrors() {
		return (validationMessageMap != null && !validationMessageMap.isEmpty());
		//return !getValidationMessages().isEmpty();
	}
	
	/**
	 * Sets the Validation Messages to the Map.
	 *
	 * @param aMap the a map
	 */
	protected void setValidationMessages(Map <String, ErrorMessage> aMap) {
		validationMessageMap = aMap;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		if (!hasValidationErrors()) {
			return "no error messages";
		}
		else {
			StringBuilder aBuilder = new StringBuilder(validationMessageMap
					.size() * 32);
			for (String aKey : validationMessageMap.keySet()) {
				aBuilder.append(validationMessageMap.get(aKey)).append("; ");
			}
			return aBuilder.toString();
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: ErrorMessageCollector.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2012/09/12 00:31:55  mwhys
 *  Added copy constructor. (Defect 7189)
 *
 *  Revision 1.8  2011/06/02 21:35:57  mwpxp2
 *  Added containsError/1; unit tested
 *
 *  Revision 1.7  2011/06/02 19:05:48  mwpxp2
 *  Modified hasValidationErrors to avoid unnecessary map instantiation
 *
 *  Revision 1.6  2011/03/03 20:00:16  mwsyk1
 *  Reverted to version 1.4
 *
 *  Revision 1.4  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.3  2010/05/04 00:20:24  mwvkm
 *  Serializable is added in the implements section.
 *
 *  Revision 1.2  2010/04/29 17:55:01  mwcsj3
 *  Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 *  Revision 1.1.12.1  2010/04/28 19:55:10  mwcsj3
 *  Modified hasValidationErrors method
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/23 17:12:43  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.3  2009/10/05 20:36:34  mwakg
 *  Fixed Nullpointer exception
 *
 *  Revision 1.2  2009/10/04 00:56:38  mwpxp2
 *  Fixed to use lazy instantiation
 *
 *  Revision 1.1  2009/10/03 20:17:07  mwpxp2
 *  Moved to fw.error.impl ; bulk cleanup
 *
 *  Revision 1.2  2009/08/27 19:08:49  mwsmg6
 *  removed dead code
 *
 *  Revision 1.1  2009/08/27 02:24:35  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/26 18:33:13  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.2  2009/08/05 01:40:04  mwbvc
 *  Added isValidationErrors() for UID Error Msg rendering
 *
 *  Revision 1.1  2009/07/29 02:40:22  mwbxp5
 *  Renamed to ErrorMessageCollector and also renamed the methods
 *
 *  Revision 1.1  2009/07/23 21:52:08  mwhxa2
 *  Moving MessageObject to Impl package
 *
 *  Revision 1.2  2009/07/23 20:44:52  mwpxp2
 *  Added fixme
 *
 *  Revision 1.1  2009/07/23 18:45:41  mwhxa2
 *  Adding Message Object class
 *
*/
