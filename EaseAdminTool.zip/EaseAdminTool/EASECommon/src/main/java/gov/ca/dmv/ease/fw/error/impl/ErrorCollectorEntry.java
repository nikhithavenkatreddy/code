/**
 *
 */
package gov.ca.dmv.ease.fw.error.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollectorEntry;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description:  I am concrete implementation of IErrorCollectorEntry
 * File: ErrorCollectorEntry.java
 * Module:  gov.ca.dmv.ease.fw.error.impl
 * Created: Jul 30, 2009
 *
 * @author MWPXP2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ErrorCollectorEntry implements IErrorCollectorEntry {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5955583888332264469L;

	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/** Error Field To Focus */
	private String errorFieldToFocus;
	/** The exception class name. */
	private String exceptionClassName;
	/** The exception message. */
	private String exceptionMessage;
	/** The message parameters. */
	private String[] messageParameters;

	/**
	 * Instantiates a new error collector entry.
	 *
	 * @param e the e
	 */
	public ErrorCollectorEntry(Throwable e) {
		super();
		if (e != null) {
			setExceptionClassName(e.getClass().getName());
			setExceptionMessage(e.getMessage());
			//			Writer aWriter = new StringWriter(1024);
			//			PrintWriter aPrintWriter = new PrintWriter(aWriter, true);
			//			e.printStackTrace(aPrintWriter);
			//			setExceptionMessage(aWriter.toString());
		}
	}

	/**
	 * Instantiates a new error collector entry.
	 *
	 * @param e the e
	 * @param messageParameters the message parameters
	 */
	public ErrorCollectorEntry(Throwable e, String[] messageParameters) {
		super();
		setExceptionClassName(e.getClass().getName());
		setExceptionMessage(e.getMessage());
		setMessageParameters(messageParameters);
	}

	/**
	 * Instantiates a new error collector entry.
	 *
	 * @param e the e
	 * @param messageParameters the message parameters
	 * @param errorFieldToFocus
	 */
	public ErrorCollectorEntry(Throwable e, String[] messageParameters,
			String errorFieldToFocus) {
		super();
		setExceptionClassName(e.getClass().getName());
		setExceptionMessage(e.getMessage());
		setMessageParameters(messageParameters);
		setErrorFieldToFocus(errorFieldToFocus);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ErrorCollectorEntry other = (ErrorCollectorEntry) obj;
		if (exceptionClassName == null) {
			if (other.getExceptionClassName() != null) {
				return false;
			}
		}
		else if (!exceptionClassName.equals(other.getExceptionClassName())) {
			return false;
		}
		if (exceptionMessage == null) {
			if (other.getExceptionMessage() != null) {
				return false;
			}
		}
		else if (!exceptionMessage.equals(other.getExceptionMessage())) {
			return false;
		}
		return true;
	}

	/**
	 * @return the errorFieldToFocus
	 */
	public String getErrorFieldToFocus() {
		return errorFieldToFocus;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorEntry#getExceptionClassName()
	 */
	public String getExceptionClassName() {
		return exceptionClassName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorEntry#getExceptionMessage()
	 */
	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public String[] getMessageParameters() {
		return messageParameters;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasEaseExceptionOfClass(java.lang.Class)
	 */
	public boolean hasEaseExceptionOfClass(
			Class <? extends EaseException> anExceptionClass) {
		if (getExceptionClassName() != null) {
			return getExceptionClassName().equals(anExceptionClass.getName());
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionMessage(java.lang.String)
	 */
	public boolean hasExceptionMessage(String aMessage) {
		if (getExceptionMessage() != null) {
			return getExceptionMessage().equals(aMessage);
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionMessageContaining(java.lang.String)
	 */
	public boolean hasExceptionMessageContaining(String aMessage) {
		if (getExceptionMessage() != null) {
			return getExceptionMessage().contains(aMessage);
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorQuery#hasExceptionOfClass(java.lang.Class)
	 */
	public boolean hasExceptionOfClass(
			Class <? extends Exception> anExceptionClass) {
		if (getExceptionClassName() != null) {
			return getExceptionClassName().equals(anExceptionClass.getName());
		}
		else {
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((exceptionClassName == null) ? 0 : exceptionClassName
						.hashCode());
		result = prime
				* result
				+ ((exceptionMessage == null) ? 0 : exceptionMessage.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.error.IErrorCollectorEntry#hasMessageIncluding(java.lang.String)
	 */
	public boolean hasMessageIncluding(String aMessage) {
		if (exceptionMessage == null) {
			return false;
		}
		else {
			return exceptionMessage.contains(aMessage);
		}
	}

	/**
	 * @param errorFieldToFocus the errorFieldToFocus to set
	 */
	public void setErrorFieldToFocus(String errorFieldToFocus) {
		this.errorFieldToFocus = errorFieldToFocus;
	}

	/**
	 * Sets the exception class name.
	 *
	 * @param exceptionClassName the new exception class name
	 */
	protected void setExceptionClassName(String exceptionClassName) {
		this.exceptionClassName = exceptionClassName;
	}

	/**
	 * Sets the exception message.
	 *
	 * @param exceptionMessage the new exception message
	 */
	protected void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	private void setMessageParameters(String[] messageParameters) {
		this.messageParameters = messageParameters;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(2048);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append("...").append(e.getMessage()).append("...").append(
					"]");
			return aBuilder.toString();
		}
	}

	/**
	 * To string on.
	 *
	 * @param aBuilder the a builder
	 * @param anIndent the an indent
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("exceptionClassName", exceptionClassName, anIndent,
				aBuilder);
		outputKeyValue("exceptionMessage", exceptionMessage, anIndent, aBuilder);
		outputKeyValue("messageParameters", messageParameters, anIndent,
				aBuilder);
		outputKeyValue("errorFieldToFocus", errorFieldToFocus, anIndent,
				aBuilder);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ErrorCollectorEntry.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.13  2011/06/02 22:41:55  mwpxp2
 *  Cleaned up imports
 *
 *  Revision 1.12  2011/03/04 19:57:13  mwpxp2
 *  Reverted to the previous implementation of constructor on exception after debug
 *
 *  Revision 1.11  2011/03/04 03:12:25  mwpxp2
 *  Modified constructor on exception to register stack trace
 *
 *  Revision 1.10  2011/02/04 01:20:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.9  2011/01/21 02:57:52  mwpxp2
 *  Added hasMessageIncluding/1
 *
 *  Revision 1.8  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.7  2010/10/12 18:13:49  mwpxp2
 *  Implemented IErrorCollectorQuery
 *
 *  Revision 1.6  2010/09/29 20:27:39  mwtjc1
 *  Object[] parameters is replaced with String[] messageParameters
 *
 *  Revision 1.5  2010/09/28 18:06:13  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.4  2010/09/01 19:03:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/08/27 23:04:29  mwhys
 *  Overrided equals(Object) and hashCode() methods.
 *
 *  Revision 1.2  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.4  2009/10/23 17:12:11  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.3  2009/10/08 22:17:57  mwpxp2
 *  Modified contructor/1
 *
 *  Revision 1.2  2009/10/04 00:56:09  mwpxp2
 *  Removed unused constructor
 *
 *  Revision 1.1  2009/10/03 20:17:07  mwpxp2
 *  Moved to fw.error.impl ; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/26 22:57:12  mwpxp2
 *  Modified to register Throwable
 *
 *  Revision 1.2  2009/08/26 22:33:30  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.1  2009/07/30 21:40:04  mwpxp2
 *  Initial
 *
 */
