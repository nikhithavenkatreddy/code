/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.reader;

import gov.ca.dmv.ease.fw.format.IFormatConstants;

/**
 * Description: I define constants specific to format reader
 * File: IFormatReaderConstants.java
 * Module:  gov.ca.dmv.ease.fw.format.reader
 * Created: Nov 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IFormatReaderConstants extends IFormatConstants {
	/** The FIEL d_ separator. */
	char FIELD_SEPARATOR = ' '; //SPACE
	/** The NAM e_ delimite r_ left. */
	char NAME_DELIMITER_LEFT = '<';
	/** The NAM e_ delimite r_ right. */
	char NAME_DELIMITER_RIGHT = '>';
	/** The OPTION s_ end. */
	char OPTIONS_END = ')';
	/** The OPTION s_ start. */
	char OPTIONS_START = '(';
	/** The OR. */
	char OR = '|'; //PIPE
	/** The REP s_ end. */
	char REPS_END = '}';
	/** The REP s_ start. */
	char REPS_START = '{';
}
/**
 *  Modification History:
 *
 *  $Log: IFormatReaderConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/12/16 03:19:13  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.1  2010/12/01 01:28:50  mwpxp2
 *  Initial
 *
 */
