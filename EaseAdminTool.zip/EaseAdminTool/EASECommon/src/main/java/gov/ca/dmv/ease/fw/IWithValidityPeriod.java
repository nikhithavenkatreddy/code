package gov.ca.dmv.ease.fw;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: I am interface for objects requiring effective and end dates
 * File: IWithValidityPeriod.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Aug 4, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:26 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IWithValidityPeriod extends Serializable {
	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	Date getEffectiveDate();

	/**
	 * Gets the end date.
	 * 
	 * @return the end date
	 */
	Date getEndDate();

	/**
	 * Checks if is effective now.
	 * 
	 * @return true, if is effective now
	 */
	boolean isEffectiveNow();

	/**
	 * Checks if is effective on.
	 * 
	 * @param aDate the a date
	 * 
	 * @return true, if is effective on
	 */
	boolean isEffectiveOn(Date aDate);
}
/**
 *  Modification History:
 *
 *  $Log: IWithValidityPeriod.java,v $
 *  Revision 1.1  2012/10/01 02:57:26  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/08/04 16:01:34  mwpxp2
 *  Initial
 *
 */
