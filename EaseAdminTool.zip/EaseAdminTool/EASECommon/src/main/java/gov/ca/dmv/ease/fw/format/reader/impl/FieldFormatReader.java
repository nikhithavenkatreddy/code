/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.reader.impl;

import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;
import gov.ca.dmv.ease.fw.format.impl.ExactMultiValueFieldFormat;
import gov.ca.dmv.ease.fw.format.impl.ExactValueFieldFormat;
import gov.ca.dmv.ease.fw.format.impl.MessageDateFormat;
import gov.ca.dmv.ease.fw.format.impl.NumericSpacePrefixed;
import gov.ca.dmv.ease.fw.format.impl.SystemTimeFormat;
import gov.ca.dmv.ease.fw.format.impl.UppercaseAlphaSpaceFilled;
import gov.ca.dmv.ease.fw.format.reader.IFieldFormatReader;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am default implementation of IFieldFormatReader
 * File: FieldFormatReader.java
 * Module:  gov.ca.dmv.ease.fw.format.reader.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class FieldFormatReader extends AbstractFormatReader implements
		IFieldFormatReader {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4094013121601637429L;

	/**
	 * Safe substring.
	 * 
	 * @param aString 
	 * @param aStart 
	 * @param aStop 
	 * 
	 * @return the string
	 */
	private static String safeSubstring(String aString, int aStart, int aStop) {
		if (aString == null) {
			return null;
		}
		int aSize = aString.length();
		if (aStart >= aSize) {
			return null;
		}
		int aSafeStop = Math.min(aSize, aStop);
		try {
			return aString.substring(aStart, aSafeStop);
		}
		catch (StringIndexOutOfBoundsException e) {
			return null;
		}
	}

	/**
	 * Instantiates a new field format reader.
	 */
	public FieldFormatReader() {
		super();
	}

	/**
	 * Creates the multi options field format.
	 * 
	 * @param fieldFormatString 
	 * @param startPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createMultiOptionsFieldFormat(
			String fieldFormatString, int startPos) {
		String aValue = readUpTo(OPTIONS_END, fieldFormatString, 1);
		List <String> allowed = getAllowedValuesFrom(aValue, 0, aValue.length());
		String aName = readOptionalName(fieldFormatString, 0);
		return new ExactMultiValueFieldFormat(startPos, allowed, aName);
	}

	/**
	 * Creates the options field format.
	 * 
	 * @param fieldFormatString 
	 * @param startPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createOptionsFieldFormat(String fieldFormatString,
			int startPos) {
		int orIndex = fieldFormatString.indexOf(OR);
		if (orIndex >= 0) {
			return createMultiOptionsFieldFormat(fieldFormatString, startPos);
		}
		else {
			return createSingleOptionsFieldFormat(fieldFormatString, startPos);
		}
	}

	/**
	 * Creates the single options field format.
	 * 
	 * @param fieldFormatString 
	 * @param startPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createSingleOptionsFieldFormat(
			String fieldFormatString, int startPos) {
		String aValue = readUpTo(OPTIONS_END, fieldFormatString, 1);
		String aName = readOptionalName(fieldFormatString, 0);
		return new ExactValueFieldFormat(startPos, aValue, aName);
	}

	/**
	 * Creates the single typed field format.
	 * 
	 * @param fieldFormatString 
	 * @param startPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createSingleTypedFieldFormat(String fieldFormatString,
			int startPos) {
		String aName = readOptionalName(fieldFormatString, 0);
		return createTypedFieldFormat(fieldFormatString.charAt(0), 1, startPos,
				aName);
	}

	/**
	 * Creates the typed field format.
	 * 
	 * @param aTypeChar 
	 * @param aRepCount 
	 * @param startPos 
	 * @param aName 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createTypedFieldFormat(char aTypeChar, int aRepCount,
			int startPos, String aName) {
		if (aTypeChar == NUM_TYPE) {
			return new NumericSpacePrefixed(startPos, aRepCount, aName);
		}
		if (aTypeChar == ALPHA_TYPE) {
			return new UppercaseAlphaSpaceFilled(startPos, aRepCount, aName);
		}
		//		if (aTypeChar == WHITESPACE_TYPE) {
		//			return new UppercaseAlphaSpaceFilled(aRepCount);
		//		}
		if (aTypeChar == DATE_TYPE) {
			return new MessageDateFormat(startPos, aName);
		}
		if (aTypeChar == TIME_TYPE) {
			return new SystemTimeFormat(startPos, aName);
		}
		//		|| aChar == ALPHA_TYPE || aChar == DATE_TYPE
		//		|| aChar == TIME_TYPE || aChar == WHITESPACE_TYPE;
		throw new FormatValidationException(
				"Unrecognized field type character: \'" + aTypeChar + '\'');
	}

	/**
	 * Creates the typed field format.
	 * 
	 * @param fieldFormatString 
	 * @param startPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat createTypedFieldFormat(String fieldFormatString,
			int startPos) {
		String aLenString = readUpTo(REPS_END, fieldFormatString, 2);
		try {
			Integer aValue = Integer.parseInt(aLenString);
			String aName = readOptionalName(fieldFormatString, 0);
			return createTypedFieldFormat(fieldFormatString.charAt(0), aValue,
					startPos, aName);
		}
		catch (NumberFormatException e) {
			throw new FormatValidationException("Unexpected number format: \""
					+ aLenString + "\"");
		}
	}

	/**
	 * Gets the allowed values from.
	 * 
	 * @param aFieldFormatString 
	 * @param firstIndex 
	 * @param lastIndex 
	 * 
	 * @return the allowed values from
	 */
	private List <String> getAllowedValuesFrom(String aFieldFormatString,
			int firstIndex, int lastIndex) {
		StringBuilder aBuilder = new StringBuilder(16);
		List <String> readValues = new ArrayList <String>();
		char aChar;
		boolean hasOr = false;
		for (int i = firstIndex; i < lastIndex; i++) {
			aChar = aFieldFormatString.charAt(i);
			if (aChar == OR) {
				if (hasOr) {
					readValues.add(aBuilder.toString());
					aBuilder = new StringBuilder(16);
					hasOr = false;
				}
			}
			else {
				hasOr = true;
				aBuilder.append(aChar);
			}
		}
		if (hasOr) {
			readValues.add(aBuilder.toString());
		}
		return readValues;
	}

	/**
	 * Checks if is type char.
	 * 
	 * @param aChar 
	 * 
	 * @return true, if is type char
	 */
	private boolean isTypeChar(char aChar) {
		return aChar == NUM_TYPE || aChar == ALPHA_TYPE || aChar == DATE_TYPE
				|| aChar == TIME_TYPE || aChar == WHITESPACE_TYPE;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.reader.IFieldFormatReader#readFrom(java.lang.String)
	 */
	public IFieldFormat readFrom(String aFieldFormatString) {
		return readFrom(aFieldFormatString, 0);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.reader.IFieldFormatReader#readFrom(java.lang.String, int)
	 */
	public IFieldFormat readFrom(String aFieldFormatString, int startPos) {
		validateNotNull(aFieldFormatString);
		validateNotEmpty(aFieldFormatString);
		int aSize = aFieldFormatString.length();
		int aNameIndex = aFieldFormatString.indexOf(NAME_DELIMITER_LEFT);
		int aFieldTypeLimit;
		if (aNameIndex < 0) {
			aFieldTypeLimit = aSize;
		}
		else {
			aFieldTypeLimit = aNameIndex;
		}
		if (aFieldTypeLimit == 1) {
			return createSingleTypedFieldFormat(aFieldFormatString, startPos);
		}
		else {
			char firstChar = aFieldFormatString.charAt(0);
			if (firstChar == OPTIONS_START) {
				return createOptionsFieldFormat(aFieldFormatString, startPos);
			}
			if (isTypeChar(firstChar)) {
				return createTypedFieldFormat(aFieldFormatString, startPos);
			}
			else {
				throw new FormatValidationException("Cannot parse: \""
						+ aFieldFormatString + "\"");
			}
		}
	}

	/**
	 * Read optional name.
	 * 
	 * @param aFieldFormatString 
	 * @param startPos 
	 * 
	 * @return the string
	 */
	private String readOptionalName(String aFieldFormatString, int startPos) {
		int aNameMarkedStartIndex = aFieldFormatString.indexOf(
				NAME_DELIMITER_LEFT, startPos);
		if (aNameMarkedStartIndex < 0) {
			return null;
		}
		else {
			int aNameMarkedEndIndex = aFieldFormatString.indexOf(
					NAME_DELIMITER_RIGHT, aNameMarkedStartIndex + 1);
			return safeSubstring(aFieldFormatString, aNameMarkedStartIndex + 1,
					aNameMarkedEndIndex);
			//			aFieldFormatString.substring(aNameMarkedStartIndex + 1,
			//					aNameMarkedEndIndex);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldFormatReader.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/16 03:19:33  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.4  2010/11/29 21:44:38  mwpxp2
 *  Fixed reading of the last option in createMultiOptions~
 *
 *  Revision 1.3  2010/11/29 07:45:08  mwpxp2
 *  Re-wrote parsing
 *
 *  Revision 1.2  2010/11/25 00:55:11  mwpxp2
 *  Fixes
 *
 *  Revision 1.1  2010/11/24 20:41:19  mwpxp2
 *  Initial
 *
 */
