/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am generic validation exception
 * File: EaseValidationException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Nov 23, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseUiFieldValidationException extends EaseValidationException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5456930762639031675L;
	
	/**
	 * Instantiates a new ease validation exception.
	 */
	public EaseUiFieldValidationException() {
		super();
	}
	
	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseUiFieldValidationException(String message) {
		super(message);
	}
	
	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseUiFieldValidationException(String message, Throwable cause) {
		super(message, cause);
	}
	
	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseUiFieldValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: EaseUiFieldValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/05/25 17:01:35  mwhys
 *  Removed constructor that takes errorField but does not use it. (Defect 7710)
 *
 *  Revision 1.1  2010/12/03 21:02:04  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 */
