/**
 * 
 */
package gov.ca.dmv.ease.fw.journaling.impl;

import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;
import gov.ca.dmv.ease.tus.logging.po.impl.SysMgmtLog;

import java.util.List;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Description: This abstract log processor supports batch processing of log entries. It provides
 * service execute methods and also a run() method that is intended to run asynchronously. When 
 * used as a replacement for HibernateLogProcessor, concrete implementations of this class will 
 * queue log messages onto a local data structure instead of processing them synchronously to 
 * persistence. The run method, which runs in a long-running worker thread, continually monitors 
 * the queue and collects log messages into batches. When a batch is complete, the run method 
 * calls the execute(List) method which writes the entire batch to persistence.
 * 
 * File: AbstractLogBatchProcessor.java
 * Module:  gov.ca.dmv.ease.fw.journaling.impl
 * Created: Feb 25, 2013 
 * @author MWSEC2  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2013/11/07 23:39:43 $
 * Last Changed By: $Author: mwsec2 $
 */
public abstract class AbstractLogBatchProcessor extends HibernateLogProcessor implements Runnable {
	
	/* The logger for this class (not used in batch processing) */
	private static final Log LOGGER = LogFactory
			.getLog(AbstractLogBatchProcessor.class);
	/* The size of a full batch of log messages */
	private static int WAIT_TIME_SECS = 10;
	/* The size of a full batch of log messages */
	private int batchSize;
	/* A flag to indicate that the logger thread should shutdown */
	private boolean shutdown;
	/* A queue for web threads to pass system management log messages to the logging thread */
	private BlockingQueue<AbstractLog> systemManagementLogQueue;
	
	abstract public void execute(List <AbstractLog> entries);
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.listeners.log.service.ILogProcessor#execute(java.lang.String)
	 */
	@Override
	public void execute(String aMessage) {
		// In the initial implementation, only SytemManagementLog messages are batched
		if (!aMessage.startsWith(SM_PREFIX)) {
			super.execute(aMessage);
		}
		else {
			AbstractLog aLog = createLogEntry(aMessage);
			if (StringUtils.isNotBlank(aLog.getLogEntry())) {
				boolean enqueuedForBatch = getSystemManagementLogQueue().offer(aLog);
				if (!enqueuedForBatch) {
					LOGGER.warn("A log message could not be placed on log queue for async " +
							"processing. The queue is full. The log message will be processed synchronously instead");
					super.execute(aMessage);
				}
				
			}
		}
	}

	/**
	 * @return the systemManagementLogQueue
	 */
	protected BlockingQueue <AbstractLog> getSystemManagementLogQueue() {
		return systemManagementLogQueue;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		List <AbstractLog> batch = new Vector <AbstractLog>(batchSize);
		while (!shutdown) {
			while (batch.size() < batchSize && !shutdown) {
				AbstractLog entry = null;
				// If the queue is not empty, this call will dequeue
				// a message. If the queue is empty, the call will wait 
				// for the specified period for a new message. If no message 
				// is received within that period, the call returns null.			
				try {
					entry = getSystemManagementLogQueue().poll(WAIT_TIME_SECS, TimeUnit.SECONDS);
				}
				catch (InterruptedException e) {
					LOGGER.error(e.getMessage(), e);
				}
				// If no new messages received within the wait period, then break 
				// the inner loop to process the partial batch
				if (entry == null || shutdown) {
					break;
				}
				else {
					batch.add(entry);
				}
			}
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Log batch: " + batch);
			}
			if (!batch.isEmpty() && !shutdown) {
				try {
					execute(batch);
				} catch (Exception e) {
					// We only log the exception without re-throwing it, because re-throwing it will
					// terminate the logger thread.
					LOGGER.error(e.getMessage(), e);
					// In the event of DB problems, to avoid rapid-fire persistence calls, we briefly sleep the thread
					try {
						Thread.sleep(1000); 
					}
					catch (InterruptedException e1) {
						LOGGER.error(e1.getMessage(), e1);
					}
				} finally {
					// We clear the batch even if there was a DB exception. In case the problem was due to a bad message,
					// the messages in the batch that were good will still be written (this is the observed behavior)
					batch.clear();
				}
			} 
		}
		LOGGER.warn("Logging thread is stopping");
	}

	/**
	 * @param batchSize
	 */
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}
	
	/**
	 * @param systemManagementLogQueue
	 */
	public void setSystemManagementLogQueue(BlockingQueue<AbstractLog> systemManagementLogQueue) {
		this.systemManagementLogQueue = systemManagementLogQueue;
	}
	
	/**
	 * To be called by IOC container. 
	 */
	public void shutdown() {
		LOGGER.info("Shutting down...");
		shutdown = true;
		AbstractLog shutdownMessage = new SysMgmtLog();
		boolean shutdownMessageEnqueued = getSystemManagementLogQueue().offer(shutdownMessage);		
		if (!shutdownMessageEnqueued) {
			LOGGER.warn("A shutdown message could not be placed on log queue to stop the logger thread. " +
					"The queue is full. Will try to drain and process stranded log messages");
			List<AbstractLog> strandedLogMessages = new Vector<AbstractLog>();
				getSystemManagementLogQueue().drainTo(strandedLogMessages);
			// now that the queue is drained, this message should go through
			getSystemManagementLogQueue().offer(shutdownMessage);
			/* With Spring 2.5 there is no way to tell Spring to destroy this bean before destroying the 
			 * beans needed for the persistence call, so this attempt to process stranded log messages will 
			 * probably fail. If upgrading to Spring 3.x or above, this can be revisited (SmartLifecycle).
			 */
			execute(strandedLogMessages);
		}
	}
}


/**
 *  Modification History:
 *
 *  $Log: AbstractLogBatchProcessor.java,v $
 *  Revision 1.6  2013/11/07 23:39:43  mwsec2
 *  removed unused local variable
 *
 *  Revision 1.5  2013/11/07 19:37:03  mwsec2
 *  removed unused import
 *
 *  Revision 1.4  2013/11/07 00:23:58  mwsec2
 *  corrected error handling (prevent repeated inserts of a problem batch)
 *
 *  Revision 1.3  2013/09/03 17:58:16  mwsec2
 *  put expensive log statement inside isInfoEnabled block
 *
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2013/02/27 19:57:21  mwsec2
 *  added adstract class and JDBC-version of batch processor
 *
 */