/**
 * 
 */
package gov.ca.dmv.ease.fw.logging.impl;

/**
 * Description: POJO that changes log4j log levels at runtime.
 *  
 * File: LogLevelConfigurator.java
 * Module:  gov.ca.dmv.ease.fw.logging.impl
 * Created: Jul 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:50 $
 * Last Changed By: $Author: mwsec2 $
 */

import gov.ca.dmv.ease.fw.logging.ILogLevelConfigurator;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LogLevelConfigurator implements ILogLevelConfigurator {

	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ILog4JConfigurationMxBean#getLogLevel(java.lang.String)
	 */
	//@Override /* causing compile error (?) */
	public String getLogLevel(String loggerName) {
		String level = "unavailable";
		if (StringUtils.isNotBlank(loggerName)) {
			Logger logger = Logger.getLogger(loggerName);
			if (logger != null) {
				level = logger.getLevel().toString();
			}
		}
		return level;
	}
	
	//@Override
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ILog4JConfigurationMxBean#getLoggers()
	 */
	@SuppressWarnings("unchecked")
	public List <String> getLoggers() {
		List <String> list = new ArrayList <String>();
		for (Enumeration e = LogManager.getCurrentLoggers(); e
				.hasMoreElements();) {
			Logger log = (Logger) e.nextElement();
			if (log.getLevel() != null) {
				list.add(log.getName() + " = " + log.getLevel().toString());
			}
		}
		return list;
	}
	
	//@Override
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ILog4JConfigurationMxBean#setLogLevel(java.lang.String, java.lang.String)
	 */
	public void setLogLevel(String logger, String level) {
		if (StringUtils.isNotBlank(logger) && StringUtils.isNotBlank(level)) {
			Logger log = Logger.getLogger(logger);
			if (log != null) {
				log.setLevel(Level.toLevel(level.toUpperCase()));
			}
		}
	}

}

/**
 *  Modification History:
 *
 *  $Log: LogLevelConfigurator.java,v $
 *  Revision 1.2  2013/06/26 21:59:50  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2012/12/10 23:25:16  mwsec2
 *  LogLevelConfigurator jmx bean added
 *
 *  Revision 1.1.2.1  2012/11/15 20:55:44  mwsec2
 *  added for log4j support
 *
 *  Revision 1.1.6.1  2012/09/04 22:27:03  mwsec2
 *  logging & jmx enhancements
 *
 *  Revision 1.1.4.1  2012/08/01 21:17:49  mwsec2
 *  initial commit to new branch
 *
 *  Revision 1.1.2.1  2012/07/31 17:21:37  mwsec2
 *  checking in logging enhancements
 *
 */