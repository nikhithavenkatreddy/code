/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

/**
 * Description: I represent fields with system time - "HHMMSS"
 * File: SystemTimeFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 28, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SystemTimeFormat extends PatternedFieldFormat {
	/**
	 * @param startPos
	 * @param len
	 * @param name
	 */
	public SystemTimeFormat(int startPos, int len, String name) {
		super(startPos, len, name);
	}

	/** The DEFAUL t_ len. */
	private static int DEFAULT_LEN = 6;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7242360710537422077L;

	/**
	 * Instantiates a new message date format.
	 */
	public SystemTimeFormat() {
		super(UNDEF_POS, DEFAULT_LEN);
	}

	/**
	 * 
	 * 
	 * @param startPos 
	 */
	public SystemTimeFormat(int startPos) {
		super(startPos, DEFAULT_LEN);
	}

	/**
	 * Instantiates a new message date format.
	 * 
	 * @param startPos 
	 * @param aName 
	 */
	public SystemTimeFormat(int startPos, String aName) {
		super(startPos, DEFAULT_LEN, aName);
	}

	/**
	 * Instantiates a new message date format.
	 * 
	 * @param aName 
	 */
	public SystemTimeFormat(String aName) {
		super(UNDEF_POS, DEFAULT_LEN);
		setFieldName(aName);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SystemTimeFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/16 20:25:44  mwpxp2
 *  Cleanup
 *
 *  Revision 1.4  2010/12/16 03:18:29  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.3  2010/12/14 02:46:15  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2010/12/01 02:37:40  mwpxp2
 *  Added constructors
 *
 *  Revision 1.1  2010/11/29 07:42:48  mwpxp2
 *  Initial
 *
 */
