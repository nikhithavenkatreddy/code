/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.reader.impl;

import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.impl.MessageFormat;
import gov.ca.dmv.ease.fw.format.reader.IFieldFormatReader;
import gov.ca.dmv.ease.fw.format.reader.IMessageFormatReader;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am default implementation of IMessageFormatReader
 * File: MessageFormatReader.java
 * Module:  gov.ca.dmv.ease.fw.format.reader.impl
 * Created: Nov 24, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MessageFormatReader extends AbstractFormatReader implements
		IMessageFormatReader {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3836830853976789114L;

	/**
	 * Instantiates a new message format reader.
	 */
	public MessageFormatReader() {
		super();
	}

	/**
	 * Gets the field format reader.
	 * 
	 * @return the field format reader
	 */
	private IFieldFormatReader getFieldFormatReader() {
		return new FieldFormatReader();
	}

	/**
	 * Process field formats.
	 * 
	 * @param formatString 
	 * @param aStartIndex 
	 * @param aFieldFormatList 
	 */
	private void processFieldFormats(String formatString, int aStartIndex,
			List <IFieldFormat> aFieldFormatList) {
		String nextFieldString;
		int localStartIndex = aStartIndex;
		IFieldFormat nextFieldFormat;
		int aFieldPos = 0;
		IFieldFormatReader aFieldReader = getFieldFormatReader();
		while (localStartIndex < formatString.length()) {
			nextFieldString = readUpTo(FIELD_SEPARATOR, formatString,
					localStartIndex, false);
			nextFieldFormat = readNextFieldFormatFrom(nextFieldString,
					aFieldPos, aFieldReader);
			aFieldFormatList.add(nextFieldFormat);
			localStartIndex += nextFieldString.length() + 1;
			if (nextFieldFormat.getFieldName() != null) {
				aFieldPos = aFieldPos + nextFieldFormat.getLength();
			}
			else {
				aFieldPos += nextFieldFormat.getLength();
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.reader.IMessageFormatReader#readFrom(java.lang.String)
	 */
	public IMessageFormat readFrom(String aFormatString) {
		validateNotNull(aFormatString);
		validateNotEmpty(aFormatString);
		List <IFieldFormat> aFieldFormatList = new ArrayList <IFieldFormat>();
		int anIndex = 0;
		processFieldFormats(aFormatString, anIndex, aFieldFormatList);
		return new MessageFormat(aFieldFormatList);
	}

	/**
	 * Read next field format from.
	 * 
	 * @param aString 
	 * @param aStartPos 
	 * 
	 * @return the i field format
	 */
	private IFieldFormat readNextFieldFormatFrom(String aString, int aStartPos,
			IFieldFormatReader aFieldReader) {
		return aFieldReader.readFrom(aString, aStartPos);
	}
}
/**
 *  Modification History:
 *
 *  $Log: MessageFormatReader.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/12/16 03:19:34  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.3  2010/12/01 01:23:26  mwpxp2
 *  Cleanup
 *
 *  Revision 1.2  2010/11/29 07:45:26  mwpxp2
 *  Re-wrote parsing for a modified grammar
 *
 *  Revision 1.1  2010/11/25 00:55:22  mwpxp2
 *  Initial
 *
 */
