/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: This interface holds constants for resource bundles. 
 * File: IResourceBundleConstants.java
 * Module:  gov.ca.dmv.ease.fw.constants
 * Created: Oct 15, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:17 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IResourceBundleConstants {
	/** The Application Listener Resource Bundle. */
	String APPLICATION_LISTENER_NAME_RESOURCE_BUNDLE = "listenerProperties";
	/** The Error Messages Resource Bundle. */
	String ERROR_MESSAGES_RESOURCE_BUNDLE = "messages";
	/** The Panel name Resource bundle. */
	String PANEL_NAMES_RESOURCE_BUNDLE = "panels";
	/** The Panel name Resource bundle. */
	String CDLIS_PDPS_NAMES_RESOURCE_BUNDLE = "cdlisPdpsProperties";
}
/**
 *  Modification History:
 * 
 *  $Log: IResourceBundleConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:17  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2011/06/22 20:52:10  mwyxg1
 *  add cdlis pdps wait time property
 *
 *  Revision 1.6  2011/04/05 00:32:14  mwjxa11
 *  Removed the references to the obsolete resource bundles
 *
 *  Revision 1.5  2010/07/08 02:04:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.16.2  2010/06/20 18:07:00  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/02 17:07:02  mwllh
 *  A constant representing panels names and interaction activity added.
 *
 *  Revision 1.2  2010/03/22 23:29:11  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/11/02 17:11:15  mwhxa2
 *  Updated error msg resource bundle value
 *
 *  Revision 1.1  2009/10/15 22:42:44  mwhxa2
 *  Adding Resource Bundle constants file
 *
*/
