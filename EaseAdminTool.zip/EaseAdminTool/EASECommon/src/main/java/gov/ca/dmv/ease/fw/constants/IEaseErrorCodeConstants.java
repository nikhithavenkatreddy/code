/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.constants;

/**
 * Description: This interface holds constants for EASE error codes. Each code here 
 * is mapped to a message in an applicationMessages property file 
 * File: IEaseErrorCodeConstants.java
 * Module:  gov.ca.dmv.ease.fw.constants
 * Created: Sep 2, 2010 
 * @author MWSEC2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IEaseErrorCodeConstants {
	/** AUTHORIZATION FAILED CODE. */
	//	String AUTHORIZATION_FAILED_CODE = "EASE001";
	/**  PRINTER NOT FOUND CODE */
	//	String PRINTER_NOT_FOUND_CODE = "EASE003";
	/**  INVENTORY ERROR CODE */
	String INVENTORY_ERROR_CODE = "E004";
	/** The ERROR_GETTING_FEE. */
	String ERROR_GETTING_FEE = "E005";
	/** The ISSUANCE_AUTHORIZATION_FAILED_CODE. */
	String ISSUANCE_AUTHORIZATION_FAILED_CODE = "E006";
	/** The PRIMARY_PRINTER_ERROR_CODE. */
	String PRIMARY_PRINTER_ERROR_CODE = "E007";
	/** The ALTERNATIVE_PRINTER_ERROR_CODE. */
	String ALTERNATIVE_PRINTER_ERROR_CODE = "E008";
	/** The PRINTER_ERROR_CODE. */
	String PRINTER_ERROR_CODE = "E009";
	/** INVALID TTC CODE. */
	String INVALID_TTC_CODE = "0175";
	/** The BCTR_ERROR_CODE. */
	String BCTR_ERROR_CODE = "0308";
}
/**
 *  Modification History:
 *
 *  $Log: IEaseErrorCodeConstants.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2012/08/06 16:48:37  mwkfh
 *  readded 1.9 changes
 *
 *  Revision 1.10  2012/08/06 16:46:31  mwkfh
 *  added EASE005
 *
 *  Revision 1.9  2012/07/19 16:44:40  mwhys
 *  Replaced EASE with E per BRC approval and commented unused error codes EASE001, EASE003.
 *
 *  Revision 1.8  2012/07/16 19:56:09  mwhys
 *  Added EASE009 for print error.
 *
 *  Revision 1.7  2012/06/15 23:12:09  mwhys
 *  Added EASE006 for issuance office authorization error.
 *
 *  Revision 1.6  2012/03/08 22:42:31  mwkkc
 *  Added approved 0308 message related to bridge outbound
 *
 *  Revision 1.5  2012/02/23 19:09:04  mwhys
 *  Added EASE009.
 *
 *  Revision 1.4  2011/06/03 02:45:44  mwrka1
 *  added constants
 *
 *  Revision 1.3  2011/06/01 23:02:07  mwrrv3
 *  Added constant for primary printer.
 *
 *  Revision 1.2  2010/11/30 23:33:55  mwrrv3
 *  Changed the error message Code EASE002 to 0175 as per the new requirements -- Amar Bade
 *
 *  Revision 1.1  2010/09/03 16:37:46  mwsec2
 *  initial check in
 *
 */
