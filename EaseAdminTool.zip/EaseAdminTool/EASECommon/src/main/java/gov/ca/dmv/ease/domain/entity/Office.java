/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.domain.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Description: Office class encapsulates the attributes of a field office.
 * File: Office.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Jul 28, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.11 $
 * Last Changed: $Date: 2012/08/01 16:29:27 $
 * Last Changed By: $Author: mwkfh $
 */
public class Office  implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3745256864307127606L;
	// City code detail list each Office enters for lookup or keying aid
	//private List <CityCodeDetail> cityCodeDetails;
	//private List <CodeSetElement> cityCodes;
	/** The control cashier. */
	private List <Employee> controlCashiers;
	/** The bundle log control. */
	private Long currentBundleLogNumber;
	/** The office DL test window number. */
	private String driveTestWindow;
	/** The employee. */
	private List <Employee> employees;
	/** The inventory item. */
	//private InventoryItem inventoryItem;
	/** The managers in an Office. */
	private List <Employee> managers;
	/** The office name. */
	private String name;
	/** The office id. */
	private String officeId;
	//	private List <OfficeWorkdate> officeWorkdates;
	/** The organization. */
	//private List <CustomerOrganization> organizations;
	/** The office phone Number. */
	private String phoneNumber;
	/** The station. */
	//private List <Station> stations;
	/** The transaction. */
	//private List <Transaction> transactions;
	/**The satellite office indicator*/
	private String satelliteOffice;
	/**The main office id if the current office is satellite office*/
	private Long mainOfficeId;
	private Object stations;
	private Object transactions;
	private Object organizations;

	/**
	 * @return the satelliteOffice
	 */
	public String getSatelliteOffice() {
		return satelliteOffice;
	}

	/**
	 * @param satelliteOffice the satelliteOffice to set
	 */
	public void setSatelliteOffice(String satelliteOffice) {
		this.satelliteOffice = satelliteOffice;
	}

	/**
	 * @return the mainOfficeId
	 */
	public Long getMainOfficeId() {
		return mainOfficeId;
	}

	/**
	 * @param mainOfficeId the mainOfficeId to set
	 */
	public void setMainOfficeId(Long mainOfficeId) {
		this.mainOfficeId = mainOfficeId;
	}

	/**
	 * Gets the CityCodeDetail for the specified city code.
	 * 
	 * @return the CityCodeDetail
	 */
	/**public CityCodeDetail getCityCodeDetail(String cityCode) {
		for (CityCodeDetail aCityCodeDetail : cityCodeDetails) {
			if (aCityCodeDetail.getCityCode().equalsIgnoreCase(cityCode)) {
				return aCityCodeDetail;
			}
		}
		return null;
	}*/

	/**
	 * Gets the City Code Details.
	 * 
	 * @return the City Code Details
	 */
	/**public List <CityCodeDetail> getCityCodeDetails() {
		return cityCodeDetails;
	} */

	/**
	 * @return the cityCodes
	 */
	/** public List <CodeSetElement> getCityCodes() {
		return cityCodes;
	} */

	/**
	 * Gets the control cashier.
	 * 
	 * @return the controlCashier
	 */
	public List <Employee> getControlCashiers() {
		return controlCashiers;
	}

	/**
	 * Gets the current bundle log number.
	 * 
	 * @return the currentBundleLogNumber
	 */
	public Long getCurrentBundleLogNumber() {
		return currentBundleLogNumber;
	}

	/**
	 * @return the driveTestWindow
	 */
	public String getDriveTestWindow() {
		return driveTestWindow;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	public Employee getEmployee(String techId) {
		//if (!EaseUtil.isNullOrBlank(techId)) {
			for (Employee employee : getEmployees()) {
				if (techId.equals(employee.getEmployeeTechId())) {
					return employee;
				}
			}
		
		return null;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	public List <Employee> getEmployees() {
		if (employees == null) {
			employees = new ArrayList <Employee>();
		}
		return employees;
	}

	/**
	 * Gets the inventory item.
	 * 
	 * @return the inventory item
	 */
	/**public InventoryItem getInventoryItem() {
		return inventoryItem;
	} */

	/**
	 * Gets the managers.
	 * 
	 * @return the managers
	 */
	public List <Employee> getManagers() {
		return managers;
	}

	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * @return the officeWorkdates
	 */
	/*public List <OfficeWorkdate> getOfficeWorkdates() {
		return officeWorkdates;
	}*/
	/**
	 * Gets the organization.
	 * 
	 * @return the organization
	 */
	/**public List <CustomerOrganization> getOrganizations() {
		return organizations;
	} */

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Gets the station.
	 * 
	 * @return the station
	 */
	/**public List <Station> getStations() {
		return stations;
	}*/

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 */
	/**public List <Transaction> getTransactions() {
		return transactions;
	}

	/**
	 * Returns true if has employees.
	 * 
	 * @return true if employees
	 */
	public boolean hasEmployees() {
		return ((employees != null) && !employees.isEmpty());
	}

	/**
	 * Sets the City Code Details.
	 * 
	 * @param cityCodeDetails the City Code Details to Set
	 */
	/**public void setCityCodeDetails(List <CityCodeDetail> cityCodeDetails) {
		this.cityCodeDetails = cityCodeDetails;
	} */

	/**
	 * @param cityCodes the cityCodes to set
	 */
	/**public void setCityCodes(List <CodeSetElement> cityCodes) {
		this.cityCodes = cityCodes;
	} */

	/**
	 * Sets the control cashier.
	 * 
	 * @param controlCashier the controlCashier to set
	 */
	public void setControlCashiers(List <Employee> controlCashier) {
		this.controlCashiers = controlCashier;
	}

	/**
	 * Sets the current bundle log number.
	 * 
	 * @param currentBundleLogNumber the currentBundleLogNumber to set
	 */
	public void setCurrentBundleLogNumber(Long currentBundleLogNumber) {
		this.currentBundleLogNumber = currentBundleLogNumber;
	}

	/**
	 * @param testWindow the driveTestWindow to set
	 */
	public void setDriveTestWindow(String testWindow) {
		driveTestWindow = testWindow;
	}

	/**
	 * Sets the employee.
	 * 
	 * @param employee the new employee
	 */
	public void setEmployees(List <Employee> employee) {
		this.employees = employee;
	}

	/**
	 * Sets the inventory item.
	 * 
	 * @param inventoryItem the new inventory item
	 */
	/** public void setInventoryItem(InventoryItem inventoryItem) {
		this.inventoryItem = inventoryItem;
	} */

	/**
	 * Sets the managers.
	 * 
	 * @param manager the manager
	 */
	public void setManagers(List <Employee> manager) {
		this.managers = manager;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * @param officeWorkdates the officeWorkdates to set
	 */
	/*public void setOfficeWorkdates(List <OfficeWorkdate> officeWorkdates) {
		this.officeWorkdates = officeWorkdates;
	}*/
	/**
	 * Sets the organization.
	 * 
	 * @param organization the organization to set
	 */
	/** public void setOrganizations(List <CustomerOrganization> organization) {
		this.organizations = organization;
	}
*/
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Sets the station.
	 * 
	 * @param station the new station
	 */
	/** public void setStations(List <Station> station) {
		this.stations = station;
	} */

	/**
	 * Sets the transaction.
	 * 
	 * @param transaction the transaction to set
	 */
	/** public void setTransactions(List <Transaction> transaction) {
		this.transactions = transaction;
	} */

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		return result;
	}
	/**	result = prime * result
				+ ((cityCodeDetails == null) ? 0 : cityCodeDetails.hashCode());
		result = prime * result
				+ ((cityCodes == null) ? 0 : cityCodes.hashCode());
		result = prime * result
				+ ((controlCashiers == null) ? 0 : controlCashiers.hashCode());
		result = prime
				* result
				+ ((currentBundleLogNumber == null) ? 0
						: currentBundleLogNumber.hashCode());
		result = prime * result
				+ ((driveTestWindow == null) ? 0 : driveTestWindow.hashCode());
		result = prime * result
				+ ((employees == null) ? 0 : employees.hashCode());
		result = prime * result
				+ ((inventoryItem == null) ? 0 : inventoryItem.hashCode());
		result = prime * result
				+ ((mainOfficeId == null) ? 0 : mainOfficeId.hashCode());
		result = prime * result
				+ ((managers == null) ? 0 : managers.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());*/
		/*result = prime * result
				+ ((officeWorkdates == null) ? 0 : officeWorkdates.hashCode());
		*/
	/**	result = prime * result
				+ ((organizations == null) ? 0 : organizations.hashCode());
		result = prime * result
				+ ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		result = prime * result
				+ ((satelliteOffice == null) ? 0 : satelliteOffice.hashCode());
		result = prime * result
				+ ((stations == null) ? 0 : stations.hashCode());
		result = prime * result
				+ ((transactions == null) ? 0 : transactions.hashCode());
		return result;
	} */

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Office other = (Office) obj;
Object organizations = null;
		/**		if (cityCodeDetails == null) {
			if (other.cityCodeDetails != null)
				return false;
		}
		else if (!cityCodeDetails.equals(other.cityCodeDetails))
			return false;
		if (cityCodes == null) {
			if (other.cityCodes != null)
				return false;
		}
		else if (!cityCodes.equals(other.cityCodes))
			return false;
		if (controlCashiers == null) {
			if (other.controlCashiers != null)
				return false;
		}
		else if (!controlCashiers.equals(other.controlCashiers))
			return false;
		if (currentBundleLogNumber == null) {
			if (other.currentBundleLogNumber != null)
				return false;
		}
		else if (!currentBundleLogNumber.equals(other.currentBundleLogNumber))
			return false;
		if (driveTestWindow == null) {
			if (other.driveTestWindow != null)
				return false;
		}
		else if (!driveTestWindow.equals(other.driveTestWindow))
			return false;
		if (employees == null) {
			if (other.employees != null)
				return false;
		}
		else if (!employees.equals(other.employees))
			return false;
		if (inventoryItem == null) {
			if (other.inventoryItem != null)
				return false;
		}
		else if (!inventoryItem.equals(other.inventoryItem))
			return false;
		if (mainOfficeId == null) {
			if (other.mainOfficeId != null)
				return false;
		}
		else if (!mainOfficeId.equals(other.mainOfficeId))
			return false;
		if (managers == null) {
			if (other.managers != null)
				return false;
		}
		else if (!managers.equals(other.managers))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		if (officeId == null) {
			if (other.officeId != null)
				return false;
		}
		else if (!officeId.equals(other.officeId))
			return false; */
		/*if (officeWorkdates == null) {
			if (other.officeWorkdates != null)
				return false;
		} else if (!officeWorkdates.equals(other.officeWorkdates))
			return false;*/
		if (organizations == null) {
			if (other.organizations != null)
				return false;
		}
		else if (!organizations.equals(other.organizations))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		}
		else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		if (satelliteOffice == null) {
			if (other.satelliteOffice != null)
				return false;
		}
		else if (!satelliteOffice.equals(other.satelliteOffice))
			return false;
		if (stations == null) {
			if (other.stations != null)
				return false;
		}
		else if (!stations.equals(other.stations))
			return false;
		Object transactions = null;
		if (transactions == null) {
			if (other.transactions != null)
				return false;
		}
		else if (!transactions.equals(other.transactions))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Office.java,v $
 *  Revision 1.11  2012/08/01 16:29:27  mwkfh
 *  added employee methods
 *
 *  Revision 1.10  2011/06/07 22:26:01  mwhys
 *  officeWorkdates filed is commented as it is not used.
 *
 *  Revision 1.9  2011/04/30 01:03:57  mwrrv3
 *  Updated the hasCode and equals method.
 *
 *  Revision 1.8  2011/04/26 20:46:43  mwrrv3
 *  Added 2 new fields satelliteOffice and mainOfficeId in order to support who for screen, defect# 3448.
 *
 *  Revision 1.7  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.6  2010/07/08 18:59:45  mwvxm6
 *  Updated per Bridge code database spec
 *
 *  Revision 1.5  2010/07/07 21:12:39  mwvxm6
 *  Cleanup - Removed unused methods
 *
 *  Revision 1.4  2010/06/28 18:38:16  mwvxm6
 *  Moved Location and Station to Architecture project as it is required by the Print Service
 *
 *  Revision 1.3  2010/06/23 17:54:20  mwvxm6
 *  Attribute rename - driveTestWindow
 *
 *  Revision 1.2  2010/06/22 21:25:33  mwvxm6
 *  Added attributes phoneNumber and dl test window
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.7  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.6  2010/02/04 19:09:28  mwvxm6
 *  Removed Autowired and configured explicitly in spring context xml
 *
 *  Revision 1.5  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.4  2010/01/12 01:09:05  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.3  2010/01/06 00:01:55  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  Intial commit
 *
 *  Revision 1.21  2009/10/11 01:05:12  mwakg
 *  Fixed Unit test cases
 *
 *  Revision 1.20  2009/10/07 01:16:50  mwvxm6
 *  DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *
 *  Revision 1.19  2009/10/03 21:06:30  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.18  2009/09/13 20:45:35  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.17.2.1  2009/09/12 19:08:47  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.17  2009/09/04 01:41:17  mwvxm6
 *  Added CityCodeDetail list to the Office and a helper method to get CityCodeDetail for the specified city code
 *
 *  Revision 1.16  2009/09/02 00:01:22  mwrsk
 *  Updated annotations to use Subselect
 *
 *  Revision 1.15  2009/08/31 00:32:45  mwrsk
 *  code cleanup
 *
 *  Revision 1.14  2009/08/28 22:35:51  mwrsk
 *  Remove employeeWorkdateControl from office
 *
 *  Revision 1.13  2009/08/28 01:24:52  mwvxm6
 *  Updated Annotations per revised DDL
 *
 *  Revision 1.12  2009/08/27 05:39:45  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.11  2009/08/22 23:19:32  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.10  2009/08/20 02:42:35  mwrrv3
 *  Updated the annotations.
 *
 *  Revision 1.9  2009/08/19 18:41:32  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.8  2009/08/06 01:43:44  mwrrv2
 *  updated the table annotations
 *
 *  Revision 1.7  2009/08/05 05:05:46  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.6  2009/08/05 01:08:46  mwrsk
 *  Updated DB column name - from OFFICE_ID to OFFICE_NUM
 *
 *  Revision 1.5  2009/08/05 00:37:13  mwrsk
 *  Changed DB column name from BUSINESS_OBJECT_ID to ID
 *
 *  Revision 1.4  2009/07/30 18:50:41  mwrrv3
 *  Modified the annotation to get the city codes.
 *
 *  Revision 1.3  2009/07/29 17:17:55  mwrrv3
 *  Code formated and added comments.
 *
*/
