/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.format.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.format.FieldValueType;
import gov.ca.dmv.ease.fw.format.IFieldFormat;
import gov.ca.dmv.ease.fw.format.IMessageFormat;
import gov.ca.dmv.ease.fw.format.IPayloadSampleProducer;
import gov.ca.dmv.ease.fw.format.exception.impl.FormatValidationException;
import gov.ca.dmv.ease.fw.format.reader.impl.MessageFormatReader;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am default implementation of IMessageFormat
 * File: MessageFormat.java
 * Module:  gov.ca.dmv.ease.fw.format.impl
 * Created: Nov 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class MessageFormat implements IMessageFormat {
	/** The RANDOMIZER. */
	protected static IPayloadSampleProducer PRODUCER = new PayloadSampleProducer();
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5648685126418212452L;
	/** The fields. */
	private List <IFieldFormat> fields;
	/** The message name. */
	private String messageName;

	/**
	 * Parses the.
	 * 
	 * @param aMessageFormat 
	 * @param aMessagePayload 
	 * 
	 * @return the string
	 */
	public static String parse(String aMessageFormat, String aMessagePayload) {
		MessageFormatReader aReader = new MessageFormatReader();
		IMessageFormat aFormat = aReader.readFrom(aMessageFormat);
		return aFormat.parsePayload(aMessagePayload);
	}

	/**
	 * Instantiates a new message format.
	 */
	public MessageFormat() {
		super();
	}

	/**
	 * Instantiates a new message format.
	 * 
	 * @param aFieldFormatList 
	 */
	public MessageFormat(List <IFieldFormat> aFieldFormatList) {
		super();
		addAll(aFieldFormatList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#add(gov.ca.dmv.ease.fw.format.IFieldFormat)
	 */
	public IMessageFormat add(IFieldFormat aField) {
		getFields().add(aField);
		return this;
	}

	/**
	 * Adds the all.
	 * 
	 * @param fieldFormatList 
	 */
	public void addAll(List <IFieldFormat> fieldFormatList) {
		getFields().addAll(fieldFormatList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#asPatternString()
	 */
	public String asPatternString() {
		StringBuilder aBuilder = new StringBuilder(getLength());
		asPatternString(aBuilder);
		return aBuilder.toString();
	}

	/**
	 * As pattern string.
	 * 
	 * @param aBuilder 
	 */
	protected void asPatternString(StringBuilder aBuilder) {
		char aTypeChar;
		for (IFieldFormat aField : getFields()) {
			aTypeChar = FieldValueType.charForType(aField.getType());
			for (int i = 0; i < aField.getLength(); i++) {
				aBuilder.append(aTypeChar);
			}
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#getFields()
	 */
	public List <IFieldFormat> getFields() {
		if (fields == null) {
			setFields(new ArrayList <IFieldFormat>());
		}
		return fields;
	}

	/**
	 * Gets the size.
	 * 
	 * @return the size
	 */
	public int getLength() {
		if (fields == null || fields.isEmpty()) {
			return 0;
		}
		else {
			IFieldFormat last = getFields().get(getFields().size() - 1);
			return last.getStartPos() + last.getLength();
		}
	}

	/**
	 * 
	 * 
	 * @return the messageName
	 */
	public String getMessageName() {
		return messageName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#getRandomCorrectSample()
	 */
	public String getRandomCorrectSample() {
		StringBuilder aBuilder = new StringBuilder(getLength());
		for (IFieldFormat aField : getFields()) {
			aBuilder.append(aField.getRandomCorrectSample());
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.ISampleProvider#getRandomCorrectSample(int)
	 */
	public String getRandomCorrectSample(int random) {
		StringBuilder aBuilder = new StringBuilder(getLength());
		for (IFieldFormat aField : getFields()) {
			aBuilder.append(aField.getRandomCorrectSample(random));
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#getRandomIncorrectSample()
	 */
	public String getRandomIncorrectSample() {
		StringBuilder aBuilder = new StringBuilder(getLength());
		for (IFieldFormat aField : getFields()) {
			aBuilder.append(aField.getRandomIncorrectSample());
		}
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.ISampleProvider#getRandomIncorrectSample(int)
	 */
	public String getRandomIncorrectSample(int random) {
		StringBuilder aBuilder = new StringBuilder(getLength());
		for (IFieldFormat aField : getFields()) {
			aBuilder.append(aField.getRandomIncorrectSample(random));
		}
		return aBuilder.toString();
	}

	/**
	 * 
	 * 
	 * @param aList 
	 */
	protected void setFields(List <IFieldFormat> aList) {
		fields = aList;
	}

	/**
	 * 
	 * 
	 * @param messageName the messageName to set
	 */
	protected void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32 + getLength());
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		if (getMessageName() != null) {
			aBuilder.append(getMessageName()).append(": ");
		}
		aBuilder.append(" fields: ").append(getFields().size());
		aBuilder.append(" size: ").append(getLength());
		for (IFieldFormat aField : getFields()) {
			aBuilder.append("\n\t").append(aField);
		}
		aBuilder.append(']');
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#validate(java.lang.String)
	 */
	public IErrorCollector validate(String aMessage) {
		IErrorCollector aCollector = new ErrorCollector();
		validate(aMessage, aCollector);
		return aCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#validate(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void validate(String aMessage, IErrorCollector aCollector) {
		if (aMessage == null) {
			aCollector.register(new FormatValidationException(
					"null message payload"));
			return;
		}
		int aSize = aMessage.length();
		if (aSize != getLength()) {
			aCollector.register(new FormatValidationException(
					"Unexpected message payload length; should be: "
							+ getLength() + " is: " + aSize));
		}
		for (IFieldFormat aField : getFields()) {
			aField.validateInMessage(aMessage, aCollector);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IValidationProvider#validateInMessage(java.lang.String, gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	public void validateInMessage(String aMessage, IErrorCollector aCollector) {
		validate(aMessage, aCollector);
	}

	/**
	 * Parses the payload.
	 * 
	 * @param aMessagePayload 
	 * 
	 * @return the string
	 */
	public String parsePayload(String aMessagePayload) {
		StringBuilder aBuilder = new StringBuilder(32 + getLength());
		parsePayload(aMessagePayload, aBuilder);
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.format.IMessageFormat#parsePayload(java.lang.String, java.lang.StringBuilder)
	 */
	public void parsePayload(String aMessagePayload, StringBuilder aBuilder) {
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		if (getMessageName() != null) {
			aBuilder.append(getMessageName()).append(": ");
		}
		aBuilder.append(" fields: ").append(getFields().size());
		aBuilder.append(" size: ").append(getLength());
		int aCount = 1;
		for (IFieldFormat aField : getFields()) {
			aBuilder.append("\n\t").append(aCount).append(". ");
			aField.parsePayload(aMessagePayload, aBuilder);
			aCount++;
		}
		aBuilder.append(']');
	}
}
/**
 *  Modification History:
 *
 *  $Log: MessageFormat.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.11  2010/12/16 03:18:29  mwpxp2
 *  Added support for field name parsing
 *
 *  Revision 1.10  2010/12/01 01:51:34  mwpxp2
 *  Adjusted refs to sample producer
 *
 *  Revision 1.9  2010/12/01 01:37:56  mwpxp2
 *  Added stubs for producing samples
 *
 *  Revision 1.8  2010/12/01 01:22:51  mwpxp2
 *  Adjusted imports for renames/moves
 *
 *  Revision 1.7  2010/11/29 21:44:02  mwpxp2
 *  Extended validate/2 to handle nulls and empties
 *
 *  Revision 1.6  2010/11/29 07:43:33  mwpxp2
 *  Modified toString/0
 *
 *  Revision 1.5  2010/11/25 00:53:41  mwpxp2
 *  Added support for generating samples
 *
 *  Revision 1.4  2010/11/24 20:40:33  mwpxp2
 *  Added messageName
 *
 *  Revision 1.3  2010/11/20 23:08:07  mwpxp2
 *  Added getEndPos/0, asPatternString
 *
 *  Revision 1.2  2010/11/20 22:21:59  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.1  2010/11/20 21:32:12  mwpxp2
 *  Initial
 *
 */
