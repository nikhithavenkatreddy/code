/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.service.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am abstract implementation of IResponse
 * I carry responseCode; errorCollector and validationMessageObject
 * 
 * //TODO - standardize on one collector, not two
 * 
 * File: AbstractResponse.java
 * Module:  gov.ca.dmv.ease.fw.service.impl
 * Created: Jul 9, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractResponse implements IResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6931945192283828011L;
	/** The error collector. */
	private IErrorCollector errorCollector;
	//TODO - response code does not seem to be used anywhere, and it looks like a candidate for removal
	/** The response code. */
	protected int responseCode = UNDEF_INT;
	/** Holds the Instance of Message Object *. */
	private ErrorMessageCollector validationMessageObject = null;

	/**
	 * Instantiates a new abstract response.
	 */
	protected AbstractResponse() {
		super();
	}

	/**
	 * Instantiates a new abstract response.
	 * 
	 * @param ex the ex
	 */
	public AbstractResponse(EaseException ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new abstract response.
	 * 
	 * @param aCollector the a collector
	 */
	protected AbstractResponse(IErrorCollector aCollector) {
		super();
		setErrorCollector(aCollector);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AbstractResponse)) {
			return false;
		}
		AbstractResponse other = (AbstractResponse) obj;
		if (errorCollector == null) {
			if (other.errorCollector != null) {
				return false;
			}
		}
		else if (!errorCollector.equals(other.errorCollector)) {
			return false;
		}
		if (responseCode != other.responseCode) {
			return false;
		}
		if (validationMessageObject == null) {
			if (other.validationMessageObject != null) {
				return false;
			}
		}
		else if (!validationMessageObject.equals(other.validationMessageObject)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponse#getErrorCollector()
	 */
	public IErrorCollector getErrorCollector() {
		if (errorCollector == null) {
			setErrorCollector(new ErrorCollector());
		}
		return errorCollector;
	}

	/**
	 * Gets the response code for service which is executed.
	 * 
	 * @return the responseCode
	 */
	public int getResponseCode() {
		return responseCode;
	}

	/**
	 * Gets the Validation Messages as Message Object <code>MessageObject</code>.
	 * 
	 * @return the validationMessageObject
	 */
	public ErrorMessageCollector getValidationMessageObject() {
		if (validationMessageObject == null) {
			setValidationMessageObject(new ErrorMessageCollector());
		}
		return validationMessageObject;
	}

	/**
	 * Checks for errors.
	 * 
	 * @return true, if successful
	 */
	public boolean hasErrors() {
		if (errorCollector != null && errorCollector.hasErrors()) {
			return true;
		}
		if (validationMessageObject != null
				&& validationMessageObject.hasValidationErrors()) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((errorCollector == null) ? 0 : errorCollector.hashCode());
		result = prime * result + responseCode;
		result = prime
				* result
				+ ((validationMessageObject == null) ? 0
						: validationMessageObject.hashCode());
		return result;
	}

	/**
	 * Output key value.
	 * 
	 * @param aKey 
	 * @param aValue 
	 * @param anIndent 
	 * @param aBuilder 
	 */
	protected void outputKeyValue(String aKey, Object aValue, int anIndent,
			StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.service.IResponse#register(java.lang.Exception)
	 */
	public void register(Exception e) {
		getErrorCollector().register(e);
	}

	/**
	 * Sets the error collector.
	 * 
	 * @param aCollector the new error collector
	 */
	public void setErrorCollector(IErrorCollector aCollector) {
		errorCollector = aCollector;
	}

	/**
	 * Sets the response code.
	 * 
	 * @param responseCode the new response code
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * Sets the Validation Messages.
	 * 
	 * @param validationMessageObject the Validation Messages
	 */
	public void setValidationMessageObject(
			ErrorMessageCollector validationMessageObject) {
		this.validationMessageObject = validationMessageObject;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#simpleToString()
	 */
	public String simpleToString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [");
		aBuilder.append("...").append("]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		try {
			StringBuilder aBuilder = new StringBuilder(1024);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			toStringOn(aBuilder, 1);
			aBuilder.append("\n]");
			return aBuilder.toString();
		}
		catch (Exception e) {
			//System.out.println("Exception: " + e);
			StringBuilder aBuilder = new StringBuilder(64);
			aBuilder.append(getClass().getSimpleName()).append(" [");
			aBuilder.append("...").append(e.getMessage()).append("...").append(
					"]");
			return aBuilder.toString();
		}
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 */
	protected void toStringOn(StringBuilder aBuilder) {
		toStringOn(aBuilder, 0);
	}

	/**
	 * To string on.
	 * 
	 * @param aBuilder 
	 * @param anIndent 
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("responseCode", responseCode, anIndent, aBuilder);
		outputKeyValue("responseCode", responseCode, anIndent, aBuilder);
		outputKeyValue("validationMessageObject", validationMessageObject,
				anIndent, aBuilder);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractResponse.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2010/12/12 05:53:27  mwpxp2
 *  Extended ITreePrintable
 *
 *  Revision 1.8  2010/10/13 00:48:32  mwpxp2
 *  Added hashCode and equals
 *
 *  Revision 1.7  2010/09/01 19:03:19  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/08/31 20:50:29  mwpxp2
 *  Added 1-arg utility constructor on EaseException
 *
 *  Revision 1.5  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.4  2010/06/22 23:20:06  mwpxp2
 *  Added todo marker for responseCode - seems unused and obsolete
 *
 *  Revision 1.3  2010/06/21 23:00:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.22.2  2010/06/20 18:06:57  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/01 20:02:54  mwpxp2
 *  Made abstract per name
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/23 17:15:55  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.2  2009/10/05 23:25:08  mwpxp2
 *  Initialized responseCode
 *
 *  Revision 1.1  2009/10/03 20:26:57  mwpxp2
 *  Moved into fw.service.impl; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:38  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.9  2009/08/26 22:32:47  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.8  2009/08/26 18:29:17  mwpxp2
 *  Added boolean hasErrors()
 *
 *  Revision 1.7  2009/08/22 21:21:04  mwpxp2
 *  Added getErrorCollector/0 and register/1 exception; added footer
 *
 */
