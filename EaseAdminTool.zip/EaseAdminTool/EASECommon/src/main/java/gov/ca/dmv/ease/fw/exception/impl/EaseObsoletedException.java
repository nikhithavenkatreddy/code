/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: My subclasses are marked for obsolesence
 * File: EaseObsoletedException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 23, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class EaseObsoletedException extends EaseException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8154953880439377997L;

	/**
	 * Instantiates a new ease obsoleted exception.
	 */
	public EaseObsoletedException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseObsoletedException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseObsoletedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseObsoletedException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseObsoletedException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/03/23 20:32:03  mwpxp2
 *  Initial
 *
 */
