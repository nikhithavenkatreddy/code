/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.http.request.impl;

import gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Default implementation for IRequestHeaderExtractor
 * File: RequestHeaderExtractor.java
 * Module:  gov.ca.dmv.ease.fw.http.request.impl
 * Created: Apr 4, 2010 
 * @author MWAKG  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class RequestHeaderExtractor implements IRequestHeaderExtractor {
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(RequestHeaderExtractor.class);

	/**
	 * Checks if is null or empty.
	 * 
	 * @param aString the a string
	 * 
	 * @return true, if is null or empty
	 */
	private static boolean isNullOrEmpty(String aString) {
		if (aString == null) {
			return true;
		}
		else {
			if (aString.length() == 0) {
				return true;
			}
		}
		return false;
	}

	/*
	 * Checks if is null or empty or blank.
	 * 
	 * @param aString the a string
	 * 
	 * @return true, if is null or empty or blank
	 *
	private static boolean isNullOrEmptyOrBlank(String aString) {
		if (aString == null) {
			return true;
		}
		else {
			if (aString.length() == 0) {
				return true;
			}
			else {
				return aString.trim().length() == 0;
			}
		}
	}
	*/
	/** The IP Address*/
	private String ipAddress;
	/** The office. */
	private String officeId;
	/** The orig user. */
	private String originalUser;
	/** The racf. */
	private String racfId;
	/** The tech. */
	private String techId;
	/** The username. */
	private String username;
	/** The remote office Id. */
	private String remoteOfficeId;
	/** The issuance officeId-techId-racfId list */
	private String issuanceStr;

	public String getIssuanceStr() {
		return issuanceStr;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getIpAddress()
	 */
	public String getIpAddress() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return ipAddress;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getOffice()
	 */
	public String getOfficeId() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getOrigUser()
	 */
	public String getOriginalUser() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return originalUser;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getRacf()
	 */
	public String getRacfId() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return racfId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getTech()
	 */
	public String getTechId() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return techId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getUsername()
	 */
	public String getUsername() {
		if (isNullOrEmpty(this.remoteOfficeId)) {
			this.setRequestParameters();
		}
		return username;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#getRemoteOfficeId()
	 */
	public String getRemoteOfficeId() {
		if (!this.isValid()) {
			this.setRequestParameters();
		}
		return remoteOfficeId;
	}

	/**
	 * Checks if is valid.
	 * 
	 * @return true, if is valid
	 */
	public boolean isValid() {
		return !isNullOrEmpty(officeId) && !isNullOrEmpty(originalUser)
				&& !isNullOrEmpty(racfId) && !isNullOrEmpty(techId)
				&& !isNullOrEmpty(username) && !isNullOrEmpty(ipAddress);
	}

	/**
	 * Returns the value before the first comma.
	 * 
	 * @param String value
	 */
	private String removeDuplicates(String value) {
		if ((value != null) && (value.indexOf(',') > 0)) {
			value = value.substring(0, value.indexOf(','));
		}
		return value;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#setRequestParameters()
	 */
	public void setRequestParameters() {
		this.setRequestParameters(null);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.http.request.IRequestHeaderExtractor#setRequestParameters(java.util.Map)
	 */
	public void setRequestParameters(Map <String, String> requestParams) {
		FacesContext facesContext;
		if (requestParams == null) {
			facesContext = FacesContext.getCurrentInstance();
			if (facesContext != null) {
				ExternalContext externalContext = facesContext
						.getExternalContext();
				if (externalContext != null) {
					requestParams = externalContext.getRequestHeaderMap();
				}
			}
		}
		LOGGER.debug("Before populating: " + this);
		if (requestParams != null) {
			//Extract username
			username = removeDuplicates(requestParams.get("iv-user"));
			//Extract Racf
			racfId = removeDuplicates(requestParams.get("racf"));
			//Extract Tech ID
			techId = removeDuplicates(requestParams.get("tech_id"));
			//Extract Office ID
			officeId = removeDuplicates(requestParams.get("office_id"));
			//Extract Original User
			originalUser = removeDuplicates(requestParams.get("uid"));
			//Extract Ip Address
			ipAddress = removeDuplicates(requestParams.get("iv-remote-address"));
			//Extract Remote Office Id
			remoteOfficeId = removeDuplicates(requestParams.get("remote_oid"));
			
			issuanceStr = removeDuplicates(requestParams.get("issuance"));
		}
		LOGGER.debug("After populating: " + this);
		
		if (!isValid()) {
			LOGGER.error("invalid: " + this);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(256);
		aBuilder.append("valid: ").append(isValid()).append(SPACER);
		aBuilder.append("username ").append(this.username).append(SPACER);
		aBuilder.append("racf ").append(this.racfId).append(SPACER);
		aBuilder.append("office ").append(this.officeId).append(SPACER);
		aBuilder.append("tech ").append(this.techId).append(SPACER);
		aBuilder.append("origUser ").append(this.originalUser).append(SPACER);
		aBuilder.append("ipAddress ").append(this.ipAddress).append(SPACER);
		aBuilder.append("remoteOffice ").append(this.remoteOfficeId).append(SPACER);
		aBuilder.append("issuance ").append(this.issuanceStr).append(SPACER);
		return aBuilder.toString();
	}
}
/**
 * Modification History:
 * 
 * $Log: RequestHeaderExtractor.java,v $
 * Revision 1.1  2012/10/01 02:57:31  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.14  2012/08/14 20:33:10  mwrrv3
 * Moved SPACER to the interface.
 *
 * Revision 1.13  2012/06/21 01:01:55  mwxxw
 * Remove LOGGER.info().
 *
 * Revision 1.12  2012/06/20 23:08:53  mwxxw
 * Add LOGGER.info().
 *
 * Revision 1.11  2012/05/17 23:37:38  mwxxw
 * Add new header name value pair: issuance.
 *
 * Revision 1.10  2011/03/23 23:47:50  mwyxk
 * Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 * Revision 1.9  2010/11/29 23:04:36  mwxxw
 * Add new field remoteOfficeId for location enforcement service.
 *
 * Revision 1.8  2010/08/27 23:20:22  mwkfh
 * updated toString to not use getters which would recall setParams which in turn called toString again in endless loop.
 *
 * Revision 1.7  2010/07/08 02:04:41  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.6  2010/05/27 21:08:06  mwkkc
 * parsed header to removed duplicate values - mwkfh
 *
 * Revision 1.5  2010/05/25 23:02:35  mwkkc
 * removed duplicate value check - mwkfh
 *
 * Revision 1.4  2010/05/25 22:56:51  mwkkc
 * removed check for duplicates in value - mwkfh
 *
 * Revision 1.3  2010/05/25 22:03:17  mwkkc
 * updated to pull request header values - mwkfh
 *
 * Revision 1.2  2010/04/22 19:25:05  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.1  2010/04/04 18:52:25  mwakg
 * Removed usage of username and using RequestHeaderExtractor
 *
 * 
 */
