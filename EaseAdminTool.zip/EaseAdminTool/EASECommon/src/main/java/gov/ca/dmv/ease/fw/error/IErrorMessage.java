/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.error;

/**
 * Description: This is an Interface that defines Error Message usage.
 * File: IErrorMessage.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Jul 23, 2009 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:16 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IErrorMessage {
	String ERROR_TYPE = "ERROR";
	String INFO_TYPE = "INFO";

	/**
	 * Gets the Error Code.
	 * 
	 * @return Error Code
	 */
	String getErrorCode();

	/**
	 * Gets the Error Text.
	 * 
	 * @return Error Text
	 */
	String getErrorText();

	/**
	 * Gets the message parameters.
	 * 
	 * @return the message parameters
	 */
	String[] getMessageParameters();
	
	String getErrorField();
}
/**
 *  Modification History:
 * 
 *  $Log: IErrorMessage.java,v $
 *  Revision 1.1  2012/10/01 02:57:16  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.5  2010/12/03 21:02:06  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.4  2010/11/17 21:35:19  mwnrk
 *  Code added for Informational Messages
 *
 *  Revision 1.3  2010/09/29 20:32:53  mwtjc1
 *  getMessageParameters() returns String[]
 *
 *  Revision 1.2  2010/09/28 18:06:04  mwtjc1
 *  support for message parameters added
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/03 20:16:41  mwpxp2
 *  Moved to fw.error; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/07/23 18:40:33  mwhxa2
 *  Adding Interface for Error Message usage
 *
*/
