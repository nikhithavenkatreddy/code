/**
 * 
 */
package gov.ca.dmv.ease.fw.journaling.impl;

import gov.ca.dmv.ease.fw.exception.impl.ServiceRequestExecutionException;
import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;

import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This log processor supports batch processing of log entries using the EASE
 * Hibernate-based PersistenceService. 
 * 
 * File: HibernateLogBatchProcessor.java
 * Module:  gov.ca.dmv.ease.fw.journaling.impl
 * Created: Dec 26, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class HibernateLogBatchProcessor extends AbstractLogBatchProcessor {
	/* The logger for this class (not used in batch processing) */
	private static final Log LOGGER = LogFactory
			.getLog(HibernateLogBatchProcessor.class);
	
	/**
	 * Writes a batch of log messages to persistence
	 * 
	 * @param entries
	 */
	@SuppressWarnings("unchecked")
	public void execute(List <AbstractLog> entries) {
		LOGGER.info("Processing batch of log entries. Batch size is " 
				+ (entries != null ? entries.size() : "0"));
		if (entries != null && entries.size() > 0) {
			IPersistenceServiceRequest logRequest = getPersistenceServiceRequestFactory()
					.createMultipleInsertOrUpdateRequest(null,
							(Collection) entries);
			PersistenceServiceResponse aResponse = logRequest.execute();
			if (aResponse.hasErrors()) {
				throw new ServiceRequestExecutionException(aResponse.getErrorCollector()
						.getEntries().get(0).getExceptionMessage());
			}
		}
		LOGGER.info("batch processing of log entries done");
	}	
}
/**
 *  Modification History:
 *
 *  $Log: HibernateLogBatchProcessor.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2013/02/27 19:57:21  mwsec2
 *  added adstract class and JDBC-version of batch processor
 *
 *  Revision 1.1.2.4  2013/01/31 18:00:03  mwsec2
 *  refined error handling
 *
 *  Revision 1.1.2.3  2013/01/23 18:31:02  mwsec2
 *  adding shutdown code to stop the worker thread upon app shutdown
 *
 *  Revision 1.1.2.2  2013/01/17 17:26:50  mwsec2
 *  refinements
 *
 *  Revision 1.1.2.1  2013/01/15 19:45:19  mwsec2
 *  committing async logging classes and associated config file changes
 *
 */
