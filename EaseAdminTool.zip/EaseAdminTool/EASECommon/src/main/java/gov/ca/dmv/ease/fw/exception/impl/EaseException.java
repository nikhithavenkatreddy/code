/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am    root exception class for EASE
 * File: EaseException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Aug 3, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseException extends RuntimeException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6570311279232247848L;

	/**
	 * Instantiates a new ease exception.
	 */
	public EaseException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseException(Throwable cause) {
		super(cause);
	}

	/**
	 * Gets the error code.
	 * 
	 * @return the error code
	 */
	public String getErrorCode() {
		return getMessage();
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/03/23 20:35:37  mwpxp2
 *  Made temporarily concrete.
 *
 *  Revision 1.3  2010/03/23 20:32:24  mwpxp2
 *  Comment/inheritance mods
 *
 *  Revision 1.2  2010/03/22 23:31:21  mwpxp2
 *  Inherits from RuntimeException not ItmException
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/23 17:20:48  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.1  2009/10/03 20:20:10  mwpxp2
 *  Moved into fw.exception.impl; fixed class comment; bulk cleanup
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.1  2009/08/03 23:19:22  mwpxp2
 *  Initial
 *
 */
