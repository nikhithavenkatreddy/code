/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.domain.entity;

import java.util.Date;

import gov.ca.dmv.ease.common.EaseValidationException;

/**
 * Description: This represents the employee work date control details.
 * File: EmployeeWorkdateControl.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Jul 12, 2009
 * @author MWRRV3
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2011/08/01 21:07:55 $
 * Last Changed By: $Author: mwkfh $
 */
public class EmployeeWorkdateControl  implements
		Comparable <EmployeeWorkdateControl> {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3410040368329578133L;
	/** The authorized work date for the employee. */
	private Date authorizedWorkDate;
	/** The current admin sequence number. */
	private Integer currentAdminSequenceNumber;
	// Added per new requirement - manual or travel crew sequence of numbers
	/** The current dl mt sequence number. */
	private Integer currentDlMtSequenceNumber;
	// Original counter or postal sequence of numbers
	/** The current dl sequence number. */
	private Integer currentDlSequenceNumber;
	/** The current vr mt sequence number. */
	private Integer currentVrMtSequenceNumber;
	/** The current vr sequence number. */
	private Integer currentVrSequenceNumber;
	/** The employee for this workdate. */
	private Employee employee;
	// The work date for which an Office is authorized to Work
	/** The office workdate. */
	private OfficeWorkdate officeWorkdate;
	/** The status of the workdate - Active/ Purge etc... */
	private String status;

	private Boolean ToAuthorizeWrkDt;

	public Boolean getToAuthorizeWrkDt() {
		return ToAuthorizeWrkDt;
	}

	public void setToAuthorizeWrkDt(Boolean toAuthorizeWrkDt) {
		ToAuthorizeWrkDt = toAuthorizeWrkDt;
	}
	/**
	 * Default Constructor.
	 */
	public EmployeeWorkdateControl() {
		super();
		initializeWorkDate();
		//office = new Office();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		EmployeeWorkdateControl other = (EmployeeWorkdateControl) obj;
		if (authorizedWorkDate == null) {
			if (other.authorizedWorkDate != null) {
				return false;
			}
		}
		else if (!authorizedWorkDate.equals(other.authorizedWorkDate)) {
			return false;
		}
		if (currentAdminSequenceNumber == null) {
			if (other.currentAdminSequenceNumber != null) {
				return false;
			}
		}
		else if (!currentAdminSequenceNumber
				.equals(other.currentAdminSequenceNumber)) {
			return false;
		}
		if (currentDlMtSequenceNumber == null) {
			if (other.currentDlMtSequenceNumber != null) {
				return false;
			}
		}
		else if (!currentDlMtSequenceNumber
				.equals(other.currentDlMtSequenceNumber)) {
			return false;
		}
		if (currentDlSequenceNumber == null) {
			if (other.currentDlSequenceNumber != null) {
				return false;
			}
		}
		else if (!currentDlSequenceNumber.equals(other.currentDlSequenceNumber)) {
			return false;
		}
		if (currentVrMtSequenceNumber == null) {
			if (other.currentVrMtSequenceNumber != null) {
				return false;
			}
		}
		else if (!currentVrMtSequenceNumber
				.equals(other.currentVrMtSequenceNumber)) {
			return false;
		}
		if (currentVrSequenceNumber == null) {
			if (other.currentVrSequenceNumber != null) {
				return false;
			}
		}
		else if (!currentVrSequenceNumber.equals(other.currentVrSequenceNumber)) {
			return false;
		}
		if (employee == null) {
			if (other.employee != null) {
				return false;
			}
		}
		else if (!employee.equals(other.employee)) {
			return false;
		}
		if (officeWorkdate == null) {
			if (other.officeWorkdate != null) {
				return false;
			}
		}
		else if (!officeWorkdate.equals(other.officeWorkdate)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the authorized work date.
	 * 
	 * @return the authorizedWorkDate
	 */
	public Date getAuthorizedWorkDate() {
		return authorizedWorkDate;
	}

	/**
	 * Gets the current admin sequence number.
	 * 
	 * @return the currentAdminSequenceNumber
	 */
	public Integer getCurrentAdminSequenceNumber() {
		return currentAdminSequenceNumber;
	}

	/**
	 * Gets the current dl mt sequence number.
	 * 
	 * @return the currentDlMtSequenceNumber
	 */
	public Integer getCurrentDlMtSequenceNumber() {
		return currentDlMtSequenceNumber;
	}

	/**
	 * Gets the current dl sequence number.
	 * 
	 * @return the currentDlSequenceNumber
	 */
	public Integer getCurrentDlSequenceNumber() {
		return currentDlSequenceNumber;
	}

	/**
	 * Gets the current vr mt sequence number.
	 * 
	 * @return the currentVrMtSequenceNumber
	 */
	public Integer getCurrentVrMtSequenceNumber() {
		return currentVrMtSequenceNumber;
	}

	/**
	 * Gets the current vr sequence number.
	 * 
	 * @return the currentVrSequenceNumber
	 */
	public Integer getCurrentVrSequenceNumber() {
		return currentVrSequenceNumber;
	}

	/**
	 * Gets the employee.
	 * 
	 * @return the employeeManager
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * Gets the office workdate.
	 * 
	 * @return the office
	 */
	public OfficeWorkdate getOfficeWorkdate() {
		return officeWorkdate;
	}

	/**
	 * Gets the status.
	 * 
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((authorizedWorkDate == null) ? 0 : authorizedWorkDate
						.hashCode());
		result = prime
				* result
				+ ((currentAdminSequenceNumber == null) ? 0
						: currentAdminSequenceNumber.hashCode());
		result = prime
				* result
				+ ((currentDlMtSequenceNumber == null) ? 0
						: currentDlMtSequenceNumber.hashCode());
		result = prime
				* result
				+ ((currentDlSequenceNumber == null) ? 0
						: currentDlSequenceNumber.hashCode());
		result = prime
				* result
				+ ((currentVrMtSequenceNumber == null) ? 0
						: currentVrMtSequenceNumber.hashCode());
		result = prime
				* result
				+ ((currentVrSequenceNumber == null) ? 0
						: currentVrSequenceNumber.hashCode());
		result = prime * result
				+ ((employee == null) ? 0 : employee.hashCode());
		result = prime * result
				+ ((officeWorkdate == null) ? 0 : officeWorkdate.hashCode());
		return result;
	}

	/*	For DL and VR cashier sequence numbers, ACTOP now assigns numbers based on modes. That is, for both
		DL and VR there is a counter or postal sequence of numbers and a manual or travel crew sequence of
		numbers:
	         0001 - 1999  VR COUNTER/POSTAL SEQUENCE NUMBER
	         2001 - 2999  VR MANUAL/TRAVEL CREW SEQUENCE NUMBER
	         3001 - 3999  DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
	         4001 - 4999  ADM311 SEQUENCE NUMBER
	         5001 - 6999  DL COUNTER/POSTAL SEQUENCE NUMBER
	         7001 - 7999  DL MANUAL/TRAVEL CREW SEQUENCE NUMBER
	         8001 - 8999  DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
	         9001 AND UP  RESERVED FOR SYSTEM USE
	*/
	/**
	 * Initialize work date.
	 */
	public void initializeWorkDate() {
		//		currentVrSequenceNumber = 1;
		//		currentVrMtSequenceNumber = 2001;
		//		currentAdminSequenceNumber = 4001;
		//		currentDlSequenceNumber = 5001;
		//		currentDlMtSequenceNumber = 7001;
	}

	/**
	 * Sets the Authorized Work Date.
	 * 
	 * @param authorizedWorkDate the authorizedWorkDate to set
	 */
	public void setAuthorizedWorkDate(Date authorizedWorkDate) {
		this.authorizedWorkDate = authorizedWorkDate;
	}

	/**
	 * Sets the Current Admin Sequence Number.
	 * 
	 * @param currentAdminSequenceNumber the currentAdminSequenceNumber to set
	 */
	public void setCurrentAdminSequenceNumber(Integer currentAdminSequenceNumber) {
		this.currentAdminSequenceNumber = currentAdminSequenceNumber;
	}

	/**
	 * Sets the current dl mt sequence number.
	 * 
	 * @param currentDlMtSequenceNumber the currentDlMtSequenceNumber to set
	 */
	public void setCurrentDlMtSequenceNumber(Integer currentDlMtSequenceNumber) {
		this.currentDlMtSequenceNumber = currentDlMtSequenceNumber;
	}

	/**
	 * Sets the Current DL Sequence Number.
	 * 
	 * @param currentDlSequenceNumber the currentDlSequenceNumber to set
	 */
	public void setCurrentDlSequenceNumber(Integer currentDlSequenceNumber) {
		this.currentDlSequenceNumber = currentDlSequenceNumber;
	}

	/**
	 * Sets the current vr mt sequence number.
	 * 
	 * @param currentVrMtSequenceNumber the currentVrMtSequenceNumber to set
	 */
	public void setCurrentVrMtSequenceNumber(Integer currentVrMtSequenceNumber) {
		this.currentVrMtSequenceNumber = currentVrMtSequenceNumber;
	}

	/**
	 * Sets the Current VR Sequence Number.
	 * 
	 * @param currentVrSequenceNumber the currentVrSequenceNumber to set
	 */
	public void setCurrentVrSequenceNumber(Integer currentVrSequenceNumber) {
		this.currentVrSequenceNumber = currentVrSequenceNumber;
	}

	/**
	 * Sets the Employee Manager.
	 * 
	 * @param employee the employee
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * Sets the Office.
	 * 
	 * @param officeWorkdate the office workdate
	 */
	public void setOfficeWorkdate(OfficeWorkdate officeWorkdate) {
		this.officeWorkdate = officeWorkdate;
	}

	/**
	 * Sets the status.
	 * 
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Compare dates for sorting
	 */
	public int compareTo(EmployeeWorkdateControl employeeWorkdateControl) {
		return employeeWorkdateControl.getCreatedDate().compareTo(
				getCreatedDate());
	}

	private Date getCreatedDate() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Updates the values with new values.
	 * 
	 * @param employeeWorkdateControl
	 */
	public void update(EmployeeWorkdateControl employeeWorkdateControl) {
		if (employeeWorkdateControl == null) {
			throw new EaseValidationException("Cannot update from null object!");
		}
		this.setStatus(employeeWorkdateControl.getStatus());
		this.setCurrentAdminSequenceNumber(employeeWorkdateControl
				.getCurrentAdminSequenceNumber());
		this.setCurrentDlMtSequenceNumber(employeeWorkdateControl
				.getCurrentDlMtSequenceNumber());
		this.setCurrentDlSequenceNumber(employeeWorkdateControl
				.getCurrentDlSequenceNumber());
		this.setCurrentVrMtSequenceNumber(employeeWorkdateControl
				.getCurrentVrMtSequenceNumber());
		this.setCurrentVrSequenceNumber(employeeWorkdateControl
				.getCurrentVrSequenceNumber());
	}
}
/**
 *  Modification History:
 *
 *  $Log: EmployeeWorkdateControl.java,v $
 *  Revision 1.10  2011/08/01 21:07:55  mwkfh
 *  added update
 *
 *  Revision 1.9  2011/08/01 16:43:38  mwkfh
 *  updated sequence numbers in initializeWorkDate
 *
 *  Revision 1.8  2010/12/29 18:45:15  mwkfh
 *  incremented seq no in initializeWorkDate by 1
 *
 *  Revision 1.7  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.5.22.2  2010/12/23 03:13:56  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.6  2010/12/22 19:06:16  mwrrv3
 *  Added implements Comparable<EmployeeWorkdateControl> for sorting the work dates.
 *
 *  Revision 1.5  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.4  2010/07/08 21:01:00  mwvxm6
 *  Updated comments
 *
 *  Revision 1.3  2010/05/19 22:47:23  mwrsk
 *  Added status
 *
 *  Revision 1.2  2010/04/22 17:00:50  mwpxp2
 *  Re-generated equals and hash for all fields; fixed class comment and file log; added missing  javadoc
 *
 *  
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 * 
 * Revision 1.5  2010/04/06 01:13:05  mwvxm6
 * Added OfficeWorkdate (for which an Office is authorized to Work) and updated EmployeeWorkdateControl
 * 
 * Revision 1.4  2010/02/23 22:52:19  mwvxm6
 * Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 * 
 * Revision 1.3  2010/01/28 19:49:20  mwhxa2
 * Updated Java Docs
 * 
 * Revision 1.2  2010/01/04 18:29:08  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. 
 *  Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 * 
 * Revision 1.1  2009/11/23 16:25:16  mwrsk
 * Intial commit
 * 
 * Revision 1.14  2009/10/15 17:14:19  mwrka1
 * Commented unused private variables
 * 
 * Revision 1.13  2009/10/12 18:42:31  mwtjc1
 * currentVRSequenceNumber variable of EmployeeWorkdateControl class is changed to currentVrSequenceNumber to satisfy camel casing requirement
 * 
 * Revision 1.12  2009/10/11 00:26:34  mwakg
 * Fixed unit tests
 * 
 * Revision 1.11  2009/10/07 20:58:01  mwvxm6
 * Initialize call in constructor, Code coverage test
 * 
 * Revision 1.10  2009/10/07 01:16:49  mwvxm6
 * DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 * 
 * Revision 1.9  2009/08/28 21:34:16  mwrsk
 * Updated annotations
 * 
 * Revision 1.8  2009/08/28 01:24:51  mwvxm6
 * Updated Annotations per revised DDL
 * 
 * Revision 1.7  2009/08/27 05:39:44  mwpxp2
 * Bulk cleanup
 * 
 * Revision 1.6  2009/08/22 23:19:32  mwrrv3
 * Implemented equals and hashCode methods.
 * 
 */
