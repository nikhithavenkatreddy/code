/**
 * 
 */
package gov.ca.dmv.ease.fw.logging;

import java.util.List;
/**
 * Description: Interface for beans that change log4j log levels at runtime.
 *  
 * File: LogLevelConfigurator.java
 * Module:  gov.ca.dmv.ease.fw.logging
 * Created: Jul 11, 2012 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */

public interface ILogLevelConfigurator {
	List<String> getLoggers();
	String	getLogLevel(String logger);
	void setLogLevel(String logger, String level);
}
/**
 *  Modification History:
 *
 *  $Log: ILogLevelConfigurator.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.1  2012/12/10 23:25:16  mwsec2
 *  LogLevelConfigurator jmx bean added
 *
 *  Revision 1.1.2.1  2012/11/15 20:55:44  mwsec2
 *  added for log4j support
 *
 *  Revision 1.1.6.1  2012/09/04 22:27:04  mwsec2
 *  logging & jmx enhancements
 *
 *  Revision 1.1.4.1  2012/08/01 21:17:48  mwsec2
 *  initial commit to new branch
 *
 *  Revision 1.1.2.1  2012/07/31 17:21:35  mwsec2
 *  checking in logging enhancements
 *
 */