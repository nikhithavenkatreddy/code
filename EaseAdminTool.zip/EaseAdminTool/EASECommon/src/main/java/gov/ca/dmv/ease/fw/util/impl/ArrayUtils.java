/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.util.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

/**
 * Description: This class contains some frequently used Array utility methods.
 * //FIXME - the class has a number of questionable method and argument names
 * //TODO - examine typing of arguments //FIXME - remove redundant Boolean.TRUE
 * and Boolean.FALSE statements // TODO - since it is used outside the UI layer,
 * this util should be moved out of the UI package branch File: ArrayUtils.java
 * Module: gov.ca.dmv.ease.ui.util.impl Created: Sep 17, 2009
 * 
 * @author MWBVC
 * @version $Revision: 1.2 $ Last Changed: $Date: 2014/09/24 19:52:02 $ Last
 *          Changed By: $Author: mwskh1 $
 */
public class ArrayUtils {
	/** The Constant EMPTY_OBJECT_ARRAY. */
	public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
	/** The Constant EMPTY_STRING_ARRAY. */
	public static final String[] EMPTY_STRING_ARRAY = new String[0];

	/**
	 * Capitalizes the string value.
	 * 
	 * @param input
	 *            String
	 * 
	 * @return the string
	 */
	public static String capitalize(String input) {
		// FIXME the method does something else than its name suggests
		String value = "";
		if (input.length() == 0 || input.trim().equals("")) {
			return input;
		}
		StringTokenizer tokenizer = new StringTokenizer(input);
		while (tokenizer.hasMoreTokens()) {
			String word = tokenizer.nextToken();
			word = String.valueOf(Character.toUpperCase(word.charAt(0)))
					+ word.substring(1).toLowerCase();
			// FIXME use string builder for concatenation in a loop
			value = value + " " + word;
		}
		return value.substring(1);
	}

	/**
	 * This method checks the equality of class and returns the object.
	 * 
	 * @param c1
	 *            the c1
	 * @param c2
	 *            the c2
	 * 
	 * @return the class
	 */
	// @SuppressWarnings("unchecked")
	protected static Class <?> commonClass(Class <?> c1, Class <?> c2) {
		if (c1 == c2) {
			return c1;
		}
		if ((c1 == Object.class) || c1.isAssignableFrom(c2)) {
			return c1;
		}
		if (c2.isAssignableFrom(c1)) {
			return c2;
		}
		if (c1.isPrimitive() || c2.isPrimitive()) {
			throw new IllegalArgumentException("incompatible types " + c1
					+ " and " + c2);
		}
		return Object.class;
	}

	/**
	 * Concatenates two arrays into one. If arr1 is null or empty, returns arr2.
	 * If arr2 is null or empty, returns arr1. May return null if both arrays
	 * are null, or one is empty and the other null.
	 * 
	 * @param toArray
	 *            the to array
	 * @param totalLen
	 *            the total len
	 * @param arrs
	 *            the arrs
	 * 
	 * @return the object
	 */
	protected static Object concat(Object toArray, int totalLen, Object[] arrs) {
		if (totalLen == 0) {
			// Should we allocate an empty array instead?
			return toArray;
		}
		if (totalLen > Array.getLength(toArray)) {
			toArray = Array.newInstance(toArray.getClass().getComponentType(),
					totalLen);
		}
		for (int i = 0, len = arrs.length, offset = 0; i < len; i++) {
			final Object arr = arrs[i];
			if (arr != null) {
				int arrayLen = Array.getLength(arr);
				if (arrayLen > 0) {
					System.arraycopy(arr, 0, toArray, offset, arrayLen);
					offset += arrayLen;
				}
			}
		}
		return toArray;
	}

	/**
	 * Concatenates two arrays into one. If arr1 is null or empty, returns arr2.
	 * If arr2 is null or empty, returns arr1. May return null if both arrays
	 * are null, or one is empty and the other null.
	 * 
	 * @param arr1
	 *            input array
	 * @param arr2
	 *            input array
	 * 
	 * @return Object the concatenated array, elements of arr1 first
	 */
	public static Object concat(Object arr1, Object arr2) {
		int len1 = (arr1 == null) ? (-1) : Array.getLength(arr1);
		if (len1 <= 0) {
			return arr2;
		}
		int len2 = (arr2 == null) ? (-1) : Array.getLength(arr2);
		if (len2 <= 0) {
			return arr1;
		}
		Class <?> commonComponentType = commonClass(arr1.getClass()
				.getComponentType(), arr2.getClass().getComponentType());
		Object newArray = Array.newInstance(commonComponentType, len1 + len2);
		System.arraycopy(arr1, 0, newArray, 0, len1);
		System.arraycopy(arr2, 0, newArray, len1, len2);
		return newArray;
	}

	/**
	 * This method concatenates all the given objects.
	 * 
	 * @param arr1
	 *            the arr1
	 * @param arr2
	 *            the arr2
	 * @param arr3
	 *            the arr3
	 * 
	 * @return the object
	 */
	// TODO remove, since it is not used
	@Deprecated
	public static Object concat(Object arr1, Object arr2, Object arr3) {
		// FIXME - argument names are misleading
		// TODO consider replacing by concat(Object ... elem)
		return concat(new Object[] { arr1, arr2, arr3 });
	}

	/**
	 * This method concatenates all the given objects.
	 * 
	 * @param arr1
	 *            the arr1
	 * @param arr2
	 *            the arr2
	 * @param arr3
	 *            the arr3
	 * @param arr4
	 *            the arr4
	 * 
	 * @return the object
	 */
	// TODO remove, since it is not used
	@Deprecated
	public static Object concat(Object arr1, Object arr2, Object arr3,
			Object arr4) {
		// FIXME - argument names are misleading
		// TODO consider replacing by concat(Object ... elem)
		return concat(new Object[] { arr1, arr2, arr3, arr4 });
	}

	/**
	 * This method concatenates all the given objects.
	 * 
	 * @param arr1
	 *            the arr1
	 * @param arr2
	 *            the arr2
	 * @param arr3
	 *            the arr3
	 * @param arr4
	 *            the arr4
	 * @param arr5
	 *            the arr5
	 * 
	 * @return the object
	 */
	// TODO remove, since it is not used
	@Deprecated
	public static Object concat(Object arr1, Object arr2, Object arr3,
			Object arr4, Object arr5) {
		// FIXME - argument names are misleading
		// TODO consider replacing by concat(Object ... elem)
		return concat(new Object[] { arr1, arr2, arr3, arr4, arr5 });
	}

	/**
	 * Concatenates arrays into one. Any null or empty arrays are ignored. If
	 * all arrays are null or empty, returns null. Elements will be ordered in
	 * the order in which the arrays are supplied.
	 * 
	 * @param arrs
	 *            array of arrays
	 * 
	 * @return the concatenated array
	 */
	public static Object concat(Object[] arrs) {
		int totalLen = 0;
		Class <?> commonComponentType = null;
		for (Object arr : arrs) {
			// skip all null arrays
			if (arr == null) {
				continue;
			}
			int arrayLen = Array.getLength(arr);
			// skip all empty arrays
			if (arrayLen == 0) {
				continue;
			}
			totalLen += arrayLen;
			Class <?> componentType = arr.getClass().getComponentType();
			commonComponentType = (commonComponentType == null) ? componentType
					: commonClass(commonComponentType, componentType);
		}
		if (commonComponentType == null) {
			return null;
		}
		return concat(Array.newInstance(commonComponentType, totalLen),
				totalLen, arrs);
	}

	/**
	 * This method concatenates the given object to the given array of objects.
	 * 
	 * @param toArray
	 *            the to array
	 * @param arrs
	 *            the arrs
	 * 
	 * @return the object
	 */
	// TODO remove, since it is not used
	@Deprecated
	public static Object concatSameType(Object toArray, Object[] arrs) {
		int totalLen = 0;
		for (Object arr : arrs) {
			if (arr != null) {
				totalLen += Array.getLength(arr);
			}
		}
		return concat(toArray, totalLen, arrs);
	}

	/**
	 * Contains.
	 * 
	 * @param valueArray
	 *            the value array
	 * @param array
	 *            the array
	 * 
	 * @return true, if successful
	 */
	public static boolean contains(List <String> valueArray, Object... array) {
		if (EaseUtil.isNotNull(valueArray)) {
			for (String value : valueArray) {
				boolean returnBoolean = contains(array, value);
				if (returnBoolean) {
					return Boolean.TRUE;
				}
			}
		}
		return Boolean.FALSE;
	}

	/**
	 * Contains.
	 * 
	 * @param value
	 *            the value
	 * @param array
	 *            the array
	 * 
	 * @return true, if successful
	 */
	public static boolean contains(Object value, Object... array) {
		// FIXME - 2nd argument name is misleading - although internally, the
		// syntax is treated as array, it means an anumerated list
		return contains(array, value);
	}

	/**
	 * This method checks the availability of an object in the given array of
	 * objects and return boolean value accordingly.
	 * 
	 * @param array
	 *            the array
	 * @param value
	 *            the value
	 * 
	 * @return true, if successful
	 */
	public static boolean contains(Object[] array, Object value) {
		if (array == null || array.length == 0) {
			return false;
		}
		for (Object o : array) {
			if ((o == null && value == null) || (o != null && o.equals(value))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Contains.
	 * 
	 * @param codeSetElementList
	 *            the codeSetElement list
	 * @param array
	 *            the array
	 * 
	 * @return true, if successful
	 */
	public static boolean containsInCodeSetElementList(
			List <CodeSetElement> codeSetElementList, String... array) {
		// FIXME this method does not belong here but rather to CodeSet
		// TODO move to CodeSet and redirect from here, mark as obsolete
		if (!EaseUtil.isNullOrBlank(codeSetElementList)) {
			for (CodeSetElement value : codeSetElementList) {
				if (contains(array, value.getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Contains.
	 * 
	 * @param list1
	 *            the list of T type
	 * @param list2
	 *            the list of T type
	 * 
	 * @return List as a (mathematical) union of two lists
	 */
	public static <T> List <T> union(List <T> list1, List <T> list2) {
		Set <T> set = new HashSet <T>();
		if (!EaseUtil.isNullOrBlank(list1))
			set.addAll(list1);
		if (!EaseUtil.isNullOrBlank(list2))
			set.addAll(list2);
		return new ArrayList <T>(set);
	}

	/**
	 * This method returns the array of strings for a given string and
	 * delimiter.
	 * 
	 * @param str
	 *            the str
	 * @param separator
	 *            the separator
	 * 
	 * @return the string[]
	 */
	@Deprecated
	public static String[] splitShortString(String str, char separator) {
		return StringUtil.splitShortString(str, separator);
		// //FIXME why in Array utils?
		// int len;
		// if (str == null || (len = str.length()) == 0) {
		// return ArrayUtils.EMPTY_STRING_ARRAY;
		// }
		// int lastTokenIndex = 0;
		// // Step 1: how many substrings?
		// // We exchange double scan time for less memory allocation
		// for (int pos = str.indexOf(separator); pos >= 0; pos = str.indexOf(
		// separator, pos + 1)) {
		// lastTokenIndex++;
		// }
		// // Step 2: allocate exact size array
		// String[] list = new String[lastTokenIndex + 1];
		// int oldPos = 0;
		// // Step 3: retrieve substrings
		// for (int pos = str.indexOf(separator), i = 0; pos >= 0; pos = str
		// .indexOf(separator, (oldPos = (pos + 1)))) {
		// list[i++] = substring(str, oldPos, pos);
		// }
		// list[lastTokenIndex] = substring(str, oldPos, len);
		// return list;
	}

	/**
	 * This method returns the substring assuming the second parameter as the
	 * beginning index and the third parameter as ending index.
	 * 
	 * @param str
	 *            the str
	 * @param begin
	 *            the begin
	 * @param end
	 *            the end
	 * 
	 * @return the string
	 */
	@Deprecated
	public static String substring(String str, int begin, int end) {
		return StringUtil.substring(str, begin, end);
		// //FIXME how come this is in _Array_Util?
		// //FIXME what if str is null or empty or end < begin?
		// if (begin == end) {
		// return "";
		// }
		// return str.substring(begin, end);
	}

	/**
	 * This method trims all the strings in the given array of strings.
	 * 
	 * @param strings
	 *            the strings
	 * 
	 * @return the string[]
	 */
	@Deprecated
	public static String[] trim(String[] stringArr) {
		return StringUtil.trim(stringArr);
		// if (strings == null) {
		// return null;
		// }
		// for (int i = 0, len = strings.length; i < len; i++) {
		// strings[i] = strings[i].trim();
		// }
		// return strings;
	}

	/**
	 * Instantiates a new array utils.
	 */
	protected ArrayUtils() {
	}
}
/**
 * Modification History:
 * 
 * $Log: ArrayUtils.java,v $
 * Revision 1.2  2014/09/24 19:52:02  mwskh1
 * AB60 Merge from AB60Branch to the Head
 *
 * Revision 1.1.12.2  2014/07/14 22:14:19  mwnxg5
 * EASE Formatted.
 *
 * Revision 1.1.12.1  2014/07/11 20:50:34  mwnxg5
 * Added method union (of the lists).
 * Revision 1.1 2012/10/01 02:57:34 mwpxp2 Initial -
 * split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930
 * into WS5-compatible project organizations
 * 
 * Revision 1.4 2012/08/25 17:51:42 mwpxp2 Removed raw types in concat/1
 * 
 * Revision 1.3 2012/08/15 23:28:55 mwpxp2 For comaptibility, provided
 * redirections to StringUtil for String-related emthods, but deprecated them
 * 
 * Revision 1.2 2012/08/15 23:19:11 mwpxp2 Soreted members; added fixmes and
 * todos; fixed raw types and removed unneeded suppressions of type warnings
 * 
 * Revision 1.1 2011/06/10 23:13:15 mwyxg1 move ArrayUtils from ui package to fw
 * package
 * 
 * Revision 1.18 2011/03/03 22:56:49 mwsec2 comments added, deprecated
 * annotations added, one fixme removed
 * 
 * Revision 1.17 2011/02/01 18:56:36 mwsec2 todo added
 * 
 * Revision 1.16 2011/01/14 16:42:37 mwhys Added null check for
 * containsInCodeSetElementList().
 * 
 * Revision 1.15 2010/12/30 21:22:21 mwrka1 avoided null pointer exception if
 * array is null
 * 
 * Revision 1.14 2010/12/30 21:16:39 mwrka1 rollback
 * 
 * Revision 1.12 2010/12/07 22:52:40 mwjxa11 refactored
 * containsInCodeSetElementList method again
 * 
 * Revision 1.11 2010/12/07 22:20:16 mwjxa11 refactored
 * containsInCodeSetElementList method
 * 
 * Revision 1.10 2010/12/06 20:27:24 mwpxp2 Added todo, fixmes
 * 
 * Revision 1.9 2010/12/06 18:04:00 mwjxa11 added containsInCodeSetElementList
 * method
 * 
 * Revision 1.8 2010/12/06 01:41:57 mwjxa11 Reverting back to previous version
 * 
 * Revision 1.6 2010/08/19 18:27:34 mwpxp2 Added fixmes. This class has no
 * discernible unit test.
 * 
 * Revision 1.5 2010/03/23 00:04:03 mwpxp2 Fixed file footer
 * 
 */
