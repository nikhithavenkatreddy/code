package gov.ca.dmv.ease.fw.format;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: I define interface to be used for validating payload exemplars against the corresponding format
 * File: IValidationProvider.java
 * Module:  gov.ca.dmv.ease.fw.format
 * Created: Nov 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:19 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IValidationProvider {
	/**
	 * Validate.
	 * 
	 * @param aField 
	 * 
	 * @return the i error collector
	 */
	IErrorCollector validate(String aField);

	/**
	 * Validate.
	 * 
	 * @param aCollector 
	 * @param aField 
	 */
	void validate(String aField, IErrorCollector aCollector);

	/**
	 * Validate in message.
	 * 
	 * @param message 
	 * @param collector 
	 */
	void validateInMessage(String message, IErrorCollector collector);
}
/**
 *  Modification History:
 *
 *  $Log: IValidationProvider.java,v $
 *  Revision 1.1  2012/10/01 02:57:19  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/12/01 01:22:08  mwpxp2
 *  Initial - refactored out from the original interfaces
 *
 */
