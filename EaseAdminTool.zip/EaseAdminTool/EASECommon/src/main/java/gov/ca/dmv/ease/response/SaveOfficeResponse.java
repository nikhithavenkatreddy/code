/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.response;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

/**
 * Description: I am this and that
 * File: SaveOfficeResponse.java
 * Module:  gov.ca.dmv.ease.admintool.response.impl
 * Created: Nov 15, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/11/17 00:19:01 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class SaveOfficeResponse extends AbstractResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6694245060793485156L;

	/**
	 * Default constructor
	 */
	public SaveOfficeResponse() {
		super();
	}

	/**
	 * Constructor that takes an error collector instance
	 * 
	 * @param collector
	 */
	public SaveOfficeResponse(IErrorCollector collector) {
		super(collector);
	}
}
