/**
 * 
 */
package gov.ca.dmv.ease.fw.exception.impl;

/**
 * Description: I am exception to be used in converters
 * File: EaseConverterException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Mar 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseConverterException extends EaseConversionException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3546376223007703313L;

	/**
	 * Instantiates a new ease converter exception.
	 */
	public EaseConverterException() {
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseConverterException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseConverterException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseConverterException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseConverterException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 21:08:30  mwpxp2
 *  Changed super to EaseConversionException
 *
 *  Revision 1.1  2010/03/22 23:30:01  mwpxp2
 *  Initial
 *
 */
