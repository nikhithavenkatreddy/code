/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.response;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;


/**
 * Description: I am this and that
 * File: SaveWorkDateStatusResponse.java
 * Module:  gov.ca.dmv.ease.admintool.response.impl
 * Created: Oct 19, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/19 17:37:01 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class SaveWorkDateStatusResponse extends AbstractResponse {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6999271806585788215L;

	/**
	 * Default constructor
	 */
	public SaveWorkDateStatusResponse() {
		super();
	}

	/**
	 * Constructor that takes an error collector instance
	 * 
	 * @param collector
	 */
	public SaveWorkDateStatusResponse(IErrorCollector collector) {
		super(collector);
	}
}
