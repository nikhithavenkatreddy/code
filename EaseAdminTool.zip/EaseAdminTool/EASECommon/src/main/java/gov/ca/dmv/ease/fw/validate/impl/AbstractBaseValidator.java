/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.fw.validate.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.SpringUtils;
import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.util.List;

/**
 * Description: Abstract superclass for Base validators
 *  //FIXME - there is no reason for this class to exist - its code should be rolled up into AbstractValidator
 *  //FIXME - the public validateValidatable should be removed - it illicitly extends IValidator which is normative wrt public behavior
 *  
 * File: AbstractBaseValidator.java
 * Module:  gov.ca.dmv.ease.fw.validate.impl
 * Created: Aug 27, 2009 
 * @author mwhxa2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractBaseValidator extends AbstractValidator {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1882372610064181858L;
	//FIXME ---move to constants
	protected static final String VALIDATABLE_IS_NULL_ERROR_MESSAGE = "VALIDATABLE_IS_NULL_ERROR_MESSAGE";

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.fw.IValidator#validate(gov.ca.dmv.ease.fw.IValidatable)
	 */
	public static IErrorCollector validate(IValidatable validatable) {
		IErrorCollector aCollector = new ErrorCollector();
		validate(validatable, aCollector);
		return aCollector;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.fw.IValidator#validate(gov.ca.dmv.ease.fw.IValidatable,
	 * gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public static void validate(IValidatable validatable, IErrorCollector collector) {
		try {
			if (isNullOrBlank(validatable)) {
				collector.register(new EaseValidationException(SpringUtils
						.getMessage(VALIDATABLE_IS_NULL_ERROR_MESSAGE)));
			}
			validateValidatable(validatable, collector);
		}
		catch (Exception e) {
			collector.register(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.fw.IValidator#validate(gov.ca.dmv.ease.fw.IValidatable,
	 * gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public static IErrorCollector validate(List <IValidatable> validatables) {
		IErrorCollector aCollector = new ErrorCollector();
		validate(validatables, aCollector);
		return aCollector;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.fw.IValidator#validate(gov.ca.dmv.ease.fw.IValidatable,
	 * gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public static void validate(List <IValidatable> validatables,
			IErrorCollector collector) {
		try {
			if (isNullOrBlank(validatables)) {
				collector.register(new EaseValidationException(SpringUtils
						.getMessage(VALIDATABLE_IS_NULL_ERROR_MESSAGE)));
			}
			else {
				for (IValidatable validatable : validatables) {
					validate(validatable, collector);
				}
			}
		}
		catch (Exception e) {
			collector.register(e);
		}
	}

	/**
	 * Validate validatable.
	 * 
	 * @param validatable the validatable
	 * @param collector the collector
	 */
	public static void validateValidatable(IValidatable validatable,
			IErrorCollector aCollector) {
		//FIXME - the public validateValidatable should be removed - it illicitly extends IValidator which is normative wrt public behavior
		//NOTE: be careful not to introduce stack overflow here 
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractBaseValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:31  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.8  2012/08/14 20:33:27  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.7  2010/09/13 04:39:47  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.6  2010/08/12 22:33:29  mwpxp2
 *  Added fixmes; this class is marked for being rolled into its super
 *
 *  Revision 1.5  2010/05/04 00:55:31  mwpxp2
 *  Imports cleanup
 *
 *  Revision 1.4  2010/03/22 23:35:28  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.3  2010/02/17 20:20:36  mwbxp5
 *  Added a message ---needs to be fixed later
 *
 *  Revision 1.2  2010/02/17 20:17:32  mwbxp5
 *  Moving error messages from Arch project to DL project
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.5  2009/10/27 22:25:43  mwpxp2
 *  Added a note in validateValidatable/2
 *
 *  Revision 1.4  2009/10/23 17:19:02  mwpxp2
 *  Fixed class header, added missing footer, javadoc
 *
 */
