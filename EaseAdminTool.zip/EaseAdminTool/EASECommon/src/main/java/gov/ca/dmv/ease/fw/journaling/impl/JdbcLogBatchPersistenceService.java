/**
 * 
 */
package gov.ca.dmv.ease.fw.journaling.impl;

import gov.ca.dmv.ease.tus.logging.po.impl.AbstractLog;
import gov.ca.dmv.ease.tus.logging.po.impl.SysMgmtLog;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


/**
 * Description: A persistence service for logging to a database, using JDBC support for
 * batch inserts.
 * 
 * File: JdbcLogBatchPersistenceService.java
 * Module:  gov.ca.dmv.ease.fw.journaling.impl
 * Created: Feb 22, 2013 
 * @author MWSEC2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/06/26 21:59:49 $
 * Last Changed By: $Author: mwsec2 $
 */
public class JdbcLogBatchPersistenceService extends JdbcDaoSupport {
	/* The logger for this class (not used in batch processing) */
	private static final Log LOGGER = LogFactory
			.getLog(JdbcLogBatchPersistenceService.class);
	
	private static String sql = "insert into VTDM036U_SYS_MGMT_LOG ("
		+ "LOG_ENTRY, METHOD_CLASS_NME, PRINCIPAL_ID, THREAD_ID, "
		+ "LOG_TSTAMP, OFFICE_ID, TECH_ID, DL_NBR, TRANS_DT, PARTITION_ID) values "
		+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	/**
	 *  
	 * @param entries
	 */
	public void insertSystemManagementBatch(final List <AbstractLog> entries) {
		LOGGER.info("Processing batch of system management log entries. Batch size is " 
				+ (entries != null ? entries.size() : "0"));
		getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
		
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				SysMgmtLog entry = (SysMgmtLog)entries.get(i);
				int j = 1;
				ps.setString(j++, entry.getLogEntry());
				ps.setString(j++, entry.getMethodClassName());
				ps.setString(j++, entry.getPrincipalId());
				ps.setString(j++, entry.getThreadId());
				ps.setTimestamp(j++, new Timestamp(entry.getTimeStamp().getTime()));
				ps.setString(j++, entry.getOfficeId());
				ps.setString(j++, entry.getTechId());
				ps.setString(j++, entry.getDlOrIdNumber());
				ps.setDate(j++, new java.sql.Date(entry.getTransactionDate().getTime()));
				ps.setInt(j++, entry.getPartitionId());
			}
			
			@Override
			public int getBatchSize() {
				return entries.size();
			}
		});
		LOGGER.info("batch processing of log entries done");
	}
}


/**
 *  Modification History:
 *
 *  $Log: JdbcLogBatchPersistenceService.java,v $
 *  Revision 1.2  2013/06/26 21:59:49  mwsec2
 *  WAS7 upgrade merge (includes log4j and batch journaling enhancements)
 *
 *  Revision 1.1.2.3  2013/04/30 16:43:57  mwsec2
 *  removing sys_id field
 *
 *  Revision 1.1.2.2  2013/03/12 16:15:43  mwsec2
 *  removed unneeded columns from insert statement
 *
 *  Revision 1.1.2.1  2013/02/27 19:56:37  mwsec2
 *  initial check in
 *
 */