/**
 * 
 */
package gov.ca.dmv.ease.fw.validate;

import gov.ca.dmv.ease.fw.error.IErrorCollector;

import java.util.List;

/**
 * Description: I am interface for validators operating on IValidatable objects.
 * I validate either directly on the object by returning an instance of IErrorCollector,
 * or use a pre-existing IErrorCollector and add to it if need be.
 * 
 * File: IValidator.java
 * Module:  gov.ca.dmv.ease.bo
 * Created: Jul 30, 2009 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IValidator {
	/**
	 * Validate.
	 * 
	 * @param aValidatable the a validatable
	 * 
	 * @return the i error collector
	 */
	IErrorCollector validate(IValidatable aValidatable);

	/**
	 * Validate.
	 * 
	 * @param aValidatable the a validatable
	 * @param aCollector the a collector
	 */
	void validate(IValidatable aValidatable, IErrorCollector aCollector);

	/**
	 * Validates a list of validatables
	 * @param validatables validatables to be validated
	 * @return IErrorCollector instance
	 */
	public IErrorCollector validate(List <IValidatable> validatables);

	/**
	 * Validates a list of validatables and collects the errors into collector
	 * @param validatables validatables to be validated
	 * @param collector Error collector
	 */
	public void validate(List <IValidatable> validatables,
			IErrorCollector collector);
}
/**
 *  Modification History:
 *
 *  $Log: IValidator.java,v $
 *  Revision 1.1  2012/10/01 02:57:27  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/11 17:19:53  mwpxp2
 *  Cleaned up imports
 *
 *  Revision 1.2  2010/09/04 17:30:02  mwhys
 *  Removed serializable.
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/11 22:51:35  mwakg
 *  Refactored validation framework and its implementing code
 *
 *  Revision 1.1  2009/10/03 20:28:33  mwpxp2
 *  Moved into fw.validate
 *
 *  Revision 1.1  2009/08/27 02:24:36  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/07/30 21:27:21  mwpxp2
 *  Added Serializable as super
 *
 *  Revision 1.1  2009/07/30 21:24:45  mwpxp2
 *  Initial
 *
 */
