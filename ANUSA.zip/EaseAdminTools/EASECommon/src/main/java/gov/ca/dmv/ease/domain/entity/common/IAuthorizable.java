/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.domain.entity.common;

/**
 * Description: I define the interface to authorize users
 *   
 * File: IAuthorizable.java
 * Module:  gov.ca.dmv.ease.fw.auth
 * Created: Nov 21, 2009 
 * @author MWRSK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IAuthorizable {
	/**
	 * Gets the employee tech id.
	 * 
	 * @return the employee tech id
	 */
	String getEmployeeTechId();
}
/**
 *  Modification History:
 * 
 *  $Log: IAuthorizable.java,v $
 *  Revision 1.1  2012/10/01 02:57:23  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:23:57  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:28:48  mwpxp2
 *  Javadoc/cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
*/
