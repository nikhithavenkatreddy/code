package gov.ca.dmv.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.ca.dmv.DAO.ActiveWorkDateDAO;
import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

@Service
public class ActiveWorkDateService {
	
	@Autowired
	private ActiveWorkDateDAO activeWorkDateDAO;
	
	@Transactional
	public List<Vtdm028uOfficeWrkDtCntrl> getOfficeWrkDtControlByOfficeIdAndWorkDate(int officeId, String officeWorkDate){
		return activeWorkDateDAO.getOfficeWrkDtControlByOfficeIdAndWorkDate(officeId, officeWorkDate);
		
	}
	
	@Transactional
	public List<Integer> getAllOfficeIds(){
		return activeWorkDateDAO.getAllOfficeIds();
	}

}
