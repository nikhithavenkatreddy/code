package gov.ca.dmv.DAO;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.ca.dmv.domain.Vtdm027uEmpWrkDtCntrl;
import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

@Repository
public class ActiveWorkDateDAO {

	private static final String AUTHD_WRK_DT_STATUS_S = "S";
	private static final String AUTHD_WRK_DT_STATUS_A = "A";

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<Vtdm028uOfficeWrkDtCntrl> getOfficeWrkDtControlByOfficeIdAndWorkDate(int officeId,
			String officeWorkDate) {
		return entityManager
				.createQuery(
						"from Vtdm028uOfficeWrkDtCntrl owdc where owdc.vssm028uOffice.officeId = :officeId and owdc.createTstamp = :officeWorkDate")
				.setParameter("officeId", officeId).setParameter("authdWrkDtStatus", AUTHD_WRK_DT_STATUS_S)
				.setParameter("officeWorkDate", officeWorkDate).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getAllOffices() {
		// TODO Auto-generated method stub
		return entityManager.createQuery("select officeId from Vssm028uOffice").getResultList();
	}

	public String updateOfficeWorkDateStatus(List<Vtdm028uOfficeWrkDtCntrl> input) {

		String responseMessage = null;
		if (input.size() == 0) {
			responseMessage = "No office work date control records found to update";
			return responseMessage;
		}
		for (Vtdm028uOfficeWrkDtCntrl vtdm028uOfficeWrkDtCntrl : input) {
			vtdm028uOfficeWrkDtCntrl.setAuthdWrkDtStatus(AUTHD_WRK_DT_STATUS_A);
			entityManager.merge(vtdm028uOfficeWrkDtCntrl);
			responseMessage = "Records Has Been Updated";
		}
		return responseMessage;
	}
	
	
	public String updateWorkDateStatus(
			List<Vtdm027uEmpWrkDtCntrl> input, boolean updateBoth) {
		
		String responseMessage = null;
		if (input.size() == 0) {
			responseMessage = "No office work date control records found to update";
			return responseMessage;
		}
		for (Vtdm027uEmpWrkDtCntrl vtdm027uEmpWrkDtCntrl : input) {
			//if ("A".equals(employeeWorkdateControl.getStatus())) {
			vtdm027uEmpWrkDtCntrl.setAuthdWrkDtStatus(AUTHD_WRK_DT_STATUS_A);
			entityManager.merge(vtdm027uEmpWrkDtCntrl);
			//}
		}
		// Also update Office Work Date Records if both should be.
		if (updateBoth) {
			for (Vtdm027uEmpWrkDtCntrl vtdm027uEmpWrkDtCntrl : input) {
				//if ("A".equals(employeeWorkdateControl.getOfficeWorkdate()
				//		.getStatus())) {
				
				Vtdm028uOfficeWrkDtCntrl vtdm028uOfficeWrkDtCntrl = entityManager.find(Vtdm028uOfficeWrkDtCntrl.class, vtdm027uEmpWrkDtCntrl.getOfficeWrkDtCntrlSysid());
				vtdm028uOfficeWrkDtCntrl.setAuthdWrkDtStatus(AUTHD_WRK_DT_STATUS_A);
				entityManager.merge(vtdm028uOfficeWrkDtCntrl);
				responseMessage = "Records Has Been Updated";

				//}
			}
		
		}
		
		return responseMessage;
	}

}
