package gov.ca.dmv.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeScreenController {

	
	@RequestMapping("/home")
	public String view() {
		return "index";
	}
}
