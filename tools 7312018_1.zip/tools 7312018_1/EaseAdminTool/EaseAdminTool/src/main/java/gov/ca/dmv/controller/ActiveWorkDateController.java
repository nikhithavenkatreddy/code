package gov.ca.dmv.controller;

import java.util.Arrays;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import gov.ca.dmv.model.ActiveWorkDateModel;
import gov.ca.dmv.service.ActiveWorkDateService;

@Controller
public class ActiveWorkDateController {

	@Autowired
	private ActiveWorkDateService activeWorkDateService;
	
	@RequestMapping("/activeWorkDate")
	public String view(@ModelAttribute("model") ActiveWorkDateModel activeWorkDateModel) {
		
//		activeWorkDateModel.setOfficeIds(Arrays.asList( "110 Office-110",
//			      "112-office-112",
//			      "113-office-113",
//			      "114-office-114",
//			      "115-office-115",
//			      "116-office-116",
//			      "117-office-117"));
		activeWorkDateModel.setOfficeIds(activeWorkDateService.getAllOfficeIds());
		activeWorkDateModel.setWorkDate(Calendar.getInstance().getTime());
		return "activateWorkDate";
	}
}
