/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial;

/**
 * Description: Enumeration to determine the types of Fee Paid Check. 
 * 
 * File: FeePaidCheckType.java
 * Module:  gov.ca.dmv.ease.bo.financial
 * Created: Mar 4, 2010 
 * @author MWUXB  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:33 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum FeePaidCheckType {
	/** Commercial Driver License Application Fee Paid Check. */
	CDL_APP_FEE_PAID_CHECK,
	/** Commercial Driver License Drive Test Fee Used Check. */
	CDL_DRIVE_TEST_FEE_USED_CHECK,
	/** Fire Fighter Application Fee Paid Check. */
	FIRE_FIGHTER_APP_FEE_PAID_CHECK,
	/** MotorCycle Re-test Fee Due Check. */
	MOTORCYCLE_RETEST_FEE_DUE_CHECK,
	/** MotorCycle Re-test Fee Paid Check. */
	MOTORCYCLE_RETEST_FEE_PAID_CHECK,
	/** MotorCycle Re-test Fee Used Check. */
	MOTORCYCLE_RETEST_FEE_USED_CHECK,
	/** Non Commercial Driver License Re-test Fee Due Check. */
	NON_COMMERCIAL_RETEST_FEE_DUE_CHECK,
	/** Non Commercial Driver License Re-test Fee Paid Check. */
	NON_COMMERCIAL_RETEST_FEE_PAID_CHECK,
	/** Non Commercial Driver License Re-test Fee Used Check. */
	NON_COMMERCIAL_RETEST_FEE_USED_CHECK
}
/**
 *  Modification History:
 * 
 *  $Log: FeePaidCheckType.java,v $
 *  Revision 1.2  2010/07/22 17:50:33  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/04/01 22:23:44  mwhxa2
 *  Added comments
 *
 *  Revision 1.1  2010/03/05 00:50:24  mwuxb
 *  Initial Commit
 *
*/
