/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.app.dl.fee.impl.FeeRateCode;
import gov.ca.dmv.ease.bo.financial.FeeStatusType;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am this and that
 * File: DriverLicenseRateStatus.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Mar 17, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/08/31 22:04:58 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DriverLicenseRateStatus extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2832637400756419414L;
	/** Holds the fee code (Registration fee, RLP fee, Air quality fee etc...) */
	private FeeRateCode feeRatecode;
	/** Fee Status Types - Fee Due, Fee Used, Fee Paid etc*/
	//TODO Do we need to check for Duplicates???
	private List <FeeStatusType> feeStatusTypes;

	/**
	 * Default Constructor. 
	 **/
	public DriverLicenseRateStatus() {
		// Empty Constructor
	}

	/**
	 * This is constructor for Fee Rate Code and associated Fee Status.
	 * 
	 * @param feeRatecode the Fee Rate Code
	 * @param feeStatusType the associated Fee Status for Fee Rate Code.
	 */
	public DriverLicenseRateStatus(FeeRateCode feeRatecode,
			FeeStatusType feeStatusType) {
		this.feeRatecode = feeRatecode;
		this.addFeeStatusType(feeStatusType);
	}

	/**
	 * This is constructor for Fee Rate Code and associated Fee Statuses.
	 * 
	 * @param feeRatecode the Fee Rate Code
	 * @param feeStatusTypes the associated Fee Statuses for Fee Rate Code.
	 */
	public DriverLicenseRateStatus(FeeRateCode feeRatecode,
			List <FeeStatusType> feeStatusTypes) {
		this.feeRatecode = feeRatecode;
		this.feeStatusTypes = feeStatusTypes;
	}

	/**
	 * Adds Fee status to be associated with a Fee Rate Code.
	 * 
	 * @param feeStatusType the feeStatusType to Add
	 */
	public void addFeeStatusType(FeeStatusType feeStatusType) {
		if (EaseUtil.isNullOrBlank(this.feeStatusTypes)) {
			feeStatusTypes = new ArrayList <FeeStatusType>();
		}
		feeStatusTypes.add(feeStatusType);
	}

	/**
	 * Gets the Fee Rate Code.
	 * 
	 * @return the feeRatecode
	 */
	public FeeRateCode getFeeRatecode() {
		return feeRatecode;
	}

	/**
	 * Gets the Fee Statuses associated with a Fee Rate Code.
	 * 
	 * @return the feeStatusTypes
	 */
	public List <FeeStatusType> getFeeStatusTypes() {
		return feeStatusTypes;
	}

	/**
	 * Sets the Fee Rate Code.
	 * 
	 * @param feeRatecode the feeRatecode to set
	 */
	public void setFeeRatecode(FeeRateCode feeRatecode) {
		this.feeRatecode = feeRatecode;
	}

	/**
	 * Sets the Fee Statuses associated with a Fee Rate Code.
	 * 
	 * @param feeStatusTypes the feeStatusTypes to set
	 */
	public void setFeeStatusTypes(List <FeeStatusType> feeStatusTypes) {
		this.feeStatusTypes = feeStatusTypes;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DriverLicenseRateStatus.java,v $
 *  Revision 1.4  2012/08/31 22:04:58  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.3  2010/12/02 00:15:46  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.2  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/03/17 22:59:29  mwhxa2
 *  Created DriverLicenseFee, DriverLicenseRateStatus and updated Fee.
 *
*/
