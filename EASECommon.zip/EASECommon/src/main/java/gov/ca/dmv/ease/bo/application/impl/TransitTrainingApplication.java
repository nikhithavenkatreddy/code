/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;

import java.util.Date;

/**
 * Description: This class captures information pertaining to the receipt payment for a Transit Training document.
 * A Verification of Transit Training Certificate (VTT) is a document issued by the DMV 
 * authorizing a person to drive a transit bus. 
 * The VTT certificate must accompany a valid California Class A or B DL with a PV endorsement.
 * File: TransitTrainingPayment.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class TransitTrainingApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2429850056741045209L;
	/** This represents the current system date in counter mode or the 6 position payment date. */
	private Date dateFeePaid;

	/**
	 * Instantiates a new application.
	 */
	public TransitTrainingApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the dateFeePaid
	 */
	public Date getDateFeePaid() {
		return dateFeePaid;
	}

	/**
	 * @param dateFeePaid the dateFeePaid to set
	 */
	public void setDateFeePaid(Date dateFeePaid) {
		this.dateFeePaid = dateFeePaid;
	}
}
