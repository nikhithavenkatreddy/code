/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator.impl;

/**
 * Description: I am Locator Helper.
 * File: DummyLocatorHelper.java
 * Module:  gov.ca.dmv.ease.bo.locator.impl
 * Created: Jan 28, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DummyLocatorHelper {
	/**
	 * Get the full line address.
	 * 
	 * @return the Full Address
	 */
	public static String getFullAddress(Address address) {
		StringBuilder stringBuilder = new StringBuilder();
		String fullLineAddr = "";
		if (address.getLine1() != null) {
			stringBuilder.append(address.getLine1().trim()).append(" ");
		}
		if (address.getLine2() != null) {
			stringBuilder.append(address.getLine2().trim()).append(" ");
		}
		fullLineAddr = stringBuilder.toString();
		// Check for the length of the address and if address length is > 0 then
		// remove the space at the end of the address
		if (fullLineAddr.length() > 0) {
			fullLineAddr = fullLineAddr.substring(0, fullLineAddr.length() - 1);
		}
		return fullLineAddr;
	}

	/**
	 * This method check is the Addresses are same.
	 * 
	 * @param address the compare Address
	 * @param residenceAddress the compare to Address
	 * @return true if both are same Addresses
	 */
	public static boolean isSameAs(Address address, Address residenceAddress) {
		if (address.getCity() == null) {
			if (residenceAddress.getCity() != null) {
				return false;
			}
		}
		else if (!address.getCity().equals(residenceAddress.getCity())) {
			return false;
		}
		if (address.getCounty() == null) {
			if (residenceAddress.getCounty() != null) {
				return false;
			}
		}
		else if (!address.getCounty().equals(residenceAddress.getCounty())) {
			return false;
		}
		if (address.getLine1() == null) {
			if (residenceAddress.getLine1() != null) {
				return false;
			}
		}
		else if (!address.getLine1().equals(residenceAddress.getLine1())) {
			return false;
		}
		if (address.getLine2() == null) {
			if (residenceAddress.getLine2() != null) {
				return false;
			}
		}
		else if (!address.getLine2().equals(residenceAddress.getLine2())) {
			return false;
		}
		if (address.getState() == null) {
			if (residenceAddress.getState() != null) {
				return false;
			}
		}
		else if (!address.getState().equals(residenceAddress.getState())) {
			return false;
		}
		return true;
	}
}
