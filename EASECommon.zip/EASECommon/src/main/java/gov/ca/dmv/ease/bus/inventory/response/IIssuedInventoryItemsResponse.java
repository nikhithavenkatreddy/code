/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;

import java.util.List;

/**
 * Description: I am interface for responses from inventory for requests 
 * File: IIssuedInventoryItemsResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response
 * Created: Dec 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/12/13 20:48:20 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IIssuedInventoryItemsResponse extends
		IInventoryServiceResponse {
	/**
	 * Gets the number of available inventory.
	 * 
	 * @return the available inventory count
	 */
	int getAvailableInventoryCount();

	/**
	 * Gets the item list.
	 * 
	 * @return the item list
	 */
	List <IInventoryItem> getIssuedItemList();

	/**
	 * Gets the item list as a sequence.
	 * 
	 * @return the sequence list
	 */
	List <IContiguousItemSequence> getIssuedSequenceList();
}
/**
 *  Modification History:
 *
 *  $Log: IIssuedInventoryItemsResponse.java,v $
 *  Revision 1.3  2010/12/13 20:48:20  mwkfh
 *  added availableInventoryCount for multiple issue response
 *
 *  Revision 1.2  2010/12/07 19:31:31  mwkfh
 *  updated getIssuedSequenceList return value
 *
 *  Revision 1.1  2010/12/05 00:06:17  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 */
