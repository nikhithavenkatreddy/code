/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am response carrying issued inventory item
 * File: IssuedInventoryItemResponse.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.response.impl
 * Created: Sep 16, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/10/15 18:42:27 $
 * Last Changed By: $Author: mwkfh $
 */
public class IssuedInventoryItemResponse extends InventoryServiceResponse
		implements IIssuedInventoryItemResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4274660911306475555L;
	/** The issued item. */
	private IInventoryItem issuedItem;

	/**
	 * Instantiates a new issued inventory item response.
	 */
	protected IssuedInventoryItemResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public IssuedInventoryItemResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public IssuedInventoryItemResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new issued inventory item response.
	 * 
	 * @param anItem the an item
	 */
	public IssuedInventoryItemResponse(IInventoryItem anItem) {
		super();
		setIssuedItem(anItem);
	}

	/**
	 * Gets the issued item.
	 * 
	 * @return the issuedItem
	 */
	public IInventoryItem getIssuedItem() {
		return issuedItem;
	}

	/**
	 * Sets the issued item.
	 * 
	 * @param anItem the an item
	 */
	protected void setIssuedItem(IInventoryItem anItem) {
		issuedItem = anItem;
		if (issuedItem == null) {
			setAffectedItemCount(0);
		}
		else {
			setAffectedItemCount(1);
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssuedInventoryItemResponse.java,v $
 *  Revision 1.3  2010/10/15 18:42:27  mwkfh
 *  added IIssuedInventoryItemResponse
 *
 *  Revision 1.2  2010/10/06 22:33:07  mwkfh
 *  updated for single object
 *
 *  Revision 1.1  2010/09/20 20:29:13  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/16 22:34:14  mwpxp2
 *  Initial implementation
 *
 */
