/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult;

/**
 * Description: Enumeration to determine Drive and Law Test Result Type.
 * 
 * File: DriveAndLawTestResultType.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult
 * Created: Jan 28, 2010 
 * @author MWRSK  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum DriveAndLawTestResultType {
	/** Non Class M Drive Test Result Type. */
	CLASS_F_DRIVE_TEST_RESULT,
	/** Non Class M Law Test Result Type. */
	CLASS_F_LAW_TEST_RESULT,
	/** Class M Drive Test Result Type. */
	CLASS_M_DRIVE_TEST_RESULT,
	/** Class M Law Test Result Type. */
	CLASS_M_LAW_TEST_RESULT,
	/** Signs Test Result Type. */
	SIGNS_TEST_RESULT,
	/** Word and Phrase Test Result Type. */
	WORD_AND_PHRASE_TEST_RESULT
}
/**
 *  Modification History:
 * 
 *  $Log: DriveAndLawTestResultType.java,v $
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/03/18 17:21:05  mwhxa2
 *  Changed name to DriveAndLawTestResultType
 *
 *  Revision 1.3  2010/03/15 17:55:25  mwuxb
 *  Changed Non_Class_M type to Class F
 *
 *  Revision 1.2  2010/01/29 15:04:33  mwrsk
 *  USed upper case for types
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
*/
