/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial;

/**
 * Description: I am interface for determining payment type
 * File: IPaymentType.java
 * Module:  gov.ca.dmv.ease.bo.financial
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/21 22:22:46 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IPaymentType {
	/**
	 * Checks if is cash.
	 * 
	 * @return true, if is cash
	 */
	boolean isCash();

	/**
	 * Checks if is check.
	 * 
	 * @return true, if is check
	 */
	boolean isCheck();

	/**
	 * Checks if is credit.
	 * 
	 * @return true, if is credit
	 */
	boolean isCredit();

	/**
	 * Checks if is debit.
	 * 
	 * @return true, if is debit
	 */
	boolean isDebit();

	/**
	 * Checks if is voucher.
	 * 
	 * @return true, if is voucher
	 */
	boolean isVoucher();
}
/**
 *  Modification History:
 *
 *  $Log: IPaymentType.java,v $
 *  Revision 1.1  2011/10/21 22:22:46  mwpxp2
 *  Initial - extracted out from the WS4 payment implementation
 *
 */
