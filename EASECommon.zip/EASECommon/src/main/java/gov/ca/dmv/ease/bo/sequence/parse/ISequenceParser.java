/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.parse;

import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequenceConstants;

import java.io.Serializable;

/**
 * Description: I am interface for parsing ISequences
 * File: ISequenceParser.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 3, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/30 18:50:56 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequenceParser extends ISequenceConstants, Serializable {
	 
	/**
	 * Parses the.
	 * 
	 * @param aSequence the a sequence
	 * 
	 * @return the i sequence elem list
	 */
	
	ISequenceElemList parse(ISequence aSequence);
}
/**
 *  Modification History:
 *
 *  $Log: ISequenceParser.java,v $
 *  Revision 1.2  2010/09/30 18:50:56  mwpxp2
 *  Cleaned imports
 *
 *  Revision 1.1  2010/09/10 18:26:20  mwbxg3
 *  moved from gov.ca.dmv.ease.bo.sequence package and renamed from ISequenceParserNew to ISequenceParser
 *
 *  Revision 1.1  2010/09/10 00:32:55  mwbxg3
 *  Initial creation.
 *
 *  Revision 1.2  2010/09/09 21:05:11  mwpxp2
 *  Changed return type of the main call to ISequenceElemList
 *
 *  Revision 1.1  2010/09/04 05:53:51  mwpxp2
 *  Initial, in progress
 *
 */
