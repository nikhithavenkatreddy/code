package gov.ca.dmv.ease.bo.dl.exams;

import static java.util.Arrays.asList;

import java.util.List;

/**
 * Description: This interface defines constants related to knowledge exams and AKTS 
 * File: IKnowledgeExamCodes.java
 * Module:  gov.ca.dmv.ease.bo.dl.exams
 * Created: Dec 22, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/08/01 21:00:20 $
 * Last Changed By: $Author: mwgxd3 $
 */
public interface IKnowledgeExamCodes {
	/* California Driver Examination Original */	
	String BASIC_ORIGINAL_EXAM = "BK";
	/* California Driver Examination (Renewal) */	
	String BASIC_RENEWAL_EXAM = "RN";
	/* California Motorcycle Examination */	
	String MOTORCYCLE_EXAM = "MC";
	/* California Provisional Licensing Examination */	
	String BASIC_PROVISIONAL_EXAM = "PR";
	/* Road Sign Test */	
	String SIGN_EXAM = "SI";
	/* Commercial Class A */
	String CLASS_A_EXAM = "CA";
	/* Commercial General Knowledge Test Class B */
	String COMMERCIAL_GENERAL_EXAM = "GK";
	/* Air Brakes Test */
	String AIR_BRAKES_EXAM = "AB";
	/* Doubles-Triples Endorsement Test */	
	String DOUBLE_TRIPLE_EXAM = "DT";
	/* Tank Vehicle Endorsement Test */	
	String TANK_VEHICLE_EXAM = "TK";
	/* Passenger Vehicle Endorsement Test */	
	String PASSENGER_VEHICLE_EXAM = "PV";
	/* Hazardous Materials Endorsement Test	*/
	String HAZMAT_EXAM = "HM";
	/* Driver's Examination for Recreational Vehicles and Noncommercial Class A Trailers */	
	String RV_AND_TRAILER_EXAM = "RV";
	/* Driver's Examination for 45' Housecars */	
	String HOUSE_CAR_EXAM = "HC";
	/** The Constant BASIC_TESTS. */
	Object BASIC_TESTS[] = { BASIC_ORIGINAL_EXAM, BASIC_RENEWAL_EXAM };
	List <String> BASIC_KNOWLEDGE_TESTS = asList(BASIC_ORIGINAL_EXAM, BASIC_RENEWAL_EXAM, BASIC_PROVISIONAL_EXAM);
	
	String AKTS_FAIL_CODE = "F";
	String AKTS_PASS_CODE = "A";
	String EASE_FAIL_CODE = "F"; 
	String EASE_PASS_CODE = "A"; 
	String AKTS_ENGLISH_CODE = "en";
	String AKTS_SPANISH_CODE = "es";
	String AKTS_CHINESE_CODE = "zh"; 
	String AKTS_KOREAN_CODE = "ko"; 
	String AKTS_VIET_CODE = "vi"; 
	String EASE_ENGLISH_CODE = "EN"; 
	String EASE_SPANISH_CODE = "SP";
	String EASE_CHINESE_CODE = "CH"; 
	String EASE_KOREAN_CODE = "KO"; 
	String EASE_OTHER_LANG_CODE = "OT"; 
	String EASE_VIET_CODE = "VI"; 

}


/**
 *  Modification History:
 *
 *  $Log: IKnowledgeExamCodes.java,v $
 *  Revision 1.3  2012/08/01 21:00:20  mwgxd3
 *  AKTS defecr 43 - add list of basic knowledge tests.
 *
 *  Revision 1.2  2012/04/17 22:26:47  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.4  2012/03/08 23:49:24  mwsec2
 *  ease english code added
 *
 *  Revision 1.1.2.3  2012/03/07 23:11:42  mwsec2
 *  result constants added
 *
 *  Revision 1.1.2.2  2012/03/02 22:36:10  mwgxd3
 *  add BASIC_TESTS[]
 *
 *  Revision 1.1.2.1  2012/02/15 19:39:39  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */