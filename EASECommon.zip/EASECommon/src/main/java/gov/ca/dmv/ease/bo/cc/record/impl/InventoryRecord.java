/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.cc.record.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.util.Date;
import java.util.List;

/**
 * Description: This represents the details of the Inventory Record which is attributes needed for 
 * the interface to the bridge code communicating to the legacy system
 * File: InventoryRangeRecord.java
 * Module:  gov.ca.dmv.ease.bo.cc.impl
 * Created: May 25, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2012/08/15 16:15:54 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class InventoryRecord {
	/*
	 * 0 - No Inventory 
	 * 1 - Normal Generation 
	 * 2 - Permits / Prorates 
	 * 3 - Key Entered
	 */
	private CodeSetElement inventoryGeneratedClassCode;
	private Boolean isInventoryAlreadyIssued; // 'Y'=Yes
	private Boolean isInventoryAutoAssignmentMade; // 'Y'=Yes
	private Boolean isInventoryAutoAssignmentRequired; // 'Y'=Yes
	private Boolean isInventoryInvolved; // 'Y'=Yes
	private Boolean isInventoryMayNeedTin; // (Originals ONLY) 'Y'=Yes
	/** The issued Inventory Calendar Date. */
	private Date issuedInventoryCalendarDate;
	/** The list of issued Inventory records. */
	private List <IssuedInventoryRecord> issuedInventoryRecords;
	/** The issued TIN Calendar Date */
	private Date issuedTinCalendarDate;

	/**
	 * @return the inventoryGeneratedClassCode
	 */
	public CodeSetElement getInventoryGeneratedClassCode() {
		return inventoryGeneratedClassCode;
	}

	/**
	 * @return the issuedInventoryCalendarDate
	 */
	public Date getIssuedInventoryCalendarDate() {
		return issuedInventoryCalendarDate;
	}

	/**
	 * @return the issuedInventoryRecords
	 */
	public List <IssuedInventoryRecord> getIssuedInventoryRecords() {
		return issuedInventoryRecords;
	}

	/**
	 * @return the issuedTinCalendarDate
	 */
	public Date getIssuedTinCalendarDate() {
		return issuedTinCalendarDate;
	}

	/**
	 * @return the isInventoryAlreadyIssued
	 */
	public boolean isInventoryAlreadyIssued() {
		return isInventoryAlreadyIssued;
	}

	/**
	 * @return the isInventoryAutoAssignmentMade
	 */
	public boolean isInventoryAutoAssignmentMade() {
		return isInventoryAutoAssignmentMade;
	}

	/**
	 * @return the isInventoryAutoAssignmentRequired
	 */
	public boolean isInventoryAutoAssignmentRequired() {
		return isInventoryAutoAssignmentRequired;
	}

	/**
	 * @return the isInventoryInvolved
	 */
	public boolean isInventoryInvolved() {
		return isInventoryInvolved;
	}

	/**
	 * @return the isInventoryMayNeedTIN
	 */
	public boolean isInventoryMayNeedTin() {
		return isInventoryMayNeedTin;
	}

	/**
	 * @param isInventoryAlreadyIssued the isInventoryAlreadyIssued to set
	 */
	public void setInventoryAlreadyIssued(boolean isInventoryAlreadyIssued) {
		this.isInventoryAlreadyIssued = isInventoryAlreadyIssued;
	}

	/**
	 * @param isInventoryAutoAssignmentMade the isInventoryAutoAssignmentMade to set
	 */
	public void setInventoryAutoAssignmentMade(
			boolean isInventoryAutoAssignmentMade) {
		this.isInventoryAutoAssignmentMade = isInventoryAutoAssignmentMade;
	}

	/**
	 * @param isInventoryAutoAssignmentRequired the isInventoryAutoAssignmentRequired to set
	 */
	public void setInventoryAutoAssignmentRequired(
			boolean isInventoryAutoAssignmentRequired) {
		this.isInventoryAutoAssignmentRequired = isInventoryAutoAssignmentRequired;
	}

	/**
	 * @param inventoryGeneratedClassCode the inventoryGeneratedClassCode to set
	 */
	public void setInventoryGeneratedClassCode(
			CodeSetElement inventoryGeneratedClassCode) {
		this.inventoryGeneratedClassCode = inventoryGeneratedClassCode;
	}

	/**
	 * @param isInventoryInvolved the isInventoryInvolved to set
	 */
	public void setInventoryInvolved(boolean isInventoryInvolved) {
		this.isInventoryInvolved = isInventoryInvolved;
	}

	/**
	 * @param isInventoryMayNeedTIN the isInventoryMayNeedTIN to set
	 */
	public void setInventoryMayNeedTin(boolean isInventoryMayNeedTin) {
		this.isInventoryMayNeedTin = isInventoryMayNeedTin;
	}

	/**
	 * @param issuedInventoryCalendarDate the issuedInventoryCalendarDate to set
	 */
	public void setIssuedInventoryCalendarDate(Date issuedInventoryCalendarDate) {
		this.issuedInventoryCalendarDate = issuedInventoryCalendarDate;
	}

	/**
	 * @param issuedInventoryRecords the issuedInventoryRecords to set
	 */
	public void setIssuedInventoryRecords(
			List <IssuedInventoryRecord> issuedInventoryRecords) {
		this.issuedInventoryRecords = issuedInventoryRecords;
	}

	/**
	 * @param issuedTinCalendarDate the issuedTinCalendarDate to set
	 */
	public void setIssuedTinCalendarDate(Date issuedTinCalendarDate) {
		this.issuedTinCalendarDate = issuedTinCalendarDate;
	}
}
