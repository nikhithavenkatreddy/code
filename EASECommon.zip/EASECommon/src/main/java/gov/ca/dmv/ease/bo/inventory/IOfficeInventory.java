/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory;

/**
 * Description: I am interface for a local office inventory
 * File: IOfficeInventory.java
 * Module:  gov.ca.dmv.ease.bo.inventory
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/08/31 03:45:44 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeInventory extends IInventory {
	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeInventory.java,v $
 *  Revision 1.2  2010/08/31 03:45:44  mwpxp2
 *  Cleanup
 *
 *  Revision 1.1  2010/08/30 23:25:21  mwpxp2
 *  Initial
 *
 */
