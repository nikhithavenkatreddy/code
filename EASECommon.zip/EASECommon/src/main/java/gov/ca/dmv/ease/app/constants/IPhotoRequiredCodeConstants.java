/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: Photo required code constants
 * File: IPhotoRequiredCodeConstants.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Jun 16, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/07/02 17:14:41 $
 * Last Changed By: $Author: mwhys $
 */
public interface IPhotoRequiredCodeConstants {
	/** The NO t_ required. */
	String NOT_REQUIRED = "N";
	/** The PHOT o_ waived. */
	String PHOTO_WAIVED = "E";
	/** The REQUIRED. */
	String REQUIRED = "Y";
	/** The DUPLICATE. */
	String DUPLICATE = "D";
	/**
	 * DL Photo Retake Constants.
	 */
	String DL_PHOTO_RETAKE = "3";
	/** The constant for photo not matched. */
	String PHOTO_NOT_MATCH = "N";
	/** The constant for photo not matched. */
	String PHOTO_NOT_MATCH_TWO = "2";
	/**
	 * TYPE PHOTO ON FILE(N=NBS P=POLAROID, L=LIS, W=NO PHOTO)
	 */
	String TYPE_PHOTO_ON_FILE_NBS = "N";
	String TYPE_PHOTO_ON_FILE_POLAROID = "P";
	String TYPE_PHOTO_ON_FILE_LIS = "L";
	String TYPE_PHOTO_ON_FILE_NO_PHOTO = "W";
}
/**
 *  Modification History:
 *
 *  $Log: IPhotoRequiredCodeConstants.java,v $
 *  Revision 1.4  2012/07/02 17:14:41  mwhys
 *  Added TYPE_PHOTO_ON_FILE_NO_PHOTO code "W". (Issuance defect from Ia)
 *
 *  Revision 1.3  2011/10/20 23:49:59  mwuxb
 *  Added constant PHOTO_NOT_MATCH_TWO
 *
 *  Revision 1.2  2011/09/02 18:55:06  mwhys
 *  Added DUPLICATE.
 *
 *  Revision 1.1  2011/05/25 00:13:21  mwtjc1
 *  moved from EaseDriverLicense to EaseCommons
 *
 *  Revision 1.11  2011/05/18 20:43:53  mwxxw
 *  Fix defect 5966. Add more constants.
 *
 *  Revision 1.10  2011/03/18 00:36:39  mwxxw
 *  Fix defect 4187.
 *
 *  Revision 1.9  2011/03/04 00:53:48  mwuxb
 *  Added constant PHOTO_NOT_MATCH
 *
 *  Revision 1.8  2010/12/28 18:52:39  mwsym2
 *  Committed on behalf of Prabhu Rajendran mwpxr5
 *  DL_PHOTO_RETAKE added
 *
 *  Revision 1.7  2010/11/18 23:52:21  mwpxp2
 *  Deleted redundant modifiers
 *
 *  Revision 1.6  2010/10/24 18:50:39  mwhxb3
 *  renamed to PHOTO_WAIVED.
 *
 *  Revision 1.5  2010/07/26 22:34:25  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/07/07 23:32:25  mwyxg1
 *  add WAIVED
 *
 *  Revision 1.3  2010/06/23 17:36:26  mwyxg1
 *  change class to interface
 *
 *  Revision 1.2  2010/06/21 23:18:44  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.2.1  2010/06/20 18:08:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.1  2010/06/16 18:07:34  mwyxg1
 *  add new
 *
 */
