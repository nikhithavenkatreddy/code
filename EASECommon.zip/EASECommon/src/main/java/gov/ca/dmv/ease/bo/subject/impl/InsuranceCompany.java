/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

/**
 * Description: This class is used to capture information relating to the Insurance Company
 * File: InsuranceCompany.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: May 5, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2010/12/07 22:11:40 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InsuranceCompany extends Organization {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2100832169603360373L;
	/** The Insurance Company Abbreviation .*/
	private String insuranceCompanyAbbreviation;
	/** The Insurance Company Number relevant to DMV .
	 * This is the 4 position California Tax or Insurance Company ID Number from the insurance certificate.*/
	private String insuranceCompanyNumber;
	/** DELETE!! USE Org name
	 *  The name. */
	//private String name;
	/** The status indicator. */
	private String statusIndicator;

	/**
	 * @return the insuranceCompanyAbbreviation
	 */
	public String getInsuranceCompanyAbbreviation() {
		return insuranceCompanyAbbreviation;
	}

	/**
	 * @return the insuranceCompanyNumber
	 */
	public String getInsuranceCompanyNumber() {
		return insuranceCompanyNumber;
	}

	/**
	 * @return the statusIndicator
	 */
	public String getStatusIndicator() {
		return statusIndicator;
	}

	/**
	 * @param insuranceCompanyAbbreviation the insuranceCompanyAbbreviation to set
	 */
	public void setInsuranceCompanyAbbreviation(
			String insuranceCompanyAbbreviation) {
		this.insuranceCompanyAbbreviation = insuranceCompanyAbbreviation;
	}

	/**
	 * @param insuranceCompanyNumber the insuranceCompanyNumber to set
	 */
	public void setInsuranceCompanyNumber(String insuranceCompanyNumber) {
		this.insuranceCompanyNumber = insuranceCompanyNumber;
	}

	/**
	 * @param statusIndicator the statusIndicator to set
	 */
	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("insuranceCompanyAbbreviation",
				insuranceCompanyAbbreviation, anIndent, aBuilder);
		outputKeyValue("insuranceCompanyNumber", insuranceCompanyNumber,
				anIndent, aBuilder);
		outputKeyValue("statusIndicator", statusIndicator, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
