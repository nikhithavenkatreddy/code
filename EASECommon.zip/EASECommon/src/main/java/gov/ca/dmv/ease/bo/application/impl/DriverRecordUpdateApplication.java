/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class is used by the TTC 30U to perform miscellaneous Driver Record Update transactions
 * File: DriverRecordUpdateApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 14, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class DriverRecordUpdateApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1577836572929766551L;
	/** The TypeOfUpdate option values 1 to 9 */
	private CodeSetElement typeOfUpdateCode;

	/**
	 * Gets the Type of Update Code.
	 * 
	 * @return the typeOfUpdateCode
	 */
	public CodeSetElement getTypeOfUpdateCode() {
		return typeOfUpdateCode;
	}

	/**
	 * Sets the Type of Update Code.
	 * 
	 * @param typeOfUpdateCode the typeOfUpdateCode to set
	 */
	public void setTypeOfUpdateCode(CodeSetElement typeOfUpdateCode) {
		this.typeOfUpdateCode = typeOfUpdateCode;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DriverRecordUpdateApplication.java,v $
 *  Revision 1.5  2012/03/14 01:57:55  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.4  2010/07/22 17:50:27  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/07/20 20:47:21  mwhxa2
 *  Updated Java Docs
 *
*/
