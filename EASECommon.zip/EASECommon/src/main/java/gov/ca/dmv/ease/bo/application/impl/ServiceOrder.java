/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Description: This class captures the detail of the Service Order.
 * File: ServiceOrder.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 6, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/07/20 16:36:53 $
 * Last Changed By: $Author: mwhys $
 */
public class ServiceOrder implements Serializable {
	/** The ServiceOrder.java */
	private static final long serialVersionUID = -8682699157304855275L;
	/** The Action for which Service Of Order has not been completed. */
	private String action;
	/** The Action Code. */
	private CodeSetElement actionCode;
	/** The Action Reason Code. */
	private CodeSetElement actionReasonCode;
	/** This represents the effective date for each action requiring service of order displays. */
	private Date effectiveDate;
	/** The License Location Code. */
	private CodeSetElement locationCode;
	/** The Service Code. 
	 * (T - Telephone service, V - Verbal notice ..) */
	private CodeSetElement serviceCode;
	/** This represents the current system date or service date. */
	private Date serviceDate;
	/** The Vehicle Section Code. */
	private List <CodeSetElement> vehicleCodeSectionCodes;
	
	/**
	 * Gets the Action.
	 * 
	 * @return the action
	 */
	public String getAction() {
		return this.action;
	}
	
	/**
	 * Gets the Action Code.
	 * 
	 * @return the actionCode
	 */
	public CodeSetElement getActionCode() {
		return this.actionCode;
	}
	
	/**
	 * Gets the Action Reason Code.
	 * 
	 * @return the actionReasonCode
	 */
	public CodeSetElement getActionReasonCode() {
		return this.actionReasonCode;
	}
	
	/**
	 * Gets the Effective Date.
	 * 
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return this.effectiveDate;
	}
	
	/**
	 * Gets the License Location Code.
	 * 
	 * @return the locationCode
	 */
	public CodeSetElement getLocationCode() {
		return this.locationCode;
	}
	
	/**
	 * Gets the Service Code.
	 * 
	 * @return the serviceCode
	 */
	public CodeSetElement getServiceCode() {
		return this.serviceCode;
	}
	
	/**
	 * Gets the Service Date.
	 * 
	 * @return the serviceDate
	 */
	public Date getServiceDate() {
		return this.serviceDate;
	}
	
	/**
	 * Gets the vehicle code section codes.
	 *
	 * @return the vehicleCodeSectionCodes
	 */
	public List <CodeSetElement> getVehicleCodeSectionCodes() {
		return vehicleCodeSectionCodes;
	}
	
	/**
	 * Sets the Action.
	 * 
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	/**
	 * Sets the Action Code.
	 * 
	 * @param actionCode the actionCode to set
	 */
	public void setActionCode(CodeSetElement actionCode) {
		this.actionCode = actionCode;
	}
	
	/**
	 * Sets the Action Reason Code.
	 * 
	 * @param actionReasonCode the actionReasonCode to set
	 */
	public void setActionReasonCode(CodeSetElement actionReasonCode) {
		this.actionReasonCode = actionReasonCode;
	}
	
	/**
	 * Sets the Effective Date.
	 * 
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	/**
	 * Sets the License Location Code.
	 * 
	 * @param locationCode the locationCode to set
	 */
	public void setLocationCode(CodeSetElement locationCode) {
		this.locationCode = locationCode;
	}
	
	/**
	 * Sets the Service Code.
	 * 
	 * @param serviceCode the serviceCode to set
	 */
	public void setServiceCode(CodeSetElement serviceCode) {
		this.serviceCode = serviceCode;
	}
	
	/**
	 * Sets the Service Date.
	 * 
	 * @param serviceDate the serviceDate to set
	 */
	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}
	
	/**
	 * Sets the vehicle code section codes.
	 *
	 * @param vehicleCodeSectionCodes the vehicleCodeSectionCodes to set
	 */
	public void setVehicleCodeSectionCodes(
			List <CodeSetElement> vehicleCodeSectionCodes) {
		this.vehicleCodeSectionCodes = vehicleCodeSectionCodes;
	}
}
/**
 *  Modification History:
 *
 *  $Log: ServiceOrder.java,v $
 *  Revision 1.7  2011/07/20 16:36:53  mwhys
 *  implements Serializable.
 *
 *  
 */
