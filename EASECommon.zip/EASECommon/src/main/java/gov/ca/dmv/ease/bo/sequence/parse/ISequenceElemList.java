/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.parse;

import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequenceConstants;
import gov.ca.dmv.ease.bo.sequence.ISequenceElem;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;

import java.io.Serializable;
import java.util.List;

/**
 * Description: I am interface for an ordered collection of ISequenceElems
 * File: ISequenceElemList.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 8, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/10/09 00:18:28 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequenceElemList extends ISequenceConstants, Serializable {
	/**
	 * Gets the elems.
	 * 
	 * @return the elems
	 */
	List <ISequenceElem> getElems();

	/**
	 * Gets the next.
	 * 
	 * @return the next
	 */
	ISequenceElemList getNext();

	/**
	 * Gets the previous.
	 * 
	 * @return the previous
	 */
	ISequenceElemList getPrevious();

	/**
	 * As sequence.
	 * 
	 * @return the i sequence
	 */
	ISequence asSequence(ISequencePattern aPattern);

	/**
	 * Adds the elem.
	 * 
	 * @param anElem the an elem
	 */
	void addElem(ISequenceElem anElem);
}
/**
 *  Modification History:
 *
 *  $Log: ISequenceElemList.java,v $
 *  Revision 1.2  2010/10/09 00:18:28  mwpxp2
 *  Added ISequenceConstants as super
 *
 *  Revision 1.1  2010/09/30 18:50:39  mwpxp2
 *  Moved in to parse package
 *
 *  Revision 1.2  2010/09/11 00:27:00  mwpxp2
 *  Changed asSequence/0 to asSequence/1
 *
 *  Revision 1.1  2010/09/08 21:00:12  mwpxp2
 *  Initial
 *
 */
