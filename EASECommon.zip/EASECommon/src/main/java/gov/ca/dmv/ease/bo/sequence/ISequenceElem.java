/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence;

import java.io.Serializable;

/**
 * Description: I am interface for a one char sequence element
 * File: ISequenceElem.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 8, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/10/09 00:09:23 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequenceElem extends ISequenceConstants, Serializable {
	/**
	 * As int value.
	 * 
	 * @return the int
	 */
	int asIntValue();

	/**
	 * Gets the absolute max char.
	 * 
	 * @return the absolute max char
	 */
	char getAbsoluteMaxChar();

	/**
	 * As char value.
	 * 
	 * @return the char
	 */
	char getCharValue();

	/**
	 * Gets the max char - max allowed value given by constraint or a default.
	 * 
	 * @return the max char
	 */
	char getMaxChar();

	/**
	 * Gets the min char - min allowed value given by constraint or a default.
	 * 
	 * @return the min char
	 */
	char getMinChar();

	/**
	 * Gets the next.
	 * 
	 * @return the next
	 */
	ISequenceElem getNext();

	/**
	 * Gets the pattern char.
	 * 
	 * @return the pattern char
	 */
	char getPatternChar();

	/**
	 * Gets the previous.
	 * 
	 * @return the previous
	 */
	ISequenceElem getPrevious();

	/**
	 * Checks if is fixed.
	 * 
	 * @return true, if is fixed
	 */
	boolean isFixed();

	/**
	 * Checks if is over.
	 * 
	 * @return true, if is over
	 */
	boolean isOver();

	/**
	 * Checks if is over or under.
	 * 
	 * @return true, if is over or under
	 */
	boolean isOverOrUnder();

	/**
	 * Checks if is under.
	 * 
	 * @return true, if is under
	 */
	boolean isUnder();

	/**
	 * Sets the max char.
	 * 
	 * @param aVal the new max char
	 */
	void setMaxChar(char aVal);

	/**
	 * Sets the min char.
	 * 
	 * @param aVal the new min char
	 */
	void setMinChar(char aVal);
}
/**
 *  Modification History:
 *
 *  $Log: ISequenceElem.java,v $
 *  Revision 1.3  2010/10/09 00:09:23  mwpxp2
 *  Made setting max and min chars public; added getAbsoluteMaxChar/0
 *
 *  Revision 1.2  2010/09/09 00:45:49  mwpxp2
 *  Added 3 calls: 2 get~ and one is~
 *
 *  Revision 1.1  2010/09/08 21:00:12  mwpxp2
 *  Initial
 *
 */
