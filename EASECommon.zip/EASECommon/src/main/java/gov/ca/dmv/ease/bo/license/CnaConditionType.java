/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license;

/**
 * Description: Enumeration of CNA conditions
 * 
 * File: CnaConditionType.java
 * Module:  gov.ca.dmv.ease.bo.license
 * Created: Feb 24, 2010 
 * @author MWRSK  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/10/30 00:02:43 $
 * Last Changed By: $Author: mwuxb $
 */
public enum CnaConditionType {
	CNA_GET_CDLIS_PDPS_RESPONSE, CNA_HQ_INQUIRY, CNA_INVENTORY_INQUIRY, 
	CNA_LPV_INQUIRY, CNA_SEND_CDLIS_PDPS_INQUIRY, CNA_SSN_VERIFICATION, CNA_VOUCHER_INQUIRY,
	CNA_ADDRESS_INQUIRY
}
/**
 *  Modification History:
 * 
 *  $Log: CnaConditionType.java,v $
 *  Revision 1.5  2010/10/30 00:02:43  mwuxb
 *  Removed duplicate constant CNA_HEAD_QUARTER_INQUIRY
 *
 *  Revision 1.4  2010/08/04 16:51:19  mwcyl
 *  added cna_address_inquiry
 *
 *  Revision 1.3  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/05/25 18:05:33  mwbxp5
 *  Added other CNA conditions
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/02/25 02:13:13  mwrsk
 *  Made changes related to cnaConditionType
 *
*/
