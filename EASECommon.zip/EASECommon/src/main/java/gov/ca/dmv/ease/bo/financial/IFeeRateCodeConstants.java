/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial;

/**
 * Description: This is an interface to hold Fee Rate Code Constants.
 * File: IFeeRateCodeConstants.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Apr 26, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/12/08 20:51:22 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IFeeRateCodeConstants {
	/** Add Restriction Ignition Device Fee Rate Code. */
	String ADD_RESTRICTION_IGNITION_INTERLOCK_DEVICE_FEE_RATE_CODE = "730";
	/** Commercial DL Application Fee Rate Code. */
	String CDL_APPLICATION_FEE_RATE_CODE = "759";
	/** Commercial DL Test Fee Rate Code. */
	String CDL_DRIVE_TEST_FEE_RATE_CODE = "760";
	/**Credit Voucher code*/
	String CREDIT_VOUCHER_CODE = "C";
	/** Driver License Reissue Type 01 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_01_FEE_RATE_CODE = "731";
	/** Driver License Reissue Type 02 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_02_FEE_RATE_CODE = "746";
	/** Driver License Reissue Type 03 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_03_FEE_RATE_CODE = "747";
	/** Driver License Reissue Type 04 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_04_FEE_RATE_CODE = "743";
	/** Driver License Reissue Type 05 Fee Rate Code. */
	String DRIVER_LICENSE_REISSUE_TYPE_05_FEE_RATE_CODE = "744";
	/** Drug Screening Reissue Fee Rate Code. */
	String DRUG_SCREENING_REISSUE_FEE_RATE_CODE = "749";
	/** Family Law Due Fee Rate Code. */
	String FAMILY_LAW_DUE_FEE_RATE_CODE = "762";
	/** Fee amount status indicator*/
	String FEE_AMOUNT_OVER = "OVER";
	/** Fee amount indicator*/
	String FEE_AMOUNT_UNDER = "UNDER";
	/** Fire-Fighter DL Application Fee Rate Code. */
	String FIRE_FIGHTER_APPLICATION_FEE_RATE_CODE = "771";
	/**Ignore Voucher code*/
	String IGNORE_VOUCHER_CODE = "I";
	/** Motorcycle DL Re-test Fee Rate Code. */
	String MOTORCYCLE_RETEST_FEE_RATE_CODE = "-9999";
	/** NonCommercial DL Re-test Fee Rate Code. */
	String NON_CDL_RETEST_FEE_RATE_CODE = "773";
	/** Preliminary Alcohol Screening Reissue Fee Rate Code. */
	String PRELIMINARY_ALCOHOL_SCREENING_REISSUE_FEE_RATE_CODE = "748";
}
/**
 *  Modification History:
 * 
 *  $Log: IFeeRateCodeConstants.java,v $
 *  Revision 1.1  2010/12/08 20:51:22  mwpxp2
 *  Moved in to proper package
 *
 *  Revision 1.4  2010/12/07 03:03:13  mwpxp2
 *  Added toStringOn/1; sorted
 *
 *  Revision 1.3  2010/09/22 20:36:16  mwcsj3
 *  Added few constants
 *
 *  Revision 1.2  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/26 20:44:28  mwhxa2
 *  Interface to hold fee rate code constamts
 *
*/
