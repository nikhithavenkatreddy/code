/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response for SeedInventoryPersistenceBusinessObject response
 *  //TODO - generalize item count to PersistenceServiceResponse

 * File: SeedLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Sep 12, 2009
 * 
 * @author MWKFH
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/01/07 17:45:51 $
 * Last Changed By: $Author: mwkfh $
 */
public class SeedLocalInventoryResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2345564943600423104L;

	/**
	 * Instantiates a new seed business object response.
	 * 
	 */
	protected SeedLocalInventoryResponse() {
		super();
	}

	/**
	 * Instantiates a new seed business object response.
	 * 
	 * @param ex
	 */
	public SeedLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new seed business object response.
	 * 
	 * @param ex the ex
	 */
	public SeedLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new seed business object response.
	 * 
	 * @param collector
	 */
	public SeedLocalInventoryResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new seed business object response.
	 * 
	 * @param collector
	 * @param aCount
	 */
	public SeedLocalInventoryResponse(IErrorCollector collector, int aCount) {
		super(collector);
		setAffectedItemsCount(aCount);
	}

	/**
	 * Instantiates a new seed business object response.
	 * 
	 * @param aCount
	 */
	public SeedLocalInventoryResponse(int aCount) {
		super();
		setAffectedItemsCount(aCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SeedLocalInventoryResponse.java,v $
 *  Revision 1.6  2011/01/07 17:45:51  mwkfh
 *  updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 *  Revision 1.5  2010/10/20 18:18:59  mwkfh
 *  updated java docs
 *
 *  Revision 1.4  2010/10/13 00:59:40  mwpxp2
 *  Refactored with super
 *
 *  Revision 1.3  2010/10/12 22:22:32  mwpxp2
 *  Added affectedItemCount; toString/0; todo
 *
 *  Revision 1.2  2010/10/12 20:57:10  mwpxp2
 *  Added constructors from super
 *
 *  Revision 1.1  2010/09/20 18:25:45  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/14 16:31:33  mwkfh
 *  updated local inventory persistence
 *
 *  Revision 1.1  2010/09/13 16:54:40  mwkfh
 *  added LocalPersistenceService and Seed for inventory
 *
 */
