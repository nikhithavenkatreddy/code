/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.app.dl.fee.impl.FeeRateCode;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/** 
 * Description: This is a Driver License Fee Class, it captures Fee Rate Code along 
 * with associated Fee Status('s) Information.
 * File: DriverLicenseFee.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Apr 28, 2009 
 * @author MWCSJ3  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/08/31 22:04:58 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DriverLicenseFee extends Fee {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8107817578015113069L;
	/** The List of Driver License Rate and Statuses. */
	private List <DriverLicenseRateStatus> driverLicenseRateStatuses = new ArrayList <DriverLicenseRateStatus>();

	/** Default Constructor */
	public DriverLicenseFee() {
		//Empty Constructor
	}

	/**
	 * Adds the driver license rate status.
	 * 
	 * @param newdriverLicenseRateStatus the newdriver license rate status
	 */
	public void addDriverLicenseRateStatus(
			DriverLicenseRateStatus newdriverLicenseRateStatus) {
		FeeRateCode aFeeRatecode = newdriverLicenseRateStatus.getFeeRatecode();
		if (aFeeRatecode == null || StringUtils.isBlank(aFeeRatecode.getCode())) {
			return; // DriverLicenseRateStatus with empty FeeRateCode cannot be added in the list  
		}
		//TODO Confirm if we will have duplicate driverLicenseRateStatuses. ex. Family Law Fee Code(768) may occur many times.
		//		for (int i = 0; i < driverLicenseRateStatuses.size(); i++) {
		//			DriverLicenseRateStatus existingDriverLicenseRateStatus = driverLicenseRateStatuses
		//					.get(i);
		//			FeeRateCode feeRateCode = existingDriverLicenseRateStatus
		//					.getFeeRatecode();
		//			if (aFeeRatecode.getCode().trim().equals(feeRateCode.getCode())) { // If DriverLicenseRateStatus with expected FeeRateCode already exists, then overwrite it with a new DriverLicenseRateStatus				
		//				driverLicenseRateStatuses.set(i, newdriverLicenseRateStatus);
		//				return;
		//			}
		//		}
		driverLicenseRateStatuses.add(newdriverLicenseRateStatus);
	}

	/**
	 * Gets the List of Driver License Rate and Statuses.
	 * 
	 * @return the driverLicenseRateStatuses
	 */
	public List <DriverLicenseRateStatus> getDriverLicenseRateStatuses() {
		return driverLicenseRateStatuses;
	}

	/**
	 * Gets the driver license rate status for expected fee rate code.
	 * 
	 * @param expectedFeeRatecode the expected fee ratecode
	 * 
	 * @return the driver license rate status for expected fee rate code
	 */
	public DriverLicenseRateStatus getDriverLicenseRateStatusForExpectedFeeRateCode(
			String expectedFeeRatecode) {
		for (DriverLicenseRateStatus driverLicenseRateStatus : driverLicenseRateStatuses) {
			FeeRateCode actualFeeRateCode = driverLicenseRateStatus
					.getFeeRatecode();
			if (actualFeeRateCode != null
					&& !StringUtils.isBlank(actualFeeRateCode.getCode())) {
				if (expectedFeeRatecode.trim().equals(
						actualFeeRateCode.getCode().trim())) {
					// As per the logic of addDriverLicenseRateStatus method, for one type of FeeRateCode, one and only one DriverLicenseRateStatus can be available.
					// This will force to use addDriverLicenseRateStatus method instead of setDriverLicenseRateStatuses method
					return driverLicenseRateStatus;
				}
			}
		}
		return null;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DriverLicenseFee.java,v $
 *  Revision 1.4  2012/08/31 22:04:58  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.3  2010/07/22 17:50:28  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/04/26 22:13:44  mwhxb3
 *  Updated addDriverLicenseRateStatus.
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.7  2010/04/06 00:36:11  mwtjc1
 *  updated
 *
 *  Revision 1.6  2010/04/06 00:26:06  mwtjc1
 *  addDriverLicenseRateStatus method is updated
 *
 *  Revision 1.5  2010/04/06 00:21:59  mwtjc1
 *  addDriverLicenseRateStatus method is updated
 *
 *  Revision 1.4  2010/04/06 00:01:59  mwtjc1
 *  updated
 *
 *  Revision 1.3  2010/04/05 23:56:02  mwtjc1
 *  addDriverLicenseRateStatus method is added
 *
 *  Revision 1.2  2010/04/05 23:47:39  mwtjc1
 *  getDriverLicenseRateStatusForExpectedFeeRateCode method added
 *
 *  Revision 1.1  2010/03/17 22:59:29  mwhxa2
 *  Created DriverLicenseFee, DriverLicenseRateStatus and updated Fee.
 *
 *  Revision 1.4  2010/03/10 01:39:45  mwhxa2
 *  Changed from code set element to fee rate code
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/09/13 20:45:32  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.5.2.1  2009/09/12 19:08:44  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.5  2009/08/27 05:39:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/22 23:21:46  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.3  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:36  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:17  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
