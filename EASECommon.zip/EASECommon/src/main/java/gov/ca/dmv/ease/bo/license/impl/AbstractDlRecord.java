/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.ITreePrintable;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.Serializable;

/**
 * Description: This represents the abstract super class and encapsulate
 * designate action code.
 * File: AbstractDlRecord.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Aug 11, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2012/10/02 19:32:29 $
 * Last Changed By: $Author: mwuxb $
 */
public abstract class AbstractDlRecord implements ITreePrintable, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6604133244481735275L;
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(AbstractDlRecord dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null abstractDlRecord argument expected in copy constructor in "
							+ this);
		}
		//Copy actionCode
		if (isNotNull(dataToCopy.getActionCode())) {
			setActionCode(new CodeSetElement(dataToCopy.getActionCode()));
		}
		else {
			setActionCode(null);
		}
	}
	
	/**
	 * Output key value.
	 *
	 * @param aKey the a key
	 * @param aValue the a value
	 * @param anIndent the an indent
	 * @param aBuilder the a builder
	 */
	protected static void outputKeyValue(String aKey, Object aValue,
			int anIndent, StringBuilder aBuilder) {
		BusinessObject.outputKeyValue(aKey, aValue, anIndent, aBuilder);
	}
	
	/** The action code. */
	private CodeSetElement actionCode;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AbstractDlRecord other = (AbstractDlRecord) obj;
		if (actionCode == null) {
			if (other.actionCode != null) {
				return false;
			}
		}
		else if (!actionCode.equals(other.actionCode)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the Action code.
	 * 
	 * @return the actionCode
	 */
	public CodeSetElement getActionCode() {
		return actionCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((actionCode == null) ? 0 : actionCode.hashCode());
		return result;
	}
	
	/**
	 * This method provides Primary Indicator.
	 * 
	 * @return true if Primary Record
	 */
	public boolean isPrimary() {
		return getActionCode() != null
				&& "P".equalsIgnoreCase(getActionCode().getCode());
	}
	
	
	/**
	 * This method is possible doubles..
	 * 
	 * @return true if Possible Double.
	 */
	public boolean isPossibleDoubles() {
		return getActionCode() != null
				&& "D".equalsIgnoreCase(getActionCode().getCode());
	}
	
	/**
	 * This method provides Ignored Indicator.
	 * 
	 * @return true if Ignored Record
	 */
	public boolean isIgnored() {
		return getActionCode() != null
				&& "I".equalsIgnoreCase(getActionCode().getCode());
	}
	
	/**
	 * Sets the Action code.
	 * 
	 * @param actionCode the actionCode to set
	 */
	public void setActionCode(CodeSetElement actionCode) {
		this.actionCode = actionCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(128);
		aBuilder.append(getClass().getSimpleName()).append("[");
		aBuilder.append("]");
		toStringOn(aBuilder, 0);
		return aBuilder.toString();
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.ITreePrintable#toStringOn(java.lang.StringBuilder, int)
	 */
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("actionCode", actionCode, anIndent, aBuilder);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AbstractDlRecord.java,v $
 *  Revision 1.10  2012/10/02 19:32:29  mwuxb
 *  Added method to check possible double record.
 *
 *  Revision 1.9  2012/09/14 21:00:26  mwhys
 *  Added copy method. (Defect 6900 - AN fatal)
 *
 *  Revision 1.8  2011/06/07 18:19:33  mwkfh
 *  fixed possible null pointer issue
 *
 *  Revision 1.7  2011/06/07 16:20:32  mwhys
 *  Added isIgnored() method.
 *
 *  Revision 1.6  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 03:54:32  mwpxp2
 *  Added toStringOn/1, toString/0; sorted
 *
 *  Revision 1.4  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.2.2.2  2010/06/20 18:07:12  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.3  2010/06/07 16:54:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/05/27 14:37:54  mwrsk
 *  Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 *  Revision 1.1  2010/04/21 00:54:57  mwuxb
 *  Added AbstractDlRecord
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/03/19 01:14:19  mwvxm6
 *  Updated AniRecord to use only required attributes instead of Person
 *
 *  Revision 1.4  2010/03/15 17:06:00  mwhxa2
 *  Added Serialization
 *
 *  Revision 1.3  2010/02/09 20:37:59  mwrsk
 *  Pull up person to DLRecord
 *
 *  Revision 1.2  2010/01/28 22:21:40  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/03 21:06:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.5  2009/09/15 20:23:02  mwsmg6
 *  refactoring isPrimary
 *
 *  Revision 1.4  2009/09/10 23:03:27  mwakg
 *  Removed EliActionCode class and replaced with CodeSetElement
 *
 *  Revision 1.3  2009/08/27 05:39:52  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2009/08/16 21:54:15  mwakg
 *  Corrected wrong actioncode class
 *
 *  Revision 1.1  2009/08/12 00:36:14  mwrrv3
 *  Refactored the code.
 *
*/
