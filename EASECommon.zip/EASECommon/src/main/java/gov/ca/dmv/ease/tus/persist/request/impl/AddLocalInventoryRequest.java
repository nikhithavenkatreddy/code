/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.AddLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I am a request to add local inventory items.
 * File: AddLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Jun 8, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/06/08 17:33:29 $
 * Last Changed By: $Author: mwkfh $
 */
public class AddLocalInventoryRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4219219237086484312L;
	/** The sequences. */
	IContiguousItemSequence contiguousItemSequence;

	/**
	 * @param userContext
	 * @param contiguousItemSequence
	 */
	public AddLocalInventoryRequest(IUserContext userContext,
			IContiguousItemSequence contiguousItemSequence) {
		super(userContext);
		setContiguousItemSequence(contiguousItemSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public AddLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Gets the contiguousItemSequence.
	 * 
	 * @return the contiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		return contiguousItemSequence;
	}

	/**
	 * Sets the contiguousItemSequence.
	 * 
	 * @param contiguousItemSequence
	 */
	private void setContiguousItemSequence(
			IContiguousItemSequence contiguousItemSequence) {
		this.contiguousItemSequence = contiguousItemSequence;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AddLocalInventoryRequest.java,v $
 *  Revision 1.1  2011/06/08 17:33:29  mwkfh
 *  added AddLocalInventoryRequest
 *
 */
