/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.dl.fee.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: This class represents Fee Rate Code.
 * File: FeeRateCode.java
 * Module:  gov.ca.dmv.ease.app.dl.fee.impl
 * Created: Mar 9, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/08/31 22:04:00 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class FeeRateCode extends BusinessObject implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2349425699369675922L;
	/** The Rate Code. */
	private String code;
	/** The Rate Code Description. */
	private String description;
	/** The	Effective Start Date. */
	private Date effectiveBeginDate;
	/** The	Effective End Date. */
	private Date effectiveEndDate;
	/** The Fee Amount. */
	private String feeAmount;

	/**
	 * Default Constructor.
	 */
	public FeeRateCode() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		if (object == null) {
			return false;
		}
		if (!(object instanceof FeeRateCode)) {
			return false;
		}
		FeeRateCode other = (FeeRateCode) object;
		if (code != null && other.getCode() == null || code == null
				&& other.getCode() != null) {
			return false;
		}
		else if (code != null && other.getCode() != null
				&& !code.equals(other.getCode())) {
			return false;
		}
		if (feeAmount != null && other.getFeeAmount() == null
				|| feeAmount == null && other.getFeeAmount() != null) {
			return false;
		}
		else if (feeAmount != null && other.getFeeAmount() != null
				&& !feeAmount.equals(other.getFeeAmount())) {
			return false;
		}
		if (description != null && other.getDescription() == null
				|| description == null && other.getDescription() != null) {
			return false;
		}
		else if (description != null && other.getDescription() != null
				&& !description.equals(other.getDescription())) {
			return false;
		}
		if (effectiveBeginDate != null && other.getEffectiveBeginDate() == null
				|| effectiveBeginDate == null
				&& other.getEffectiveBeginDate() != null) {
			return false;
		}
		else if (effectiveBeginDate != null
				&& other.getEffectiveBeginDate() != null
				&& !effectiveBeginDate.equals(other.getEffectiveBeginDate())) {
			return false;
		}
		if (effectiveEndDate != null && other.getEffectiveEndDate() == null
				|| effectiveEndDate == null
				&& other.getEffectiveEndDate() != null) {
			return false;
		}
		else if (effectiveEndDate != null
				&& other.getEffectiveEndDate() != null
				&& !effectiveEndDate.equals(other.getEffectiveEndDate())) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the Rate Code.
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Gets the Description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Gets the Effective Begin Date.
	 * 
	 * @return the effectiveBeginDate
	 */
	public Date getEffectiveBeginDate() {
		return effectiveBeginDate;
	}

	/**
	 * Gets the Effective End Date.
	 * 
	 * @return the effectiveEndDate
	 */
	public Date getEffectiveEndDate() {
		return effectiveEndDate;
	}

	/**
	 * Gets the Fee Amount.
	 * 
	 * @return the feeAmount
	 */
	public String getFeeAmount() {
		return feeAmount;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((feeAmount == null) ? 0 : feeAmount.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime
				* result
				+ ((effectiveBeginDate == null) ? 0 : effectiveBeginDate
						.hashCode());
		result = prime
				* result
				+ ((effectiveEndDate == null) ? 0 : effectiveEndDate.hashCode());
		return result;
	}

	/**
	 * Sets the Rate Code.
	 * 
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Sets the Description.
	 * 
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Sets the Effective Begin Date.
	 * 
	 * @param effectiveBeginDate the effectiveBeginDate to set
	 */
	public void setEffectiveBeginDate(Date effectiveBeginDate) {
		this.effectiveBeginDate = effectiveBeginDate;
	}

	/**
	 * Sets the Effective End Date.
	 * 
	 * @param effectiveEndDate the effectiveEndDate to set
	 */
	public void setEffectiveEndDate(Date effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	/**
	 * Sets the Fee Amount.
	 * 
	 * @param feeAmount the feeAmount to set
	 */
	public void setFeeAmount(String feeAmount) {
		this.feeAmount = feeAmount;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: FeeRateCode.java,v $
 *  Revision 1.1  2012/08/31 22:04:00  mwrrv3
 *  Fixed PMD issues and moved to .impl package.
 *
 *  Revision 1.2  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/10 01:42:46  mwhxa2
 *  Updated setter method
 *
 *  Revision 1.1  2010/03/10 01:32:50  mwhxa2
 *  Adding FeeRateCode
 *
*/
