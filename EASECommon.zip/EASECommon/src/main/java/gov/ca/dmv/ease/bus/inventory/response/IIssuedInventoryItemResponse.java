/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;

/**
 * Description: I am interface for responses from inventory for requests 
 * involving inventory items
 * 
 * File: IIssuedInventoryItemResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response
 * Created: Oct 15, 2010 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/12/04 21:28:56 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IIssuedInventoryItemResponse extends IInventoryServiceResponse {
	/**
	 * Gets the item.
	 * 
	 * @return the item
	 */
	IInventoryItem getIssuedItem();
}
/**
 *  Modification History:
 *
 *  $Log: IIssuedInventoryItemResponse.java,v $
 *  Revision 1.2  2010/12/04 21:28:56  mwkfh
 *  updated comment
 *
 *  Revision 1.1  2010/10/15 18:42:26  mwkfh
 *  added IIssuedInventoryItemResponse
 *
 */
