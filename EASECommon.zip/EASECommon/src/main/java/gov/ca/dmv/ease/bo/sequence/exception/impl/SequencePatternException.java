/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.exception.impl;

/**
 * Description: Exception to be used when a sequence pattern is invalid wrt its constraints
 * File: SequencePatternException.java
 * Module:  gov.ca.dmv.ease.bo.sequence.exception.impl
 * Created: Oct 21, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/10/22 16:16:58 $
 * Last Changed By: $Author: mwkfh $
 */
public class SequencePatternException extends SequenceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8293503691283420581L;

	/**
	 * Instantiates a new sequence parsing exception.
	 */
	public SequencePatternException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public SequencePatternException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public SequencePatternException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public SequencePatternException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequencePatternException.java,v $
 *  Revision 1.1  2010/10/22 16:16:58  mwkfh
 *  new exception
 *
 */
