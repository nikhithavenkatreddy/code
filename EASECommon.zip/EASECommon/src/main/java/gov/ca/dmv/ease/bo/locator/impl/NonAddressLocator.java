/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator.impl;

import gov.ca.dmv.ease.bo.locator.NonAddressType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: This class is used for holding Phone, Fax, Email address etc 
 * (other than non-address locator).
 * File: NonAddressLocator.java
 * Module:  gov.ca.dmv.ease.bo.locator.impl
 * Created: Aug 12, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/04/07 04:04:54 $
 * Last Changed By: $Author: mwhys $
 */
public class NonAddressLocator extends Locator {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -262889812870479493L;
	/** This represents the contact phone number, fax number, email address etc. */
	private String contact;
	/** The contact method. This represents the contact method type such as Phone/Fax/Email etc.*/
	private NonAddressType contactMethodType;

	/**
	 * Constructor.
	 * 
	 * @param contactMethodType
	 */
	public NonAddressLocator(NonAddressType contactMethodType) {
		super();
		this.contactMethodType = contactMethodType;
	}

	/**
	 * Instantiates a new non address locator.
	 *
	 * @param objectToCopy the data to copy
	 */
	public NonAddressLocator(NonAddressLocator objectToCopy) {
		super();
		copy(objectToCopy);
	}

	/**
	 * Copy the data from dataToCopy to this object.
	 * @param objectToCopy
	 */
	private void copy(NonAddressLocator objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null NonAddressLocator argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		//Copy Contact value
		setContact(objectToCopy.getContact());
		//Copy Contact Method type
		setContactMethodType(objectToCopy.getContactMethodType());
	}

	/**
	 * Gets the contact.
	 * 
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}

	/**
	 * @return the contactMethodType
	 */
	public NonAddressType getContactMethodType() {
		return contactMethodType;
	}

	/**
	 * @return the phoneNumberAreaCode
	 */
	public String getPhoneNumberAreaCode() {
		return getContact().substring(0, 3);
	}

	/**
	 * @return the phoneNumberPrefix
	 */
	public String getPhoneNumberPrefix() {
		return getContact().substring(3, 6);
	}

	/**
	 * @return the phoneNumberSuffix
	 */
	public String getPhoneNumberSuffix() {
		return getContact().substring(6, 10);
	}

	/**
	 * Sets the contact.
	 * 
	 * @param contact the new contact
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}

	/**
	 * @param contactMethodType the contactMethodType to set
	 */
	public void setContactMethodType(NonAddressType contactMethodType) {
		this.contactMethodType = contactMethodType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((contact == null) ? 0 : contact.hashCode());
		result = prime
				* result
				+ ((contactMethodType == null) ? 0 : contactMethodType
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		NonAddressLocator other = (NonAddressLocator) obj;
		if (contact == null) {
			if (other.contact != null)
				return false;
		}
		else if (!contact.equals(other.contact))
			return false;
		if (contactMethodType == null) {
			if (other.contactMethodType != null)
				return false;
		}
		else if (!contactMethodType.equals(other.contactMethodType))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: NonAddressLocator.java,v $
 *  Revision 1.5  2011/04/07 04:04:54  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.4.32.2  2011/04/05 22:25:07  mwrrv3
 *  Added copy constructor.
 *
 *  Revision 1.4.32.1  2011/04/02 20:22:24  mwhys
 *  Added copy constructor to be implemented.
 *
 *  Revision 1.4  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/05/01 22:54:26  mwuxb
 *  Added constructor to NonAddressLocator
 *
 *  Revision 1.2  2010/04/29 17:08:25  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/04/15 01:09:18  mwuxb
 *  Added attribute contactMethodType
 *
 *  Revision 1.2  2010/01/28 22:36:48  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:21  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/09/02 15:55:30  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.6  2009/09/02 15:43:44  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.5  2009/08/27 05:39:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/22 23:21:48  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.3  2009/08/13 00:03:40  mwrrv3
 *  Added more comments and formatted.
 *
 *  Revision 1.2  2009/07/14 23:44:38  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:44:15  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 4:40:14 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 4:40:14 PM  MWCSJ3
 *  $Initial
 *  $
 */
