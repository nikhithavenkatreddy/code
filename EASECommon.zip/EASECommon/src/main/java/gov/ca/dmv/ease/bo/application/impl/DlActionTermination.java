/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.subject.impl.Person;

import java.util.Date;

/**
 * Description: The Dl Action Termination Application is used to run ttc 43U
 * Service Of Order and license location information.
 * File: DlActionTermination.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:27 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DlActionTermination {
	/** The Driver. */
	private Person driver;
	/** The license location code. (S - Surrendered, L - Lost) */
	private CodeSetElement licenseLocation;
	/** This represents the current system date or service date. */
	private Date licenseSurrenderedProcessDate;
	/** This represents the originalActionEffectiveDate. */
	private Date originalActionEffectiveDate;
	/** The terminationAuthorityCode.  */
	private CodeSetElement originalAuthoritySection;
	/** The terminationAuthorityCode.  */
	private CodeSetElement terminationAuthorityCode;

	/**
	 * @return the driver
	 */
	public Person getDriver() {
		return driver;
	}

	/**
	 * @return the licenseLocation
	 */
	public CodeSetElement getLicenseLocation() {
		return licenseLocation;
	}

	/**
	 * @return the licenseSurrenderedProcessDate
	 */
	public Date getLicenseSurrenderedProcessDate() {
		return licenseSurrenderedProcessDate;
	}

	/**
	 * @return the originalActionEffectiveDate
	 */
	public Date getOriginalActionEffectiveDate() {
		return originalActionEffectiveDate;
	}

	/**
	 * @return the originalAuthoritySection
	 */
	public CodeSetElement getOriginalAuthoritySection() {
		return originalAuthoritySection;
	}

	/**
	 * @return the terminationAuthorityCode
	 */
	public CodeSetElement getTerminationAuthorityCode() {
		return terminationAuthorityCode;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(Person driver) {
		this.driver = driver;
	}

	/**
	 * @param licenseLocation the licenseLocation to set
	 */
	public void setLicenseLocation(CodeSetElement licenseLocation) {
		this.licenseLocation = licenseLocation;
	}

	/**
	 * @param licenseSurrenderedProcessDate the licenseSurrenderedProcessDate to set
	 */
	public void setLicenseSurrenderedProcessDate(
			Date licenseSurrenderedProcessDate) {
		this.licenseSurrenderedProcessDate = licenseSurrenderedProcessDate;
	}

	/**
	 * @param originalActionEffectiveDate the originalActionEffectiveDate to set
	 */
	public void setOriginalActionEffectiveDate(Date originalActionEffectiveDate) {
		this.originalActionEffectiveDate = originalActionEffectiveDate;
	}

	/**
	 * @param originalAuthoritySection the originalAuthoritySection to set
	 */
	public void setOriginalAuthoritySection(
			CodeSetElement originalAuthoritySection) {
		this.originalAuthoritySection = originalAuthoritySection;
	}

	/**
	 * @param terminationAuthorityCode the terminationAuthorityCode to set
	 */
	public void setTerminationAuthorityCode(
			CodeSetElement terminationAuthorityCode) {
		this.terminationAuthorityCode = terminationAuthorityCode;
	}
}
