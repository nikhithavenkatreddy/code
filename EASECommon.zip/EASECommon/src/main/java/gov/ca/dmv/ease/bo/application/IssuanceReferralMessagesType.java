/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application;

/**
 * Description: Enumeration of Issuance Referral Messages.
 * File: IssuanceReferralMessagesType.java
 * Module:  gov.ca.dmv.ease.bo.application
 * Created: May 14, 2010 
 * @author MWUXB  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/07/22 17:50:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum IssuanceReferralMessagesType {
	CERTIFICATION_OF_EXPERIENCE_SUBMITTED(15, "PENDING DL 170 VERIFICATION"), CHECK_CDLIS_OR_NDR_MATCHES(
			22, "CHECK CDLIS/PDPS MATCHES"), COE_OR_COURT_RESTRICTION_REMOVED(
			13, "COE OR COURT RESTRICTION REMOVED"), COMMERICAL_CHECK_CDL_OR_NDR(
			23, "***COMMERCIAL--CHECK CDLIS/PDPS***"), GENDER_CORRECTION_OR_CHANGE_PROCESSED(
			21, "GENDER CORR/CHANGE - DOCUMENTATION NEEDED"), MAIL_MILITARY_EXTENSION_CARD(
			14, "MAIL MILITARY EXTENSION CARD"), MOLOKEN_PHOTO_NOT_TAKEN(11,
			"MOLOKAN - NO PHOTO TAKEN - USE CORRECTION CAMERA"), MORE_THAN_15_HITS_ON_ANI(
			12, "ANI INQUIRY - MORE THAN 15 RECORDS - VERIFY"), NAME_SEX_DLNUMBER_OR_BIRTHDATE_CHANGED(
			17, "NAME OR BIRTHDATE CHANGE--CHANGE OR CANCEL ID CARD"), NEW_NUMBER_REQUESTED(
			16, "NEW PERMANENT NUMBER ASSIGNED"), PHOTO_BEING_HELD_OK_TO_RELEASE(
			5, "OK TO MAIL LIC/ID - ADD RESTR/EXP YEAR IF NEC"), PHOTO_PREVIOUSLY_TAKEN_APPLICATION_VOIDED(
			7, "DESTROY PRIOR PHOTO IN HOLD FILE"), PHOTO_PRINTED_WITH_NO_DL_NUMBER(
			3, "ADD DL#/SP# TO LICENSE/ID CARD"), PHOTO_PRINTED_WITH_NO_EXPIRY_DATE(
			4, "ADD EXPIRATION YEAR TO LICENSE/ID CARD"), PHOTO_RETAKE_STATUS_SET_DESTROY_PRIOR_PHOTO(
			18, "PHOTO RETAKE STATUS SET - DESTROY PHOTO LICENSE/ID CARD"), PHOTO_TAKEN_BEFORE_COMPLETION(
			2, "PHOTO TAKEN BEFORE COMPLETION - HOLD LICENSE/ID CARD"), PHOTO_TAKEN_ON_R_OUT_REC(
			10, "ROUTE TO RCA FOR REVIEW"), PROJECT_OR_KEYED_EXPIRATION_DATES_NOT_EQUAL(
			9, "CHECK/CORRECT EXP YEAR"), RECORD_PROCESSED_WITH_CNA(8,
			"CNA CONDITION - VERIFY RECORD STATUS"), RECORD_PROCESSED_WITH_NO_DL_NUMBER(
			6, "TRANSACTION CODE VALIDATION BYPASSED"),
	//This is the list of Issuance Referral Messages on the Issuance Referral Document.
	RECORDS_TO_BE_COMBINED(0, "RECORDS TO BE COMBINED"), ROUTE_TO_RSA_PREVIOUS_FRAUD(
			19, "ROUTE TO RCA - PREVIOUS FRAUD APP"), ROUTE_TO_RSA_SUSPECTED_FRAUD(
			20, "ROUTE TO RCA - SUSPECTED FRAUD APP"), STOPS_WERE_BYPASSED(1,
			"STOP BYPASSED - VERIFY RECORD STATUS");
	private final String description;
	private final int indicator;

	/**
	 * Instantiates a new issuance referral messages type.
	 * 
	 * @param indicator the indicator
	 * @param description the description
	 */
	private IssuanceReferralMessagesType(int indicator, String description) {
		this.indicator = indicator;
		this.description = description;
	}

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Gets the indicator.
	 * 
	 * @return the indicator
	 */
	public int getIndicator() {
		return indicator;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: IssuanceReferralMessagesType.java,v $
 *  Revision 1.4  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.3  2010/06/21 23:01:05  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.1.6.2  2010/06/20 18:07:15  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.2  2010/06/05 22:13:41  mwuxb
 *  update # 18 entry
 *
 *  Revision 1.1  2010/05/15 01:01:08  mwuxb
 *  Initial commit
 *
*/
