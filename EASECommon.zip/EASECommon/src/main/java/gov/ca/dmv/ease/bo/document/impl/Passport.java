/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

/**
 * Description: Passport is subclass of LegalPresenceDocument.
 * File: Passport.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Jul 11, 2009
 * @author MWRRV3
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/04/07 04:04:57 $
 * Last Changed By: $Author: mwhys $
 */
public class Passport extends LegalPresenceDocument {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9023177817117659526L;
	/** Holds the passport number. */
	private String passportNumber;
	
	/**
	 * Default Constructor.
	 * 
	 */
	public Passport() {
	}
	
	/**
	 * Copy constructor
	 */
	public Passport(Passport passport) {
		super();
		copy(passport);
	}
	
	/**
	 * Copy.
	 *
	 * @param document the document
	 */
	protected void copy(Passport passport) {
		if (passport == null) {
			throw new EaseValidationException(
					"non-null passport argument expected in copy method in "
							+ this);
		}
		super.copy(passport);
		setPassportNumber(passport.getPassportNumber());
	}
	
	/**
	 * Gets the passport number.
	 * 
	 * @return the passport number
	 */
	public String getPassportNumber() {
		return passportNumber;
	}
	
	/**
	 * Sets the passport number.
	 * 
	 * @param passportNumber the new passport number
	 */
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("passportNumber", passportNumber, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((passportNumber == null) ? 0 : passportNumber.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passport other = (Passport) obj;
		if (passportNumber == null) {
			if (other.passportNumber != null)
				return false;
		}
		else if (!passportNumber.equals(other.passportNumber))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Passport.java,v $
 *  Revision 1.6  2011/04/07 04:04:57  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.5.6.2  2011/04/05 18:55:36  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *  Generated hashCode() and equals() methods.
 *
 *  Revision 1.5  2011/01/17 01:20:10  mwpxp2
 *  Builk cleanup
 *
 *  Revision 1.4  2010/12/07 22:08:36  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.3  2010/12/07 02:42:34  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.2  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/02/08 22:05:53  mwrsk
 *  Remove DocumentType Changes
 *
 *  Revision 1.2  2010/01/11 21:38:44  mwhxa2
 *  Updated constructor
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.8  2009/10/15 17:46:39  mwrka1
 *  removed default constructor
 *
 *  Revision 1.7  2009/10/13 17:20:22  mwtjc1
 *  getPassportNumber and setPassportNumber methods are made public
 *
 *  Revision 1.6  2009/08/27 05:39:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.5  2009/08/04 16:58:17  mwyxg1
 *  update document
 *
 *  Revision 1.4  2009/08/04 16:56:01  mwyxg1
 *  add constructor, update comments
 *
 *  Revision 1.3  2009/07/14 23:44:34  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.2  2009-07-12 15:28:06  ppalacz
 *  Bulk format
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 
 *  $
 *  $Revision 1.1  May 4, 2009 4:40:12 PM  MWCSJ3
 *  $Initial
 *  $
 */
