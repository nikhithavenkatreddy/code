/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class is used for Address change or inquiry transactions.
 * Use the address locator property in the Person class to capture changed address
 * File: AddressChangeApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 14, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class AddressChangeApplication extends Application {

	private static final long serialVersionUID = -5672729999246649005L;
	/** Is Correction Only for an existing address. */
	private Boolean isCorrectionOnly;
	/** The voter registration requested. */
	private CodeSetElement voterRegistationRequestedCode;

	/**
	 * @return the voterRegistationRequestedCode
	 */
	public CodeSetElement getVoterRegistationRequestedCode() {
		return voterRegistationRequestedCode;
	}

	/**
	 * Gets the Correction Only.
	 * 
	 * @return the isCorrectionOnly
	 */
	public Boolean isCorrectionOnly() {
		return isCorrectionOnly;
	}

	/**
	 * Sets the Correction Only.
	 * 
	 * @param isCorrectionOnly the isCorrectionOnly to set
	 */
	public void setCorrectionOnly(Boolean isCorrectionOnly) {
		this.isCorrectionOnly = isCorrectionOnly;
	}

	/**
	 * @param voterRegistationRequestedCode the voterRegistationRequestedCode to set
	 */
	public void setVoterRegistationRequestedCode(
			CodeSetElement voterRegistationRequestedCode) {
		this.voterRegistationRequestedCode = voterRegistationRequestedCode;
	}
}
