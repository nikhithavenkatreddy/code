/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.financial.FeePaidCheckType;
import gov.ca.dmv.ease.bo.financial.FeeStatusType;
import gov.ca.dmv.ease.bo.financial.IFeeRateCodeConstants;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;

/**
 * Description: Invoice class is used to get the invoice details of an
 * application (DL or VR Application) uses the InvoiceItem collection, which in
 * turn uses the Fee object to get fees for each invoice item. 
 * //TODO - given that the code allows only a single payment per type, using List<Payment> is questionable and possibly wrong
 * //TODO - accessors are not lazy, and the related lists are set externally - setting using a constructor or a method with "addAll: semantics would be preferable
 * //TODO - some constants are still hard-coded and have no clear meaning -> maintenance hazard
 * //TODO - there are still methods whose names violate naming conventions
 * 
 * File: Invoice.java 
 * Module: gov.ca.dmv.ease.bo.financial.impl 
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.26 $ 
 * Last Changed: $Date: 2012/08/15 16:22:57 $ 
 * Last Changed By: $Author: mwrrv3 $
 */
public class Invoice extends BusinessObject implements IFeeRateCodeConstants {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 629152380906995411L;
	/** This is invoice amount and it comes from mainframe */
	private BigDecimal amount;
	/** Fee Refund Action Code. H - Headquarters Refund, C - Cash Refund */
	private CodeSetElement feeRefundActionCode;
	/** The details of the Headquarter Refund if there is an over payment of the invoice */
	private HeadquarterRefundDetail headquarterRefundDetail;
	/** The invoice item. */
	//InvoiceItems contains Max 2 Elements - 1st is for DLA, 2nd is for CDA
	private List <InvoiceItem> invoiceItems;
	/** The payment. */
	private List <Payment> payments;
	/** The receipt. */
	private Receipt receipt;
	/** The total fee waived. */
	private BigDecimal totalFeeWaived;

	/** Default Constructor */
	public Invoice() {
	}

	/**
	 * Adds the fee.
	 * 
	 * @param fee
	 *            the fee
	 */
	public void addFee(Fee fee) {
		InvoiceItem item = new InvoiceItem();
		item.setFee(fee);
		//TODO replace invoiceItems with lazy getter
		invoiceItems.add(item);
	}

	/**
	 * Adds the payment.
	 * 
	 * @param payment
	 *            the payment
	 */
	public void addPayment(Payment payment) {
		//TODO replace payments with lazy getter
		payments.add(payment);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Invoice other = (Invoice) obj;
		if (amount == null) {
			if (other.amount != null) {
				return false;
			}
		}
		else if (!amount.equals(other.amount)) {
			return false;
		}
		if (feeRefundActionCode == null) {
			if (other.feeRefundActionCode != null) {
				return false;
			}
		}
		else if (!feeRefundActionCode.equals(other.feeRefundActionCode)) {
			return false;
		}
		if (invoiceItems == null) {
			if (other.invoiceItems != null) {
				return false;
			}
		}
		else if (!invoiceItems.equals(other.invoiceItems)) {
			return false;
		}
		if (payments == null) {
			if (other.payments != null) {
				return false;
			}
		}
		else if (!payments.equals(other.payments)) {
			return false;
		}
		if (receipt == null) {
			if (other.receipt != null) {
				return false;
			}
		}
		else if (!receipt.equals(other.receipt)) {
			return false;
		}
		if (totalFeeWaived == null) {
			if (other.totalFeeWaived != null) {
				return false;
			}
		}
		else if (!totalFeeWaived.equals(other.totalFeeWaived)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the add restriction id fee multiplication indicator.
	 * 
	 * @return the add restriction id fee multiplication indicator
	 */
	public int getAddRestrictionIdFeeMultiplicationIndicator() {
		return getMultiplicationIndicatorForExpectedFeeRateCode(ADD_RESTRICTION_IGNITION_INTERLOCK_DEVICE_FEE_RATE_CODE);
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * This method returns Invoice balance type (OVER or UNDER).
	 * 
	 * @return the balanceType
	 */
	public String getBalanceType() {
		String balanceType = "";
		if (getNetAmount().doubleValue() > 0) {
			balanceType = FEE_AMOUNT_OVER;
		}
		else if (getNetAmount().doubleValue() < 0) {
			balanceType = FEE_AMOUNT_UNDER;
		}
		return balanceType;
	}

	/**
	 * Gets the cash payment.
	 * 
	 * @return the cash payment
	 */
	public CashPayment getCashPayment() {
		CashPayment cashPayment = null;
		for (Payment payment : getPayments()) {
			if (payment instanceof CashPayment) {
				cashPayment = (CashPayment) payment;
				break;
			}
		}
		return cashPayment;
	}

	/**
	 * Gets the check payment.
	 * 
	 * @return the check payment
	 */
	public List <CheckPayment> getCheckPayments() {
		List <CheckPayment> checkPayments = new ArrayList <CheckPayment>();
		for (Payment payment : getPayments()) {
			if (payment instanceof CheckPayment) {
				checkPayments.add((CheckPayment) payment);
			}
		}
		return checkPayments;
	}

	/**
	 * Gets the credit payment.
	 * 
	 * @return the credit payment
	 */
	public CreditPayment getCreditPayment() {
		CreditPayment creditPayment = null;
		for (Payment payment : getPayments()) {
			if (payment instanceof CreditPayment) {
				creditPayment = (CreditPayment) payment;
				break;
			}
		}
		return creditPayment;
	}

	/**
	 * Gets the debit payment.
	 * 
	 * @return the debit payment
	 */
	public DebitPayment getDebitPayment() {
		for (Payment aPayment : getPayments()) {
			if (aPayment.isDebit()) {
				return (DebitPayment) aPayment;
			}
		}
		return null;
	}

	/**
	 * Gets the manual credit payment.
	 * 
	 * @return the manual credit payment
	 */
	public List <DebitPayment> getDebitPayments() {
		List <DebitPayment> manualCredits = new ArrayList <DebitPayment>();
		for (Payment payment : getPayments()) {
			if (payment instanceof DebitPayment) {
				manualCredits.add(((DebitPayment) payment));
			}
		}
		return manualCredits;
	}

	/**
	 * This method will fetch the Driver License Fee Information.
	 * 
	 * @return the driver license fee
	 */
	public DriverLicenseFee getDriverLicenseFee() {
		if (!hasInvoiceItems()) {
			//No Invoice Items Present
			return null;
		}
		else {
			//Driver License Transactions can have only one Invoice Item. 
			InvoiceItem processInvoiceItem = getInvoiceItems().get(0);
			//Check for DLA Fee
			return processInvoiceItem.getDriverLicenceFee();
		}
	}

	/**
	 * Gets the driver license reissue fee rate code type.
	 * 
	 * This method returns the type of reissue fee rate code such as type 1, type 2, type 3. 
	 * 
	 * @return the driver license reissue fee rate code type
	 */
	public String getDriverLicenseReissueFeeRateCodeType() {
		String reissueRateCodeType = null;
		DriverLicenseFee dlFee = getDriverLicenseFee();
		if (dlFee != null) {
			String feeRateCode = "";
			for (DriverLicenseRateStatus driverLicenseRateStatus : dlFee
					.getDriverLicenseRateStatuses()) {
				feeRateCode = driverLicenseRateStatus.getFeeRatecode()
						.getCode().trim();
				if (feeRateCode
						.equals(DRIVER_LICENSE_REISSUE_TYPE_01_FEE_RATE_CODE)) {
					reissueRateCodeType = "1";
					break;
				}
				else if (feeRateCode
						.equals(DRIVER_LICENSE_REISSUE_TYPE_02_FEE_RATE_CODE)) {
					reissueRateCodeType = "2";
					break;
				}
				else if (feeRateCode
						.equals(DRIVER_LICENSE_REISSUE_TYPE_03_FEE_RATE_CODE)) {
					reissueRateCodeType = "3";
					break;
				}
				else if (feeRateCode
						.equals(DRIVER_LICENSE_REISSUE_TYPE_04_FEE_RATE_CODE)) {
					reissueRateCodeType = "4";
					break;
				}
				else if (feeRateCode
						.equals(DRIVER_LICENSE_REISSUE_TYPE_05_FEE_RATE_CODE)) {
					reissueRateCodeType = "5";
					break;
				}
			}
		}
		return reissueRateCodeType;
	}

	/**
	 * Gets the drug screening reissue fee multiplication indicator.
	 * 
	 * @return the drug screening reissue fee multiplication indicator
	 */
	public int getDrugScreeningReissueFeeMultiplicationIndicator() {
		return getMultiplicationIndicatorForExpectedFeeRateCode(DRUG_SCREENING_REISSUE_FEE_RATE_CODE);
	}

	/**
	 * Gets the family law due fee multiplication indicator.
	 * 
	 * @return the family law due fee multiplication indicator
	 */
	public int getFamilyLawDueFeeMultiplicationIndicator() {
		return getMultiplicationIndicatorForExpectedFeeRateCode(FAMILY_LAW_DUE_FEE_RATE_CODE);
	}

	/**
	 * @return the feeActionCode
	 */
	public CodeSetElement getFeeRefundActionCode() {
		return feeRefundActionCode;
	}

	/**
	 * Gets the fee refund action code string.
	 * 
	 * @return the fee refund action code string
	 */
	public String getFeeRefundActionCodeString() {
		if (feeRefundActionCode == null) {
			return " ";
		}
		else {
			return feeRefundActionCode.getCode();
		}
	}

	/**
	 * Gets the Head Quarter Refund Detail.
	 * 
	 * @return the headquarterRefundDetail
	 */
	public HeadquarterRefundDetail getHeadquarterRefundDetail() {
		return headquarterRefundDetail;
	}

	/**
	 * Gets the invoice item.
	 * 
	 * @return the invoiceItem
	 */
	public List <InvoiceItem> getInvoiceItems() {
		if (invoiceItems == null) {
			setInvoiceItems(new ArrayList <InvoiceItem>());
		}
		return invoiceItems;
	}

	/**
	 * Gets the invoice total.
	 * 
	 * @return the invoice total
	 */
	public BigDecimal getInvoiceTotal() {
		BigDecimal totalAmount = new BigDecimal(0);
		double amt = 0;
		double waivedAmount = 0;
		for (InvoiceItem item : getInvoiceItems()) {
			if (item.getWaivedAmount() != null) {
				waivedAmount += item.getWaivedAmount().doubleValue();
			}
			if (item.getFee() != null && item.getFee().getAmount() != null) {
				amt += item.getFee().getAmount().doubleValue();
			}
		}
		return totalAmount.add(new BigDecimal(amt - waivedAmount,
				MathContext.DECIMAL32));
	}

	/**
	 * Gets the multiplication indicator for expected fee rate code.
	 * 
	 * This method returns Multiplication Indicator (count) of the 
	 * same DriverLicenseRateStatus for the given fee rate code.
	 * Note - Multiplication Indicator concept applies to only fee selected fee rate codes. 
	 * 
	 * @param expectedFeeRateCode the expected fee rate code
	 * @return the multiplication indicator for expected fee rate code
	 */
	private int getMultiplicationIndicatorForExpectedFeeRateCode(
			String expectedFeeRateCode) {
		int muplicationIndicator = 0;
		DriverLicenseFee dlFee = getDriverLicenseFee();
		if (dlFee != null) {
			String feeRateCode = "";
			for (DriverLicenseRateStatus driverLicenseRateStatus : dlFee
					.getDriverLicenseRateStatuses()) {
				feeRateCode = driverLicenseRateStatus.getFeeRatecode()
						.getCode().trim();
				//Check for fee type.
				if (expectedFeeRateCode.equals(feeRateCode)) {
					//For matching fee rate code - increment the multiplication indicator. 
					muplicationIndicator += 1;
				}
			}
		}
		return muplicationIndicator;
	}

	/**
	 * Gets the amount difference.
	 * 
	 * @return the amount difference
	 */
	public BigDecimal getNetAmount() {
		return getPaymentTotal().subtract(getInvoiceTotal());
	}

	/**
	 * Gets the net amount status message. Returns - OVER, UNDER based on the Net Amount. 
	 *
	 * @return the net amount status message
	 */
	public String getNetAmountStatusMessage() {
		String statusMessage = "";
		if (getNetAmount() != null) {
			if (getNetAmount().intValue() > 0) {
				statusMessage = FEE_AMOUNT_OVER;
			}
			else if (getNetAmount().intValue() < 0) {
				statusMessage = FEE_AMOUNT_UNDER;
			}
		}
		return statusMessage;
	}

	/**
	 * Gets the payment.
	 * 
	 * @return the payment
	 */
	public List <Payment> getPayments() {
		if (payments == null) {
			setPayments(new ArrayList <Payment>());
		}
		return payments;
	}

	/**
	 * Gets the total payment amount.
	 * 
	 * @return the total payment amount
	 */
	public BigDecimal getPaymentTotal() {
		BigDecimal totalAmtPaid = new BigDecimal(0);
		double amt = 0;
		for (Payment aPayment : getPayments()) {
			if (aPayment.getAmount() != null) {
				if (aPayment instanceof Voucher) {
					Voucher voucher = (Voucher) aPayment;
					if ((!EaseUtil.isNullOrBlank(voucher.getStatusCode()) && voucher
							.getStatusCode().getCode().equalsIgnoreCase(
									IGNORE_VOUCHER_CODE))) {
						continue; // Ignore Voucher payment having 'Ignore (I)' status code
					}
				}
				amt += aPayment.getAmount().doubleValue();
			}
		}
		return totalAmtPaid.add(new BigDecimal(amt, MathContext.DECIMAL32));
	}

	/**
	 * Gets the phase1 total vouchers amount.
	 * 
	 * @return the phase1 total vouchers amount
	 */
	public BigDecimal getPhase1TotalVouchersAmount() {
		return getTotalVouchersAmountForPhase("1");
	}

	/**
	 * Gets the phase2 total vouchers amount.
	 * 
	 * @return the phase2 total vouchers amount
	 */
	public BigDecimal getPhase2TotalVouchersAmount() {
		return getTotalVouchersAmountForPhase("2");
	}

	/**
	 * Gets the preliminary alcohol screening fee multiplication indicator.
	 * 
	 * @return the preliminary alcohol screening fee multiplication indicator
	 */
	public int getPreliminaryAlcoholScreeningFeeMultiplicationIndicator() {
		return getMultiplicationIndicatorForExpectedFeeRateCode(PRELIMINARY_ALCOHOL_SCREENING_REISSUE_FEE_RATE_CODE);
	}

	/**
	 * Gets the receipt.
	 * 
	 * @return the receipt
	 */
	public Receipt getReceipt() {
		return receipt;
	}

	/**
	 * Returns the total manual credit payment.
	 * 
	 * @return
	 */
	public BigDecimal getTotaDebitPaymentsAmount() {
		double totalManualCreditPaymentsAmount = 0;
		List <DebitPayment> manualCreditPayments = getDebitPayments();
		for (DebitPayment manualCreditPayment : manualCreditPayments) {
			if (manualCreditPayment != null
					&& manualCreditPayment.getAmount() != null) {
				totalManualCreditPaymentsAmount += manualCreditPayment
						.getAmount().doubleValue();
			}
		}
		return new BigDecimal(totalManualCreditPaymentsAmount);
	}

	/**
	 * Returns the total checks amount.
	 * 
	 * @return
	 */
	public BigDecimal getTotalChecksAmount() {
		double chkAmt = 0;
		//List <CheckPayment> checkPayments = getCheckPayments();
		for (CheckPayment checkPayment : getCheckPayments()) {
			if (checkPayment != null && checkPayment.getAmount() != null) {
				chkAmt += checkPayment.getAmount().doubleValue();
			}
		}
		return new BigDecimal(chkAmt);
	}

	/**
	 * Gets the total fee waived.
	 * 
	 * @return the totalFeeWaived
	 */
	public BigDecimal getTotalFeeWaived() {
		return totalFeeWaived;
	}

	/**
	 * Returns the total vouchers amount.
	 * 
	 * @return
	 */
	public BigDecimal getTotalVouchersAmount() {
		double totalVoucherAmount = 0;
		List <Voucher> vouchers = getVoucherPayments();
		for (Voucher voucher : vouchers) {
			// Consider a Voucher only if status code is Credit (C).  
			if (voucher != null
					&& voucher.getAmount() != null
					&& voucher.getStatusCode().getCode().equalsIgnoreCase(
							CREDIT_VOUCHER_CODE)) {
				totalVoucherAmount += voucher.getAmount().doubleValue();
			}
		}
		return new BigDecimal(totalVoucherAmount);
	}

	/**
	 * Gets the total vouchers amount for phase.
	 * 
	 * @param phaseNumber the phase number
	 * 
	 * @return the total vouchers amount for phase
	 */
	private BigDecimal getTotalVouchersAmountForPhase(String phaseNumber) {
		double totalVoucherAmount = 0;
		for (Voucher voucher : getVoucherPayments()) {
			// Consider a Voucher only if status code is Credit (C).  
			if (voucher != null
					&& voucher.getAmount() != null
					&& voucher.getStatusCode().getCode().equalsIgnoreCase(
							CREDIT_VOUCHER_CODE)
					&& voucher.getReceiptPhaseNumber().equalsIgnoreCase(
							phaseNumber)) {
				totalVoucherAmount += voucher.getAmount().doubleValue();
			}
		}
		return new BigDecimal(totalVoucherAmount);
	}

	/**
	 * Gets the voucher payment.
	 * 
	 * @return the voucher payment
	 */
	public Voucher getVoucherPayment() {
		for (Payment payment : getPayments()) {
			if (payment instanceof Voucher) {
				return (Voucher) payment;
			}
		}
		return null;
	}

	/**
	 * Gets the voucher payment.
	 * 
	 * @return the voucher payment
	 */
	public List <Voucher> getVoucherPayments() {
		List <Voucher> vouchers = new ArrayList <Voucher>();
		for (Payment payment : getPayments()) {
			if (payment instanceof Voucher) {
				vouchers.add(((Voucher) payment));
			}
		}
		return vouchers;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime
				* result
				+ ((feeRefundActionCode == null) ? 0 : feeRefundActionCode
						.hashCode());
		result = prime * result
				+ ((invoiceItems == null) ? 0 : invoiceItems.hashCode());
		result = prime * result
				+ ((payments == null) ? 0 : payments.hashCode());
		result = prime * result + ((receipt == null) ? 0 : receipt.hashCode());
		result = prime * result
				+ ((totalFeeWaived == null) ? 0 : totalFeeWaived.hashCode());
		return result;
	}

	public boolean hasInvoiceItems() {
		if (invoiceItems == null) {
			return false;
		}
		else {
			return !getInvoiceItems().isEmpty();
		}
	}

	/**
	 * This method checks if CDL Application Fee is Paid Indicator.
	 * 
	 * @return true if CDL Application Fee is Paid
	 *         false if not Paid
	 *         null if not applicable
	 */
	public Boolean isCdlApplicationFeePaidIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.CDL_APP_FEE_PAID_CHECK, FeeStatusType.FEE_PAID);
	}

	/**
	 * This method checks if CDL Drive Test Fee Used Indicator.
	 * 
	 * @return true if CDL Drive Test Fee is Used
	 *         false if not Used
	 *         null if not applicable
	 */
	public Boolean isCdlDriveTestFeeUsedIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.CDL_DRIVE_TEST_FEE_USED_CHECK,
				FeeStatusType.FEE_USED);
	}

	/**
	 * This method checks if Driver License Fee is Paid.
	 * 
	 * @param feePaidCheckType the Fee Paid Check Type
	 * @param feeStatusType 
	 * @return true if Fee is Paid/Used/Due
	 *         false if not paid
	 *         null if not applicable
	 */
	public Boolean isFeeStatusAppliedIndicator(
			FeePaidCheckType feePaidCheckType, FeeStatusType feeStatusType) {
		Boolean returnFlag = false;
		DriverLicenseFee dlFee = getDriverLicenseFee();
		if (dlFee == null) {
			return false;
		}
		else {
			returnFlag = false;
			String feeRateDesc = "";
			for (DriverLicenseRateStatus driverLicenseRateStatus : dlFee
					.getDriverLicenseRateStatuses()) {
				feeRateDesc = driverLicenseRateStatus.getFeeRatecode()
						.getDescription();
				//Check for Fee Type
				if (feePaidCheckType.equals(feeRateDesc)
						&& driverLicenseRateStatus.getFeeStatusTypes()
								.contains(FeeStatusType.FEE_PAID)
						&& feeStatusType.equals(FeeStatusType.FEE_PAID)) {
					returnFlag = true;
					break;
				}
				else if (feePaidCheckType.equals(feeRateDesc)
						&& driverLicenseRateStatus.getFeeStatusTypes()
								.contains(FeeStatusType.FEE_DUE)
						&& feeStatusType.equals(FeeStatusType.FEE_DUE)) {
					returnFlag = true;
					break;
				}
				else if (feePaidCheckType.equals(feeRateDesc)
						&& driverLicenseRateStatus.getFeeStatusTypes()
								.contains(FeeStatusType.FEE_USED)
						&& feeStatusType.equals(FeeStatusType.FEE_USED)) {
					returnFlag = true;
					break;
				}
				//				else if (feePaidCheckType
				//						.equals(FeePaidCheckType.FIRE_FIGHTER_APP_FEE_PAID_CHECK)
				//						&& FIRE_FIGHTER_APPLICATION_FEE_RATE_CODE
				//								.equals(feeRateDesc)
				//						&& driverLicenseRateStatus.getFeeStatusTypes()
				//								.contains(FeeStatusType.FEE_PAID)) {
				//					isFeePaidCheckIndicator = true;
				//					break;
				//				}
				//				else if (feePaidCheckType
				//						.equals(FeePaidCheckType.CDL_DRIVE_TEST_FEE_USED_CHECK)
				//						&& CDL_DRIVE_TEST_FEE_RATE_CODE.equals(feeRateDesc)
				//						&& driverLicenseRateStatus.getFeeStatusTypes()
				//								.contains(FeeStatusType.FEE_USED)) {
				//					isFeePaidCheckIndicator = true;
				//					break;
				//				}
				//				else if (NON_CDL_RETEST_FEE_RATE_CODE.equals(feeRateDesc)) {
				//					if ((feePaidCheckType
				//							.equals(FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_DUE_CHECK) && driverLicenseRateStatus
				//							.getFeeStatusTypes()
				//							.contains(FeeStatusType.FEE_DUE))
				//							|| (feePaidCheckType
				//									.equals(FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_USED_CHECK) && driverLicenseRateStatus
				//									.getFeeStatusTypes().contains(
				//											FeeStatusType.FEE_USED))
				//							|| (feePaidCheckType
				//									.equals(FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_PAID_CHECK) && driverLicenseRateStatus
				//									.getFeeStatusTypes().contains(
				//											FeeStatusType.FEE_NOT_PAID))) {
				//						isFeePaidCheckIndicator = true;
				//						break;
				//					}
				//				}
				//				else if (MOTORCYCLE_RETEST_FEE_RATE_CODE.equals(feeRateDesc)) {
				//					if ((feePaidCheckType
				//							.equals(FeePaidCheckType.MOTORCYCLE_RETEST_FEE_DUE_CHECK) && driverLicenseRateStatus
				//							.getFeeStatusTypes()
				//							.contains(FeeStatusType.FEE_DUE))
				//							|| (feePaidCheckType
				//									.equals(FeePaidCheckType.MOTORCYCLE_RETEST_FEE_USED_CHECK) && driverLicenseRateStatus
				//									.getFeeStatusTypes().contains(
				//											FeeStatusType.FEE_USED))
				//							|| (feePaidCheckType
				//									.equals(FeePaidCheckType.MOTORCYCLE_RETEST_FEE_PAID_CHECK) && driverLicenseRateStatus
				//									.getFeeStatusTypes().contains(
				//											FeeStatusType.FEE_NOT_PAID))) {
				//						isFeePaidCheckIndicator = true;
				//						break;
				//					}
				//				}
			}
		}
		return returnFlag;
	}

	/**
	 * This method checks if Fire Fighter Application Fee is Paid Indicator.
	 * 
	 * @return true if Fire Fighter Application Fee is Paid
	 *         false if not Paid
	 *         null if not applicable
	 */
	public Boolean isFireFighterApplicationFeePaidIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.FIRE_FIGHTER_APP_FEE_PAID_CHECK,
				FeeStatusType.FEE_PAID);
	}

	/**
	 * This method checks if Motor Cycle Re-test Fee Due Indicator.
	 * 
	 * @return true if Motor Cycle Re-test is Due
	 *         false if not Due
	 *         null if not applicable
	 */
	public Boolean isMotorCycleRetestFeeDueIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.MOTORCYCLE_RETEST_FEE_DUE_CHECK,
				FeeStatusType.FEE_DUE);
	}

	/**
	 * This method checks if Motor Cycle Re-test Fee Paid Indicator.
	 * 
	 * @return true if Motor Cycle Re-test Fee is Paid
	 *         false if not paid
	 *         null if not applicable
	 */
	public Boolean isMotorCycleRetestFeePaidIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.MOTORCYCLE_RETEST_FEE_PAID_CHECK,
				FeeStatusType.FEE_PAID);
	}

	/**
	 * This method checks if Motor Cycle Re-test Fee Used Indicator.
	 * 
	 * @return true if Motor Cycle Re-test is Used
	 *         false if not Used
	 *         null if not applicable
	 */
	public Boolean isMotorCycleRetestFeeUsedIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.MOTORCYCLE_RETEST_FEE_USED_CHECK,
				FeeStatusType.FEE_USED);
	}

	/**
	 * This method checks if Non Commercial Re-test Fee Due Indicator.
	 * 
	 * @return true if Non Commercial Re-test Fee is Due
	 *         false if not Due
	 *         null if not applicable
	 */
	public Boolean isNonCommercialRetestFeeDueIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_DUE_CHECK,
				FeeStatusType.FEE_DUE);
	}

	/**
	 * This method checks if Non Commercial Re-test Fee Paid Indicator.
	 * 
	 * @return true if Non Commercial Re-test Fee is Paid
	 *         false if not Paid
	 *         null if not applicable
	 */
	public Boolean isNonCommercialRetestFeePaidIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_PAID_CHECK,
				FeeStatusType.FEE_PAID);
	}

	/**
	 * This method checks if Non Commercial Re-test Fee Used Indicator.
	 * 
	 * @return true if Non Commercial Re-test Fee is Used
	 *         false if not Used
	 *         null if not applicable
	 */
	public Boolean isNonCommercialRetestFeeUsedIndicator() {
		return isFeeStatusAppliedIndicator(
				FeePaidCheckType.NON_COMMERCIAL_RETEST_FEE_USED_CHECK,
				FeeStatusType.FEE_USED);
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * Sets the Cash Payment.
	 * 
	 * @param cashPayment the Cash Payment
	 */
	public void setCashPayment(CashPayment cashPayment) {
		addPayment(cashPayment);
	}

	/**
	 * @param feeActionCode
	 *            the feeActionCode to set
	 */
	public void setFeeRefundActionCode(CodeSetElement feeActionCode) {
		this.feeRefundActionCode = feeActionCode;
	}

	/**
	 * Sets the Head Quarter Refund Detail.
	 * 
	 * @param headquarterRefundDetail the headquarterRefundDetail to set
	 */
	public void setHeadquarterRefundDetail(
			HeadquarterRefundDetail headquarterRefundDetail) {
		this.headquarterRefundDetail = headquarterRefundDetail;
	}

	/**
	 * Sets the invoice item.
	 * 
	 * @param invoiceItem
	 *            the invoiceItem to set
	 */
	public void setInvoiceItems(List <InvoiceItem> invoiceItem) {
		this.invoiceItems = invoiceItem;
	}

	/**
	 * Sets the payment.
	 * 
	 * @param payment
	 *            the payment to set
	 */
	public void setPayments(List <Payment> payment) {
		//TODO this should be lazy accessor and not public
		//TODO it is used in place of "addAll"
		payments = payment;
	}

	/**
	 * Sets the receipt.
	 * 
	 * @param receipt
	 *            the receipt
	 */
	public void setReceipt(Receipt receipt) {
		this.receipt = receipt;
	}

	/**
	 * Sets the total fee waived.
	 * 
	 * @param totalFeeWaived
	 *            the totalFeeWaived to set
	 */
	public void setTotalFeeWaived(BigDecimal totalFeeWaived) {
		this.totalFeeWaived = totalFeeWaived;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("amount", amount, anIndent, aBuilder);
		outputKeyValue("feeRefundActionCode", feeRefundActionCode, anIndent,
				aBuilder);
		outputKeyValue("headquarterRefundDetail", headquarterRefundDetail,
				anIndent, aBuilder);
		outputKeyValue("invoiceItems", invoiceItems, anIndent, aBuilder);
		outputKeyValue("payments", payments, anIndent, aBuilder);
		outputKeyValue("receipt", receipt, anIndent, aBuilder);
		outputKeyValue("totalFeeWaived", totalFeeWaived, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 * Modification History:
 * 
 * $Log: Invoice.java,v $
 * Revision 1.26  2012/08/15 16:22:57  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.25  2011/01/28 08:30:31  mwpxr4
 * Updated methods for applied fee status type for a given fee check type.
 *
 * Revision 1.24  2010/12/24 01:20:51  mwrrv2
 * Updated.
 *
 * Revision 1.23  2010/12/08 20:52:17  mwpxp2
 * Imports adjusted for interface move
 *
 * Revision 1.22  2010/12/07 22:08:32  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.21  2010/12/07 03:03:12  mwpxp2
 * Added toStringOn/1; sorted
 *
 * Revision 1.20  2010/12/07 00:29:39  mwpxp2
 * Made gets on lists lazy; simplified getters using iteration; got rid of iterators
 *
 * Revision 1.19  2010/12/04 01:05:25  mwpxp2
 * Added getFeeRefundActionCodeString
 *
 * Revision 1.18  2010/12/02 00:15:46  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.17  2010/10/19 20:50:34  mwtjc1
 * null check for voucher.getStatusCode() added
 *
 * Revision 1.16  2010/09/22 20:35:42  mwcsj3
 * Fixed few TO DO's
 *
 * Revision 1.15  2010/07/22 17:50:29  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.14  2010/07/08 16:59:31  mwpxr4
 * Renamed methods.
 *
 * Revision 1.13  2010/07/07 19:08:54  mwpxp2
 * Added several todos
 *
 * Revision 1.12  2010/06/24 00:50:06  mwtjc1
 * null checks if (paymentSet != null) are kept
 *
 * Revision 1.11  2010/05/10 17:08:23  mwuxb
 * Changed String to CodeSetElement for attribute statusCode in Voucher
 *
 * Revision 1.10  2010/05/10 01:12:20  mwsxd10
 * StatusCode is changed from CodeSetElement to String.
 *
 * Revision 1.9  2010/05/06 15:24:20  mwuxb
 * Added helper methods for Phase 1 and Phase 2 Vouchers
 *
 * Revision 1.8  2010/05/05 01:02:43  mwuxb
 * Added Helper method.
 *
 * Revision 1.7  2010/05/05 00:33:14  mwuxb
 * Removed attribute netDifferenceCode
 *
 * Revision 1.6  2010/05/04 18:31:44  mwuxb
 * Added attribute netDifferenceCode
 *
 * Revision 1.5  2010/04/26 22:20:11  mwhxb3
 * Increment multiplication indicator by 1.
 *
 * Revision 1.4  2010/04/26 20:44:52  mwhxa2
 * moved fee rate codes to constants file
 *
 * Revision 1.3  2010/04/24 21:36:09  mwuxb
 * Added helper method to get Driver License Fee
 *
 * Revision 1.2  2010/04/24 18:31:51  mwuxb
 * Added new fee rate codes for misc transactions.
 *
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.18  2010/04/13 17:29:14  mwhxa2
 * reset indicator incase of no invoice items to process
 *
 * Revision 1.17  2010/04/06 18:35:21  mwhxa2
 * Updated logic to calculate Fee paid
 *
 * Revision 1.16  2010/04/02 01:21:32  mwhxa2
 * Added constants for Fee Rate Codes
 *
 * Revision 1.15  2010/04/01 22:39:06  mwhxa2
 * Added isFeePaidCheckIndicator()
 *
 * Revision 1.14  2010/03/23 17:14:44  mwpxr4
 * Added Indicators for Fee Paid flags
 *
 * Revision 1.13  2010/03/05 01:44:40  mwuxb
 * updates for voucher payment's status codes
 *
 * Revision 1.12  2010/03/04 19:23:30  mwvxm6
 * Added HeadquarterRefundDetail and updated Invoice to contain this for refund details
 *
 * Revision 1.11  2010/03/04 02:43:19  mwuxb
 * updated feeActionCode to feeRefundActionCode
 *
 * Revision 1.10  2010/03/03 16:11:02  mwrsk
 * cleanup imports
 *
 * Revision 1.9  2010/02/17 18:11:32  mwvxm6
 * Deleted ManualCreditPayments and replaced all occurrences with DebitPayment (terminology is due to the screen displaying Manual Credit Payments)
 *
 * Revision 1.8  2010/02/16 22:44:21  mwrsk
 * Added getInvoiceTotal()
 *
 * Revision 1.7  2010/02/10 01:59:44  mwvxm6
 * Removed transaction attribute from Invoice
 *
 * Revision 1.6  2010/02/04 19:09:28  mwvxm6
 * Removed Autowired and configured explicitly in spring context xml
 *
 * Revision 1.5  2010/01/28 19:53:51  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.4  2010/01/12 01:56:45  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.3  2010/01/05 03:01:42  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.2  2010/01/04 18:29:08  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.1  2009/11/23 16:25:13  mwrsk
 * Intial commit
 *
 * Revision 1.26  2009/09/13 20:45:32  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.25.2.1  2009/09/12 19:08:44  mwakg
 * Removed CodeSetElement sub classes
 *
 * Revision 1.25  2009/08/27 23:47:31  mwcsj3
 * Added getDebitPayment method
 *
 * Revision 1.24  2009/08/27 05:39:42  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.23  2009/08/22 23:21:46  mwrrv3
 * Implemented equals and hashCode methods.
 *
 * Revision 1.22  2009/08/20 22:29:46  mwrrv2
 * Added getTotalManualCreditPaymentsAmount(), getTotalVouchersAmount() methods.
 * Revision 1.21 2009/08/20 17:53:22 mwrrv3 Added new
 * helper method getTotalChecksAmount to get the total checks amount.
 * 
 * Revision 1.20 2009/08/12 00:38:20 mwrrv3 Removed balanceType attribute.
 * 
 * Revision 1.19 2009/08/11 20:24:59 mwrrv3 Updated the helper methods
 * implementation.
 * 
 * Revision 1.18 2009/08/11 01:45:01 mwrrv3 Updated helper method and
 * implemented getBalanceType method.
 * 
 * Revision 1.17 2009/08/08 23:52:42 mwskd2 Added new attribute feeActionCode.
 * 
 * Revision 1.16 2009/08/06 01:39:48 mwrrv3 Initialized the receipt instance in
 * the constructor.
 * 
 * Revision 1.15 2009/08/06 00:43:49 mwrrv3 Added getManualCreditPayments
 * method.
 * 
 * Revision 1.14 2009/08/05 19:12:03 mwrrv3 Created empty objects and assigned
 * to the list in the constructor.
 * 
 * Revision 1.13 2009/08/05 05:10:39 mwrrv3 Refactored Set to List.
 * 
 * Revision 1.12 2009/08/05 00:22:10 mwrrv3 Added getVoucherList method.
 * 
 * Revision 1.11 2009/08/04 16:55:25 mwrsk Remove Hibernate annotations
 * 
 * Revision 1.10 2009/08/03 23:27:54 mwrrv3 Removed initialization of receipt in
 * Invoice constructor.
 * 
 * Revision 1.9 2009/08/03 21:50:44 mwrrv3 Added getCheckPayment method and
 * added comments.
 * 
 * Revision 1.8 2009/08/03 20:41:34 mwrrv3 Added default constructor and created
 * new objects in side default constructor and added comments.
 * 
 * Revision 1.7 2009/07/29 02:12:34 mwrrv3 Added amount field to store the
 * invoice amount due that comes from Mainframe.
 * 
 * Revision 1.6 2009/07/27 23:39:54 mwrrv3 Modified the methods implementation
 * and removed unnecessary methods.
 * 
 * Revision 1.5 2009/07/23 02:43:11 mwrrv3 Removed amount attribute and added
 * getTotalPaymentAmount() method and implemented getNetAmount() and addFee()
 * methods.
 * 
 * Revision 1.4 2009/07/22 00:33:04 mwrrv3 Added new methods for Cash and Credit
 * card payment.
 * 
 * Revision 1.3 2009/07/21 18:33:58 mwrrv3 Modified the business objects.
 * 
 * Revision 1.2 2009/07/14 23:44:36 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.1 2009-07-12 07:35:16 ppalacz Moved to .impl package; added file
 * decorations, todos
 * 
 * Revision 1.1 2009-07-10 07:09:24 ppalacz Synch
 * 
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial ITM commit $ $Revision
 * 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3 $Initial $
 */
