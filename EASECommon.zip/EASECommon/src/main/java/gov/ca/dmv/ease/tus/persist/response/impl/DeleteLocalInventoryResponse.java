/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response to deleting local inventory items.
 * File: DeleteLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Jun 9, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/06/09 18:32:20 $
 * Last Changed By: $Author: mwkfh $
 */
public class DeleteLocalInventoryResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3859188114935063979L;

	/**
	 * Instantiates a new delete business object response.
	 * 
	 */
	protected DeleteLocalInventoryResponse() {
		super();
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param ex
	 */
	public DeleteLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param ex the ex
	 */
	public DeleteLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param collector
	 */
	public DeleteLocalInventoryResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param collector
	 * @param aCount
	 */
	public DeleteLocalInventoryResponse(IErrorCollector collector, int aCount) {
		super(collector);
		setAffectedItemsCount(aCount);
	}

	/**
	 * Instantiates a new delete business object response.
	 * 
	 * @param aCount
	 */
	public DeleteLocalInventoryResponse(int aCount) {
		super();
		setAffectedItemsCount(aCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DeleteLocalInventoryResponse.java,v $
 *  Revision 1.1  2011/06/09 18:32:20  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 */
