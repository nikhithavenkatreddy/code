/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.staticdata;

import gov.ca.dmv.ease.bo.staticdata.impl.CityCodeDetail;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Description: I am this and that
 * File: .java
 * Module:  
 * Created: Jul 28, 2009 
 * @author MWRRV3  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/10/08 20:52:31 $
 * Last Changed By: $Author: mwrrv3 $
 */

public interface IOfficeCityCodeRegistrySingleton extends Serializable {
	/**
	 * Gets the all code sets.
	 * 
	 * @return the all code sets
	 */
	Map<String, List<CityCodeDetail>> getAllOfficeCityCodes();

	/**
	 * Gets the code set element.
	 * 
	 * @param aCodeSetElementCode the   code set element code
	 * @param aCodeSetName the  code set name
	 * 
	 * @return the code set element
	 */
	CityCodeDetail getOfficeCityCode(String officeId,
			String cityCode);

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if is empty
	 */
	boolean isEmpty();

	/**
	 * Register.
	 * 
	 * @param aCodeSet the a code set
	 */
	void register(CityCodeDetail cityCodeDetail, String officeId);

	/**
	 * Reset.
	 */
	void reset();

	/**
	 * Size.
	 * 
	 * @return the size
	 */
	int size();
}

/**
 *  Modification History:
 * 
 *  $Log: IOfficeCityCodeRegistrySingleton.java,v $
 *  Revision 1.1  2010/10/08 20:52:31  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 */
