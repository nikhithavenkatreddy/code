/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx;

import gov.ca.dmv.ease.bo.IBusinessObject;

/**
 * Description: I define the interface that is used by the Transaction Service
 * File: ITransactionForTrxService.java
 * Module:  gov.ca.dmv.ease.bo.tx
 * Created: Aug 13, 2009
 * @author MWRSK
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/06/29 23:30:45 $
 * Last Changed By: $Author: mwcsj3 $
 */
public interface ITransactionForTrxService extends IBusinessObject {
	/**
	 * Gets the employee.
	 * 
	 * @return the employee
	 */
	String getEmployeeId();

	/**
	 * Gets the office.
	 * 
	 * @return the office
	 */
	String getOfficeId();

	/**
	 * Gets the TransactionIdentifier.
	 * 
	 * @return the TransactionIdentifier
	 */
	Integer getTransactionIdentifier();
}
/**
 *  Modification History:
 * 
 *  $Log: ITransactionForTrxService.java,v $
 *  Revision 1.2  2010/06/29 23:30:45  mwcsj3
 *  Deleted  getTypeTransactionCode method
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.11  2010/03/23 00:01:55  mwvxm6
 *  Changed Office to office_id
 *
 *  Revision 1.10  2010/03/19 01:41:32  mwrsk
 *  cleanup imports
 *
 *  Revision 1.9  2010/03/16 20:32:11  mwvxm6
 *  Updated sequence number name to transaction identification number
 *
 *  Revision 1.8  2010/03/09 22:40:47  mwhxa2
 *  Reverting back to ver 1.6
 *
 *  Revision 1.7  2010/03/09 22:38:53  mwhxa2
 *  Added getProcessHistory()
 *
 *  Revision 1.6  2010/03/09 19:38:50  mwvxm6
 *  Removed processDate, workDate, modeSettingCode, transactionNumber, Application attributed and added searchable fields to Transaction.
 *
 *  Revision 1.5  2010/03/03 16:10:20  mwrsk
 *  cleanup imports
 *
 *  Revision 1.4  2010/01/30 01:14:54  mwrsk
 *  Cleanup
 *
 *  Revision 1.3  2010/01/30 01:11:20  mwrsk
 *  updated TransactionDetl to TransactionTransformation
 *
 *  Revision 1.2  2010/01/28 22:38:42  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.1  2009/11/23 16:25:21  mwrsk
 *  Intial commit
 *
 *  Revision 1.7  2009/10/03 21:06:33  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.6  2009/09/02 03:03:08  mwrsk
 *  added getNumberDocumentsPrinted()
 *
 *  Revision 1.5  2009/08/27 05:39:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/27 02:22:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.3  2009/08/22 23:25:02  mwrrv3
 *  Changed method signature.
 *
 *  Revision 1.2  2009/08/20 01:47:44  mwrrv3
 *  Updated comments.
 *
 *  Revision 1.1  2009/08/13 16:31:15  mwrsk
 *  Moved interface to a new package
 *
 *  Revision 1.1  2009/08/13 15:04:41  mwrsk
 *  Initial commit
 *
*/
