/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.validate.IValidatable;

/**
 * Description: I am interface for an object representing a collection of invalidated inventory items;
 * the items are of the same type and form a contiguous sequence;
 * Providing lower boundary is mandatory
 * Either the count _or_ the upper boundary must be provided.
 * 
 * File: IInvalidatedItems.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item
 * Created: Dec 13, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/11/23 00:41:54 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInvalidatedItems extends IItemType, IBusinessObject,
		IItemLocation, IValidatable {
	/**
	 * Gets the count.
	 * 
	 * @return the count
	 */
	public Integer getCount();

	/**
	 * Gets the ContiguousItemSequence.
	 * 
	 * @return the ContiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence();

	/**
	 * Gets the count of the sequence item list.
	 * 
	 * @return the count
	 */
	public int getItemCount();

	/**
	 * Gets the lower boundary.
	 * 
	 * @return the lower boundary
	 */
	String getLowerBoundary();

	/**
	 * Gets the org code.
	 * 
	 * @return the org code
	 */
	String getOrgCode();

	/**
	 * Gets the pattern.
	 * 
	 * @return the pattern
	 */
	String getPattern();

	/**
	 * Gets the reason code.
	 * 
	 * @return the reason code
	 */
	char getReasonCode();

	/**
	 * Gets the upper boundary.
	 * 
	 * @return the upper boundary
	 */
	String getUpperBoundary();

	/**
	 * Checks for code.
	 * 
	 * @return true, if successful
	 */
	boolean hasCode();

	/**
	 * Checks for count.
	 * 
	 * @return true, if successful
	 */
	boolean hasCount();

	/**
	 * Checks for location.
	 * 
	 * @return true, if successful
	 */
	boolean hasLocation();

	/**
	 * Checks for lower boundary.
	 * 
	 * @return true, if successful
	 */
	boolean hasLowerBoundary();

	/**
	 * Checks for pattern.
	 * 
	 * @return true, if successful
	 */
	boolean hasPattern();

	/**
	 * Checks for reason.
	 * 
	 * @return true, if successful
	 */
	boolean hasReason();

	/**
	 * Checks for upper boundary.
	 * 
	 * @return true, if successful
	 */
	boolean hasUpperBoundary();
}
/**
 *  Modification History:
 *
 *  $Log: IInvalidatedItems.java,v $
 *  Revision 1.7  2011/11/23 00:41:54  mwkfh
 *  added getOrgCode
 *
 *  Revision 1.6  2010/12/16 23:09:10  mwkfh
 *  fixed bugs and remove not needed stuff
 *
 *  Revision 1.5  2010/12/15 18:36:43  mwkfh
 *  added getContiguousItemSequence()
 *
 *  Revision 1.4  2010/12/15 18:24:02  mwkfh
 *  added getItemCount()
 *
 *  Revision 1.3  2010/12/14 21:26:47  mwkfh
 *  updated InvalidatedItems to not require inventoryItem
 *
 *  Revision 1.2  2010/12/13 19:03:22  mwpxp2
 *  Changed inheritance; added methods
 *
 *  Revision 1.1  2010/12/13 18:44:29  mwpxp2
 *  Initial
 *
 */
