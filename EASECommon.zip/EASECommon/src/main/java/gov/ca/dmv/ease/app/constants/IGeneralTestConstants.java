/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

import static java.util.Arrays.asList;

import java.util.Arrays;
import java.util.List;

/**
 * Description: The constants for General Test.
 * File: IGeneralTestConstants.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Jul 27, 2010 
 * @author MWHXB3  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/04/17 22:26:48 $
 * Last Changed By: $Author: mwsec2 $
 */
public interface IGeneralTestConstants {
	/** The constant WAIVED means general test result needs to be corrected  */
	String CORRECTION = "*";
	String DOUBLE_CORRECTION = "**";
	/** The constant PASSED means general test passed */
	String PASSED = "P";
	/** The constant for test passed from AKTS */
	String AKTS_PASSED = "A";
	/** The constant SATISFACTORY means general test result satisfactory */
	String SATISFACTORY = "S";
	/** The constant WAIVED means general test waived */
	String WAIVED = "W";
	/** The constant FAILED means general test failed */
	String FAILED = "F";
	String CERTIFICATE_OF_COMPENTENCE = "C";
	String CERTIFICATE_OF_DRIVING_SKILL = "X";
	String FAILED_FACE_TO_FACE_TEST = "Z";
	String NOT_ENROLLED = "N";
	String ENROLLED = "E";
	/** The PASSE d_ faile d_ satisfactory. */
	List <String> PASSED_FAILED_SATISFACTORY = Arrays.asList(PASSED, AKTS_PASSED, FAILED,
			SATISFACTORY);
	/** The PASSE d_ waive d_ satisfactory. */
	List <String> PASSED_WAIVED_SATISFACTORY = Arrays.asList(PASSED, AKTS_PASSED, WAIVED,
			SATISFACTORY);
	/** The PASSE d_ waive d_ satisfactor y_ certificat e_ o f_ compentenc e_ certificat e_ o f_ drivin g_ skill. */
	List <String> PASSED_WAIVED_SATISFACTORY_CERTIFICATE_OF_COMPENTENCE_CERTIFICATE_OF_DRIVING_SKILL = Arrays
			.asList(PASSED, AKTS_PASSED, WAIVED, SATISFACTORY, CERTIFICATE_OF_COMPENTENCE,
					CERTIFICATE_OF_DRIVING_SKILL);
	/** The PASSE d_ satisfactor y_ certificat e_ o f_ drivin g_ skill. */
	List <String> PASSED_SATISFACTORY_CERTIFICATE_OF_DRIVING_SKILL = asList(
			PASSED, AKTS_PASSED, SATISFACTORY, CERTIFICATE_OF_DRIVING_SKILL);
	/** The WAIVE d_ certificat e_ o f_ compentenc e_ certificat e_ o f_ drivin g_ skill. */
	List <String> WAIVED_CERTIFICATE_OF_COMPENTENCE_CERTIFICATE_OF_DRIVING_SKILL = asList(
			WAIVED, CERTIFICATE_OF_COMPENTENCE, CERTIFICATE_OF_DRIVING_SKILL);
	/** The passed and satisfactory. */
	List <String> PASSED_AKTS_PASSED_SATISFACTORY = Arrays.asList(PASSED, AKTS_PASSED, 
			SATISFACTORY);
	
}
/**
 *  Modification History:
 *
 *  $Log: IGeneralTestConstants.java,v $
 *  Revision 1.2  2012/04/17 22:26:48  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.2  2012/04/10 18:10:23  mwgxd3
 *  AKTS: Added constant list for passed and satisfactory - to use with SIGN tests
 *
 *  Revision 1.1.2.1  2012/04/09 21:12:49  mwsec2
 *  re-based branch with changes from Head
 *
 *  Revision 1.11.14.2  2012/03/03 00:53:39  mwsec2
 *  AKTS_PASSED added. Per AKTS business rules, an AKTS_PASSED is treated the same as a manually entered PASS as far as EASE business logic goes.
 *
 *  Revision 1.11.14.1  2012/02/17 22:12:09  mwsec2
 *  re-basing AKTS branch from Head
 *
 *  Revision 1.13  2012/02/17 01:18:40  mwrka1
 *  created member list for performance
 *
 *  Revision 1.12  2012/02/16 23:44:30  mwrka1
 *  Fixed 1254
 *
 *  Revision 1.11  2011/01/30 00:30:15  mwrka1
 *  UPDATED
 *
 *  Revision 1.10  2011/01/04 00:20:07  mwrka1
 *  Updated
 *
 *  Revision 1.9  2011/01/01 00:29:01  mwrka1
 *  Updated
 *
 *  Revision 1.8  2010/12/23 06:41:18  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.6.8.1  2010/12/23 04:11:54  mwkkc
 *  Rebase from head - DL
 *
 *  Revision 1.7  2010/12/19 00:20:58  mwrka1
 *  added constant
 *
 *  Revision 1.6  2010/12/05 00:50:52  mwrka1
 *  added constant
 *
 *  Revision 1.5  2010/12/04 00:49:41  mwjxa11
 *  added FAILED constant
 *
 *  Revision 1.4  2010/11/18 23:48:08  mwpxp2
 *  Added missing javadoc; sorted
 *
 *  Revision 1.3  2010/07/28 18:18:49  mwhxb3
 *  Added CORRECTION constant.
 *
 *  Revision 1.2  2010/07/27 17:43:07  mwhxb3
 *  Changed to interface.
 *
 *  Revision 1.1  2010/07/27 17:38:21  mwhxb3
 *  The constants for General Test.
 *
 */
