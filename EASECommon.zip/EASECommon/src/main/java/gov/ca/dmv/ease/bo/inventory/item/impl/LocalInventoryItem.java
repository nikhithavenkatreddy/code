/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.inventory.exception.impl.NotYetIssuedException;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.impl.Sequence;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * Description: I am default implementation of IInventoryItem
 *  //TODO - make abstract and adjust refs
 *  
 * File: InventoryItem.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.27 $
 * Last Changed: $Date: 2011/09/23 22:00:34 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class LocalInventoryItem extends BusinessObject implements
		IInventoryItem {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2443751194753470966L;
	/** The Constant UNKNOWN_CODE. */
	public static final char UNKNOWN_CODE = 0;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#changeToOffice()
	 */
	public void changeToOffice() {
		//nothing to do
	}

	/**
	 * Checks if is null or empty.
	 * 
	 * @param aString the a string
	 * 
	 * @return true, if is null or empty
	 */
	private static boolean isNullOrEmpty(String aString) {
		if (aString == null) {
			return true;
		}
		else {
			if (StringUtils.isBlank(aString)) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	/**
	 * New instance for.
	 * 
	 * @param inventoryItemToCopy
	 * 
	 * @return the i inventory item
	 */
	public static IInventoryItem newInstanceFor(IInventoryItem inventoryItem) {
		LocalInventoryItem copyItem;
		if (inventoryItem instanceof OfficeLocalInventoryItem) {
			copyItem = new OfficeLocalInventoryItem(inventoryItem
					.getSequenceNo(), inventoryItem.getType(), inventoryItem
					.getOfficeId());
		}
		else {
			copyItem = new StationLocalInventoryItem(inventoryItem
					.getSequenceNo(), inventoryItem.getType(), inventoryItem
					.getOfficeId(), inventoryItem.getStationId());
		}
		copyItem.setAvailable(inventoryItem.isAvailable());
		copyItem.setCreatedBy(inventoryItem.getCreatedBy());
		copyItem.setCreatedDate(inventoryItem.getCreatedDate());
		//copyItem.setId(inventoryItem.getId());
		copyItem.setModifiedBy(inventoryItem.getModifiedBy());
		copyItem.setModifiedDate(inventoryItem.getModifiedDate());
		return copyItem;
	}

	/**
	 * New instance for.
	 * 
	 * @param inventoryItemToCopy
	 * @param targetLocation
	 * 
	 * @return the i inventory item
	 */
	public static IInventoryItem newInstanceFor(IInventoryItem inventoryItem,
			IItemLocation targetLocation) {
		LocalInventoryItem copyItem;
		if (isNullOrEmptyOrBlank(targetLocation.getStationId())) {
			copyItem = new OfficeLocalInventoryItem(inventoryItem.getType()
					.getCode(), targetLocation);
		}
		else {
			copyItem = new StationLocalInventoryItem(inventoryItem.getType()
					.getCode(), targetLocation);
		}
		copyItem.setAvailable(inventoryItem.isAvailable());
		copyItem.setCreatedBy(inventoryItem.getCreatedBy());
		copyItem.setCreatedDate(inventoryItem.getCreatedDate());
		//copyItem.setId(inventoryItem.getId());
		copyItem.setModifiedBy(inventoryItem.getModifiedBy());
		copyItem.setModifiedDate(inventoryItem.getModifiedDate());
		copyItem.setSequenceNoValue(inventoryItem.getSequenceNo().getValue());
		return copyItem;
	}

	/**
	 * New instance for.
	 * 
	 * @param itemType the item type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * 
	 * @return the i inventory item
	 */
	public static IInventoryItem newInstanceFor(String aType,
			String anOfficeId, String aStationId) {
		if (isNullOrEmptyOrBlank(aStationId)) {
			return new OfficeLocalInventoryItem(aType, new ItemLocation(
					anOfficeId, aStationId));
		}
		else {
			return new StationLocalInventoryItem(aType, new ItemLocation(
					anOfficeId, aStationId));
		}
	}

	/**
	 * New instance for.
	 * 
	 * @param seqNo the seq no
	 * @param itemType the item type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * 
	 * @return the i inventory item
	 */
	public static IInventoryItem newInstanceFor(ISequence seqNo,
			IItemType aType, String anOfficeId, String aStationId) {
		if (isNullOrEmptyOrBlank(aStationId)) {
			return new OfficeLocalInventoryItem(seqNo, aType, anOfficeId);
		}
		else {
			return new StationLocalInventoryItem(seqNo, aType, anOfficeId,
					aStationId);
		}
	}

	/**
	 * New instance for.
	 * 
	 * @param sequenceNoString the a seq no
	 * @param aType the a type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param lowerBoundaryString the lower boundary
	 * @param upperBoundaryString the upper boundary
	 * 
	 * @return the i inventory item
	 */
	public static IInventoryItem newInstanceFor(String sequenceNoString,
			IItemType aType, String anOfficeId, String aStationId,
			String lowerBoundaryString, String upperBoundaryString) {
		if (isNullOrEmptyOrBlank(aStationId)) {
			return new OfficeLocalInventoryItem(sequenceNoString, aType,
					anOfficeId, lowerBoundaryString, upperBoundaryString);
		}
		else {
			return new StationLocalInventoryItem(sequenceNoString, aType,
					anOfficeId, aStationId, lowerBoundaryString,
					upperBoundaryString);
		}
	}

	private static boolean isNullOrEmptyOrBlank(String aString) {
		if (aString == null) {
			return true;
		}
		if (aString.length() == 0) {
			return true;
		}
		if (aString.trim().length() == 0) {
			return true;
		}
		return false;
	}

	/** The invalidation code. */
	private Character invalidationCode = UNKNOWN_CODE;
	/** The is available. */
	private boolean isAvailable = true;
	/** The office id. */
	private String officeId;
	/** The pattern. */
	private transient ISequencePattern pattern;
	/** The sequence no. */
	private transient ISequence sequenceNo;
	/** The sequence no value. */
	private String sequenceNoValue;
	/** The type. */
	private transient IItemType type;
	/** The type code. */
	private String typeCode;

	/**
	 * Instantiates a new inventory item.
	 */
	protected LocalInventoryItem() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param aSequenceNo the a sequence no
	 * @param aType the a type
	 */
	protected LocalInventoryItem(ISequence aSequenceNo, IItemType aType,
			String anOfficeId) {
		super();
		setSequenceNo(aSequenceNo);
		setType(aType);
		setOfficeId(anOfficeId);
	}

	/**
	 * Instantiates a new local inventory item.
	 * 
	 * @param anItemTypeCode the an item type code
	 * @param aLocation the a location
	 */
	public LocalInventoryItem(String anItemTypeCode, IItemLocation aLocation) {
		super();
		setTypeCode(anItemTypeCode);
		setTargetLocation(aLocation);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#beAvailable()
	 */
	public void beAvailable() {
		setAvailable(true);
		//setModifiedDate(new Date());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#beIssued()
	 */
	public void beIssued() {
		setAvailable(false);
		//setModifiedDate(new Date());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof LocalInventoryItem)) {
			return false;
		}
		LocalInventoryItem other = (LocalInventoryItem) obj;
		if (isAvailable != other.isAvailable) {
			return false;
		}
		if (officeId == null) {
			if (other.officeId != null) {
				return false;
			}
		}
		else if (!officeId.equals(other.officeId)) {
			return false;
		}
		if (sequenceNoValue == null) {
			if (other.sequenceNoValue != null) {
				return false;
			}
		}
		else if (!sequenceNoValue.equals(other.sequenceNoValue)) {
			return false;
		}
		if (typeCode == null) {
			if (other.typeCode != null) {
				return false;
			}
		}
		else if (!typeCode.equals(other.typeCode)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getInvalidationCode()
	 */
	public char getInvalidationCode() {
		if (invalidationCode == null) {
			return UNKNOWN_CODE;
		}
		else {
			return invalidationCode.charValue();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getOfficeId()
	 */
	public String getOfficeId() {
		return officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getProcessorId()
	 */
	public String getProcessorId() {
		return null;
	}

	/**
	 * @return the pattern
	 */
	public ISequencePattern getPattern() {
		return pattern;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getSequenceNo()
	 */
	public ISequence getSequenceNo() {
		if (sequenceNo == null && !EaseUtil.isNullOrBlank(sequenceNoValue)) {
			sequenceNo = new Sequence(sequenceNoValue, getPattern());
		}
		return sequenceNo;
	}

	/**
	 * Gets the sequence no value.
	 * 
	 * @return the sequence no value
	 */
	public String getSequenceNoValue() {
		//use for persistence only
		return sequenceNoValue;
	}

	public String getStationId() {
		//only station item has non null id
		//throw new InventoryItemException("only station item has station id");
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getType()
	 */
	public IItemType getType() {
		if (type == null) {
			type = ItemType.forCode(typeCode);
		}
		return type;
	}

	/**
	 * Gets the type code.
	 * 
	 * @return the type code
	 */
	public String getTypeCode() {
		//use for persistence only
		if (typeCode == null && type != null) {
			typeCode = type.getCode();
		}
		return typeCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#hasBeenUsedUp()
	 */
	public boolean hasBeenIssued() {
		return !isAvailable;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#hasBeenIssuedBy()
	 */
	public String hasBeenIssuedBy() {
		if (hasBeenIssued()) {
			return getModifiedBy();
		}
		else {
			throw new NotYetIssuedException(this.toString());
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#hasBeenIssuedOn()
	 */
	public Date hasBeenIssuedOn() {
		if (hasBeenIssued()) {
			return getModifiedDate();
		}
		else {
			throw new NotYetIssuedException(this.toString());
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (isAvailable ? 1231 : 1237);
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());
		result = prime * result
				+ ((sequenceNoValue == null) ? 0 : sequenceNoValue.hashCode());
		result = prime * result
				+ ((typeCode == null) ? 0 : typeCode.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#hasSequenceNo(gov.ca.dmv.ease.bo.sequence.ISequence)
	 */
	public boolean hasSequenceNo(ISequence anotherSequence) {
		return getSequenceNo().equals(anotherSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#hasType(gov.ca.dmv.ease.bo.inventory.item.IItemType)
	 */
	public boolean hasType(IItemType aType) {
		return getType().equals(aType);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#isAssignedToStation()
	 */
	public boolean isAssignedToStation() {
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemState#isAvailable()
	 */
	public boolean isAvailable() {
		return isAvailable;
	}

	/**
	 * @param isAvailable the isAvailable to set
	 */
	protected void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	/**
	 * Sets the checks for been issued by.
	 * 
	 * @param aName the a name
	 */
	public void setHasBeenIssuedBy(String aName) {
		setModifiedBy(aName);
	}

	/**
	 * Sets the checks for been issued on.
	 * 
	 * @param aDate the a date
	 */
	protected void setHasBeenIssuedOn(Date aDate) {
		setModifiedDate(aDate);
	}

	/**
	 * Sets the invalidation code
	 * 
	 * @param invalidationCode the invalidationCode to set
	 */
	protected void setInvalidationCode(Character invalidationCode) {
		this.invalidationCode = invalidationCode;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId the new office id
	 */
	public void setOfficeId(String anId) {
		officeId = anId;
	}

	/**
	 * @param pattern the pattern to set
	 */
	protected void setPattern(ISequencePattern aPattern) {
		pattern = aPattern;
		sequenceNo = new Sequence(getSequenceNoValue(), aPattern);
	}

	/**
	 * Sets the sequence no.
	 * 
	 * @param aSeqNo the a seq no
	 */
	protected void setSequenceNo(ISequence aSeqNo) {
		sequenceNo = aSeqNo;
		if (sequenceNo == null) {
			sequenceNoValue = null;
			pattern = null;
		}
		else {
			sequenceNoValue = sequenceNo.getValue();
			pattern = sequenceNo.getPattern();
		}
	}

	/**
	 * Sets the sequence no value.
	 * 
	 * @param aValue the new sequence no value
	 */
	public void setSequenceNoValue(String aValue) {
		//use for persistence only
		sequenceNoValue = aValue;
		sequenceNo = new Sequence(aValue, getPattern());
	}

	/**
	 * Sets the station id.
	 * 
	 * @param anID the new station id
	 */
	public void setStationId(String anID) {
		//ignored
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#setTargetLocation(gov.ca.dmv.ease.bo.inventory.item.IItemLocation)
	 */
	public void setTargetLocation(IItemLocation theTarget) {
		setOfficeId(theTarget.getOfficeId());
		setStationId(theTarget.getStationId());
	}

	/**
	 * Sets the type.
	 * 
	 * @param aType the a type
	 */
	protected void setType(IItemType aType) {
		type = aType;
		if (type == null) {
			typeCode = null;
		}
		else {
			typeCode = type.getCode();
		}
	}

	/**
	 * Sets the type code.
	 * 
	 * @param aCode the new type code
	 */
	public void setTypeCode(String aCode) {
		//use for persistence only
		typeCode = aCode;
		if (aCode == null) {
			setType(null);
		}
		else {
			setType(ItemType.forCode(aCode));
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" office: ").append(officeId);
		aBuilder.append(" isAvailable: ").append(isAvailable);
		aBuilder.append(" sequenceNo: ").append(sequenceNo);
		aBuilder.append(" type: ").append(type);
		aBuilder.append(" ]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validate()
	 */
	@Override
	public IErrorCollector validate() {
		IErrorCollector anErrorCollector = new ErrorCollector();
		validateUsing(anErrorCollector);
		return anErrorCollector;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		if (getOfficeId() == null) {
			aCollector.register(new EaseValidationException(
					"officeId must not be null in " + this));
		}
		if (getSequenceNo() == null) {
			aCollector.register(new EaseValidationException(
					"sequenceNo must not be null in " + this));
		}
		else {
			if (getSequenceNoValue() == null) {
				aCollector.register(new EaseValidationException(
						"getSequenceNoValue must not be null in " + this));
			}
		}
		if (getType() == null) {
			aCollector.register(new EaseValidationException(
					"type must not be null in " + this));
		}
		else {
			if (getTypeCode() == null) {
				aCollector.register(new EaseValidationException(
						"getTypeCode must not be null in " + this));
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: LocalInventoryItem.java,v $
 *  Revision 1.27  2011/09/23 22:00:34  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.26  2011/09/23 21:21:20  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.25  2011/07/02 00:00:14  mwkfh
 *  added invalidationCode and reverted station changes
 *
 *  Revision 1.24  2011/06/28 21:02:00  mwxxw
 *  Add more logic for issue station level items.
 *
 *  Revision 1.23  2011/04/18 19:29:14  mwkfh
 *  removed unused hasSequenceNo
 *
 *  Revision 1.22  2011/02/07 17:15:18  mwkfh
 *  added newInstanceFor(inventoryItem)
 *
 *  Revision 1.21  2010/12/09 16:54:50  mwkfh
 *  updated getType()
 *
 *  Revision 1.20  2010/12/06 20:02:01  mwkfh
 *  updated beIssued()
 *
 *  Revision 1.19  2010/12/03 18:54:37  mwkfh
 *  added another newInstanceFor
 *
 *  Revision 1.18  2010/12/02 18:51:04  mwkfh
 *  updated getSequenceNo
 *
 *  Revision 1.17  2010/10/28 21:23:13  mwkfh
 *  added another newInstanceFor method
 *
 *  Revision 1.16  2010/10/15 22:37:17  mwkfh
 *  removed pattern from validateUsing
 *
 *  Revision 1.15  2010/10/15 17:21:11  mwkfh
 *  updated to always set both seq object and values to match either way set
 *
 *  Revision 1.14  2010/10/14 23:27:21  mwkfh
 *  removed  deprecated constructors
 *
 *  Revision 1.13  2010/10/14 17:19:45  mwkfh
 *  updated constructor and new instance and added pattern to validate
 *
 *  Revision 1.12  2010/10/13 02:18:02  mwpxp2
 *  Fixed setSequenceNo/1 to properly set setSequenceNoValue
 *
 *  Revision 1.11  2010/10/12 22:20:06  mwpxp2
 *  Fixed the static factory method to accept type; fixed accesses for type and typeCode
 *
 *  Revision 1.10  2010/10/11 17:29:33  mwpxp2
 *  Made abstract; added validation methods as per IValidatable
 *
 *  Revision 1.9  2010/10/08 01:52:44  mwpxp2
 *  Added getPattern/0
 *
 *  Revision 1.8  2010/10/05 22:27:27  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.7  2010/10/05 20:39:01  mwpxp2
 *  Adjusted references to sequence types
 *
 *  Revision 1.6  2010/10/05 17:42:16  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.5  2010/09/17 21:58:04  mwpxp2
 *  Modified in preparation for becoming abstract and for servicing concrete subclasses
 *
 *  Revision 1.4  2010/09/17 21:26:07  mwpxp2
 *  Removed references to obsoleted item state; added isAvailable inst var
 *
 *  Revision 1.3  2010/09/16 22:23:11  mwpxp2
 *  Added 2-arg constructor for item code and location
 *
 *  Revision 1.2  2010/09/15 02:07:51  mwpxp2
 *  Added setTargetLocation/1
 *
 *  Revision 1.1  2010/09/14 01:57:09  mwpxp2
 *  Renamed by adding Local prefix
 *
 *  Revision 1.9  2010/09/02 18:43:36  mwpxp2
 *  Make instance vars not to be persisted transient; added persistence-related fields.
 *
 *  Revision 1.8  2010/09/02 18:06:51  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.7  2010/09/02 17:54:56  mwpxp2
 *  Added getOfficeId/0
 *
 *  Revision 1.6  2010/09/02 17:38:36  mwpxp2
 *  Added hashCode, equals; removed obsolete behavior
 *
 *  Revision 1.5  2010/09/01 21:59:50  mwpxp2
 *  Redirected issued stamp by/date to super modified by/date
 *
 *  Revision 1.4  2010/09/01 21:56:11  mwpxp2
 *  Added convenience 3-arg constructor
 *
 *  Revision 1.3  2010/09/01 20:33:39  mwpxp2
 *  Added reference to Inventory using inventoryId
 *
 *  Revision 1.2  2010/08/31 03:49:49  mwpxp2
 *  Added hasSequenceNo/1, hasType/1, isInState/1; 2-arg constructor
 *
 *  Revision 1.1  2010/08/30 22:36:08  mwpxp2
 *  Initial, not unit tested
 *
 */
