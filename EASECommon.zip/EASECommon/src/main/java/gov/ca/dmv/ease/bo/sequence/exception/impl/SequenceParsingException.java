/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.exception.impl;

/**
 * Description: I am exception to be used in parsing of alphanum sequnces
 * File: SequenceParsingException.java
 * Module:  gov.ca.dmv.ease.bo.sequence.exception.impl
 * Created: Sep 7, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/09/30 17:45:13 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SequenceParsingException extends SequenceException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8400987112742508736L;

	/**
	 * Instantiates a new sequence parsing exception.
	 */
	public SequenceParsingException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public SequenceParsingException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public SequenceParsingException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public SequenceParsingException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequenceParsingException.java,v $
 *  Revision 1.3  2010/09/30 17:45:13  mwpxp2
 *  Changed super to SequenceException
 *
 *  Revision 1.2  2010/09/07 22:56:17  mwpxp2
 *  Formatting
 *
 *  Revision 1.1  2010/09/07 20:13:42  mwpxp2
 *  Initial
 *
 */
