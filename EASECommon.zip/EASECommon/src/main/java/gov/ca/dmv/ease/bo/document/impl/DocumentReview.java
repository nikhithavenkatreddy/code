/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;

/**
 * Description: Holds the Document Review Information
 * File: DocumentReview.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Jan 13, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/01/17 01:20:10 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DocumentReview extends BaseBusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5071872371793658369L;
	/** The DAF Record Id. */
	private String dafRecordId;
	/** The Document to Review. */
	private Document documentToReview;
	/** The Indicator for Review Document. */
	private Boolean isReviewDocument;

	/**
	 * Default Constructor.
	 */
	public DocumentReview() {
		// FIXME
	}

	/**
	 * Gets the DAF Record Id.
	 * 
	 * @return the dafRecordId
	 */
	public String getDafRecordId() {
		return dafRecordId;
	}

	/**
	 * Gets the Document to Review.
	 * 
	 * @return the documentToReview
	 */
	public Document getDocumentToReview() {
		return documentToReview;
	}

	/**
	 * Gets the Indicator for Review Document.
	 * 
	 * @return the isReviewDocument
	 */
	public Boolean isReviewDocument() {
		return isReviewDocument;
	}

	/**
	 * Sets the DAF Record Id.
	 * 
	 * @param dafRecordId the dafRecordId to set
	 */
	public void setDafRecordId(String dafRecordId) {
		this.dafRecordId = dafRecordId;
	}

	/**
	 * Sets the Document to Review.
	 * 
	 * @param documentToReview the documentToReview to set
	 */
	public void setDocumentToReview(Document documentToReview) {
		this.documentToReview = documentToReview;
	}

	/**
	 * Sets the Indicator for Review Document.
	 * 
	 * @param isReviewDocument the isReviewDocument to set
	 */
	public void setReviewDocument(Boolean isReviewDocument) {
		this.isReviewDocument = isReviewDocument;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("dafRecordId", dafRecordId, anIndent, aBuilder);
		outputKeyValue("documentToReview", documentToReview, anIndent, aBuilder);
		outputKeyValue("isReviewDocument", isReviewDocument, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DocumentReview.java,v $
 *  Revision 1.7  2011/01/17 01:20:10  mwpxp2
 *  Builk cleanup
 *
 *  Revision 1.6  2010/12/07 22:08:36  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 02:53:56  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.4  2010/12/07 02:42:34  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.3  2010/09/13 04:40:28  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/13 22:51:24  mwhxa2
 *  Draft Check in
 *
 *  Revision 1.1  2010/01/13 22:49:48  mwhxa2
 *  Draft Check in
 *
*/
