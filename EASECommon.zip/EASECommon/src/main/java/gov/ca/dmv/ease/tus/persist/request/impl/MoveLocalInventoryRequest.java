/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2010
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.MoveLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I am the request to move an inventory item location.
 * File: MoveLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 3, 2010 
 * @author MWKFH  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/07/06 17:10:44 $
 * Last Changed By: $Author: mwkfh $
 */
public class MoveLocalInventoryRequest extends PersistenceServiceRequest {
	/** The sequences. */
	IContiguousItemSequence contiguousItemSequence;
	/** The target location. */
	private IItemLocation targetLocation;

	public MoveLocalInventoryRequest(IUserContext userContect,
			IContiguousItemSequence contiguousItemSequence,
			IItemLocation targetLocation) {
		super(userContect);
		setContiguousItemSequence(contiguousItemSequence);
		setTargetLocation(targetLocation);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public MoveLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Gets the contiguousItemSequence.
	 * 
	 * @return the contiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		return contiguousItemSequence;
	}

	/**
	 * Gets the Target Location.
	 * 
	 * @return targetLocation
	 */
	public IItemLocation getTargetLocation() {
		return targetLocation;
	}

	/**
	 * Sets the contiguousItemSequence.
	 * 
	 * @param contiguousItemSequence
	 */
	private void setContiguousItemSequence(
			IContiguousItemSequence contiguousItemSequence) {
		this.contiguousItemSequence = contiguousItemSequence;
	}

	/**
	 * Sets the itemLocation.
	 * 
	 * @param itemLocation
	 */
	private void setTargetLocation(IItemLocation itemLocation) {
		this.targetLocation = itemLocation;
	}
}
/**
 *  Modification History:
 *
 *  $Log: MoveLocalInventoryRequest.java,v $
 *  Revision 1.2  2011/07/06 17:10:44  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.1  2010/12/03 16:52:08  mwkfh
 *  added move local inventory
 *
 */
