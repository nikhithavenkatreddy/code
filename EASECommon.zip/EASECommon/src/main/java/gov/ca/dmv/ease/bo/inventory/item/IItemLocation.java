/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

import java.io.Serializable;

/**
 * Description: I am interface for accessing location of an item
 * File: IItemLocation.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2011/09/23 22:00:34 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IItemLocation extends Serializable {
	/**
	 * Changes the station to an office.
	 */
	public void changeToOffice();

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	String getOfficeId();

	/**
	 * Gets the station id.
	 * 
	 * @return the station id
	 */
	String getStationId();

	/**
	 * Checks if is assigned to station.
	 * 
	 * @return true, if is assigned to station
	 */
	boolean isAssignedToStation();
}
/**
 *  Modification History:
 *
 *  $Log: IItemLocation.java,v $
 *  Revision 1.3  2011/09/23 22:00:34  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.2  2010/09/14 19:08:02  mwpxp2
 *  Extended serializable
 *
 *  Revision 1.1  2010/09/14 18:01:45  mwpxp2
 *  Initial - extracted for move item operations
 *
 */
