/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator;

/**
 * Description: Enumeration of address types.
 * 
 * File: AddressType.java
 * Module:  gov.ca.dmv.ease.bo.locator
 * Created: Feb 9, 2010
 * 
 * @author MWRSK
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/09/09 22:24:00 $
 * Last Changed By: $Author: mwtjc1 $
 */
public enum AddressType {
	/** The Headquarters Refund Address. */
	HEADQUARTERS_REFUND,
	/** The Mailing Address . */
	MAILING,
	/** The Residential address. */
	RESIDENTIAL,
	/** The OTHE r_ address. */
	OTHER_ADDRESS
}
/**
 *  Modification History:
 * 
 *  $Log: AddressType.java,v $
 *  Revision 1.3  2010/09/09 22:24:00  mwtjc1
 *  OTHER_ADDRESS added
 *
 *  Revision 1.2  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/05 01:09:24  mwuxb
 *  added headquarters refund
 *
 *  Revision 1.1  2010/02/10 01:50:00  mwrsk
 *  AddressType ENUM fixes
 *
*/
