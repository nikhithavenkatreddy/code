/**
 * 
 */
package gov.ca.dmv.ease.bo.dl.exams.impl;

import gov.ca.dmv.ease.app.constants.IGeneralTestConstants;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.dl.exams.IKnowledgeExamCodes;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.IEndorsementCodes;
import gov.ca.dmv.ease.bo.license.ILicenseClassCodes;
import gov.ca.dmv.ease.bo.license.testresult.CommercialTestResultType;
import gov.ca.dmv.ease.bo.license.testresult.DriveAndLawTestResultType;
import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.date.impl.CurrentDateUtil;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Description: Business object for a knowledge test
 * File: KnowledgeExam.java
 * Module:  gov.ca.dmv.ease.bo.dl.exams.impl
 * Created: Dec 22, 2011 
 * @author MWSEC2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/08/03 00:31:50 $
 * Last Changed By: $Author: mwgxd3 $
 */
public class KnowledgeExam extends BusinessObject implements IKnowledgeExamCodes, ILicenseClassCodes, IEndorsementCodes {
	/* the serial ID */
	private static final long serialVersionUID = 6931778995981380422L;

	/* the code that identifies the type of exam */
	private String examCode;
	/* how many times the test has been failed for this application */
	private int timesFailed;
	/* indicates whether the test is optional or not */
	private boolean optional;
	/* indicates whether the test is already passed or not */
	private boolean passed;

	
	/**
	 * A utility method for translating a string code in terms of 
	 * whether it signifies a failure. For example, a "P" indicates a 'fail value'
	 * of 0, whereas a "2" indicates a fail value of 1, etc.
	 * 
	 * @param code
	 * @return
	 */
	public static int getFailValue(String code) {
		int failValue = 1;
		try {
			Integer.parseInt(code); 
		} catch (NumberFormatException e) {
			if (!IGeneralTestConstants.FAILED.equals(code)) {
				failValue = 0;
			}
		}
		return failValue;
	}
	
	/**
	 * A util method that indicates if the person is under 18 years of age (the legal definition of a minor in CA).
	 * 
	 * @param person
	 * @return
	 */
	// TODO move this to Person (do this later)
	public static boolean isMinor(Person person) {
		Date birthDate = person.getBirthDate();
		if (birthDate != null) {
			return CurrentDateUtil.isMinor(birthDate);
		}
		return false;
	}
	
	
	/**
	 * A util method that returns the DriveAndLawTestResultType enum type if a given a test abbreviation code
	 * maps to a DriveAndLawTestResultType. Otherwise returns null
	 * 
	 * @param testTypeCode
	 * @return
	 */
	public static DriveAndLawTestResultType getNonCommercialResultType(String testTypeCode) {	
		if (ArrayUtils.contains(testTypeCode, BASIC_ORIGINAL_EXAM, BASIC_RENEWAL_EXAM, BASIC_PROVISIONAL_EXAM)) {
			return DriveAndLawTestResultType.CLASS_F_LAW_TEST_RESULT;
		} else if (SIGN_EXAM.equals(testTypeCode)) {
			return DriveAndLawTestResultType.SIGNS_TEST_RESULT;
		} else if (MOTORCYCLE_EXAM.equals(testTypeCode)) {
			return DriveAndLawTestResultType.CLASS_M_LAW_TEST_RESULT;
		} else {
			return null;
		}
	}
	
	/**
	 * A util method that returns the CommercialTestResultType enum type if a given a test abbreviation code
	 * maps to a CommercialTestResultType. Otherwise returns null
	 * 
	 * @param testTypeCode
	 * @return
	 */
	public static CommercialTestResultType getCommercialResultType(String testTypeCode) {	
		if (AIR_BRAKES_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.AIR_BRAKES_TEST_RESULT;
		} else if (DOUBLE_TRIPLE_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.DOUBLES_OR_TRIPLES_TEST_RESULT;
		} else if (TANK_VEHICLE_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.TANK_TEST_RESULT;
		} else if (PASSENGER_VEHICLE_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.PASSENGER_TEST_RESULT;
		} else if (HAZMAT_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.HAZMAT_TEST_RESULT;
		} else if (RV_AND_TRAILER_EXAM.equals(testTypeCode)) { //TODO: is this handled here or in combination with class D?
			return CommercialTestResultType.TRAILERCOACH_TEST_RESULT;
		} else if (DOUBLE_TRIPLE_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.DOUBLES_OR_TRIPLES_TEST_RESULT; 
		} else if (COMMERCIAL_GENERAL_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.GENERAL_TEST_RESULT; 
		} else if (CLASS_A_EXAM.equals(testTypeCode)) {
			return CommercialTestResultType.CLASSA_COMBINATION_TEST_RESULT;	// TODO verify this is the right mapping
		// TODO add other commercial tests (?)
		} else if (HOUSE_CAR_EXAM.equals(testTypeCode)) { //Special case 45' House Car
			return CommercialTestResultType.FIREFIGHTER_TEST_RESULT;
		} else {
			return null;
		}	
	}
	
	/**
	 * A util method that returns the set of exam codes that are required for a license class,
	 * considering whether the applicant is a minor and whether the application is original (not a renewal) 
	 * 
	 * @param licenseClassCode
	 * @param isOriginalIndicator
	 * @param isMinor
	 * @return
	 */
	public static Set<String> getRequiredExamsForLicenseClass(String licenseClassCode, 
			Boolean isOriginalIndicator, boolean isMinor) {
		boolean isOriginal = EaseUtil.isNotNullAndIsTrue(isOriginalIndicator);
		Set<String> requiredExams = new HashSet<String>();
		String basicExam = getBasicExam(isMinor, isOriginal);
		if (COMMERCIAL_CLASS_A.equals(licenseClassCode)) {
			requiredExams.add(basicExam);
			requiredExams.add(CLASS_A_EXAM); 
			requiredExams.add(COMMERCIAL_GENERAL_EXAM); 
			requiredExams.add(AIR_BRAKES_EXAM); 
		} else if (COMMERCIAL_CLASS_B.equals(licenseClassCode)) {
			requiredExams.add(basicExam);
			requiredExams.add(COMMERCIAL_GENERAL_EXAM);
			requiredExams.add(AIR_BRAKES_EXAM); 
		} else if (COMMERCIAL_CLASS_C.equals(licenseClassCode)) {
			requiredExams.add(basicExam);
			requiredExams.add(AIR_BRAKES_EXAM); 
 		} else if (NON_COMMERCIAL_CLASS_A.equals(licenseClassCode)) {
 			requiredExams.add(basicExam);
			requiredExams.add(AIR_BRAKES_EXAM); 
		} else if (NON_COMMERCIAL_CLASS_B.equals(licenseClassCode)) {
			requiredExams.add(basicExam);
			requiredExams.add(AIR_BRAKES_EXAM); 
		} else if (NON_COMMERCIAL_CLASS_C.equals(licenseClassCode)) {
			requiredExams.add(basicExam);
		} else if (MOTORCYCLE.equals(licenseClassCode)) {
			requiredExams.add(MOTORCYCLE_EXAM);
			requiredExams.add(basicExam); //basic knowledge exam is needed.
		}  
		return requiredExams;
	}
	
	/**
	 * A util method that returns the set of exam codes that are required for a license class renewal,
	 * considering whether the applicant is a minor  
	 * 
	 * @param licenseClassCode
	 * @param isMinor
	 * @return
	 */
	public static Set<String> getRequiredExamsForLicenseClass(String licenseClassCode, 
			boolean isMinor) {
		return getRequiredExamsForLicenseClass(licenseClassCode, false, isMinor);
	}
	

	/**
	 * Returns the code for the type of basic exam that is applicable.
	 * 
	 * @param isMinor
	 * @param isOriginal
	 * @return
	 */
	// TODO confirm that minor status overrides the renewal status
	protected static String getBasicExam(boolean isMinor, boolean isOriginal) {
		String basicExam = null;
		if (isMinor) {
			basicExam = BASIC_PROVISIONAL_EXAM;
		} else {
			if (isOriginal) {
				basicExam = BASIC_ORIGINAL_EXAM;
			} else {
				basicExam = BASIC_RENEWAL_EXAM;
			}
		}
		return basicExam;
	}
	
	/**
	 * A util method that returns the set of exam codes that are required for an endorsement
	 * 
	 * @param endorsementCode
	 * @return
	 */
	public static List<String> getRequiredExamsForEndorsement(String endorsementCode) {
		List<String> requiredExams = new ArrayList<String>();
		if (DOUBLE_TRIPLE.equals(endorsementCode)) {
			requiredExams.add(DOUBLE_TRIPLE_EXAM);
		} else if (HAZARDOUS_MATERIAL.equals(endorsementCode)) {
			requiredExams.add(HAZMAT_EXAM);
		}  else if (PASSENGER_VEH.equals(endorsementCode)) {
			requiredExams.add(PASSENGER_VEHICLE_EXAM);
		}  else if (TANK_VEHICLE.equals(endorsementCode)) {
			requiredExams.add(TANK_VEHICLE_EXAM);
		}
		else {
			// throw exception
		}
		return requiredExams;
	}
	
	/**
	 * A util method that returns the set of exam codes that are required for a category
	 * ===WILL NOT USE FOR PROTO
	 * @param categoryCode
	 * @return
	 */
	public static List<String> getRequiredExamsForCategory(String categoryCode, List <CodeSetElement> classCodes) {
		List<String> requiredExams = new ArrayList<String>();
		
//		if (FIRE_FIGHTER_CLASSS_B.equals(categoryCode)){
//			if(EaseUtil.isCodeFoundInCodeSetElements(classCodes, NON_COMMERCIAL_CLASS_B)) {
//				requiredExams.add(HOUSE_CAR_EXAM);
//			} else {
//				//TODO: Add FireFighter test??
//			}
//		}
		if(TRAILER_COACH.equals(categoryCode)){
			if(EaseUtil.isCodeFoundInCodeSetElements(classCodes, NON_COMMERCIAL_CLASS_A)) {
				requiredExams.add(RV_AND_TRAILER_EXAM);
			} 
		}
		return requiredExams;
	}
	/**
	 * default constructor
	 */
	public KnowledgeExam() {}
	
	/**
	 * Copy constructor
	 * 
	 * @param test
	 */
	public KnowledgeExam(KnowledgeExam exam) {
		examCode = exam.getExamCode();
		timesFailed = exam.getTimesFailed();
		optional = exam.isOptional();
		passed = exam.isPassed();
	}
	
	/**
	 * Constructor with testCode
	 * 
	 * @param testCode
	 * @param timesFailed
	 */
	public KnowledgeExam(String examCode) {
		super();
		this.examCode = examCode;
	}

	public void addFailures(int fails) {
		setTimesFailed(getTimesFailed() + fails);
	}
	
	/**
	 * @return the testCode
	 */
	public String getExamCode() {
		return examCode;
	}
	/**
	 * @param testCode the testCode to set
	 */
	public void setExamCode(String examCode) {
		this.examCode = examCode;
	}
	/**
	 * @return the timesFailed
	 */
	public int getTimesFailed() {
		return timesFailed;
	}
	
	/**
	 * @param optional the optional to set
	 */
	public void setOptional(boolean optional) {
		this.optional = optional;
	}

	/**
	 * @return the optional
	 */
	public boolean isOptional() {
		return optional;
	}

	public boolean isInSet(Set<KnowledgeExam> set) {
		if (set == null) {
			return false;
		}
		for (KnowledgeExam exam : set) {
			if (equals(exam)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * @param timesFailed the timesFailed to set
	 */
	public void setTimesFailed(int timesFailed) {
		this.timesFailed = timesFailed;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (optional ? 1231 : 1237);
		result = prime * result + (passed ? 1231 : 1237);
		result = prime * result
				+ ((examCode == null) ? 0 : examCode.hashCode());
		result = prime * result + timesFailed;
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		KnowledgeExam other = (KnowledgeExam) obj;
		if (optional != other.optional)
			return false;
		if (passed != other.passed)
			return false;
		if (examCode == null) {
			if (other.examCode != null)
				return false;
		}
		else if (!examCode.equals(other.examCode))
			return false;
		if (timesFailed != other.timesFailed)
			return false;
		return true;
	}

	/**
	 * @param passed the passed to set
	 */
	public void setPassed(boolean passed) {
		this.passed = passed;
	}

	/**
	 * @return the passed
	 */
	public boolean isPassed() {
		return passed;
	}
	
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("testCode", examCode, anIndent, aBuilder);
		outputKeyValue("timesFailed", timesFailed, anIndent, aBuilder);
		outputKeyValue("optional", optional, anIndent, aBuilder);
		outputKeyValue("passed", passed, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}


/**
 *  Modification History:
 *
 *  $Log: KnowledgeExam.java,v $
 *  Revision 1.4  2012/08/03 00:31:50  mwgxd3
 *  AKTS defect 42 - RV is a required test.
 *
 *  Revision 1.3  2012/07/12 22:14:05  mwgxd3
 *  AKTS - need basic knowledge exam for motorcycle
 *
 *  Revision 1.2  2012/04/17 22:26:48  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.1.2.9  2012/04/09 23:28:09  mwsec2
 *  changed getFailValue to count all failure codes as one failure
 *
 *  Revision 1.1.2.8  2012/04/09 20:54:25  mwsec2
 *  changed getFailValue
 *
 *  Revision 1.1.2.7  2012/03/30 23:30:29  mwgxd3
 *  change method visibility
 *
 *  Revision 1.1.2.6  2012/03/29 18:51:01  mwgxd3
 *  update basic provisional
 *
 *  Revision 1.1.2.5  2012/03/27 21:14:05  mwgxd3
 *  update w/ special tests for HC
 *
 *  Revision 1.1.2.4  2012/03/02 01:13:56  mwgxd3
 *  started to add logic for categories. Removed School Bus from endorsement logic (no knowledge test).
 *
 *  Revision 1.1.2.3  2012/02/24 00:31:09  mwsec2
 *  added logic to getRequiredExamsForLicenseClass
 *
 *  Revision 1.1.2.2  2012/02/23 00:37:29  mwsec2
 *  added TODOs and FIXMEs
 *
 *  Revision 1.1.2.1  2012/02/15 19:39:40  mwsec2
 *  initial commit of AKTS code into AKTS branch
 *
 */