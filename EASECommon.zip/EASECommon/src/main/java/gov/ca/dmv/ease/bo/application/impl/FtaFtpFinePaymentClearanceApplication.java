/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.app.activity.impl.InteractionActivity;
import gov.ca.dmv.ease.bo.citation.impl.CitationDetail;
import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.locator.AddressType;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.vr.record.impl.VehicleRecord;

import java.math.BigDecimal;
import java.util.List;

/**
 * Description: This class captures information to process fine collection.
 * A person�s driving privilege may be suspended for a Failure to Appear (FTA) or
 * Failure to Pay (FTP) if one of the following is on his/her driving record:
 * �Two or more FTA notifications.
 * �Two or more FTP notifications.
 * �One violation pursuant to CVC �40509.5.
 * �One FTA notification for driving under the influence.
 * File: FtaFtpFinePaymentClearanceApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 22, 2010
 * 
 * @author MWVXM6
 * @version $Revision: 1.21 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class FtaFtpFinePaymentClearanceApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8975165672329646519L;
	/** The list of Citation Detail. */
	private List <CitationDetail> citationDetails;
	/** The Docket Number. */
	private String docketNumber;
	/** The number of citations. */
	private int numberOfCitations;// This comes from DLL TCode
	/** The Number of Non Payable Citations. */
	private Integer numberOfNonPayableCitations;
	/** The Number of Payable Citations. */
	private Integer numberOfPayableCitations;
	/** The total Fine Due. */
	private BigDecimal totalFineDue;
	/** The Vehicle information. */
	private VehicleRecord vehicleRecord;
	/** The other address. */
	private Address prevOtherAddress = new Address(AddressType.OTHER_ADDRESS);
	/** The dll return code. */
	private String dllReturnCode;
	/** The fee rate code for total service fee amount. */
	private String feeRateCodeForTotalServiceFeeAmount;// This is populated by fee service - fee rate code 792
	/** The service fee amount. */
	private BigDecimal totalServiceFeeAmount; // This is populated by fee service
	/** The ineraction activity of interest. */
	private InteractionActivity interactionActivityOfInterest;
	
	/**
	 * Instantiates a new fta ftp fine payment clearance application.
	 */
	public FtaFtpFinePaymentClearanceApplication() {
		setIsFeeRequired(true);
	}
	/**
	 * Gets the fee rate code for total service fee amount.
	 * 
	 * @return the fee rate code for total service fee amount
	 */
	public String getFeeRateCodeForTotalServiceFeeAmount() {
		return feeRateCodeForTotalServiceFeeAmount;
	}

	/**
	 * Sets the fee rate code for total service fee amount.
	 * 
	 * @param feeRateCodeForTotalServiceFeeAmount the new fee rate code for total service fee amount
	 */
	public void setFeeRateCodeForTotalServiceFeeAmount(
			String feeRateCodeForTotalServiceFeeAmount) {
		this.feeRateCodeForTotalServiceFeeAmount = feeRateCodeForTotalServiceFeeAmount;
	}

	/**
	 * Gets the total service fee amount.
	 * 
	 * @return the total service fee amount
	 */
	public BigDecimal getTotalServiceFeeAmount() {
		return totalServiceFeeAmount;
	}

	/**
	 * Sets the total service fee amount.
	 * 
	 * @param totalServiceFeeAmount the new total service fee amount
	 */
	public void setTotalServiceFeeAmount(BigDecimal totalServiceFeeAmount) {
		this.totalServiceFeeAmount = totalServiceFeeAmount;
	}

	/**
	 * Gets the interaction activity of interest.
	 * 
	 * @return the interaction activity of interest
	 */
	public InteractionActivity getInteractionActivityOfInterest() {
		return interactionActivityOfInterest;
	}

	/**
	 * Sets the interaction activity of interest.
	 * 
	 * @param ineractionActivityOfInterest the ineraction activity of interest
	 */
	public void setInteractionActivityOfInterest(
			InteractionActivity ineractionActivityOfInterest) {
		this.interactionActivityOfInterest = ineractionActivityOfInterest;
	}

	/**
	 * Gets the prev other address.
	 * 
	 * @return the prev other address
	 */
	public Address getPrevOtherAddress() {
		return prevOtherAddress;
	}

	/**
	 * Sets the prev other address.
	 * 
	 * @param prevOtherAddress the new prev other address
	 */
	public void setPrevOtherAddress(Address prevOtherAddress) {
		this.prevOtherAddress = prevOtherAddress;
	}

	/**
	 * Gets the citation details.
	 * 
	 * @return the citationDetails
	 */
	public List <CitationDetail> getCitationDetails() {
		return citationDetails;
	}

	/**
	 * Gets the docket number.	 *
	 * 
	 * @return the docketNumber
	 */
	public String getDocketNumber() {
		return docketNumber;
	}

	/**
	 * Gets the number non payable citations.
	 * 
	 * @return the numberNonPayableCitations
	 */
	public Integer getNumberOfNonPayableCitations() {
		return numberOfNonPayableCitations;
	}

	/**
	 * Gets the number payable citations.
	 * 
	 * @return the numberPayableCitations
	 */
	public Integer getNumberOfPayableCitations() {
		return numberOfPayableCitations;
	}

	/**
	 * Gets the total fine due.
	 * 
	 * @return the totalFineDue
	 */
	public BigDecimal getTotalFineDue() {
		return totalFineDue;
	}

	/**
	 * Gets the vehicle record.
	 * 
	 * @return the vehicleRecord
	 */
	public VehicleRecord getVehicleRecord() {
		return vehicleRecord;
	}

	/**
	 * Sets the citation details.
	 * 
	 * @param citationDetails the citationDetails to set
	 */
	public void setCitationDetails(List <CitationDetail> citationDetails) {
		this.citationDetails = citationDetails;
	}

	/**
	 * Sets the docket number.
	 * 
	 * @param docketNumber the docketNumber to set
	 */
	public void setDocketNumber(String docketNumber) {
		this.docketNumber = docketNumber;
	}

	/**
	 * Gets the number of citations.
	 * 
	 * @return the number of citations
	 */
	public int getNumberOfCitations() {
		return numberOfCitations;
	}

	/**
	 * Sets the number of citations.
	 * 
	 * @param numberOfCitations the new number of citations
	 */
	public void setNumberOfCitations(int numberOfCitations) {
		this.numberOfCitations = numberOfCitations;
	}

	/**
	 * Sets the number non payable citations.
	 * 
	 * @param numberOfNonPayableCitations the number of non payable citations
	 */
	public void setNumberOfNonPayableCitations(
			Integer numberOfNonPayableCitations) {
		this.numberOfNonPayableCitations = numberOfNonPayableCitations;
	}

	/**
	 * Sets the number payable citations.
	 * 
	 * @param numberOfPayableCitations the number of payable citations
	 */
	public void setNumberOfPayableCitations(Integer numberOfPayableCitations) {
		this.numberOfPayableCitations = numberOfPayableCitations;
	}

	/**
	 * Sets the total fine due.
	 * 
	 * @param totalFineDue the totalFineDue to set
	 */
	public void setTotalFineDue(BigDecimal totalFineDue) {
		this.totalFineDue = totalFineDue;
	}

	/**
	 * Sets the vehicle record.
	 * 
	 * @param vehicleRecord the vehicleRecord to set
	 */
	public void setVehicleRecord(VehicleRecord vehicleRecord) {
		this.vehicleRecord = vehicleRecord;
	}

	/**
	 * Gets the dll return code.
	 * 
	 * @return the dll return code
	 */
	public String getDllReturnCode() {
		return dllReturnCode;
	}

	/**
	 * Sets the dll return code.
	 * 
	 * @param dllReturnCode the new dll return code
	 */
	public void setDllReturnCode(String dllReturnCode) {
		this.dllReturnCode = dllReturnCode;
	}
}
/**
 *  Modification History:
 *
 *  $Log: FtaFtpFinePaymentClearanceApplication.java,v $
 *  Revision 1.21  2012/03/14 01:57:55  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.20  2011/01/30 06:48:03  mwtjc1
 *  IsFeeRequired is set to true
 *
 *  Revision 1.19  2010/11/30 23:44:16  mwtjc1
 *  numberOfCitations added
 *
 *  Revision 1.18  2010/11/18 23:51:33  mwtjc1
 *  feeRateCodeForTotalServiceFeeAmount and totalServiceFeeAmount added
 *
 *  Revision 1.17  2010/11/18 23:25:36  mwtjc1
 *  interactionActivityOfInterest is moved here from FtaFtpProcessContext
 *
 *  Revision 1.16  2010/09/15 16:24:13  mwtjc1
 *  footer added
 *
 */
