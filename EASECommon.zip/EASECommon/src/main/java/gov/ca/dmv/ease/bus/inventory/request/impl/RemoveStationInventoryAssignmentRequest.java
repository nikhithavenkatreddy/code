/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request for removing inventory assignment items from a station
 * File: RemoveStationInventoryAssignmentRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Jul 12, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/07/13 17:31:07 $
 * Last Changed By: $Author: mwkfh $
 */
public class RemoveStationInventoryAssignmentRequest extends
		AbstractMultipleItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5980084075472677995L;

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param items the items
	 */
	public RemoveStationInventoryAssignmentRequest(IUserContext context,
			IInventoryItem... items) {
		super(context, items);
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param listOfItems the list of items
	 */
	public RemoveStationInventoryAssignmentRequest(IUserContext context,
			List <IInventoryItem> listOfItems) {
		super(context, listOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: RemoveStationInventoryAssignmentRequest.java,v $
 *  Revision 1.1  2011/07/13 17:31:07  mwkfh
 *  added RemoveStationInventoryAssignmentRequest
 *
 */
