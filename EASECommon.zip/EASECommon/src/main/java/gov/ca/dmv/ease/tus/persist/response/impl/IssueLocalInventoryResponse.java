/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response for IssueLocalInventoryPersistenceBusinessObject response
 * 
 * File: IssueLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Sep 17, 2009
 * 
 * @author MWKFH
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/10/12 20:57:10 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class IssueLocalInventoryResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 507652743384544226L;
	/** The domain object. */
	private IInventoryItem inventoryItem;

	/**
	 * 
	 */
	public IssueLocalInventoryResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public IssueLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ex the ex
	 */
	public IssueLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public IssueLocalInventoryResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Instantiates a new issued item response.
	 * 
	 */
	public IssueLocalInventoryResponse(IInventoryItem inventoryItem) {
		super();
		setIssuedItem(inventoryItem);
	}

	/**
	 * This method returns the results of the retrieve business object function in persistence service.
	 * 
	 * @return the domainObject
	 */
	public IInventoryItem getIssuedItem() {
		super.throwExceptionIfErrorFound();
		return inventoryItem;
	}

	/**
	 * This method sets the results to this response object.
	 * 
	 * @param IInventoryItem the domainObject to set
	 */
	private void setIssuedItem(IInventoryItem inventoryItem) {
		this.inventoryItem = inventoryItem;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueLocalInventoryResponse.java,v $
 *  Revision 1.3  2010/10/12 20:57:10  mwpxp2
 *  Added constructors from super
 *
 *  Revision 1.2  2010/10/06 22:32:39  mwkfh
 *  updated to use IInventoryItem
 *
 *  Revision 1.1  2010/09/20 18:25:45  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/20 16:49:52  mwkfh
 *  added issue local inv item
 *
 */
