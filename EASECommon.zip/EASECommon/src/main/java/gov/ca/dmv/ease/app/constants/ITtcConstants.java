/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

import java.util.Arrays;
import java.util.List;

/**
 * Description: This defines the constants for TTC. 
 * File: ITtcConstants.java 
 * Module: gov.ca.dmv.ease.app.constants
 * Created: July 19, 2010
 * @author MWKFH
 * @version $Revision: 1.4 $ 
 * Last Changed: $Date: 2012/07/27 18:18:05 $ Last
 * Changed By: $Author: mwhys $
 */
public interface ITtcConstants {
	/** The AD d_ cour t_ rest r_ ttc. */
	String ADD_COURT_RESTR_TTC = "12M";
	/** The ADL. */
	String ADL = "ADL";
	/** The Constant CDA_TTC. */
	String CDA = "CDA";
	/** The COUNSELOR_INQUIRY. */
	String COUNSELOR_INQUIRY = "07Q";
	/** The DAF. */
	String DAF = "DAF";
	/** The DIR. */
	String DIR = "DIR";
	/** The Constant DL_INQUIRY_TCODE. */
	String DL_INQUIRY_TCODE = "DLI";
	/** The dl ttc. */
	String[] DL_TTC = { "DLA", "DLC", "DLD", "DLE", "DRT", "DLP" };
	/** The D l_ tt c_ withou t_ dlp. */
	String[] DL_TTC_WITHOUT_DLP = { "DLA", "DLC", "DLD", "DLE", "DRT" };
	/** The Constant DLA_TTC. */
	String DLA = "DLA";
	/** The Constant DLC_TTC. */
	String DLC = "DLC";
	/** The Constant DLD_TTC. */
	String DLD = "DLD";
	/** The Constant DLE_TTC. */
	String DLE = "DLE";
	/** The Constant DLP_TTC. */
	String DLP = "DLP";
	/** The driver license application. */
	List <String> DRIVER_LICENSE_APPLICATION_TTCS = Arrays.asList("DLA", "DLD",
			"DLE", "DLC", "DLP", "DRT");
	/** The DRIVING school instruction lic ttc. */
	String DRIVING_SCHOOL_INST_LIC_TTC = "20M";
	/** The MIS c_ drive r_ recor d_ update. */
	String MISC_DRIVER_RECORD_UPDATE = "30U";
	/** The AUTOMATED TEMP DL 22 application. */
	String AUTOMATED_TEMP_DL_22_APPLICATION = "22M";
	/** The Constant DRT_TTC. */
	String DRT = "DRT";
	/** The Constant FCP. */
	String FCP = "FCP";
	/** The FR PENALTY FEE PAYMENT TTC. */
	String FR_PENALTY_FEE_PAYMENT_TTC = "14M";
	/** The MEDICA l_ repor t_ update. */
	String MEDICAL_REPORT_UPDATE = "05M";
	/** The ID ttc. */
	String[] ID_TTC = { "IDA", "IDC", "IDS", "IDP", "IRT" };
	/** The Constant IDA_TTC. */
	String IDA = "IDA";
	/** The IDC. */
	String IDC = "IDC";
	/** The Constant IDP_TTC. */
	String IDP = "IDP";
	/** The Constant IDS_TTC. */
	String IDS = "IDS";
	/** The IRT. */
	String IRT = "IRT";
	/** The MIS c_ fixe d_ fe e_ ttc. */
	String MISC_FIXED_FEE_TTC = "92M";
	/** The MIS c_ varie d_ fe e_ ttc. */
	String MISC_VARIED_FEE_TTC = "98M";
	/** The Constant OCCUPATIONAL_LICENSE_INQUIRY. */
	String OCCUPATIONAL_LICENSE_INQUIRY = "OLI";
	/** The PRF. */
	String PRF = "PRF";
	/** The REISSU e_ fe e_ payment. */
	String REISSUE_FEE_PAYMENT = "04M";
	/** The RM v_ cour t_ rest r_ ttc. */
	String RMV_COURT_RESTR_TTC = "13M";
	/** The salesperson license application. */
	List <String> SALESPERSON_LICENSE_APPLICATION_TTC = Arrays.asList("SPO",
			"SPR", "SRX", "SPD", "SPC");
	/** The SIXT y_ u. */
	String SIXTY_U = "60U";
	/** The SP ttc. */
	String[] SP_TTC = { "SPC", "SPD", "SPO", "SPR", "SRX" };
	/** The Constant SPC_TTC. */
	String SPC = "SPC";
	/** The Constant SPD_TTC. */
	String SPD = "SPD";
	/** The SPECIA l_ certificat e_ fe e_ payment. */
	String SPECIAL_CERTIFICATE_FEE_PAYMENT = "06M";
	/** The Constant SPO_TTC. */
	String SPO = "SPO";
	/** The Constant SPR_TTC. */
	String SPR = "SPR";
	/** The Constant SRX_TTC. */
	String SRX = "SRX";
	/** The TRAN s_ trn g_ pm t_ ttc. */
	String TRANS_TRNG_PMT_TTC = "07M";
	/** The Constant SERVICE_ORDER_INQ. */
	String SERVICE_ORDER_INQ = "60U";
	/** The dl review ttc. */
	String[] TTC_DLREVIEW = { "DLA", "IDA", "DLC", "DLD", "DLE", "DRT", "IDS",
			"IDC", "CDA", "DLC", "DLD", "DLE", "DRT", "DAF" };
	/** The 92M. */
	String _92M = "92M";
	/** The 06M. */
	String _06M = "06M";
	/** The 07M. */
	String _07M = "07M";
	/** The 38U. */
	String _38U = "38U";
	/** The 10Q. */
	String _10Q = "10Q";
	/** The DL cancellation. */
	String DL_CANCELLATION = "70U";
	/** The DL ID TTCs. */
	String[] DL_ID_TTCS = { "DLA", "DLD", "DLE", "DLC", "DLP", "DRT", "IDA",
			"IDC", "IDS", "IDP", "IRT" };
	/** The DL IDs SP TTCs. */
	String[] DL_ID_SP_TTCS = { "DLA", "DLD", "DLE", "DLC", "DLP", "DRT", "IDA",
			"IDC", "IDS", "IDP", "IRT", "SPO", "SPR", "SRX", "SPD", "SPC" };
	/** The DL ID TTCs without photo retake. */
	String[] DL_ID_TTCS_WITHOUT_PHOTO_RETAKE = { "DLA", "DLD", "DLE", "DLC",
			"DLP", "IDA", "IDC", "IDS", "IDP" };
	/** The NO_WORK_DATE_TTCS_LIST. These TTCs do not require a work date. */
	Object[] NO_WORK_DATE_TTCS_LIST = { DRT, IRT, CDA };
}
/**
 * Modification History:
 * $Log: ITtcConstants.java,v $
 * Revision 1.4  2012/07/27 18:18:05  mwhys
 * Added 07Q.
 *
 * Revision 1.3  2011/10/25 23:48:53  mwhys
 * Added NO_WORK_DATE_TTCS_LIST.
 *
 * Revision 1.2  2011/07/27 01:18:38  mwrrv3
 * Code formatted and added 10Q TTC constant. Defect# 6557.
 *
 * Revision 1.1  2011/05/31 22:04:56  mwtjc1
 * moved from EASEDriverLicense
 *
 * Revision 1.34  2011/02/15 23:40:43  mwhxb3
 * Added constants.
 *
 * Revision 1.33  2011/02/15 18:16:09  mwrrv2
 * _38U added
 *
 * Revision 1.32  2011/01/29 02:26:30  mwrrv2
 * Inventory defect fix.
 *
 * Revision 1.31  2011/01/20 19:38:39  mwtjc1
 * comments updated
 *
 * Revision 1.30  2011/01/20 19:38:18  mwtjc1
 * SPX removed
 *
 * Revision 1.29  2011/01/10 21:56:17  mwtjc1
 * DL_TTC_WITHOUT_DLP added
 *
 * Revision 1.28  2011/01/03 01:53:50  mwhxb3
 * Added TTC constants.
 *
 * Revision 1.27  2011/01/03 01:44:29  mwhxb3
 * Added AUTOMATED_DL_TTC.
 *
 * Revision 1.26  2011/01/03 01:38:07  mwhxb3
 * Added DL_ID_SP_TTCS.
 *
 * Revision 1.25  2010/12/24 18:09:38  mwhxb3
 * Added DL_ID_TTCS.
 *
 * Revision 1.24  2010/12/23 06:41:18  mwkkc
 * Merged Production code from Branch
 *
 * Revision 1.22.4.2  2010/12/23 04:11:54  mwkkc
 * Rebase from head - DL
 *
 * Revision 1.23  2010/12/21 20:42:43  mwrrv2
 * ADDED AUTOMATED_TEMP_DL_22_APPLICATION = "22M"
 *
 * Revision 1.22  2010/12/16 22:09:51  mwnrk
 * Added new constant for DL_CANCELLATION 70U.
 *
 * Revision 1.21  2010/12/15 23:02:23  mwtjc1
 * _92M added
 *
 * Revision 1.20  2010/11/20 02:35:24  mwrrv2
 * Added 05M constant.
 *
 * Revision 1.19  2010/11/18 23:54:48  mwpxp2
 * Added missing javadoc; sorted
 *
 * Revision 1.18  2010/10/29 15:58:36  mwyxg1
 * add sixty U
 *
 * Revision 1.17  2010/10/15 21:10:56  mwyxg1
 * add PRF
 *
 * Revision 1.16  2010/10/08 20:18:43  mwuxb
 * Added TTC constant DLP to the list.
 *
 * Revision 1.15  2010/09/12 20:24:13  mwcsj3
 * Added constant for 14M TTC
 *
 * Revision 1.14  2010/09/01 16:22:10  mwtjc1
 * FCP added
 *
 * Revision 1.13  2010/09/01 00:04:24  mwhxb3
 * Added TTC constants.
 *
 * Revision 1.12  2010/08/31 16:18:49  mwrrv2
 * Updated support for 04M and 06M ttc.
 *
 * Revision 1.11  2010/08/20 17:30:54  mwcsj3
 * Added more ID TTC constants
 *
 * Revision 1.10  2010/08/11 18:20:44  mwyxg1
 * add DAF
 *
 * Revision 1.9  2010/08/10 23:09:13  mwcsj3
 * Added constants
 *
 * Revision 1.8  2010/08/06 00:58:14  mwtjc1
 * OCCUPATIONAL_LICENSE_INQUIRY added
 *
 * Revision 1.7  2010/08/03 18:52:19  mwyxg1
 * add new ttcs
 *
 * Revision 1.6  2010/08/03 17:42:41  mwhxb3
 * Added DLD_TTC.
 *
 * Revision 1.5  2010/08/03 17:40:55  mwhxb3
 * Added DLC_TTC.
 *
 * Revision 1.4  2010/08/03 00:13:24  mwhxb3
 * Added  DLE_TTC.
 *
 * Revision 1.3  2010/08/03 00:09:49  mwhxb3
 * Added DRT_TTC.
 *
 * Revision 1.2  2010/07/28 23:14:12  mwrrv2
 * Updated to support CheckTtcType decision activity.
 *
 * Revision 1.1  2010/07/26 22:53:27  mwkfh
 * Changed to Interface
 *
 * Revision 1.3  2010/07/26 22:30:31  mwpxp2
 * Fixed file footer; added javadoc; added fixme for package location
 *
 * Revision 1.2  2010/07/23 00:01:57  mwuxb
 * Added constant DL_INQUIRY_TCODE
 * 
 * Revision 1.1  2010/07/19 18:11:05  mwkfh
 * New TTC constants class.
 * 
 */
