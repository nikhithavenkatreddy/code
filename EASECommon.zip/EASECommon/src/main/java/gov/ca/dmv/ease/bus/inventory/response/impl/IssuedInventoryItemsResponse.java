/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.conversion.impl.ContiguousItemSequenceConverter;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemsResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import java.util.List;

/**
 * Description: I am response carrying issued inventory item list
 * File: IssuedInventoryItemsResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response.impl
 * Created: Dec 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/12/23 06:18:22 $
 * Last Changed By: $Author: mwkkc $
 */
public class IssuedInventoryItemsResponse extends InventoryServiceResponse
		implements IIssuedInventoryItemsResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5720327831920083440L;
	/** The issued item list. */
	private List <IInventoryItem> issuedItemList;
	/** The issued sequence list. */
	private List <IContiguousItemSequence> issuedSequenceList;
	/** The available inventory count */
	private int availableInventoryCount = -1;

	/**
	 * Instantiates a new issued inventory item response.
	 */
	protected IssuedInventoryItemsResponse() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public IssuedInventoryItemsResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * @param ex
	 */
	public IssuedInventoryItemsResponse(EaseException ex,
			int availableInventoryCount) {
		super(ex);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public IssuedInventoryItemsResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public IssuedInventoryItemsResponse(IErrorCollector collector,
			int availableInventoryCount) {
		super(collector);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * Instantiates a new issued inventory item response.
	 * 
	 * @param anItem the an item
	 */
	public IssuedInventoryItemsResponse(List <IInventoryItem> anItemList) {
		super();
		setIssuedItemList(anItemList);
	}

	/**
	 * Instantiates a new issued inventory items response.
	 * 
	 * @param anItemList the an item list
	 * @param availableInventoryCount the available inventory count
	 */
	public IssuedInventoryItemsResponse(List <IInventoryItem> anItemList,
			int availableInventoryCount) {
		super();
		setIssuedItemList(anItemList);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * Returns the number of available inventory
	 * 
	 * @return
	 */
	public int getAvailableInventoryCount() {
		return availableInventoryCount;
	}

	/**
	 * Gets the issued item list.
	 * 
	 * @return the issuedItemList
	 */
	public List <IInventoryItem> getIssuedItemList() {
		return issuedItemList;
	}

	/**
	 * Gets the issued item list as a sequence list.
	 * 
	 * @return the issuedSequenceList
	 */
	public List <IContiguousItemSequence> getIssuedSequenceList() {
		if (issuedSequenceList == null) {
			issuedSequenceList = ContiguousItemSequenceConverter.getInstance()
					.toItemSequenceListFrom(getIssuedItemList());
		}
		return issuedSequenceList;
	}

	/**
	 * Sets the number of available inventory
	 * 
	 * @param availableInventoryCount
	 */
	private void setAvailableInventoryCount(int availableInventoryCount) {
		this.availableInventoryCount = availableInventoryCount;
	}

	/**
	 * Sets the issued item.
	 * 
	 * @param anItem the an item
	 */
	protected void setIssuedItemList(List <IInventoryItem> anItemList) {
		issuedItemList = anItemList;
		issuedSequenceList = null;
		if (issuedItemList == null) {
			setAffectedItemCount(0);
		}
		else {
			setAffectedItemCount(issuedItemList.size());
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssuedInventoryItemsResponse.java,v $
 *  Revision 1.5  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.3.4.1  2010/12/23 03:13:56  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.4  2010/12/19 21:48:45  mwtjc1
 *  IssuedInventoryItemsResponse(List <IInventoryItem> anItemList,int availableInventoryCount) constructor added
 *
 *  Revision 1.3  2010/12/13 20:48:19  mwkfh
 *  added availableInventoryCount for multiple issue response
 *
 *  Revision 1.2  2010/12/07 19:31:31  mwkfh
 *  updated getIssuedSequenceList return value
 *
 *  Revision 1.1  2010/12/05 00:06:16  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 */
