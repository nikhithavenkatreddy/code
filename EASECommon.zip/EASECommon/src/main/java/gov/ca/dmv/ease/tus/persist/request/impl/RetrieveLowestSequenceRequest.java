/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveLowestSequenceResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I represent the request to retrieve the object with the
 *  lowest sequence number from the persistent store
 * File: RetrieveLowestSequenceRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Nov 3, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/11/03 23:42:43 $
 * Last Changed By: $Author: mwkfh $
 */
public class RetrieveLowestSequenceRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5718831493609618922L;
	/** The item type code. */
	private String itemTypeCode;
	/** The office id. */
	private String officeId;

	/**
	 * Instantiates a new local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public RetrieveLowestSequenceRequest(IUserContext userContext,
			String itemTypeCode, String officeId) {
		super(userContext);
		this.itemTypeCode = itemTypeCode;
		this.officeId = officeId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public RetrieveLowestSequenceResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * This method gets the item type code based on which the search has to be done.
	 * 
	 * @return the itemTypeCode
	 */
	public String getItemTypeCode() {
		return itemTypeCode;
	}

	/**
	 * This method gets the office id based on which the search has to be done.
	 * 
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveLowestSequenceRequest.java,v $
 *  Revision 1.1  2011/11/03 23:42:43  mwkfh
 *  Initial
 *
 */
