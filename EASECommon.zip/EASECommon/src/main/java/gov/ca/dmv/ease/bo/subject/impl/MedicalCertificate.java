/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.logging.IAuditable;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Business Object for medical certificate
 * File: MedicalCertificate.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: Feb 4, 2013 
 * @author MWSKH1  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2013/05/29 16:49:46 $
 * Last Changed By: $Author: mwskh1 $
 */
public class MedicalCertificate extends Subject implements IAuditable {
	/** The BLANK. */
	private static final String BLANK = "";
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory
			.getLog(MedicalCertificate.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7864442830241831518L;
	/** The issue Date of medical certificate */
	private Date issueDate;
	/** The medical examiner LicNumber. */
	private String examinerLicNumber;
	/** The medical examiner PhoneNumber. */
	private String examinerPhoneNumber;
	private String examinerPhoneNumberAreadCode;
	private String examinerPhoneNumberPrefix;
	private String examinerPhoneNumberSuffix;
	/** The examinerState. */
	private String examinerState;
	/** The medical examiner rSpecialty. */
	private String examinerSpecialty;
	/** The medical examiner LastName. */
	private String examinerLastName;
	/** The medical examiner FirstName. */
	private String examinerFirstName;
	/** The medical examiner Middle Name. */
	private String examinerMiddleName;
	/** The examiner Suffix. */
	private String examinerSuffix;
	/** The restrictions. There can be up to 10*/
	private List <String> restrictions;
	/** The self Certification code. */
	private String selfCertification;

	/**
	 * Default Constructor.
	 */
	public MedicalCertificate() {
	}

	/**
	 * Instantiates a new person.
	 *
	 * @param person the person
	 */
	public MedicalCertificate(MedicalCertificate medicalCertificate) {
		super();
		copy(medicalCertificate);
	}

	/**
	 * @return the issueDate
	 */
	public Date getIssueDate() {
		return issueDate;
	}

	/**
	 * @param issueDate the issueDate to set
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	/**
	 * @return the examinerLicNumber
	 */
	public String getExaminerLicNumber() {
		return examinerLicNumber;
	}

	/**
	 * @param examinerLicNumber the examinerLicNumber to set
	 */
	public void setExaminerLicNumber(String examinerLicNumber) {
		this.examinerLicNumber = examinerLicNumber;
	}

	/**
	 * @return the examinerPhoneNumber
	 */
	public String getExaminerPhoneNumber() {
		return examinerPhoneNumber;
	}

	/**
	 * @param examinerPhoneNumber the examinerPhoneNumber to set
	 */
	public void setExaminerPhoneNumber(String examinerPhoneNumber) {
		this.examinerPhoneNumber = examinerPhoneNumber;
	}
	
	public String getExaminerPhoneNumberAreadCode() {
		return examinerPhoneNumberAreadCode;
	}

	public void setExaminerPhoneNumberAreadCode(String examinerPhoneNumberAreadCode) {
		this.examinerPhoneNumberAreadCode = examinerPhoneNumberAreadCode;
	}

	public String getExaminerPhoneNumberPrefix() {
		return examinerPhoneNumberPrefix;
	}

	public void setExaminerPhoneNumberPrefix(String examinerPhoneNumberPrefix) {
		this.examinerPhoneNumberPrefix = examinerPhoneNumberPrefix;
	}

	public String getExaminerPhoneNumberSuffix() {
		return examinerPhoneNumberSuffix;
	}

	public void setExaminerPhoneNumberSuffix(String examinerPhoneNumberSuffix) {
		this.examinerPhoneNumberSuffix = examinerPhoneNumberSuffix;
	}

	/**
	 * @return the examinerState
	 */
	public String getExaminerState() {
		return examinerState;
	}

	/**
	 * @param examinerState the examinerState to set
	 */
	public void setExaminerState(String examinerState) {
		this.examinerState = examinerState;
	}

	/**
	 * @return the examinerSpecialty
	 */
	public String getExaminerSpecialty() {
		return examinerSpecialty;
	}

	/**
	 * @param examinerSpecialty the examinerSpecialty to set
	 */
	public void setExaminerSpecialty(String examinerSpecialty) {
		this.examinerSpecialty = examinerSpecialty;
	}

	/**
	 * @return the examinerLastName
	 */
	public String getExaminerLastName() {
		return examinerLastName;
	}

	/**
	 * @param examinerLastName the examinerLastName to set
	 */
	public void setExaminerLastName(String examinerLastName) {
		this.examinerLastName = examinerLastName;
	}

	/**
	 * @return the examinerFirstName
	 */
	public String getExaminerFirstName() {
		return examinerFirstName;
	}

	/**
	 * @param examinerFirstName the examinerFirstName to set
	 */
	public void setExaminerFirstName(String examinerFirstName) {
		this.examinerFirstName = examinerFirstName;
	}

	/**
	 * @return the examinerMiddleName
	 */
	public String getExaminerMiddleName() {
		return examinerMiddleName;
	}

	/**
	 * @param examinerMiddleName the examinerMiddleName to set
	 */
	public void setExaminerMiddleName(String examinerMiddleName) {
		this.examinerMiddleName = examinerMiddleName;
	}

	/**
	 * @return the examinerSuffix
	 */
	public String getExaminerSuffix() {
		return examinerSuffix;
	}

	/**
	 * @param examinerSuffix the examinerSuffix to set
	 */
	public void setExaminerSuffix(String examinerSuffix) {
		this.examinerSuffix = examinerSuffix;
	}

	/**
	 * @return the restrictions
	 */
	public List <String> getRestrictions() {
		return restrictions;
	}

	/**
	 * @param restrictions the restrictions to set
	 */
	public void setRestrictions(List <String> restrictions) {
		this.restrictions = restrictions;
	}

	/**
	 * Copy  medical certificate restrictions
	 *
	 * @param licenseNumbersOfDuplicateAniRecordsToCopy the license numbers of duplicate ani records to copy
	 */
	protected void copyRestrictions(List <String> restrictions) {
		if (isNotNull(restrictions)) {
			for (String licenseNumberToCopy : restrictions) {
				addRestrictions(licenseNumberToCopy);
			}
		}
	}

	/**
	 * Adds the medical certificate restrictions
	 *
	 * @param licenseNumber the license number
	 */
	public void addRestrictions(String licenseNumber) {
		if (!EaseUtil.isNotNull(this.restrictions)) {
			this.restrictions = new ArrayList <String>();
			this.restrictions.add(licenseNumber);
		}
		else {
			for (String restriction : restrictions) {
				if (licenseNumber.equalsIgnoreCase(restriction)) {
					//If Driver License # already exist do not add it to the list.
					return;
				}
			}
			this.restrictions.add(licenseNumber);
		}
	}

	/**
	 * @return the selfCertification
	 */
	public String getSelfCertification() {
		return selfCertification;
	}

	/**
	 * @param selfCertification the selfCertification to set
	 */
	public void setSelfCertification(String selfCertification) {
		this.selfCertification = selfCertification;
	}

	/**
	 * This method is to copy Medical Certificate.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(MedicalCertificate dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null person argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);

		//Copy Issue date
		if (isNotNull(dataToCopy.getIssueDate())) {
			setIssueDate(new Date(dataToCopy.getIssueDate().getTime()));
		}
		else {
			setIssueDate(null);
		}
		//Copy  Examiner License Number
		setExaminerLicNumber(dataToCopy.getExaminerLicNumber());
		//Copy  Examiner Phone Number
		setExaminerPhoneNumber(dataToCopy.getExaminerPhoneNumber());
		setExaminerPhoneNumberAreadCode(dataToCopy.getExaminerPhoneNumberAreadCode());
		setExaminerPhoneNumberPrefix(dataToCopy.getExaminerPhoneNumberPrefix());
		setExaminerPhoneNumberSuffix(dataToCopy.getExaminerPhoneNumberSuffix());
		//Copy  Examiner State
		setExaminerState(dataToCopy.getExaminerState());
		//Copy  Examiner Specialty
		setExaminerSpecialty(dataToCopy.getExaminerSpecialty());
		//Copy  Examiner Last Name
		setExaminerLastName(dataToCopy.getExaminerLastName());
		//Copy  Examiner First Name
		setExaminerFirstName(dataToCopy.getExaminerFirstName());
		//Copy  Examiner Middle Name
		setExaminerMiddleName(dataToCopy.getExaminerMiddleName());
		//Copy  Examiner Suffix
		setExaminerSuffix(dataToCopy.getExaminerSuffix());
		//Copy medical certificate restrictions
		copyRestrictions(dataToCopy.getRestrictions());
		//Copy self ceritifcation code
		setSelfCertification(dataToCopy.getSelfCertification());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		MedicalCertificate other = (MedicalCertificate) obj;
		if (issueDate == null) {
			if (other.issueDate != null) {
				return false;
			}
		}
		else if (!issueDate.equals(other.issueDate)) {
			return false;
		}
		if (examinerLicNumber == null) {
			if (other.examinerLicNumber != null) {
				return false;
			}
		}
		else if (!examinerLicNumber.equals(other.examinerLicNumber)) {
			return false;
		}
		if (examinerPhoneNumber == null) {
			if (other.examinerPhoneNumber != null) {
				return false;
			}
		}
		else if (!examinerPhoneNumber.equals(other.examinerPhoneNumber)) {
			return false;
		}
		if (examinerPhoneNumberAreadCode == null) {
			if (other.examinerPhoneNumberAreadCode != null) {
				return false;
			}
		}
		else if (!examinerPhoneNumberAreadCode.equals(other.examinerPhoneNumberAreadCode)) {
			return false;
		}
		if (examinerPhoneNumberPrefix == null) {
			if (other.examinerPhoneNumberPrefix != null) {
				return false;
			}
		}
		else if (!examinerPhoneNumberPrefix.equals(other.examinerPhoneNumberPrefix)) {
			return false;
		}
		if (examinerPhoneNumberSuffix == null) {
			if (other.examinerPhoneNumberSuffix != null) {
				return false;
			}
		}
		else if (!examinerPhoneNumberSuffix.equals(other.examinerPhoneNumberSuffix)) {
			return false;
		}
		if (examinerState == null) {
			if (other.examinerState != null) {
				return false;
			}
		}
		else if (!examinerState.equals(other.examinerState)) {
			return false;
		}
		if (examinerSpecialty == null) {
			if (other.examinerSpecialty != null) {
				return false;
			}
		}
		else if (!examinerSpecialty.equals(other.examinerSpecialty)) {
			return false;
		}
		if (examinerLastName == null) {
			if (other.examinerLastName != null) {
				return false;
			}
		}
		else if (!examinerLastName.equals(other.examinerLastName)) {
			return false;
		}
		if (examinerFirstName == null) {
			if (other.examinerFirstName != null) {
				return false;
			}
		}
		else if (!examinerFirstName.equals(other.examinerFirstName)) {
			return false;
		}
		if (examinerMiddleName == null) {
			if (other.examinerMiddleName != null) {
				return false;
			}
		}
		else if (!examinerMiddleName.equals(other.examinerMiddleName)) {
			return false;
		}
		if (examinerSuffix == null) {
			if (other.examinerSuffix != null) {
				return false;
			}
		}
		else if (!examinerSuffix.equals(other.examinerSuffix)) {
			return false;
		}
		if (restrictions == null) {
			if (other.restrictions != null) {
				return false;
			}
		}
		else if (!restrictions.equals(other.restrictions)) {
			return false;
		}
		if (selfCertification == null) {
			if (other.selfCertification != null) {
				return false;
			}
		}
		else if (!selfCertification.equals(other.selfCertification)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((issueDate == null) ? 0 : issueDate.hashCode());
		result = prime
				* result
				+ ((examinerLicNumber == null) ? 0 : examinerLicNumber
						.hashCode());
		result = prime
				* result
				+ ((examinerPhoneNumber == null) ? 0 : examinerPhoneNumber
						.hashCode());
		result = prime
				* result
				+ ((examinerPhoneNumberAreadCode == null) ? 0 : examinerPhoneNumberAreadCode
						.hashCode());
		result = prime
				* result
				+ ((examinerPhoneNumberPrefix == null) ? 0 : examinerPhoneNumberPrefix
						.hashCode());
		result = prime
				* result
				+ ((examinerPhoneNumberSuffix == null) ? 0 : examinerPhoneNumberSuffix
						.hashCode());
		result = prime * result
				+ ((examinerState == null) ? 0 : examinerState.hashCode());
		result = prime
				* result
				+ ((examinerSpecialty == null) ? 0 : examinerSpecialty
						.hashCode());
		result = prime
				* result
				+ ((examinerLastName == null) ? 0 : examinerLastName.hashCode());
		result = prime
				* result
				+ ((examinerFirstName == null) ? 0 : examinerFirstName
						.hashCode());
		result = prime
				* result
				+ ((examinerMiddleName == null) ? 0 : examinerMiddleName
						.hashCode());
		result = prime * result
				+ ((examinerSuffix == null) ? 0 : examinerSuffix.hashCode());
		result = prime * result
				+ ((restrictions == null) ? 0 : restrictions.hashCode());
		result = prime
				* result
				+ ((selfCertification == null) ? 0 : selfCertification
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.subject.impl.Subject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("issueDate", issueDate, anIndent, aBuilder);
		outputKeyValue("examinerLicNumber", examinerLicNumber, anIndent,
				aBuilder);
		outputKeyValue("examinerPhoneNumber", examinerPhoneNumber, anIndent,
				aBuilder);
		outputKeyValue("examinerPhoneNumberAreadCode", examinerPhoneNumberAreadCode, anIndent,
				aBuilder);
		outputKeyValue("examinerPhoneNumberPrefix", examinerPhoneNumberPrefix, anIndent,
				aBuilder);
		outputKeyValue("examinerPhoneNumberSuffix", examinerPhoneNumberSuffix, anIndent,
				aBuilder);
		outputKeyValue("examinerState", examinerState, anIndent, aBuilder);
		outputKeyValue("examinerSpecialty", examinerSpecialty, anIndent,
				aBuilder);
		outputKeyValue("examinerLastName", examinerLastName, anIndent, aBuilder);
		outputKeyValue("examinerFirstName", examinerFirstName, anIndent,
				aBuilder);
		outputKeyValue("examinerMiddleName", examinerMiddleName, anIndent,
				aBuilder);
		outputKeyValue("examinerSuffix", examinerSuffix, anIndent, aBuilder);
		outputKeyValue("restrictions", restrictions, anIndent, aBuilder);
		outputKeyValue("selfCertification", selfCertification, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	public void outputAuditLog(StringBuilder stringBuilder) {
		// TODO Auto-generated method stub
	}
}
/**
 * Modification History:
 *
 * $Log: MedicalCertificate.java,v $
 * Revision 1.2  2013/05/29 16:49:46  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.1.2.3  2013/05/15 22:12:00  mwjmf6
 * Added examinerPhoneNumberAreadCode, examinerPhoneNumberPrefix and examinerPhoneNumberSuffix
 *
 * Revision 1.1.2.2  2013/05/08 22:01:21  mwgxd3
 * CDLIS - remove expiration date - it is already in Person
 *
 * Revision 1.1.2.1  2013/03/09 00:13:17  mwgxd3
 * Update
 *
 * Revision 1.1  2013/02/28 21:04:07  mwskh1
 * initial commit
 *
 * $Initial $
 */
