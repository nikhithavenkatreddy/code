/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: I am to be used when there is no inventory item available of a given type in a given inventory
 * File: InventoryItemUnavailableException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/22 20:55:55 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryItemUnavailableException extends InventoryItemException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9164988919237051302L;

	/**
	 * Instantiates a new inventory item unavailable exception.
	 */
	public InventoryItemUnavailableException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public InventoryItemUnavailableException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public InventoryItemUnavailableException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public InventoryItemUnavailableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryItemUnavailableException.java,v $
 *  Revision 1.2  2010/09/22 20:55:55  mwpxp2
 *  hierarchy mod
 *
 *  Revision 1.1  2010/08/30 21:13:22  mwpxp2
 *  Initial
 *
 */
