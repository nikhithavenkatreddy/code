/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2010
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import java.util.List;

/**
 * Description: I am the response for IssueLocalInventoryPersistenceBusinessObjectList response
 * File: IssueMultipleLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Dec 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/12/23 06:18:23 $
 * Last Changed By: $Author: mwkkc $
 */
public class IssueMultipleLocalInventoryResponse extends
		PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2635995484155607009L;
	/** The inventory item list. */
	private List <IInventoryItem> inventoryItemList;
	/** The available inventory count */
	private int availableInventoryCount = -1;

	/**
	 * Default constructor
	 */
	public IssueMultipleLocalInventoryResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public IssueMultipleLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * @param ex
	 */
	public IssueMultipleLocalInventoryResponse(EaseException ex,
			int availableInventoryCount) {
		super(ex);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ex the ex
	 */
	public IssueMultipleLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ex the ex
	 */
	public IssueMultipleLocalInventoryResponse(Exception ex,
			int availableInventoryCount) {
		super();
		getErrorCollector().register(ex);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public IssueMultipleLocalInventoryResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Instantiates a new issued item list response.
	 * 
	 * @param inventoryItemList
	 */
	public IssueMultipleLocalInventoryResponse(
			List <IInventoryItem> inventoryItemList) {
		super();
		setIssuedItemList(inventoryItemList);
	}

	/**
	 * Instantiates a new issue multiple local inventory response.
	 * 
	 * @param inventoryItemList the inventory item list
	 * @param availableInventoryCount the available inventory count
	 */
	public IssueMultipleLocalInventoryResponse(
			List <IInventoryItem> inventoryItemList, int availableInventoryCount) {
		super();
		setIssuedItemList(inventoryItemList);
		setAvailableInventoryCount(availableInventoryCount);
	}

	/**
	 * Returns the number of available inventory count
	 * 
	 * @return availableInventoryCount
	 */
	public int getAvailableInventoryCount() {
		return availableInventoryCount;
	}

	/**
	 * This method returns the results of the retrieve business object function in persistence service.
	 * 
	 * @return the domainObject list
	 */
	public List <IInventoryItem> getIssuedItemList() {
		super.throwExceptionIfErrorFound();
		return inventoryItemList;
	}

	/**
	 * Sets the number of available inventory count
	 * 
	 * @param availableInventoryCount
	 */
	private void setAvailableInventoryCount(int availableInventoryCount) {
		this.availableInventoryCount = availableInventoryCount;
	}

	/**
	 * This method sets the results to this response object.
	 * 
	 * @param inventoryItemList the domainObject list to set
	 */
	private void setIssuedItemList(List <IInventoryItem> inventoryItemList) {
		this.inventoryItemList = inventoryItemList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueMultipleLocalInventoryResponse.java,v $
 *  Revision 1.4  2010/12/23 06:18:23  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.2.4.1  2010/12/23 03:13:54  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.3  2010/12/19 21:42:31  mwtjc1
 *  IssueMultipleLocalInventoryResponse(
 *  			List <IInventoryItem> inventoryItemList, int availableInventoryCount) added
 *
 *  Revision 1.2  2010/12/13 20:48:19  mwkfh
 *  added availableInventoryCount for multiple issue response
 *
 *  Revision 1.1  2010/12/05 00:03:16  mwkfh
 *  added IssueMultipleLocalInventoryReequest/Response
 *
 */
