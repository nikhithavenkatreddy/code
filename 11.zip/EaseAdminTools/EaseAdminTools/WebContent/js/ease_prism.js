// this event listener, variable and function are used for resetting the focus when within frameset
if (document.addEventListener) {
	document.addEventListener("focus", setActiveElement, true);
}
var focusedElement = document;
function setActiveElement(e) {
  focusedElement = e.target;    
}

var keyDownValue;
document.onkeypress = getkeyPressValue;

function getkeyPressValue(event){
	var keyPressValue = (window.event) ? window.event.keyCode : event.which;	
	event = window.event ? window.event : event;
	var obj = event.target || event.srcElement;
	// Backspace button key value is 8
	if(keyPressValue == 8){
		if (obj.type != 'text' && obj.type != 'password') {
			return false;
		}
		return true;
	} if(keyPressValue == 13){ // Enter button key value is 32
		// If the object id is City Code (residence or mailing) then don't
		// submit the form if the value not empty.
		if(obj.id == "MAIN_FORM:cityCode" || obj.id == "MAIN_FORM:mailCityCode" || obj.id == "MAIN_FORM:residenceCityCode") {
			if(obj.value == "" || obj.value == "*") {
				if(obj.id == "MAIN_FORM:residenceCityCode" && obj.value == "*") {
					// If the residence city code field has star then copy the
					// mailing city name and mailing state to residence city
					// name and residence state fields respectively.
					populateCityCodeInfo(document.getElementById("MAIN_FORM:residenceCityCode"), "ResidenceCityCode");
				}
				document.getElementById("MAIN_FORM:button1").click();
				return true;
			} else {
				return false;
			}
		}		
		else if(obj.id == "MAIN_FORM:addMoreChecks"){
			document.getElementById("MAIN_FORM:addMoreChecks").click();
			return true;
		}
		else if(obj.id == "MAIN_FORM:addMoreDebits"){
			document.getElementById("MAIN_FORM:addMoreDebits").click();
			return true;
		}
		else if(obj.id == "MAIN_FORM:addMoreReceipts"){
			document.getElementById("MAIN_FORM:addMoreReceipts").click();
			return true;
		} else if(document.getElementById("MAIN_FORM:PageName") != null && 
			document.getElementById("MAIN_FORM:PageName").value == "easeSessionExpire") {
			document.getElementById("MAIN_FORM:cancel").click();
		}
		// If the focus is on the following buttons other than first button
		// (generally ENTER button) the submit that
		// particular button in order to avoid submitting the ENTER button
		// always.
		else if(obj.id == "MAIN_FORM:button2" || obj.id == "MAIN_FORM:button3" || obj.id == "MAIN_FORM:button4" || obj.id == "MAIN_FORM:button5" || 
				obj.id == "MAIN_FORM:button6" || obj.id == "MAIN_FORM:button7" || obj.id == "MAIN_FORM:button8" || obj.id == "MAIN_FORM:button9" || 
				obj.id == "MAIN_FORM:button10" || obj.id == "MAIN_FORM:button11" || obj.id == "MAIN_FORM:button12" ){
			return true;
		}
		else {
			document.getElementById("MAIN_FORM:button1").click();
			return true;
		}
	}
}

//to disable mouse right click.
document.oncontextmenu = new Function("return false;");

var isAlt;
var isCtrl;
document.onkeydown = disableSpecialKeys;
//Disable all the special keys like F1 to F12, Alt+N, Backspace etc.
function disableSpecialKeys(e){
	if(window.event){ 
		//alert("if IE"+window.event.keyCode);
		keyDownValue = window.event.keyCode; 
		if(window.event.ctrlKey)
			isCtrl = true;
		else
			isCtrl = false;
		if(window.event.altKey)
			isAlt = true;
		else
			isAlt = false;
	} else {
		keyDownValue = e.which; 
		if(e.ctrlKey)
			isCtrl = true;
		else
			isCtrl = false;
		if(e.altKey)
			isAlt = true;
		else
			isAlt = false;
	}

	// Disable F1 = 112,  F2 = 113, F3 = 114, F4 = 115, F5 = 116, 
	// F7 = 118; F8 = 119, F9 = 120, F10 = 121, F11 = 122, F12 = 123
	// alert("Key Values is "+keyDownValue);
	if(keyDownValue == 112 || keyDownValue == 113 || keyDownValue == 114 || keyDownValue == 115 
			|| keyDownValue == 116 || keyDownValue == 118 || keyDownValue == 119
			|| keyDownValue == 120 || keyDownValue == 121 || keyDownValue == 122 || keyDownValue == 123
			|| keyDownValue == 27) {
		return false;
	}	
	//F6 = Print Screen Shot
	if(keyDownValue == 117 && document.getElementById("MAIN_FORM:PageName") != null){
		printTextAreaContent(document.getElementById("MAIN_FORM:PageName").value);
		return false;
	} 
	//Check if Ctrl or Alt is pressed 
	if(isCtrl || isAlt){
		//alert("keyDownValue   "+keyDownValue);
		//CTRL-C (Copy) = 67, CTRL-V (Paste) = 86 and CTRL-Z (Undo) = 90
		if(keyDownValue == 67 || keyDownValue == 86 || keyDownValue == 90 || keyDownValue == 61 || keyDownValue == 45) {
			return true;
		} else {			
			return false;
		}
	}
	return true;
}

//This function is going to extract the page contents or element contents and
//assign it to the string variable and formats it to text.
function printTextAreaContent(pageName){
	window.print();	
}