
//This function overwrites the TTC in the select DL transaction screen.
function overwrite(input, e) {
	var isNN = (navigator.appName.indexOf("Netscape") != -1);
	var keyCode = (isNN) ? e.which : e.keyCode;
	var filter = [8,17,18,19,20,27,37,38,39,40,45,46,93,144,145];
	if(!containsElement(filter, keyCode)){
		if(document.selection) {
		    // Create empty selection range
		   var selRange = document.selection.createRange();
		   // Set focus on the element
		
		   input.focus();
		   // Move selection start and end to 0 position
		
		   //selRange.moveStart ('character', 2);
		
		   // Move selection start and end to desired position
		   selRange.moveStart('character', 0);
		   selRange.moveEnd('character', 1);
	       selRange.select();
		} else if (input.selectionStart || input.selectionStart == '0') {
           begin = input.selectionStart;
           end = input.selectionEnd;
           if(end == begin){
        	   input.selectionEnd = end + 1;
        	   input.focus();
           }
	     }
	}
}
//Check the input element is contains in the array and return true if found otherwise false.
function containsElement(arr, ele) {
    var found = false;
    var index = 0;
    while(index < arr.length){
      if(arr[index] == ele){
    	  found = true;
          break;
      }
      else {
          index++;
      }
    }
    return found;
}