//For Informational Message we need to find out whether value got changed or not in the data table.
//Function to update fields when one is changed in data tables
function controlChangeForDataTable(obj, datatableId){
	var id =  obj.id;
	var idName = id.split(":");
	var currentIndex = idName[2];
	var newValue = document.getElementById(id).value;
	var originalValue = document.getElementById(id).defaultValue;
	newValue = newValue.toUpperCase();
	//alert("MAIN_FORM:" + datatableId + ":" + currentIndex + ":valueChange");
	if(newValue!=originalValue){
		document.getElementById("MAIN_FORM:" + datatableId + ":" + currentIndex + ":valueChange").value = "true";
	}
	else{
		document.getElementById("MAIN_FORM:" + datatableId + ":" + currentIndex + ":valueChange").value = "false";
	}
}