package gov.ca.dmv.ease.admintool.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.response.impl.SaveLocationAndStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveOfficeResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveWorkDateStatusResponse;
import gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.admin.impl.OfficeWorkdate;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AdminToolPersistenceServiceTest {
	/** The application context. */
	private ApplicationContext applicationContext;
	/** The fixture. */
	private AdminToolPersistenceService adminToolPersistenceService;

	@Before
	public void setUp() throws Exception {
		String[] configLocations = { "classpath:test-applicationContext-fw-services.xml" };
		applicationContext = new ClassPathXmlApplicationContext(configLocations);
		assertNotNull(applicationContext);
		adminToolPersistenceService = AdminToolPersistenceService.getInstance();
	}
	@Test
	public void testUpdateStationAndLocationInfo()
	{
		StationAndLocationInfo info = new StationAndLocationInfo();

		Station stn = new Station("675");
		stn.setPrimaryPrinterId("1235");
		stn.setAlternatePrinterId("4322");

		Location loc = new Location();
		loc.setIpAddress("199.99.99.98");

		info.setStation(stn);
		info.setLocation(loc);
		SaveLocationAndStationResponse response=adminToolPersistenceService.updateStationAndLocationInfo(info);
		

	}

	@After
	public void tearDown() throws Exception {
		applicationContext = null;
		adminToolPersistenceService = null;
	}

	@Test
	public void testGetEmployeeOfficeDetails() {
		InputData inputData = new InputData();
		inputData.setOfficeId("999");
		inputData.setTechId("XX");
		List <EmployeeWorkdateControl> employeeDetails = adminToolPersistenceService
				.getEmployeeOfficeDetails(inputData);
		assertNotNull(employeeDetails);
	}

	@Test
	public void testGetOffices() {
		List <Office> offices = adminToolPersistenceService.getAllOffices();
		assertNotNull(offices);
	}

	@Test
	public void testGetAllStations() {
		List <Station> stations = adminToolPersistenceService.getAllStations();
		assertNotNull(stations);
	}

	@Test
	public void testUpdateWorkDateStatus01() {
		EmployeeWorkdateControl employee = new EmployeeWorkdateControl();
		OfficeWorkdate officeWorkdate = new OfficeWorkdate();
		Office office = new Office();
		office.setId(new Long(999));
		officeWorkdate.setOffice(office);
		employee.setOfficeWorkdate(officeWorkdate);
		List <EmployeeWorkdateControl> input = new ArrayList <EmployeeWorkdateControl>();
		input.add(employee);
		SaveWorkDateStatusResponse response = adminToolPersistenceService
				.updateWorkDateStatus(input, false);
		assertNotNull(response);
	}

	@Test
	public void testUpdateWorkDateStatus02() {
		EmployeeWorkdateControl employee = new EmployeeWorkdateControl();
		OfficeWorkdate officeWorkdate = new OfficeWorkdate();
		Office office = new Office();
		office.setId(new Long(999));
		officeWorkdate.setOffice(office);
		employee.setOfficeWorkdate(officeWorkdate);
		List <EmployeeWorkdateControl> input = new ArrayList <EmployeeWorkdateControl>();
		input.add(employee);
		SaveWorkDateStatusResponse response = adminToolPersistenceService
				.updateWorkDateStatus(input, true);
		assertNotNull(response);
	}

	@Test
	public void testAddStationInfo() {
		Station inputData = new Station();
		inputData.setStationId("892");
		inputData.setPrimaryPrinterId("FGH");
		inputData.setAlternatePrinterId("NU-FGH");
		inputData.setInventoryAssigned(false);
		adminToolPersistenceService.addStationInfo(inputData);
		boolean stationExists = adminToolPersistenceService
				.doesStationExist("892");
		assertTrue(stationExists);
	}

	@Test
	public void testGetEmployeeOfficeDetailsByOfficeId() {
		InputData input = new InputData();
		input.setOfficeId("999");
		List <EmployeeWorkdateControl> employeeOfficeDetails = adminToolPersistenceService
				.getEmployeeOfficeDetailsByOfficeId(input);
		assertNotNull(employeeOfficeDetails);
	}

	@Test
	public void testGetStationInfoByOfficeId() {
		List <Station> stations = adminToolPersistenceService
				.getStationInfoByOfficeId("999");
		assertNotNull(stations);
	}
	
	@Test
	public void testGetHostOffices() {
		List <Office> hostOffices = adminToolPersistenceService.getHostOffices();
		assertNotNull(hostOffices);
		assertTrue(hostOffices.size() != 0);
		assertEquals(hostOffices.get(0).getSatelliteOffice(), "N");
	}
	
	@Test
	public void testAddOffice() {
		Office newOffice = new Office();
		newOffice.setName("TEST OFFICE 10");
		newOffice.setOfficeId("809"); 
		newOffice.setPhoneNumber("8101090144"); 
		newOffice.setDriveTestWindow(""); 
		newOffice.setSatelliteOffice("N");
		newOffice.setCreatedBy("admin");
		newOffice.setModifiedBy("admin");
		SaveOfficeResponse response = adminToolPersistenceService.addOffice(newOffice);
		assertNotNull(response);
		assertTrue(response.getErrorCollector().hasErrors());
	}
}
