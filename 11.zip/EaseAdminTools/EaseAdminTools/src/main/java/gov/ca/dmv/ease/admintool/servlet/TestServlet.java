package gov.ca.dmv.ease.admintool.servlet;

import gov.ca.dmv.ease.admintool.bo.Office;
import gov.ca.dmv.ease.admintool.dao.AdminToolDao;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TraceServlet.
 */
public class TestServlet extends HttpServlet {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6379888583583308191L;

	/**
	 * Instantiates a new test servlet.
	 *
	 * @see HttpServlet#HttpServlet()
	 */
	public TestServlet() {
		super();
	}

	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
	 */
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Process request.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultset = null;
		try {
			IAdminToolPersistenceService adminDAO = new AdminToolDao();
			List <Office> offices = null;//adminDAO.getAllOffices();
			PrintWriter out = response.getWriter();
			StringBuilder output = new StringBuilder();
			output.append("<HTML>\n");
			output.append("<HEAD>\n");
			output.append("<TITLE>Test</TITLE>\n");
			output.append("</HEAD>\n");
			output.append("<BODY>\n");
			for (Office office : offices) {
				output.append(office.getOfficeId() + "-"
						+ office.getOfficeName() + "</br>");
			}
			output.append("</BODY>\n");
			output.append("</HTML>");
			out.println(output);
			out.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (resultset != null) {
					resultset.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}*/
	}
}