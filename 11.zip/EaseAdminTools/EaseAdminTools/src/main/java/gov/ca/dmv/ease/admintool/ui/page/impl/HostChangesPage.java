/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.admintool.ui.page.impl;

import gov.ca.dmv.ease.admintool.dao.AdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;
import gov.ca.dmv.ease.admintool.response.impl.SaveOfficeResponse;
import gov.ca.dmv.ease.bo.admin.impl.Office;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

/**
 * Description: I am this and that File: HostChangesPage.java Module:
 * gov.ca.dmv.ease.admintool.ui.page.impl Created: Nov 8, 2012
 * 
 * @author mwpkc2
 * @version $Revision: 1.3 $ Last Changed: $Date: 2012/12/22 00:20:00 $ Last
 *          Changed By: $Author: mwnrk $
 */
public class HostChangesPage {
	/** The admin dao. */
	private IAdminToolPersistenceService adminDAO = new AdminToolPersistenceService();
	/** The selected office. */
	private Long selectedOfficeId;
	/** The selected office. */
	private Long selectedNewSatelliteOfficeId;
	/** The all offices. */
	private List<Office> allOffices;
	/** The all offices. */
	private List<Office> allOfficesExceptSelected;
	/** The select items. */
	private List<SelectItem> officeSelectItems = new ArrayList<SelectItem>();
	/** The satellite office select items. */
	private List<SelectItem> satelliteOfficeSelectItems = new ArrayList<SelectItem>();
	/** The update satellite office select items. */
	private List<SelectItem> updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
	/** The load. */
	private boolean load = true;
	/** The show new office fields. */
	private boolean showNewOfficeFields;
	/** The show new office fields. */
	private boolean showHostOfficesExceptSelected;
	/** The show satellite office. */
	private boolean showNewSatelliteOffice;
	/** The new office id. */
	private String newOfficeName;
	/** The new office id. */
	private String newOfficeId;
	/** The new office phone number. */
	private String newOfficePhoneNumber;
	/** The new office dl test window number. */
	private String newOfficeDlTestWindowNumber;
	/** The new satellite office indicator. */
	private String newSatelliteOfficeIndicator;
	/** The selected office obj. */
	private Office selectedOfficeObj;

	private String selectedIndicator;

	/** The selected option. */
	private String selectedOption;

	public String getSelectedOption() {
		return selectedOption;
	}

	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}

	/**
	 * Gets the office select items.
	 * 
	 * @return the office select items
	 */
	public List<SelectItem> getOfficeSelectItems() {
		return officeSelectItems;
	}

	public void setOfficeSelectItems(List<SelectItem> officeSelectItems) {
		this.officeSelectItems = officeSelectItems;
	}

	public List<SelectItem> getSatelliteOfficeSelectItems() {
		return satelliteOfficeSelectItems;
	}

	public void setSatelliteOfficeSelectItems(
			List<SelectItem> satelliteOfficeSelectItems) {
		this.satelliteOfficeSelectItems = satelliteOfficeSelectItems;
	}

	public List<SelectItem> getUpdateSatelliteOfficeSelectItems() {
		return updateSatelliteOfficeSelectItems;
	}

	public void setUpdateSatelliteOfficeSelectItems(
			List<SelectItem> updateSatelliteOfficeSelectItems) {
		this.updateSatelliteOfficeSelectItems = updateSatelliteOfficeSelectItems;
	}

	/**
	 * Checks if is show host offices except selected.
	 * 
	 * @return true, if is show host offices except selected
	 */
	public boolean isShowHostOfficesExceptSelected() {
		return showHostOfficesExceptSelected;
	}

	/**
	 * Sets the show host offices except selected.
	 * 
	 * @param showHostOfficesExceptSelected
	 *            the new show host offices except selected
	 */
	public void setShowHostOfficesExceptSelected(
			boolean showHostOfficesExceptSelected) {
		this.showHostOfficesExceptSelected = showHostOfficesExceptSelected;
	}

	/**
	 * Checks if is show new satellite office.
	 * 
	 * @return true, if is show new satellite office
	 */
	public boolean isShowNewSatelliteOffice() {
		return showNewSatelliteOffice;
	}

	public void setShowNewSatelliteOffice(boolean showNewSatelliteOffice) {
		this.showNewSatelliteOffice = showNewSatelliteOffice;
	}

	/**
	 * Gets the new office name.
	 * 
	 * @return the new office name
	 */
	public String getNewOfficeName() {
		return newOfficeName;
	}

	/**
	 * Sets the new office name.
	 * 
	 * @param newOfficeName
	 *            the new new office name
	 */
	public void setNewOfficeName(String newOfficeName) {
		this.newOfficeName = newOfficeName;
	}

	/** The new satellite office id. */
	private Long newSatelliteOfficeId;

	/**
	 * Gets the new satellite office id.
	 * 
	 * @return the new satellite office id
	 */
	public Long getNewSatelliteOfficeId() {
		return newSatelliteOfficeId;
	}

	/**
	 * Sets the new satellite office id.
	 * 
	 * @param newSatelliteOfficeId
	 *            the new new satellite office id
	 */
	public void setNewSatelliteOfficeId(Long newSatelliteOfficeId) {
		this.newSatelliteOfficeId = newSatelliteOfficeId;
	}

	/**
	 * Gets the new office id.
	 * 
	 * @return the new office id
	 */
	public String getNewOfficeId() {
		return newOfficeId;
	}

	/**
	 * Sets the new office id.
	 * 
	 * @param newOfficeId
	 *            the new new office id
	 */
	public void setNewOfficeId(String newOfficeId) {
		this.newOfficeId = newOfficeId;
	}

	/**
	 * Gets the new office phone number.
	 * 
	 * @return the new office phone number
	 */
	public String getNewOfficePhoneNumber() {
		return newOfficePhoneNumber;
	}

	/**
	 * Sets the new office phone number.
	 * 
	 * @param newOfficePhoneNumber
	 *            the new new office phone number
	 */
	public void setNewOfficePhoneNumber(String newOfficePhoneNumber) {
		this.newOfficePhoneNumber = newOfficePhoneNumber;
	}

	/**
	 * Gets the new office dl test window number.
	 * 
	 * @return the new office dl test window number
	 */
	public String getNewOfficeDlTestWindowNumber() {
		return newOfficeDlTestWindowNumber;
	}

	/**
	 * Sets the new office dl test window number.
	 * 
	 * @param newOfficeDlTestWindowNumber
	 *            the new new office dl test window number
	 */
	public void setNewOfficeDlTestWindowNumber(
			String newOfficeDlTestWindowNumber) {
		this.newOfficeDlTestWindowNumber = newOfficeDlTestWindowNumber;
	}

	/**
	 * Gets the new satellite office indicator.
	 * 
	 * @return the new satellite office indicator
	 */
	public String getNewSatelliteOfficeIndicator() {
		return newSatelliteOfficeIndicator;
	}

	/**
	 * Sets the new satellite office indicator.
	 * 
	 * @param newSatelliteOfficeIndicator
	 *            the new new satellite office indicator
	 */
	public void setNewSatelliteOfficeIndicator(
			String newSatelliteOfficeIndicator) {
		this.newSatelliteOfficeIndicator = newSatelliteOfficeIndicator;
	}

	/**
	 * Checks if is show new office fields.
	 * 
	 * @return true, if is show new office fields
	 */
	public boolean isShowNewOfficeFields() {
		return showNewOfficeFields;
	}

	/**
	 * Sets the show new office fields.
	 * 
	 * @param showNewOfficeFields
	 *            the new show new office fields
	 */
	public void setShowNewOfficeFields(boolean showNewOfficeFields) {
		this.showNewOfficeFields = showNewOfficeFields;
	}

	/**
	 * Gets the faces context.
	 * 
	 * @return the faces context
	 */
	private FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	/**
	 * Sets the all offices except selected.
	 * 
	 * @param allOfficesExceptSelected
	 *            the new all offices except selected
	 */
	public void setAllOfficesExceptSelected(
			List<Office> allOfficesExceptSelected) {
		this.allOfficesExceptSelected = allOfficesExceptSelected;
	}

	/**
	 * Gets the all offices.
	 * 
	 * @return the all offices
	 */
	public List<Office> getOfficesExcept() {
		if (selectedOfficeId != null)
			allOfficesExceptSelected = adminDAO
					.getHostOfficesExcept(selectedOfficeId);
		return allOfficesExceptSelected;
	}

	/**
	 * Gets the office by id.
	 * 
	 * @param id
	 *            the id
	 * @return the office by id
	 */
	private Office getOfficeById(Long id) {
		if (id == null)
			return null;
		Office retValue = null;
		if (allOffices != null) {
			for (Office office : allOffices) {
				if (id.equals(office.getId())) {
					retValue = office;
					break;
				}
			}
		}
		return retValue;
	}

	/**
	 * Gets the selected office id.
	 * 
	 * @return the selected office id
	 */
	public Long getSelectedOfficeId() {
		return selectedOfficeId;
	}

	/**
	 * Sets the selected office id.
	 * 
	 * @param selectedOfficeId
	 *            the new selected office id
	 */
	public void setSelectedOfficeId(Long selectedOfficeId) {
		this.selectedOfficeId = selectedOfficeId;
	}

	/**
	 * Gets the selected new satellite office id.
	 * 
	 * @return the selected new satellite office id
	 */
	public Long getSelectedNewSatelliteOfficeId() {
		return selectedNewSatelliteOfficeId;
	}

	public void setSelectedNewSatelliteOfficeId(
			Long selectedNewSatelliteOfficeId) {
		this.selectedNewSatelliteOfficeId = selectedNewSatelliteOfficeId;
	}

	/**
	 * Sets the all offices.
	 * 
	 * @param allOffices
	 *            the new all offices
	 */
	public void setAllOffices(List<Office> allOffices) {
		this.allOffices = allOffices;
	}

	// ------------------------------------------------------------
	/**
	 * Gets the select offices.
	 * 
	 * @return the select offices
	 */
	public List<SelectItem> getSelectOffices() {
		if (load) {
			if (getSelectedOption().equalsIgnoreCase("Y"))
				allOffices = adminDAO.getSatelliteOffices();
			else
				allOffices = getAllOffices();

			if (allOffices.size() == 0)
				officeSelectItems.add(new SelectItem(0, "-SELECT-"));
			else {
				for (Office data : allOffices) {
					officeSelectItems.add(new SelectItem(data.getId(), data
							.getOfficeId()
							+ " - "
							+ data.getName()
							+ " - "
							+ data.getSatelliteOffice()));
				}
			}
		if (getSelectedOption().equalsIgnoreCase("N"))
			officeSelectItems.add(new SelectItem(-1, "OTHER"));
		}
		load = false;
		return officeSelectItems;
	}

	public List<SelectItem> getSatelliteOffices() {
		if (load) {
			List<Office> allOffices = adminDAO.getSatelliteOffices();
			if (allOffices.size() == 0)
				officeSelectItems.add(new SelectItem(0, "-SELECT-"));
			else {
				for (Office data : allOffices) {
					officeSelectItems.add(new SelectItem(data.getId(), data
							.getOfficeId()
							+ " - "
							+ data.getName()
							+ " - "
							+ data.getSatelliteOffice()));
				}
			}
			officeSelectItems.add(new SelectItem(-1, "OTHER"));
		}
		load = false;
		return officeSelectItems;
	}

	// ------------------------------------------------------------
	/**
	 * Gets the select offices.
	 * 
	 * @return the select offices
	 */
	public List<SelectItem> getSelectSatelliteOffices() {
		satelliteOfficeSelectItems.clear();
		for (Office data : getAllHostOffices()) {
			satelliteOfficeSelectItems.add(new SelectItem(data.getId(), data
					.getOfficeId()
					+ " - "
					+ data.getName()
					+ " - "
					+ data.getSatelliteOffice()));
		}
		return satelliteOfficeSelectItems;
	}

	/**
	 * Gets the select host offices.
	 * 
	 * @return the select host offices
	 */
	public List<SelectItem> getUpdateSatelliteOffice() {
		updateSatelliteOfficeSelectItems.clear();
		for (Office data : getOfficesExcept()) {
			updateSatelliteOfficeSelectItems.add(new SelectItem(data.getId(),
					data.getOfficeId() + " - " + data.getName() + " - "
							+ data.getSatelliteOffice()));
		}
		return updateSatelliteOfficeSelectItems;
	}

	// ------------------------------------------------------------
	/**
	 * Gets the all offices.
	 * 
	 * @return the all offices
	 */
	public List<Office> getAllOffices() {
		allOffices = adminDAO.getAllOffices();
		return allOffices;
	}

	/**
	 * Gets the all offices.
	 * 
	 * @return the all offices
	 */
	public List<Office> getAllHostOffices() {
		allOffices = adminDAO.getHostOffices();
		return allOffices;
	}

	/**
	 * Gets the all offices except selected.
	 * 
	 * @return the all offices except selected
	 */
	public List<Office> getAllOfficesExceptSelected() {
		if (selectedOfficeId != null) {
			allOfficesExceptSelected = adminDAO
					.getHostOfficesExcept(selectedOfficeId);
		}
		return allOfficesExceptSelected;
	}

	// ------------------------------------------------------------
	/**
	 * Gets the select station id ids.
	 * 
	 * @param event
	 *            the event
	 * @return the select station id ids
	 */
	public void onOfficeIdChange(ValueChangeEvent event) {
		Long selectedOffice = (Long) event.getNewValue();
		if (selectedOffice != null) {
			if (selectedOffice.equals(-1L)) {
				setShowHostOfficesExceptSelected(false);
				setShowNewOfficeFields(true);
				setShowNewSatelliteOffice(false);
			} else {
				setShowNewOfficeFields(false);
				setShowHostOfficesExceptSelected(true);
			}
		}
		// selectedOfficeObj = getOfficeById(selectedNewSatelliteOfficeId);
		// officeIdChanged(selectedOfficeObj);
	}

	/**
	 * On satellite office indicator.
	 * 
	 * @param event
	 *            the event
	 */
	public void onSatelliteOfficeIndicator(ValueChangeEvent event) {
		String selectedSatelliteOfficeIndicator = (String) event.getNewValue();
		if (selectedSatelliteOfficeIndicator != null) {
			if ("Y".equals(selectedSatelliteOfficeIndicator))
				setShowNewSatelliteOffice(true);
			else
				setShowNewSatelliteOffice(false);
		}
	}



	/**
	 * Continue to home action.
	 * 
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public String continueToHomeAction() throws IOException {
		selectedOption = null;
		selectedOfficeId = null;
		selectedNewSatelliteOfficeId = null;
		allOffices = new ArrayList<Office>();
		allOfficesExceptSelected = new ArrayList<Office>();
		officeSelectItems = new ArrayList<SelectItem>();
		satelliteOfficeSelectItems = new ArrayList<SelectItem>();
		updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
		load = false;
		showNewOfficeFields = false;
		showHostOfficesExceptSelected = false;
		showNewSatelliteOffice = false;
		newOfficeName = null;
		newOfficeId = null;
		newOfficePhoneNumber = null;
		newOfficeDlTestWindowNumber = null;
		newSatelliteOfficeIndicator = null;
		selectedOfficeObj = null;
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"/EaseAdminTools");
		return "";
	}

	public void resetFromIndicatorUpdate() {
		allOffices = new ArrayList<Office>();
		allOfficesExceptSelected = new ArrayList<Office>();
		officeSelectItems = new ArrayList<SelectItem>();
		satelliteOfficeSelectItems = new ArrayList<SelectItem>();
		updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
		getFacesContext().addMessage(
				null,
				new FacesMessage("RECORDS WERE UPDATED SUCCESSFULLY"
						+ "-brErrorMsg"));
		load = true;
		getSelectOffices();
	}

	/**
	 * Continue to update work date status action.
	 * 
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public String continueToUpdate() throws IOException {
		if (getSelectedOption().equalsIgnoreCase("Y")) {
			selectedOfficeObj = getOfficeById(selectedOfficeId);
			SaveOfficeResponse response = adminDAO.updateOfficeIndicatorToN(
					selectedOfficeObj, "N");
			if (!response.getErrorCollector().hasErrors()) {
				resetFromIndicatorUpdate();
				return null;

			}

			return "";
		} else if (getSelectedOption().equalsIgnoreCase("N")) {
			if (selectedOfficeId != null) {
				if (selectedOfficeId.equals(-1L)) {
					Office office = new Office();
					// SYS_ID
					office.setName(newOfficeName); // OFFICE_NME
					office.setOfficeId(newOfficeId); // OFFICE_ID
					office.setPhoneNumber(newOfficePhoneNumber); // OFFICE_PHONE_NBR
					office.setDriveTestWindow(newOfficeDlTestWindowNumber); // OFFICE_DL_TEST_WINDOW_NBR
					office.setSatelliteOffice(newSatelliteOfficeIndicator); // SATELLITE_OFFICE_IND
					if (newSatelliteOfficeId == null)
						newSatelliteOfficeId = 0L;
					office.setMainOfficeId(newSatelliteOfficeId); // OFFICE_SYSID
					// CREATOR_ID
					// CREATE_TSTAMP
					// MODIFIED_BY
					// MODIFIED_TSTAMP
					SaveOfficeResponse response = adminDAO.addOffice(office);
					if (!response.getErrorCollector().hasErrors()) {
						reset();
						return null;
						/*
						 * getFacesContext().addMessage( null, new FacesMessage(
						 * "RECORDS WERE UPDATED SUCCESSFULLY" +
						 * "-brErrorMsg"));
						 */
					}
				} else {
					selectedOfficeObj = getOfficeById(selectedNewSatelliteOfficeId);
					SaveOfficeResponse response = adminDAO
							.updateSatelliteOfficeIndicator(selectedOfficeObj,
									selectedOfficeId);
					if (!response.getErrorCollector().hasErrors()) {
						reset();
						return null;
						/*
						 * getFacesContext().addMessage( null, new FacesMessage(
						 * "RECORDS WERE UPDATED SUCCESSFULLY" +
						 * "-brErrorMsg"));
						 */
					}
				}
			}
		}
		return "";
	}

	/**
	 * Continue to reset action.
	 * 
	 * @return the string
	 * @throws IOException
	 */
	public String continueToResetAction() throws IOException {
		resetButton();
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"hostChanges.jsf");
		return "";
	}

	// General purpose local methods
	// ----------------------------------------------
	/**
	 * Reset.
	 */
	private void reset() {
		selectedOfficeId = null;
		selectedNewSatelliteOfficeId = null;
		allOffices = new ArrayList<Office>();
		allOfficesExceptSelected = new ArrayList<Office>();
		officeSelectItems = new ArrayList<SelectItem>();
		satelliteOfficeSelectItems = new ArrayList<SelectItem>();
		updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
		load = false;
		showNewOfficeFields = false;
		showHostOfficesExceptSelected = false;
		showNewSatelliteOffice = false;
		newOfficeName = null;
		newOfficeId = null;
		newOfficePhoneNumber = null;
		newOfficeDlTestWindowNumber = null;
		newSatelliteOfficeIndicator = null;
		selectedOfficeObj = null;
		getFacesContext().addMessage(
				null,
				new FacesMessage("RECORDS WERE UPDATED SUCCESSFULLY"
						+ "-brErrorMsg"));
		load = true;
		getSelectOffices();
		getUpdateSatelliteOffice();
	}

	private void resetButton(){
		selectedOfficeId = null;
		selectedNewSatelliteOfficeId = null;
		allOffices = new ArrayList<Office>();
		allOfficesExceptSelected = new ArrayList<Office>();
		officeSelectItems = new ArrayList<SelectItem>();
		satelliteOfficeSelectItems = new ArrayList<SelectItem>();
		updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
		showNewOfficeFields = false;
		showHostOfficesExceptSelected = false;
		showNewSatelliteOffice = false;
		newOfficeName = null;
		newOfficeId = null;
		newOfficePhoneNumber = null;
		newOfficeDlTestWindowNumber = null;
		newSatelliteOfficeIndicator = null;
		selectedOfficeObj = null;
		selectedOption = null;
	}
	/**
	 * Change.
	 * 
	 * @param event
	 *            the event
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public void change(ValueChangeEvent event) throws IOException {
		load = true;
		selectedOption = null;
		resetBack();
		selectedIndicator = (String) event.getNewValue();
		setSelectedOption(selectedIndicator.trim());
		if (getSelectedOption().equalsIgnoreCase("Y"))
			this.showNewSatelliteOffice=false;
		getSelectOffices();
		FacesContext.getCurrentInstance().getExternalContext().redirect(
				"hostChanges.jsf");
		
	}
	public void resetBack(){
		selectedOfficeId = null;
		selectedNewSatelliteOfficeId = null;
		allOffices = new ArrayList<Office>();
		allOfficesExceptSelected = new ArrayList<Office>();
		officeSelectItems = new ArrayList<SelectItem>();
		satelliteOfficeSelectItems = new ArrayList<SelectItem>();
		updateSatelliteOfficeSelectItems = new ArrayList<SelectItem>();
		showNewOfficeFields = false;
		showHostOfficesExceptSelected = false;
		showNewSatelliteOffice = false;
		newOfficeName = null;
		newOfficeId = null;
		newOfficePhoneNumber = null;
		newOfficeDlTestWindowNumber = null;
		newSatelliteOfficeIndicator = null;
		selectedOfficeObj = null;
	}

}