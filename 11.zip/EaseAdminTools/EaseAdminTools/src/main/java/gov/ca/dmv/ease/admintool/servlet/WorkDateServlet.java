package gov.ca.dmv.ease.admintool.servlet;

import gov.ca.dmv.ease.admintool.bo.EmployeeOfficeDetails;
import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.dao.AdminToolDao;
import gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Description: Servlet implementation class WorkDateServlet.
 * File: Office.java
 * Module:  gov.ca.dmv.ease.admintool.bo
 * Created: Aug 14, 2012 
 * @author mwpkc2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/10/24 00:33:45 $
 * Last Changed By: $Author: mwpkc2 $
 */
public class WorkDateServlet extends HttpServlet {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new work date servlet.
	 *
	 * @see HttpServlet#HttpServlet()
	 */
	public WorkDateServlet() {
		super();
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Process request.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*String hidAction = request.getParameter("hidAction");
		HttpSession session = request.getSession();
		IAdminToolPersistenceService adminDAO = new AdminToolDao();
		//String officeId = request.getParameter("");
		//String techId = request.getParameter("");
		session.setAttribute("officeId", "791");
		session.setAttribute("techId", "M2");
		if ("RESTART".equalsIgnoreCase(hidAction)) {
			response.sendRedirect("camvTraceInput.jsp");
		}
		else if ("CANCEL".equalsIgnoreCase(hidAction)) {
			session.removeAttribute("officeId");
			session.removeAttribute("techId");
		}
		else if ("OK".equalsIgnoreCase(hidAction)) {
			InputData inputData = new InputData();
			inputData.setOfficeId("791");
			inputData.setTechId("M2");
			List <EmployeeOfficeDetails> employeeOfficeDetailsList = (ArrayList <EmployeeOfficeDetails>) adminDAO
					.getEmployeeOfficeDetails(inputData);
			session.setAttribute("employeeOfficeDetails",
					employeeOfficeDetailsList);
			for (EmployeeOfficeDetails employeeOfficeDetails : employeeOfficeDetailsList) {
				System.out.println(employeeOfficeDetails);
			}
		}*/
	}
}
