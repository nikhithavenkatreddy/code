/**
 * 
 */
package gov.ca.dmv.ease.admintool.dao;

import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.like;
import edu.emory.mathcs.backport.java.util.Collections;
import gov.ca.dmv.ease.admintool.bo.InputData;
import gov.ca.dmv.ease.admintool.response.impl.SaveLocationAndStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveOfficeResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveStationResponse;
import gov.ca.dmv.ease.admintool.response.impl.SaveWorkDateStatusResponse;
import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.admin.impl.EmployeeWorkdateControl;
import gov.ca.dmv.ease.bo.admin.impl.Office;
import gov.ca.dmv.ease.bo.admin.impl.OfficeWorkdate;
import gov.ca.dmv.ease.bo.app.impl.Location;
import gov.ca.dmv.ease.bo.app.impl.Station;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.ApplicationException;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.IRetrieveCriteriaObjectRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.IPersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveAllBusinessObjectsResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveCriteriaObjectResponse;
import gov.ca.dmv.ease.tus.persist.service.impl.PersistenceService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

/**
 * Description: Data access service class which leverages the EASE
 * PersistenceService File: AdminToolDaoHibernate.java Module:
 * gov.ca.dmv.ease.admintool.dao Created: Oct 15, 2012
 * 
 * @author MWSEC2
 * @version $Revision: 1.13 $ Last Changed: $Date: 2012/12/21 17:59:56 $ Last
 *          Changed By: $Author: mwnrk $
 */
public class AdminToolPersistenceService implements
		IAdminToolPersistenceService {
	/** The SINGLETON. */
	private static AdminToolPersistenceService SINGLETON;

	/**
	 * Gets the single instance of AdminToolPersistenceService.
	 * 
	 * @return single instance of AdminToolPersistenceService
	 */
	public static AdminToolPersistenceService getInstance() {
		if (SINGLETON == null) {
			SINGLETON = new AdminToolPersistenceService();
		}
		return SINGLETON;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolDao#getEmployeeOfficeDetails(
	 * gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	@SuppressWarnings("unchecked")


	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#isIpAddressExisted(java.lang.String)
	 */
	@Override
	public boolean isIpAddressExisted(String ipAddress) {
		IErrorCollector errorCollector = new ErrorCollector();
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		String ipQuery = "SELECT LOC.STATION_IP_ADDR FROM VSSM059U_LOCATION_INFO LOC WHERE LOC.STATION_IP_ADDR = :ipAddress";
		session.beginTransaction();
		Query sqlQuery = session.createSQLQuery(ipQuery);
		sqlQuery.setParameter("ipAddress", ipAddress);
		List<Integer> ipResults = sqlQuery.list();
		if (ipResults.size() > 0) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#isNewStationIdExisted(java.lang.String)
	 */
	@Override
	public boolean isNewStationIdExisted(String newStationId) {
		IErrorCollector errorCollector = new ErrorCollector();
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		String stationQuery = "SELECT STN.STATION_ID FROM VSSM060U_STATION_INFO STN WHERE STN.STATION_ID = :newStationId";
		session.beginTransaction();
		Query sqlQuery = session.createSQLQuery(stationQuery);
		sqlQuery.setParameter("newStationId", newStationId);
		List<Integer> ipResults = sqlQuery.list();
		if (ipResults.size() > 0) {
			return true;
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#
	 * addLocationAndStationDetails(gov.ca.dmv.ease.bo.app.impl.Location)
	 */
	@Override
	public SaveLocationAndStationResponse addLocationAndStationDetails(
			Location input) {
		IErrorCollector errorCollector = new ErrorCollector();
		SaveLocationAndStationResponse response = null;
		try {
			String l1Code = getL1ServerInfo(input.getOfficeId());
			if(l1Code == null) {
				EaseException exc = new EaseException("PLEASE CONTACT ISD");
				errorCollector.register(exc);
				response = new SaveLocationAndStationResponse(errorCollector);
				return response;
			}
			input.setL1ServerCode(l1Code);
			input.setL1ServerSuffix("P01");
			IPersistenceServiceRequest request = PersistenceServiceRequestFactory
					.getInstance().createSaveOrUpdateBusinessObjectRequest(
							UserContext.getDefaultInstanceForDb(), input);
			IPersistenceServiceResponse persistenceResponse = request.execute();
			if (persistenceResponse.hasErrors()) {
				response = new SaveLocationAndStationResponse(
						persistenceResponse.getErrorCollector());
			} else {
				response = new SaveLocationAndStationResponse();
			}

		} catch (Exception e) {
			errorCollector.register(e);
			response = new SaveLocationAndStationResponse(errorCollector);
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addStationInfo
	 * (gov.ca.dmv.ease.admintool.bo.StationInfo)
	 */
	@Override
	public SaveStationResponse addStationInfo(Station newStation) {
		SaveStationResponse response = new SaveStationResponse();
		IErrorCollector errorCollector = new ErrorCollector();
		try {
			IPersistenceServiceRequest request = PersistenceServiceRequestFactory
					.getInstance().createSaveOrUpdateBusinessObjectRequest(
							UserContext.getDefaultInstanceForDb(), newStation);
			PersistenceServiceResponse persistanceRequest = (PersistenceServiceResponse) request
					.execute();
			if (persistanceRequest.hasErrors()) {
				throw new ApplicationException(persistanceRequest
						.getErrorCollector().getEntries().get(0)
						.getExceptionMessage());
			} else {
				response = new SaveStationResponse();
			}
		} catch (Exception e) {
			errorCollector.register(e);
			response = new SaveStationResponse(errorCollector);
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#addOffice(
	 * gov.ca.dmv.ease.bo.admin.impl.Office)
	 */
	@Override
	public SaveOfficeResponse addOffice(Office newOffice) {
		SaveOfficeResponse response = new SaveOfficeResponse();
		IErrorCollector errorCollector = new ErrorCollector();
		try {
			IPersistenceServiceRequest request = PersistenceServiceRequestFactory
					.getInstance().createSaveOrUpdateBusinessObjectRequest(
							UserContext.getDefaultInstanceForDb(), newOffice);
			PersistenceServiceResponse persistanceRequest = (PersistenceServiceResponse) request
					.execute();
			if (persistanceRequest.hasErrors()) {
				throw new ApplicationException(persistanceRequest
						.getErrorCollector().getEntries().get(0)
						.getExceptionMessage());
			} else {
				response = new SaveOfficeResponse();
			}
		} catch (Exception e) {
			errorCollector.register(e);
			response = new SaveOfficeResponse(errorCollector);
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#doesStationExist
	 * (java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public boolean doesStationExist(String stationSysId) {
		List listOfBusinessObjects = null;
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Station.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();
		if (aResponse.hasErrors()) {
			request.rollbackTransaction();
			throw new EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("stationId", stationSysId));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}
		return listOfBusinessObjects != null
				&& listOfBusinessObjects.size() > 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllOffices
	 * ()
	 */
	@Override
	public List<Office> getAllOffices() {
		IPersistenceServiceRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveAllBusinessObjectsRequest(
						UserContext.getDefaultInstanceForDb(), Office.class);
		RetrieveAllBusinessObjectsResponse aResponse = (RetrieveAllBusinessObjectsResponse) request
				.execute();
		List<IBusinessObject> listOfBusinessObjects = aResponse.getResults();
		List<Office> offices = new ArrayList<Office>();
		for (IBusinessObject obj : listOfBusinessObjects) {
			Office office = (Office) obj;
			offices.add(office);
		}
		Collections.sort(offices, new Comparator<Office>() {
			public int compare(Office ofc1, Office ofc2) {
				return ofc1.getOfficeId().compareTo(ofc2.getOfficeId());
			}
		});
		return offices;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getAllStations
	 * ()
	 */
	@Override
	public List<Station> getAllStations() {
		IPersistenceServiceRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveAllBusinessObjectsRequest(
						UserContext.getDefaultInstanceForDb(), Station.class);
		RetrieveAllBusinessObjectsResponse aResponse = (RetrieveAllBusinessObjectsResponse) request
				.execute();
		List<IBusinessObject> listOfBusinessObjects = aResponse.getResults();
		List<Station> stations = new ArrayList<Station>();
		for (IBusinessObject obj : listOfBusinessObjects) {
			Station station = (Station) obj;
			stations.add(station);
		}
		return stations;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#
	 * getEmployeeOfficeDetailsByOfficeId
	 * (gov.ca.dmv.ease.admintool.bo.InputData)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<EmployeeWorkdateControl> getEmployeeOfficeDetailsByOfficeId(
			InputData input) throws EaseException {
		// No Tech ID
		/**
		 * SELECT * FROM MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL ewdc
			LEFT JOIN MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL owdc ON owdc.SYS_ID = ewdc.OFFICE_WRK_DT_CNTRL_SYSID
			LEFT JOIN MWKDB2MV.VSSM028U_OFFICE o ON owdc.OFFICE_SYSID = o.SYS_ID
			--LEFT JOIN MWKDB2MV.VSSM026U_EMPLOYEE_A e ON e.SYS_ID = ewdc.EMPLOYEE_SYSID
			WHERE o.OFFICE_ID = '111'
			--AND e.TECH_ID = 'YY'
			AND ewdc.AUTHD_WRK_DT_STATUS = 'A' 
			AND owdc.AUTHD_WRK_DT_STATUS in('S', 'A')
			
			AND owdc.AUTHD_WRK_DT = '2015-11-17 00.00.00.0'
			--ORDER BY ewdc.MODIFIED_TSTAMP DESC
			FETCH FIRST 1 ROWS ONLY;
		 */
		Class<?> aClass = OfficeWorkdate.class;
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		List<EmployeeWorkdateControl> retValue = new ArrayList<EmployeeWorkdateControl>();
		Criteria criteria = session.createCriteria(aClass, "owc");
		// Commented below to display all the records.x`
		criteria.createCriteria("owc.office", "off");
		criteria.add(Restrictions.eq("off.officeId", input.getOfficeId()));
		Calendar cal = Calendar.getInstance();
		Date currentDate = cal.getTime();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm.ss.SSS");

		System.out.println("Printing the current date2 " + cal.getTime());
		
		Object[] values = new Object[] {"S","A"}; //"A"
		criteria.add(Restrictions.in("owc.status", values));
		
		List retrievedList = criteria.list();
		sdf = new SimpleDateFormat("MM/dd/yyyy");
		for (Object obj : retrievedList) {			
			OfficeWorkdate officeWorkdate = (OfficeWorkdate) obj;
			String authWkDate = null;
			String currentDate1 = null;
			
			if(officeWorkdate.getAuthorizedWorkDate() != null) {
				authWkDate = sdf.format(officeWorkdate.getAuthorizedWorkDate());
				currentDate1 = sdf.format(currentDate);
			}

			if(authWkDate != null && currentDate1 != null && authWkDate.equalsIgnoreCase(currentDate1)) {
				EmployeeWorkdateControl ewdc = new EmployeeWorkdateControl();
				ewdc.setOfficeWorkdate(officeWorkdate);				
				retValue.add(ewdc);
				//return retValue;
			}			
		}
		session.getTransaction().commit();
		return retValue;
	}


	
	public List<EmployeeWorkdateControl> getEmployeeOfficeDetails(
			InputData inputData) {
		Class<?> aClass;
		aClass = EmployeeWorkdateControl.class;
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		Object[] ewcValues = new Object[] {"A", "S"};
		Criteria criteria = session.createCriteria(aClass, "ewc");
		criteria.createCriteria("ewc.employee", "emp");
		//criteria.add(Restrictions.eq("ewc.status", "S"));
		criteria.add(Restrictions.in("ewc.status",ewcValues));
		String techId = inputData.getTechId();

		if (techId != null && !"".equalsIgnoreCase(techId)
				&& !"*".equalsIgnoreCase(techId)) {
			criteria.add(eq("emp.employeeTechId", techId));
		}
		criteria.createCriteria("ewc.officeWorkdate", "offWd");
		criteria.createCriteria("offWd.office", "off");
		criteria.add(Restrictions.eq("off.officeId", inputData.getOfficeId()));
		Object[] values = new Object[] {"A", "S"};
		criteria.add(Restrictions.in("offWd.status", values));
		
		List<EmployeeWorkdateControl> retValue = new ArrayList<EmployeeWorkdateControl>();
		List<Object> retrievedList = criteria.list();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

		for (Object obj : retrievedList) {
			EmployeeWorkdateControl empWkDtCntrol = (EmployeeWorkdateControl) obj;
			OfficeWorkdate officeWorkdate = empWkDtCntrol.getOfficeWorkdate();
			String currentDate1 = null;
			String authWkDate = null;
			if(officeWorkdate != null && officeWorkdate.getAuthorizedWorkDate() != null) {
				authWkDate = sdf.format(officeWorkdate.getAuthorizedWorkDate());
				currentDate1 = sdf.format(Calendar.getInstance().getTime());
			}
			if(authWkDate != null && currentDate1 != null && authWkDate.equalsIgnoreCase(currentDate1)) {
				retValue.add(empWkDtCntrol);
			}
		}
		session.getTransaction().commit();
		return retValue;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#
	 * getStationInfoByOfficeId(java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Station> getStationInfoByOfficeId(String officeId) {
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		String superQuery = "SELECT STN.SYS_ID, STN.STATION_ID, STN.PRIMARY_PRINTER_ID, STN.ALTERNATE_PRINTER_ID, STN.INVENTORY_ASSIGNED_FLG, STN.CREATOR_ID, STN.CREATE_TSTAMP, STN.MODIFIED_BY, STN.MODIFIED_TSTAMP "
				+ " FROM VSSM060U_STATION_INFO STN";
		String subQuery = "SELECT DISTINCT LOC.STATION_SYSID FROM VSSM059U_LOCATION_INFO LOC WHERE LOC.OFFICE_ID = :office_id";
		session.beginTransaction();
		Query sqlQuery = session.createSQLQuery(subQuery);
		sqlQuery.setParameter("office_id", officeId);
		List<Integer> subResults = sqlQuery.list();
		List<Long> longList = new ArrayList<Long>();
		for (Integer integer : subResults) {
			longList.add(new Long(integer));
		}
		List<Station> superResults = new ArrayList<Station>();
		if (longList.size() != 0) {
			Criteria criteria = session.createCriteria(Station.class, "stn");
			criteria.add(Restrictions.in("stn.id", longList));
			sqlQuery = session.createSQLQuery(superQuery);
			superResults = criteria.list();
		}
		Collections.sort(superResults, new Comparator<Station>() {
			public int compare(Station ofc1, Station ofc2) {
				return ofc1.getStationId().compareTo(ofc2.getStationId());
			}
		});
		return superResults;
	}

	/**
	 * * Testing *.
	 *
	 * @param stationSysId the station sys id
	 * @return the station by id test
	 */
	@Override
	public Station getStationByIdTest(String stationSysId) {
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Station.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();

		List<IBusinessObject> listOfBusinessObjects = null;// aResponse.getResults();

		if (aResponse.hasErrors()) {
			// request.rollbackTransaction();
			// throw new
			// EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("id", new Long(stationSysId)));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}

		Station retStation = null;
		if (listOfBusinessObjects != null && listOfBusinessObjects.size() == 1)
			retStation = (Station) listOfBusinessObjects.get(0);
		return retStation;

	}


	/**
	 * Gets the station by id.
	 *
	 * @param stationSysId the station sys id
	 * @return the station by id
	 */
	public Station getStationById(String stationSysId) {
		
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Station.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();

		List<IBusinessObject> listOfBusinessObjects = null;// aResponse.getResults();

		if (aResponse.hasErrors()) {
			// request.rollbackTransaction();
			// throw new
			// EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("id", new Long(stationSysId)));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}

		Station retStation = null;
		if (listOfBusinessObjects != null && listOfBusinessObjects.size() == 1)
			retStation = (Station) listOfBusinessObjects.get(0);
		return retStation;
	}

	/**
	 * Gets the location by station sys id.
	 *
	 * @param stationSysId the station sys id
	 * @return the location by station sys id
	 */
	public Location getLocationByStationSysId(String stationSysId) {
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Location.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();

		List<IBusinessObject> listOfBusinessObjects = null;// aResponse.getResults();

		if (aResponse.hasErrors()) {
			// request.rollbackTransaction();
			// throw new
			// EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("station.id", new Long(stationSysId)));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}

		Location retLocation = null;
		if (listOfBusinessObjects != null && listOfBusinessObjects.size() == 1)
			retLocation = (Location) listOfBusinessObjects.get(0);
		return retLocation;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getStationAndLocationInfo(java.lang.String)
	 */
	@Override
	public StationAndLocationInfo getStationAndLocationInfo(String id) {
		StationAndLocationInfo info = new StationAndLocationInfo();
		info.setStation(getStationById(id));
		info.setLocation(getLocationByStationSysId(id));
		return info;
	}

	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateStationAndLocationInfo(gov.ca.dmv.ease.admintool.dao.StationAndLocationInfo)
	 */
	@Override
	public SaveLocationAndStationResponse updateStationAndLocationInfo(
			StationAndLocationInfo info) {
		if (info == null)
			throw new NullPointerException("Illegal object");

		SaveLocationAndStationResponse busResponse = new SaveLocationAndStationResponse();
		IErrorCollector errorCollector = new ErrorCollector();
		Session session = null;
		try {
			Location loc = getLocationByStationSysId(info.getLocation()
					.getStation().getId().toString());
			//Station station = getStationById(info.getStation().getId().toString());
			session = PersistenceService.getInstance().getSessionFactory()
					.getCurrentSession();
			session.beginTransaction();
			loc.setIpAddress(info.getLocation().getIpAddress());
			session.update(loc);

			/**STATION INFO*/
			Station station = (Station) session.load(Station.class, info.getStation().getId());
			station.setAlternatePrinterId(info.getStation().getAlternatePrinterId());
			station.setPrimaryPrinterId(info.getStation().getPrimaryPrinterId());
			
			session.saveOrUpdate(station);
			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
			errorCollector.register(e);
			busResponse = new SaveLocationAndStationResponse(errorCollector);
			session.getTransaction().rollback();
		}
		return busResponse;
	}

	/**
	 * ***** END ***************.
	 *
	 * @param input the input
	 * @param updateBoth the update both
	 * @return the save work date status response
	 */


	public SaveWorkDateStatusResponse updateOfficeWorkDateStatus(
			List <OfficeWorkdate> input) {

		SaveWorkDateStatusResponse busResponse = null;
		IErrorCollector errorCollector = new ErrorCollector();
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		if (input.size() == 0) {
			errorCollector.register(new IllegalArgumentException(
					"No office work date control records found to update"));
			busResponse = new SaveWorkDateStatusResponse();
			busResponse.setErrorCollector(errorCollector);
			return busResponse;
		}
		try {
			// Update Office Work Date Records (Status).
			for (OfficeWorkdate officeWorkdate : input) {
				//if ("A".equals(officeWorkdate.getStatus())) {
					officeWorkdate.setStatus("A");
					session.update(officeWorkdate);
				//}
			}
			session.getTransaction().commit();
			busResponse = new SaveWorkDateStatusResponse();
		} catch (Exception e) {
			errorCollector.register(e);
			busResponse = new SaveWorkDateStatusResponse(errorCollector);
			session.getTransaction().rollback();
		}
		return busResponse;
	
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @seegov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#
	 * updateWorkDateStatus(java.util.List, boolean)
	 */
	@Override
	public SaveWorkDateStatusResponse updateWorkDateStatus(
			List<EmployeeWorkdateControl> input, boolean updateBoth) {
		SaveWorkDateStatusResponse busResponse = null;
		IErrorCollector errorCollector = new ErrorCollector();
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		if (input.size() == 0) {
			errorCollector.register(new IllegalArgumentException(
					"No employee work date control records found to update"));
			busResponse = new SaveWorkDateStatusResponse();
			busResponse.setErrorCollector(errorCollector);
			return busResponse;
		}
		try {
			// Update Employee Work Date Records.
			for (EmployeeWorkdateControl employeeWorkdateControl : input) {
				//if ("A".equals(employeeWorkdateControl.getStatus())) {
					employeeWorkdateControl.setStatus("A");
					session.update(employeeWorkdateControl);
				//}
			}
			// Also update Office Work Date Records if both should be.
			if (updateBoth) {
				for (EmployeeWorkdateControl employeeWorkdateControl : input) {
					//if ("A".equals(employeeWorkdateControl.getOfficeWorkdate()
					//		.getStatus())) {
						employeeWorkdateControl.getOfficeWorkdate().setStatus(
								"A");
						session.update(employeeWorkdateControl);
					//}
				}
			}
			session.getTransaction().commit();
			busResponse = new SaveWorkDateStatusResponse();
		} catch (Exception e) {
			errorCollector.register(e);
			busResponse = new SaveWorkDateStatusResponse(errorCollector);
			session.getTransaction().rollback();
		}
		return busResponse;
	}

	/**
	 * Gets the offices by satellite indicator.
	 *
	 * @param satelliteInd the satellite ind
	 * @return the offices by satellite indicator
	 */
	@SuppressWarnings("unchecked")
	private List<Office> getOfficesBySatelliteIndicator(String satelliteInd) {
		if (satelliteInd == null) {
			throw new NullPointerException("Satellite Indicator was null");
		}
		Class<?> aClass = Office.class;
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		List<Office> hostOffices = new ArrayList<Office>();
		Criteria criteria = session.createCriteria(aClass, "ofc");
		criteria.add(Restrictions.eq("ofc.satelliteOffice", satelliteInd));
		List retrievedList = criteria.list();
		for (Object obj : retrievedList) {
			hostOffices.add((Office) obj);
		}
		session.getTransaction().commit();
		return hostOffices;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getHostOffices()
	 */
	@Override
	public List<Office> getHostOffices() {
		return getOfficesBySatelliteIndicator("N");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getSatelliteOffices()
	 */
	@Override
	public List<Office> getSatelliteOffices() {
		return getOfficesBySatelliteIndicator("Y");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#getHostOfficesExcept(java.lang.Long)
	 */
	@Override
	public List<Office> getHostOfficesExcept(Long id) {
		// List <Office> hostOffices = getOfficesBySatelliteIndicator("N");
		List<Office> hostOffices = getAllOffices();
		for (Office office : hostOffices) {
			if (id.equals(office.getId())) {
				hostOffices.remove(office);
				break;
			}
		}
		Collections.sort(hostOffices, new Comparator<Office>() {
			public int compare(Office ofc1, Office ofc2) {
				return ofc1.getOfficeId().compareTo(ofc2.getOfficeId());
			}
		});
		return hostOffices;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateSatelliteOfficeIndicator(gov.ca.dmv.ease.bo.admin.impl.Office, java.lang.Long)
	 */
	@Override
	public SaveOfficeResponse updateSatelliteOfficeIndicator(
			Office targetOffice, Long satelliteOfficeSysId) {
		SaveOfficeResponse busResponse = null;
		IErrorCollector errorCollector = new ErrorCollector();
		if (targetOffice == null || satelliteOfficeSysId == null) {
			errorCollector.register(new NullPointerException(
					"targetOffice or satelliteOfficeSysId was null"));
			busResponse = new SaveOfficeResponse();
			busResponse.setErrorCollector(errorCollector);
			return busResponse;
		}
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		busResponse = new SaveOfficeResponse();
		try {
			// Set OfficeSysId value
			targetOffice.setMainOfficeId(satelliteOfficeSysId);
			// Set satellite office indicator value to "Y"
			targetOffice.setSatelliteOffice("Y");
			// Where sysid = <target_office_id>
			Criteria criteria = session.createCriteria(Office.class, "ofc");
			criteria.add(Restrictions.eq("ofc.id", targetOffice.getId()));
			session.update(targetOffice);
			session.getTransaction().commit();
		} catch (Exception e) {
			errorCollector.register(e);
			busResponse = new SaveOfficeResponse(errorCollector);
			session.getTransaction().rollback();
		}
		return busResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.admintool.dao.IAdminToolPersistenceService#updateOfficeIndicatorToN(gov.ca.dmv.ease.bo.admin.impl.Office, java.lang.String)
	 */
	@Override
	public SaveOfficeResponse updateOfficeIndicatorToN(Office targetOffice,
			String indicator) {
		SaveOfficeResponse busResponse = null;
		IErrorCollector errorCollector = new ErrorCollector();
		if (targetOffice == null) {
			errorCollector.register(new NullPointerException(
					"targetOffice or satelliteOfficeSysId was null"));
			busResponse = new SaveOfficeResponse();
			busResponse.setErrorCollector(errorCollector);
			return busResponse;
		}
		Session session = PersistenceService.getInstance().getSessionFactory()
				.getCurrentSession();
		session.beginTransaction();
		busResponse = new SaveOfficeResponse();
		try {
			// Set OfficeSysId value to "0"
			targetOffice.setMainOfficeId(0L);
			// Set satellite office indicator value to "N"
			targetOffice.setSatelliteOffice("N");
			// Where sysid = <target_office_id>
			Criteria criteria = session.createCriteria(Office.class, "ofc");
			criteria.add(Restrictions.eq("ofc.id", targetOffice.getId()));
			session.update(targetOffice);
			session.getTransaction().commit();
		} catch (Exception e) {
			errorCollector.register(e);
			busResponse = new SaveOfficeResponse(errorCollector);
			session.getTransaction().rollback();
		}
		return busResponse;
	}

	public StationAndLocationInfo lookupIpAddress(String ipAddress) {
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Location.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();

		List<IBusinessObject> listOfBusinessObjects = null;// aResponse.getResults();

		if (aResponse.hasErrors()) {
			// request.rollbackTransaction();
			// throw new
			// EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("ipAddress", ipAddress));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}

		Location retLocation = null;
		if (listOfBusinessObjects != null && listOfBusinessObjects.size() == 1)
			retLocation = (Location) listOfBusinessObjects.get(0);
		
		StationAndLocationInfo stationAndLocationInfo = new StationAndLocationInfo();
		stationAndLocationInfo.setLocation(retLocation);
		return stationAndLocationInfo;
	}
	
	private String getL1ServerInfo(String officeId) {
		IRetrieveCriteriaObjectRequest request = PersistenceServiceRequestFactory
				.getInstance().createRetrieveCriteriaObjectRequest(
						UserContext.getDefaultInstanceForDb(), Location.class);
		request.beginTransaction();
		RetrieveCriteriaObjectResponse aResponse = (RetrieveCriteriaObjectResponse) request
				.execute();

		List<IBusinessObject> listOfBusinessObjects = null;// aResponse.getResults();

		if (aResponse.hasErrors()) {
			// request.rollbackTransaction();
			// throw new
			// EaseException(aResponse.getErrorCollector().toString());
		} else {
			Criteria criteria = aResponse.getCriteriaInstance();
			criteria.add(Restrictions.eq("officeId", officeId));
			listOfBusinessObjects = criteria.list();
			request.commitTransaction();
		}

		Location retLocation = null;
		if (listOfBusinessObjects != null && listOfBusinessObjects.size() > 0)
			retLocation = (Location) listOfBusinessObjects.get(0);
		
		return retLocation != null ? retLocation.getL1ServerCode() : null;
	}
}
/**
 * Modification History:
 * 
 * $Log: AdminToolPersistenceService.java,v $
 * Revision 1.13  2012/12/21 17:59:56  mwnrk
 * Modified the files.
 * Revision 1.12 2012/11/17 00:19:00
 * mwpkc2 Added Satellite Host functionality
 * 
 * Revision 1.11 2012/10/29 18:16:30 mwpkc2 Modified Update functionality.
 * 
 * Revision 1.10 2012/10/26 16:56:38 mwpkc2 Made changes as existing BOs are
 * being used
 * 
 * Revision 1.9 2012/10/24 23:33:03 mwpkc2 Made integration changes
 * 
 * Revision 1.8 2012/10/24 21:47:36 mwpkc2 Made integration changes
 * 
 * Revision 1.7 2012/10/24 21:17:39 mwpkc2 Refined service method
 * implementations
 * 
 * Revision 1.6 2012/10/24 00:33:45 mwpkc2 Updated service method
 * implementations
 * 
 * Revision 1.5 2012/10/22 19:58:30 mwpkc2 implemented getEmployeeOfficeDetails
 * 
 * Revision 1.4 2012/10/19 17:37:01 mwpkc2 Created response classes
 * 
 * Revision 1.3 2012/10/19 16:29:09 mwpkc2 Implemented few more methods
 * 
 * Revision 1.2 2012/10/18 20:02:39 mwpkc2 Removed compilation errors
 * 
 * Revision 1.1 2012/10/18 18:57:53 mwpkc2 Made changes as EASE Portal standards
 * 
 * Revision 1.1 2012/10/15 18:36:57 mwsec2 initial check in
 * 
 */
