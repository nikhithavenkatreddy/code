			SELECT * FROM MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL ewdc
			LEFT JOIN MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL owdc ON owdc.SYS_ID = ewdc.OFFICE_WRK_DT_CNTRL_SYSID
			LEFT JOIN MWKDB2MV.VSSM028U_OFFICE o ON owdc.OFFICE_SYSID = o.SYS_ID
			LEFT JOIN MWKDB2MV.VSSM026U_EMPLOYEE_A e ON e.SYS_ID = ewdc.EMPLOYEE_SYSID
			WHERE o.OFFICE_ID = '111'
			--AND e.TECH_ID = 'YY'
			--AND ewdc.AUTHD_WRK_DT_STATUS = 'A' 
			AND owdc.AUTHD_WRK_DT_STATUS in('S', 'A')
			
			--AND owdc.AUTHD_WRK_DT = '2014-07-23 00.00.00.0'
			--ORDER BY ewdc.MODIFIED_TSTAMP DESC
			FETCH FIRST 1 ROWS ONLY;
			
			
			SELECT * from MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL owdc LEFT JOIN MWKDB2MV.VSSM028U_OFFICE o ON owdc.OFFICE_SYSID = o.SYS_ID
			LEFT JOIN MWKDB2MV.VSSM026U_EMPLOYEE_A e ON e.SYS_ID = ewdc.EMPLOYEE_SYSID
			WHERE o.OFFICE_ID = '111'
			--AND e.TECH_ID = 'YY'
			--AND ewdc.AUTHD_WRK_DT_STATUS = 'A' 
			AND owdc.AUTHD_WRK_DT_STATUS in('S', 'A')
			
			--AND owdc.AUTHD_WRK_DT = '2014-11-17 00.00.00.0'
			--ORDER BY ewdc.MODIFIED_TSTAMP DESC
			FETCH FIRST 1 ROWS ONLY;
			
			select * from MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL where office_sysid=2401 order by modified_tstamp desc;
			
			--select * from MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL where office_wrk_dt_cntrl_sysid =  order by modified_tstamp desc; 
			
			update MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL set AUTHD_WRK_DT=to_date('2015-11-18', 'YYYY-MM-DD') where office_sysid=2401 and sys_id=16145;
			
			select * from MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL where office_sysid=2401; 
			select * from MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL where office_wrk_dt_cntrl_sysid in (2688, 2662, 2687, 2689);
			
			update MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL  set office_wrk_dt_cntrl_sysid = 2662 where employee_sysid=29086; 
			
			select * from MWKDB2MV.VTDM027U_EMP_WRK_DT_CNTRL where employee_sysid=29086;
			
			select * from MWKDB2MV.VSSM026U_EMPLOYEE_A where tech_id='YY';
			
			-- 2689 = 2015-11-18
			
			SELECT TO_DATE (TO_CHAR (SYSTIMESTAMP, 'YYYY-MON-DD HH24:MI:SS'),
                'YYYY-MON-DD HH24:MI:SS'
               ) AS my_date
  FROM DUAL;


select this_.SYS_ID as SYS1_10_1_, this_.CREATOR_ID as CREATOR2_10_1_, this_.CREATE_TSTAMP as CREATE3_10_1_, this_.MODIFIED_BY as MODIFIED4_10_1_, this_.MODIFIED_TSTAMP as MODIFIED5_10_1_, this_.AUTHD_WRK_DT as AUTHD6_10_1_, this_.AUTHD_WRK_DT_STATUS as AUTHD7_10_1_, this_.OFFICE_SYSID as OFFICE8_10_1_, off1_.SYS_ID as SYS1_9_0_, off1_.CREATOR_ID as CREATOR2_9_0_, off1_.CREATE_TSTAMP as CREATE3_9_0_, off1_.MODIFIED_BY as MODIFIED4_9_0_, off1_.MODIFIED_TSTAMP as MODIFIED5_9_0_, off1_.OFFICE_NME as OFFICE6_9_0_, off1_.OFFICE_ID as OFFICE7_9_0_, off1_.OFFICE_DL_TEST_WINDOW_NBR as OFFICE8_9_0_, off1_.OFFICE_PHONE_NBR as OFFICE9_9_0_, off1_.SATELLITE_OFFICE_IND as SATELLITE10_9_0_, off1_.OFFICE_SYSID as OFFICE11_9_0_ from VTDM028U_OFFICE_WRK_DT_CNTRL this_ inner join VSSM028U_OFFICE off1_ on this_.OFFICE_SYSID=off1_.SYS_ID where off1_.OFFICE_ID='111' and this_.AUTHD_WRK_DT_STATUS in ('A', 'S') fetch first 1 rows only;

select * from MWKDB2MV.VTDM028U_OFFICE_WRK_DT_CNTRL where office_sysid=2401;

select * from MWKDB2MV.VSSM028U_OFFICE where office
			