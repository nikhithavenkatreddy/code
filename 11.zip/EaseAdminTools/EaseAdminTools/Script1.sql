select * from MWKDB2MV.VTDM036U_SYS_MGMT_LOG where log_entry like '%SS5%';

select * from MWKDB2MV.VTDM036U_SYS_MGMT_LOG where log_entry like '%LPV%';

select log_entry from MWKDB2MV.VTDM036U_SYS_MGMT_LOG where log_entry like '%ZIP%';

select log_entry from MWKDB2MV.VTDM036U_SYS_MGMT_LOG where log_entry like '%SVR%';

select * from MWKDB2MV.VTDM036U_SYS_MGMT_LOG where log_entry like '%EL1%';