/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.locator.AddressType;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.fw.validate.IValidatable;

import java.util.Date;

/**
 * Description: The Address business object captures the street name, 
 * house/apartment number in line1, line2, line3 and line4.
 * File: Address.java
 * Module: gov.ca.dmv.ease.bo.locator.impl
 * Created: Apr 28, 2009
 * 
 * @author MWCSJ3
 * @version $Revision: 1.12 $
 * Last Changed: $Date: 2011/07/08 23:31:26 $
 * Last Changed By: $Author: mwhys $
 */
public class Address extends Locator implements IValidatable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -317153252951918200L;
	/** Holds the address type (Residential, Mailing, etc...) */
	private AddressType addressType;
	
	/**
	 * Sets the address type.
	 *
	 * @param addressType the addressType to set
	 */
	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}
	
	/** The city. */
	private String city;
	/** The county. */
	private String county;
	/** The Address line1. */
	private String line1;
	/** The Address line2. */
	private String line2;
	/** This holds return validity codes from the back end for address inquiry. */
	private CodeSetElement serviceVerificationCode;
	/** The state code. */
	private CodeSetElement stateCode;
	/** The zip code. */
	private String zip;
	
	/**
	 * Constructor.
	 * 
	 * @param addressType the Address Type
	 */
	public Address(AddressType addressType) {
		this.addressType = addressType;
	}
	
	/**
	 * Constructor.
	 * 
	 * @param addressType the Address Type
	 */
	public Address(String addressType) {
		this.addressType = AddressType.valueOf(addressType);
	}
	
	/**
	 * Instantiates a new Address data - copy constructor.
	 *
	 * @param address the address
	 */
	public Address(Address address) {
		super();
		copy(address);
	}
	
	/**
	 * Gets the address type.
	 * 
	 * @return the address type
	 */
	public AddressType getAddressType() {
		return addressType;
	}
	
	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * Gets the county.
	 *
	 * @return the county
	 */
	public String getCounty() {
		return county;
	}
	
	/**
	 * Gets the line1.
	 * 
	 * @return the line1
	 */
	public String getLine1() {
		return line1;
	}
	
	/**
	 * Gets the line2.
	 * 
	 * @return the line2
	 */
	public String getLine2() {
		return line2;
	}
	
	/**
	 * Gets the service verification code.
	 * 
	 * @return the service verification code
	 */
	public CodeSetElement getServiceVerificationCode() {
		return serviceVerificationCode;
	}
	
	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		if (stateCode != null) {
			return stateCode.getCode();
		}
		return null;
	}
	
	/**
	 * Gets the state code.
	 *
	 * @return the stateCode
	 */
	public CodeSetElement getStateCode() {
		return stateCode;
	}
	
	/**
	 * Gets the zip code.
	 * 
	 * @return the zip code
	 */
	public String getZip() {
		return zip;
	}
	
	/**
	 * This method returns if a address values are populated or not.
	 * 
	 * @return True if address values are populated
	 */
	public boolean isEmpty() {
		return (DummyLocatorHelper.getFullAddress(this) == null
				|| DummyLocatorHelper.getFullAddress(this).trim().length() == 0
				|| getCity() == null || getCity().trim().length() == 0);
	}
	
	/**
	 * Sets the city.
	 *
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	 * Sets the county.
	 *
	 * @param county the county to set
	 */
	public void setCounty(String county) {
		this.county = county;
	}
	
	/**
	 * Set the full address to the line1, line2, line3 and line4.
	 *
	 * @param fullAddress the new full address
	 */
	public void setFullAddress(String fullAddress) {
		//We need to split the full address and assign it to line1, line2, 
		//line3 and line4
		line1 = fullAddress;
	}
	
	/**
	 * Sets the line1.
	 * 
	 * @param line1 the new line1
	 */
	public void setLine1(String line1) {
		this.line1 = line1;
	}
	
	/**
	 * Sets the line2.
	 * 
	 * @param line2 the new line2
	 */
	public void setLine2(String line2) {
		this.line2 = line2;
	}
	
	/**
	 * Sets the service verification code.
	 * 
	 * @param serviceVerificationCode the new service verification code
	 */
	public void setServiceVerificationCode(
			CodeSetElement serviceVerificationCode) {
		this.serviceVerificationCode = serviceVerificationCode;
	}
	
	/**
	 * Sets the state code.
	 *
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(CodeSetElement stateCode) {
		this.stateCode = stateCode;
	}
	
	/**
	 * Sets the zip.
	 *
	 * @param zipCode the new zip
	 */
	/*	public void setState(String state) {
			this.state = state;
		}*/
	/**
	 * Sets the zip code.
	 * 
	 * @param zipCode the new zip code
	 */
	public void setZip(String zipCode) {
		this.zip = zipCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.IValidatable#validate()
	 */
	public IErrorCollector validate() {
		return null;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.IValidatable#validateUsing(gov.ca.dmv.ease.fw.IErrorCollector)
	 */
	public void validateUsing(IErrorCollector collector) {
	}
	
	/**
	 * Checks if is same as except county.
	 *
	 * @param compareTo the compare to
	 * @return true, if is same as except county
	 */
	public boolean isSameAsExceptCounty(Address compareTo) {
		if (!EaseUtil.isNullOrBlank(compareTo)) {
			//LINE 1
			if (EaseUtil.isNullOrBlank(getLine1())) {
				if (!EaseUtil.isNullOrBlank(compareTo.getLine1())) {
					return false;
				}
			}
			else if (!getLine1().equalsIgnoreCase(compareTo.getLine1())) {
				return false;
			}
			//LINE 2
			if (EaseUtil.isNullOrBlank(getLine2())) {
				if (!EaseUtil.isNullOrBlank(compareTo.getLine2())) {
					return false;
				}
			}
			else if (!getLine2().equalsIgnoreCase(compareTo.getLine2())) {
				return false;
			}
			//CITY
			if (EaseUtil.isNullOrBlank(getCity())) {
				if (!EaseUtil.isNullOrBlank(compareTo.getCity())) {
					return false;
				}
			}
			else if (!getCity().equalsIgnoreCase(compareTo.getCity())) {
				return false;
			}
			//STATE
			if (EaseUtil.isNullOrBlank(getState())) {
				if (!EaseUtil.isNullOrBlank(compareTo.getState())) {
					return false;
				}
			}
			else if (!getState().equalsIgnoreCase(compareTo.getState())) {
				return false;
			}
			//ZIP
			if (EaseUtil.isNullOrBlank(getZip())) {
				if (!EaseUtil.isNullOrBlank(compareTo.getZip())) {
					return false;
				}
			}
			else if (!getZip().equalsIgnoreCase(compareTo.getZip())) {
				return false;
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * This method is to copy Address.
	 *
	 * @param objectToCopy the object to copy
	 */
	protected void copy(Address objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null address argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		setAddressType(objectToCopy.getAddressType());
		setLine1(objectToCopy.getLine1());
		setLine2(objectToCopy.getLine2());
		setCounty(objectToCopy.getCounty());
		setCity(objectToCopy.getCity());
		if (EaseUtil.isNotNull(objectToCopy.getServiceVerificationCode())) {
			setServiceVerificationCode(new CodeSetElement(objectToCopy
					.getServiceVerificationCode()));
		}
		else {
			setServiceVerificationCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getStateCode())) {
			setStateCode(new CodeSetElement(objectToCopy.getStateCode()));
		}
		else {
			setStateCode(null);
		}
		setZip(objectToCopy.getZip());
		if (EaseUtil.isNotNull(objectToCopy.getEffectiveDate())) {
			setEffectiveDate(new Date(objectToCopy.getEffectiveDate().getTime()));
		}
		else {
			setEffectiveDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getEndDate())) {
			setEndDate(new Date(objectToCopy.getEndDate().getTime()));
		}
		else {
			setEndDate(null);
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((addressType == null) ? 0 : addressType.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((county == null) ? 0 : county.hashCode());
		result = prime * result + ((line1 == null) ? 0 : line1.hashCode());
		result = prime * result + ((line2 == null) ? 0 : line2.hashCode());
		result = prime
				* result
				+ ((serviceVerificationCode == null) ? 0
						: serviceVerificationCode.hashCode());
		result = prime * result
				+ ((stateCode == null) ? 0 : stateCode.hashCode());
		result = prime * result + ((zip == null) ? 0 : zip.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (addressType == null) {
			if (other.addressType != null)
				return false;
		}
		else if (!addressType.equals(other.addressType))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		}
		else if (!city.equals(other.city))
			return false;
		if (county == null) {
			if (other.county != null)
				return false;
		}
		else if (!county.equals(other.county))
			return false;
		if (line1 == null) {
			if (other.line1 != null)
				return false;
		}
		else if (!line1.equals(other.line1))
			return false;
		if (line2 == null) {
			if (other.line2 != null)
				return false;
		}
		else if (!line2.equals(other.line2))
			return false;
		if (serviceVerificationCode == null) {
			if (other.serviceVerificationCode != null)
				return false;
		}
		else if (!serviceVerificationCode.equals(other.serviceVerificationCode))
			return false;
		if (stateCode == null) {
			if (other.stateCode != null)
				return false;
		}
		else if (!stateCode.equals(other.stateCode))
			return false;
		if (zip == null) {
			if (other.zip != null)
				return false;
		}
		else if (!zip.equals(other.zip))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Address.java,v $
 *  Revision 1.12  2011/07/08 23:31:26  mwhys
 *  Added isSameAsExceptCounty()
 *
 *  Revision 1.11  2011/04/07 04:04:54  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.10.10.6  2011/04/05 18:09:17  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.10.10.5  2011/04/04 20:34:02  mwkfh
 *  updated copy
 *
 *  Revision 1.10.10.4  2011/04/04 19:00:18  mwkfh
 *  added null check to copy
 *
 *  Revision 1.10.10.3  2011/04/04 18:02:13  mwkfh
 *  fixed copy for state code
 *
 *  Revision 1.10.10.2  2011/04/04 17:01:10  mwkfh
 *  changed copy to protected
 *
 *  Revision 1.10.10.1  2011/04/04 00:55:00  mwrrv3
 *  Added copyConstructor functionality to this class.
 *
 *  Revision 1.10  2010/12/29 22:47:18  mwtjc1
 *  addressType is set in copy method
 *
 *  Revision 1.9  2010/12/14 17:36:28  mwrxn3
 *  Updated
 *
 *  Revision 1.8  2010/12/13 19:24:13  mwrxn3
 *  Removed getMyCopy method and updated with copy constructor
 *
 *  Revision 1.7  2010/12/12 22:30:22  mwrxn3
 *  Added getMyCopy method
 *
 *  Revision 1.6  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.5  2010/07/11 21:21:17  mwhxb3
 *  Check if the stateCode is null.
 *
 *  Revision 1.4  2010/05/12 17:16:45  mwvxm6
 *  Removed attribute apartmentOrSuite
 *
 *  Revision 1.3  2010/05/10 20:51:31  mwrsk
 *  USe equalsIgnoreCase in "equals()" method
 *
 *  Revision 1.2  2010/04/29 17:24:51  mwvxm6
 *  Added attribute apartmentOrSuite
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.14  2010/04/05 18:09:06  mwvxm6
 *  Changed Address attribute state code type from String to CodeSetElement
 *
 *  Revision 1.13  2010/03/03 21:30:03  mwrsk
 *  Added serviceVerificationCode
 *
 *  Revision 1.12  2010/03/03 16:10:01  mwrsk
 *  Removed private constructor
 *
 *  Revision 1.11  2010/03/03 16:09:11  mwrsk
 *  cleanup imports
 *
 *  Revision 1.10  2010/02/25 23:57:44  mwvxm6
 *  Updated a new constructor to accept a string and derive type code
 *
 *  Revision 1.9  2010/02/25 01:41:17  mwrsk
 *  Removed "returnCode"
 *
 *  Revision 1.8  2010/02/24 21:03:13  mwuxb
 *  Added attribute returnCode
 *
 *  Revision 1.7  2010/02/18 18:36:33  mwhxa2
 *  Updated Constructor
 *
 *  Revision 1.6  2010/02/12 00:26:08  mwrsk
 *  Changed addressTypeCode to addressType
 *
 *  Revision 1.5  2010/02/10 01:50:00  mwrsk
 *  AddressType ENUM fixes
 *
 *  Revision 1.4  2010/01/28 22:36:48  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/06 00:01:55  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:21  mwrsk
 *  Intial commit
 *
 *  Revision 1.20  2009/10/15 22:18:26  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.19  2009/10/03 21:06:34  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.18  2009/09/24 18:24:55  mwhxa2
 *  Address now implements IValidatable
 *
 *  Revision 1.17  2009/09/24 00:21:35  mwcsj3
 *  Added helper method to check if Mailing address and Residence address are same
 *
 *  Revision 1.16  2009/09/02 15:55:30  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.15  2009/09/02 15:43:43  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.14  2009/08/27 05:39:56  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2009/08/25 16:18:22  mwsmg6
 *  removed unnecessary import
 *
 *  Revision 1.12  2009/08/25 15:10:00  mwsmg6
 *  removed CityCode from Address
 *
 *  Revision 1.11  2009/08/23 21:30:46  mwakg
 *  Added isEmpty method
 *
 *  Revision 1.10  2009/08/22 23:21:48  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.8  2009/08/05 21:47:04  mwrrv3
 *  Added setFullAddress method.
 *
 *  Revision 1.7  2009/08/03 23:45:48  mwrrv3
 *  Added default constructor and created new objects inside default constructor and added comments.
 *
 *  Revision 1.6  2009/07/28 01:59:24  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.5  2009/07/22 00:43:54  mwrrv3
 *  Added comments.
 *
 *  Revision 1.4  2009/07/21 23:46:13  mwpxp2
 *  Added a fixme
 *
 *  Revision 1.3  2009/07/21 18:33:59  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.2  2009/07/14 23:44:38  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:44:15  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
