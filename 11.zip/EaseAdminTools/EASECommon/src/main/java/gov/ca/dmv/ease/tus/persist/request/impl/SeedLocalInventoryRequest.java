/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.response.impl.SeedLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

import java.util.List;

/**
 * Description: I am request to replace all existing instances of a given class of BO with the instances provided of that class.
 * 
 * File: SeedLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Sep 12, 2010 
 * @author MWKFH  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/11/07 19:47:31 $
 * Last Changed By: $Author: mwkfh $
 */
public class SeedLocalInventoryRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7456029094146529417L;
	/** The all sequences. */
	List <IContiguousItemSequence> contiguousItemSequenceList;
	/** Office Id to purge */
	private String officeId;
	/** Processor Id to purge */
	private String processorId;

	/**
	 * @param userContext
	 * @param contiguousItemSequenceList
	 */
	public SeedLocalInventoryRequest(IUserContext userContext,
			List <IContiguousItemSequence> contiguousItemSequenceList) {
		super(userContext);
		setContiguousItemSequenceList(contiguousItemSequenceList);
		if (!EaseUtil.isNullOrBlank(contiguousItemSequenceList)) {
			//assume list is for same office & processor
			setOfficeId(contiguousItemSequenceList.get(0).getOfficeId());
			setProcessorId(contiguousItemSequenceList.get(0).getProcessorId());
		}
	}

	/**
	 * @param userContext
	 * @param officeId
	 * @param processorId
	 * @param contiguousItemSequenceList
	 */
	public SeedLocalInventoryRequest(IUserContext userContext, String officeId,
			String processorId,
			List <IContiguousItemSequence> contiguousItemSequenceList) {
		super(userContext);
		setContiguousItemSequenceList(contiguousItemSequenceList);
		setOfficeId(officeId);
		setProcessorId(processorId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public SeedLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Adds the.
	 * 
	 * @param contiguousItemSequence
	 */
	public void add(IContiguousItemSequence contiguousItemSequence) {
		getContiguousItemSequenceList().add(contiguousItemSequence);
	}

	/**
	 * Adds the all.
	 * 
	 * @param contiguousItemSequence list
	 */
	public void addAll(List <IContiguousItemSequence> contiguousItemSequenceList) {
		getContiguousItemSequenceList().addAll(contiguousItemSequenceList);
	}

	/**
	 * Gets the contiguousItemSequence list.
	 * 
	 * @return the contiguousItemSequence list
	 */
	public List <IContiguousItemSequence> getContiguousItemSequenceList() {
		return contiguousItemSequenceList;
	}

	/**
	 * Gets the office id
	 * 
	 * @return
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Gets the processor id
	 * 
	 * @return the processorId
	 */
	public String getProcessorId() {
		return processorId;
	}

	/**
	 * Return true if the office id is not blank or null
	 * 
	 * @return true/false
	 */
	public boolean hasOfficeId() {
		return !EaseUtil.isNullOrBlank(getOfficeId());
	}

	/**
	 * Return true if the processor id is not blank or null
	 * 
	 * @return true/false
	 */
	public boolean hasProcessorId() {
		return !EaseUtil.isNullOrBlank(getProcessorId());
	}

	/**
	 * Sets the contiguousItemSequence list.
	 * 
	 * @param contiguousItemSequenceList
	 */
	protected void setContiguousItemSequenceList(
			List <IContiguousItemSequence> contiguousItemSequenceList) {
		this.contiguousItemSequenceList = contiguousItemSequenceList;
	}

	/** 
	 * Sets the office id
	 * 
	 * @param officeId
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Sets the processor id
	 * 
	 * @param processorId the processorId to set
	 */
	public void setProcessorId(String processorId) {
		this.processorId = processorId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SeedLocalInventoryRequest.java,v $
 *  Revision 1.5  2011/11/07 19:47:31  mwkfh
 *  updated constructor
 *
 *  Revision 1.4  2011/09/23 00:20:28  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.3  2011/01/10 21:48:05  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.2  2011/01/07 17:45:51  mwkfh
 *  updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 *  Revision 1.1  2010/09/20 18:25:44  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/14 16:31:33  mwkfh
 *  updated local inventory persistence
 *
 *  Revision 1.2  2010/09/14 00:44:03  mwkfh
 *  made LocalPersistenceService non-static
 *
 *  Revision 1.1  2010/09/13 16:54:40  mwkfh
 *  added LocalPersistenceService and Seed for inventory
 *
 */
