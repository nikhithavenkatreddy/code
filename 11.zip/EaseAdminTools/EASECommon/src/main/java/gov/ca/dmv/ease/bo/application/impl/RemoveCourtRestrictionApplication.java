/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;

import java.util.Map;

/**
 * Description: This class captures information pertaining to the payments for removing court restrictions.
 * File: RemoveCourtRestrictionApplication.java
 * Module:  gov.ca.dmv.ease.bo.misc
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class RemoveCourtRestrictionApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4627821635271352846L;
	/** The fee indicators */
	private Map <String, Integer> feeIndicators;

	/**
	 * Instantiates a new application.
	 */
	public RemoveCourtRestrictionApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the feeIndicators
	 */
	public Map <String, Integer> getFeeIndicators() {
		return feeIndicators;
	}

	/**
	 * @param feeIndicators the feeIndicators to set
	 */
	public void setFeeIndicators(Map <String, Integer> feeIndicators) {
		this.feeIndicators = feeIndicators;
	}
}
