/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

/**
 * Description: I represent a cash payment
 * File: CashPayment.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Aug 4, 2009 
 * @author MWRSK  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/01/22 02:49:49 $
 * Last Changed By: $Author: mwyxg1 $
 */
public class CashPayment extends Payment {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7865594694773720016L;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.Payment#isCash()
	 */
	@Override
	public boolean isCash() {
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CashPayment.java,v $
 *  Revision 1.5  2011/01/22 02:49:49  mwyxg1
 *  remove constructor
 *
 *  Revision 1.4  2011/01/22 02:28:28  mwyxg1
 *  add date
 *
 *  Revision 1.3  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/07/07 18:47:24  mwpxp2
 *  Added is~ redefinition from super
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/06 00:14:19  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/10/13 22:39:29  mwvxm6
 *  Added PaymentValidator so that the validate method get code coverage for this method.
 *  Added a basic Payment validation to check for amount NOT= 0.
 *  Comment out this validation if a uses case requires 0 or null amounts
 *
 *  Revision 1.5  2009/10/03 21:06:33  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.4  2009/09/25 00:01:07  mwhxa2
 *  Payment now extends base businessObject
 *
 *  Revision 1.3  2009/08/04 16:01:31  mwrsk
 *  Remove Hibernate annotations
 *
 *  Revision 1.2  2009/07/14 23:44:37  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:17  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  May 4, 2009 4:39:52 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  May 4, 2009 4:39:52 PM  MWCSJ3
 *  $Initial
 *  $
 */
