/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response;

import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am interface for responses from inventory for requests 
 * involving inventory items
 * 
 * File: IInventoryServiceResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/20 22:07:52 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IInventoryServiceResponse extends IResponse {
	
	/**
	 * Gets the affected item count.
	 * 
	 * @return the affected item count
	 */
	int getAffectedItemCount();
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryServiceResponse.java,v $
 *  Revision 1.1  2010/09/20 22:07:52  mwpxp2
 *  Initial
 *
 */
