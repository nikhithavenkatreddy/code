/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

import java.util.Date;
import java.util.List;

/**
 * Description: I am the persistence response for AssignDafNumber
 * File: AssignDafNumberResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Dec 17, 2010
 * 
 * @author MWYXG1
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/20 22:35:56 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class AuthorizeWorkDateResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4369686093023545376L;
	private List <Date> authorizedWorkDates;

	/**
	 * Default constructor.
	 * 
	 * @param transaction the transaction
	 */
	public AuthorizeWorkDateResponse(List <Date> authorizedWorkDates) {
		super();
		setAuthorizedWorkDates(authorizedWorkDates);
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public AuthorizeWorkDateResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ex the ex
	 */
	public AuthorizeWorkDateResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param errorCollector the error collector
	 */
	public AuthorizeWorkDateResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * @return the authorizedWorkDates
	 */
	public List <Date> getAuthorizedWorkDates() {
		return authorizedWorkDates;
	}

	/**
	 * @param authorizedWorkDates the authorizedWorkDates to set
	 */
	public void setAuthorizedWorkDates(List <Date> authorizedWorkDates) {
		this.authorizedWorkDates = authorizedWorkDates;
	}	
}
/**
 *  Modification History:
 *
 *  $Log: AuthorizeWorkDateResponse.java,v $
 *  Revision 1.1  2011/10/20 22:35:56  mwrrv3
 *  Initial Commit - Performance Change
 *
 *  Revision 1.5  2011/01/13 22:36:17  mwtjc1
 *  getTransaction deprecated
 *
 *  Revision 1.4  2011/01/13 22:35:23  mwtjc1
 *  AssignDafNumberResponse(ITransaction transaction) deprecated
 *
 *  Revision 1.3  2011/01/13 22:35:00  mwtjc1
 *  allocatedDafNumber added
 *
 *  Revision 1.2  2010/12/21 16:43:56  mwyxg1
 *  change constructor
 *
 *  Revision 1.1  2010/12/17 23:01:03  mwyxg1
 *  add new
 *
 */
