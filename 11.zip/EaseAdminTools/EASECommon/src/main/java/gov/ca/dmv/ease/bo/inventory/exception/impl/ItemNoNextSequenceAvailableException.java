/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: I am exception to be used to signal no availability of the next sequence
 * for a sequence pattern
 * File: ItemNoNextSequenceAvailableException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Sep 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/22 20:56:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ItemNoNextSequenceAvailableException extends
		InventoryItemException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5491473299444956088L;

	/**
	 * Instantiates a new item no next sequence available exception.
	 */
	public ItemNoNextSequenceAvailableException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public ItemNoNextSequenceAvailableException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public ItemNoNextSequenceAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public ItemNoNextSequenceAvailableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ItemNoNextSequenceAvailableException.java,v $
 *  Revision 1.1  2010/09/22 20:56:20  mwpxp2
 *  Initial
 *
 */
