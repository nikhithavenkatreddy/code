/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * Description: Enum for Sales Person print class codes.
 * File: SalesPersonTable.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Apr 4, 2011 
 * @author MWXXW  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2012/08/14 20:42:57 $
 * Last Changed By: $Author: mwrrv3 $
 */
public enum SalesPersonTable {
	CLASS_CODE_PRIORITY_1(1, "74"),
	CLASS_CODE_PRIORITY_2(2, "72"),
	CLASS_CODE_PRIORITY_3(3, "64"),
	CLASS_CODE_PRIORITY_4(4, "73"),
	CLASS_CODE_PRIORITY_5(5, "65"),
	CLASS_CODE_PRIORITY_6(6, "78");
	
	private final int priorityId;
	private final String printClassCode;
	private static final Map <String, Integer> PRT_CLS_CD_TO_PRIORITY_MAP;
	
	// Make the mapping
	static
	{
		PRT_CLS_CD_TO_PRIORITY_MAP = new HashMap <String, Integer>();
		for (DlIdDrivingSchoolInstructorTable item : DlIdDrivingSchoolInstructorTable.values() ) {
			PRT_CLS_CD_TO_PRIORITY_MAP.put(item.getPrintClassCode(), item
					.getPriorityId());
		}
	}
	
	/**
	 * Constructor
	 */
	private SalesPersonTable(int priorityId, String printClassCode) {
		this.priorityId = priorityId;
		this.printClassCode = printClassCode;
	}

	/**
	 * Getter for priority id.
	 * @return
	 */
	public int getPriorityId() {
		return priorityId;
	}

	/**
	 * Getter for printClassCode.
	 * @return
	 */
	public String getPrintClassCode() {
		return printClassCode;
	}

	public static int getPriorityIdByPrintClassCode(String printClassCode) {
		int priorityId = -1;
		if (PRT_CLS_CD_TO_PRIORITY_MAP.containsKey(printClassCode)) {
			priorityId = PRT_CLS_CD_TO_PRIORITY_MAP.get(printClassCode);
		}
		return priorityId;
	}
}


/**
 *  Modification History:
 *
 *  $Log: SalesPersonTable.java,v $
 *  Revision 1.3  2012/08/14 20:42:57  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.2  2011/04/06 22:19:07  mwxxw
 *  Add more printClassCode mapping according requirement.
 *
 *  Revision 1.1  2011/04/06 00:32:16  mwxxw
 *  New files add for calculation printClassCode for printed docs.
 *
 */
