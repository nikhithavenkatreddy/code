/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;
import gov.ca.dmv.ease.fw.service.impl.AbstractResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am default implementation of IInventoryStatusRequestResponse
 * File: InventoryStatusRequestResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/20 22:39:01 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryStatusRequestResponse extends AbstractResponse implements
		IInventoryStatusRequestResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5274565813937526952L;
	/** The thresholds. */
	private List <IItemThreshold> thresholds;

	/**
	 * Instantiates a new inventory status request response.
	 */
	protected InventoryStatusRequestResponse() {
		super();
	}

	/**
	 * Instantiates a new inventory status request response.
	 * 
	 * @param aList the a list
	 */
	public InventoryStatusRequestResponse(List <IItemThreshold> aList) {
		super();
		setThresholdsFor(aList);
	}

	/**
	 * Sets the thresholds for.
	 * 
	 * @param aList the new thresholds for
	 */
	private void setThresholdsFor(List <IItemThreshold> aList) {
		getThresholds().addAll(aList);
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public InventoryStatusRequestResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * The Constructor.
	 * 
	 * @param collector the collector
	 */
	public InventoryStatusRequestResponse(IErrorCollector collector) {
		super(collector);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse#getThresholdForItemCode(java.lang.String)
	 */
	public IItemThreshold getThresholdForItemCode(String aCode) {
		for (IItemThreshold aLowPoint : getThresholds()) {
			if (aLowPoint.isForCode(aCode)) {
				return aLowPoint;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse#getThresholds()
	 */
	public List <IItemThreshold> getThresholds() {
		if (thresholds == null) {
			setThresholds(new ArrayList <IItemThreshold>());
		}
		return thresholds;
	}

	/**
	 * Sets the thresholds.
	 * 
	 * @param aList the a list
	 */
	protected void setThresholds(List <IItemThreshold> aList) {
		thresholds = aList;
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryStatusRequestResponse.java,v $
 *  Revision 1.1  2010/09/20 22:39:01  mwpxp2
 *  Initial
 *
 */
