/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.subject.impl.Person;

/**
 * Description: This class captures information required to cancel a License
 * File: LicenseCancellation.java
 * Module:  gov.ca.dmv.ease.bo.misc
 * Created: Apr 14, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/07/22 17:50:28 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LicenseCancellation {
	/** The Applicant. */
	private Person applicant;

	/**
	 * @return the applicant
	 */
	public Person getApplicant() {
		return applicant;
	}

	/**
	 * @param applicant the applicant to set
	 */
	public void setApplicant(Person applicant) {
		this.applicant = applicant;
	}
}
