/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.factory;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.request.impl.AddLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueMultipleLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MoveLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveLowestSequenceRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SeedLocalInventoryRequest;

import java.util.List;

/**
 * Description: Interface for an object producing service requests. This factory
 * is to be called by Persistence service clients. The requests produces by the
 * factory follow the Command Pattern and they can be executed directly.
 * 
 * File: ILocalPersistenceServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.tus.print.request.factory
 * Created: Sep 12, 2010
 * 
 * @author MWAKG
 * @version $Revision: 1.13 $
 * Last Changed: $Date: 2011/11/03 23:43:08 $
 * Last Changed By: $Author: mwkfh $
 */
public interface ILocalPersistenceServiceRequestFactory {
	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param domainObject the domain object
	 * 
	 * @return the persistence service request
	 */
	AddLocalInventoryRequest createAddLocalInventoryRequest(
			IUserContext userContext, IContiguousItemSequence domainObject);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param domainObject the domain object
	 * 
	 * @return the persistence service request
	 */
	DeleteLocalInventoryRequest createDeleteLocalInventoryRequest(
			IUserContext userContext, IContiguousItemSequence domainObject);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param domainObject the domain object
	 * 
	 * @return the persistence service request
	 */
	IssueLocalInventoryRequest createIssueLocalInventoryRequest(
			IUserContext userContext, IInventoryItem domainObject);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param domainObject the domain object
	 * 
	 * @return the persistence service request
	 */
	IssueMultipleLocalInventoryRequest createIssueMultipleLocalInventoryRequest(
			IUserContext userContext, IInventoryItem domainObject, int quantity);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param sequenceToUpdate the sequence item
	 * @param targetLocation the target location
	 * 
	 * @return the persistence service request
	 */
	MoveLocalInventoryRequest createMoveLocalInventoryRequest(
			IUserContext userContext, IContiguousItemSequence sequenceToUpdate,
			IItemLocation targetLocation);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param itemTypeCode the item type code
	 * @param officeId the office id
	 * 
	 * @return the persistence service request
	 */
	RetrieveLowestSequenceRequest createRetrieveLowestSequenceRequest(
			IUserContext userContext, String itemTypeCode, String officeId);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param sequenceList the list of item sequences
	 * 
	 * @return the persistence service request
	 */
	SeedLocalInventoryRequest createSeedLocalInventoryRequest(
			IUserContext userContext,
			List <IContiguousItemSequence> sequenceList);

	/**
	 * Creates a new ILocalPersistenceServiceRequest object.
	 * 
	 * @param userContext the user context
	 * @param officeId the office id to purge
	 * @param processorId the processor id to purge
	 * @param sequenceList the list of item sequences
	 * 
	 * @return the persistence service request
	 */
	SeedLocalInventoryRequest createSeedLocalInventoryRequest(
			IUserContext userContext, String officeId, String processorId,
			List <IContiguousItemSequence> sequenceList);
}
/**
 *  Modification History:
 *
 *  $Log: ILocalPersistenceServiceRequestFactory.java,v $
 *  Revision 1.13  2011/11/03 23:43:08  mwkfh
 *  added createRetrieveLowestSequenceRequest
 *
 *  Revision 1.12  2011/09/23 00:20:30  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.11  2011/07/06 17:10:45  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.10  2011/06/09 18:32:20  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.9  2011/06/08 17:33:30  mwkfh
 *  added AddLocalInventoryRequest
 *
 *  Revision 1.8  2011/01/10 21:57:52  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.7  2011/01/07 17:45:51  mwkfh
 *  updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 *  Revision 1.6  2010/12/05 00:03:17  mwkfh
 *  added IssueMultipleLocalInventoryReequest/Response
 *
 *  Revision 1.5  2010/12/03 16:52:09  mwkfh
 *  added move local inventory
 *
 *  Revision 1.4  2010/10/22 21:23:22  mwkfh
 *  removed unneeded methods
 *
 *  Revision 1.3  2010/10/06 22:32:39  mwkfh
 *  updated to use IInventoryItem
 *
 *  Revision 1.2  2010/09/20 23:20:38  mwpxp2
 *  Added three methods: for getting current item coutn, for issuing inventory item, and for setting thresholds
 *
 *  Revision 1.1  2010/09/20 18:25:44  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.3  2010/09/20 16:49:51  mwkfh
 *  added issue local inv item
 *
 *  Revision 1.2  2010/09/14 16:31:32  mwkfh
 *  updated local inventory persistence
 *
 *  Revision 1.1  2010/09/13 16:54:40  mwkfh
 *  added LocalPersistenceService and Seed for inventory
 *
 */
