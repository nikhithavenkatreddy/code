/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.subject.impl.Person;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: I am the PRF application object.
 * File: ProofFilingInquiry.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 5, 2010
 * @author MWVXM6
 * @version $Revision: 1.15 $
 * Last Changed: $Date: 2013/08/16 22:20:24 $
 * Last Changed By: $Author: mwlcr1 $
 */
public class ProofOfInsuranceFiling extends Application implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6259058907239666834L;
	/** The Insurance Policy. */ 
	private InsurancePolicy insurancePolicy;
	/** The return code from tcode. */
	private String returnCodeFromTcode;// DHA, DHB and DQ1 TCode return codes
	/** The return code from insurance company inquiry. */
	private String returnCodeFromInsuranceCompanyInquiry; //DHA, DHB return code
	//** The Proof of Filing Termination Date */
	private Date prfFilingTerminationDate;
		
	/**
	 * Gets the return code from tcode.
	 * 
	 * @return the return code from tcode
	 */
	public String getReturnCodeFromTcode() {
		return returnCodeFromTcode;
	}
	
	/**
	 * Sets the return code from tcode.
	 * 
	 * @param returnCodeFromTcode the new return code from tcode
	 */
	public void setReturnCodeFromTcode(String returnCodeFromTcode) {
		this.returnCodeFromTcode = returnCodeFromTcode;
	}
	
	/**
	 * Instantiates a new proof of insurance filing.
	 */
	public ProofOfInsuranceFiling() {
		insurancePolicy = new InsurancePolicy();
		setDriver(new Person());
	}
	
	/**
	 * Instantiates a new proof of insurance filing.
	 *
	 * @param aDriver the a driver
	 */
	public ProofOfInsuranceFiling(Person aDriver) {
		super();
		setDriver(aDriver);
	}
	
	/**
	 * Gets the driver.
	 * 
	 * @return the driver
	 */
	public Person getDriver() {
		return getApplicant();
	}
	
	/**
	 * Gets the insurance policy.
	 * 
	 * @return the insurancePolicy
	 */
	public InsurancePolicy getInsurancePolicy() {
		return insurancePolicy;
	}
	
	/**
	 * Sets the driver.
	 * 
	 * @param driver the driver to set
	 */
	public void setDriver(Person driver) {
		setApplicant(driver);
	}
	
	/**
	 * Sets the insurance policy.
	 * 
	 * @param insurancePolicy the insurancePolicy to set
	 */
	public void setInsurancePolicy(InsurancePolicy insurancePolicy) {
		this.insurancePolicy = insurancePolicy;
	}
	
	/**
	 * Sets the return code from insurance company inquiry.
	 *
	 * @param returnCodeFromInsuranceCompanyInquiry the returnCodeFromInsuranceCompanyInquiry to set
	 */
	public void setReturnCodeFromInsuranceCompanyInquiry(
			String returnCodeFromInsuranceCompanyInquiry) {
		this.returnCodeFromInsuranceCompanyInquiry = returnCodeFromInsuranceCompanyInquiry;
	}
	
	/**
	 * Gets the return code from insurance company inquiry.
	 *
	 * @return the returnCodeFromInsuranceCompanyInquiry
	 */
	public String getReturnCodeFromInsuranceCompanyInquiry() {
		return returnCodeFromInsuranceCompanyInquiry;
	}

	/**
	 * @param prfFilingTerminationDate the prfFilingTerminationDate to set
	 */
	public void setPrfFilingTerminationDate(Date prfFilingTerminationDate) {
		this.prfFilingTerminationDate = prfFilingTerminationDate;
	}

	/**
	 * @return the prfFilingTerminationDate
	 */
	public Date getPrfFilingTerminationDate() {
		return prfFilingTerminationDate;
	}

	}
/**
 *  Modification History:
 * 
 *  $Log: ProofOfInsuranceFiling.java,v $
 *  Revision 1.15  2013/08/16 22:20:24  mwlcr1
 *  Defect MO-DL #3 created prf of termination field for receipt
 *
 *  Revision 1.14  2012/03/14 01:57:56  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.13  2012/01/05 21:11:09  mwhys
 *  Added returnCodeFromInsuranceCompanyInquiry. (Defect 1126)
 *
 *  Revision 1.12  2011/10/19 17:17:23  mwpxp2
 *  Added constructor/1
 *
 *  Revision 1.11  2010/12/05 00:51:47  mwtjc1
 *  comment updated
 *
 *  Revision 1.10  2010/12/05 00:15:08  mwtjc1
 *  javadoc added
 *
 *  Revision 1.9  2010/12/04 22:11:08  mwtjc1
 *  returnCodeFromTcode added
 *
 *  Revision 1.8  2010/09/07 15:42:21  mwhys
 *  Added CVS footer.
 *
 *  
 */
