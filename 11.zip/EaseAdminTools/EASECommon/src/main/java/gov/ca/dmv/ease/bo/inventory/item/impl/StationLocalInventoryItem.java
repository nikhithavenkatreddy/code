/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.impl.Sequence;
import gov.ca.dmv.ease.bo.sequence.impl.SequencePatternFactory;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: I am concrete representation of an inventory item assigned to a station
 * 
 * File: StationLocalInventoryItem.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Sep 17, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.14 $
 * Last Changed: $Date: 2011/09/23 22:00:33 $
 * Last Changed By: $Author: mwkfh $
 */
public class StationLocalInventoryItem extends LocalInventoryItem {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7857379120991827901L;
	/** The station id. */
	private String stationId;

	/**
	 * Instantiates a new station local inventory item.
	 */
	protected StationLocalInventoryItem() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param anItemTypeCode the an item type code
	 * @param location the location
	 */
	public StationLocalInventoryItem(String anItemTypeCode,
			IItemLocation location) {
		super(anItemTypeCode, location);
	}

	/**
	 * Instantiates a new station local inventory item.
	 * 
	 * @param aSeqNo the a seq no & pattern
	 * @param aType the a type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 */
	public StationLocalInventoryItem(ISequence aSeqNo, IItemType aType,
			String anOfficeId, String aStationId) {
		super(aSeqNo, aType, anOfficeId);
		setStationId(aStationId);
	}

	/**
	 * Instantiates a new station local inventory item.
	 * 
	 * @param sequenceNoString the a seq no
	 * @param aType the a type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param lowerBoundaryString the lower boundary
	 * @param upperBoundaryString the upper boundary
	 */
	public StationLocalInventoryItem(String sequenceNoString, IItemType aType,
			String anOfficeId, String aStationId, String lowerBoundaryString,
			String upperBoundaryString) {
		super(new Sequence(sequenceNoString, SequencePatternFactory
				.getInstance().getSequencePatternForCode(aType.getCode(),
						lowerBoundaryString, upperBoundaryString)), aType,
				anOfficeId);
		setStationId(aStationId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#changeToOffice()
	 */
	public void changeToOffice() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			stationId = stationId.substring(0, 2) + "#";
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof StationLocalInventoryItem)) {
			return false;
		}
		StationLocalInventoryItem other = (StationLocalInventoryItem) obj;
		if (stationId == null) {
			if (other.stationId != null) {
				return false;
			}
		}
		else if (!stationId.equals(other.stationId)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getOfficeMnemonic()
	 */
	@Override
	public String getProcessorId() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			return stationId.substring(0, 2);
		}
		else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#getStationId()
	 */
	@Override
	public String getStationId() {
		return stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInventoryItem#isAssignedToStation()
	 */
	@Override
	public boolean isAssignedToStation() {
		return true;
	}

	/**
	 * Sets the station id.
	 * 
	 * @param anID the new station id
	 */
	@Override
	public void setStationId(String anID) {
		if (anID != null) {
			stationId = anID.toUpperCase();
		}
		else {
			stationId = anID;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.impl.LocalInventoryItem#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" office: ").append(getOfficeId());
		aBuilder.append(" station: ").append(stationId);
		aBuilder.append(" isAvailable: ").append(isAvailable());
		aBuilder.append(" sequenceNo: ").append(getSequenceNo());
		aBuilder.append(" type: ").append(getType());
		aBuilder.append(" ]");
		return aBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease.fw.error.IErrorCollector)
	 */
	@Override
	public void validateUsing(IErrorCollector aCollector) {
		if (getStationId() == null) {
			aCollector.register(new EaseValidationException(
					"stationId must not be null"));
		}
		super.validateUsing(aCollector);
	}
}
/**
 *  Modification History:
 *
 *  $Log: StationLocalInventoryItem.java,v $
 *  Revision 1.14  2011/09/23 22:00:33  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.13  2011/09/23 21:21:20  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.12  2011/06/29 20:42:30  mwkfh
 *  removed constructor with stationId and location
 *
 *  Revision 1.11  2011/06/17 23:40:01  mwhys
 *  Added an overloaded constructor.
 *
 *  Revision 1.10  2011/01/26 23:38:56  mwkfh
 *  setStationId to upper case
 *
 *  Revision 1.9  2010/10/14 23:27:21  mwkfh
 *  removed  deprecated constructors
 *
 *  Revision 1.8  2010/10/14 17:19:20  mwkfh
 *  updated constructors
 *
 *  Revision 1.7  2010/10/12 22:20:49  mwpxp2
 *  Added constructor/5 with type arg
 *
 *  Revision 1.6  2010/10/11 17:29:54  mwpxp2
 *  Added validation methods as per IValidatable
 *
 *  Revision 1.5  2010/10/08 01:53:11  mwpxp2
 *  Added constructor with pattern instance
 *
 *  Revision 1.4  2010/10/05 22:27:27  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.3  2010/10/05 20:39:14  mwpxp2
 *  Adjusted references to sequence types
 *
 *  Revision 1.2  2010/10/05 17:42:16  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.1  2010/09/20 21:54:35  mwkfh
 *  fixed typo in class name
 *
 *  Revision 1.1  2010/09/17 21:57:22  mwpxp2
 *  Initial
 *
 */
