package gov.ca.dmv.ease.bo.admin;

import gov.ca.dmv.ease.bo.admin.impl.Office;

import java.util.Date;

/**
 * Description: I am interface for office workdate implementations
 * File: IOfficeWorkdate.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 21, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/21 23:21:51 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IOfficeWorkdate {
	/**
	 * @return the authorizedWorkDate
	 */
	Date getAuthorizedWorkDate();

	/**
	 * @return the office
	 */
	Office getOffice();

	/**
	 * @return the status
	 */
	String getStatus();
}
/**
 *  Modification History:
 *
 *  $Log: IOfficeWorkdate.java,v $
 *  Revision 1.1  2011/10/21 23:21:51  mwpxp2
 *  Extracted from existing implementation
 *
 */
