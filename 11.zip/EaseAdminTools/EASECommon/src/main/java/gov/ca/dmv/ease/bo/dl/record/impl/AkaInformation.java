/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.dl.record.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.io.Serializable;
import java.util.Date;

/**
 * Description: The AkaInformation class is a container for response fields of possible matches from CDLIS/PDPS
 * File: AkaInformation.java
 * Module:  gov.ca.dmv.ease.bo.dl.record.impl
 * Created: Mar 16, 2010
 * 
 * @author MWVXM6
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/05/13 22:24:43 $
 * Last Changed By: $Author: mwhys $
 */
public class AkaInformation implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9178676612544189891L;
	/** The date of birth of the AKA person. */
	private Date akaBirthDate;
	/** The DL Number of the AKA person. */
	private String akaDlNumber;
	/** The Last Five Digits of DL Number of the AKA person. */
	@Deprecated
	private String akaDlNumberLastFiveDigits;
	/** The State of the AKA persons DL. */
	private String akaDlState;
	/** The AKA Name of the Person. */
	private PersonName akaName;
	/** The AKA persons Social Security number. */
	@Deprecated
	private String akaSsn;
	
	/**
	 * Instantiates a new aka information.
	 */
	public AkaInformation() {
	}
	
	/**
	 * Instantiates a new aka information.
	 *
	 * @param akaInformation the aka information
	 */
	public AkaInformation(AkaInformation akaInformation) {
		super();
		copy(akaInformation);
	}
	
	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(AkaInformation dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null person argument expected in copy constructor in "
							+ this);
		}
		//Copy Aka birthdate
		if (isNotNull(dataToCopy.getAkaBirthDate())) {
			setAkaBirthDate(new Date(dataToCopy.getAkaBirthDate().getTime()));
		}
		else {
			setAkaBirthDate(null);
		}
		//Copy Aka Dl umber
		setAkaDlNumber(dataToCopy.getAkaDlNumber());
		//Copy akaDlNumberLastFiveDigits
		setAkaDlNumberLastFiveDigits(dataToCopy.getAkaDlNumberLastFiveDigits());
		//Copy akaDlState
		setAkaDlState(dataToCopy.getAkaDlState());
		//Copy akaName
		if (isNotNull(dataToCopy.getAkaName())) {
			setAkaName(new PersonName(dataToCopy.getAkaName()));
		}
		else {
			setAkaName(null);
		}
		//Copy akaSsn
		setAkaSsn(dataToCopy.getAkaSsn());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((akaBirthDate == null) ? 0 : akaBirthDate.hashCode());
		result = prime * result
				+ ((akaDlNumber == null) ? 0 : akaDlNumber.hashCode());
		result = prime
				* result
				+ ((akaDlNumberLastFiveDigits == null) ? 0
						: akaDlNumberLastFiveDigits.hashCode());
		result = prime * result
				+ ((akaDlState == null) ? 0 : akaDlState.hashCode());
		result = prime * result + ((akaName == null) ? 0 : akaName.hashCode());
		result = prime * result + ((akaSsn == null) ? 0 : akaSsn.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AkaInformation other = (AkaInformation) obj;
		if (akaBirthDate == null) {
			if (other.akaBirthDate != null)
				return false;
		}
		else if (!akaBirthDate.equals(other.akaBirthDate))
			return false;
		if (akaDlNumber == null) {
			if (other.akaDlNumber != null)
				return false;
		}
		else if (!akaDlNumber.equals(other.akaDlNumber))
			return false;
		if (akaDlNumberLastFiveDigits == null) {
			if (other.akaDlNumberLastFiveDigits != null)
				return false;
		}
		else if (!akaDlNumberLastFiveDigits
				.equals(other.akaDlNumberLastFiveDigits))
			return false;
		if (akaDlState == null) {
			if (other.akaDlState != null)
				return false;
		}
		else if (!akaDlState.equals(other.akaDlState))
			return false;
		if (akaName == null) {
			if (other.akaName != null)
				return false;
		}
		else if (!akaName.equals(other.akaName))
			return false;
		if (akaSsn == null) {
			if (other.akaSsn != null)
				return false;
		}
		else if (!akaSsn.equals(other.akaSsn))
			return false;
		return true;
	}
	
	/**
	 * Simple setter for aka birth date.
	 * @return birth date of aka person
	 */
	public Date getAkaBirthDate() {
		return akaBirthDate;
	}
	
	/**
	 * Gets the aka dl number.
	 * 
	 * @return the akaDlNumber
	 */
	public String getAkaDlNumber() {
		return akaDlNumber;
	}
	
	/**
	 * Gets the aka dl number last five digits.
	 * 
	 * @return the aka dl number last five digits
	 * @deprecated
	 */
	@Deprecated
	public String getAkaDlNumberLastFiveDigits() {
		return akaDlNumberLastFiveDigits;
	}
	
	/**
	 * Gets the aka dl state.
	 * 
	 * @return the akaDlState
	 */
	public String getAkaDlState() {
		return akaDlState;
	}
	
	/**
	 * Gets the aka name.
	 * 
	 * @return the akaName
	 */
	public PersonName getAkaName() {
		return akaName;
	}
	
	/**
	 * Gets the aka ssn.
	 * 
	 * @return the akaSsn
	 * @deprecated
	 */
	@Deprecated
	public String getAkaSsn() {
		return akaSsn;
	}
	
	/**
	 * Simple getter for aka birth date.
	 * @param akaBirthDate  birth date of aka person
	 */
	public void setAkaBirthDate(Date akaBirthDate) {
		this.akaBirthDate = akaBirthDate;
	}
	
	/**
	 * Sets the aka dl number.
	 * 
	 * @param akaDlNumber the akaDlNumber to set
	 */
	public void setAkaDlNumber(String akaDlNumber) {
		this.akaDlNumber = akaDlNumber;
	}
	
	/**
	 * Sets the aka dl number last five digits.
	 * 
	 * @param akaDlNumberLastFiveDigits the new aka dl number last five digits
	 * @deprecated
	 */
	@Deprecated
	public void setAkaDlNumberLastFiveDigits(String akaDlNumberLastFiveDigits) {
		this.akaDlNumberLastFiveDigits = akaDlNumberLastFiveDigits;
	}
	
	/**
	 * Sets the aka dl state.
	 * 
	 * @param akaDlState the akaDlState to set
	 */
	public void setAkaDlState(String akaDlState) {
		this.akaDlState = akaDlState;
	}
	
	/**
	 * Sets the aka name.
	 * 
	 * @param akaName the akaName to set
	 */
	public void setAkaName(PersonName akaName) {
		this.akaName = akaName;
	}
	
	/**
	 * Sets the aka ssn.
	 * 
	 * @param akaSsn the akaSsn to set
	 * @deprecated
	 */
	@Deprecated
	public void setAkaSsn(String akaSsn) {
		this.akaSsn = akaSsn;
	}
}
/**
 * Modification History:
 * 
 * $Log: AkaInformation.java,v $
 * Revision 1.4  2011/05/13 22:24:43  mwhys
 * Fixed defect TRN 698. Added copy constructor.
 *
 *
 */
