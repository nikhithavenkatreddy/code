/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.List;

/**
 * Description: I am request to find out the count of available items of a given type for a given location
 * File: GetCurrentItemCountRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/20 23:19:30 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class GetCurrentItemCountRequest extends AbstractInventoryStateRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5898678582651164691L;

	/**
	 * Instantiates a new gets the current item count request.
	 */
	protected GetCurrentItemCountRequest() {
		super();
	}

	/**
	 * @param context
	 */
	protected GetCurrentItemCountRequest(IUserContext context) {
		super(context);
	}

	/**
	 * @param context
	 * @param thresholdList
	 */
	public GetCurrentItemCountRequest(IUserContext context,
			List <IItemThreshold> thresholdList) {
		super(context, thresholdList);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	@Override
	public IInventoryStatusRequestResponse execute() {
		return getService().execute(this);
	}
}
/**
 *  Modification History:
 *
 *  $Log: GetCurrentItemCountRequest.java,v $
 *  Revision 1.2  2010/09/20 23:19:30  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/20 18:30:19  mwpxp2
 *  Initial
 *
 */
