/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.locator;

/**
 * Description: Enumeration of non address types.
 * 
 * File: NonAddressType.java
 * Module:  gov.ca.dmv.ease.bo.locator
 * Created: Apr 14, 2010 
 * @author MWUXB  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/07/22 17:50:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum NonAddressType {
	/** The COMPANY_PHONE. */
	COMPANY_PHONE,
	/** The HOME_EMAIL. */
	HOME_EMAIL,
	/** The HOME_FAX. */
	HOME_FAX,
	/** The HOME_PHONE. */
	HOME_PHONE
}
/**
 *  Modification History:
 * 
 *  $Log: NonAddressType.java,v $
 *  Revision 1.3  2010/07/22 17:50:32  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/05/18 03:50:47  mwuxb
 *  Updated
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/04/15 01:11:23  mwuxb
 *  Initial Commit
 *
*/
