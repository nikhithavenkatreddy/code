/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.testresult.CommercialTestResultCode;
import gov.ca.dmv.ease.bo.license.testresult.CommercialTestResultType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.util.Date;

/**
 * Description: This class represents a commercial test result
 * File: CommercialTestResult.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult.impl
 * Created: Jan 6, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.8 $
 * Last Changed: $Date: 2012/08/15 16:23:22 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class CommercialTestResult extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7933550243590534417L;
	/** Holds Commercial Test Result Type */
	private CommercialTestResultType commercialTestResultType;
	/** Holds Examiner's Id. */
	private String examinerId;
	/** Holds Driver License Class of Pre Trip Test. */
	private CodeSetElement licenseClassCode;
	/** Holds Test Result Code. */
	private CodeSetElement testResultCode;
	/** Holds Drive Test Date. To derive the Failure Date the testResultCode will be "F" . */
	private Date testResultDate;
	
	/**
	 * Overridden Constructor.
	 * 
	 * @param driveTestType Drive Test Type
	 */
	public CommercialTestResult(
			CommercialTestResultType commercialTestResultType) {
		this.commercialTestResultType = commercialTestResultType;
	}
	
	/**
	 * Overridden Constructor.
	 * 
	 * @param driveTestType Drive Test Type
	 */
	public CommercialTestResult(String commercialTestResultType) {
		this.commercialTestResultType = CommercialTestResultType
				.valueOf(commercialTestResultType);
	}
	
	/**
	 * @param commercialTestResult
	 */
	public CommercialTestResult(CommercialTestResult objectToCopy) {
		super();
		copy(objectToCopy);
	}
	
	/**
	 * @param commercialTestResult
	 */
	protected void copy(CommercialTestResult objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null CommercialTestResult argument expected in copy method in "
							+ this);
		}
		super.copy(objectToCopy);
		if (isNotNull(objectToCopy.getCommercialTestResultType())) {
			setCommercialTestResultType(objectToCopy
					.getCommercialTestResultType());
		}
		else {
			setCommercialTestResultType(null);
		}
		if (isNotNull(objectToCopy.getLicenseClassCode())) {
			setLicenseClassCode(new CodeSetElement(objectToCopy
					.getLicenseClassCode()));
		}
		else {
			setLicenseClassCode(null);
		}
		if (isNotNull(objectToCopy.getExaminerId())) {
			setExaminerId(objectToCopy.getExaminerId());
		}
		else {
			setExaminerId(null);
		}
		if (isNotNull(objectToCopy.getTestResultCode())) {
			setTestResultCode(new CodeSetElement(objectToCopy
					.getTestResultCode()));
		}
		else {
			setTestResultCode(null);
		}
		if (isNotNull(objectToCopy.getTestResultDate())) {
			setTestResultDate(new Date(objectToCopy.getTestResultDate()
					.getTime()));
		}
		else {
			setTestResultDate(null);
		}
	}
	
	/**
	 * Gets the Pre Trip Test Result.
	 * 
	 * @return the preTripTestResultType
	 */
	public CommercialTestResultType getCommercialTestResultType() {
		return commercialTestResultType;
	}
	
	/**
	 * @param commercialTestResultType the commercialTestResultType to set
	 */
	public void setCommercialTestResultType(
			CommercialTestResultType commercialTestResultType) {
		this.commercialTestResultType = commercialTestResultType;
	}
	
	/**
	 * Gets the Examiner Id.
	 * 
	 * @return the examinerID
	 */
	public String getExaminerId() {
		return examinerId;
	}
	
	/**
	 * Gets the Driver License Class.
	 * 
	 * @return the licenseClassCode
	 */
	public CodeSetElement getLicenseClassCode() {
		return licenseClassCode;
	}
	
	/**
	 * Gets the Test Failure Date.
	 * 
	 * @return the testFailureDate
	 */
	public Date getTestFailureDate() {
		if (getTestResultCode() != null
				&& getTestResultCode().getCode().equalsIgnoreCase(
						CommercialTestResultCode.Failed.getCodeName())) {
			return testResultDate;
		}
		return null;
	}
	
	/**
	 * Gets the Pre Trip Test Result Code.
	 * 
	 * @return the testResultCode
	 */
	public CodeSetElement getTestResultCode() {
		return testResultCode;
	}
	
	public Date getTestResultDate() {
		return testResultDate;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommercialTestResult other = (CommercialTestResult) obj;
		if (commercialTestResultType == null) {
			if (other.commercialTestResultType != null)
				return false;
		}
		else if (!commercialTestResultType
				.equals(other.commercialTestResultType))
			return false;
		if (examinerId == null) {
			if (other.examinerId != null)
				return false;
		}
		else if (!examinerId.equals(other.examinerId))
			return false;
		if (licenseClassCode == null) {
			if (other.licenseClassCode != null)
				return false;
		}
		else if (!licenseClassCode.equals(other.licenseClassCode))
			return false;
		if (testResultCode == null) {
			if (other.testResultCode != null)
				return false;
		}
		else if (!testResultCode.equals(other.testResultCode))
			return false;
		if (testResultDate == null) {
			if (other.testResultDate != null)
				return false;
		}
		else if (!testResultDate.equals(other.testResultDate))
			return false;
		return true;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((commercialTestResultType == null) ? 0
						: commercialTestResultType.hashCode());
		result = prime * result
				+ ((examinerId == null) ? 0 : examinerId.hashCode());
		result = prime
				* result
				+ ((licenseClassCode == null) ? 0 : licenseClassCode.hashCode());
		result = prime * result
				+ ((testResultCode == null) ? 0 : testResultCode.hashCode());
		result = prime * result
				+ ((testResultDate == null) ? 0 : testResultDate.hashCode());
		return result;
	}

	/**
	 * Sets the Examiner Id.
	 * 
	 * @param examinerId the examinerId to set
	 */
	public void setExaminerId(String examinerId) {
		this.examinerId = examinerId;
	}
	
	/**
	 * Sets the Driver License Class.
	 * 
	 * @param licenseClassCode the licenseClassCode to set
	 */
	public void setLicenseClassCode(CodeSetElement driverLicenseClass) {
		this.licenseClassCode = driverLicenseClass;
	}
	
	/**
	 * Sets the Test Failure Date.
	 * 
	 * @param examinerId the testFailureDate to set
	 */
	public void setTestFailureDate(Date testFailureDate) {
		/** For the Failure Date the application will set testResultCode to "F" . */
		this.testResultDate = testFailureDate;
	}
	
	/**
	 * Sets the Test Result Code.
	 * 
	 * @param testResultCode the testResultCode to set
	 */
	public void setTestResultCode(CodeSetElement testResult) {
		this.testResultCode = testResult;
	}
	
	public void setTestResultDate(Date testResultDate) {
		this.testResultDate = testResultDate;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("commercialTestResultType", commercialTestResultType,
				anIndent, aBuilder);
		outputKeyValue("examinerID", examinerId, anIndent, aBuilder);
		outputKeyValue("licenseClassCode", licenseClassCode, anIndent, aBuilder);
		outputKeyValue("testResultDate", testResultDate, anIndent, aBuilder);
		outputKeyValue("testResultCode", testResultCode, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CommercialTestResult.java,v $
 *  Revision 1.8  2012/08/15 16:23:22  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.7  2011/04/07 04:04:55  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.6.10.8  2011/04/06 00:51:28  mwhys
 *  Updated copy to call super.
 *
 *  Revision 1.6.10.7  2011/04/05 20:02:50  mwhys
 *  Updated copy method.
 *
 *  Revision 1.6.10.6  2011/04/05 19:01:26  mwark
 *  Updated the exception message.
 *
 *  Revision 1.6.10.5  2011/04/05 19:00:06  mwark
 *  Modified the copy constructor and moved teh equals method from the beginning of the class to the hashcode method place.
 *
 *  Revision 1.6.10.4  2011/04/03 20:38:23  mwrka1
 *  updated for cloning
 *
 *  Revision 1.6.10.3  2011/04/03 19:49:46  mwrka1
 *  modified varible name
 *
 *  Revision 1.6.10.2  2011/04/03 19:27:28  mwrka1
 *  updated modifier
 *
 *  Revision 1.6.10.1  2011/04/03 19:23:58  mwrka1
 *  added copy constructor
 *
 *  Revision 1.6  2010/12/24 22:07:54  mwrka1
 *  EQUALS AND HASCODE UPDATED
 *
 *  Revision 1.5  2010/12/07 22:11:40  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 03:57:52  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.3  2010/08/12 17:19:54  mwvxm6
 *  Updated failure date to testResultDate. The failure date is now derived based on result code.
 *
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.6  2010/03/18 20:33:33  mwrsk
 *  Change  driverLicenseClass to CodeSetElement
 *
 *  Revision 1.5  2010/02/26 01:07:24  mwvxm6
 *  Removed default constructor
 *
 *  Revision 1.4  2010/02/25 23:57:44  mwvxm6
 *  Updated a new constructor to accept a string and derive type code
 *
 *  Revision 1.3  2010/01/29 15:19:41  mwrsk
 *  renamed testResult to include "Code" suffix
 *
 *  Revision 1.2  2010/01/28 22:48:56  mwrsk
 *  Added missing import statement
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
 *  Revision 1.4  2010/01/08 03:25:02  mwrsk
 *  refactor names
 *
 *  Revision 1.3  2010/01/08 03:19:22  mwrsk
 *  Keep it consistent with DriveAndLawtest
 *
 *  Revision 1.2  2010/01/07 23:32:29  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.1  2010/01/07 18:29:48  mwhxa2
 *  Domain Model changes - Draft 1
 *
*/
