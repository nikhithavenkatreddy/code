/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.tx;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.bo.tx.impl.LicenseType;
import gov.ca.dmv.ease.bo.tx.impl.TransactionStatus;

import java.sql.Blob;
import java.util.Date;

/**
 * Description: I define the interface for the transaction to be used
 * by the application
 *
 * File: ITransaction.java
 * Module:  gov.ca.dmv.ease.bo.tx
 * Created: Mar 26, 2010
 *
 * @author MWRSK
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2012/08/16 20:03:19 $
 * Last Changed By: $Author: mwhys $
 */
public interface ITransaction {
	/**
	 * Gets the DL application.
	 *
	 * @return the DL application
	 */
	Application getApplication();
	
	/**
	 * Gets the birth date.
	 *
	 * @return the birthDate
	 */
	Date getBirthDate();
	
	/**
	 * Gets the cna status.
	 *
	 * @return the cnaStatus
	 */
	String getCnaStatus();
	
	/**
	 * Gets the employee.
	 *
	 * @return the employee
	 */
	String getEmployeeId();
	
	/**
	 * Gets the license name.
	 *
	 * @return the licenseName
	 */
	String getLicenseName();
	
	/**
	 * Gets the license number.
	 *
	 * @return the licenseNumber
	 */
	String getLicenseNumber();
	
	/**
	 * Gets the license type.
	 *
	 * @return the licenseType
	 */
	LicenseType getLicenseType();
	
	/**
	 * Gets the office.
	 *
	 * @return the office
	 */
	String getOfficeId();
	
	/**
	 * Gets the station.
	 *
	 * @return the station
	 */
	String getStationId();
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	TransactionStatus getStatus();
	
	/**
	 * Gets the transaction data.
	 *
	 * @return the transaction data
	 */
	Blob getTransactionData();
	
	/**
	 * Gets the sequence number.
	 *
	 * @return the sequence number
	 */
	Integer getTransactionIdentifier();
	
	/**
	 * Gets the type transaction code.
	 *
	 * @return the type transaction code
	 */
	String getTypeTransactionCode();
	
	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	boolean isEmpty();
}
/**
 *  Modification History:
 *
 *  $Log: ITransaction.java,v $
 *  Revision 1.7  2012/08/16 20:03:19  mwhys
 *  Added getStatus(). (Defect 7150)
 *
 *  Revision 1.6  2011/01/23 21:39:25  mwpxp2
 *  Added getTypeTransactionCode/0 already present in the implementation
 *
 *  Revision 1.5  2011/01/05 22:28:53  mwtjc1
 *  isEmpty added
 *
 *  Revision 1.4  2010/08/27 17:35:55  mwyxg1
 *  change getDlApplication to getApplicaton
 *
 *  Revision 1.3  2010/07/22 17:50:33  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.2  2010/06/29 23:30:45  mwcsj3
 *  Deleted  getTypeTransactionCode method
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.4  2010/04/07 17:51:58  mwvxm6
 *  Changed the type of attribute birthDate to Date
 *
 *  Revision 1.3  2010/04/02 01:24:28  mwvxm6
 *  Moved ControlCashierSeqNumber to userContext from transaction
 *
 *  Revision 1.2  2010/03/29 17:08:23  mwhxa2
 *  Changing LicenseTypeCode to LicenseType
 *
 *  Revision 1.1  2010/03/26 18:17:22  mwrsk
 *  Added ITransaction interface
 *
*/
