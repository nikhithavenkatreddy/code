/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

import gov.ca.dmv.ease.fw.exception.impl.OperationFailedException;

/**
 * Description: I am exception to be used for failures in processing of sequences
 * File: SequenceProcessingException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Sep 3, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/03 18:40:03 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SequenceProcessingException extends OperationFailedException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3943744608314217530L;

	/**
	 * Instantiates a new sequence processing exception.
	 */
	public SequenceProcessingException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public SequenceProcessingException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public SequenceProcessingException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public SequenceProcessingException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequenceProcessingException.java,v $
 *  Revision 1.1  2010/09/03 18:40:03  mwpxp2
 *  Initial
 *
 */
