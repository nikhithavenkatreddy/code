/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class captures information pertaining to the receipt payment for Special Certificates.
 * These include Special Certificates like ambulance driver certificate (ambulance certificate)
 * and Hazardous Agricultural Materials/Waste Transportation Verification of Training (HAM)
 * File: SpecialCertificateApplication.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.14 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class SpecialCertificateApplication extends Application {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5383930105731073086L;
	/** This represents the certificate App Number */
	private String certificateApplicatioNumber;
	/** This represents if Duplicate Special Certificate */
	private Boolean isDuplicateSpecialCertificate = Boolean.FALSE;
	/** This represents if a valid outOfStateDl is presented */
	private Boolean isOutOfStateDl = Boolean.FALSE;
	/** typeCertificate Code. E - Ambulance Driver etc..*/
	private CodeSetElement typeCertificateCode;
	/** Prints Required*/
	private Boolean printsReq;
	/** Is Original Application */
	private Boolean isOriginalApplication = Boolean.TRUE;

	/**
	 * Instantiates a new application.
	 */
	public SpecialCertificateApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the certificateApplicatioNumber
	 */
	public String getCertificateApplicatioNumber() {
		return certificateApplicatioNumber;
	}

	/**
	 * @return the typeCertificateCode
	 */
	public CodeSetElement getTypeCertificateCode() {
		return typeCertificateCode;
	}

	/**
	 * @return the isDuplicateSpecialCertificate
	 */
	public Boolean isDuplicateSpecialCertificate() {
		return isDuplicateSpecialCertificate;
	}

	/**
	 * @return the isOutOfStateDl
	 */
	public Boolean isOutOfStateDl() {
		return isOutOfStateDl;
	}

	/**
	 * @param certificateApplicatioNumber the certificateApplicatioNumber to set
	 */
	public void setCertificateApplicatioNumber(
			String certificateApplicatioNumber) {
		this.certificateApplicatioNumber = certificateApplicatioNumber;
	}

	/**
	 * @param isDuplicateSpecialCertificate the isDuplicateSpecialCertificate to set
	 */
	public void setDuplicateSpecialCertificate(
			Boolean isDuplicateSpecialCertificate) {
		this.isDuplicateSpecialCertificate = isDuplicateSpecialCertificate;
	}

	/**
	 * @param isOutOfStateDl the isOutOfStateDl to set
	 */
	public void setOutOfStateDl(Boolean isOutOfStateDl) {
		this.isOutOfStateDl = isOutOfStateDl;
	}

	/**
	 * @param typeCertificateCode the typeCertificateCode to set
	 */
	public void setTypeCertificateCode(CodeSetElement typeCertificateCode) {
		this.typeCertificateCode = typeCertificateCode;
	}

	/**
	 * @param printsReq the printsReq to set
	 */
	public void setPrintsReq(Boolean printsReq) {
		this.printsReq = printsReq;
	}

	/**
	 * @return the printsReq
	 */
	public Boolean getPrintsReq() {
		return printsReq;
	}

	/**
	 * @param isOriginalApplication the isOriginalApplication to set
	 */
	public void setIsOriginalApplication(Boolean isOriginalApplication) {
		this.isOriginalApplication = isOriginalApplication;
	}

	/**
	 * @return the isOriginalApplication
	 */
	public Boolean isOriginalApplication() {
		return isOriginalApplication;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SpecialCertificateApplication.java,v $
 *  Revision 1.14  2012/03/14 01:57:55  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.13  2011/02/12 23:25:36  mwhys
 *  Removed the default value of printsReq to fix issues with fees.
 *  Defect 4991.
 *
 *  Revision 1.12  2011/02/11 00:00:24  mwhys
 *  Committing on behalf of Rajan (mwrrv2) for fixing 06M fees. Fix for defect 4920.
 *
 *  Revision 1.11  2011/01/29 22:51:55  mwrrv2
 *  Initializing isFeeRequired to true in the constructor.
 *
 *  Revision 1.10  2011/01/07 19:27:05  mwrrv3
 *  PRINTS REQ Field populates default value set as Y -- Amar Bade
 *
 *  Revision 1.9  2010/12/16 18:30:46  mwtjc1
 *  printsReq is initialized to false
 *
 *  Revision 1.8  2010/10/26 00:30:11  mwrrv3
 *  Added new attribute printsReq.
 *
 */
