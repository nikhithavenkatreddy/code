/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: SocialSecurityDocument is the subclass of IdentifyingDocument 
 * and encapsulates the attributes in a social security document.
 * File: SocialSecurityDocument.java
 * Module:  gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/04/07 04:04:57 $
 * Last Changed By: $Author: mwhys $
 */
public class SocialSecurityDocument extends AbstractSupportingDocument {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6657546939349402702L;
	/** The social security number. */
	private String ssn;
	/** SSN Service Verification code from the ssn inquiry response */
	private CodeSetElement ssnServiceVerificationCode;
	
	/** Default Constructor */
	public SocialSecurityDocument() {
	}
	
	/**
	 * Copy constructor
	 * 
	 */
	public SocialSecurityDocument(SocialSecurityDocument socialSecurityDocument) {
		super();
		copy(socialSecurityDocument);
	}
	
	/**
	 * Copy.
	 *
	 * @param document the document
	 */
	protected void copy(SocialSecurityDocument socialSecurityDocument) {
		if (socialSecurityDocument == null) {
			throw new EaseValidationException(
					"non-null socialSecurityDocument argument expected in copy method in "
							+ this);
		}
		super.copy(socialSecurityDocument);
		// SSN
		setSsn(socialSecurityDocument.getSsn());
		//ssnServiceVerificationCode
		if (EaseUtil.isNotNull(socialSecurityDocument
				.getSsnServiceVerificationCode())) {
			setSsnServiceVerificationCode(new CodeSetElement(
					socialSecurityDocument.getSsnServiceVerificationCode()));
		}
		else {
			setSsnServiceVerificationCode(null);
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SocialSecurityDocument other = (SocialSecurityDocument) obj;
		if (ssn == null) {
			if (other.ssn != null) {
				return false;
			}
		}
		else if (!ssn.equals(other.ssn)) {
			return false;
		}
		if (ssnServiceVerificationCode == null) {
			if (other.ssnServiceVerificationCode != null) {
				return false;
			}
		}
		else if (!ssnServiceVerificationCode
				.equals(other.ssnServiceVerificationCode)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the social security number.
	 * 
	 * @return the ssnNumber
	 */
	public String getSsn() {
		return ssn;
	}
	
	/**
	 * Gets the social security number verification code.
	 * 
	 * @return the ssnVerificationCode
	 */
	public CodeSetElement getSsnServiceVerificationCode() {
		return ssnServiceVerificationCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((ssn == null) ? 0 : ssn.hashCode());
		result = prime
				* result
				+ ((ssnServiceVerificationCode == null) ? 0
						: ssnServiceVerificationCode.hashCode());
		return result;
	}
	
	/**
	 * Sets the social security number.
	 * 
	 * @param ssn the social security number
	 */
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
	/**
	 * Sets the social security number verification code.
	 * 
	 * @param ssnVerificationCode the ssnVerificationCode to set
	 */
	public void setSsnServiceVerificationCode(CodeSetElement ssnVerificationCode) {
		this.ssnServiceVerificationCode = ssnVerificationCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.document.impl.Document#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("ssn", ssn, anIndent, aBuilder);
		outputKeyValue("ssnServiceVerificationCode",
				ssnServiceVerificationCode, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SocialSecurityDocument.java,v $
 *  Revision 1.7  2011/04/07 04:04:57  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.6.6.3  2011/04/05 22:27:17  mwhys
 *  Updated.
 *
 *  Revision 1.6.6.2  2011/04/05 19:01:43  mwhys
 *  Moved the code that throws exception from copy-constructor to copy-method.
 *
 *  Revision 1.6  2011/01/17 01:19:23  mwpxp2
 *  Adjusted super name after rename
 *
 *  Revision 1.5  2010/12/07 22:08:35  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.4  2010/12/07 02:42:34  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.3  2010/09/13 04:40:27  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.8  2010/03/03 18:51:28  mwvxm6
 *  Updated attribute name to SsnServiceVerificationCode, and updated user verification code for Bdlp and Ssn verification
 *
 *  Revision 1.7  2010/03/03 16:07:17  mwrsk
 *  Remove isValid
 *
 *  Revision 1.6  2010/03/03 16:03:54  mwrsk
 *  Remove isValid
 *
 *  Revision 1.5  2010/02/08 22:05:53  mwrsk
 *  Remove DocumentType Changes
 *
 *  Revision 1.4  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.3  2010/01/11 21:26:07  mwhxa2
 *  Added Document Type as Enum
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.20  2009/10/15 22:22:12  mwcsj3
 *  Fixed to do's
 *
 *  Revision 1.19  2009/10/13 18:53:59  mwtjc1
 *  getValidator method is made public
 *
 *  Revision 1.18  2009/10/03 21:06:31  mwpxp2
 *  Adjusted imports for fw refactorings; bulk cleanup
 *
 *  Revision 1.17  2009/09/29 22:06:28  mwhxa2
 *  Extends BaseBusinessObject
 *
 *  Revision 1.16  2009/09/13 20:45:36  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.15.2.1  2009/09/12 19:08:48  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.15  2009/08/27 05:39:49  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.14  2009/08/22 23:19:33  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.13  2009/08/17 14:57:34  mwbxp5
 *  Removed SSN verification number.
 *
 *  Revision 1.12  2009/08/12 20:54:33  mwcsj3
 *  Set isValidate to false
 *
 *  Revision 1.11  2009/08/11 17:36:06  mwrrv3
 *  Refactored and moved CommonFixtureFactory from src/java/test to sre/main/java fixture impl package.
 *
 *  Revision 1.10  2009/08/08 20:52:26  mwrrv3
 *  Changed data type String to CodeSetElement.
 *
 *  Revision 1.9  2009/08/05 05:05:46  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.8  2009/08/05 01:35:01  mwcsj3
 *  SsnVerificationCode data type set to string
 *
 *  Revision 1.7  2009/08/04 16:34:44  mwyxg1
 *  add super()
 *
 *  Revision 1.6  2009/08/04 16:22:15  mwyxg1
 *  initiate attributes in constructor
 *
 *  Revision 1.5  2009/07/30 01:48:52  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.4  2009/07/23 17:54:58  mwrrv3
 *  Added class comments and removed name attribute.
 *
 *  Revision 1.3  2009/07/20 22:41:14  mwrrv3
 *  Added two new isValidated and isValid attributes to the social security document.
 *
 *  Revision 1.2  2009/07/14 23:44:33  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
