/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license;

/**
 * Description: Enumeration to determine the types of Interim Permits
 * 
 * File: InterimPermitType.java
 * Module:  gov.ca.dmv.ease.bo.license
 * Created: Feb 18, 2010 
 * @author MWRSK  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:31 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum InterimPermitType {
	INSTRUCTION_PERMIT, TEMPORARY
}
/**
 *  Modification History:
 * 
 *  $Log: InterimPermitType.java,v $
 *  Revision 1.2  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.1  2010/02/19 03:10:35  mwrsk
 *  Added InterimPermit changes
 *
*/
