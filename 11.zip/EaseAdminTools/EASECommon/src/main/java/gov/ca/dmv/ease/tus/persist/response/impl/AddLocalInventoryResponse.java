/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response to adding local inventory items.
 * File: AddLocalInventoryResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Jun 8, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/06/08 17:33:31 $
 * Last Changed By: $Author: mwkfh $
 */
public class AddLocalInventoryResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -960180895917614633L;

	/**
	 * Instantiates a new add business object response.
	 * 
	 */
	protected AddLocalInventoryResponse() {
		super();
	}

	/**
	 * Instantiates a new add business object response.
	 * 
	 * @param ex
	 */
	public AddLocalInventoryResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new add business object response.
	 * 
	 * @param ex the ex
	 */
	public AddLocalInventoryResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new add business object response.
	 * 
	 * @param collector
	 */
	public AddLocalInventoryResponse(IErrorCollector collector) {
		super(collector);
	}

	/**
	 * Instantiates a new add business object response.
	 * 
	 * @param collector
	 * @param aCount
	 */
	public AddLocalInventoryResponse(IErrorCollector collector, int aCount) {
		super(collector);
		setAffectedItemsCount(aCount);
	}

	/**
	 * Instantiates a new add business object response.
	 * 
	 * @param aCount
	 */
	public AddLocalInventoryResponse(int aCount) {
		super();
		setAffectedItemsCount(aCount);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AddLocalInventoryResponse.java,v $
 *  Revision 1.1  2011/06/08 17:33:31  mwkfh
 *  added AddLocalInventoryRequest
 *
 */
