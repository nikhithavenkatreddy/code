/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.subject.impl.CustomerOrganization;

import java.util.Date;

/** 
 * Description: This represents the DrivingSchoolInstructor License and it extends License 
 * and inherits the properties from License class.
 * File: DrivingSchoolInstructorLicense.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 7, 2010
 * @author mwvxm6
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/12/07 22:08:54 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DrivingSchoolInstructorLicense extends License {
	private static final long serialVersionUID = -8710409333923968119L;
	/** The driving School details. 
	 * CustomerOrganization attribute customerTypeCode is set to drivingSchool*/
	private CustomerOrganization employerDrivingSchool;
	/** The employment Start Date (or fee paid?) of the license holder. */
	private Date employmentStartDate;

	/**
	 * @return the employerDrivingSchool
	 */
	public CustomerOrganization getEmployerDrivingSchool() {
		return employerDrivingSchool;
	}

	/**
	 * The Employers License Number. 
	 * @return the employersLicenseNumber
	 */
	public String getEmployersLicenseNumber() {
		return getEmployerDrivingSchool().getLicenseNumber();
	}

	/**
	 * @return the employmentStartDate
	 */
	public Date getEmploymentStartDate() {
		return employmentStartDate;
	}

	/**
	 * @param employerDrivingSchool the employerDrivingSchool to set
	 */
	public void setEmployerDrivingSchool(
			CustomerOrganization employerDrivingSchool) {
		this.employerDrivingSchool = employerDrivingSchool;
	}

	/**
	 * @param employmentStartDate the employmentStartDate to set
	 */
	public void setEmploymentStartDate(Date employmentStartDate) {
		this.employmentStartDate = employmentStartDate;
	}

	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("employerDrivingSchool", employerDrivingSchool,
				anIndent, aBuilder);
		outputKeyValue("employmentStartDate", employmentStartDate, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}