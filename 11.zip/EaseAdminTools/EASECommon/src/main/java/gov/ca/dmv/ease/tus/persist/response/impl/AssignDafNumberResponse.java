/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.tx.ITransaction;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the persistence response for AssignDafNumber
 * File: AssignDafNumberResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Dec 17, 2010
 * 
 * @author MWYXG1
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/01/13 22:36:17 $
 * Last Changed By: $Author: mwtjc1 $
 */
public class AssignDafNumberResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4369686093023545376L;
	/** The transaction. */
	private ITransaction transaction;
	/** The allocated daf number. */
	private int allocatedDafNumber;

	/**
	 * Default constructor.
	 * 
	 * @param transaction the transaction
	 * @deprecated
	 */
	public AssignDafNumberResponse(ITransaction transaction) {
		super();
		setTransaction(transaction);
	}

	/**
	 * Default constructor.
	 * 
	 * @param allocatedDafNumber the allocated daf number
	 */
	public AssignDafNumberResponse(int allocatedDafNumber) {
		super();
		setAllocatedDafNumber(allocatedDafNumber);
	}

	/**
	 * The Constructor.
	 * 
	 * @param ex the ex
	 */
	public AssignDafNumberResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param ex the ex
	 */
	public AssignDafNumberResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param errorCollector the error collector
	 */
	public AssignDafNumberResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 * @deprecated
	 */
	public ITransaction getTransaction() {
		return transaction;
	}

	/**
	 * Sets the transaction.
	 * 
	 * @param transaction the transaction to set
	 */
	private void setTransaction(ITransaction transaction) {
		this.transaction = transaction;
	}

	/**
	 * Gets the allocated daf number.
	 * 
	 * @return the allocated daf number
	 */
	public int getAllocatedDafNumber() {
		return allocatedDafNumber;
	}

	/**
	 * Sets the allocated daf number.
	 * 
	 * @param allocatedDafNumber the new allocated daf number
	 */
	private void setAllocatedDafNumber(int allocatedDafNumber) {
		this.allocatedDafNumber = allocatedDafNumber;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AssignDafNumberResponse.java,v $
 *  Revision 1.5  2011/01/13 22:36:17  mwtjc1
 *  getTransaction deprecated
 *
 *  Revision 1.4  2011/01/13 22:35:23  mwtjc1
 *  AssignDafNumberResponse(ITransaction transaction) deprecated
 *
 *  Revision 1.3  2011/01/13 22:35:00  mwtjc1
 *  allocatedDafNumber added
 *
 *  Revision 1.2  2010/12/21 16:43:56  mwyxg1
 *  change constructor
 *
 *  Revision 1.1  2010/12/17 23:01:03  mwyxg1
 *  add new
 *
 */
