/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.document.impl.Application;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.AssignDafNumberResponse;
import gov.ca.dmv.ease.tus.persist.service.ITransactionPersistenceService;

/**
 * Description: I represent the request to retrieve object from the persistent store
 * File: AssignDafNumberRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 17, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/12/23 06:18:22 $
 * Last Changed By: $Author: mwkkc $
 */
public class AssignDafNumberRequest extends PersistenceServiceRequest {
	private static final long serialVersionUID = 1759593206330372926L;
	private Application application;

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public AssignDafNumberResponse execute() {
		return ((ITransactionPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Instantiates a new issue local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public AssignDafNumberRequest(IUserContext userContext,
			Application application) {
		super(userContext);
		this.application = application;
	}

	/**
	 * Gets the application
	 *
	 * @return the application
	 */
	public Application getApplication() {
		return application;
	}

	/**
	 * Sets the application
	 *
	 * @param application the application to set
	 */
	public void setApplication(Application application) {
		this.application = application;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AssignDafNumberRequest.java,v $
 *  Revision 1.4  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.1.4.1  2010/12/23 03:13:56  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.3  2010/12/22 17:34:01  mwyxg1
 *  add application
 *
 *  Revision 1.2  2010/12/21 16:53:37  mwyxg1
 *  remove transaction
 *
 *  Revision 1.1  2010/12/17 23:19:54  mwyxg1
 *  add new
 *
 */
