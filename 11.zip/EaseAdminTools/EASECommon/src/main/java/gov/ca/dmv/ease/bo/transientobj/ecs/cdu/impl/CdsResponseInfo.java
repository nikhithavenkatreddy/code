/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl;

import gov.ca.dmv.ease.bo.dl.record.impl.DrivingRecord;

/**
 * Description: The purpose of this class is to encapsulate the CDS response for the CDLIS and PDPS information
 * File: $ CdsResponseInfo.java $
 * Module:  gov.ca.dmv.ease.bo.transientobj.ecs.cdu.impl
 * Created: Mar 16, 2011
 * @author MWHYS  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2012/08/14 20:46:58 $
 * Last Changed By: $ MWHYS $
 */
public class CdsResponseInfo {
	/** The SOI header field. */
	private String soiHeaderField;
	/** The message type. */
	private String messageType;
	/** The error indicator. */
	private String errorIndicator;
	/** The match indicator. */
	private String matchIndicator;
	/** The processing status. */
	private String processingStatus;
	/** The CDLIS/PDPS data record. */
	private DrivingRecord drivingRecord;

	/**
	 * Sets the soi header field.
	 *
	 * @param soiHeaderField the soiHeaderField to set
	 */
	public void setSoiHeaderField(String soiHeaderField) {
		this.soiHeaderField = soiHeaderField;
	}

	/**
	 * Gets the soi header field.
	 *
	 * @return the soiHeaderField
	 */
	public String getSoiHeaderField() {
		return soiHeaderField;
	}

	/**
	 * Sets the message type.
	 *
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * Gets the message type.
	 *
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * Sets the error indicator.
	 *
	 * @param errorIndicator the errorIndicator to set
	 */
	public void setErrorIndicator(String errorIndicator) {
		this.errorIndicator = errorIndicator;
	}

	/**
	 * Gets the error indicator.
	 *
	 * @return the errorIndicator
	 */
	public String getErrorIndicator() {
		return errorIndicator;
	}

	/**
	 * Sets the processing status.
	 *
	 * @param processingStatus the processingStatus to set
	 */
	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	/**
	 * Gets the processing status.
	 *
	 * @return the processingStatus
	 */
	public String getProcessingStatus() {
		return processingStatus;
	}

	/**
	 * Sets the driving record.
	 *
	 * @param drivingRecord the drivingRecord to set
	 */
	public void setDrivingRecord(DrivingRecord drivingRecord) {
		this.drivingRecord = drivingRecord;
	}

	/**
	 * Gets the driving record.
	 *
	 * @return the drivingRecord
	 */
	public DrivingRecord getDrivingRecord() {
		return drivingRecord;
	}

	/**
	 * Sets the match indicator.
	 *
	 * @param matchIndicator the matchIndicator to set
	 */
	public void setMatchIndicator(String matchIndicator) {
		this.matchIndicator = matchIndicator;
	}

	/**
	 * Gets the match indicator.
	 *
	 * @return the matchIndicator
	 */
	public String getMatchIndicator() {
		return matchIndicator;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CdsResponseInfo.java,v $
 *  Revision 1.2  2012/08/14 20:46:58  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.1  2011/03/21 22:07:46  mwhys
 *  Initial commit.
 *
 */
