/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I am a request to delete local inventory items.
 * File: DeleteLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Jun 9, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/06/09 18:32:22 $
 * Last Changed By: $Author: mwkfh $
 */
public class DeleteLocalInventoryRequest extends PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5050053854239043661L;
	/** The sequences. */
	IContiguousItemSequence contiguousItemSequence;

	/**
	 * @param userContext
	 * @param contiguousItemSequence
	 */
	public DeleteLocalInventoryRequest(IUserContext userContext,
			IContiguousItemSequence contiguousItemSequence) {
		super(userContext);
		setContiguousItemSequence(contiguousItemSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.impl.PersistenceServiceRequest#execute()
	 */
	@Override
	public DeleteLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * Gets the contiguousItemSequence.
	 * 
	 * @return the contiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		return contiguousItemSequence;
	}

	/**
	 * Sets the contiguousItemSequence.
	 * 
	 * @param contiguousItemSequence
	 */
	private void setContiguousItemSequence(
			IContiguousItemSequence contiguousItemSequence) {
		this.contiguousItemSequence = contiguousItemSequence;
	}
}
/**
 *  Modification History:
 *
 *  $Log: DeleteLocalInventoryRequest.java,v $
 *  Revision 1.1  2011/06/09 18:32:22  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 */
