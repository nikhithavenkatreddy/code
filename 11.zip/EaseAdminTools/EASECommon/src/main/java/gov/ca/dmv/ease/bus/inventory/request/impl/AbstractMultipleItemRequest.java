/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.process.IUserContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am abstract superclass for requests operating on multiple inventory items
 * File: AbstractMultipleItemRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request.impl
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2011/07/06 17:10:46 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class AbstractMultipleItemRequest extends
		AbstractInventoryItemsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3608743560450850563L;
	/** The item list. */
	private List <IInventoryItem> itemList;

	/**
	 * Instantiates a new abstract multi item request.
	 */
	protected AbstractMultipleItemRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 * @param items the items
	 */
	public AbstractMultipleItemRequest(IUserContext context,
			IInventoryItem... items) {
		super(context);
		setItemsFrom(items);
	}

	/**
	 * Instantiates a new abstract multi item request.
	 * 
	 * @param context the context
	 * @param aListOfItems the a list of items
	 */
	public AbstractMultipleItemRequest(IUserContext context,
			List <IInventoryItem> aListOfItems) {
		super(context);
		setItemsFrom(aListOfItems);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (itemList == null) {
			return 0;
		}
		else {
			return itemList.size();
		}
	}

	/**
	 * @return the itemList
	 */
	public List <IInventoryItem> getItemList() {
		if (itemList == null) {
			setItemList(new ArrayList <IInventoryItem>());
		}
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	protected void setItemList(List <IInventoryItem> aList) {
		itemList = aList;
	}

	/**
	 * Sets the items from.
	 * 
	 * @param items the new items from
	 */
	protected void setItemsFrom(IInventoryItem[] items) {
		if (items != null) {
			for (IInventoryItem item : items) {
				getItemList().add(item);
			}
		}
	}

	/**
	 * Sets the items from.
	 * 
	 * @param listOfItems the new items from
	 */
	protected void setItemsFrom(List <IInventoryItem> listOfItems) {
		getItemList().addAll(listOfItems);
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractMultipleItemRequest.java,v $
 *  Revision 1.5  2011/07/06 17:10:46  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.4  2011/06/09 18:32:49  mwkfh
 *  added ContiguousItemSequence
 *
 *  Revision 1.3  2010/09/28 17:13:28  mwpxp2
 *  Made getItemList/0 lazy.
 *
 *  Revision 1.2  2010/09/20 23:19:03  mwpxp2
 *  Refactoring cleanup
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.1  2010/09/14 18:41:30  mwpxp2
 *  Initial
 *
 */
