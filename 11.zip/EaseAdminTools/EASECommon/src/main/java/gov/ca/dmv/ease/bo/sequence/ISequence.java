/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence;

import gov.ca.dmv.ease.bo.sequence.parse.ISequenceElemList;

import java.io.Serializable;

/**
 * Description: I am interface for manipulating sequences
 * File: ISequence.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 3, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2010/10/06 00:32:56 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequence extends Serializable {
	/**
	 * As parsed.
	 * 
	 * @return the i parsed sequence
	 */
	ISequenceElemList asParsed();

	/**
	 * As string.
	 * 
	 * @return the string
	 */
	String asString();

	/**
	 * Gets the next.
	 * 
	 * @return the next
	 */
	ISequence getNext();

	/**
	 * Gets the pattern.
	 * 
	 * @return the pattern
	 */
	ISequencePattern getPattern();

	/**
	 * Gets the sequence no.
	 * 
	 * @return the sequence no
	 */
	String getSequenceNo();

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	String getValue();

	/**
	 * Checks if is after.
	 * 
	 * @param aSequence the a sequence
	 * 
	 * @return true, if is after
	 */
	boolean isAfter(ISequence aSequence);

	/**
	 * Checks if is after.
	 * 
	 * @param upperBoundarySequenceString the upper boundary sequence string
	 * 
	 * @return true, if is after
	 */
	boolean isAfter(String upperBoundarySequenceString);

	/**
	 * Next sequence.
	 * 
	 * @return the i sequence
	 */
	ISequence nextSequence();

	/**
	 * Previous sequence.
	 * 
	 * @return the i sequence
	 */
	ISequence previousSequence();
}
/**
 *  Modification History:
 *
 *  $Log: ISequence.java,v $
 *  Revision 1.7  2010/10/06 00:32:56  mwpxp2
 *  Added isAfter test for sequence
 *
 *  Revision 1.6  2010/10/05 20:40:04  mwpxp2
 *  Added calls for compatibility - before cleanup
 *
 *  Revision 1.5  2010/09/30 18:49:56  mwpxp2
 *  Moved to obsolete package
 *
 *  Revision 1.4  2010/09/10 23:30:58  mwbxg3
 *  *** empty log message ***
 *
 *  Revision 1.3  2010/09/08 01:56:13  mwpxp2
 *  Added value getter
 *
 *  Revision 1.2  2010/09/04 05:58:56  mwpxp2
 *  Corrected return type of asParsed/0
 *
 *  Revision 1.1  2010/09/04 05:53:51  mwpxp2
 *  Initial, in progress
 *
 */
