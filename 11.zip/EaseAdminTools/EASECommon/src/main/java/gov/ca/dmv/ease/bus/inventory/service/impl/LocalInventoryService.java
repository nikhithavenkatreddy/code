/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.service.impl;

import gov.ca.dmv.ease.bo.IBusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.inventory.item.impl.ItemType;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.conversion.impl.ContiguousItemSequenceConverter;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.DeleteInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetCurrentItemCountRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetLowestSequenceRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.ManuallyIssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.MoveInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RemoveStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RestoreInventoryItemsAvailabilityRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SeedInventoryFromDmvaRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SetItemCountThresholdRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryItemResponse;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemResponse;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemsResponse;
import gov.ca.dmv.ease.bus.inventory.response.impl.GetLowestSequenceResponse;
import gov.ca.dmv.ease.bus.inventory.response.impl.InventoryServiceResponse;
import gov.ca.dmv.ease.bus.inventory.response.impl.InventoryStatusRequestResponse;
import gov.ca.dmv.ease.bus.inventory.response.impl.IssuedInventoryItemResponse;
import gov.ca.dmv.ease.bus.inventory.response.impl.IssuedInventoryItemsResponse;
import gov.ca.dmv.ease.bus.inventory.service.ILocalInventoryService;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.error.impl.ErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.tus.persist.request.IPersistenceServiceRequest;
import gov.ca.dmv.ease.tus.persist.request.factory.ILocalPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.factory.IPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.LocalPersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.request.factory.impl.PersistenceServiceRequestFactory;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueMultipleLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MultipleRetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.PersistenceServiceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveBusinessObjectResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveLowestSequenceResponse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: I am default implementation of ILocalInventoryService
 * File: LocalInventoryService.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.service.impl
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.40 $
 * Last Changed: $Date: 2012/08/15 16:24:37 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class LocalInventoryService implements ILocalInventoryService {
	/**
	* Logger for this class
	*/
	private static final Log LOGGER = LogFactory
			.getLog(LocalInventoryService.class);
	/** The SINGLETON. */
	private static LocalInventoryService SINGLETON;
	/* inv assignment bucket type */
	private static final IItemType ASSIGNMENT_TYPE = ItemType.forCode("000");

	/**
	 * Gets the single instance of LocalInventoryService.
	 * 
	 * @return single instance of LocalInventoryService
	 */
	public static LocalInventoryService getInstance() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getInstance() - start");
		}
		if (SINGLETON == null) {
			initSingleton();
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getInstance() - end");
		}
		return SINGLETON;
	}

	/**
	 * Gets the local persistence service request factory.
	 * 
	 * @return the local persistence service request factory
	 */
	protected static ILocalPersistenceServiceRequestFactory getLocalPersistenceServiceRequestFactory() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getLocalPersistenceServiceRequestFactory() - start");
		}
		ILocalPersistenceServiceRequestFactory returnLocalPersistenceServiceRequestFactory = LocalPersistenceServiceRequestFactory
				.getInstance();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getLocalPersistenceServiceRequestFactory() - end");
		}
		return returnLocalPersistenceServiceRequestFactory;
	}

	/**
	 * Gets the persistence service request factory.
	 * 
	 * @return the persistence service request factory
	 */
	protected static IPersistenceServiceRequestFactory getPersistenceServiceRequestFactory() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getPersistenceServiceRequestFactory() - start");
		}
		IPersistenceServiceRequestFactory returnPersistenceServiceRequestFactory = PersistenceServiceRequestFactory
				.getInstance();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("getPersistenceServiceRequestFactory() - end");
		}
		return returnPersistenceServiceRequestFactory;
	}

	/**
	 * Inits the singleton.
	 */
	public static void initSingleton() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("initSingleton() - start");
		}
		SINGLETON = new LocalInventoryService();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("initSingleton() - end");
		}
	}

	/**
	 * Instantiates a new local inventory service.
	 */
	private LocalInventoryService() {
		super();
	}

	/**
	 * As business objects.
	 * 
	 * @param anItemList the an item list
	 * 
	 * @return the collection< i business object>
	 */
	private Collection <IBusinessObject> asBusinessObjectsUsingInventoryItems(
			List <IInventoryItem> anItemList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asBusinessObjects(List<IInventoryItem> anItemList="
					+ anItemList + ") - start");
		}
		validate(anItemList);
		List <IBusinessObject> aBoList = new ArrayList <IBusinessObject>(
				anItemList.size());
		for (IBusinessObject aBO : anItemList) {
			aBoList.add(aBO);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asBusinessObjects(List<IInventoryItem>) - end");
		}
		return aBoList;
	}

	/**
	 * As business objects.
	 * 
	 * @param anItemList the an item list
	 * 
	 * @return the object
	 */
	private Object asBusinessObjectsUsingThresholds(
			List <IItemThreshold> anItemList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asBusinessObjects(List<IItemThreshold> anItemList="
					+ anItemList + ") - start");
		}
		validate(anItemList);
		List <IBusinessObject> aBoList = new ArrayList <IBusinessObject>(
				anItemList.size());
		for (IBusinessObject aBO : anItemList) {
			aBoList.add(aBO);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asBusinessObjects(List<IItemThreshold>) - end");
		}
		return aBoList;
	}

	/*
	 * As item thresholds.
	 * 
	 * @param aBoList the a bo list
	 * 
	 * @return the list< i item threshold>
	 *
	private List <IInventoryItem> asLocalInventoryItems(
			Collection <IBusinessObject> aBoList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("asLocalInventoryItems(Collection<IBusinessObject> aBoList="
							+ aBoList + ") - start");
		}
		List <IInventoryItem> anItemList = new ArrayList <IInventoryItem>(
				aBoList.size());
		for (IBusinessObject aBo : aBoList) {
			IInventoryItem anItem = (IInventoryItem) aBo;
			anItemList.add(anItem);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("asLocalInventoryItems(Collection<IBusinessObject>) - end");
		}
		return anItemList;
	}
	*/
	/**
	 * As item thresholds.
	 * 
	 * @param aBoList the a bo list
	 * 
	 * @return the list< i item threshold>
	 */
	private List <IItemThreshold> asItemThresholds(
			Collection <IBusinessObject> aBoList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asItemThresholds(Collection<IBusinessObject> aBoList="
					+ aBoList + ") - start");
		}
		List <IItemThreshold> anItemList = new ArrayList <IItemThreshold>(
				aBoList.size());
		for (IBusinessObject aBo : aBoList) {
			IItemThreshold anItem = (IItemThreshold) aBo;
			anItemList.add(anItem);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("asItemThresholds(Collection<IBusinessObject>) - end");
		}
		return anItemList;
	}

	/**
	 * Checks if item is in list.
	 * 
	 * @param anItem the an item
	 * @param anItemList the an item list
	 * 
	 * @return boolean
	 */
	private boolean contains(IInventoryItem anItem,
			List <IBusinessObject> anItemList) {
		if ((anItem != null) && (anItemList != null)) {
			//check if exists
			String itemListStationId;
			String itemStationId = "";
			if (anItem instanceof StationLocalInventoryItem) {
				itemStationId = anItem.getStationId();
			}
			for (IBusinessObject objItem : anItemList) {
				IInventoryItem itemListItem = (IInventoryItem) objItem;
				if (itemListItem instanceof StationLocalInventoryItem) {
					itemListStationId = itemListItem.getStationId();
				}
				else {
					itemListStationId = "";
				}
				if ((anItem.getSequenceNo().getValue().equals(itemListItem
						.getSequenceNo().getValue()))
						&& (anItem.getType().getCode().equals(itemListItem
								.getType().getCode()))
						&& (anItem.getOfficeId().equals(itemListItem
								.getOfficeId()))
						&& (itemStationId.equals(itemListStationId))) {
					return true;
				}
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.AddInventoryItemRequest)
	 */
	public InventoryServiceResponse execute(
			AddInventoryItemRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(AddInventoryItemRequest anInventoryRequest="
					+ anInventoryRequest + ") - start");
		}
		List <IInventoryItem> itemList = anInventoryRequest.getItemList();
		//Validate
		IErrorCollector aCollector = new ErrorCollector();
		validateBusinessObjects(aCollector, itemList);
		if (aCollector.hasErrors()) {
			InventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
					aCollector);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(AddInventoryItemRequest) - end");
			}
			return returnInventoryServiceResponse;
		}
		//Retrieve items
		List <IBusinessObject> retrievedItems = retrieveInventoryItemList(
				anInventoryRequest.getUserContext(), itemList);
		for (IInventoryItem invItem : itemList) {
			invItem.beIssued();
		}
		List <IBusinessObject> unavailableItems = retrieveInventoryItemList(
				anInventoryRequest.getUserContext(), itemList);
		if (retrievedItems == null) {
			retrievedItems = unavailableItems;
		}
		else if (unavailableItems != null) {
			retrievedItems.addAll(unavailableItems);
		}
		//remove retrieved records from list
		for (int index = 0; index < itemList.size(); index++) {
			if (contains((IInventoryItem) itemList.get(index), retrievedItems)) {
				itemList.remove(index);
				index--;
			}
			else {
				((IInventoryItem) itemList.get(index)).beAvailable();
			}
		}
		int itemsToUpdate = 0;
		if (EaseUtil.isNotNull(itemList)) {
			itemsToUpdate = itemList.size();
		}
		//add remaining list
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createMultipleInsertOrUpdateRequest(
						anInventoryRequest.getUserContext(),
						asBusinessObjectsUsingInventoryItems(itemList));
		InventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(AddInventoryItemRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.AddInventoryRequest)
	 */
	public InventoryServiceResponse execute(
			AddInventoryRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(AddInventoryRequest anInventoryRequest="
					+ anInventoryRequest + ") - start");
		}
		IContiguousItemSequence itemSequence = anInventoryRequest
				.getContiguousItemSequence();
		itemSequence.hasUpperBoundary();
		int itemsToUpdate = anInventoryRequest.getItemCount();
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createAddLocalInventoryRequest(
						anInventoryRequest.getUserContext(), itemSequence);
		InventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(AddInventoryRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.AddInventoryRequest)
	 */
	public InventoryServiceResponse execute(
			AddStationInventoryAssignmentRequest anInventoryRequest) {
		LOGGER
				.info("execute(AddStationInventoryAssignmentRequest anInventoryRequest="
						+ anInventoryRequest + ") - start");
		List <IInventoryItem> stationInvAssignmentList = anInventoryRequest
				.getItemList();
		if (!EaseUtil.isNullOrBlank(stationInvAssignmentList)) {
			IErrorCollector aCollector = new ErrorCollector();
			//validate station assignment type
			validateStationAssignmentObjects(aCollector,
					stationInvAssignmentList);
			if (aCollector.hasErrors()) {
				return new InventoryServiceResponse(aCollector);
			}
			//save to database
			IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
					.createMultipleInsertOrUpdateRequest(
							anInventoryRequest.getUserContext(),
							asBusinessObjectsUsingInventoryItems(stationInvAssignmentList));
			return executeAndProcessResponse(aPersistenceRequest,
					stationInvAssignmentList.size());
		}
		LOGGER.info("execute(AddStationInventoryAssignmentRequest) - end");
		//return new InventoryServiceResponse(new ApplicationException(
		//		"UNABLE TO CREATE STATION INVENTORY ASSIGNMENT BUCKETS"));
		return new InventoryServiceResponse(0);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.DeleteInventoryItemRequest)
	 */
	public InventoryServiceResponse execute(
			DeleteInventoryItemRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(DeleteInventoryItemRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		IContiguousItemSequence itemSequence = anInventoryRequest
				.getContiguousItemSequence();
		itemSequence.hasUpperBoundary();
		//IPersistenceServiceRequest aPersistenceRequest;
		//if (!EaseUtil.isNullOrBlank(anInventoryRequest
		//		.getContiguousItemSequence())) {
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createDeleteLocalInventoryRequest(
						anInventoryRequest.getUserContext(), itemSequence);
		//}
		int itemsToUpdate = itemSequence.getItemCount();
		/*
		else {
			Collection <IBusinessObject> boList = null;
			List <IInventoryItem> itemList = anInventoryRequest.getItemList();
			IErrorCollector aCollector = new ErrorCollector();
			validateBusinessObjects(aCollector, itemList);
			if (aCollector.hasErrors()) {
				InventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
						aCollector);
				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("error validating item list - "
							+ aCollector.toString());
					LOGGER.info("execute(DeleteInventoryItemRequest) - end");
				}
				return returnInventoryServiceResponse;
			}
			if (hasBusinessObjectIds(itemList)) {
				boList = asBusinessObjects(itemList);
			}
			else {
				//add looking in stations for office sent items
				List <IInventoryItem> stationList = new ArrayList <IInventoryItem>();
				for (IInventoryItem item : itemList) {
					if (item instanceof OfficeLocalInventoryItem) {
						stationList.add(new StationLocalInventoryItem(item
								.getSequenceNo(), item.getType(), item
								.getOfficeId(), (String) null));
					}
				}
				if (!stationList.isEmpty()) {
					itemList.addAll(stationList);
				}
				//add unavailable items
				List <IInventoryItem> unavailableList = new ArrayList <IInventoryItem>();
				IInventoryItem unavailableItem = null;
				for (IInventoryItem item : itemList) {
					unavailableItem = LocalInventoryItem.newInstanceFor(item);
					if (item.isAvailable()) {
						unavailableItem.beIssued();
					}
					else {
						unavailableItem.beAvailable();
					}
					unavailableList.add(unavailableItem);
				}
				itemList.addAll(unavailableList);
				//load items
				IPersistenceServiceRequest aMultiRetrieveRequest = getPersistenceServiceRequestFactory()
						.createMultipleRetrieveBusinessObjectRequest(
								anInventoryRequest.getUserContext(),
								asBusinessObjects(itemList));
				MultipleRetrieveBusinessObjectResponse returnMultiRetrieveResponse = (MultipleRetrieveBusinessObjectResponse) aMultiRetrieveRequest
						.execute();
				if (returnMultiRetrieveResponse.hasErrors()) {
					InventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
							returnMultiRetrieveResponse.getErrorCollector());
					if (LOGGER.isInfoEnabled()) {
						LOGGER.info("error retrieving item list - "
								+ returnMultiRetrieveResponse
										.getErrorCollector().toString());
						LOGGER
								.info("execute(DeleteInventoryItemRequest) - end");
					}
					return returnInventoryServiceResponse;
				}
				else {
					boList = returnMultiRetrieveResponse.getResults();
				}
			}
			if (EaseUtil.isNotNull(boList)) {
				itemsToUpdate = boList.size();
			}
			aPersistenceRequest = getPersistenceServiceRequestFactory()
					.createMultipleDeleteBusinessObjectRequest(
							anInventoryRequest.getUserContext(), boList);
		}
		*/
		//delete items
		InventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("items deleted = "
					+ returnInventoryServiceResponse.getAffectedItemCount());
			LOGGER.info("execute(DeleteInventoryItemRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.GetCurrentItemCountRequest)
	 */
	public IInventoryStatusRequestResponse execute(
			GetCurrentItemCountRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(GetCurrentItemCountRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createMultipleRetrieveBusinessObjectRequest(
						anInventoryRequest.getUserContext(),
						(Collection <IBusinessObject>) asBusinessObjectsUsingThresholds(anInventoryRequest
								.getThresholds()));
		PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
				.execute();
		if (aPeristenceResponse.hasErrors()) {
			IInventoryStatusRequestResponse returnInventoryStatusRequestResponse = new InventoryStatusRequestResponse(
					aPeristenceResponse.getErrorCollector());
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(GetCurrentItemCountRequest) - end");
			}
			return returnInventoryStatusRequestResponse;
		}
		else {
			IInventoryStatusRequestResponse returnInventoryStatusRequestResponse = new InventoryStatusRequestResponse(
					asItemThresholds(((MultipleRetrieveBusinessObjectResponse) aPeristenceResponse)
							.getResults()));
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(GetCurrentItemCountRequest) - end");
			}
			return returnInventoryStatusRequestResponse;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.GetLowestSequenceRequest)
	 */
	public IInventoryItemResponse execute(
			GetLowestSequenceRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(GetLowestSequenceRequest anInventoryRequest="
					+ anInventoryRequest + ") - start");
		}
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createRetrieveLowestSequenceRequest(
						anInventoryRequest.getUserContext(),
						anInventoryRequest.getItemTypeCode(),
						anInventoryRequest.getOfficeId());
		PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
				.execute();
		GetLowestSequenceResponse returnInventoryItemResponse;
		if (aPeristenceResponse.hasErrors()) {
			returnInventoryItemResponse = new GetLowestSequenceResponse(
					aPeristenceResponse.getErrorCollector());
		}
		else {
			returnInventoryItemResponse = new GetLowestSequenceResponse(
					((RetrieveLowestSequenceResponse) aPeristenceResponse)
							.getItem());
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(GetLowestSequenceRequest) - end");
		}
		return returnInventoryItemResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.IssueInventoryItemRequest)
	 */
	public IIssuedInventoryItemResponse execute(
			IssueInventoryItemRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(IssueInventoryItemRequest anInventoryRequest="
					+ anInventoryRequest + ") - start");
		}
		IInventoryItem item;
		if (isInventoryFromStation(anInventoryRequest.getUserContext(),
				anInventoryRequest.getLocation(), anInventoryRequest
						.getItemTypeCode())) {
			item = new StationLocalInventoryItem(anInventoryRequest
					.getItemTypeCode(), anInventoryRequest.getLocation());
		}
		else {
			anInventoryRequest.getLocation().changeToOffice();
			item = new StationLocalInventoryItem(anInventoryRequest
					.getItemTypeCode(), anInventoryRequest.getLocation());
			//			item = new OfficeLocalInventoryItem(anInventoryRequest
			//					.getItemTypeCode(), anInventoryRequest.getLocation());
		}
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createIssueLocalInventoryRequest(
						anInventoryRequest.getUserContext(), item);
		PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
				.execute();
		if (aPeristenceResponse.hasErrors()) {
			IssuedInventoryItemResponse returnIssuedInventoryItemResponse = new IssuedInventoryItemResponse(
					aPeristenceResponse.getErrorCollector());
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(IssueInventoryItemRequest) - end");
			}
			return returnIssuedInventoryItemResponse;
		}
		else {
			IssuedInventoryItemResponse returnIssuedInventoryItemResponse = new IssuedInventoryItemResponse(
					((IssueLocalInventoryResponse) aPeristenceResponse)
							.getIssuedItem());
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(IssueInventoryItemRequest) - end");
			}
			return returnIssuedInventoryItemResponse;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.IssueMultipleInventoryItemsRequest)
	 */
	public IIssuedInventoryItemsResponse execute(
			IssueMultipleInventoryItemsRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(IssueMultipleInventoryItemsRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		IInventoryItem item;
		if (isInventoryFromStation(anInventoryRequest.getUserContext(),
				anInventoryRequest.getLocation(), anInventoryRequest
						.getItemTypeCode())) {
			item = new StationLocalInventoryItem(anInventoryRequest
					.getItemTypeCode(), anInventoryRequest.getLocation());
		}
		else {
			anInventoryRequest.getLocation().changeToOffice();
			item = new StationLocalInventoryItem(anInventoryRequest
					.getItemTypeCode(), anInventoryRequest.getLocation());
			//			item = new OfficeLocalInventoryItem(anInventoryRequest
			//					.getItemTypeCode(), anInventoryRequest.getLocation());
		}
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createIssueMultipleLocalInventoryRequest(
						anInventoryRequest.getUserContext(), item,
						anInventoryRequest.getQuantity());
		IssueMultipleLocalInventoryResponse aPeristenceResponse = (IssueMultipleLocalInventoryResponse) aPersistenceRequest
				.execute();
		if (aPeristenceResponse.hasErrors()) {
			IIssuedInventoryItemsResponse returnIssuedInventoryItemsResponse = new IssuedInventoryItemsResponse(
					aPeristenceResponse.getErrorCollector(),
					aPeristenceResponse.getAvailableInventoryCount());
			if (LOGGER.isInfoEnabled()) {
				LOGGER
						.info("execute(IssueMultipleInventoryItemsRequest) - end");
			}
			return returnIssuedInventoryItemsResponse;
		}
		else {
			IIssuedInventoryItemsResponse returnIssuedInventoryItemsResponse = new IssuedInventoryItemsResponse(
					aPeristenceResponse.getIssuedItemList(),
					aPeristenceResponse.getAvailableInventoryCount());
			if (LOGGER.isInfoEnabled()) {
				LOGGER
						.info("execute(IssueMultipleInventoryItemsRequest) - end");
			}
			return returnIssuedInventoryItemsResponse;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.ManuallyIssueMultipleInventoryItemsRequest)
	 */
	public IInventoryServiceResponse execute(
			ManuallyIssueMultipleInventoryItemsRequest anInventoryRequest) {
		//delete local inventory
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(ManuallyIssueMultipleInventoryItemsRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		//Collection <IBusinessObject> boList = null;
		List <IInventoryItem> itemList = anInventoryRequest.getItemList();
		IErrorCollector aCollector = new ErrorCollector();
		validateBusinessObjects(aCollector, itemList);
		if (aCollector.hasErrors()) {
			IInventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
					aCollector);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("error validating item list - "
						+ aCollector.toString());
				LOGGER
						.info("execute(ManuallyIssueMultipleInventoryItemsRequest) - end");
			}
			return returnInventoryServiceResponse;
		}
		/*
		if (hasBusinessObjectIds(itemList)) {
			boList = asBusinessObjects(itemList);
		}
		else {
			//load items
			IPersistenceServiceRequest aMultiRetrieveRequest = getPersistenceServiceRequestFactory()
					.createMultipleRetrieveBusinessObjectRequest(
							anInventoryRequest.getUserContext(),
							asBusinessObjects(itemList));
			MultipleRetrieveBusinessObjectResponse returnMultiRetrieveResponse = (MultipleRetrieveBusinessObjectResponse) aMultiRetrieveRequest
					.execute();
			if (returnMultiRetrieveResponse.hasErrors()) {
				IInventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
						returnMultiRetrieveResponse.getErrorCollector());
				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("error retrieving item list - "
							+ returnMultiRetrieveResponse.getErrorCollector()
									.toString());
					LOGGER
							.info("execute(ManuallyIssueMultipleInventoryItemsRequest) - end");
				}
				return returnInventoryServiceResponse;
			}
			else {
				boList = returnMultiRetrieveResponse.getResults();
			}
		}
		int itemsToUpdate = 0;
		if (EaseUtil.isNotNull(boList)) {
			itemsToUpdate = boList.size();
			//issue items
			for (IBusinessObject boItem : boList) {
				((IInventoryItem) boItem).beIssued();
			}
		}
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createMultipleInsertOrUpdateRequest(
						anInventoryRequest.getUserContext(), boList);
		IInventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("items issued = "
					+ returnInventoryServiceResponse.getAffectedItemCount());
			LOGGER
					.info("execute(ManuallyIssueMultipleInventoryItemsRequest) - end");
		}
		*/
		List <IContiguousItemSequence> itemSequenceList = ContiguousItemSequenceConverter
				.getInstance().toItemSequenceListFrom(itemList);
		int affectedItemCount = 0;
		int itemsToUpdate;
		InventoryServiceResponse returnInventoryServiceResponse;
		for (IContiguousItemSequence itemSequence : itemSequenceList) {
			//purge local inventory
			itemSequence.hasUpperBoundary();
			IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
					.createDeleteLocalInventoryRequest(
							anInventoryRequest.getUserContext(), itemSequence);
			itemsToUpdate = itemSequence.getItemCount();
			returnInventoryServiceResponse = executeAndProcessResponse(
					aPersistenceRequest, itemsToUpdate);
			affectedItemCount += returnInventoryServiceResponse
					.getAffectedItemCount();
			if (returnInventoryServiceResponse.hasErrors()) {
				aCollector.addEntries(returnInventoryServiceResponse
						.getErrorCollector().getEntries());
			}
		}
		if (aCollector.hasErrors()) {
			return new InventoryServiceResponse(affectedItemCount, aCollector);
		}
		else {
			return new InventoryServiceResponse(affectedItemCount);
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.MoveInventoryItemRequest)
	 */
	public InventoryServiceResponse execute(
			MoveInventoryItemRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(MoveInventoryItemRequest anInventoryRequest="
					+ anInventoryRequest + ") - start");
		}
		IContiguousItemSequence itemSequence = anInventoryRequest
				.getContiguousItemSequence();
		IErrorCollector aCollector = new ErrorCollector();
		itemSequence.hasUpperBoundary();
		//validateBusinessObjects(aCollector, itemList);
		if (aCollector.hasErrors()) {
			InventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
					aCollector);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(MoveInventoryFromDmvaRequest) - end");
			}
			return returnInventoryServiceResponse;
		}
		int itemsToUpdate = 0;
		if (EaseUtil.isNotNull(itemSequence)) {
			itemsToUpdate = itemSequence.getItemCount();
		}
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createMoveLocalInventoryRequest(
						anInventoryRequest.getUserContext(), itemSequence,
						anInventoryRequest.getLocation());
		InventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(MoveInventoryItemRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.AddInventoryRequest)
	 */
	public InventoryServiceResponse execute(
			RemoveStationInventoryAssignmentRequest anInventoryRequest) {
		LOGGER
				.info("execute(RemoveStationInventoryAssignmentRequest anInventoryRequest="
						+ anInventoryRequest + ") - start");
		List <IInventoryItem> stationInvAssignmentList = anInventoryRequest
				.getItemList();
		if (!EaseUtil.isNullOrBlank(stationInvAssignmentList)) {
			IErrorCollector aCollector = new ErrorCollector();
			//validate station assignment type
			validateStationAssignmentObjects(aCollector,
					stationInvAssignmentList);
			if (aCollector.hasErrors()) {
				return new InventoryServiceResponse(aCollector);
			}
			Collection <IBusinessObject> businessObjectList;
			if (EaseUtil.isNullOrBlank(stationInvAssignmentList.get(0).getId())) {
				//load items
				businessObjectList = retrieveInventoryItemList(
						anInventoryRequest.getUserContext(),
						stationInvAssignmentList);
			}
			else {
				businessObjectList = asBusinessObjectsUsingInventoryItems(stationInvAssignmentList);
			}
			//save to database
			IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
					.createMultipleDeleteBusinessObjectRequest(
							anInventoryRequest.getUserContext(),
							businessObjectList);
			return executeAndProcessResponse(aPersistenceRequest,
					stationInvAssignmentList.size());
		}
		LOGGER.info("execute(RemoveStationInventoryAssignmentRequest) - end");
		//return new InventoryServiceResponse(new ApplicationException(
		//		"UNABLE TO CREATE STATION INVENTORY ASSIGNMENT BUCKETS"));
		return new InventoryServiceResponse(0);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.RestoreInventoryItemsAvailabilityRequest)
	 */
	public IInventoryServiceResponse execute(
			RestoreInventoryItemsAvailabilityRequest anInventoryRequest) {
		//add local inventory
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(RestoreInventoryItemsAvailabilityRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		//Collection <IBusinessObject> boList = null;
		/*
		List <IInventoryItem> itemList = anInventoryRequest.getItemList();
		IErrorCollector aCollector = new ErrorCollector();
		validateBusinessObjects(aCollector, itemList);
		if (aCollector.hasErrors()) {
			IInventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
					aCollector);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("error validating item list - "
						+ aCollector.toString());
				LOGGER
						.info("execute(RestoreInventoryItemsAvailabilityRequest) - end");
			}
			return returnInventoryServiceResponse;
		}
		if (hasBusinessObjectIds(itemList)) {
			boList = asBusinessObjects(itemList);
		}
		else {
			//make items unavailable
			for (IInventoryItem invItem : itemList) {
				invItem.beIssued();
			}
			//load items
			IPersistenceServiceRequest aMultiRetrieveRequest = getPersistenceServiceRequestFactory()
					.createMultipleRetrieveBusinessObjectRequest(
							anInventoryRequest.getUserContext(),
							asBusinessObjects(itemList));
			MultipleRetrieveBusinessObjectResponse returnMultiRetrieveResponse = (MultipleRetrieveBusinessObjectResponse) aMultiRetrieveRequest
					.execute();
			if (returnMultiRetrieveResponse.hasErrors()) {
				IInventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
						returnMultiRetrieveResponse.getErrorCollector());
				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("error retrieving item list - "
							+ returnMultiRetrieveResponse.getErrorCollector()
									.toString());
					LOGGER
							.info("execute(RestoreInventoryItemsAvailabilityRequest) - end");
				}
				return returnInventoryServiceResponse;
			}
			else {
				boList = returnMultiRetrieveResponse.getResults();
			}
		}
		*/
		List <IContiguousItemSequence> itemSequenceList = anInventoryRequest
				.getContiguousItemSequenceList();
		int itemsToUpdate = 0;
		/*
		if (EaseUtil.isNotNull(boList)) {
			itemsToUpdate = boList.size();
			//make items available
			for (IBusinessObject boItem : boList) {
				((IInventoryItem) boItem).beAvailable();
			}
		}
		Collection <IBusinessObject> boList = new ArrayList <IBusinessObject>();
		if (itemsToUpdate < 5) {
			for (IInventoryItem item : itemList) {
				boList.add(item);
			}
		}
		else {
			List <IContiguousItemSequence> itemSequenceList = ContiguousItemSequenceConverter
					.getInstance().toItemSequenceListFrom(itemList);
			for (IContiguousItemSequence item : itemSequenceList) {
				boList.add(item);
			}
		}
		*/
		Collection <IBusinessObject> boList = new ArrayList <IBusinessObject>();
		for (IContiguousItemSequence seqItem : itemSequenceList) {
			itemsToUpdate += seqItem.getItemCount();
			boList.add(seqItem);
			/* removed saving single items to different table
			List <IInventoryItem> itemList = seqItem.asItemList();
			itemsToUpdate += itemList.size();
			if (itemList.size() > 1) {
				boList.add(seqItem);
			}
			else {
				boList.addAll(itemList);
			}
			*/
		}
		//restore items
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createMultipleInsertOrUpdateRequest(
						anInventoryRequest.getUserContext(), boList);
		IInventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("items restored = "
					+ returnInventoryServiceResponse.getAffectedItemCount());
			LOGGER
					.info("execute(RestoreInventoryItemsAvailabilityRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.SeedInventoryFromDmvaRequest)
	 */
	public InventoryServiceResponse execute(
			SeedInventoryFromDmvaRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(SeedInventoryFromDmvaRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		List <IContiguousItemSequence> sequenceList = anInventoryRequest
				.getAllSequences();
		//validation handled by persistence service
		//		IErrorCollector aCollector = new ErrorCollector();
		//		for (IContiguousItemSequence sequence : sequenceList) {
		//			validateBusinessObjects(aCollector, sequence.asItemList());
		//		}
		//		if (aCollector.hasErrors()) {
		//			InventoryServiceResponse returnInventoryServiceResponse = new InventoryServiceResponse(
		//					aCollector);
		//			if (LOGGER.isInfoEnabled()) {
		//				LOGGER.info("execute(SeedInventoryFromDmvaRequest) - end");
		//			}
		//			return returnInventoryServiceResponse;
		//		}
		int itemsToUpdate = 0;
		if (EaseUtil.isNotNull(sequenceList)) {
			itemsToUpdate = sequenceList.size();
		}
		IPersistenceServiceRequest aPersistenceRequest = getLocalPersistenceServiceRequestFactory()
				.createSeedLocalInventoryRequest(
						anInventoryRequest.getUserContext(),
						anInventoryRequest.getOfficeId(),
						anInventoryRequest.getProcessorId(), sequenceList);
		InventoryServiceResponse returnInventoryServiceResponse = executeAndProcessResponse(
				aPersistenceRequest, itemsToUpdate);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("execute(SeedInventoryFromDmvaRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.service.ILocalInventoryService#execute(gov.ca.dmv.ease.bus.dl.inventory.request.impl.SetItemCountThresholdRequest)
	 */
	public IInventoryStatusRequestResponse execute(
			SetItemCountThresholdRequest anInventoryRequest) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("execute(SetItemCountThresholdRequest anInventoryRequest="
							+ anInventoryRequest + ") - start");
		}
		Collection <IBusinessObject> businessObjects = (Collection <IBusinessObject>) asBusinessObjectsUsingThresholds(anInventoryRequest
				.getThresholds());
		IPersistenceServiceRequest aPersistenceRequest = getPersistenceServiceRequestFactory()
				.createMultipleInsertOrUpdateRequest(
						anInventoryRequest.getUserContext(), businessObjects);
		PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
				.execute();
		if (aPeristenceResponse.hasErrors()) {
			IInventoryStatusRequestResponse returnInventoryStatusRequestResponse = new InventoryStatusRequestResponse(
					aPeristenceResponse.getErrorCollector());
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(SetItemCountThresholdRequest) - end");
			}
			return returnInventoryStatusRequestResponse;
		}
		else {
			IInventoryStatusRequestResponse returnInventoryStatusRequestResponse = new InventoryStatusRequestResponse(
					asItemThresholds(businessObjects));
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("execute(SetItemCountThresholdRequest) - end");
			}
			return returnInventoryStatusRequestResponse;
		}
	}

	/**
	 * Execute and process response.
	 * 
	 * @param aPersistenceRequest the a persistence request
	 * @param anInventoryRequest the an inventory request
	 * 
	 * @return the inventory service response
	 */
	protected InventoryServiceResponse executeAndProcessResponse(
			IPersistenceServiceRequest aPersistenceRequest, int itemCount) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("executeAndProcessResponse(IPersistenceServiceRequest aPersistenceRequest="
							+ aPersistenceRequest
							+ ", int itemCount="
							+ itemCount + ") - start");
		}
		//this is common part, functioning as utility
		PersistenceServiceResponse aPeristenceResponse = aPersistenceRequest
				.execute();
		InventoryServiceResponse returnInventoryServiceResponse;
		int affectedCount = aPeristenceResponse.getAffectedItemsCount();
		//		if (aPeristenceResponse instanceof SeedLocalInventoryResponse) {
		//			affectedCount = ((SeedLocalInventoryResponse) aPeristenceResponse)
		//					.getAffectedItemsCount();
		//		}
		//		else if (aPeristenceResponse instanceof AddLocalInventoryResponse) {
		//			affectedCount = ((AddLocalInventoryResponse) aPeristenceResponse)
		//					.getAffectedItemsCount();
		//		}
		//		else {
		//			affectedCount = itemCount;
		//		}
		if (aPeristenceResponse.hasErrors()) {
			returnInventoryServiceResponse = new InventoryServiceResponse(
					affectedCount, aPeristenceResponse.getErrorCollector());
		}
		else {
			returnInventoryServiceResponse = new InventoryServiceResponse(
					affectedCount);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("executeAndProcessResponse(IPersistenceServiceRequest, IInventoryItemsRequest) - end");
		}
		return returnInventoryServiceResponse;
	}

	/**
	 * Retrieves the inventory items from the DB.
	 * 
	 * @param anItemList the an item list
	 * 
	 * @return boolean
	 */
	private List <IBusinessObject> retrieveInventoryItemList(
			IUserContext userContext, List <IInventoryItem> anItemList) {
		IPersistenceServiceRequest aMultipleRetrieveAvailableRequest = getPersistenceServiceRequestFactory()
				.createMultipleRetrieveBusinessObjectRequest(userContext,
						asBusinessObjectsUsingInventoryItems(anItemList));
		MultipleRetrieveBusinessObjectResponse returnMultipleRetrieveAvailableResponse = (MultipleRetrieveBusinessObjectResponse) aMultipleRetrieveAvailableRequest
				.execute();
		return returnMultipleRetrieveAvailableResponse.getResults();
	}

	/**
	 * Checks business objects for ids.
	 * 
	 * @param anItemList the an item list
	 * 
	 * @return boolean
	 */
	private boolean hasBusinessObjectIds(List <IInventoryItem> anItemList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("hasBusinessObjectIds(List<IInventoryItem> anItemList="
					+ anItemList + ") - start");
		}
		for (IInventoryItem invItem : anItemList) {
			if (invItem.getId() == null) {
				return false;
			}
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("hasBusinessObjectIds(List<IInventoryItem>) - end");
		}
		return true;
	}

	/**
	 * Retrieves the station inventory assignment information and returns true if
	 * the inventory can be pulled from the station.
	 * 
	 * @param userContext
	 * @param itemLocation
	 * @param itemTypeCode
	 * 
	 * @return boolean
	 */
	private boolean isInventoryFromStation(IUserContext userContext,
			IItemLocation itemLocation, String itemTypeCode) {
		LOGGER.info("isInventoryFromStation(IItemLocation itemLocation="
				+ itemLocation + ", String itemTypeCode=" + itemTypeCode
				+ ") - start");
		boolean isInventoryFromStation = false;
		if ((itemLocation != null) && (itemLocation.getStationId() != null)) {
			//check inventory assigned flag in station
			//			Station aStation = new Station(itemLocation.getStationId());
			//			IPersistenceServiceRequest aRequest = getPersistenceServiceRequestFactory()
			//					.createRetrieveBusinessObjectRequest(userContext, aStation);
			//			RetrieveBusinessObjectResponse aResponse = (RetrieveBusinessObjectResponse) aRequest
			//					.execute();
			//			if (aResponse.hasErrors()
			//					|| EaseUtil.isNullOrBlank(aResponse.getResults())) {
			//				LOGGER.error("Unable to load station '"
			//						+ itemLocation.getStationId() + "'!");
			//			}
			//			else {
			//				isInventoryFromStation = ((Station) aResponse.getResults().get(
			//						0)).isInventoryAssigned();
			//			}
			if (userContext.isLocalInventoryAssigned()) {
				//check inventory assigned bucket for item code
				IInventoryItem stationInvAssignment = new StationLocalInventoryItem(
						itemTypeCode, ItemType.forCode("000"), itemLocation
								.getOfficeId(), itemLocation.getStationId(),
						itemTypeCode, itemTypeCode);
				//check for station inventory for now
				//				IContiguousItemSequence stationInvAssignment = new ContiguousItemSequence(
				//						itemTypeCode, itemLocation.getOfficeId(), itemLocation
				//								.getStationId(), null, null, true);
				IPersistenceServiceRequest aRequest = getPersistenceServiceRequestFactory()
						.createRetrieveBusinessObjectRequest(userContext,
								stationInvAssignment);
				RetrieveBusinessObjectResponse aResponse = (RetrieveBusinessObjectResponse) aRequest
						.execute();
				if (aResponse.hasErrors()) {
					LOGGER.error("Unable to load station '"
							+ itemLocation.getStationId()
							+ "' inventory item assignment for type '"
							+ itemTypeCode + "'!");
					//isInventoryFromStation = false;
				}
				else {
					if (aResponse.hasResults()) {
						isInventoryFromStation = true;
					}
				}
			}
		}
		LOGGER
				.info("isInventoryFromStation(IItemLocation itemLocation, String itemTypeCode) - isInventoryFromStation="
						+ isInventoryFromStation + " - end");
		return isInventoryFromStation;
	}

	/*
	 * Sets the target location.
	 * 
	 * @param theTarget the the target
	 * @param anItemList the an item list
	 *
	private void setTargetLocation(IItemLocation theTarget,
			List <IInventoryItem> anItemList) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("setTargetLocation(IItemLocation theTarget="
					+ theTarget + ", List<IInventoryItem> anItemList="
					+ anItemList + ") - start");
		}
		validate(anItemList);
		for (IInventoryItem anItem : anItemList) {
			anItem.setTargetLocation(theTarget);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER
					.info("setTargetLocation(IItemLocation, List<IInventoryItem>) - end");
		}
	}
	*/
	//	/**
	//	 * Validate.
	//	 * 
	//	 * @param anItemList the an item list
	//	 */
	//	private void validate(List <IInventoryItem> anItemList) {
	//		if (anItemList == null) {
	//			throw new EaseValidationException("Null item list in " + this);
	//		}
	//		if (anItemList.isEmpty()) {
	//			throw new EaseValidationException("Empty item list in " + this);
	//		}
	//	}
	/**
	 * Validate.
	 * 
	 * @param anItemList the an item list
	 */
	private void validate(List <? extends IBusinessObject> anItemList) {
		LOGGER.info("validate(List<? extends IBusinessObject> anItemList="
				+ anItemList + ") - start");
		if (anItemList == null) {
			throw new EaseValidationException("Null item list in " + this);
		}
		//if (anItemList.isEmpty()) {
		//	throw new EaseValidationException("Empty item list in " + this);
		//}
		LOGGER.info("validate(List<? extends IBusinessObject>) - end");
	}

	/**
	 * Validate business objects.
	 * 
	 * @param itemList the item list
	 * 
	 * @return the i error collector
	 */
	private void validateStationAssignmentObjects(IErrorCollector aCollector,
			List <IInventoryItem> itemList) {
		LOGGER
				.info("validateStationAssignmentObjects(List<IInventoryItem> itemList="
						+ itemList + ") - start");
		if (EaseUtil.isNotNull(itemList)) {
			//validate station assignment type
			for (IInventoryItem stationInvAssignment : itemList) {
				if (!ASSIGNMENT_TYPE.getCode().equals(
						stationInvAssignment.getType().getCode())) {
					aCollector
							.register(new EaseValidationException(
									"INVALID INVENTORY ITEM TYPE FOR STATION ASSIGNMENT"));
					break; //stop after first error
				}
			}
			LOGGER
					.info("validateStationAssignmentObjects(List<IInventoryItem>) - end");
		}
	}

	/**
	 * Validate business objects.
	 * 
	 * @param itemList the item list
	 * 
	 * @return the i error collector
	 */
	private void validateBusinessObjects(IErrorCollector aCollector,
			List <IInventoryItem> itemList) {
		LOGGER.info("validateBusinessObjects(List<IInventoryItem> itemList="
				+ itemList + ") - start");
		for (IInventoryItem inventoryItem : itemList) {
			inventoryItem.validateUsing(aCollector);
		}
		LOGGER.info("validateBusinessObjects(List<IInventoryItem>) - end");
	}
}
/**
 *  Modification History:
 *
 *  $Log: LocalInventoryService.java,v $
 *  Revision 1.40  2012/08/15 16:24:37  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.39  2011/11/04 16:39:20  mwkfh
 *  added GetLowestSequence
 *
 *  Revision 1.38  2011/10/19 20:33:15  mwpxp2
 *  Fixed same erasure defect: renamed asBusinessObject on two different collections to different methods: asBusinessObjectUsing...
 *
 *  Revision 1.37  2011/09/23 23:22:59  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.36  2011/09/23 00:20:29  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.35  2011/08/09 16:39:58  mwkfh
 *  restore changed to only save to range table
 *
 *  Revision 1.34  2011/07/15 21:53:45  mwkfh
 *  updated execute(RemoveStationInventoryAssignmentRequest)
 *
 *  Revision 1.33  2011/07/13 17:31:06  mwkfh
 *  added RemoveStationInventoryAssignmentRequest
 *
 *  Revision 1.32  2011/07/12 00:11:17  mwkfh
 *  added AddStationInventoryAssignmentRequest
 *
 *  Revision 1.31  2011/07/07 22:32:43  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.30  2011/07/06 17:10:44  mwkfh
 *  updated for local inventory redesign
 *
 *  Revision 1.29  2011/07/02 00:01:11  mwkfh
 *  updated executeAndProcessResponse
 *
 *  Revision 1.28  2011/06/28 21:01:59  mwxxw
 *  Add more logic for issue station level items.
 *
 *  Revision 1.27  2011/06/17 23:39:41  mwhys
 *  Updated isInventoryFromStation(). Use a different constructor to create StationLocalInventoryItem.
 *
 *  Revision 1.26  2011/06/09 18:32:20  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.25  2011/06/08 18:55:34  mwkfh
 *  added AddInventoryRequest
 *
 *  Revision 1.24  2011/05/05 16:38:38  mwkfh
 *  updated isInventoryFromStation to not query station_info table
 *
 *  Revision 1.23  2011/04/29 20:48:42  mwkfh
 *  commented unused methods
 *
 *  Revision 1.22  2011/04/08 18:10:11  mwkfh
 *  changed executeAndProcessResponse param to the actual count
 *
 *  Revision 1.21  2011/02/07 17:18:28  mwkfh
 *  updated execute(DeleteInventoryItemRequest) to delete unavailable items - defect 4748
 *
 *  Revision 1.20  2011/01/10 21:48:06  mwkfh
 *  added purge office id to seed action
 *
 *  Revision 1.19  2011/01/07 17:45:51  mwkfh
 *  updated seed to use contiguousItemSquence to reduce memory from expanded list
 *
 *  Revision 1.18  2010/12/24 03:05:45  mwkfh
 *  updated execute DeleteInventoryItemRequest to look in stations for office sent items since station not always known
 *
 *  Revision 1.17  2010/12/23 06:18:23  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.15.4.1  2010/12/23 03:13:56  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.16  2010/12/19 21:49:16  mwtjc1
 *  populating AvailableInventoryCount in the response with issuedItemList
 *
 *  Revision 1.15  2010/12/17 00:18:52  mwtjc1
 *  IInventoryServiceResponse execute(
 *  			RestoreInventoryItemsAvailabilityRequest anInventoryRequest)
 *  			updated
 *
 *  Revision 1.14  2010/12/13 20:48:19  mwkfh
 *  added availableInventoryCount for multiple issue response
 *
 *  Revision 1.13  2010/12/08 19:03:13  mwkfh
 *  added RestoreInventoryItemsAvailabilityRequest
 *
 *  Revision 1.12  2010/12/07 00:19:36  mwkfh
 *  added ManuallyIssue and IssueMultiple
 *
 *  Revision 1.11  2010/12/06 20:02:51  mwkfh
 *  updated execute(AddInventoryItemRequest) to check for items before adding
 *
 *  Revision 1.10  2010/12/05 00:06:16  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 *  Revision 1.9  2010/12/03 19:29:41  mwkfh
 *  updated delete to load ids if not set
 *
 *  Revision 1.8  2010/12/03 16:52:08  mwkfh
 *  added move local inventory
 *
 *  Revision 1.7  2010/12/02 16:39:02  mwkfh
 *  allowed list to be empty
 *
 *  Revision 1.6  2010/10/15 18:42:27  mwkfh
 *  added IIssuedInventoryItemResponse
 *
 *  Revision 1.5  2010/10/13 02:18:46  mwpxp2
 *  Added info-level logging
 *
 *  Revision 1.4  2010/10/07 17:15:48  mwkfh
 *  split getItem and getItemList into separate interfaces from IInventoryRequest
 *
 *  Revision 1.3  2010/10/06 22:34:00  mwkfh
 *  updated Issue Item, and get and set threshold
 *
 *  Revision 1.2  2010/09/20 23:13:38  mwpxp2
 *  Added execute stubs for GetCurrentItemCountRequest and SetItemCountThresholdRequest
 *
 *  Revision 1.1  2010/09/20 20:29:13  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.9  2010/09/20 18:26:17  mwpxp2
 *  Added execute() stubs for GetCurrentItemCountRequest and SetItemCountThresholdRequest
 *
 *  Revision 1.8  2010/09/16 22:38:30  mwpxp2
 *  Stubbed implementation of execution of IssueInventoryItemRequest
 *
 *  Revision 1.7  2010/09/15 19:11:26  mwpxp2
 *  Implementation done, ready for testing; removed unnecessary static factory ref
 *
 *  Revision 1.6  2010/09/15 01:16:26  mwpxp2
 *  Partially implemented, not tested
 *
 *  Revision 1.5  2010/09/14 20:01:52  mwpxp2
 *  Refactored to use four types of requests: add, remove, move, seed
 *
 *  Revision 1.4  2010/09/14 19:01:06  mwpxp2
 *  Adjustments per interface mods
 *
 *  Revision 1.3  2010/09/13 04:42:11  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.2  2010/09/02 20:44:55  mwpxp2
 *  Adjusted for IItem to IInvenotryItem rename
 *
 *  Revision 1.1  2010/09/01 00:39:32  mwpxp2
 *  Initial with method stubs
 *
 */
