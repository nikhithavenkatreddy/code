/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.impl.StationLocalInventoryItem;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemsResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am request to issue multiple inventory items for particular location, for item of a given type
 * File: IssueMultipleInventoryItemsRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Dec 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/09/23 21:45:45 $
 * Last Changed By: $Author: mwkfh $
 */
public class IssueMultipleInventoryItemsRequest extends
		AbstractInventoryRequest implements IInventoryItemRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9131815920125924465L;
	/** The item type code. */
	private String itemTypeCode;
	/** The location. */
	private IItemLocation location;
	/** The quantity */
	private int quantity = 1;

	/**
	 * Instantiates a new issue inventory item request.
	 */
	protected IssueMultipleInventoryItemsRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected IssueMultipleInventoryItemsRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Instantiates a new issue inventory item request.
	 * 
	 * @param context the context
	 * @param forLocation the for location
	 * @param anItemTypeCode the an item type code
	 */
	public IssueMultipleInventoryItemsRequest(IUserContext context,
			IItemLocation forLocation, String anItemTypeCode, int quantity) {
		super(context);
		setLocation(forLocation);
		setItemTypeCode(anItemTypeCode);
		setQuantity(quantity);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	public IIssuedInventoryItemsResponse execute() {
		return getService().execute(this);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (itemTypeCode == null) {
			return 0;
		}
		else {
			return 1;
		}
	}

	/**
	 * @deprecated
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.IInventoryRequest#getItemList()
	 */
	public IInventoryItem getItem() {
		//TODO: add check to see if inventory should be issued by workstation
		//		if (getLocation().isAssignedToStation()) {
		return new StationLocalInventoryItem(getItemTypeCode(), getLocation());
		//		}
		//		else {
		//return new OfficeLocalInventoryItem(getItemTypeCode(), getLocation());
		//		}
	}

	/**
	 * Gets the item type code.
	 * 
	 * @return the itemTypeCode
	 */
	public String getItemTypeCode() {
		return itemTypeCode;
	}

	/**
	 * Gets the location.
	 * 
	 * @return the location
	 */
	public IItemLocation getLocation() {
		return location;
	}

	/**
	 * Returns the quantity
	 * 
	 * @return int quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Sets the item type code.
	 * 
	 * @param itemTypeCode the itemTypeCode to set
	 */
	protected void setItemTypeCode(String aCodeString) {
		itemTypeCode = aCodeString;
	}

	/**
	 * Sets the location.
	 * 
	 * @param location the location to set
	 */
	protected void setLocation(IItemLocation aLocation) {
		location = aLocation;
	}

	/**
	 * Sets the quantity
	 *
	 * @param quantity
	 */
	protected void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueMultipleInventoryItemsRequest.java,v $
 *  Revision 1.4  2011/09/23 21:45:45  mwkfh
 *  added ProcessorId
 *
 *  Revision 1.3  2011/04/12 16:40:23  mwkfh
 *  deprecated getItem
 *
 *  Revision 1.2  2011/01/21 01:04:37  mwkfh
 *  changed getItem to only return Office items for issuing
 *
 *  Revision 1.1  2010/12/05 00:06:17  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 */
