/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.exception.impl.EaseException;

/**
 * Description: I am the response for LocalInventoryPersistenceBusinessObject response
 * File: RetrieveLowestSequenceResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Nov 3, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/11/03 23:42:55 $
 * Last Changed By: $Author: mwkfh $
 */
public class RetrieveLowestSequenceResponse extends PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 507652743384544226L;
	/** The domain object. */
	private IInventoryItem inventoryItem;

	/**
	 * Default Constructor
	 */
	public RetrieveLowestSequenceResponse() {
		super();
	}

	/**
	 * @param ex
	 */
	public RetrieveLowestSequenceResponse(EaseException ex) {
		super(ex);
	}

	/**
	 * Instantiates a new business object response.
	 * 
	 * @param ex the ex
	 */
	public RetrieveLowestSequenceResponse(Exception ex) {
		super();
		getErrorCollector().register(ex);
	}

	/**
	 * Instantiates a new business object response.
	 * 
	 * @param ErrorCollector the errorCollector
	 */
	public RetrieveLowestSequenceResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Instantiates a new item response.
	 * 
	 */
	public RetrieveLowestSequenceResponse(IInventoryItem inventoryItem) {
		super();
		setItem(inventoryItem);
	}

	/**
	 * This method returns the results of the retrieve business object function in persistence service.
	 * 
	 * @return the domainObject
	 */
	public IInventoryItem getItem() {
		super.throwExceptionIfErrorFound();
		return inventoryItem;
	}

	/**
	 * This method sets the results to this response object.
	 * 
	 * @param IInventoryItem the domainObject to set
	 */
	private void setItem(IInventoryItem inventoryItem) {
		this.inventoryItem = inventoryItem;
	}
}
/**
 *  Modification History:
 *
 *  $Log: RetrieveLowestSequenceResponse.java,v $
 *  Revision 1.1  2011/11/03 23:42:55  mwkfh
 *  Initial
 *
 */
