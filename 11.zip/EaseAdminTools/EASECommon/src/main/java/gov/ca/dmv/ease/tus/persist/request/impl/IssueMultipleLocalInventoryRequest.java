/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2010
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueMultipleLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.service.ILocalPersistenceService;

/**
 * Description: I represent the request to retrieve inventory objects from the persistent store
 * File: IssueMultipleLocalInventoryRequest.java
 * Module:  gov.ca.dmv.ease.tus.persist.request.impl
 * Created: Dec 4, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/12/05 00:03:17 $
 * Last Changed By: $Author: mwkfh $
 */
public class IssueMultipleLocalInventoryRequest extends
		PersistenceServiceRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3102898439725536915L;
	/** The domain object. */
	private IInventoryItem inventoryItem;
	/** The quantity */
	private int quantity = 1;

	/**
	 * Instantiates a new issue local inventory business object request.
	 * 
	 * @param userContext the user context
	 * @param businessObject the business object
	 */
	public IssueMultipleLocalInventoryRequest(IUserContext userContext,
			IInventoryItem inventoryItem, int quantity) {
		super(userContext);
		setInventoryItem(inventoryItem);
		setQuantity(quantity);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.tus.persist.request.PersistenceServiceRequest#execute()
	 */
	@Override
	public IssueMultipleLocalInventoryResponse execute() {
		return ((ILocalPersistenceService) getPersistenceService())
				.execute(this);
	}

	/**
	 * This method gets the business object based on which the search has to be done.
	 * 
	 * @return the businessObject BusinessObject to be searched on
	 */
	public IInventoryItem getInventoryItem() {
		return inventoryItem;
	}

	/**
	 * Returns the quantity
	 * 
	 * @return int quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Sets the inventoryItem
	 *
	 * @param inventoryItem
	 */
	protected void setInventoryItem(IInventoryItem inventoryItem) {
		this.inventoryItem = inventoryItem;
	}

	/**
	 * Sets the quantity
	 *
	 * @param quantity
	 */
	protected void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
/**
 *  Modification History:
 *
 *  $Log: IssueMultipleLocalInventoryRequest.java,v $
 *  Revision 1.1  2010/12/05 00:03:17  mwkfh
 *  added IssueMultipleLocalInventoryReequest/Response
 *
 */
