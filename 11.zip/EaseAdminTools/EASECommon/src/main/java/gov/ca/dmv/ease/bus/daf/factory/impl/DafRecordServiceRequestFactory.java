/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.daf.factory.impl;

import gov.ca.dmv.ease.bus.daf.factory.IDafRecordServiceRequestFactory;
import gov.ca.dmv.ease.bus.daf.request.impl.PurgeDafRecordRequestBus;
import gov.ca.dmv.ease.fw.process.IUserContext;

/**
 * Description: I am the factory that creates requests for the DafRecordService.
 * 
 * File: DafServiceRequestFactory.java
 * Module:  gov.ca.dmv.ease.bus.daf.factory.impl
 * Created: Feb 17, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/02/18 01:01:23 $
 * Last Changed By: $Author: mwkfh $
 */
public class DafRecordServiceRequestFactory implements
		IDafRecordServiceRequestFactory {
	/** The SINGLETON. */
	private static IDafRecordServiceRequestFactory SINGLETON;

	/**
	 * Gets the single instance of DafRecordServiceRequestFactory.
	 * 
	 * @return single instance of DafRecordServiceRequestFactory
	 */
	public static IDafRecordServiceRequestFactory getInstance() {
		if (SINGLETON == null) {
			initSingleton();
		}
		return SINGLETON;
	}

	/**
	 * Inits the singleton.
	 */
	private static void initSingleton() {
		SINGLETON = new DafRecordServiceRequestFactory();
		//		SINGLETON = (IDafRecordServiceRequestFactory) EaseApplicationContext
		//				.getApplicationContext().getBean(
		//						"dafRecordServiceRequestFactory");
	}

	/**
	 * Instantiates a new DAF record service request factory.
	 */
	private DafRecordServiceRequestFactory() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IDafRecordServiceRequestFactory#createPurgeDafRecordRequestBus(gov.ca.dmv.ease.fw.process.IUserContext, Integer)
	 */
	public PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, Integer dafNumber) {
		return new PurgeDafRecordRequestBus(context, dafNumber);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IDafRecordServiceRequestFactory#createPurgeDafRecordRequestBus(gov.ca.dmv.ease.fw.process.IUserContext, Integer, boolean)
	 */
	public PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, Integer dafNumber, boolean isItHardDelete) {
		return new PurgeDafRecordRequestBus(context, dafNumber, isItHardDelete);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IDafRecordServiceRequestFactory#createPurgeDafRecordRequestBus(gov.ca.dmv.ease.fw.process.IUserContext, String)
	 */
	public PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, String dlNumber) {
		return new PurgeDafRecordRequestBus(context, dlNumber);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.factory.IDafRecordServiceRequestFactory#createPurgeDafRecordRequestBus(gov.ca.dmv.ease.fw.process.IUserContext, String, boolean)
	 */
	public PurgeDafRecordRequestBus createPurgeDafRecordRequestBus(
			IUserContext context, String dlNumber, boolean isItHardDelete) {
		return new PurgeDafRecordRequestBus(context, dlNumber, isItHardDelete);
	}
}
/**
 *  Modification History:
 *
 *  $Log: DafRecordServiceRequestFactory.java,v $
 *  Revision 1.1  2011/02/18 01:01:23  mwkfh
 *  added for use by purge daf service
 *
 */
