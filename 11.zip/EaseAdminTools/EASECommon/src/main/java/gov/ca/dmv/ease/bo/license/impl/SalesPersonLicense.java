/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.subject.impl.CustomerOrganization;

import java.util.Date;

/** 
 * Description: This represents the Sp License and it extends License 
 * and inherits the properties from License class.
 * File: SpLicense.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 7, 2010
 * @author mwvxm6
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2010/12/07 22:08:55 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SalesPersonLicense extends License {
	private static final long serialVersionUID = -8710409333923968119L;
	/** The Date the license Application Signed by the employer */
	private Date dateApplicationSigned;
	/** The vehicle sales firm (dealer) number/details. 
	 * CustomerOrganization attribute customerTypeCode is set to dealer*/
	private CustomerOrganization vehicleSalesOrganization;

	/**
	 * @return the employmentStartDate
	 */
	public Date getDateApplicationSigned() {
		return dateApplicationSigned;
	}

	/**
	 * The Employers License Number
	 * @return the employersLicenseNumber
	 */
	public String getEmployersLicenseNumber() {
		return getVehicleSalesOrganization().getLicenseNumber();
	}

	/**
	 * @return the firmNumber
	 */
	public String getFirmNumber() {
		return vehicleSalesOrganization.getOrganizationId();
	}

	/**
	 * @return the vehicleSalesOrg
	 */
	public CustomerOrganization getVehicleSalesOrganization() {
		return vehicleSalesOrganization;
	}

	/**
	 * @param employmentStartDate the employmentStartDate to set
	 */
	public void setDateApplicationSigned(Date employmentStartDate) {
		this.dateApplicationSigned = employmentStartDate;
	}

	/**
	 * @param vehicleSalesOrg the vehicleSalesOrg to set
	 */
	public void setVehicleSalesOrganization(CustomerOrganization vehicleSalesOrg) {
		this.vehicleSalesOrganization = vehicleSalesOrg;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.license.impl.License#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("dateApplicationSigned", dateApplicationSigned,
				anIndent, aBuilder);
		outputKeyValue("vehicleSalesOrganization", vehicleSalesOrganization,
				anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SalesPersonLicense.java,v $
 *  Revision 1.5  2010/12/07 22:08:55  mwpxp2
 *  Implemented ITreePrintable
 *
 */