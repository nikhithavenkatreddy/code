/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.citation.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * Description: This class is used to capture detail information of the citation.
 * File: CitationDetail.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 22, 2010
 * 
 * @author MWVXM6
 * @version $Revision: 1.40 $
 * Last Changed: $Date: 2010/11/19 19:04:09 $
 * Last Changed By: $Author: mwhys $
 */
public class CitationDetail implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7362110639418183007L;
	/** The amended Code. */
	private CodeSetElement amendedCode;
	/** The amended Date. */
	private Date amendedDate;
	/** The blood Alcohol Content. */
	private String bloodAlcoholContent;
	/** The conviction Date. */
	private Date convictionDate;
	/** The court code. */
	private CodeSetElement courtCode;
	/** The list of disposition codes (A - Dismissed, B - Bail forfeiter). */
	private List <CodeSetElement> dispositionCodes;
	/** The Docket Number. */
	private String docketNumber;
	/** The DUI probation Condition Codes. */
	private List <CodeSetElement> duiProbationConditionCodes;
	/** The total Fine Due. */
	private BigDecimal fineAmount;
	/** The jail Term. */
	private String jailTerm;
	/** The Probation Conditions. */
	private List <CodeSetElement> probationConditions;
	/** The probation Date. */
	private Date probationDate;
	/** The probation Term. */
	private String probationTerm;
	/** The restriction Date. */
	private Date restrictionDate;
	/** The restriction term. */
	private String restrictionTerm;
	/** The list of sections violated. */
	private List <SectionViolated> sectionsViolated;
	/** The indicator if selected For Payment. */
	private Boolean selectedForPayment = false;
	/** The suspension Date. */
	private Date suspensionDate;
	/** The suspension Term. */
	private String suspensionTerm;
	/** The Vehicle License Number. */
	private String existingVehicleLicenseNumber; // It is set by DLL response. Every FTA citation may or may not have existing vehicle license number.
	/** The Vehicle License Number. */
	private String vehicleLicenseNumber; // If user changes the vehicle license number on update screen, then it is populated to this variable.
	/** The violation Date. */
	private Date violationDate;
	/** The other address. */
	private Address otherAddress;
	/** The indicator if selected FTA or FTP is updated during the transaction. */
	private Boolean updated = false; // If citation is successfully updated, then this attribute is set to true.
	/** The fta citation. */
	private Boolean ftaCitation; // If citation record from is a type of FTA then it is set to true.
	/** The ftp citation. */
	private Boolean ftpCitation; // If citation record from is a type of FTP then it is set to true.
	/** The paid. */
	private Boolean isPaid = false;// If citation is paid then it is set to true.
	/** The aka name. */
	private PersonName akaName;
	/** The update code. */
	private String updateCode; // updated code from DCA/DCF Tcodes. If Citation is successfully updated then then updateCode=000/FTD/Hex(000)	
	/** The actual fee amount. */
	private BigDecimal actualFeeAmount; // This is populated by fee service
	/** The fee rate code for service fee amount. */
	private String feeRateCodeForServiceFeeAmount;// This is populated by fee service- fee rate code 790/791
	/** The service fee amount. */
	private BigDecimal serviceFeeAmount; // This is populated by fee service

	/**
	 * Gets the actual fee amount.
	 * 
	 * @return the actual fee amount
	 */
	public BigDecimal getActualFeeAmount() {
		return actualFeeAmount;
	}

	/**
	 * Sets the actual fee amount.
	 * 
	 * @param actualFeeAmount the new actual fee amount
	 */
	public void setActualFeeAmount(BigDecimal actualFeeAmount) {
		this.actualFeeAmount = actualFeeAmount;
	}

	/**
	 * Gets the fee rate code for service fee amount.
	 * 
	 * @return the fee rate code for service fee amount
	 */
	public String getFeeRateCodeForServiceFeeAmount() {
		return feeRateCodeForServiceFeeAmount;
	}

	/**
	 * Sets the fee rate code for service fee amount.
	 * 
	 * @param feeRateCodeForServiceFeeAmount the new fee rate code for service fee amount
	 */
	public void setFeeRateCodeForServiceFeeAmount(
			String feeRateCodeForServiceFeeAmount) {
		this.feeRateCodeForServiceFeeAmount = feeRateCodeForServiceFeeAmount;
	}

	/**
	 * Gets the service fee amount.
	 * 
	 * @return the service fee amount
	 */
	public BigDecimal getServiceFeeAmount() {
		return serviceFeeAmount;
	}

	/**
	 * Sets the service fee amount.
	 * 
	 * @param serviceFeeAmount the new service fee amount
	 */
	public void setServiceFeeAmount(BigDecimal serviceFeeAmount) {
		this.serviceFeeAmount = serviceFeeAmount;
	}

	/**
	 * Gets the update code.
	 * 
	 * @return the update code
	 */
	public String getUpdateCode() {
		return updateCode;
	}

	/**
	 * Sets the update code.
	 * 
	 * @param updateCode the new update code
	 */
	public void setUpdateCode(String updateCode) {
		this.updateCode = updateCode;
	}

	/**
	 * Gets the aka name.
	 * 
	 * @return the aka name
	 */
	public PersonName getAkaName() {
		return akaName;
	}

	/**
	 * Sets the aka name.
	 * 
	 * @param akaName the new aka name
	 */
	public void setAkaName(PersonName akaName) {
		this.akaName = akaName;
	}

	/**
	 * Gets the paid.
	 * 
	 * @return the paid
	 */
	public Boolean hasBeenPaid() {
		return isPaid;
	}

	/**
	 * Sets the paid.
	 * 
	 * @param isPaid the new paid
	 */
	public void setPaid(Boolean isPaid) {
		this.isPaid = isPaid;
	}

	/**
	 * Gets the fta citation.
	 * 
	 * @return the fta citation
	 */
	public Boolean getFtaCitation() {
		return ftaCitation;
	}

	/**
	 * Sets the fta citation.
	 * 
	 * @param ftaCitation the new fta citation
	 */
	public void setFtaCitation(Boolean ftaCitation) {
		this.ftaCitation = ftaCitation;
	}

	/**
	 * Gets the ftp citation.
	 * 
	 * @return the ftp citation
	 */
	public Boolean getFtpCitation() {
		return ftpCitation;
	}

	/**
	 * Sets the ftp citation.
	 * 
	 * @param ftpCitation the new ftp citation
	 */
	public void setFtpCitation(Boolean ftpCitation) {
		this.ftpCitation = ftpCitation;
	}

	/**
	 * Sets the other address.
	 * 
	 * @param otherAddress the otherAddress to set
	 */
	public void setOtherAddress(Address otherAddress) {
		this.otherAddress = otherAddress;
	}

	/**
	 * Gets the other address.
	 * 
	 * @return the otherAddress
	 */
	public Address getOtherAddress() {
		return otherAddress;
	}

	/**
	 * Gets the amended code.
	 * 
	 * @return the amendedCode
	 */
	public CodeSetElement getAmendedCode() {
		return amendedCode;
	}

	/**
	 * Gets the amended date.
	 * 
	 * @return the amendedDate
	 */
	public Date getAmendedDate() {
		return amendedDate;
	}

	/**
	 * Gets the blood alcohol content.
	 * 
	 * @return the bloodAlcoholContent
	 */
	public String getBloodAlcoholContent() {
		return bloodAlcoholContent;
	}

	/**
	 * Gets the conviction date.
	 * 
	 * @return the convictionDate
	 */
	public Date getConvictionDate() {
		return convictionDate;
	}

	/**
	 * Gets the court code.
	 * 
	 * @return the courtCode
	 */
	public CodeSetElement getCourtCode() {
		return courtCode;
	}

	/**
	 * Gets the disposition codes.
	 * 
	 * @return the dispositionCodes
	 */
	public List <CodeSetElement> getDispositionCodes() {
		return dispositionCodes;
	}

	/**
	 * Gets the docket number.
	 * 
	 * @return the docketNumber
	 */
	public String getDocketNumber() {
		return docketNumber;
	}

	/**
	 * Gets the dui probation condition codes.
	 * 
	 * @return the duiProbationConditionCodes
	 */
	public List <CodeSetElement> getDuiProbationConditionCodes() {
		return duiProbationConditionCodes;
	}

	/**
	 * Gets the fine amount.
	 * 
	 * @return the fineAmount
	 */
	public BigDecimal getFineAmount() {
		return fineAmount;
	}

	/**
	 * Gets the jail term.
	 * 
	 * @return the jailTerm
	 */
	public String getJailTerm() {
		return jailTerm;
	}

	/**
	 * Gets the Probation Conditions.
	 * 
	 * @return the probationConditions
	 */
	public List <CodeSetElement> getProbationConditions() {
		return this.probationConditions;
	}

	/**
	 * Gets the probation date.
	 * 
	 * @return the probationDate
	 */
	public Date getProbationDate() {
		return probationDate;
	}

	/**
	 * Gets the probation term.
	 * 
	 * @return the probationTerm
	 */
	public String getProbationTerm() {
		return probationTerm;
	}

	/**
	 * Gets the restriction term.
	 * 
	 * @return the restrictionTerm
	 */
	public String getRestrictionTerm() {
		return restrictionTerm;
	}

	/**
	 * Gets the sections violated.
	 * 
	 * @return the sectionsViolated
	 */
	public List <SectionViolated> getSectionsViolated() {
		return sectionsViolated;
	}

	/**
	 * Gets the suspension date.
	 * 
	 * @return the suspensionDate
	 */
	public Date getSuspensionDate() {
		return suspensionDate;
	}

	/**
	 * Gets the suspension term.
	 * 
	 * @return the suspensionTerm
	 */
	public String getSuspensionTerm() {
		return suspensionTerm;
	}

	/**
	 * Gets the Vehicle License Number.
	 * 
	 * @return the vehicleLicenseNumber
	 */
	public String getVehicleLicenseNumber() {
		return this.vehicleLicenseNumber;
	}

	/**
	 * Gets the violation date.
	 * 
	 * @return the violationDate
	 */
	public Date getViolationDate() {
		return violationDate;
	}

	/**
	 * Checks if is selected for payment.
	 * 
	 * @return the selectedForPayment
	 */
	public boolean isSelectedForPayment() {
		return selectedForPayment;
	}

	/**
	 * Sets the amended code.
	 * 
	 * @param amendedCode the amendedCode to set
	 */
	public void setAmendedCode(CodeSetElement amendedCode) {
		this.amendedCode = amendedCode;
	}

	/**
	 * Sets the amended date.
	 * 
	 * @param amendedDate the amendedDate to set
	 */
	public void setAmendedDate(Date amendedDate) {
		this.amendedDate = amendedDate;
	}

	/**
	 * Sets the blood alcohol content.
	 * 
	 * @param bloodAlcoholContent the bloodAlcoholContent to set
	 */
	public void setBloodAlcoholContent(String bloodAlcoholContent) {
		this.bloodAlcoholContent = bloodAlcoholContent;
	}

	/**
	 * Sets the conviction date.
	 * 
	 * @param convictionDate the convictionDate to set
	 */
	public void setConvictionDate(Date convictionDate) {
		this.convictionDate = convictionDate;
	}

	/**
	 * Sets the court code.
	 * 
	 * @param courtCode the courtCode to set
	 */
	public void setCourtCode(CodeSetElement courtCode) {
		this.courtCode = courtCode;
	}

	/**
	 * Sets the disposition codes.
	 * 
	 * @param dispositionCodes the dispositionCodes to set
	 */
	public void setDispositionCodes(List <CodeSetElement> dispositionCodes) {
		this.dispositionCodes = dispositionCodes;
	}

	/**
	 * Sets the docket number.
	 * 
	 * @param docketNumber the docketNumber to set
	 */
	public void setDocketNumber(String docketNumber) {
		this.docketNumber = docketNumber;
	}

	/**
	 * Sets the dui probation condition codes.
	 * 
	 * @param duiProbationConditionCodes the duiProbationConditionCodes to set
	 */
	public void setDuiProbationConditionCodes(
			List <CodeSetElement> duiProbationConditionCodes) {
		this.duiProbationConditionCodes = duiProbationConditionCodes;
	}

	/**
	 * Sets the fine amount.
	 * 
	 * @param fineAmount the fineAmount to set
	 */
	public void setFineAmount(BigDecimal fineAmount) {
		this.fineAmount = fineAmount;
	}

	/**
	 * Sets the jail term.
	 * 
	 * @param jailTerm the jailTerm to set
	 */
	public void setJailTerm(String jailTerm) {
		this.jailTerm = jailTerm;
	}

	/**
	 * Sets the Probation Conditions.
	 * 
	 * @param probationConditions the probationConditions to set
	 */
	public void setProbationConditions(List <CodeSetElement> probationConditions) {
		this.probationConditions = probationConditions;
	}

	/**
	 * Sets the probation date.
	 * 
	 * @param probationDate the probationDate to set
	 */
	public void setProbationDate(Date probationDate) {
		this.probationDate = probationDate;
	}

	/**
	 * Sets the probation term.
	 * 
	 * @param probationTerm the probationTerm to set
	 */
	public void setProbationTerm(String probationTerm) {
		this.probationTerm = probationTerm;
	}

	/**
	 * Sets the restriction term.
	 * 
	 * @param restrictionTerm the restrictionTerm to set
	 */
	public void setRestrictionTerm(String restrictionTerm) {
		this.restrictionTerm = restrictionTerm;
	}

	/**
	 * Sets the sections violated.
	 * 
	 * @param sectionsViolated the sectionsViolated to set
	 */
	public void setSectionsViolated(List <SectionViolated> sectionsViolated) {
		this.sectionsViolated = sectionsViolated;
	}

	/**
	 * Sets the selected for payment.
	 * 
	 * @param selectedForPayment the selectedForPayment to set
	 */
	public void setSelectedForPayment(boolean selectedForPayment) {
		this.selectedForPayment = selectedForPayment;
	}

	/**
	 * Sets the suspension date.
	 * 
	 * @param suspensionDate the suspensionDate to set
	 */
	public void setSuspensionDate(Date suspensionDate) {
		this.suspensionDate = suspensionDate;
	}

	/**
	 * Sets the suspension term.
	 * 
	 * @param suspensionTerm the suspensionTerm to set
	 */
	public void setSuspensionTerm(String suspensionTerm) {
		this.suspensionTerm = suspensionTerm;
	}

	/**
	 * Sets the Vehicle License Number.
	 * 
	 * @param vehicleLicenseNumber the vehicleLicenseNumber to set
	 */
	public void setVehicleLicenseNumber(String vehicleLicenseNumber) {
		this.vehicleLicenseNumber = vehicleLicenseNumber;
	}

	/**
	 * Gets the existing vehicle license number.
	 * 
	 * @return the existing vehicle license number
	 */
	public String getExistingVehicleLicenseNumber() {
		return existingVehicleLicenseNumber;
	}

	/**
	 * Sets the existing vehicle license number.
	 * 
	 * @param existingVehicleLicenseNumber the new existing vehicle license number
	 */
	public void setExistingVehicleLicenseNumber(
			String existingVehicleLicenseNumber) {
		this.existingVehicleLicenseNumber = existingVehicleLicenseNumber;
	}

	/**
	 * Sets the violation date.
	 * 
	 * @param violationDate the violationDate to set
	 */
	public void setViolationDate(Date violationDate) {
		this.violationDate = violationDate;
	}

	/**
	 * Checks if is updated.
	 * 
	 * @return true, if is updated
	 */
	public boolean isUpdated() {
		return updated;
	}

	/**
	 * Sets the updated.
	 * 
	 * @param updated the new updated
	 */
	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	/**
	 * Gets the restriction date.
	 * 
	 * @return the restriction date
	 */
	public Date getRestrictionDate() {
		return restrictionDate;
	}

	/**
	 * Sets the restriction date.
	 * 
	 * @param restrictionDate the new restriction date
	 */
	public void setRestrictionDate(Date restrictionDate) {
		this.restrictionDate = restrictionDate;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CitationDetail.java,v $
 *  Revision 1.40  2010/11/19 19:04:09  mwhys
 *  implements Serializable
 *
 *  Revision 1.39  2010/11/19 00:04:20  mwtjc1
 *  actualFeeAmount added
 *
 *  Revision 1.38  2010/11/18 23:52:21  mwtjc1
 *  java doc added
 *
 *  Revision 1.37  2010/11/18 23:50:02  mwtjc1
 *  feeRateCodeForServiceFeeAmount and serviceFeeAmount added
 *
 *  Revision 1.36  2010/11/18 23:14:11  mwtjc1
 *  java doc added
 *
 *  Revision 1.35  2010/11/18 23:13:46  mwtjc1
 *  actualFineAmount and actualServiceFeeAmount added
 *
 *  Revision 1.34  2010/09/24 17:54:22  mwhys
 *  refactored getPaid() method to hasBeenPaid().
 *
 *  Revision 1.33  2010/09/20 19:28:25  mwazg5
 *  Removed getPayCode,setPayCode and getUpdateDisplayCode functions
 *
 *  Revision 1.32  2010/09/13 22:04:57  mwtjc1
 *  comment for setPayCode added
 *
 *  Revision 1.31  2010/09/13 18:13:37  mwazg5
 *  Added setPayCode function
 *
 *  Revision 1.30  2010/09/13 17:31:46  mwtjc1
 *  constants added
 *
 *  Revision 1.29  2010/09/11 21:32:35  mwtjc1
 *  getUpdateDisplayCode and getPayCode added
 *
 *  Revision 1.28  2010/09/11 18:56:50  mwtjc1
 *  comment added
 *
 *  Revision 1.27  2010/09/11 18:53:41  mwtjc1
 *  comment added
 *
 *  Revision 1.26  2010/09/10 20:57:19  mwtjc1
 *  restriction date is made date instead of string
 *
 *  Revision 1.25  2010/09/10 16:13:19  mwtjc1
 *  currentVehicleLicenseNumber is changed to existingVehicleLicenseNumber
 *
 *  Revision 1.23  2010/09/09 22:34:53  mwtjc1
 *  currentVehicleLicenseNumber added
 *
 *  Revision 1.21  2010/09/07 21:35:38  mwtjc1
 *  updated is initialized to false
 *
 *  Revision 1.20  2010/09/07 21:30:56  mwtjc1
 *  updateCode added
 *
 *  Revision 1.19  2010/09/07 20:58:56  mwtjc1
 *  akaName added
 *
 *  Revision 1.18  2010/09/07 15:46:11  mwhys
 *  Added CVS footer.
 *
 *  
 */
