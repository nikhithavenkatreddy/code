/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.transientobj.impl;

import gov.ca.dmv.ease.bo.financial.impl.Voucher;

/**
 * Description: The Voucher and its Return Code after the service call
 * File: VoucherReturnCode.java
 * Module:  gov.ca.dmv.ease.bo.transientobj.impl
 * Created: Mar 9, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/07/22 17:50:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class VoucherReturnCode {
	/** The Error Code after the service call. */
	private ReturnCode errorCode;
	/** The inquired voucher */
	private Voucher inquiredVoucher;
	/** The Return Code after the service call. */
	private ReturnCode returnCode;
	/** The validated voucher. */
	private Voucher validatedVoucher;

	/**
	 * @return the errorCode
	 */
	public ReturnCode getErrorCode() {
		return errorCode;
	}

	/**
	 * Get the inquired voucher.
	 * 
	 * @return the inquiredVoucher
	 */
	public Voucher getInquiredVoucher() {
		return inquiredVoucher;
	}

	/**
	 * @return the returnCode
	 */
	public ReturnCode getReturnCode() {
		return returnCode;
	}

	/**
	 * Get validated voucher.
	 * 
	 * @return the validated voucher
	 */
	public Voucher getValidatedVoucher() {
		return validatedVoucher;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(ReturnCode errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Set the inquired voucher.
	 * 
	 * @param inquiredVoucher the inquiredVoucher to set
	 */
	public void setInquiredVoucher(Voucher anInquiredVoucher) {
		inquiredVoucher = anInquiredVoucher;
	}

	/**
	 * @param returnCode the returnCode to set
	 */
	public void setReturnCode(ReturnCode returnCode) {
		this.returnCode = returnCode;
	}

	/**
	 *  Set validated voucher.
	 *  
	 * @param voucher the validated voucher to set
	 */
	public void setValidatedVoucher(Voucher aValidatedVoucher) {
		validatedVoucher = aValidatedVoucher;
	}
}
