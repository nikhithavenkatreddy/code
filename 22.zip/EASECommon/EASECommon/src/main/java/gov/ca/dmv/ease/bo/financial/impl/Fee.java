/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.financial.IFee;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;

import java.math.BigDecimal;

/**
 * Description: This is a fee class and it represents fee Amount.
 * File: Fee.java
 * Module:  gov.ca.dmv.ease.bo.financial.impl
 * Created: Apr 28, 2009
 * 
 * @author MWCSJ3
 * @version $Revision: 1.9 $
 * Last Changed: $Date: 2012/09/15 00:41:57 $
 * Last Changed By: $Author: mwhys $
 */
public class Fee extends BusinessObject implements IFee {
	/** Action code constant to represent NO PAYMENT. */
	public static final String ACTION_CODE_N = "N";
	/** Action code constant to represent PAY. */
	public static final String ACTION_CODE_P = "P";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8107817578015113069L;
	/** The action code. */
	private String actionCode;
	/** The amount. */
	private BigDecimal amount;
	/** The fee type. */
	private String feeType; //FIXME should be enum
	/** Rate Code. */
	private String rateCode; //FIXME should be enum
	
	/**
	 * Default Constructor.
	 */
	@Deprecated
	public Fee() {
		//FIXME reduce visibility
		//Empty Constructor // - but why?
	}
	
	/**
	 * Instantiates a new fee.
	 *
	 * @param fee the fee
	 */
	public Fee(Fee fee) {
		super();
		copy(fee);
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#copy(gov.ca.dmv.ease.bo.impl.BusinessObject)
	 */
	@Override
	protected void copy(BusinessObject dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null Fee argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		Fee fee = (Fee) dataToCopy;
		//Copy actionCode
		if (isNotNull(fee.getActionCode())) {
			setActionCode(fee.getActionCode());
		}
		//Copy amount
		if (isNotNull(fee.getAmount())) {
			setAmount(new BigDecimal(fee.getAmount().doubleValue()));
		}
		else {
			setAmount(null);
		}
		//Copy feeType
		if (isNotNull(fee.getFeeType())) {
			setFeeType(fee.getFeeType());
		}
		//Copy rateCode
		if (isNotNull(fee.getRateCode())) {
			setRateCode(fee.getRateCode());
		}
	}
	
	/**
	 * Instantiates a new fee.
	 *
	 * @param anAmount the an amount
	 */
	public Fee(BigDecimal anAmount) {
		super();
		setAmount(anAmount);
	}
	
	/**
	 * Instantiates a new fee.
	 *
	 * @param anAmount the an amount
	 */
	public Fee(Double anAmount) {
		super();
		setAmount(new BigDecimal(anAmount));
	}
	
	/**
	 * Instantiates a new fee.
	 *
	 * @param anAmount the an amount
	 */
	public Fee(int anAmount) {
		super();
		setAmount(new BigDecimal(anAmount));
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Fee other = (Fee) obj;
		if (amount == null) {
			if (other.amount != null) {
				return false;
			}
		}
		else if (!amount.equals(other.amount)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Gets the action code.
	 * 
	 * @return the actionCode
	 */
	public String getActionCode() {
		return actionCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IFee#getAmount()
	 */
	public BigDecimal getAmount() {
		return amount;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IFee#getFeeType()
	 */
	public String getFeeType() {
		return feeType;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.financial.impl.IFee#getRateCode()
	 */
	public String getRateCode() {
		return rateCode;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		return result;
	}
	
	/**
	 * Sets the action code.
	 * 
	 * @param actionCode the actionCode to set
	 */
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	
	/**
	 * Sets the amount.
	 * 
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	/**
	 * Sets the fee type.
	 * 
	 * @param feeType the feeType to set
	 */
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	
	/**
	 * Sets the rate code.
	 *
	 * @param rateCode the rateCode to set
	 */
	public void setRateCode(String rateCode) {
		this.rateCode = rateCode;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("amount", amount, anIndent, aBuilder);
		outputKeyValue("feeType", feeType, anIndent, aBuilder);
		outputKeyValue("actionCode", actionCode, anIndent, aBuilder);
		outputKeyValue("rateCode", rateCode, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Fee.java,v $
 *  Revision 1.9  2012/09/15 00:41:57  mwhys
 *  Added copy constructor. (Defect 6900 - AN fatal)
 *
 *  Revision 1.8  2011/10/21 22:25:55  mwpxp2
 *  Implemented extracted interface; added contructors/1; cleaned up; requires mods of visibility of public setters
 *
 *  Revision 1.7  2010/12/16 21:17:14  mwpxr4
 *  Added rateCode in fee.
 *
 *  Revision 1.6  2010/12/07 22:08:32  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.5  2010/12/07 03:03:13  mwpxp2
 *  Added toStringOn/1; sorted
 *
 *  Revision 1.4  2010/10/19 22:33:10  mwhys
 *  Added 2 constant fields: ACTION_CODE_P and ACTION_CODE_N.
 *
 *  Revision 1.3  2010/10/14 16:47:11  mwrrv3
 *  Added new attributes to support generate fee page.
 *
 *  Revision 1.2  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.5  2010/03/17 22:59:29  mwhxa2
 *  Created DriverLicenseFee, DriverLicenseRateStatus and updated Fee.
 *
 *  Revision 1.4  2010/03/10 01:39:45  mwhxa2
 *  Changed from code set element to fee rate code
 *
 *  Revision 1.3  2010/01/28 19:53:51  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/09/13 20:45:32  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.5.2.1  2009/09/12 19:08:44  mwakg
 *  Removed CodeSetElement sub classes
 *
 *  Revision 1.5  2009/08/27 05:39:43  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2009/08/22 23:21:46  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.3  2009/08/03 20:41:34  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.2  2009/07/14 23:44:36  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 07:35:17  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
