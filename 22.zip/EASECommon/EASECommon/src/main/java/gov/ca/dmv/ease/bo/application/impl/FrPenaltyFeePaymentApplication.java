/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

import java.util.List;

/**
 * Description: This class captures information pertaining to the Penalty Fee Payment if a license holder
 * does not have proof of financial responsibility
 * File: FrPenaltyFeePayment.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2012/03/14 01:57:56 $
 * Last Changed By: $Author: mwxxw $
 */
public class FrPenaltyFeePaymentApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3043308844319168678L;
	/** This represents the collecting fee for restriction - E, T, S, F 
	 * Currently 4 are on the screen*/
	private List <CodeSetElement> frPenaltyFeeTypeCodes;

	/**
	 * Instantiates a new application.
	 */
	public FrPenaltyFeePaymentApplication() {
		super();
		setFeeRequired(true);
	}

	/**
	 * @return the frPenaltyFeeTypeCodes
	 */
	public List <CodeSetElement> getFrPenaltyFeeTypeCodes() {
		return frPenaltyFeeTypeCodes;
	}

	/**
	 * @param frPenaltyFeeTypeCodes the frPenaltyFeeTypeCodes to set
	 */
	public void setFrPenaltyFeeTypeCodes(
			List <CodeSetElement> frPenaltyFeeTypeCodes) {
		this.frPenaltyFeeTypeCodes = frPenaltyFeeTypeCodes;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: FrPenaltyFeePaymentApplication.java,v $
 *  Revision 1.5  2012/03/14 01:57:56  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.4  2011/01/29 22:51:55  mwrrv2
 *  Initializing isFeeRequired to true in the constructor.
 *
 *  Revision 1.3  2010/09/10 22:23:07  mwrrv3
 *  Added log at the end.
 *
 */
