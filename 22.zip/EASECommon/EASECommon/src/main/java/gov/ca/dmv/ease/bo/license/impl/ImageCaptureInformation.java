package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

import java.util.Date;

/**
 * Description: This class holds L1 Server Image Related Information.
 * This corresponding table records the image information messages received from the L1 server.
 * It provides notification of Fingerprint and Photo capture operations on the L1 server
 * File: ImageCaptureInformation.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 21, 2010
 * @author MWVXM6
 * @version $Revision: 1.6 $
 * Last Changed: $Date: 2011/01/22 22:49:11 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ImageCaptureInformation extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3410040368329578133L;
	//private String transactionId = null;
	// The active Directory Id
	/** The active directory id. */
	private String activeDirectoryId = null;
	/*	 The application Type
	 * 	 "D" - Driver License
		 "I" - Identification Card
		 "S" - Salesperson*/
	/** The application type. */
	private String applicationType = null;
	/*	 The digit Captured by the fingerprint scan
	 * 	 0 = RIGHT THUMB    5 = LEFT THUMB
		 1 = RIGHT INDEX    6 = LEFT INDEX
		 2 = RIGHT MIDDLE   7 = LEFT MIDDLE
		 3 = RIGHT RING     8 = LEFT RING
		 4 = RIGHT LITTLE   9 = LEFT LITTLE
		 N = NO DIGITS PRESENT*/
	/** The digit captured. */
	private String digitCaptured = null;
	//private String fingerprintCaptureTime;
	//private String scannerId;
	/*	 The employee Authorization Code
	* 	 "P" - Primary
	 "S" - Secondary
	 "A" - Password*/
	/** The employee authorization code. */
	private String employeeAuthorizationCode = null;
	// The tech id
	/** The employee id. */
	private String employeeId = null;
	/** The fingerprint match indicator. */
	private String fingerprintMatchIndicator = null;
	/*	 "1" - Meets Threshold
		 "2" - Below Threshold
		 "3" - Meets Threshold at ICS
		 "4" - Below Threshold at ICS*/
	/** The fingerprint quality indicator. */
	private String fingerprintQualityIndicator = null;
	/** The fingerprint scanner indicator. */
	private String fingerprintScannerId = null;
	/*	The image Capture Match Indicator
	 *   "Y" � Fingerprint/Photo matched
		 "N" - Fingerprint/Photo did not match
		 "C" - CAN (not referenced in DMVA)
		 "U" - Unavailable (L1 Server can not communicate with fingerprint scanner)
		 "M" - Molokan (not used in DMVA)*/
	/** The image capture match indicator. */
	private String imageCaptureMatchIndicator = null;
	//private String photoMatchIndicator= null;
	// The CAMERA STATION ID for Photo or SCANNER ID for Fingerprint
	/** The image capture station id. */
	private String imageCaptureStationId = null;
	//	 Timestamp of image capture
	/** The image capture time stamp. */
	private Date imageCaptureTimeStamp = null;
	// Location Key to application in process.
	/** The license number. */
	private String licenseNumber = null;
	// The Office where Photo taken
	/** The photo office number. */
	private String photoOfficeNumber = null;
	//  The photo Override Indicator which can be "Y" or 	" "
	/** The photo override indicator. */
	private String photoOverrideIndicator = null;
	//	 The Photo sequence number
	/** The photo sequence number. */
	private String photoSequenceNumber = null;
	/*	 The queue Selection Method
	*   "F" - Fingerprint
	 "B" - Barcode
	 "N" - DL/ID Number*/
	/** The queue selection method. */
	private String queueSelectionMethod = null;
	/*	 The type of responsece message received from L1
	* 	 "R" - Fingerprint Response
	 "D" - Photo Complete
	 "L" - Photo Lock
	 "U" - Photo Unlock*/
	/** The type message request. */
	private String typeMessageRequest = null;

	/**
	 * Gets the active directory id.
	 *
	 * @return the active directory id
	 */
	public String getActiveDirectoryId() {
		return activeDirectoryId;
	}

	/**
	 * Gets the application type.
	 *
	 * @return the application type
	 */
	public String getApplicationType() {
		return applicationType;
	}

	/**
	 * Gets the digit captured.
	 *
	 * @return the digit captured
	 */
	public String getDigitCaptured() {
		return digitCaptured;
	}

	/**
	 * Gets the employee authorization code.
	 *
	 * @return the employee authorization code
	 */
	public String getEmployeeAuthorizationCode() {
		return employeeAuthorizationCode;
	}

	/**
	 * Gets the employee id.
	 *
	 * @return the employee id
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * Gets the fingerprint match indicator.
	 *
	 * @return the fingerprintMatchIndicator
	 */
	public String getFingerprintMatchIndicator() {
		return fingerprintMatchIndicator;
	}

	/**
	 * Gets the fingerprint quality indicator.
	 *
	 * @return the fingerprint quality indicator
	 */
	public String getFingerprintQualityIndicator() {
		return fingerprintQualityIndicator;
	}

	/**
	 * Gets the fingerprint scanner id.
	 *
	 * @return the fingerprintScannerId
	 */
	public String getFingerprintScannerId() {
		return fingerprintScannerId;
	}

	/**
	 * Gets the image capture match indicator.
	 *
	 * @return the image capture match indicator
	 */
	public String getImageCaptureMatchIndicator() {
		return imageCaptureMatchIndicator;
	}

	/**
	 * Gets the image capture station id.
	 *
	 * @return the image capture station id
	 */
	public String getImageCaptureStationId() {
		return imageCaptureStationId;
	}

	/**
	 * Gets the image capture time stamp.
	 *
	 * @return the image capture time stamp
	 */
	public Date getImageCaptureTimeStamp() {
		return imageCaptureTimeStamp;
	}

	/**
	 * Gets the license number.
	 *
	 * @return the license number
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}

	/**
	 * Gets the photo office number.
	 *
	 * @return the photo office number
	 */
	public String getPhotoOfficeNumber() {
		return photoOfficeNumber;
	}

	/**
	 * Gets the photo override indicator.
	 *
	 * @return the photo override indicator
	 */
	public String getPhotoOverrideIndicator() {
		return photoOverrideIndicator;
	}

	/**
	 * Gets the photo sequence number.
	 *
	 * @return the photo sequence number
	 */
	public String getPhotoSequenceNumber() {
		return photoSequenceNumber;
	}

	/**
	 * Gets the queue selection method.
	 *
	 * @return the queue selection method
	 */
	public String getQueueSelectionMethod() {
		return queueSelectionMethod;
	}

	/**
	 * Gets the type message request.
	 *
	 * @return the type message request
	 */
	public String getTypeMessageRequest() {
		return typeMessageRequest;
	}

	/**
	 * Sets the active directory id.
	 *
	 * @param activeDirectoryId the new active directory id
	 */
	public void setActiveDirectoryId(String activeDirectoryId) {
		this.activeDirectoryId = activeDirectoryId;
	}

	/**
	 * Sets the application type.
	 *
	 * @param applicationType the new application type
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	/**
	 * Sets the digit captured.
	 *
	 * @param digitCaptured the new digit captured
	 */
	public void setDigitCaptured(String digitCaptured) {
		this.digitCaptured = digitCaptured;
	}

	/**
	 * Sets the employee authorization code.
	 *
	 * @param employeeAuthorizationCode the new employee authorization code
	 */
	public void setEmployeeAuthorizationCode(String employeeAuthorizationCode) {
		this.employeeAuthorizationCode = employeeAuthorizationCode;
	}

	/**
	 * Sets the employee id.
	 *
	 * @param employeeId the new employee id
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * Sets the fingerprint match indicator.
	 *
	 * @param fingerprintMatchIndicator the fingerprintMatchIndicator to set
	 */
	public void setFingerprintMatchIndicator(String fingerprintMatchIndicator) {
		this.fingerprintMatchIndicator = fingerprintMatchIndicator;
	}

	/**
	 * Sets the fingerprint quality indicator.
	 *
	 * @param fingerprintQualityIndicator the new fingerprint quality indicator
	 */
	public void setFingerprintQualityIndicator(
			String fingerprintQualityIndicator) {
		this.fingerprintQualityIndicator = fingerprintQualityIndicator;
	}

	/**
	 * Sets the fingerprint scanner id.
	 *
	 * @param fingerprintScannerId the fingerprintScannerId to set
	 */
	public void setFingerprintScannerId(String fingerprintScannerId) {
		this.fingerprintScannerId = fingerprintScannerId;
	}

	/**
	 * Sets the image capture match indicator.
	 *
	 * @param imageCaptureMatchIndicator the new image capture match indicator
	 */
	public void setImageCaptureMatchIndicator(String imageCaptureMatchIndicator) {
		this.imageCaptureMatchIndicator = imageCaptureMatchIndicator;
	}

	/**
	 * Sets the image capture station id.
	 *
	 * @param imageCaptureStationId the new image capture station id
	 */
	public void setImageCaptureStationId(String imageCaptureStationId) {
		this.imageCaptureStationId = imageCaptureStationId;
	}

	/**
	 * Sets the image capture time stamp.
	 *
	 * @param imageCaptureTimeStamp the new image capture time stamp
	 */
	public void setImageCaptureTimeStamp(Date imageCaptureTimeStamp) {
		this.imageCaptureTimeStamp = imageCaptureTimeStamp;
	}

	/**
	 * Sets the license number.
	 *
	 * @param dlIdNumber the new license number
	 */
	public void setLicenseNumber(String dlIdNumber) {
		this.licenseNumber = dlIdNumber;
	}

	/**
	 * Sets the photo office number.
	 *
	 * @param photoOfficeNumber the new photo office number
	 */
	public void setPhotoOfficeNumber(String photoOfficeNumber) {
		this.photoOfficeNumber = photoOfficeNumber;
	}

	/**
	 * Sets the photo override indicator.
	 *
	 * @param photoOverrideIndicator the new photo override indicator
	 */
	public void setPhotoOverrideIndicator(String photoOverrideIndicator) {
		this.photoOverrideIndicator = photoOverrideIndicator;
	}

	/**
	 * Sets the photo sequence number.
	 *
	 * @param photoSequenceNumber the new photo sequence number
	 */
	public void setPhotoSequenceNumber(String photoSequenceNumber) {
		this.photoSequenceNumber = photoSequenceNumber;
	}

	/**
	 * Sets the queue selection method.
	 *
	 * @param queueSelectionMethod the new queue selection method
	 */
	public void setQueueSelectionMethod(String queueSelectionMethod) {
		this.queueSelectionMethod = queueSelectionMethod;
	}

	/**
	 * Sets the type message request.
	 *
	 * @param typeMessageRequest the new type message request
	 */
	public void setTypeMessageRequest(String typeMessageRequest) {
		this.typeMessageRequest = typeMessageRequest;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("activeDirectoryId", activeDirectoryId, anIndent,
				aBuilder);
		outputKeyValue("applicationType", applicationType, anIndent, aBuilder);
		outputKeyValue("digitCaptured", digitCaptured, anIndent, aBuilder);
		outputKeyValue("employeeAuthorizationCode", employeeAuthorizationCode,
				anIndent, aBuilder);
		outputKeyValue("employeeId", employeeId, anIndent, aBuilder);
		outputKeyValue("fingerprintQualityIndicator",
				fingerprintQualityIndicator, anIndent, aBuilder);
		outputKeyValue("imageCaptureMatchIndicator",
				imageCaptureMatchIndicator, anIndent, aBuilder);
		outputKeyValue("imageCaptureStationId", imageCaptureStationId,
				anIndent, aBuilder);
		outputKeyValue("imageCaptureTimeStamp", imageCaptureTimeStamp,
				anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("photoOfficeNumber", photoOfficeNumber, anIndent,
				aBuilder);
		outputKeyValue("photoOverrideIndicator", photoOverrideIndicator,
				anIndent, aBuilder);
		outputKeyValue("photoSequenceNumber", photoSequenceNumber, anIndent,
				aBuilder);
		outputKeyValue("queueSelectionMethod", queueSelectionMethod, anIndent,
				aBuilder);
		outputKeyValue("typeMessageRequest", typeMessageRequest, anIndent,
				aBuilder);
		outputKeyValue("fingerprintMatchIndicator", fingerprintMatchIndicator,
				anIndent, aBuilder);
		outputKeyValue("fingerprintScannerId", fingerprintScannerId, anIndent,
				aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ImageCaptureInformation.java,v $
 *  Revision 1.6  2011/01/22 22:49:11  mwpxp2
 *  Added missing javadoc; sorted
 *
 *  Revision 1.5  2010/12/28 02:58:15  mwpxr4
 *  Added fingerprint scanner id and match indicator.
 *
 *  Revision 1.4  2010/12/07 22:08:54  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.3  2010/12/07 03:56:08  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.2  2010/10/15 23:02:19  mwvxm6
 *  Update attribute name
 *
 *  Revision 1.1  2010/10/13 18:58:39  mwvxm6
 *  Initial commit
 *
 *
 *  Revision 1.1  2010/01/29 23:02:32  MWVXM6
 *  Initial Commit
 *
*/
