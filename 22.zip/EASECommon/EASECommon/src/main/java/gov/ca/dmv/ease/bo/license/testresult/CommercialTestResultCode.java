/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult;

/**
 * Description: Enumeration to determine commercial Test Result Type
 * 
 * File: CommercialTestResultCode.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult
 * Created: Jan 28, 2010 
 * @author MWRSK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/08/12 17:19:54 $
 * Last Changed By: $Author: mwvxm6 $
 */
public enum CommercialTestResultCode {
	Failed("F"),
	Passed("P"),
	Satisfactory("S"),
	Waived("W"),
	// Satisfactory with corrective lenses	
	SatisfactoryWithCorrectiveLenses("L");
	
	private CommercialTestResultCode(String codeName) {
		this.codeName = codeName;
	}

	private String codeName;

	public String getCodeName() {
		return codeName;
	}

}

