/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.impl.Sequence;
import gov.ca.dmv.ease.bo.sequence.impl.SequencePatternFactory;

/**
 * Description: I am concrete representation of an inventory item assigned to an office but not to a station
 * 
 * File: OfficeLocalInventoryItem.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Sep 17, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2010/10/14 23:27:21 $
 * Last Changed By: $Author: mwkfh $
 */
public class OfficeLocalInventoryItem extends LocalInventoryItem {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5358261143013959312L;

	/**
	 * Instantiates a new office local inventory item.
	 */
	protected OfficeLocalInventoryItem() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param anItemTypeCode the an item type code
	 * @param location the location
	 */
	public OfficeLocalInventoryItem(String anItemTypeCode,
			IItemLocation location) {
		super(anItemTypeCode, location);
	}

	/**
	 * Instantiates a new office local inventory item.
	 * 
	 * @param aSeqNo the a seq no
	 * @param aType the a type
	 * @param aPattern the a pattern
	 * @param anOfficeId the an office id
	 */
	public OfficeLocalInventoryItem(ISequence aSeqNo, IItemType aType,
			String anOfficeId) {
		super(aSeqNo, aType, anOfficeId);
	}

	/**
	 * Instantiates a new office local inventory item.
	 * 
	 * @param sequenceNoString the a seq no
	 * @param aType the a type
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 * @param lowerBoundaryString the lower boundary
	 * @param upperBoundaryString the upper boundary
	 */
	public OfficeLocalInventoryItem(String sequenceNoString, IItemType aType,
			String anOfficeId, String lowerBoundaryString,
			String upperBoundaryString) {
		super(new Sequence(sequenceNoString, SequencePatternFactory
				.getInstance().getSequencePatternForCode(aType.getCode(),
						lowerBoundaryString, upperBoundaryString)), aType,
				anOfficeId);
	}
}
/**
 *  Modification History:
 *
 *  $Log: OfficeLocalInventoryItem.java,v $
 *  Revision 1.7  2010/10/14 23:27:21  mwkfh
 *  removed  deprecated constructors
 *
 *  Revision 1.6  2010/10/14 17:19:20  mwkfh
 *  updated constructors
 *
 *  Revision 1.5  2010/10/12 22:20:29  mwpxp2
 *  Added constructor/4 with type arg
 *
 *  Revision 1.4  2010/10/08 01:53:01  mwpxp2
 *  Added constructor with pattern instance
 *
 *  Revision 1.3  2010/10/05 20:39:14  mwpxp2
 *  Adjusted references to sequence types
 *
 *  Revision 1.2  2010/10/05 17:42:16  mwpxp2
 *  Adjusted imports
 *
 *  Revision 1.1  2010/09/17 21:57:22  mwpxp2
 *  Initial
 *
 */
