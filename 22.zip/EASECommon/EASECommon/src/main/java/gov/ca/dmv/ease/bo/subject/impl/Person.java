/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import static gov.ca.dmv.ease.app.constants.ITtcConstants.DL_TTC;
import static gov.ca.dmv.ease.app.constants.ITtcConstants.ID_TTC;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Document;
import gov.ca.dmv.ease.bo.document.impl.LegalPresenceDocument;
import gov.ca.dmv.ease.bo.document.impl.Passport;
import gov.ca.dmv.ease.bo.document.impl.SocialSecurityDocument;
import gov.ca.dmv.ease.bo.license.impl.DriverLicense;
import gov.ca.dmv.ease.bo.license.impl.IdCard;
import gov.ca.dmv.ease.bo.license.impl.License;
import gov.ca.dmv.ease.bo.license.impl.OutOfStateLicense;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.logging.IAuditable;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: Person class encapsulates all the physical characteristics of a
 * person. Person Business Object represents Owner in vehicle registration
 * transaction and an applicant in Driver License transaction.
 * File: Person.java
 * Module: gov.ca.dmv.ease.bo.subject.impl
 * Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.49 $
 * Last Changed: $Date: 2013/05/29 16:49:46 $
 * Last Changed By: $Author: mwskh1 $
 */
public class Person extends Subject implements IAuditable {
	/** The BLANK. */
	private static final String BLANK = "";
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(Person.class);
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7864442830241831518L;
	/** The birth date. */
	private Date birthDate;
	/** The current name. This holds the name which Technician keyed on the screen.*/
	private PersonName currentName;
	/**
	 * The List of Documents associated with this person.
	 * Documents can be of Legal Presence, Social Security, Passport etc
	 **/
	private List <Document> documents;
	/** The driver license. */
	private DriverLicense driverLicense;
	/** The duplicate license number of Ani change inquiry.
	 * This field holds a license number when Name/Birthdate is changed after initial HQ inquiry and there
	 * was a single hit with record conditions and was selected as 'D' duplicate record.*/
	private String duplicateLicenseNumberOfAniChangeInquiry;
	/** The existing birth date. This is the birth date on the record. */
	private Date existingBirthDate;
	/** The existing gender code. This is the gender code on the record. */
	private CodeSetElement existingGenderCode;
	/** The eye color code. */
	private CodeSetElement eyeColorCode;
	/** The gender code of the person. */
	private CodeSetElement genderCode;
	/** The hair color code. */
	private CodeSetElement hairColorCode;
	/** The height in feet of the person. */
	private Integer heightInFeet;
	/** The height in inches of the person. */
	private Integer heightInInch;
	/** Identification card associated to a person. */
	private IdCard idCard;
	/** To capture change in gender based on user data.*/
	private Boolean isGenderChanged;
	/** The license numbers of duplicate ANI records.
	 *  If an ANI record from Multiple ANI records is selected as - "Possible Double" with code "D"
	 *  then add license # of that ANI record to the list.
	 */
	private List <String> licenseNumbersOfDuplicateAniRecords = new ArrayList <String>();
	/** The Medical Expiration Date of existing record. */
	private Date medicalExpirationDate;
	/** The minor indicator. */
	private Boolean minor;
	/** Name With Special Characters. */
	private PersonName nameWithSpecialCharacters;
	/** The New Medical Expiration Date. */
	private Date newMedicalExpirationDate;
	/** The Person Names. This represents the AKA names of the person returned from the mainframe. */
	private List <PersonName> personNames;
	/** The previous birth date. Use from EliRecord person birth date.*/
	private Date previousBirthDate;
	/** The previous license number. This holds old license#, when new license number is requested for the Person. */
	private String previousLicenseNumber;
	/** The previous license. This holds list previous out of state license information. */
	private List <OutOfStateLicense> previousLicenses;
	/** The previous name. This holds the name returned from the mainframe during the Headquarter's inquiry response.
	 * This represents the name available on the Driver Record on the mainframe.
	 *
	 * Note - If previous name is different than the current name,
	 * 		  previous name will be added as an AKA name to the personNames field at the end of transaction. */
	private PersonName previousName;
	/** The previous out of state license entered on the CDLIS/PDPS inquiry screen. */
	private OutOfStateLicense previousOutOfStateLicense;
	/** The prev out of state license read only. */
	private OutOfStateLicense prevOutOfStateLicenseReadOnly;
	/**
	 * Holds the California resident ID of the person. Resident ID is specific
	 * for California applicants, this ID doesn't exist for non-resident
	 * applicants from other states and countries.
	 */
	private String residentId;
	/** The weight. */
	private Integer weight;
	/** Medical certificate. */
	private MedicalCertificate medicalCertificate;

	/*
		@Transient
		private List <Name> names;*/
	/**
	 * Default Constructor.
	 */
	public Person() {
		//FIXME
	}

	/**
	 * Instantiates a new person.
	 *
	 * @param person the person
	 */
	public Person(Person person) {
		super();
		copy(person);
	}

	/**
	 * Adds the Document to be associated with Applicant.
	 *
	 * @param applicantDocument the applicant document
	 */
	public void addApplicantDocument(Document applicantDocument) {
		this.getDocuments().add(applicantDocument);
	}

	/**
	 * Adds the license numbers of duplicate ani records.
	 *
	 * @param licenseNumber the license number
	 */
	public void addLicenseNumbersOfDuplicateAniRecords(String licenseNumber) {
		if (!EaseUtil.isNotNull(this.licenseNumbersOfDuplicateAniRecords)) {
			this.licenseNumbersOfDuplicateAniRecords = new ArrayList <String>();
			this.licenseNumbersOfDuplicateAniRecords.add(licenseNumber);
		}
		else {
			for (String dlNumber : licenseNumbersOfDuplicateAniRecords) {
				if (licenseNumber.equalsIgnoreCase(dlNumber)) {
					//If Driver License # already exist do not add it to the list.
					return;
				}
			}
			this.licenseNumbersOfDuplicateAniRecords.add(licenseNumber);
		}
	}

	/**
	 * Adds the previous license.
	 *
	 * @param previousLicense the previous license
	 */
	public void addPreviousLicense(OutOfStateLicense previousLicense) {
		if (!EaseUtil.isNotNull(this.previousLicenses)) {
			this.previousLicenses = new ArrayList <OutOfStateLicense>();
		}
		this.previousLicenses.add(previousLicense);
	}

	/**
	 * This method is to copy Person.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(Person dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null person argument expected in copy constructor in "
							+ this);
		}
		super.copy(dataToCopy);
		//Copy birthdate
		if (isNotNull(dataToCopy.getBirthDate())) {
			setBirthDate(new Date(dataToCopy.getBirthDate().getTime()));
		}
		else {
			setBirthDate(null);
		}
		//Copy Current name
		if (dataToCopy.getCurrentName() != null) {
			setCurrentName(new PersonName(dataToCopy.getCurrentName()));
		}
		else {
			setCurrentName(null);
		}
		//Copy Documents
		copyDocuments(dataToCopy.getDocuments());
		//Copy DriverLicense
		if (dataToCopy.getDriverLicense() != null) {
			setDriverLicense(new DriverLicense(dataToCopy.getDriverLicense()));
		}
		else {
			setDriverLicense(null);
		}
		//Copy Duplicate License Number Of Ani Change Inquiry
		setDuplicateLicenseNumberOfAniChangeInquiry(dataToCopy
				.getDuplicateLicenseNumberOfAniChangeInquiry());
		//Copy Existing birth date
		if (isNotNull(dataToCopy.getExistingBirthDate())) {
			setExistingBirthDate(new Date(dataToCopy.getExistingBirthDate()
					.getTime()));
		}
		else {
			setExistingBirthDate(null);
		}
		//Copy Existing gender code
		if (isNotNull(dataToCopy.getExistingGenderCode())) {
			setExistingGenderCode(new CodeSetElement(dataToCopy
					.getExistingGenderCode()));
		}
		else {
			setExistingGenderCode(null);
		}
		//Copy Eye color code
		if (isNotNull(dataToCopy.getEyeColorCode())) {
			setEyeColorCode(new CodeSetElement(dataToCopy.getEyeColorCode()));
		}
		else {
			setEyeColorCode(null);
		}
		//Copy Gender code
		if (isNotNull(dataToCopy.getGenderCode())) {
			setGenderCode(new CodeSetElement(dataToCopy.getGenderCode()));
		}
		else {
			setGenderCode(null);
		}
		//Copy Hair color code
		if (isNotNull(dataToCopy.getHairColorCode())) {
			setHairColorCode(new CodeSetElement(dataToCopy.getHairColorCode()));
		}
		else {
			setHairColorCode(null);
		}
		//Copy Height in feet
		if (isNotNull(dataToCopy.getHeightInFeet())) {
			setHeightInFeet(new Integer(dataToCopy.getHeightInFeet()));
		}
		else {
			setHeightInFeet(null);
		}
		//Copy Height in inch
		if (isNotNull(dataToCopy.getHeightInInch())) {
			setHeightInInch(new Integer(dataToCopy.getHeightInInch()));
		}
		else {
			setHeightInInch(null);
		}
		//Copy IdCard
		if (dataToCopy.getIdCard() != null) {
			setIdCard(new IdCard(dataToCopy.getIdCard()));
		}
		else {
			setIdCard(null);
		}
		//Copy isGenderChanged
		if (isNotNull(dataToCopy.isGenderChanged())) {
			setGenderChanged(new Boolean(dataToCopy.isGenderChanged()));
		}
		else {
			setGenderChanged(null);
		}
		//Copy License Numbers Of Duplicate Ani Records
		copyLicenseNumbersOfDuplicateAniRecords(dataToCopy
				.getLicenseNumbersOfDuplicateAniRecords());
		//Copy Medical Expiration Date
		if (isNotNull(dataToCopy.getMedicalExpirationDate())) {
			setMedicalExpirationDate(new Date(dataToCopy
					.getMedicalExpirationDate().getTime()));
		}
		else {
			setMedicalExpirationDate(null);
		}
		//Copy minor
		if (isNotNull(dataToCopy.getMinor())) {
			setMinor(new Boolean(dataToCopy.getMinor()));
		}
		else {
			setMinor(null);
		}
		//Copy New Medical Expiration Date
		if (isNotNull(dataToCopy.getNewMedicalExpirationDate())) {
			setNewMedicalExpirationDate(new Date(dataToCopy
					.getNewMedicalExpirationDate().getTime()));
		}
		else {
			setNewMedicalExpirationDate(null);
		}
		//Copy Person names
		copyPersonNames(dataToCopy.getPersonNames());
		//Copy Previous License Number
		setPreviousLicenseNumber(dataToCopy.getPreviousLicenseNumber());
		//Copy Previous Licenses
		copyPreviousLicenses(dataToCopy.getPreviousLicenses());
		//Copy Previous Out Of State License
		if (isNotNull(dataToCopy.getPreviousOutOfStateLicense())) {
			setPreviousOutOfStateLicense(new OutOfStateLicense(dataToCopy
					.getPreviousOutOfStateLicense()));
		}
		else {
			setPreviousOutOfStateLicense(null);
		}
		//Copy Previous name
		if (dataToCopy.getPreviousName() != null) {
			setPreviousName(new PersonName(dataToCopy.getPreviousName()));
		}
		else {
			setPreviousName(null);
		}
		//Copy Previous birth date
		if (isNotNull(dataToCopy.getPreviousBirthDate())) {
			setPreviousBirthDate(new Date(dataToCopy.getPreviousBirthDate()
					.getTime()));
		}
		else {
			setPreviousBirthDate(null);
		}
		//Copy Previous Out Of State License Read Only
		if (isNotNull(dataToCopy.getPrevOutOfStateLicenseReadOnly())) {
			setPrevOutOfStateLicenseReadOnly(new OutOfStateLicense(dataToCopy
					.getPrevOutOfStateLicenseReadOnly()));
		}
		else {
			setPrevOutOfStateLicenseReadOnly(null);
		}
		//Copy Resident ID
		setResidentId(dataToCopy.getResidentId());
		//Copy weight
		if (isNotNull(dataToCopy.getWeight())) {
			setWeight(new Integer(dataToCopy.getWeight()));
		}
		else {
			setWeight(null);
		}
		//Copy MedicalCertificate
		if (dataToCopy.getMedicalCertificate() != null) {
			setMedicalCertificate(new MedicalCertificate(dataToCopy
					.getMedicalCertificate()));
		}
		else {
			setMedicalCertificate(null);
		}
	}

	/**
	 * Copy documents.
	 *
	 * @param documentsToCopy the documents to copy
	 */
	protected void copyDocuments(List <Document> documentsToCopy) {
		if (isNotNull(documentsToCopy)) {
			List <Document> documents = new ArrayList <Document>();
			for (Document documentToCopy : documentsToCopy) {
				if (isNotNull(documentToCopy)) {
					if (documentToCopy.getClass() == LegalPresenceDocument.class) {
						documents.add(new LegalPresenceDocument(
								(LegalPresenceDocument) documentToCopy));
					}
					else if (documentToCopy.getClass() == Passport.class) {
						documents.add(new Passport((Passport) documentToCopy));
					}
					else if (documentToCopy.getClass() == SocialSecurityDocument.class) {
						documents.add(new SocialSecurityDocument(
								(SocialSecurityDocument) documentToCopy));
					}
				}
			}
			setDocuments(documents);
		}
		else {
			setDocuments(null);
		}
	}

	/**
	 * Copy license numbers of duplicate ani records.
	 *
	 * @param licenseNumbersOfDuplicateAniRecordsToCopy the license numbers of duplicate ani records to copy
	 */
	protected void copyLicenseNumbersOfDuplicateAniRecords(
			List <String> licenseNumbersOfDuplicateAniRecordsToCopy) {
		if (isNotNull(licenseNumbersOfDuplicateAniRecordsToCopy)) {
			for (String licenseNumberToCopy : licenseNumbersOfDuplicateAniRecordsToCopy) {
				addLicenseNumbersOfDuplicateAniRecords(licenseNumberToCopy);
			}
		}
	}

	/**
	 * Copy person names.
	 *
	 * @param personNamesToCopy the person names to copy
	 */
	private void copyPersonNames(List <PersonName> personNamesToCopy) {
		if (isNotNull(personNamesToCopy)) {
			List <PersonName> personNames = new ArrayList <PersonName>();
			for (PersonName personNameToCopy : personNamesToCopy) {
				if (isNotNull(personNameToCopy)) {
					personNames.add(new PersonName(personNameToCopy));
				}
			}
			setPersonNames(personNames);
		}
		else {
			setPersonNames(null);
		}
	}

	/**
	 * Copy previous licenses.
	 *
	 * @param previousLicensesToCopy the previous licenses to copy
	 */
	private void copyPreviousLicenses(
			List <OutOfStateLicense> previousLicensesToCopy) {
		if (isNotNull(previousLicensesToCopy)) {
			List <OutOfStateLicense> previousLicenses = new ArrayList <OutOfStateLicense>();
			for (OutOfStateLicense previousLicenseToCopy : previousLicensesToCopy) {
				if (isNotNull(previousLicenseToCopy)) {
					previousLicenses.add(new OutOfStateLicense(
							previousLicenseToCopy));
				}
			}
			setPreviousLicenses(previousLicenses);
		}
		else {
			setPreviousLicenses(null);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Person other = (Person) obj;
		if (birthDate == null) {
			if (other.birthDate != null) {
				return false;
			}
		}
		else if (!birthDate.equals(other.birthDate)) {
			return false;
		}
		if (currentName == null) {
			if (other.currentName != null) {
				return false;
			}
		}
		else if (!currentName.equals(other.currentName)) {
			return false;
		}
		if (documents == null) {
			if (other.documents != null) {
				return false;
			}
		}
		else if (!documents.equals(other.documents)) {
			return false;
		}
		if (driverLicense == null) {
			if (other.driverLicense != null) {
				return false;
			}
		}
		else if (!driverLicense.equals(other.driverLicense)) {
			return false;
		}
		if (duplicateLicenseNumberOfAniChangeInquiry == null) {
			if (other.duplicateLicenseNumberOfAniChangeInquiry != null) {
				return false;
			}
		}
		else if (!duplicateLicenseNumberOfAniChangeInquiry
				.equals(other.duplicateLicenseNumberOfAniChangeInquiry)) {
			return false;
		}
		if (existingBirthDate == null) {
			if (other.existingBirthDate != null) {
				return false;
			}
		}
		else if (!existingBirthDate.equals(other.existingBirthDate)) {
			return false;
		}
		if (existingGenderCode == null) {
			if (other.existingGenderCode != null) {
				return false;
			}
		}
		else if (!existingGenderCode.equals(other.existingGenderCode)) {
			return false;
		}
		if (eyeColorCode == null) {
			if (other.eyeColorCode != null) {
				return false;
			}
		}
		else if (!eyeColorCode.equals(other.eyeColorCode)) {
			return false;
		}
		if (genderCode == null) {
			if (other.genderCode != null) {
				return false;
			}
		}
		else if (!genderCode.equals(other.genderCode)) {
			return false;
		}
		if (hairColorCode == null) {
			if (other.hairColorCode != null) {
				return false;
			}
		}
		else if (!hairColorCode.equals(other.hairColorCode)) {
			return false;
		}
		if (heightInFeet == null) {
			if (other.heightInFeet != null) {
				return false;
			}
		}
		else if (!heightInFeet.equals(other.heightInFeet)) {
			return false;
		}
		if (heightInInch == null) {
			if (other.heightInInch != null) {
				return false;
			}
		}
		else if (!heightInInch.equals(other.heightInInch)) {
			return false;
		}
		if (idCard == null) {
			if (other.idCard != null) {
				return false;
			}
		}
		else if (!idCard.equals(other.idCard)) {
			return false;
		}
		if (isGenderChanged == null) {
			if (other.isGenderChanged != null) {
				return false;
			}
		}
		else if (!isGenderChanged.equals(other.isGenderChanged)) {
			return false;
		}
		if (licenseNumbersOfDuplicateAniRecords == null) {
			if (other.licenseNumbersOfDuplicateAniRecords != null) {
				return false;
			}
		}
		else if (!licenseNumbersOfDuplicateAniRecords
				.equals(other.licenseNumbersOfDuplicateAniRecords)) {
			return false;
		}
		if (medicalExpirationDate == null) {
			if (other.medicalExpirationDate != null) {
				return false;
			}
		}
		else if (!medicalExpirationDate.equals(other.medicalExpirationDate)) {
			return false;
		}
		if (minor == null) {
			if (other.minor != null) {
				return false;
			}
		}
		else if (!minor.equals(other.minor)) {
			return false;
		}
		if (nameWithSpecialCharacters == null) {
			if (other.nameWithSpecialCharacters != null) {
				return false;
			}
		}
		else if (!nameWithSpecialCharacters
				.equals(other.nameWithSpecialCharacters)) {
			return false;
		}
		if (newMedicalExpirationDate == null) {
			if (other.newMedicalExpirationDate != null) {
				return false;
			}
		}
		else if (!newMedicalExpirationDate
				.equals(other.newMedicalExpirationDate)) {
			return false;
		}
		if (personNames == null) {
			if (other.personNames != null) {
				return false;
			}
		}
		else if (!personNames.equals(other.personNames)) {
			return false;
		}
		if (prevOutOfStateLicenseReadOnly == null) {
			if (other.prevOutOfStateLicenseReadOnly != null) {
				return false;
			}
		}
		else if (!prevOutOfStateLicenseReadOnly
				.equals(other.prevOutOfStateLicenseReadOnly)) {
			return false;
		}
		if (previousBirthDate == null) {
			if (other.previousBirthDate != null) {
				return false;
			}
		}
		else if (!previousBirthDate.equals(other.previousBirthDate)) {
			return false;
		}
		if (previousLicenseNumber == null) {
			if (other.previousLicenseNumber != null) {
				return false;
			}
		}
		else if (!previousLicenseNumber.equals(other.previousLicenseNumber)) {
			return false;
		}
		if (previousLicenses == null) {
			if (other.previousLicenses != null) {
				return false;
			}
		}
		else if (!previousLicenses.equals(other.previousLicenses)) {
			return false;
		}
		if (previousName == null) {
			if (other.previousName != null) {
				return false;
			}
		}
		else if (!previousName.equals(other.previousName)) {
			return false;
		}
		if (previousOutOfStateLicense == null) {
			if (other.previousOutOfStateLicense != null) {
				return false;
			}
		}
		else if (!previousOutOfStateLicense
				.equals(other.previousOutOfStateLicense)) {
			return false;
		}
		if (residentId == null) {
			if (other.residentId != null) {
				return false;
			}
		}
		else if (!residentId.equals(other.residentId)) {
			return false;
		}
		if (weight == null) {
			if (other.weight != null) {
				return false;
			}
		}
		else if (!weight.equals(other.weight)) {
			return false;
		}
		if (medicalCertificate == null) {
			if (other.medicalCertificate != null) {
				return false;
			}
		}
		else if (!medicalCertificate.equals(other.medicalCertificate)) {
			return false;
		}
		return true;
	}

	/**
	 * This method gets the AKA Name as the First Element in Person Names List.
	 * As per the Convertor logic.
	 *
	 * @return AKA Name of a person
	 */
	public PersonName getAkaName() {
		PersonName akaName = null;
		if ((!EaseUtil.isNullOrBlank(this.personNames))
				&& personNames.size() >= 1) {
			akaName = this.personNames.get(0);
		}
		return akaName;
	}

	/**
	 * Gets the Birth Date.
	 *
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Gets the changed name.
	 *
	 * @return the changed name
	 */
	public PersonName getChangedName() {
		PersonName akaName = null;
		if (!EaseUtil.isNullOrBlank(this.personNames)) {
			akaName = this.personNames.get(0);
		}
		return akaName;
	}

	/**
	 * Gets the current name.
	 *
	 * @return the current name
	 */
	public PersonName getCurrentName() {
		return currentName;
	}

	/**
	 * Gets the dlor id number.
	 *
	 * @return the dlor id number
	 */
	public String getDlorIdNumber() {
		String dlOrIdNumber = BLANK;
		DriverLicense driverLicense = getDriverLicense();
		IdCard idCard = getIdCard();
		if (!EaseUtil.isNullOrBlank(driverLicense)
				&& !EaseUtil.isNullOrBlank(driverLicense.getLicenseNumber())) {
			dlOrIdNumber = driverLicense.getLicenseNumber().trim();
		}
		else if (!EaseUtil.isNullOrBlank(idCard)
				&& !EaseUtil.isNullOrBlank(idCard.getLicenseNumber())) {
			dlOrIdNumber = idCard.getIdNumber().trim();
		}
		return dlOrIdNumber;
	}

	/**
	 * Gets the Document by Type.
	 *
	 * @param documentClass Document type (class) to retrieve
	 *
	 * @return Document
	 */
	private Document getDocumentByType(Class <? extends Document> documentClass) {
		Document documentByType = null;
		if (!EaseUtil.isNullOrBlank(this.getDocuments())) {
			for (Document document : this.getDocuments()) {
				if (documentClass.isInstance(document)) {
					documentByType = document;
					break;
				}
			}
		}
		return documentByType;
	}

	/**
	 * Gets the Documents associated with Applicant.
	 * TODO Converter is expecting SSN to be passed as SocialSecurityDocument as a first element of List<Document>
	 *
	 * @return the documents
	 */
	public List <Document> getDocuments() {
		if (!EaseUtil.isNotNull(this.documents)) {
			this.documents = new ArrayList <Document>();
		}
		return documents;
	}

	/**
	 * Gets the Driver License.
	 *
	 * @return the driverLicense
	 */
	public DriverLicense getDriverLicense() {
		return driverLicense;
	}

	/**
	 * Gets the duplicate license number of ani change inquiry.
	 *
	 * @return the duplicateLicenseNumberOfAniChangeInquiry
	 */
	public String getDuplicateLicenseNumberOfAniChangeInquiry() {
		return duplicateLicenseNumberOfAniChangeInquiry;
	}

	/**
	 * Gets the existing birth date.
	 *
	 * @return the existingBirthDate
	 */
	public Date getExistingBirthDate() {
		return existingBirthDate;
	}

	/**
	 * Gets the Existing Gender Code.
	 *
	 * @return the existing gender code
	 */
	public CodeSetElement getExistingGenderCode() {
		return existingGenderCode;
	}

	/**
	 * Gets the Eye Color.
	 *
	 * @return the eyeColorCode
	 */
	public CodeSetElement getEyeColorCode() {
		return eyeColorCode;
	}

	/**
	 * Gets the fee due date from fee due year.
	 *
	 * @param ttc the ttc
	 * @return the fee due date from fee due year
	 */
	public Date getFeeDueDateFromFeeDueYear(String ttc) {
		License license = null;
		//For DL ttc
		if (ArrayUtils.contains(DL_TTC, ttc)) {
			license = getDriverLicense();
		}
		//For ID ttc
		else if (ArrayUtils.contains(ID_TTC, ttc)) {
			license = getIdCard();
		}
		if (license != null) {
			try {
				int feeDueYear = Integer.parseInt(license.getFeeDueYear());
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(getBirthDate());
				calendar.set(Calendar.YEAR,
						changeTwoDigitYeartoFourDigit(feeDueYear));
				return calendar.getTime();
			}
			catch (NumberFormatException e) {
				return null;
			}
		}
		return null;
	}

	/**
	 * Change two digit yearto four digit.
	 *
	 * @param twoDigitYear the two digit year
	 * @return the int
	 */
	private static int changeTwoDigitYeartoFourDigit(int twoDigitYear) {
		//FIXME: make more general so it can work after the year 2069!
		if (twoDigitYear < 70) {
			return twoDigitYear + 2000;
		}
		else {
			return twoDigitYear + 1900;
		}
	}

	/**
	 * Gets the gender Code.
	 *
	 * @return the genderCode
	 */
	public CodeSetElement getGenderCode() {
		return genderCode;
	}

	/**
	 * Gets the Hair Color.
	 *
	 * @return the hairColorCode
	 */
	public CodeSetElement getHairColorCode() {
		return hairColorCode;
	}

	/**
	 * Gets the Height in Feet.
	 *
	 * @return the heightInFeet
	 */
	public Integer getHeightInFeet() {
		return heightInFeet;
	}

	/**
	 * Gets the Height in Inches.
	 *
	 * @return the heightInInch
	 */
	public Integer getHeightInInch() {
		return heightInInch;
	}

	/**
	 * Gets the ID Card.
	 *
	 * @return the idCard
	 */
	public IdCard getIdCard() {
		return idCard;
	}

	/**
	 * Gets the Legal Presence Document.
	 *
	 * @return Legal Presence Document
	 */
	public LegalPresenceDocument getLegalPresenceDocument() {
		Document documentByType = this
				.getDocumentByType(LegalPresenceDocument.class);
		return EaseUtil.isNullOrBlank(documentByType) ? null
				: (LegalPresenceDocument) documentByType;
	}

	/**
	 * Gets the License Numbers Of Duplicate Ani Records.
	 *
	 * @return the licenseNumbersOfDuplicateAniRecords
	 */
	public List <String> getLicenseNumbersOfDuplicateAniRecords() {
		return licenseNumbersOfDuplicateAniRecords;
	}

	/**
	 * Gets the medical expiration date.
	 *
	 * @return the medicalExpirationDate
	 */
	public Date getMedicalExpirationDate() {
		return medicalExpirationDate;
	}

	/**
	 * Gets the Indicator for Minor.
	 *
	 * @return the minor
	 */
	public Boolean getMinor() {
		return minor;
	}

	/**
	 * Gets the more aka name.
	 *
	 * @return the more aka name
	 */
	public PersonName getMoreAkaName() {
		PersonName akaName = null;
		if ((!EaseUtil.isNullOrBlank(this.personNames))
				&& personNames.size() >= 2) {
			akaName = this.personNames.get(1);
		}
		return akaName;
	}

	/**
	 * Gets the name with special characters.
	 *
	 * @return the nameWithSpecialCharacters
	 */
	public PersonName getNameWithSpecialCharacters() {
		if (nameWithSpecialCharacters == null && currentName != null) {
			nameWithSpecialCharacters = new PersonName(currentName);
		}
		return nameWithSpecialCharacters;
	}

	/**
	 * Gets the new medical expiration date.
	 *
	 * @return the newMedicalExpirationDate
	 */
	public Date getNewMedicalExpirationDate() {
		return newMedicalExpirationDate;
	}

	/**
	 * Gets the passport.
	 *
	 * @return the passport
	 */
	public Passport getPassport() {
		Document documentByType = this.getDocumentByType(Passport.class);
		return EaseUtil.isNullOrBlank(documentByType) ? null
				: (Passport) documentByType;
	}

	/**
	 * Gets the Person Names.
	 *
	 * @return the personNames
	 */
	public List <PersonName> getPersonNames() {
		if (!EaseUtil.isNotNull(personNames)) {
			personNames = new ArrayList <PersonName>();
		}
		return personNames;
	}

	/**
	 * Gets the previous birth date.
	 *
	 * @return the previous birth date
	 */
	public Date getPreviousBirthDate() {
		return previousBirthDate;
	}

	/**
	 * Gets the previous license number.
	 *
	 * @return the previousLicenseNumber
	 */
	public String getPreviousLicenseNumber() {
		return previousLicenseNumber;
	}

	/**
	 * Gets the Previous Licenses.
	 *
	 * @return the previousLicenses
	 */
	public List <OutOfStateLicense> getPreviousLicenses() {
		return previousLicenses;
	}

	/**
	 * Gets the previous name.
	 *
	 * @return the previousName
	 */
	public PersonName getPreviousName() {
		return previousName;
	}

	/**
	 * Gets the previous out of state license entered on the CDLIS/PDPS inquiry screen.
	 *
	 * @return the previousOutOfStateLicense
	 */
	public OutOfStateLicense getPreviousOutOfStateLicense() {
		return previousOutOfStateLicense;
	}

	/**
	 * Gets the prev out of state license read only.
	 *
	 * @return the prev out of state license read only
	 */
	public OutOfStateLicense getPrevOutOfStateLicenseReadOnly() {
		return prevOutOfStateLicenseReadOnly;
	}

	/**
	 * Gets the resident id.
	 *
	 * @return the residentId
	 */
	public String getResidentId() {
		return residentId;
	}

	/**
	 * Gets the Social Security Document.
	 *
	 * @return Social Security Document
	 */
	public SocialSecurityDocument getSocialSecurityDocument() {
		Document documentByType = this
				.getDocumentByType(SocialSecurityDocument.class);
		return EaseUtil.isNullOrBlank(documentByType) ? null
				: (SocialSecurityDocument) documentByType;
	}

	/**
	 * Gets the Weight.
	 *
	 * @return the weight
	 */
	public Integer getWeight() {
		return weight;
	}

	/**
	 * Check if applicant has a license number.
	 *
	 * @return a boolean
	 */
	public boolean hasDriverLicenceNumer() {
		if (EaseUtil.isNullOrBlank(driverLicense)) {
			return false;
		}
		else {
			if (driverLicense.hasLicenseNumber()) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime * result
				+ ((currentName == null) ? 0 : currentName.hashCode());
		result = prime * result
				+ ((documents == null) ? 0 : documents.hashCode());
		result = prime * result
				+ ((driverLicense == null) ? 0 : driverLicense.hashCode());
		result = prime
				* result
				+ ((duplicateLicenseNumberOfAniChangeInquiry == null) ? 0
						: duplicateLicenseNumberOfAniChangeInquiry.hashCode());
		result = prime
				* result
				+ ((existingBirthDate == null) ? 0 : existingBirthDate
						.hashCode());
		result = prime
				* result
				+ ((existingGenderCode == null) ? 0 : existingGenderCode
						.hashCode());
		result = prime * result
				+ ((eyeColorCode == null) ? 0 : eyeColorCode.hashCode());
		result = prime * result
				+ ((genderCode == null) ? 0 : genderCode.hashCode());
		result = prime * result
				+ ((hairColorCode == null) ? 0 : hairColorCode.hashCode());
		result = prime * result
				+ ((heightInFeet == null) ? 0 : heightInFeet.hashCode());
		result = prime * result
				+ ((heightInInch == null) ? 0 : heightInInch.hashCode());
		result = prime * result + ((idCard == null) ? 0 : idCard.hashCode());
		result = prime * result
				+ ((isGenderChanged == null) ? 0 : isGenderChanged.hashCode());
		result = prime
				* result
				+ ((licenseNumbersOfDuplicateAniRecords == null) ? 0
						: licenseNumbersOfDuplicateAniRecords.hashCode());
		result = prime
				* result
				+ ((medicalExpirationDate == null) ? 0 : medicalExpirationDate
						.hashCode());
		result = prime * result + ((minor == null) ? 0 : minor.hashCode());
		result = prime
				* result
				+ ((nameWithSpecialCharacters == null) ? 0
						: nameWithSpecialCharacters.hashCode());
		result = prime
				* result
				+ ((newMedicalExpirationDate == null) ? 0
						: newMedicalExpirationDate.hashCode());
		result = prime * result
				+ ((personNames == null) ? 0 : personNames.hashCode());
		result = prime
				* result
				+ ((prevOutOfStateLicenseReadOnly == null) ? 0
						: prevOutOfStateLicenseReadOnly.hashCode());
		result = prime
				* result
				+ ((previousBirthDate == null) ? 0 : previousBirthDate
						.hashCode());
		result = prime
				* result
				+ ((previousLicenseNumber == null) ? 0 : previousLicenseNumber
						.hashCode());
		result = prime
				* result
				+ ((previousLicenses == null) ? 0 : previousLicenses.hashCode());
		result = prime * result
				+ ((previousName == null) ? 0 : previousName.hashCode());
		result = prime
				* result
				+ ((previousOutOfStateLicense == null) ? 0
						: previousOutOfStateLicense.hashCode());
		result = prime * result
				+ ((residentId == null) ? 0 : residentId.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		result = prime
				* result
				+ ((medicalCertificate == null) ? 0 : medicalCertificate
						.hashCode());
		return result;
	}

	/**
	 * Check if applicant has a previous license number.
	 *
	 * @return a boolean
	 */
	public boolean hasPreviousDriverLicenceNumer() {
		if (EaseUtil.isNullOrBlank(previousLicenseNumber)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the Indicator for Gender Change.
	 *
	 * @return the isGenderChanged
	 */
	public Boolean isGenderChanged() {
		return isGenderChanged;
	}

	/**
	 * returns whether the new medical expiration date has changed
	 *
	 * @return
	 */
	public boolean isMedicalExpirationDateNew() {
		return !EaseUtil.isSameDate(getMedicalExpirationDate(),
				getNewMedicalExpirationDate());
	}

	/**
	 * This method is used for Audit Logging.
	 *
	 * @param stringBuilder the buffer
	 */
	public void outputAuditLog(StringBuilder stringBuilder) {
		// TODO Auto-generated method stub
	}

	/**
	 * Removes the driver license.
	 */
	public void removeDriverLicense() {
		setDriverLicense(null);
	}

	/**
	 * Removes the id card.
	 */
	public void removeIdCard() {
		setIdCard(null);
	}

	/**
	 * Removes the license number of duplicate records.
	 *
	 * @param licenseNumber the license number
	 */
	public void removeLicenseNumberOfDuplicateRecords(String licenseNumber) {
		if (!EaseUtil.isNotNull(this.licenseNumbersOfDuplicateAniRecords)) {
			return;
		}
		else {
			for (String dlNumber : licenseNumbersOfDuplicateAniRecords) {
				if (licenseNumber.equalsIgnoreCase(dlNumber)) {
					//If Driver License # already exist remove from the list.
					this.licenseNumbersOfDuplicateAniRecords
							.remove(licenseNumber);
					return;
				}
			}
		}
	}

	/**
	 * Removes the license number of all duplicate records.
	 */
	public void removeAllLicenseNumberOfDuplicateRecords() {
		this.licenseNumbersOfDuplicateAniRecords = new ArrayList <String>();
	}

	/**
	 * Sets the Birth Date.
	 *
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date aDob) {
		LOGGER.info(" Setting birthdate to " + aDob);
		// BUG TESTING ONLY - start
		try {
			validateDob(birthDate, aDob);
		}
		catch (EaseValidationException e) {
			LOGGER.info("===Suspicious DOB assignment detected: ===");
			LOGGER.info(e.getStackTrace().toString());
		}
		// BUG TESTING ONLY - end
		this.birthDate = aDob;
	}

	/**
	 * Sets the current name.
	 *
	 * @param currentName the currentName to set
	 */
	public void setCurrentName(PersonName currentName) {
		this.currentName = currentName;
	}

	/**
	 * Sets the Documents to be associated with Applicant.
	 *
	 * @param applicantDocuments the new documents
	 */
	public void setDocuments(List <Document> applicantDocuments) {
		this.documents = applicantDocuments;
	}

	/**
	 * Sets the Driver License.
	 *
	 * @param driverLicense the driverLicense to set
	 */
	public void setDriverLicense(DriverLicense driverLicense) {
		this.driverLicense = driverLicense;
	}

	/**
	 * Sets the duplicate license number of ani change inquiry.
	 *
	 * @param duplicateLicenseNumberOfAniChangeInquiry the duplicateLicenseNumberOfAniChangeInquiry to set
	 */
	public void setDuplicateLicenseNumberOfAniChangeInquiry(
			String duplicateLicenseNumberOfAniChangeInquiry) {
		this.duplicateLicenseNumberOfAniChangeInquiry = duplicateLicenseNumberOfAniChangeInquiry;
	}

	/**
	 * Sets the existing birth date.
	 *
	 * @param existingBirthDate the existingBirthDate to set
	 */
	public void setExistingBirthDate(Date existingBirthDate) {
		this.existingBirthDate = existingBirthDate;
	}

	/**
	 * Sets the Existing Gender Code.
	 *
	 * @param existingGenderCode the new existing gender code
	 */
	public void setExistingGenderCode(CodeSetElement existingGenderCode) {
		this.existingGenderCode = existingGenderCode;
	}

	/**
	 * Sets the Eye Color.
	 *
	 * @param eyeColorCode the eyeColorCode to set
	 */
	public void setEyeColorCode(CodeSetElement eyeColorCode) {
		this.eyeColorCode = eyeColorCode;
	}

	/**
	 * Sets the Indicator for Gender Change.
	 *
	 * @param isGenderChanged the isGenderChanged to set
	 */
	public void setGenderChanged(Boolean isGenderChanged) {
		this.isGenderChanged = isGenderChanged;
	}

	/**
	 * Sets the gender Code.
	 *
	 * @param genderCode the genderCode to set
	 */
	public void setGenderCode(CodeSetElement genderCode) {
		this.genderCode = genderCode;
	}

	/**
	 * Sets the Hair Color.
	 *
	 * @param hairColorCode the hairColorCode to set
	 */
	public void setHairColorCode(CodeSetElement hairColorCode) {
		this.hairColorCode = hairColorCode;
	}

	/**
	 * Sets the Height in Feet.
	 *
	 * @param heightInFeet the heightInFeet to set
	 */
	public void setHeightInFeet(Integer heightInFeet) {
		this.heightInFeet = heightInFeet;
	}

	/**
	 * Sets the Height in Inches.
	 *
	 * @param heightInInch the heightInInch to set
	 */
	public void setHeightInInch(Integer heightInInch) {
		this.heightInInch = heightInInch;
	}

	/**
	 * Sets the ID Card.
	 *
	 * @param idCard the idCard to set
	 */
	public void setIdCard(IdCard idCard) {
		this.idCard = idCard;
	}

	/**
	 * Sets the medical expiration date.
	 *
	 * @param medicalExpirationDate the medicalExpirationDate to set
	 */
	public void setMedicalExpirationDate(Date medicalExpirationDate) {
		this.medicalExpirationDate = medicalExpirationDate;
	}

	/**
	 * Sets the Indicator for Minor.
	 *
	 * @param minor the minor to set
	 */
	public void setMinor(Boolean minor) {
		this.minor = minor;
	}

	/**
	 * Sets the name with special characters.
	 *
	 * @param aNameWithSpecialCharacters the new name with special characters
	 */
	public void setNameWithSpecialCharacters(
			PersonName aNameWithSpecialCharacters) {
		nameWithSpecialCharacters = aNameWithSpecialCharacters;
	}

	/**
	 * Sets the new medical expiration date.
	 *
	 * @param newMedicalExpirationDate the newMedicalExpirationDate to set
	 */
	public void setNewMedicalExpirationDate(Date newMedicalExpirationDate) {
		this.newMedicalExpirationDate = newMedicalExpirationDate;
	}

	/**
	 * Sets the Person Names.
	 *
	 * @param personNames the personNames to set
	 */
	public void setPersonNames(List <PersonName> personNames) {
		this.personNames = personNames;
	}

	/**
	 * Sets the previous birth date.
	 *
	 * @param previousBirthDate the new previous birth date
	 */
	public void setPreviousBirthDate(Date previousBirthDate) {
		this.previousBirthDate = previousBirthDate;
	}

	/**
	 * Sets the previous license number.
	 *
	 * @param previousLicenseNumber the previousLicenseNumber to set
	 */
	public void setPreviousLicenseNumber(String previousLicenseNumber) {
		this.previousLicenseNumber = previousLicenseNumber;
	}

	/**
	 * Sets the Previous Licenses.
	 *
	 * @param previousLicenses the new previous licenses
	 */
	public void setPreviousLicenses(List <OutOfStateLicense> previousLicenses) {
		this.previousLicenses = previousLicenses;
	}

	/**
	 * Sets the previous name.
	 *
	 * @param previousName the previousName to set
	 */
	public void setPreviousName(PersonName previousName) {
		this.previousName = previousName;
	}

	/**
	 * Sets the previous out of state license entered on the CDLIS/PDPS inquiry screen.
	 *
	 * @param previousOutOfStateLicense the previousOutOfStateLicense to set
	 */
	public void setPreviousOutOfStateLicense(
			OutOfStateLicense previousOutOfStateLicense) {
		this.previousOutOfStateLicense = previousOutOfStateLicense;
	}

	/**
	 * Sets the prev out of state license read only.
	 *
	 * @param prevOutOfStateLicenseReadOnly the new prev out of state license read only
	 */
	public void setPrevOutOfStateLicenseReadOnly(
			OutOfStateLicense prevOutOfStateLicenseReadOnly) {
		this.prevOutOfStateLicenseReadOnly = prevOutOfStateLicenseReadOnly;
	}

	/**
	 * Sets the resident id.
	 *
	 * @param residentId the residentId to set
	 */
	public void setResidentId(String residentId) {
		this.residentId = residentId;
	}

	/**
	 * Sets the Weight.
	 *
	 * @param weight the weight to set
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.subject.impl.Subject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("birthDate", birthDate, anIndent, aBuilder);
		outputKeyValue("currentName", currentName, anIndent, aBuilder);
		outputKeyValue("documents", documents, anIndent, aBuilder);
		outputKeyValue("driverLicense", driverLicense, anIndent, aBuilder);
		outputKeyValue("duplicateLicenseNumberOfAniChangeInquiry",
				duplicateLicenseNumberOfAniChangeInquiry, anIndent, aBuilder);
		outputKeyValue("existingBirthDate", existingBirthDate, anIndent,
				aBuilder);
		outputKeyValue("existingGenderCode", existingGenderCode, anIndent,
				aBuilder);
		outputKeyValue("eyeColorCode", eyeColorCode, anIndent, aBuilder);
		outputKeyValue("genderCode", genderCode, anIndent, aBuilder);
		outputKeyValue("hairColorCode", hairColorCode, anIndent, aBuilder);
		outputKeyValue("heightInFeet", heightInFeet, anIndent, aBuilder);
		outputKeyValue("heightInInch", heightInInch, anIndent, aBuilder);
		outputKeyValue("idCard", idCard, anIndent, aBuilder);
		outputKeyValue("isGenderChanged", isGenderChanged, anIndent, aBuilder);
		outputKeyValue("licenseNumbersOfDuplicateAniRecords",
				licenseNumbersOfDuplicateAniRecords, anIndent, aBuilder);
		outputKeyValue("medicalExpirationDate", medicalExpirationDate,
				anIndent, aBuilder);
		outputKeyValue("minor", minor, anIndent, aBuilder);
		outputKeyValue("newMedicalExpirationDate", newMedicalExpirationDate,
				anIndent, aBuilder);
		outputKeyValue("personNames", personNames, anIndent, aBuilder);
		outputKeyValue("previousLicenseNumber", previousLicenseNumber,
				anIndent, aBuilder);
		outputKeyValue("previousLicenses", previousLicenses, anIndent, aBuilder);
		outputKeyValue("previousOutOfStateLicense", previousOutOfStateLicense,
				anIndent, aBuilder);
		outputKeyValue("previousName", previousName, anIndent, aBuilder);
		outputKeyValue("previousBirthDate", previousBirthDate, anIndent,
				aBuilder);
		outputKeyValue("prevOutOfStateLicenseReadOnly",
				prevOutOfStateLicenseReadOnly, anIndent, aBuilder);
		outputKeyValue("residentId", residentId, anIndent, aBuilder);
		outputKeyValue("weight", weight, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/**
	 * Validate dob. BUG TESTING ONLY
	 *
	 * @param anExistingDob the an existing dob
	 * @param aNewDob the a new dob
	 */
	private void validateDob(Date anExistingDob, Date aNewDob) {
		//if the dates are a day apart, throw an exception - BUG TESTING ONLY
		if (anExistingDob != null && aNewDob != null) {
			if (anExistingDob.getYear() == aNewDob.getYear()
					&& anExistingDob.getMonth() == aNewDob.getMonth()) {
				int aDay1 = anExistingDob.getDay();
				int aDay2 = aNewDob.getDay();
				int diff = Math.abs(aDay1 - aDay2);
				if (diff > 0 && diff < 2) {
					throw new EaseValidationException("date1: " + anExistingDob
							+ " date2: " + aNewDob + " diff: " + diff);
				}
			}
		}
	}

	public void setMedicalCertificate(MedicalCertificate medicalCertificate) {
		this.medicalCertificate = medicalCertificate;
	}

	public MedicalCertificate getMedicalCertificate() {
		return medicalCertificate;
	}
}
/**
 * Modification History:
 *
 * $Log: Person.java,v $
 * Revision 1.49  2013/05/29 16:49:46  mwskh1
 * CDLIS 5.2 - Code merge into HEAD
 *
 * Revision 1.48.2.2  2013/03/28 18:12:04  mwskh1
 * CDLIS Mod - added housekeeping logics for medicalCertificate
 *
 * Revision 1.48.2.1  2013/03/28 16:52:21  mwgxd3
 * CDLIS - Add medicalCertificate
 *
 * Revision 1.48  2013/01/18 19:32:51  mwhys
 * Added getFeeDueDateFromFeeDueYear(). (Defect 8524, 8537)
 *
 * Revision 1.47  2013/01/17 21:58:31  mwpxr5
 * Junit coverage update
 *
 * Revision 1.46  2012/10/04 23:46:48  mwuxb
 * Updated to remove unreachable code.
 *
 * Revision 1.45  2012/10/02 19:46:05  mwuxb
 * Added method removeAllLicenseNumberOfDuplicateRecords
 *
 * Revision 1.44  2012/08/14 20:46:44  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.43  2012/02/04 00:48:58  mwkkc
 * build
 *
 * Revision 1.42  2012/02/03 01:53:54  mwpxp2
 * Added transient code to catch dob decrement
 *
 * Revision 1.41  2012/01/30 23:53:47  mwsec2
 * FODI integration code merged to HEAD
 *
 * Revision 1.40  2012/01/09 22:38:41  mwhys
 * Added LOGGER in setBirthDate().
 *
 * Revision 1.39  2011/08/23 16:51:15  mwhys
 * Updated getNameWithSpecialCharacters() to replace BeanUtils with PersonName's copy constructor.
 *
 * Revision 1.38  2011/08/22 22:58:23  mwhys
 * Added 2 methods to remove DL and ID cards.
 *
 * Revision 1.37  2011/07/25 23:35:02  mwhys
 * Added getDlorIdNumber().
 *
 * Revision 1.36  2011/07/12 23:00:37  mwhxb3
 * Added
 *  1: hasDriverLicenceNumer - Check if applicant has a license number.
 *  2: hasPreviousDriverLicenceNumer - Check if applicant has a previous license number.
 *
 * Revision 1.35  2011/04/07 04:04:54  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.34.2.6  2011/04/05 22:13:48  mwhys
 * Updated copyDocuments() method to check for the class type.
 *
 * Revision 1.34.2.5  2011/04/05 18:07:16  mwhys
 * Moved the code that throws exception from copy-constructor to copy-method.
 *
 * Revision 1.34.2.3  2011/04/05 16:47:29  mwhys
 * Updated copy method to create new Dates.
 *
 * Revision 1.34.2.2  2011/04/04 16:27:34  mwhys
 * Added explicit ELSE blocks inside the copy method.
 *
 * Revision 1.34.2.1  2011/04/02 20:50:12  mwhys
 * (1) Regenerated hashCode() and equals() methods.
 * (2) Updated copy method.
 *
 * Revision 1.34  2011/02/05 00:36:25  mwhys
 * Added a field OutOfStateLicense::previousOutOfStateLicense to fix defect 4789.
 *
 * Revision 1.33  2011/01/25 19:28:51  mwrrv3
 * Refactored the code to support name change functionality.
 *
 * Revision 1.32  2011/01/16 01:35:14  mwhxb3
 * Return currentName is nameWithSpecialCharacters is null.
 *
 * Revision 1.31  2011/01/12 19:39:17  mwrrv3
 * Added new attribute nameWithSpecialCharacters.
 *
 * Revision 1.30  2011/01/06 00:26:32  mwhys
 * Added a field to store previousBirthDate from the ELI record.
 * This will be used in the hidden logic.
 *
 * Revision 1.29  2010/12/13 19:25:34  mwrxn3
 * Removed getMyCopy method and updated with copy constructor
 *
 * Revision 1.28  2010/12/12 22:31:26  mwrxn3
 * Added getMyCopy method
 *
 * Revision 1.27  2010/12/07 22:11:39  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.26  2010/12/07 03:57:52  mwpxp2
 * Added toStringOn/1
 *
 * Revision 1.25  2010/12/07 01:50:50  mwpxp2
 * Added toString/0
 *
 * Revision 1.24  2010/12/06 02:16:51  mwhys
 * Added state variable: prevOutOfStateLicenseReadOnly.
 *
 * Revision 1.23  2010/12/02 00:15:47  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.22  2010/11/08 17:28:17  mwrxn3
 *  Added clonePerson method
 *
 * Revision 1.21  2010/10/29 17:42:57  mwuxb
 * Added variable existingBirthDate. This will represent the birth date on the DMV database.
 *
 * Revision 1.20  2010/10/15 23:42:31  mwuxb
 * Added new variable - existingBirthDate for SSN inquiry process.
 *
 * Revision 1.19  2010/09/13 04:40:28  mwhys
 * Made all the Rules and Services static for Session Management.
 *
 * Revision 1.18  2010/08/12 18:56:15  mwcsj3
 * Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 * Revision 1.17  2010/07/26 23:34:53  mwyxg1
 * initiate licenseNumbersOfDuplicateAniRecords
 *
 * Revision 1.16  2010/07/26 23:29:27  mwyxg1
 * remove setLicenseNumbersOfDuplicateAniRecords
 *
 * Revision 1.15  2010/07/26 23:19:17  mwyxg1
 * add setLicenseNumbersOfDuplicateAniRecords
 *
 * Revision 1.14  2010/07/22 17:50:29  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.13  2010/06/21 23:01:00  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.10.2.2  2010/06/20 18:07:11  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.12  2010/06/02 20:41:58  mwrsk
 * Remove clone()
 *
 * Revision 1.11  2010/06/01 22:01:58  mwuxb
 * Added variable duplicateLicenseNumberOfAniChangeInquiry
 *
 * Revision 1.10  2010/05/27 21:27:11  mwvxm6
 * Updated equals method
 *
 * Revision 1.9  2010/05/19 01:45:52  mwuxb
 * Added helper method to remove duplicate license number.
 *
 * Revision 1.8  2010/05/15 01:34:42  mwuxb
 * Removed attribute issuanceReferralMessages
 *
 * Revision 1.7  2010/05/13 20:22:21  mwuxb
 * Added attribute issuanceReferralMessages
 *
 * Revision 1.6  2010/05/12 20:19:55  mwuxb
 * Updated helper methods
 *
 * Revision 1.5  2010/05/09 20:57:11  mwuxb
 * Added attribute previousLicenseNumber
 *
 * Revision 1.4  2010/05/05 23:26:27  mwrsk
 * Removed defaults
 *
 * Revision 1.3  2010/04/29 00:37:20  mwuxb
 * Added attribute licenseNumbersOfDuplicateAniRecords
 *
 * Revision 1.2  2010/04/19 16:59:40  mwuxb
 * Updated AKA logic
 *
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.36  2010/04/15 00:06:41  mwuxb
 * Updated helper methods for applicant's documents
 *
 * Revision 1.35  2010/04/14 23:58:03  mwuxb
 * Updated
 *
 * Revision 1.34  2010/04/14 23:42:56  mwuxb
 * Added helper method for passport document
 *
 * Revision 1.33  2010/04/13 18:08:05  mwrsk
 * Added boundary checks for getAkaName() & getMoreAkaName()
 *
 * Revision 1.32  2010/04/13 00:40:23  mwuxb
 * Updated Java docs.
 *
 * Revision 1.31  2010/04/08 01:18:55  mwsxd10
 * Swapping flag added.
 *
 * Revision 1.30  2010/04/03 00:33:30  mwuxb
 * Added attribute previousName
 *
 * Revision 1.29  2010/04/02 21:34:37  mwuxb
 * Added attribute newMedicalExpirationDate
 *
 * Revision 1.28  2010/03/23 23:59:50  mwhxb3
 * Changed the isInstance()  parameter - has to be a object of compatible type.
 *
 * Revision 1.27  2010/03/11 17:26:55  mwuxb
 * Added helper method to add previous license
 *
 * Revision 1.26  2010/02/26 22:59:16  mwvxm6
 * Updated attribute name from sexCode to genderCode
 *
 * Revision 1.25  2010/02/11 17:53:30  mwtjc1
 * comment is added for getDocuments() method
 *
 * Revision 1.24  2010/02/09 23:36:42  mwvxm6
 * Removed the method isCaliforniaResident in Person as it is not being set or correctly used.
 *
 * Revision 1.23  2010/02/09 23:20:47  mwvxm6
 * Removed the method isCaliforniaResident in Person as it is not being set or correctly used.
 *
 * Revision 1.22  2010/02/08 22:28:35  mwrsk
 * Use isInstance instead of equals
 *
 * Revision 1.21  2010/02/08 22:25:05  mwrsk
 * Refactor person.applicantDocuments to person.documents
 *
 * Revision 1.20  2010/02/08 22:05:53  mwrsk
 * Remove DocumentType Changes
 *
 * Revision 1.19  2010/02/04 19:09:28  mwvxm6
 * Removed Autowired and configured explicitly in spring context xml
 *
 * Revision 1.18  2010/01/28 22:48:46  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.17  2010/01/21 19:48:50  mwhxa2
 * Modified - Now consists of List of Out of State Licenses
 *
 * Revision 1.16  2010/01/13 22:02:51  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.15  2010/01/12 22:23:12  mwhxa2
 * Added getAKAName()
 *
 * Revision 1.14  2010/01/12 22:22:12  mwhxa2
 * Added getAKAName()
 *
 * Revision 1.13  2010/01/12 22:07:05  mwhxa2
 * Added Medical Expiration Date
 *
 * Revision 1.12  2010/01/12 02:47:11  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.11  2010/01/12 02:16:48  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.10  2010/01/12 01:50:50  mwhxa2
 * Added Person Names
 *
 * Revision 1.9  2010/01/12 01:43:15  mwhxa2
 * Fixed compilation issues
 *
 * Revision 1.8  2010/01/12 01:05:19  mwhxa2
 * Implemented getLegalPresenceDocument()
 *
 * Revision 1.7  2010/01/11 19:38:37  mwhxa2
 * Associating Person with Documents
 *
 * Revision 1.6  2010/01/07 22:45:00  mwhxa2
 * Domain Model changes - Draft 1
 *
 * Revision 1.5  2010/01/06 19:19:00  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.4  2010/01/06 00:01:55  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.3  2010/01/05 03:01:42  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.2  2010/01/04 18:29:08  mwvxm6
 * BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 * Revision 1.1  2009/11/23 16:25:13  mwrsk
 * Intial commit
 *
 * Revision 1.45  2009/10/15 22:14:57  mwcsj3
 * Fixed to do's
 *
 * Revision 1.44  2009/10/15 18:22:12  mwrka1
 * followed by PMD rules
 *
 * Revision 1.43  2009/10/12 18:09:12  mwcsj3
 * Removed unused and unimplemented methods
 *
 * Revision 1.42  2009/10/03 21:06:32  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.41  2009/09/29 23:32:19  mwcsj3
 * Added californiaResident variable with get and set methods
 *
 * Revision 1.40  2009/09/29 02:20:24  mwhxa2
 * Implements IValidatable
 *
 * Revision 1.39  2009/09/28 21:23:26  mwrsk
 * IAuditable & ILoggable moved to framework project
 *
 * Revision 1.38  2009/09/13 20:52:29  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.36.2.1  2009/09/12 19:08:51  mwakg
 * Removed CodeSetElement sub classes
 *
 * Revision 1.36  2009/09/10 04:35:58  mwsmg6
 * LicenseClass
 *
 * Revision 1.35  2009/09/02 23:03:27  mwcsj3
 * Updated setBirthDate method
 *
 * Revision 1.34  2009/09/02 22:53:27  mwcsj3
 * Formatted and fixed ArrayIndexOutOfBounds exception in calculateAge method
 *
 * Revision 1.33  2009/09/02 15:55:26  mwsmg6
 * removal of CodeSetElements from the business tier
 *
 * Revision 1.32  2009/09/02 15:43:41  mwsmg6
 * removal of CodeSetElements from the business tier
 *
 * Revision 1.31  2009/09/01 22:05:20  mwcsj3
 * Made changes to accommodate movement of isMinor from DlApplication to Person
 *
 * Revision 1.30  2009/08/31 21:19:03  mwsxd10
 * outputAuditLog(StringBuffer) implemented from IAuditable for logging.
 *
 * Revision 1.29  2009/08/27 22:02:48  mwvkk1
 * implemened Iauditable interface
 *
 * Revision 1.28 2009/08/27 05:39:48 mwpxp2
 * Bulk cleanup
 *
 * Revision 1.27 2009/08/22 23:21:46 mwrrv3
 * Implemented equals and hashCode methods.
 *
 * Revision 1.26 2009/08/22 21:07:00 mwakg
 * fixed get and Set methods for addresses logic
 *
 * Revision 1.25 2009/08/22 18:21:26 mwakg
 * fixed logical issue
 *
 * Revision 1.24 2009/08/17 18:10:26 mwakg
 * made clone method public
 *
 * Revision 1.23 2009/08/17 17:57:56 mwakg
 * Added clone method for person BO
 *
 * Revision 1.22 2009/08/17 17:55:45 mwakg
 * Added clone method for person BO
 *
 * Revision 1.21 2009/08/10 21:15:58 mwrrv3
 * Initialized new objects in the constructor.
 *
 * Revision 1.20 2009/08/10 21:13:32 mwrrv3
 * IdCard new attribute added.
 *
 * Revision 1.19 2009/08/10 16:09:32 mwakg
 * fixed binding issues for SearchPersonByNumber
 *
 * Revision 1.18 2009/08/06 19:09:24 mwrrv3
 * Checking null value for setting mailing and residence address.
 *
 * Revision 1.17 2009/08/06 01:02:52 mwrrv3
 * Updated the getAkaName method.
 *
 * Revision 1.16 2009/08/05 21:16:27 mwrrv3
 * Modified the code inside the helper methods.
 *
 * Revision 1.15 2009/08/05 19:12:03 mwrrv3
 * Created empty objects and assigned to the list in the constructor.
 *
 * Revision 1.14 2009/08/05 05:23:52 mwrrv3
 * Refactored Set to List.
 *
 * Revision 1.13 2009/08/04 02:39:33 mwrrv3
 * Removed CdlisPdpsHistory attribute.
 *
 * Revision 1.12 2009/08/03 22:52:32 mwrrv3
 * Commented driverLicense and previousLicense initialization in the constructor.
 *
 * Revision 1.11 2009/08/03 20:41:35 mwrrv3
 * Added default constructor and created new objects in side default constructor and added comments.
 *
 * Revision 1.10 2009/07/30 23:00:33 mwrrv3
 * Modified the set mail and residence address implementation.
 *
 * Revision 1.9 2009/07/30 00:51:58 mwrrv3
 * Added set methods for mailing address and residence address.
 *
 * Revision 1.8 2009/07/28 00:40:41 mwrrv3
 * Changed DriverLicense to OutOfStateLicense.
 *
 * Revision 1.7 2009/07/27 23:54:57 mwrrv3
 * Removed uncommented code.
 *
 * Revision 1.6 2009/07/27 23:00:12 mwrrv3
 * Code formated and added comments.
 *
 * Revision 1.5 2009/07/27 22:44:45 mwrrv3
 * Changed License to DriverLicense object.
 *
 * Revision 1.4 2009/07/22 18:38:00 mwbxp5
 * Cleaned the Person Object. Removed ref to DlApplication, Documents, CdlisPdps history
 *
 * Revision 1.3 2009/07/21 18:33:57 mwrrv3
 * Modified the business objects.
 *
 * Revision 1.2 2009/07/14 23:44:25 mwpxp2
 * Initial move to hnode20
 *
 * Revision 1.1 2009-07-12 00:55:16 ppalacz
 * Moved to .impl package; added file decorations, todos
 *
 * Revision 1.1 2009-07-10 07:09:24 ppalacz
 * Synch
 *
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3
 * $Initial ITM commit $
 *
 * $Revision 1.1 Apr 28, 2009 2:35:43 PM MWCSJ3
 * $Initial $
 */
