/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.response.impl;

import gov.ca.dmv.ease.bo.tx.ITransaction;
import gov.ca.dmv.ease.fw.error.IErrorCollector;

/**
 * Description: I am the persistence response for UpdateDafRecordPersistenceRequest
 * File: UpdateDafRecordPersistenceResponse.java
 * Module:  gov.ca.dmv.ease.tus.persist.response.impl
 * Created: Jan 14, 2011
 * 
 * @author MWTJC1
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/01/14 19:57:41 $
 * Last Changed By: $Author: mwtjc1 $
 */
public class UpdateDafRecordPersistenceResponse extends
		PersistenceServiceResponse {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1704258085687426027L;
	/** The transaction. */
	private ITransaction transaction;
	
	/**
	 * Instantiates a new update daf record persistence response.
	 */
	public UpdateDafRecordPersistenceResponse() {
		
	}
	public UpdateDafRecordPersistenceResponse(ITransaction transaction) {
		super();
		setTransaction(transaction);
	}

	/**
	 * Instantiates a new issued business object response.
	 * 
	 * @param errorCollector the error collector
	 */
	public UpdateDafRecordPersistenceResponse(IErrorCollector errorCollector) {
		super();
		setErrorCollector(errorCollector);
	}

	/**
	 * Gets the transaction.
	 * 
	 * @return the transaction
	 * 
	 */
	public ITransaction getTransaction() {
		return transaction;
	}

	/**
	 * Sets the transaction.
	 * 
	 * @param transaction the transaction to set
	 */
	private void setTransaction(ITransaction transaction) {
		this.transaction = transaction;
	}
}
/**
 *  Modification History:
 *
 *  $Log: UpdateDafRecordPersistenceResponse.java,v $
 *  Revision 1.2  2011/01/14 19:57:41  mwtjc1
 *  default constructor added
 *
 *  Revision 1.1  2011/01/14 19:55:26  mwtjc1
 *  first commit
 *
 */
