/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.impl;

import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequenceConstants;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.exception.impl.InvalidSequenceException;
import gov.ca.dmv.ease.bo.sequence.exception.impl.NoSequenceAvailableException;
import gov.ca.dmv.ease.bo.sequence.parse.ISequenceElemList;
import gov.ca.dmv.ease.bo.sequence.parse.ISequenceParser;
import gov.ca.dmv.ease.bo.sequence.parse.impl.SequenceParser;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description:  I am implementation of ISequence
 * File: Sequence.java
 * Module:  gov.ca.dmv.ease.bo.sequence.impl
 * Created: Sep 3, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.18 $
 * Last Changed: $Date: 2011/01/03 16:06:15 $
 * Last Changed By: $Author: mwkfh $
 */
public class Sequence implements ISequence {
	/** The PARSER. */
	private static ISequenceParser PARSER = null;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1441715521193668503L;

	/**
	 * Gets the parser instance.
	 * 
	 * @return the parser instance
	 */
	protected static ISequenceParser getParserInstance() {
		if (PARSER == null) {
			PARSER = new SequenceParser();
		}
		return PARSER;
	}

	/** The pattern. */
	private ISequencePattern pattern;
	/** The value. */
	private String value;

	/**
	 * Instantiates a new sequence.
	 */
	protected Sequence() {
		super();
	}

	/**
	 * Instantiates a new sequence.
	 * 
	 * @param aSeqValue
	 *            the a seq value
	 * @param aPattern
	 *            the a pattern
	 */
	public Sequence(String aSeqValue, ISequencePattern aPattern) {
		super();
		if (aPattern != null) {
			setValue(addTrimmedSpaces(aSeqValue, aPattern.getValue()));
		}
		else {
			setValue(aSeqValue);
		}
		setPattern(aPattern);
	}

	/**
	 * Add missing spaces to trimmed boundary
	 * 
	 * @param boundary
	 * @return altered boundary
	 */
	public static String addTrimmedSpaces(String aSeqValue, String aPatternValue) {
		if ((!EaseUtil.isNullOrBlank(aPatternValue)) && (aSeqValue != null)
				&& (aSeqValue.length() < aPatternValue.length())) {
			String alteredSequence = aSeqValue.trim();
			//add end spaces
			int index = aPatternValue.length() - 1;
			String suffix = "";
			while ((index > 0)
					&& (aPatternValue.charAt(index--) == ISequenceConstants.SPACE_FILLER)) {
				suffix += ISequenceConstants.SPACE;
			}
			alteredSequence += suffix;
			//add begin spaces
			for (char patternDigit : aPatternValue.toCharArray()) {
				if ((alteredSequence.length() < aPatternValue.length())
						&& ((patternDigit == ISequenceConstants.SPACE_FILLER) || (patternDigit == ISequenceConstants.INCREMENTING_DIGIT_WITH_LEADING_SPACE))) {
					alteredSequence = ISequenceConstants.SPACE
							+ alteredSequence;
				}
				else {
					break;
				}
			}
			return alteredSequence;
		}
		else {
			return aSeqValue;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#asParsed()
	 */
	public ISequenceElemList asParsed() {
		return getParserInstance().parse(this);
	}

	public String asString() {
		return getValue();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Sequence)) {
			return false;
		}
		Sequence other = (Sequence) obj;
		if (pattern == null) {
			if (other.pattern != null) {
				return false;
			}
		}
		else if (!pattern.equals(other.pattern)) {
			return false;
		}
		if (value == null) {
			if (other.value != null) {
				return false;
			}
		}
		else if (!value.equals(other.value)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#getNext()
	 */
	public ISequence getNext() {
		validateIfInRange();
		validateIfLastSequence();
		ISequenceElemList anElemList = asParsed();
		ISequenceElemList aNext = anElemList.getNext();
		return aNext.asSequence(getPattern());
		//		return asParsed().getNext().asSequence(getPattern());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#getPattern()
	 */
	public ISequencePattern getPattern() {
		return pattern;
	}

	public String getSequenceNo() {
		return getValue();
	}

	/**
	 * Gets the value.
	 * 
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pattern == null) ? 0 : pattern.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/**
	 * Checks if is after.
	 * 
	 * @param aSequence the a sequence
	 * 
	 * @return true, if is after
	 */
	public boolean isAfter(ISequence aSequence) {
		return isAfter(aSequence.getSequenceNo());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#isAfter(java.lang.String)
	 */
	public boolean isAfter(String aSequenceString) {
		return getSequenceNo().compareTo(aSequenceString) > 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#nextSequence()
	 */
	public ISequence nextSequence() {
		return getNext();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.sequence.ISequence#previousSequence()
	 */
	public ISequence previousSequence() {
		validateIfInRange();
		validateIfFirstSequence();
		return asParsed().getPrevious().asSequence(getPattern());
	}

	/**
	 * Sets the pattern.
	 * 
	 * @param pattern
	 *            the new pattern
	 */
	protected void setPattern(ISequencePattern aPattern) {
		pattern = aPattern;
	}

	/**
	 * Sets the value.
	 * 
	 * @param value
	 *            the new value
	 */
	public void setValue(String aVal) {
		value = aVal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append('"').append(getValue()).append('"').append(" ");
		aBuilder.append('"').append(getPattern()).append(" ]");
		return aBuilder.toString();
	}

	/**
	 * Validate if first sequence.
	 */
	private void validateIfFirstSequence() {
		String aLowerLimit = getPattern().getLowerSequenceBoundary();
		if (getSequenceNo().equals(aLowerLimit)) {
			throw new NoSequenceAvailableException(
					"No next sequence available before \"" + aLowerLimit + "\"");
		}
	}

	/**
	 * Validate if in range.
	 */
	private void validateIfInRange() {
		validateIfNotBeforeFirstSequence();
		validateIfNotAfterLastSequence();
	}

	/**
	 * Validate if last sequence.
	 */
	private void validateIfLastSequence() {
		String anUpperLimit = getPattern().getUpperSequenceBoundary();
		if (getSequenceNo().equals(anUpperLimit)) {
			throw new NoSequenceAvailableException(
					"No next sequence available after \"" + anUpperLimit
							+ "\" in " + this);
		}
	}

	/**
	 * Validate if after last sequence.
	 */
	private void validateIfNotAfterLastSequence() {
		String anUpperLimit = getPattern().getUpperSequenceBoundary();
		if (EaseUtil.isNotBlank(anUpperLimit)
				&& getSequenceNo().compareTo((anUpperLimit)) > 0) {
			throw new InvalidSequenceException(
					"Current sequence is after the upper limit:  \""
							+ anUpperLimit + "\" in " + this);
		}
	}

	/**
	 * Validate if before first sequence.
	 */
	private void validateIfNotBeforeFirstSequence() {
		String aLowerLimit = getPattern().getLowerSequenceBoundary();
		if (getSequenceNo().compareTo((aLowerLimit)) < 0) {
			throw new InvalidSequenceException(
					"Current sequence is before the lower limit: \""
							+ aLowerLimit + "\"");
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: Sequence.java,v $
 * Revision 1.18  2011/01/03 16:06:15  mwkfh
 * added blank check for pattern in addTrimmedSpaces
 *
 * Revision 1.17  2010/12/23 06:18:21  mwkkc
 * Merged Production code from Branch
 *
 * Revision 1.14.8.1  2010/12/23 03:13:54  mwkkc
 * Rebase from head - Common
 *
 * Revision 1.16  2010/12/20 19:22:17  mwkfh
 * added null check in constructor
 *
 * Revision 1.15  2010/12/20 19:14:23  mwkfh
 * refactored addTrimmedSpaces
 *
 * Revision 1.14  2010/12/04 20:06:27  mwkfh
 * updated validateIfNotAfterLastSequence to allow blank upper bound
 *
 * Revision 1.13  2010/10/21 16:54:33  mwpxp2
 * Used InvalidSequenceException in validations if before lower boundary or if after upper boundary.
 *
 * Revision 1.12  2010/10/21 16:49:10  mwpxp2
 * Added three validations, incl. validateIfInRange
 *
 * Revision 1.11  2010/10/09 00:09:53  mwpxp2
 * Obsolete todo removed
 *
 * Revision 1.10  2010/10/06 00:34:16  mwpxp2
 * Added validation if no previous or next sequence available
 *
 * Revision 1.9  2010/10/05 20:40:52  mwpxp2
 * Adjusted for interface mods
 *
 * Revision 1.8  2010/09/30 18:54:02  mwpxp2
 * Adjusted imports
 *
 * Revision 1.7  2010/09/11 00:27:31  mwpxp2
 * Modified toString/0 to quote string values
 *
 * Revision 1.6  2010/09/10 23:22:47  mwbxg3
 * added test for NextSequence
 * Revision 1.5 2010/09/09 01:28:53 mwpxp2 Added
 * toString/0
 * 
 * Revision 1.4 2010/09/08 01:57:44 mwpxp2 Added equals/0, hashCode/0;
 * 
 * Revision 1.3 2010/09/07 22:59:03 mwpxp2 Javadoc
 * 
 * Revision 1.2 2010/09/04 05:59:29 mwpxp2 Corrected return type of asParsed/0
 * 
 * Revision 1.1 2010/09/04 05:53:51 mwpxp2 Initial, in progress
 * 
 */
