/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.inventory.item.IItemLocation;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: I represent location of an Inventory Item
 * File: ItemLocation.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/09/23 22:00:33 $
 * Last Changed By: $Author: mwkfh $
 */
public class ItemLocation implements IItemLocation {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2991363248426028285L;
	/** The office id. */
	private String officeId;
	/** The station id. */
	private String stationId;

	/**
	 * Instantiates a new item location.
	 */
	protected ItemLocation() {
		super();
	}

	/**
	 * Instantiates a new item location.
	 * 
	 * @param anOfficeId the an office id
	 */
	public ItemLocation(String anOfficeId) {
		super();
		setOfficeId(anOfficeId);
	}

	/**
	 * Instantiates a new item location.
	 * 
	 * @param anOfficeId the an office id
	 * @param aStationId the a station id
	 */
	public ItemLocation(String anOfficeId, String aStationId) {
		super();
		setOfficeId(anOfficeId);
		setStationId(aStationId);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#changeToOffice()
	 */
	public void changeToOffice() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			stationId = stationId.substring(0, 2) + "#";
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ItemLocation)) {
			return false;
		}
		ItemLocation other = (ItemLocation) obj;
		if (officeId == null) {
			if (other.officeId != null) {
				return false;
			}
		}
		else if (!officeId.equals(other.officeId)) {
			return false;
		}
		if (stationId == null) {
			if (other.stationId != null) {
				return false;
			}
		}
		else if (!stationId.equals(other.stationId)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Gets the station id.
	 * 
	 * @return the stationId
	 */
	public String getStationId() {
		return stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#isAssignedToStation()
	 */
	public boolean isAssignedToStation() {
		return !EaseUtil.isNullOrBlank(getStationId());
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId the officeId to set
	 */
	protected void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Sets the station id.
	 * 
	 * @param stationId the stationId to set
	 */
	protected void setStationId(String stationId) {
		this.stationId = stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" office: ").append(officeId);
		aBuilder.append(" station: ").append(stationId);
		aBuilder.append(" ]");
		return aBuilder.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: ItemLocation.java,v $
 *  Revision 1.7  2011/09/23 22:00:33  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.6  2011/08/12 20:15:27  mwxxw
 *  Improve logic in isAssignedToStation().
 *
 *  Revision 1.5  2010/10/05 22:27:27  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.4  2010/09/30 18:09:48  mwpxp2
 *  Added hashCode, equals
 *
 *  Revision 1.3  2010/09/17 18:15:34  mwkfh
 *  fixed setter params in constructors
 *
 *  Revision 1.2  2010/09/17 18:09:27  mwkfh
 *  added setters to constructors
 *
 *  Revision 1.1  2010/09/14 19:08:20  mwpxp2
 *  Initial
 *
 */
