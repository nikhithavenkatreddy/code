/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.document.impl.Application;

/**
 * Description: This class captures information pertaining to Miscellaneous Items
 * with a Fixed Fee 
 * File: MiscellaneousFixedFeeItems.java
 * Module:  gov.ca.dmv.ease.bo.misc
 * Created: Apr 12, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/03/14 01:57:55 $
 * Last Changed By: $Author: mwxxw $
 */
public class MiscellaneousFixedFeeItemsApplication extends Application {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8465813572792451373L;
	/** (Verify?) If the applicant is a company like driving school. */
	//private CustomerOrganization applicantCompany;
	/** The item Code requested by the customer (34 - Junior Permit) */
	private CodeSetElement itemCode;
	/** The customer last name or the companys name */
	private String otherIdentifyingInformation;
	/** The requested number of items. */
	private Integer quantity;

	/**
	 * Default Constructor.
	 */
	public MiscellaneousFixedFeeItemsApplication() {
		super();
		setFeeRequired(true);
	}

	//
	//	/**
	//	 * @return the applicantCompany
	//	 */
	//	public CustomerOrganization getApplicantCompany() {
	//		return applicantCompany;
	//	}
	/**
	 * @return the itemCode
	 */
	public CodeSetElement getItemCode() {
		return itemCode;
	}

	/**
	 * @return the otherIdentifyingInformation
	 */
	public String getOtherIdentifyingInformation() {
		return otherIdentifyingInformation;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	//	/**
	//	 * @param applicantCompany the applicantCompany to set
	//	 */
	//	public void setApplicantCompany(CustomerOrganization applicantCompany) {
	//		this.applicantCompany = applicantCompany;
	//	}
	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(CodeSetElement itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * @param otherIdentifyingInformation the otherIdentifyingInformation to set
	 */
	public void setOtherIdentifyingInformation(
			String otherIdentifyingInformation) {
		this.otherIdentifyingInformation = otherIdentifyingInformation;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
}
