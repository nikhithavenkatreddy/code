/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.admin;

import java.io.Serializable;

/**
 * Description: I am common interface for various types of providers of sequence numbers
 * 	         0001 - 1999  VR COUNTER/POSTAL SEQUENCE NUMBER
*	         2001 - 2999  VR MANUAL/TRAVEL CREW SEQUENCE NUMBER
*	         3001 - 3999  DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
*	         4001 - 4999  ADM311 SEQUENCE NUMBER
*	         5001 - 6999  DL COUNTER/POSTAL SEQUENCE NUMBER
*	         7001 - 7999  DL MANUAL/TRAVEL CREW SEQUENCE NUMBER
*	         8001 - 8999  DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
*	         9001 AND UP  RESERVED FOR SYSTEM USE
 * File: ISequenceNumberProvider.java
 * Module:  gov.ca.dmv.ease.bo.admin
 * Created: Oct 22, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/10/25 00:20:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface ISequenceNumberProvider extends Serializable {
	
	/** The Constant VR_COUNTER_MAX. */
	static final int VR_COUNTER_MAX = 0;
	
	/** The Constant VR_MANUAL_MAX. */
	static final int VR_MANUAL_MAX = 0;
	
	/** The Constant DER_MANUAL_MAX. */
	static final int DER_MANUAL_MAX = 0;
	
	/** The Constant AMD_MAX. */
	static final int AMD_MAX = 0;
	
	/** The Constant DL_COUNTER_MAX. */
	static final int DL_COUNTER_MAX = 0;
	
	/** The Constant DL_MANUAL_MAX. */
	static final int DL_MANUAL_MAX = 0;
	
	/** The Constant DER_MANUAL2_MAX. */
	static final int DER_MANUAL2_MAX = 0;
	
	/** The Constant RESERVED_MAX. */
	static final int RESERVED_MAX = 0;
	
	/** The Constant VR_COUNTER_MIN. */
	static final int VR_COUNTER_MIN = 0;
	
	/** The Constant VR_MANUAL_MIN. */
	static final int VR_MANUAL_MIN = 0;
	
	/** The Constant DER_MANUAL_MIN. */
	static final int DER_MANUAL_MIN = 0;
	
	/** The Constant AMD_MIN. */
	static final int AMD_MIN = 0;
	
	/** The Constant DL_COUNTER_MIN. */
	static final int DL_COUNTER_MIN = 0;
	
	/** The Constant DL_MANUAL_MIN. */
	static final int DL_MANUAL_MIN = 0;
	
	/** The Constant DER_MANUAL2_MIN. */
	static final int DER_MANUAL2_MIN = 0;
	
	/** The Constant RESERVED_MIN. */
	static final int RESERVED_MIN = 0;

	/**
	 * The Enum SequenceType.
	 */
	public enum SequenceType {
		//VR COUNTER/POSTAL SEQUENCE NUMBER
		/** The V r_ counter. */
		VR_COUNTER,
		//VR MANUAL/TRAVEL CREW SEQUENCE NUMBER
		/** The V r_ manual. */
		VR_MANUAL,
		//DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
		/** The DE r_ manual. */
		DER_MANUAL,
		//ADM311 SEQUENCE NUMBER
		/** The AMD. */
		AMD,
		//DL COUNTER/POSTAL SEQUENCE NUMBER
		/** The D l_ counter. */
		DL_COUNTER,
		//DL MANUAL/TRAVEL CREW SEQUENCE NUMBER
		/** The D l_ manual. */
		DL_MANUAL,
		//DER FOR MANUAL/TRAVEL CREW SEQUENCE NUMBER
		/** The DE r_ manua l2. */
		DER_MANUAL2,
		//RESERVED FOR SYSTEM USE
		/** The RESERVED. */
		RESERVED;
		
		/**
		 * Gets the min for.
		 *
		 * @param type the type
		 * @return the min for
		 */
		public static int getMinFor(SequenceType type) {
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * Gets the max for.
		 *
		 * @param type the type
		 * @return the max for
		 */
		public static int getMaxFor(SequenceType type) {
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * Gets the description.
		 *
		 * @param type the type
		 * @return the description
		 */
		public static int getDescription(SequenceType type) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	/**
	 * Gets the current number.
	 *
	 * @return the current number
	 */
	int getCurrentNumber();

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	String getDescription();

	/**
	 * Gets the max.
	 *
	 * @return the max
	 */
	int getMax();

	/**
	 * Increment.
	 */
	void increment();

	/**
	 * Increment and get current number.
	 *
	 * @return the int
	 */
	int incrementAndGetCurrentNumber();
}
/**
 *  Modification History:
 *
 *  $Log: ISequenceNumberProvider.java,v $
 *  Revision 1.1  2011/10/25 00:20:32  mwpxp2
 *  Initial
 *
 */
