/** 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: Application Pending Code Constants.
 * File: IApplicationPendingCodeConstants.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Aug 5, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/12/11 20:08:30 $
 * Last Changed By: $Author: mwhys $
 */
public interface IApplicationPendingCodeConstants {
	/** The Driver License and ID Card Pending Indicator. */
	String DL_AND_ID_PENDING = "B";
	/** The Driver License Pending Indicator. */
	String DL_PENDING = "D";
	/** The ID Card Pending Indicator. */
	String ID_PENDING = "I";
}
/**
 *  Modification History:
 * 
 *  $Log: IApplicationPendingCodeConstants.java,v $
 *  Revision 1.1  2011/12/11 20:08:30  mwhys
 *  Moved to EASECommon project.
 *
 *  Revision 1.2  2010/11/19 18:22:33  mwpxp2
 *  Sorted; added missing javadoc
 *
 *  Revision 1.1  2010/08/05 18:48:39  mwhxa2
 *  Application Pending Indicators
 *
*/
