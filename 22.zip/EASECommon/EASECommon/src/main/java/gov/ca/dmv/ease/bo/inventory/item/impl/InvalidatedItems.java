/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import static gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence.ORG_CODE_OFFICE;
import static gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence.ORG_CODE_WORKSTATION;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IInvalidatedItems;
import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.inventory.item.IItemType;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bo.sequence.impl.ContiguousItemSequence;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: I am implementation of IInvalidatedItems
 * File: InvalidatedItems.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Dec 13, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.14 $
 * Last Changed: $Date: 2011/11/23 00:40:55 $
 * Last Changed By: $Author: mwkfh $
 */
public class InvalidatedItems extends BusinessObject implements
		IInvalidatedItems {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6006475677157934102L;
	/** The Constant UNKNOWN_CODE. */
	public static final char UNKNOWN_CODE = 0;
	/** The item type code. */
	private String code;
	/** The count. */
	private Integer count;
	/** The lower boundary. */
	private String lowerBoundary;
	/** The office id. */
	private String officeId;
	/** The org code. */
	private String orgCode;
	/** The pattern. */
	private String pattern;
	/** The reason code. */
	private Character reasonCode;
	/** The station id. */
	private String stationId;
	/** The upper boundary. */
	private String upperBoundary;

	/**
	 * Instantiates a new invalidated items.
	 */
	protected InvalidatedItems() {
		super();
	}

	/**
	 * Instantiates a new invalidated items.
	 * 
	 * @param anItemSequence 
	 * @param aReasonCode 
	 */
	public InvalidatedItems(IContiguousItemSequence anItemSequence,
			char aReasonCode) {
		super();
		setReasonCode(aReasonCode);
		setCount(anItemSequence.getSequenceCount());
		setCode(anItemSequence.getItemType().getCode());
		setOfficeId(anItemSequence.getOfficeId());
		setStationId(anItemSequence.getStationId());
		setPattern(anItemSequence.getPattern().getValue());
		setLowerBoundary(anItemSequence.getLowerBoundary());
		setUpperBoundary(anItemSequence.getUpperBoundary());
		setOrgCode(anItemSequence.getOrgCode());
	}

	/**
	 * Instantiates a new invalidated items.
	 * 
	 * @param anItem 
	 * @param aReasonCode 
	 * @param aLowerBoundary 
	 * @param aCount 
	 */
	public InvalidatedItems(IInventoryItem anItem, char aReasonCode,
			String aLowerBoundary, int aCount) {
		super();
		setReasonCode(aReasonCode);
		setCount(aCount);
		setCode(anItem.getType().getCode());
		setOfficeId(anItem.getOfficeId());
		setStationId(anItem.getStationId());
		setPattern(anItem.getPattern().getValue());
		setLowerBoundary(aLowerBoundary);
	}

	/**
	 * Instantiates a new invalidated items.
	 * 
	 * @param anItem 
	 * @param aReasonCode 
	 * @param aLowerBoundary 
	 * @param anUpperBoundary 
	 */
	public InvalidatedItems(IInventoryItem anItem, char aReasonCode,
			String aLowerBoundary, String anUpperBoundary) {
		super();
		setReasonCode(aReasonCode);
		setUpperBoundary(anUpperBoundary);
		setCode(anItem.getType().getCode());
		setOfficeId(anItem.getOfficeId());
		setStationId(anItem.getStationId());
		setPattern(anItem.getPattern().getValue());
		setLowerBoundary(aLowerBoundary);
	}

	/**
	 * Instantiates a new invalidated items.
	 * 
	 * @param anItemCode
	 * @param aReasonCode
	 * @param anOfficeId
	 * @param aStationId
	 * @param aPattern
	 * @param aLowerBoundary
	 * @param aCount
	 * @param anOrgCode
	 */
	public InvalidatedItems(String anItemCode, char aReasonCode,
			String anOfficeId, String aStationId, String aPattern,
			String aLowerBoundary, int aCount, String anOrgCode) {
		super();
		setReasonCode(aReasonCode);
		setCount(aCount);
		setCode(anItemCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setPattern(aPattern);
		setLowerBoundary(aLowerBoundary);
		setOrgCode(anOrgCode);
	}

	/**
	 * Instantiates a new invalidated items.
	 * 
	 * @param anItemCode
	 * @param aReasonCode
	 * @param anOfficeId
	 * @param aStationId
	 * @param aPattern
	 * @param aLowerBoundary
	 * @param anUpperBoundary
	 * @param anOrgCode
	 */
	public InvalidatedItems(String anItemCode, char aReasonCode,
			String anOfficeId, String aStationId, String aPattern,
			String aLowerBoundary, String anUpperBoundary, String anOrgCode) {
		super();
		setReasonCode(aReasonCode);
		setCode(anItemCode);
		setOfficeId(anOfficeId);
		setStationId(aStationId);
		setPattern(aPattern);
		if (EaseUtil.isNullOrBlank(aLowerBoundary)) {
			setLowerBoundary(anUpperBoundary);
		}
		else {
			setLowerBoundary(aLowerBoundary);
		}
		if (EaseUtil.isNullOrBlank(anUpperBoundary)) {
			setUpperBoundary(aLowerBoundary);
		}
		else {
			setUpperBoundary(anUpperBoundary);
		}
		setOrgCode(anOrgCode);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#changeToOffice()
	 */
	public void changeToOffice() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			stationId = stationId.substring(0, 2) + "#";
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getCode()
	 */
	public String getCode() {
		return code;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getContiguousItemSequence()
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		if (hasCode() && hasLowerBoundary()) {
			return new ContiguousItemSequence(getCode(), getOfficeId(),
					getStationId(), getLowerBoundary(), getUpperBoundary(),
					getCount(), false, getOrgCode());
		}
		else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getCount()
	 */
	public Integer getCount() {
		if (count == null) {
			return new Integer("0");
		}
		else {
			return count;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getDescription()
	 */
	public String getDescription() {
		if (getCode() != null) {
			IItemType itemType = ItemType.forCode(getCode());
			return itemType.getDescription();
		}
		else {
			return null; //or throw exception
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getItemCount()
	 */
	public int getItemCount() {
		IContiguousItemSequence itemSeq = getContiguousItemSequence();
		if (itemSeq != null) {
			int itemCount = itemSeq.getItemCount();
			//fix missing spaces in boundaries if necessary
			if (!getLowerBoundary().equals(itemSeq.getLowerBoundary())) {
				setLowerBoundary(itemSeq.getLowerBoundary());
			}
			if (!EaseUtil.isNullOrBlank(getUpperBoundary())
					&& !getUpperBoundary().equals(itemSeq.getUpperBoundary())) {
				setUpperBoundary(itemSeq.getUpperBoundary());
			}
			return itemCount;
		}
		else {
			return getCount().intValue();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getLowerBoundary()
	 */
	public String getLowerBoundary() {
		return lowerBoundary;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getOfficeId()
	 */
	public String getOfficeId() {
		return officeId; //or throw exception
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getPattern()
	 */
	public String getPattern() {
		return pattern;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IContiguousItemSequence#getOrgCode()
	 */
	public String getOrgCode() {
		if (orgCode == null) {
			setOrgCode();
		}
		return orgCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getReasonCode()
	 */
	public char getReasonCode() {
		if (reasonCode == null) {
			return UNKNOWN_CODE;
		}
		else {
			return reasonCode.charValue();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getStationId()
	 */
	public String getStationId() {
		return stationId; //or throw exception
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#getUpperBoundary()
	 */
	public String getUpperBoundary() {
		return upperBoundary;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#hasCode()
	 */
	public boolean hasCode() {
		return code != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#hasCount()
	 */
	public boolean hasCount() {
		return count != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#hasLocation()
	 */
	public boolean hasLocation() {
		return getOfficeId() != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.InvalidatedItems#hasLowerBoundary()
	 */
	public boolean hasLowerBoundary() {
		return getLowerBoundary() != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInvalidatedItems#hasPattern()
	 */
	public boolean hasPattern() {
		return getPattern() != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInvalidatedItems#hasReason()
	 */
	public boolean hasReason() {
		return (getReasonCode() == UNKNOWN_CODE || getReasonCode() == ' ' ? false
				: true);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInvalidatedItems#hasUpperBoundary()
	 */
	public boolean hasUpperBoundary() {
		return getUpperBoundary() != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IInvalidatedItems#isAssignedToStation()
	 */
	public boolean isAssignedToStation() {
		if (!EaseUtil.isNullOrBlank(stationId)) {
			return true;
		}
		else {
			return false; //or throw exception
		}
	}

	/**
	 * Checks if is for station.
	 * 
	 * @return true, if is for station
	 */
	public boolean isForStation() {
		return (getStationId() != null) && !getStationId().endsWith("#");
	}

	/**
	 * 
	 * 
	 * @param code the type code to set
	 */
	protected void setCode(String code) {
		this.code = code;
	}

	/**
	 * 
	 * 
	 * @param aCount 
	 */
	protected void setCount(int aCount) {
		//must be > 0
		count = Integer.valueOf(aCount);
	}

	/**
	 * 
	 * 
	 * @param lowerBoundary the lowerBoundary to set
	 */
	protected void setLowerBoundary(String lowerBoundary) {
		if (lowerBoundary == null) {
			this.lowerBoundary = lowerBoundary;
		}
		else {
			this.lowerBoundary = lowerBoundary.toUpperCase();
		}
	}

	/**
	 * 
	 * 
	 * @param officeId the officeId to set
	 */
	protected void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Set the org code based on the station.
	 */
	protected void setOrgCode() {
		setOrgCode(null);
	}

	/**
	 * Set the org code based.
	 * 
	 * @param orgCode the org code
	 */
	protected void setOrgCode(String orgCode) {
		if (EaseUtil.isNotNull(orgCode)) {
			this.orgCode = orgCode;
		}
		else {
			if (isForStation()) {
				this.orgCode = ORG_CODE_WORKSTATION;
			}
			else {
				this.orgCode = ORG_CODE_OFFICE;
			}
		}
	}

	/**
	 * 
	 * 
	 * @param pattern the pattern to set
	 */
	protected void setPattern(String pattern) {
		this.pattern = pattern;
	}

	/**
	 * 
	 * 
	 * @param reasonCode the reasonCode to set
	 */
	protected void setReasonCode(Character reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * 
	 * 
	 * @param stationId the stationId to set
	 */
	protected void setStationId(String stationId) {
		this.stationId = stationId;
	}

	/**
	 * 
	 * 
	 * @param upperBoundary the upperBoundary to set
	 */
	protected void setUpperBoundary(String upperBoundary) {
		if (upperBoundary == null) {
			this.upperBoundary = upperBoundary;
		}
		else {
			this.upperBoundary = upperBoundary.toUpperCase();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("code", code, anIndent, aBuilder);
		outputKeyValue("officeId", officeId, anIndent, aBuilder);
		outputKeyValue("stationId", stationId, anIndent, aBuilder);
		outputKeyValue("reasonCode", reasonCode, anIndent, aBuilder);
		outputKeyValue("pattern", pattern, anIndent, aBuilder);
		outputKeyValue("lowerBoundary", lowerBoundary, anIndent, aBuilder);
		outputKeyValue("upperBoundary", upperBoundary, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InvalidatedItems.java,v $
 *  Revision 1.14  2011/11/23 00:40:55  mwkfh
 *  added orgCode
 *
 *  Revision 1.13  2011/09/23 22:00:33  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.12  2011/08/12 20:15:00  mwxxw
 *  Improve logic in isAssignedToStation() function.
 *
 *  Revision 1.11  2011/02/01 18:47:31  mwkfh
 *  updated constructor to set the upper or lower boundary with the other if passed null or blank
 *
 *  Revision 1.10  2010/12/31 23:27:01  mwkfh
 *  made updates to deal with null upper boundary
 *
 *  Revision 1.9  2010/12/31 01:42:17  mwkfh
 *  updated getItemCount to fix boundaries
 *
 *  Revision 1.8  2010/12/23 06:18:23  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.6.4.1  2010/12/23 03:13:57  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.7  2010/12/20 20:02:23  mwkfh
 *  moved boundaries to be set after the pattern
 *
 *  Revision 1.6  2010/12/16 23:09:09  mwkfh
 *  fixed bugs and remove not needed stuff
 *
 *  Revision 1.5  2010/12/15 18:36:43  mwkfh
 *  added getContiguousItemSequence()
 *
 *  Revision 1.4  2010/12/15 18:26:43  mwkfh
 *  updated getItemCount()
 *
 *  Revision 1.3  2010/12/15 18:24:01  mwkfh
 *  added getItemCount()
 *
 *  Revision 1.2  2010/12/14 21:26:46  mwkfh
 *  updated InvalidatedItems to not require inventoryItem
 *
 *  Revision 1.1  2010/12/13 19:13:22  mwpxp2
 *  Initial
 *
 */
