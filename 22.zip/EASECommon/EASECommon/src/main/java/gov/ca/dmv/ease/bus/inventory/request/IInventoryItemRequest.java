package gov.ca.dmv.ease.bus.inventory.request;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;

/**
 * Description: I am interface for Inventory-related requests
 * File: IInventoryRequest.java
 * Module:  gov.ca.dmv.ease.bus.dl.inventory.request
 * Created: Sep 14, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2011/04/12 16:40:22 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryItemRequest extends IInventoryRequest {
	/**
	 * Gets the item list.
	 * 
	 * @return the item list
	 * 
	 * @deprecated
	 */
	IInventoryItem getItem();
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryItemRequest.java,v $
 *  Revision 1.2  2011/04/12 16:40:22  mwkfh
 *  deprecated getItem
 *
 *  Revision 1.1  2010/10/07 17:15:48  mwkfh
 *  split getItem and getItemList into separate interfaces from IInventoryRequest
 *
 *  Revision 1.2  2010/09/20 23:17:59  mwpxp2
 *  Extended IRequest
 *
 *  Revision 1.1  2010/09/20 20:29:13  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.2  2010/09/15 23:20:30  mwpxp2
 *  getItemList/0 promoted to interface
 *
 *  Revision 1.1  2010/09/14 23:55:10  mwpxp2
 *  Initial
 *
 */
