/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.cc.record.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

/**
 * Description: This represents the details of the Issued Inventory Record which is attributes needed for 
 * the interface to the bridge code communicating to the legacy system
 * File: IssuedInventoryRecord.java
 * Module:  gov.ca.dmv.ease.bo.cc.record.impl
 * Created: May 27, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/07/22 17:50:33 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class IssuedInventoryRecord {
	/** The inventory Low Order Point. */
	private Boolean isIssuedInventoryLowOrderPoint; // 'Y'=Yes
	/* Called Error Code on the screen.
	 * 
	 * 'E'=I/O ERR 
	 * 'H'=HQ ISSUE 
	 * 'I'=INSUF QNTY 
	 * 'M'=MNL ISSUE 
	 * 'O'=OFFICE 
	 * 'R'=TOO MNY RNGS 
	 * ' '=NONE
	 */
	private CodeSetElement issuedInventoryActionCode;
	/** The inventory BeginningValue. */
	private String issuedInventoryBeginningValue;
	/** The inventory Dependency code. */
	private CodeSetElement issuedInventoryDependencyCode;
	/** The inventory EndingValue. */
	private String issuedInventoryEndingValue;
	/** The inventory item code. */
	private CodeSetElement issuedInventoryItemCode;
	/** The inventory Quantity. */
	private Integer issuedInventoryQuantity;
	/** The problem code. 
	 * D - Damaged
	 * M - Missing
	 * V - Voided
	 * R - Refused */
	private CodeSetElement problemCode;

	/**
	 * @return the issuedInventoryActionCode
	 */
	public CodeSetElement getIssuedInventoryActionCode() {
		return issuedInventoryActionCode;
	}

	/**
	 * @return the issuedInventoryBeginningValue
	 */
	public String getIssuedInventoryBeginningValue() {
		return issuedInventoryBeginningValue;
	}

	/**
	 * @return the issuedInventoryDependencyCode
	 */
	public CodeSetElement getIssuedInventoryDependencyCode() {
		return issuedInventoryDependencyCode;
	}

	/**
	 * @return the issuedInventoryEndingValue
	 */
	public String getIssuedInventoryEndingValue() {
		return issuedInventoryEndingValue;
	}

	/**
	 * @return the issuedInventoryItemCode
	 */
	public CodeSetElement getIssuedInventoryItemCode() {
		return issuedInventoryItemCode;
	}

	/**
	 * @return the issuedInventoryQuantity
	 */
	public Integer getIssuedInventoryQuantity() {
		return issuedInventoryQuantity;
	}

	/**
	 * @return the problemCode
	 */
	public CodeSetElement getProblemCode() {
		return problemCode;
	}

	/**
	 * @return the isIssuedInventoryLowOrderPoint
	 */
	public boolean isIssuedInventoryLowOrderPoint() {
		return isIssuedInventoryLowOrderPoint;
	}

	/**
	 * @param issuedInventoryActionCode the issuedInventoryActionCode to set
	 */
	public void setIssuedInventoryActionCode(
			CodeSetElement issuedInventoryActionCode) {
		this.issuedInventoryActionCode = issuedInventoryActionCode;
	}

	/**
	 * @param issuedInventoryBeginningValue the issuedInventoryBeginningValue to set
	 */
	public void setIssuedInventoryBeginningValue(
			String issuedInventoryBeginningValue) {
		this.issuedInventoryBeginningValue = issuedInventoryBeginningValue;
	}

	/**
	 * @param issuedInventoryDependencyCode the issuedInventoryDependencyCode to set
	 */
	public void setIssuedInventoryDependencyCode(
			CodeSetElement issuedInventoryDependencyCode) {
		this.issuedInventoryDependencyCode = issuedInventoryDependencyCode;
	}

	/**
	 * @param issuedInventoryEndingValue the issuedInventoryEndingValue to set
	 */
	public void setIssuedInventoryEndingValue(String issuedInventoryEndingValue) {
		this.issuedInventoryEndingValue = issuedInventoryEndingValue;
	}

	/**
	 * @param issuedInventoryItemCode the issuedInventoryItemCode to set
	 */
	public void setIssuedInventoryItemCode(
			CodeSetElement issuedInventoryItemCode) {
		this.issuedInventoryItemCode = issuedInventoryItemCode;
	}

	/**
	 * @param isIssuedInventoryLowOrderPoint the isIssuedInventoryLowOrderPoint to set
	 */
	public void setIssuedInventoryLowOrderPoint(
			boolean isIssuedInventoryLowOrderPoint) {
		this.isIssuedInventoryLowOrderPoint = isIssuedInventoryLowOrderPoint;
	}

	/**
	 * @param issuedInventoryQuantity the issuedInventoryQuantity to set
	 */
	public void setIssuedInventoryQuantity(Integer issuedInventoryQuantity) {
		this.issuedInventoryQuantity = issuedInventoryQuantity;
	}

	/**
	 * @param problemCode the problemCode to set
	 */
	public void setProblemCode(CodeSetElement problemCode) {
		this.problemCode = problemCode;
	}
}
