/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.Date;

/**
 * Description: This class holds Fingerprint Related Information
 * File: FingerprintInformation.java
 * Module:  gov.ca.dmv.ease.bo.license.impl
 * Created: Apr 21, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.10 $
 * Last Changed: $Date: 2011/04/07 04:04:52 $
 * Last Changed By: $Author: mwhys $
 */
public class FingerprintInformation extends BusinessObject {
	/** The constant serial version UID. */
	private static final long serialVersionUID = 2779232143829801805L;
	/** Indicates which digit on the customer's hand was captured (for use at the ICS)
	 * Valid codes are: 0 = Right Thumb, 1 = Right Index, 2 = Right Middle, 3 = Right Ring,
	 * 	4 = Right Little, 5 = Left Thumb, 6 = Left Index, 7 = Left Middle, 8 = Left Ring, 9 = Left Little, N = No Digits.
	 * If this field is not applicable, it will contain a space. .*/
	private String digitCapturedCode;
	/** The Date fingerprint was captured.*/
	private Date fingerprintCaptureDate;
	/** The Time fingerprint was captured (HHMMSS).*/
	private String fingerprintCaptureTime;
	/** The Indicates match or other. Valid codes are 'Y' = Matched, 'U' Unavailable, 'N' No match & 'C' CNA  & Space .*/
	private String fingerprintMatchCode;
	/** This is the fingprint threshold assessment: Valid codes are: '1', '2', '3' & '4'.  
	 * If the the message originates from the web application, codes '1' & '2' are used for "Above Threshold" and Below Threshold respectively. 
	 * If the message origin is from the ICS, code '3' & '4' are used for "Above Threshold" and "Below Threshold" respectively. 
	 * If this field is naot applicable, it will contain a space..*/
	private String fingerprintQualityCode;
	/** The MAC Address of fingerprint scanner if message origin is from the web application.*/
	private String scannerId;
	
	/**
	 * Instantiates a new fingerprint information.
	 */
	public FingerprintInformation() {
		super();
	}
	
	/**
	 * Instantiates a new fingerprint information.
	 *
	 * @param dataToCopy the data to copy
	 */
	public FingerprintInformation(FingerprintInformation dataToCopy) {
		super();
		copy(dataToCopy);
	}
	
	/**
	 * Copy.
	 *
	 * @param objectToCopy the data to copy
	 */
	protected void copy(FingerprintInformation objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy method for " + this);
		}
		super.copy(objectToCopy);
		setDigitCapturedCode(objectToCopy.getDigitCapturedCode());
		if (EaseUtil.isNotNull(objectToCopy.getFingerprintCaptureDate())) {
			setFingerprintCaptureDate(new Date(objectToCopy
					.getFingerprintCaptureDate().getTime()));
		}
		else {
			setFingerprintCaptureDate(null);
		}
		setFingerprintCaptureTime(objectToCopy.getFingerprintCaptureTime());
		setFingerprintMatchCode(objectToCopy.getFingerprintMatchCode());
		setFingerprintQualityCode(objectToCopy.getFingerprintQualityCode());
		setScannerId(objectToCopy.getScannerId());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		FingerprintInformation other = (FingerprintInformation) obj;
		if (digitCapturedCode == null) {
			if (other.digitCapturedCode != null) {
				return false;
			}
		}
		else if (!digitCapturedCode.equals(other.digitCapturedCode)) {
			return false;
		}
		if (fingerprintCaptureDate == null) {
			if (other.fingerprintCaptureDate != null) {
				return false;
			}
		}
		else if (!fingerprintCaptureDate.equals(other.fingerprintCaptureDate)) {
			return false;
		}
		if (fingerprintCaptureTime == null) {
			if (other.fingerprintCaptureTime != null) {
				return false;
			}
		}
		else if (!fingerprintCaptureTime.equals(other.fingerprintCaptureTime)) {
			return false;
		}
		if (fingerprintMatchCode == null) {
			if (other.fingerprintMatchCode != null) {
				return false;
			}
		}
		else if (!fingerprintMatchCode.equals(other.fingerprintMatchCode)) {
			return false;
		}
		if (fingerprintQualityCode == null) {
			if (other.fingerprintQualityCode != null) {
				return false;
			}
		}
		else if (!fingerprintQualityCode.equals(other.fingerprintQualityCode)) {
			return false;
		}
		if (scannerId == null) {
			if (other.scannerId != null) {
				return false;
			}
		}
		else if (!scannerId.equals(other.scannerId)) {
			return false;
		}
		return true;
	}
	
	/**
	 * @return the digitCapturedCode
	 */
	public String getDigitCapturedCode() {
		return digitCapturedCode;
	}
	
	/**
	 * @return the fingerprintCaptureDate
	 */
	public Date getFingerprintCaptureDate() {
		return fingerprintCaptureDate;
	}
	
	/**
	 * @return the fingerprintCaptureTime
	 */
	public String getFingerprintCaptureTime() {
		return fingerprintCaptureTime;
	}
	
	/**
	 * @return the fingerprintMatchCode
	 */
	public String getFingerprintMatchCode() {
		return fingerprintMatchCode;
	}
	
	/**
	 * @return the fingerprintQualityCode
	 */
	public String getFingerprintQualityCode() {
		return fingerprintQualityCode;
	}
	
	/**
	 * @return the scannerId
	 */
	public String getScannerId() {
		return scannerId;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((digitCapturedCode == null) ? 0 : digitCapturedCode
						.hashCode());
		result = prime
				* result
				+ ((fingerprintCaptureDate == null) ? 0
						: fingerprintCaptureDate.hashCode());
		result = prime
				* result
				+ ((fingerprintCaptureTime == null) ? 0
						: fingerprintCaptureTime.hashCode());
		result = prime
				* result
				+ ((fingerprintMatchCode == null) ? 0 : fingerprintMatchCode
						.hashCode());
		result = prime
				* result
				+ ((fingerprintQualityCode == null) ? 0
						: fingerprintQualityCode.hashCode());
		result = prime * result
				+ ((scannerId == null) ? 0 : scannerId.hashCode());
		return result;
	}
	
	/**
	 * @param digitCapturedCode the digitCapturedCode to set
	 */
	public void setDigitCapturedCode(String digitCapturedCode) {
		this.digitCapturedCode = digitCapturedCode;
	}
	
	/**
	 * @param fingerprintCaptureDate the fingerprintCaptureDate to set
	 */
	public void setFingerprintCaptureDate(Date fingerprintCaptureDate) {
		this.fingerprintCaptureDate = fingerprintCaptureDate;
	}
	
	/**
	 * @param fingerprintCaptureTime the fingerprintCaptureTime to set
	 */
	public void setFingerprintCaptureTime(String fingerprintCaptureTime) {
		this.fingerprintCaptureTime = fingerprintCaptureTime;
	}
	
	/**
	 * @param fingerprintMatchCode the fingerprintMatchCode to set
	 */
	public void setFingerprintMatchCode(String fingerprintMatchCode) {
		this.fingerprintMatchCode = fingerprintMatchCode;
	}
	
	/**
	 * @param fingerprintQualityCode the fingerprintQualityCode to set
	 */
	public void setFingerprintQualityCode(String fingerprintQualityCode) {
		this.fingerprintQualityCode = fingerprintQualityCode;
	}
	
	/**
	 * @param scannerId the scannerId to set
	 */
	public void setScannerId(String scannerId) {
		this.scannerId = scannerId;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("digitCapturedCode", digitCapturedCode, anIndent,
				aBuilder);
		outputKeyValue("fingerprintCaptureDate", fingerprintCaptureDate,
				anIndent, aBuilder);
		outputKeyValue("fingerprintCaptureTime", fingerprintCaptureTime,
				anIndent, aBuilder);
		outputKeyValue("fingerprintMatchCode", fingerprintMatchCode, anIndent,
				aBuilder);
		outputKeyValue("fingerprintQualityCode", fingerprintQualityCode,
				anIndent, aBuilder);
		outputKeyValue("scannerId", scannerId, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
}
/**
 * Modification History:
 * 
 * $Log: FingerprintInformation.java,v $
 * Revision 1.10  2011/04/07 04:04:52  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.8.10.7  2011/04/05 21:00:59  mwkfh
 * updated copy method
 *
 * Revision 1.8.10.6  2011/04/05 18:14:28  mwhys
 * Moved the code that throws exception from copy-constructor to copy-method.
 *
 * Revision 1.8.10.5  2011/04/04 20:20:05  mwkfh
 * added exception to copy constructor
 *
 * Revision 1.8.10.4  2011/04/04 18:59:11  mwkfh
 * added null check to copy
 *
 * Revision 1.8.10.3  2011/04/04 18:27:45  mwkfh
 * added super.copy to copy
 *
 * Revision 1.8.10.2  2011/04/04 16:40:34  mwkfh
 * changed copy method to protected
 *
 */
