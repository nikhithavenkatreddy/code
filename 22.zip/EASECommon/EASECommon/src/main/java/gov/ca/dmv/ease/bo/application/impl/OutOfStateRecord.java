/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.application.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.license.impl.OutOfStateLicense;
import gov.ca.dmv.ease.bo.subject.impl.Person;

import java.io.Serializable;
import java.util.List;

/**
 * Description: This class captures information to process 10Q-State of Record (Out of State) Inquiry
 * File: OutOfStateRecord.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: May 13, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.12 $
 * Last Changed: $Date: 2013/10/25 17:49:24 $
 * Last Changed By: $Author: mwskh1 $
 */
public class OutOfStateRecord implements Serializable {
	/** The serialVersionUID. */
	private static final long serialVersionUID = -5112027507516083202L;
	/** The accidents. The fixed length of characters from the 10Q ttc response
	 * for all accident data H4 to next HX as calculated by requirements.
	*/
	private String accidents;
	/** The Applicant. */
	private Person applicant;
	/** The cdlis or pdps indicator */
	private String cdlisOrPdpsIndicator;
	/** The convictions.  The fixed length of characters from the 10Q ttc response
	 * for all conviction data H3 to next HX as calculated by requirements.
	*/
	private String convictions;
	/** The licenses. */
	private String licenses;
	/** The medical history indicator. */
	private String medicalHistoryIndicator;
	/** The names.  The fixed length of characters from the 10Q ttc response
	 * for all aka names data.  Current Name (680) through 3rd AKA Name (750 + 35) 35 bytes each
	*/
	private String names;
	/** The out of state license. */
	private OutOfStateLicense outOfStateLicense;
	// Can be in OutOfStateLicense
	/** The pendingWithdrawl flag. */
	private List <CodeSetElement> pendingWithdrawl;
	/** The pending withdrawl indicator. */
	private String pendingWithdrawlIndicator;
	/** The permits.  The fixed length of characters from the 10Q ttc response
	 * for all permit data H2 to next HX as calculated by requirements.
	*/
	private String permits;
	/** The restrictions. */
	private Boolean restrictions;
	/** The restrictions.  The fixed length of characters from the 10Q ttc response
	 * for all restrictions data appended into one string.  49 bytes each (no end filler)
	*/
	private String restrictionsBytes;
	/** The total accidents. */
	private String totalAccidents;
	/** The total accidents on record. */
	private String totalAccidentsOnRecord;
	/** The total convictions. */
	private String totalConvictions;
	/** The total convictions on record. */
	private String totalConvictionsOnRecord;
	/** The total permits. */
	private String totalPermits;
	/* The below fields are required by the document generator for fields not displayed in the UI */
	/** The licenses.  The fixed length of characters from the 10Q ttc response
	 * for all license number data.  Current State Code (888) through 3RD AKA DL NUMBER (971 + 35) 27 characters each
	*/
	/** The total restrictions. */
	private String totalRestrictions;
	/** The total withdrawals. */
	private String totalWithdrawals;
	/** The total withdrawals on record. */
	private String totalWithdrawalsOnRecord;
	/** The withdrawals. The fixed length of characters from the 10Q ttc response
	 * for all withdrawal data H5 to end as calculated by requirements.
	 * */
	private String withdrawals;
	/** CDLIS 5.2  A temporary flag to be used for CDLIS 5.2 testing.  Gap code is an origin code */
	private boolean isAcGapCodeEnabled = false;

	/**
	 * Instantiates a new out of state record.
	 */
	public OutOfStateRecord() {
		super();
	}

	/**
	 * Instantiates a new out of state record.
	 *
	 * @param aPerson the a person
	 */
	public OutOfStateRecord(Person aPerson) {
		super();
		setApplicant(aPerson);
	}

	/**
	 * Gets the accidents.
	 *
	 * @return the accidents
	 */
	public String getAccidents() {
		return accidents;
	}

	/* Fields from person for doc gen
	private CodeSetElement genderCode;
	private CodeSetElement eyeColorCode;
	private Integer heightInFeet;
	private Integer heightInInch;
	private Integer weight;
	private Date birthDate;
	 */
	/**
	 * Gets the applicant.
	 *
	 * @return the applicant
	 */
	public Person getApplicant() {
		return applicant;
	}

	/**
	* Gets the cdlis or pdps indicator
	* 
	* @return the cdlisOrPdpsIndicator
	*/
	public String getCdlisOrPdpsIndicator() {
		return cdlisOrPdpsIndicator;
	}

	/**
	 * Gets the convictions.
	 *
	 * @return the convictions
	 */
	public String getConvictions() {
		return convictions;
	}

	/**
	 * Gets the licenses.
	 *
	 * @return the licenses
	 */
	public String getLicenses() {
		return licenses;
	}

	/**
	 * Gets the medical history indicator.
	 *
	 * @return the medical history indicator
	 */
	public String getMedicalHistoryIndicator() {
		return medicalHistoryIndicator;
	}

	/**
	 * Gets the names.
	 *
	 * @return the names
	 */
	public String getNames() {
		return names;
	}

	/**
	 * Gets the out of state license.
	 *
	 * @return the outOfStateLicense
	 */
	public OutOfStateLicense getOutOfStateLicense() {
		return outOfStateLicense;
	}

	/**
	 * Gets the pending withdrawl.
	 *
	 * @return the pendingWithdrawl
	 */
	public List <CodeSetElement> getPendingWithdrawl() {
		return pendingWithdrawl;
	}

	/**
	 * Gets the pending withdrawl indicator.
	 *
	 * @return the pending withdrawl indicator
	 */
	public String getPendingWithdrawlIndicator() {
		return pendingWithdrawlIndicator;
	}

	/**
	 * Gets the permits.
	 *
	 * @return the permits
	 */
	public String getPermits() {
		return permits;
	}

	/**
	 * Gets the restrictions.
	 *
	 * @return the restrictions
	 */
	public Boolean getRestrictions() {
		return restrictions;
	}

	/**
	 * Gets the restrictions bytes.
	 *
	 * @return the restrictions bytes
	 */
	public String getRestrictionsBytes() {
		return restrictionsBytes;
	}

	/**
	 * Gets the total accidents.
	 *
	 * @return the total accidents
	 */
	public String getTotalAccidents() {
		return totalAccidents;
	}

	/**
	 * Gets the total accidents on record.
	 *
	 * @return the total accidents on record
	 */
	public String getTotalAccidentsOnRecord() {
		return totalAccidentsOnRecord;
	}

	/**
	 * Gets the total convictions.
	 *
	 * @return the total convictions
	 */
	public String getTotalConvictions() {
		return totalConvictions;
	}

	/**
	 * Gets the total convictions on record.
	 *
	 * @return the total convictions on record
	 */
	public String getTotalConvictionsOnRecord() {
		return totalConvictionsOnRecord;
	}

	/**
	 * Gets the total permits.
	 *
	 * @return the total permits
	 */
	public String getTotalPermits() {
		return totalPermits;
	}

	/**
	 * Gets the total restrictions.
	 *
	 * @return the total restrictions
	 */
	public String getTotalRestrictions() {
		return totalRestrictions;
	}

	/**
	 * Gets the total withdrawals.
	 *
	 * @return the total withdrawals
	 */
	public String getTotalWithdrawals() {
		return totalWithdrawals;
	}

	/**
	 * Gets the total withdrawals on record.
	 *
	 * @return the total withdrawals on record
	 */
	public String getTotalWithdrawalsOnRecord() {
		return totalWithdrawalsOnRecord;
	}

	/**
	 * Gets the withdrawals.
	 *
	 * @return the withdrawals
	 */
	public String getWithdrawals() {
		return withdrawals;
	}

	/**
	 * Sets the accidents.
	 *
	 * @param accidents the new accidents
	 */
	public void setAccidents(String accidents) {
		this.accidents = accidents;
	}

	/**
	 * Sets the applicant.
	 *
	 * @param applicant the applicant to set
	 */
	public void setApplicant(Person applicant) {
		this.applicant = applicant;
	}

	/**
	 * Sets the cdlis or pdps indicator
	 * 
	 * @param cdlisOrPdpsIndicator the cdlisOrPdpsIndicator to set
	 */
	public void setCdlisOrPdpsIndicator(String cdlisOrPdpsIndicator) {
		this.cdlisOrPdpsIndicator = cdlisOrPdpsIndicator;
	}

	/**
	 * Sets the convictions.
	 *
	 * @param convictions the new convictions
	 */
	public void setConvictions(String convictions) {
		this.convictions = convictions;
	}

	/**
	 * Sets the licenses.
	 *
	 * @param licenses the new licenses
	 */
	public void setLicenses(String licenses) {
		this.licenses = licenses;
	}

	/**
	 * Sets the medical history indicator.
	 *
	 * @param medicalHistoryIndicator the new medical history indicator
	 */
	public void setMedicalHistoryIndicator(String medicalHistoryIndicator) {
		this.medicalHistoryIndicator = medicalHistoryIndicator;
	}

	/**
	 * Sets the names.
	 *
	 * @param names the new names
	 */
	public void setNames(String names) {
		this.names = names;
	}

	/**
	 * Sets the out of state license.
	 *
	 * @param outOfStateLicense the outOfStateLicense to set
	 */
	public void setOutOfStateLicense(OutOfStateLicense outOfStateLicense) {
		this.outOfStateLicense = outOfStateLicense;
	}

	/**
	 * Sets the pending withdrawl.
	 *
	 * @param pendingWithdrawl the pendingWithdrawl to set
	 */
	public void setPendingWithdrawl(List <CodeSetElement> pendingWithdrawl) {
		this.pendingWithdrawl = pendingWithdrawl;
	}

	/**
	 * Sets the pending withdrawl indicator.
	 *
	 * @param pendingWithdrawlIndicator the new pending withdrawl indicator
	 */
	public void setPendingWithdrawlIndicator(String pendingWithdrawlIndicator) {
		this.pendingWithdrawlIndicator = pendingWithdrawlIndicator;
	}

	/**
	 * Sets the permits.
	 *
	 * @param permits the new permits
	 */
	public void setPermits(String permits) {
		this.permits = permits;
	}

	/**
	 * Sets the restrictions.
	 *
	 * @param restrictions the restrictions to set
	 */
	public void setRestrictions(Boolean restrictions) {
		this.restrictions = restrictions;
	}

	/**
	 * Sets the restrictions bytes.
	 *
	 * @param restrictionsBytes the new restrictions bytes
	 */
	public void setRestrictionsBytes(String restrictionsBytes) {
		this.restrictionsBytes = restrictionsBytes;
	}

	/**
	 * Sets the total accidents.
	 *
	 * @param totalAccidents the new total accidents
	 */
	public void setTotalAccidents(String totalAccidents) {
		this.totalAccidents = totalAccidents;
	}

	/**
	 * Sets the total accidents on record.
	 *
	 * @param totalAccidentsOnRecord the new total accidents on record
	 */
	public void setTotalAccidentsOnRecord(String totalAccidentsOnRecord) {
		this.totalAccidentsOnRecord = totalAccidentsOnRecord;
	}

	/**
	 * Sets the total convictions.
	 *
	 * @param totalConvictions the new total convictions
	 */
	public void setTotalConvictions(String totalConvictions) {
		this.totalConvictions = totalConvictions;
	}

	/**
	 * Sets the total convictions on record.
	 *
	 * @param totalConvictionsOnRecord the new total convictions on record
	 */
	public void setTotalConvictionsOnRecord(String totalConvictionsOnRecord) {
		this.totalConvictionsOnRecord = totalConvictionsOnRecord;
	}

	/**
	 * Sets the total permits.
	 *
	 * @param totalPermits the new total permits
	 */
	public void setTotalPermits(String totalPermits) {
		this.totalPermits = totalPermits;
	}

	/**
	 * Sets the total restrictions.
	 *
	 * @param totalRestrictions the new total restrictions
	 */
	public void setTotalRestrictions(String totalRestrictions) {
		this.totalRestrictions = totalRestrictions;
	}

	/**
	 * Sets the total withdrawals.
	 *
	 * @param totalWithdrawals the new total withdrawals
	 */
	public void setTotalWithdrawals(String totalWithdrawals) {
		this.totalWithdrawals = totalWithdrawals;
	}

	/**
	 * Sets the total withdrawals on record.
	 *
	 * @param totalWithdrawalsOnRecord the new total withdrawals on record
	 */
	public void setTotalWithdrawalsOnRecord(String totalWithdrawalsOnRecord) {
		this.totalWithdrawalsOnRecord = totalWithdrawalsOnRecord;
	}

	/**
	 * Sets the withdrawals.
	 *
	 * @param withdrawals the new withdrawals
	 */
	public void setWithdrawals(String withdrawals) {
		this.withdrawals = withdrawals;
	}

	/**
	 * CDLIS 5.2 Sets the non commercial license status.
	 *
	 * @param isAC_GapCodeEnabled the isAC_GapCodeEnabled to set
	 */
	public void setAcGapCodeEnabled(boolean isAcGapCodeEnabled) {
		this.isAcGapCodeEnabled = isAcGapCodeEnabled;
	}

	/**
	 * CDLIS 5.2 Checks if is AC Gap code in use.
	 *
	 * @return true, if AC Gap code in use
	 */
	public boolean isAcGapCodeEnabled() {
		return isAcGapCodeEnabled;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OutOfStateRecord.java,v $
 *  Revision 1.12  2013/10/25 17:49:24  mwskh1
 *  CDLIS 5.2 - Fixed typo in setAcGapCodeEnabled
 *
 *  Revision 1.11  2013/10/03 15:11:39  mwskh1
 *  CDLIS 5.2 - Code review changes
 *
 *  Revision 1.10  2013/10/01 20:56:30  mwskh1
 *  CDLIS 5.2 - added flag to check if AC gap code in use
 *
 *  Revision 1.9  2011/10/12 21:01:17  mwkkc
 *  Performance Merge
 *
 *  Revision 1.8.10.1  2011/09/26 05:29:03  mwpxp2
 *  Added constructor on person; added missing javadoc
 *
 *  Revision 1.8  2011/04/14 23:12:11  mwjxa11
 *  Incorporated the change request updates
 *
 *  Revision 1.7  2010/12/23 06:18:24  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.6.8.2  2010/12/23 03:13:55  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.6.8.1  2010/12/22 17:38:59  mwhys
 *  Serialized.
 *
 *
 */
