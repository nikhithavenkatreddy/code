/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.document.impl;

import static gov.ca.dmv.ease.app.constants.IDlApplicationPendingCodesConstants.DL_ID_PENDED;
import static gov.ca.dmv.ease.app.constants.IDlApplicationPendingCodesConstants.DRIVER_LICENSE_PENDED;
import static gov.ca.dmv.ease.app.constants.IDlApplicationPendingCodesConstants.ID_CARD_PENDED;
import static gov.ca.dmv.ease.app.constants.ITtcConstants.DL_TTC;
import static gov.ca.dmv.ease.app.constants.ITtcConstants.ID_TTC;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_ELG;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_EXP;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_LIC;
import static gov.ca.dmv.ease.ecs.convert.IEcsConverterConstants.OUTPUT_COMM_STATUS_DESC_VAL;
import static gov.ca.dmv.ease.fw.util.impl.ArrayUtils.contains;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNullAndIsTrue;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import static java.lang.Boolean.TRUE;
import gov.ca.dmv.ease.app.constants.IDocScanConstants;
import gov.ca.dmv.ease.app.constants.ITtcConstants;
import gov.ca.dmv.ease.app.constants.PrintRequestTypes;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.dl.exams.impl.KnowledgeExam;
import gov.ca.dmv.ease.bo.dl.record.impl.DrivingRecord;
import gov.ca.dmv.ease.bo.financial.impl.InvoiceItem;
import gov.ca.dmv.ease.bo.license.CnaConditionType;
import gov.ca.dmv.ease.bo.license.impl.DriverLicense;
import gov.ca.dmv.ease.bo.license.impl.IdCard;
import gov.ca.dmv.ease.bo.subject.impl.Person;
import gov.ca.dmv.ease.bo.subject.impl.PersonName;
import gov.ca.dmv.ease.bo.tx.IProcessHistory;
import gov.ca.dmv.ease.bo.tx.impl.LicenseType;
import gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: DlApplication class is the subclass of Application and
 * represents the DL application document. DlApplication object encapsulates
 * most of the attributes of DL Application used for obtaining driver license.
 * File: DLApplication.java
 * Module: gov.ca.dmv.ease.bo.document.impl
 * Created: Apr 28, 2009
 * 
 * @author MWCSJ3
 * @version $Revision: 1.153.4.5 $
 * Last Changed: $Date: 2014/07/31 18:08:00 $
 * Last Changed By: $Author: mwlcr1 $
 */
public class DlApplication extends Application implements IDocScanConstants {
	/** The Constant BLANK. */
	private static final String BLANK = "";
	/** The Constant FIRE_FIGHTER_CLASS_A. */
	private static final String FIRE_FIGHTER_CLASS_A = "1";
	/** The Constant FIRE_FIGHTER_CLASS_B. */
	private static final String FIRE_FIGHTER_CLASS_B = "2";
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory.getLog(DlApplication.class);
	/** list of legal presence verification code values that indicate that document scanning is required. */
	private static final List <String> LPV_DOCTYPE_CDS_REQ_DOC_SCAN;
	/** The OUTPUT_COMM_STATUS_ELG. */
	private static final String OUTPUT_COMM_STATUS_ELG = "A";
	/** The OUTPUT_COMM_STATUS_EXP. */
	private static final String OUTPUT_COMM_STATUS_EXP = "6";
	/** The OUTPUT_COMM_STATUS_LIC. */
	private static final String OUTPUT_COMM_STATUS_LIC = "B";
	/** The OUTPUT_COMM_STATUS_VAL. */
	private static final String OUTPUT_COMM_STATUS_VAL = "8";
	/** The Constant PDPS_ELIGIBILITY_STATUS_DESC. 
	 * ELIGIBLE, LICENSED, VALID, EXPIRED */
	private static final Object[] PDPS_ELIGIBILITY_STATUS_DESC = {
			OUTPUT_COMM_STATUS_DESC_ELG, OUTPUT_COMM_STATUS_DESC_LIC,
			OUTPUT_COMM_STATUS_DESC_VAL, OUTPUT_COMM_STATUS_DESC_EXP };
	/** The PDPS_ELIGIBLE. */
	private static final String PDPS_ELIGIBLE = "E";
	/** The PDPS_NOT_ELIGIBLE. */
	private static final String PDPS_NOT_ELIGIBLE = "N";
	/** The QUESTIONABLE (Driving record designate action). */
	private static final String QUESTIONABLE = "Q";
	/** The SAME (Driving record designate action). */
	private static final String SAME = "S";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7003276619308844896L;
	/** The Constant STATUS_CODE_NONE. */
	private static final String STATUS_CODE_NONE = "NONE";
	/** The commercial license classes. */
	private static final List <String> COMM_LICENSE_CLASSES = Arrays.asList(
			"A", "B", "C");
	/** The non commercial license classes. */
	private static final List <String> NON_COMM_LIC_CLASSES = Arrays.asList(
			"D", "E", "F", "M");
	static {
		LOGGER.info("initializing LPV_DOCTYPE_CDS_REQ_DOC_SCAN list in static initializer");
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN = new ArrayList <String>();
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(MEXICAN_PASSPORT); //3.1.2.2 AB60 definition change//
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(CERTIFICATE_OF_CITIZENSHIP);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN
				.add(INDIAN_BLOOD_DECREE_NORTH_MARIANA_AMERICAN_INDIAN);//3.1.2.2 AB60 definition change//
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(CLEARED_INV_SECONDARY_REVIEW);
		/**2.2.3.18 - 2.2.3.18 When new keyed BD/LP code = �J�, system shall display the message: 0013-DATA DOES NOT MATCH VALID CODES. definition change*/
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(US_CITIZEN_ID_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(RESIDENT_ALIEN_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(TEMPORARY_RESIDENT_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(CANADIAN_PASSPORT);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(CANADIAN_BIRTH_CERT);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN
				.add(NONRESIDENT_ALIEN_CANADIAN_BORDER_CROSSING_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(RECORD_OF_ARRIVAL_OR_DEPARTURE_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(EMPLOYMENT_AUTHORIZATION_DOCUMENT);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(TEMPORARY_EVIDENCE_STAMP);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(MEXICAN_BORDER_CROSSING_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(NOT_VERIFIED_ELECTRONICALLY);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(MEXICAN_IFE_VOTER_CARD);
		/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'OR '2'*/
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(RE_ENTRY_PERMIT);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(PERMANENT_RESIDENT_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(REFUGEE_TRAVEL_DOCUMENT);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(I688A_EMPLOYMENT_AUTHORIZATION_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(I688B_EMPLOYMENT_AUTHORIZATION_CARD);
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN.add(AB60_LICENSE_TYPE_DOCUMENT_S);
		/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'*/
		LPV_DOCTYPE_CDS_REQ_DOC_SCAN
				.add(MEXICAN_CONSULAR_CARD_MEXICAN_VOTER_CARD);
		/**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'*/
		LOGGER.info("done initializing LPV_DOCTYPE_CDS_REQ_DOC_SCAN list in static initializer");
	}
	/** The acceptRecordIndicator. */
	private CodeSetElement acceptRecordIndicator;
	/** Another photo. */
	private CodeSetElement anotherPhoto;
	/** This represents the attachmentCode (51 - Medical Report...) */
	private CodeSetElement attachmentCode;
	/** The backend update required without cda. */
	private boolean backendUpdateRequiredWithoutCda;
	/** The CDLIS notification date. */
	private Date cdlisNotificationDate;
	/** The CDLIS notification type. N=ADD; C=CHANGE STATE OF RECORD */
	private CodeSetElement cdlisNotificationType;
	/** Indicator for remove restrictions in CDLIS/PDPS response screen.*/
	private Boolean cdlisPdpsResponseIndicator = Boolean.FALSE;
	/** The cdlis pdps result hits processed. */
	private boolean cdlisPdpsResultHits1Processed = false;
	/** The cdlis pdps result hits2 processed. */
	private boolean cdlisPdpsResultHits2Processed = false;
	//*********CDLIS/PDPS FISRT INQUIRY*********
	/** CDLIS system results. */
	private List <DrivingRecord> cdlisResultHits1 = new ArrayList <DrivingRecord>();
	//*********CDLIS/PDPS SECOND INQUIRY*********
	/** CDLIS system results. */
	private List <DrivingRecord> cdlisResultHits2 = new ArrayList <DrivingRecord>();
	//*********CDLIS/PDPS INQUIRY END*********
	/** The CDLIS transfer type. I=INTO CALIFORNIA; O=OUT OF CALIFORNIA */
	private CodeSetElement cdlisTransferType;
	/** The Applicant with old values (Name, BD, Gender, DL#). */
	private Person changedApplicant;
	/** Changed DriverEducationCode from EDIT APPLICATION DATA page. */
	private CodeSetElement changedDriverEducationCode;
	/** The changed driver education status code. */
	private CodeSetElement changedDriverEducationStatusCode;
	/** Changed DriverTrainingCode from EDIT APPLICATION DATA page. */
	private CodeSetElement changedDriverTrainingCode;
	/** The changed driver training status code. */
	private CodeSetElement changedDriverTrainingStatusCode;
	/** Check Legal Presence Y/N. */
	private Boolean checkLegalPresence = true;
	/** The class c drive test failed fee indicator. */
	private Boolean classcDriveTestFailedFeeIndicator = Boolean.FALSE;
	/** The class f drive test failed fee indicator. */
	private Boolean classfDriveTestFailedFeeIndicator = Boolean.FALSE;
	/** The voter registration comlDlDriveTestFeeUsedIndicator. */
	private Boolean comlDlDriveTestFeeUsedIndicator = Boolean.FALSE;
	/** The DL Print Request Document Code 1= Interim License, 2 = Instr Permit etc. */
	private CodeSetElement dlPrintRequestDocumentCode;
	/** The Driver Education Code. */
	private CodeSetElement driverEducationCode;
	/** The driver education record number DE#. */
	private String driverEducationRecordNumber;
	/** The Driver Education Status Code. */
	private CodeSetElement driverEducationStatusCode;
	/** The driver education status code read only for cda. 
	 *  CDA transaction can only read from this field. */
	private CodeSetElement driverEducationStatusCodeReadOnlyForCda;
	/** The Driver Training Code. */
	private CodeSetElement driverTrainingCode;
	/** The driver training record. DT# */
	private String driverTrainingRecordNumber;
	/** The Driver Training Code. */
	private CodeSetElement driverTrainingStatusCode;
	/** The driver training status code read only for cda. 
	 *  CDA transaction can only read from this field. */
	private CodeSetElement driverTrainingStatusCodeReadOnlyForCda;
	/** The eli hit counter. */
	private Integer eliHitCounter;
	/** The exams last sent to AKTS. */
	private Set <KnowledgeExam> examsLastSentToAkts;
	/** The existing SSN. This is SSN on the record. */
	private String existingSsn;
	/** The existing user verified bdlp code. This hold BD/LP code returned from the back end in the DL# inquiry response. */
	private CodeSetElement existingUserVerifiedBdlpCode;
	/** The Existing User Verified SSN Code. This is SSN verified code on the record. */
	private CodeSetElement existingUserVerifiedSsnCode;
	/** The temp system generated incomplete app reason code. */
	//private CodeSetElement tempSystemGeneratedIncompleteAppReasonCode = null;
	/** The Reason Code for Fee Required Value. */
	private CodeSetElement feeRequiredReasonCode;
	/** The finger print image retrieval map. */
	private Map <String, Boolean> fingerPrintImageRetrievalMap = new HashMap <String, Boolean>();
	/** The fire fighter fee paidindicator. */
	private Boolean fireFighterFeePaidIndicator = Boolean.FALSE;
	/** The fire fighter fee req indicator. */
	private Boolean fireFighterFeeReqIndicator = Boolean.FALSE;
	/** The gen cna drive test fee due fee indicator. */
	private Boolean genCnaDriveTestFeeDueFeeIndicator = Boolean.FALSE;
	/** The gen comm dl app fee indicator. */
	private Boolean genCommDlAppFeeIndicator = Boolean.FALSE;
	/** The gen comm dl app fee indicator. */
	private Boolean genCommDlAppFeePaidIndicator = Boolean.FALSE;
	/** The gen comm dl drv fee indicator. */
	private Boolean genCommDlDrvFeeIndicator = Boolean.FALSE;
	/** The 10 Year History Record Check. */
	private CodeSetElement historyRecord10YearCheck;
	/** The cdlis/pdps inquiry response code. This holds the status of cdlis inquiry for CDU Tcode. M = MAX EXCEEDED, P = PARTIAL RESPONSE, T = TIMEOUT, C = CNA, L = LENGTH ERROR, E = ERROR, U = UNDELIVERABLE */
	private CodeSetElement inquiryResponseCode1;
	/** The cdlis/pdps inquiry response code. This holds the status of cdlis inquiry for CDU Tcode. M = MAX EXCEEDED, P = PARTIAL RESPONSE, T = TIMEOUT, C = CNA, L = LENGTH ERROR, E = ERROR, U = UNDELIVERABLE */
	private CodeSetElement inquiryResponseCode2;
	/** The Absent Parent Indicator. All original and renewal DL Applications are checked against the Absent Parent File. �The Absent Parent File is a consolidation of names submitted by local county Family Support Agency offices, which have unresolved child support orders or judgments. �DCSS provides DMV this list of customers who are delinquent with child support orders or judgments. */
	private Boolean isAbsentParent = Boolean.FALSE;
	/** LEGAL PRESENCE PHASE 3 INDICATOR (SPACE OR Y) - Represents CDLIS/NDR Response available. */
	private Boolean isCdlisNdrResponseAvailable;
	/** Is CDLIS/PDPS cleared (by Issuance) in CDLIS/PDPS response screen. */
	private Boolean isCdlisPdpsCleared;
	/** The is commercial remove restriction indicator. REM RESTR field on CDLIS/PDPS response. To remove CDL restriction that requires a driving test. If restriction is removed generate CDL driving test fee. */
	private Boolean isCommercialRemoveRestrictionIndicator;
	/** The Indicator if DL Application was completed by HQ. CK LP. */
	private Boolean isDlApplicationCompletedByHq;
	/** The is dl id number for cna condition. */
	private Boolean isDlIdNumberForCnaCondition;
	/** The is eligible for restriction COE. Determines whether application is eligible for Course Of Employment restriction code '04'. */
	/**COE = Course Of Employment*/
	private Boolean isEligibleForRestrictionCoe;
	/** The ASVI Check Bypass Indicator. ASVI - Alien Status Verification Index is same as Legal Presence Inquiry. Set this variable to True if an Issuance Office would like to bypass Legal Presence verification. */
	private Boolean isLegalPresenceCheckBypassIndicator;
	/** The indicator for limited term legal presence. */
	private Boolean isLimitedTermIndicator;
	/** The is name change. */
	private Boolean isNameChanged = Boolean.FALSE;
	/** The is new number required. New # REQ # */
	private Boolean isNewLicenseNumberRequired;
	/** The Indicator for Organ Donor. */
	private Boolean isOrganDonor;
	/** The Indicator for Original Application. */
	private Boolean isOriginalApplicationIndicator = Boolean.TRUE;
	/** The is original for cna condition. */
	private Boolean isOriginalForCnaCondition;
	/** The Questionable PDPS Indicator. It is set to True if we have a mismatch with a selected PDPS entry. If the user selected someone from the PDPS list who does not seem to be a perfect match to the current person. */
	private Boolean isQuestionablePdpsIndicator;
	/** The is temporary license printed on DL print request screen. The logic to set the value is in Print Document Converters. */
	private boolean isTemporaryLicensePrinted = false;
	/** Indicates that a review of medical documents is required. */
	private Boolean medicalHqReviewRequiredIndicator;
	/** The Military Duty Code. */
	private CodeSetElement militaryDutyCode;
	/** The motor cycle retest req indicator. */
	private Boolean motorCycleRetestPaidIndicator = Boolean.FALSE;
	/** The motor cycle retest req indicator. */
	private Boolean motorCycleRetestReqIndicator = Boolean.FALSE;
	/** The motor cycle retest req indicator. */
	private Boolean motorCycleRetestUsedIndicator = Boolean.FALSE;
	/** The MotorCycle Training Status Code. */
	private CodeSetElement motorCycleTrainingCode;
	/** The Current Application Reason Code. */
	private CodeSetElement newIncompleteApplicationReasonCode;
	/** The User Verified BD/LP code. This code denotes the type of BD or LP document that was captured by the user for the DL application /** Sample Codes: A-American Birth Cert etc.. */
	private CodeSetElement newUserVerifiedBdlpCode;
	/** The New User Verified Ssn Code. Sample Codes: D - Verified by DMV; R - Verification Required; X - Not Verified */
	private CodeSetElement newUserVerifiedSsnCode;
	/** The non commercial drive retest fee req indicator. */
	private Boolean nonCommercialDriveRetestFeePaidIndicator = Boolean.FALSE;
	/** The non commercial drive retest fee req indicator. */
	private Boolean nonCommercialDriveRetestFeeReqIndicator = Boolean.FALSE;
	/** The non commercial drive retest fee req indicator. */
	private Boolean nonCommercialDriveRetestFeeUsedIndicator = Boolean.FALSE;
	/** The operational mode. */
	private CodeSetElement operationalMode;
	/** The Driver Education/Training waiver code. R/P code (R - Permits DE/DT to be waived). */
	private CodeSetElement outOfStateDriverEducationAndTrainingWaiveCode;
	/** The outstanding knowledge exams for this application. */
	private Set <KnowledgeExam> outstandingKnowledgeExams;
	/** The paid invoice item. */
	private InvoiceItem paidInvoiceItem;
	/** The pdps inquiry indicator. */
	private String pdpsInquiryIndicator;
	/** PDPS system results. */
	private List <DrivingRecord> pdpsResultHits1 = new ArrayList <DrivingRecord>();
	/** PDPS system results. */
	private List <DrivingRecord> pdpsResultHits2 = new ArrayList <DrivingRecord>();
	// TODO Should be removed after ELiRecord copy method is fixed.
	/** The pending applied License Classes for a Driver License. */
	private List <CodeSetElement> pendingAppliedLicenseClasses;
	/** The Photo Retrieved. */
	private CodeSetElement photoRetrieved;
	/** The photo taken type. */
	private CodeSetElement photoTakenType;
	/** The physical or mental problem code. */
	private CodeSetElement physicalOrMentalProblemCode;
	/** The previous user verified bdlp code. */
	private CodeSetElement previousUserVerifiedBdlpCode;
	/** The Previous User Verified SSN Code. This is SSN verified code on the pending record. */
	private CodeSetElement previousUserVerifiedSsnCode;
	/** The print request document code from dl id transaction. */
	private String printRequestDocumentCodeFromDlIdTransaction;
	/** The print request types. */
	private Set <PrintRequestTypes> printRequestTypes;
	/** The renewal by mail no fee indicator. */
	private Boolean renewalByMailNoFeeIndicator = Boolean.FALSE;
	/** The total application fee amount paid. */
	private int totalAppFeeAmountPaid = 0;
	/** The total pdps records count FIRST inquiry. */
	private int totalPdpsRecordsCount1 = 0;
	/** The total pdps records count for SECOND inquiry. */
	private int totalPdpsRecordsCount2 = 0;
	/** The BDLP code entered by a user - not to be changed by any other business logic!. */
	private CodeSetElement userEnteredBdlpCode;
	/** The voter registration requested. */
	private CodeSetElement voterRegistationRequested;
	/** The legal presence employee id. VTSLPEMP_LegalPresenceEmployeeId */
	private String legalPresenceEmployeeId;
	/** The is lpv secondary verification required. */
	private boolean isLpvSecondaryVerificationRequired = false;

	/**
	 * Default Constructor.
	 */
	public DlApplication() {
		super();
	}

	/**
	 * Instantiates a new dl application.
	 * 
	 * @param dataToCopy the data to copy
	 */
	public DlApplication(DlApplication dataToCopy) {
		super();
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null dlApplication argument expected in copy constructor in "
							+ this);
		}
		copy(dataToCopy);
	}

	/**
	 * Adds the exam last sent to akts.
	 *
	 * @param exam the exam
	 */
	public void addExamLastSentToAkts(KnowledgeExam exam) {
		getExamsLastSentToAkts().add(exam);
	}

	/**
	 * Adds the in finger print image retrieval map.
	 */
	public void addInFingerPrintImageRetrievalMap() {
		clearFingerPrintImageRetrievalMap();
		String key = generateKeyForFingerPrintResponseWaitedForRequests();
		if (!EaseUtil.isNullOrBlank(key)) {
			Boolean value = getFingerPrintImageRetrievalMap().get(key);
			if (value == null) {
				getFingerPrintImageRetrievalMap().put(key, Boolean.FALSE);
			}
		}
	}

	/**
	 * Adds the outstanding knowledge exam.
	 *
	 * @param exam the exam
	 */
	public void addOutstandingKnowledgeExam(KnowledgeExam exam) {
		getOutstandingKnowledgeExams().add(exam);
	}

	/**
	 * Clear existing ssn.
	 */
	public void clearExistingSsn() {
		setExistingSsn(BLANK);
	}

	/**
	 * Clear existing user verified ssn code.
	 */
	public void clearExistingUserVerifiedSsnCode() {
		setExistingUserVerifiedSsnCode(new CodeSetElement());
	}

	/**
	 * Clear finger print image retrieval map.
	 */
	private void clearFingerPrintImageRetrievalMap() {
		getFingerPrintImageRetrievalMap().clear();
	}

	/**
	 * Clear new user verified ssn code.
	 */
	public void clearNewUserVerifiedSsnCode() {
		setNewUserVerifiedSsnCode(new CodeSetElement());
	}

	/**
	 * Clear previous user verified ssn code.
	 */
	public void clearPreviousUserVerifiedSsnCode() {
		setPreviousUserVerifiedSsnCode(new CodeSetElement());
	}

	/**
	 * Clear ssn.
	 */
	public void clearSsn() {
		if (getApplicant() != null) {
			SocialSecurityDocument socialSecurityDocument = getApplicant()
					.getSocialSecurityDocument();
			if (socialSecurityDocument != null) {
				socialSecurityDocument.setSsn(BLANK);
			}
		}
	}

	/**
	 * Copy.
	 * 
	 * @param dataToCopy the data to copy
	 */
	protected void copy(DlApplication dataToCopy) {
		//TODO: this implementation is incomplete.
		if (!EaseUtil.isNullOrBlank(dataToCopy.getApplicant())) {
			setApplicant(new Person(dataToCopy.getApplicant()));
		}
		//Changed applicant
		if (!EaseUtil.isNullOrBlank(dataToCopy.getChangedApplicant())) {
			setChangedApplicant(new Person(dataToCopy.getChangedApplicant()));
		}
		if (!EaseUtil.isNullOrBlank(dataToCopy
				.getNewIncompleteApplicationReasonCode())) {
			setNewIncompleteApplicationReasonCode(new CodeSetElement(
					dataToCopy.getNewIncompleteApplicationReasonCode()));
		}
	}

	/**
	 * Does dl exist for id transaction.
	 *
	 * @param ttc the ttc
	 * @return true, if successful
	 */
	public boolean doesDlExistForIdTransaction(String ttc) {
		if (ArrayUtils.contains(ID_TTC, ttc)) {
			DriverLicense driverLicense = getApplicant().getDriverLicense();
			if (driverLicense != null) {
				String driverLicenseNumber = driverLicense.getLicenseNumber();
				if (!EaseUtil.isNullOrBlank(driverLicenseNumber)
						&& !EaseUtil.isNullOrBlank(driverLicense
								.getExistingLicenseClasses())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Does id exist for dl transaction.
	 *
	 * @param ttc the ttc
	 * @return true, if successful
	 */
	public boolean doesIdExistForDlTransaction(String ttc) {
		if (ArrayUtils.contains(DL_TTC, ttc)) {
			IdCard idCard = getApplicant().getIdCard();
			if (idCard != null) {
				String idNumber = idCard.getLicenseNumber();
				if (!EaseUtil.isNullOrBlank(idNumber)
						&& ((!EaseUtil
								.isNullOrBlank(idCard.getExpirationDate())) || (!EaseUtil
								.isNullOrBlank(idCard.getLicenseStatusCode()) && !idCard
								.getLicenseStatusCode().hasCodeEqualTo(
										STATUS_CODE_NONE)))) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Generate key for finger print response waited for requests.
	 *
	 * @return the string
	 */
	private String generateKeyForFingerPrintResponseWaitedForRequests() {
		String key = "";// name+birthdate(mmddyy)+ssn
		String name = getApplicant().getCurrentName().getFullNameWithSuffix();
		key += "Name=" + name;
		Date birthDate = getApplicant().getBirthDate();
		if (birthDate != null) {
			key += "Birthdate="
					+ EcsConverterHelper.convertDateToString(birthDate);
		}
		SocialSecurityDocument socialSecurityDocument = getApplicant()
				.getSocialSecurityDocument();
		if (socialSecurityDocument != null) {
			String ssn = socialSecurityDocument.getSsn();
			if (!EaseUtil.isNullOrBlank(ssn)) {
				key += "Ssn=" + ssn;
			}
		}
		return key;
	}

	/**
	 * Get the acceptRecordIndicator.
	 * 
	 * @return the acceptRecordIndicator
	 */
	public CodeSetElement getAcceptRecordIndicator() {
		return acceptRecordIndicator;
	}

	/**
	 * Gets the anotherPhoto.
	 * 
	 * @return the anotherPhoto
	 */
	public CodeSetElement getAnotherPhoto() {
		return anotherPhoto;
	}

	/**
	 * Gets the applicant name as string.
	 *
	 * @return the applicant name as string
	 */
	public String getApplicantNameAsString() {
		if (!EaseUtil.isNullOrBlank(getApplicant())) {
			PersonName applicantName = getApplicant().getCurrentName();
			if (!EaseUtil.isNullOrBlank(applicantName)) {
				return applicantName.getFullNameWithSuffix();
			}
		}
		return BLANK;
	}

	/**
	 * Gets the attachment code.
	 *
	 * @return the attachmentCode
	 */
	public CodeSetElement getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * Gets the cdlis notification date.
	 *
	 * @return the cdlis notification date
	 */
	public Date getCdlisNotificationDate() {
		return cdlisNotificationDate;
	}

	/**
	 * Gets the cdlis notification type.
	 *
	 * @return the cdlis notification type
	 */
	public CodeSetElement getCdlisNotificationType() {
		return cdlisNotificationType;
	}

	/**
	 * Gets the cdlis pdps response indicator.
	 *
	 * @return the cdlisPdpsResponseIndicator
	 */
	public Boolean getCdlisPdpsResponseIndicator() {
		return cdlisPdpsResponseIndicator;
	}

	/**
	 * Gets the cdlis result hits.
	 * 
	 * @return the cdlisResultHits
	 */
	public List <DrivingRecord> getCdlisResultHits1() {
		return cdlisResultHits1;
	}

	/**
	 * Gets the cdlis result hits2.
	 * 
	 * @return the cdlis result hits2
	 */
	public List <DrivingRecord> getCdlisResultHits2() {
		return cdlisResultHits2;
	}

	/**
	 * Gets the cdlis transfer type.
	 * 
	 * @return the cdlisTransferType
	 */
	public CodeSetElement getCdlisTransferType() {
		return cdlisTransferType;
	}

	/**
	 * Gets the changed applicant.
	 *
	 * @return the changedApplicant
	 */
	public Person getChangedApplicant() {
		return changedApplicant;
	}

	/**
	 * returns changed DriverEducationCode.
	 * 
	 * @return changedDriverEducationCode
	 */
	public CodeSetElement getChangedDriverEducationCode() {
		return changedDriverEducationCode;
	}

	/**
	 * Gets the changed driver education status code.
	 * 
	 * @return the changed driver education status code
	 */
	public CodeSetElement getChangedDriverEducationStatusCode() {
		return changedDriverEducationStatusCode;
	}

	/**
	 * Gets the changed driver training code.
	 * 
	 * @return changedDriverTrainingCode
	 */
	public CodeSetElement getChangedDriverTrainingCode() {
		return changedDriverTrainingCode;
	}

	/**
	 * Gets the changed driver training status code.
	 * 
	 * @return the changed driver training status code
	 */
	public CodeSetElement getChangedDriverTrainingStatusCode() {
		return changedDriverTrainingStatusCode;
	}

	/**
	 * Get the classCDriveTestFailedFeeIndicator.
	 *
	 * @return the classCDriveTestFailedFeeIndicator
	 */
	public Boolean getClasscDriveTestFailedFeeIndicator() {
		return classcDriveTestFailedFeeIndicator;
	}

	/**
	 * Get the classFDriveTestFailedFeeIndicator.
	 *
	 * @return the classFDriveTestFailedFeeIndicator
	 */
	public Boolean getClassfDriveTestFailedFeeIndicator() {
		return classfDriveTestFailedFeeIndicator;
	}

	/**
	 * Gets the comlDlDriveTestFeeUsedIndicator.
	 * 
	 * @return the comlDlDriveTestFeeUsedIndicator
	 */
	public Boolean getComlDlDriveTestFeeUsedIndicator() {
		return comlDlDriveTestFeeUsedIndicator;
	}

	/**
	 * Gets the consolidated CDLIS records.
	 *
	 * @return the consolidated cdlis records
	 */
	public List <DrivingRecord> getConsolidatedCdlisRecords() {
		List <DrivingRecord> cdlisResultHits1 = getCdlisResultHits1();
		List <DrivingRecord> cdlisResultHits2 = getCdlisResultHits2();
		List <DrivingRecord> consolidatedCdlisRecords = new ArrayList <DrivingRecord>();
		if (!EaseUtil.isNullOrBlank(cdlisResultHits1)) {
			for (DrivingRecord drivingRecord : cdlisResultHits1) {
				if (!EaseUtil.isNullOrBlank(drivingRecord)
						&& !EaseUtil.isNullOrBlank(drivingRecord
								.getLicenseNumber())) {
					consolidatedCdlisRecords.add(drivingRecord);
				}
			}
		}
		if (!EaseUtil.isNullOrBlank(cdlisResultHits2)) {
			for (DrivingRecord drivingRecord : cdlisResultHits2) {
				if (!EaseUtil.isNullOrBlank(drivingRecord)
						&& !EaseUtil.isNullOrBlank(drivingRecord
								.getLicenseNumber())) {
					consolidatedCdlisRecords.add(drivingRecord);
				}
			}
		}
		return consolidatedCdlisRecords;
	}

	/**
	 * Gets the consolidated PDPS records.
	 *
	 * @return the consolidated pdps records
	 */
	public List <DrivingRecord> getConsolidatedPdpsRecords() {
		List <DrivingRecord> pdpsResultHits1 = getPdpsResultHits1();
		List <DrivingRecord> pdpsResultHits2 = getPdpsResultHits2();
		List <DrivingRecord> consolidatedPdpsRecords = new ArrayList <DrivingRecord>();
		if (!EaseUtil.isNullOrBlank(pdpsResultHits1)) {
			for (DrivingRecord drivingRecord : pdpsResultHits1) {
				if (!EaseUtil.isNullOrBlank(drivingRecord)
						&& !EaseUtil.isNullOrBlank(drivingRecord
								.getLicenseNumber())) {
					consolidatedPdpsRecords.add(drivingRecord);
				}
			}
		}
		if (!EaseUtil.isNullOrBlank(pdpsResultHits2)) {
			for (DrivingRecord drivingRecord : pdpsResultHits2) {
				if (!EaseUtil.isNullOrBlank(drivingRecord)
						&& !EaseUtil.isNullOrBlank(drivingRecord
								.getLicenseNumber())) {
					consolidatedPdpsRecords.add(drivingRecord);
				}
			}
		}
		return consolidatedPdpsRecords;
	}

	/**
	 * Gets the Dl Print Request Document Code.
	 * 
	 * @return the dlPrintRequestDocumentCode
	 */
	public CodeSetElement getDlPrintRequestDocumentCode() {
		return dlPrintRequestDocumentCode;
	}

	/**
	 * Gets the Driver Education Code.
	 * 
	 * @return the driverEducationCode
	 */
	public CodeSetElement getDriverEducationCode() {
		return driverEducationCode;
	}

	/**
	 * Gets the Driver Education Record Number.
	 * 
	 * @return the driverEducationRecordNumber
	 */
	public String getDriverEducationRecordNumber() {
		return driverEducationRecordNumber;
	}

	/**
	 * Gets the driverEducationStatusCode.
	 * 
	 * @return the driverEducationStatusCode
	 */
	public CodeSetElement getDriverEducationStatusCode() {
		return driverEducationStatusCode;
	}

	/**
	 * Gets the driver education status code read only for cda.
	 *
	 * @return the driverEducationStatusCodeReadOnlyForCda
	 */
	public CodeSetElement getDriverEducationStatusCodeReadOnlyForCda() {
		return driverEducationStatusCodeReadOnlyForCda;
	}

	/**
	 * Gets the Driver Training Code.
	 * 
	 * @return the driverTrainingCode
	 */
	public CodeSetElement getDriverTrainingCode() {
		return driverTrainingCode;
	}

	/**
	 * Gets the Driver Training Record Number.
	 * 
	 * @return the driverTrainingRecordNumber
	 */
	public String getDriverTrainingRecordNumber() {
		return driverTrainingRecordNumber;
	}

	/**
	 * Gets the driverTrainingStatusCode.
	 * 
	 * @return the driverTrainingStatusCode
	 */
	public CodeSetElement getDriverTrainingStatusCode() {
		return driverTrainingStatusCode;
	}

	/**
	 * Gets the driver training status code read only for cda.
	 *
	 * @return the driverTrainingStatusCodeReadOnlyForCda
	 */
	public CodeSetElement getDriverTrainingStatusCodeReadOnlyForCda() {
		return driverTrainingStatusCodeReadOnlyForCda;
	}

	/**
	 * Gets the eli hit counter.
	 *
	 * @return the eliHitCounter
	 */
	public Integer getEliHitCounter() {
		return eliHitCounter;
	}

	/**
	 * Gets the exams last sent to akts.
	 *
	 * @return the outstanding tests sent to AKTS
	 */
	public Set <KnowledgeExam> getExamsLastSentToAkts() {
		if (examsLastSentToAkts == null) {
			setExamsLastSentToAkts(new HashSet <KnowledgeExam>());
		}
		return examsLastSentToAkts;
	}

	/**
	 * Gets the Driver License Existing Incomplete Application Reason Code.
	 * 
	 * @return the CodeSetElement
	 */
	public CodeSetElement getExistingDlIncompleteAppReasonCode() {
		CodeSetElement code = null;
		if (this.getLicense() != null) {
			code = this.getLicense()
					.getExistingIncompleteApplicationReasonCode();
		}
		return code;
	}

	/**
	 * Gets the ID Card Existing Incomplete Application Reason Code.
	 * 
	 * @return the CodeSetElement
	 */
	public CodeSetElement getExistingIdCardIncompleteAppReasonCode() {
		return this.getIdCard().getExistingIncompleteApplicationReasonCode();
	}

	/**
	 * Gets the existing ssn.
	 * 
	 * @return the existingSsn
	 */
	public String getExistingSsn() {
		return existingSsn;
	}

	/**
	 * Gets the existing user verified bdlp code.
	 * 
	 * @return the existingUserVerifiedBdlpCode
	 */
	public CodeSetElement getExistingUserVerifiedBdlpCode() {
		return existingUserVerifiedBdlpCode;
	}

	/**
	 * Gets the Existing User Verified Ssn Code.
	 * 
	 * @return the existingUserVerifiedSsnCode
	 */
	public CodeSetElement getExistingUserVerifiedSsnCode() {
		return existingUserVerifiedSsnCode;
	}

	/**
	 * Gets the temp system generated incomplete app reason code.
	 *
	 * @return the temp system generated incomplete app reason code
	 */
	/*public CodeSetElement getTempSystemGeneratedIncompleteAppReasonCode() {
		return tempSystemGeneratedIncompleteAppReasonCode;
	}*/
	/**
	 * Sets the temp system generated incomplete app reason code.
	 */
	/*public void setTempSystemGeneratedIncompleteAppReasonCode() {
		if (!EaseUtil.isNullOrBlank(getNewIncompleteApplicationReasonCode())) {
			tempSystemGeneratedIncompleteAppReasonCode = getNewIncompleteApplicationReasonCode()
					.copy();
		}
		else {
			tempSystemGeneratedIncompleteAppReasonCode = null;
		}
	}*/
	/**
	 * Gets the finger print image retrieval map.
	 *
	 * @return the finger print image retrieval map
	 */
	public Map <String, Boolean> getFingerPrintImageRetrievalMap() {
		return fingerPrintImageRetrievalMap;
	}

	/**
	 * Get fireFighterFeePaidIndicator.
	 *
	 * @return the fireFighterFeePaidIndicator
	 */
	public Boolean getFireFighterFeePaidIndicator() {
		return fireFighterFeePaidIndicator;
	}

	/**
	 * Gets the fire fighter fee req indicator.
	 * 
	 * @return the fire fighter fee req indicator
	 */
	public Boolean getFireFighterFeeReqIndicator() {
		return fireFighterFeeReqIndicator;
	}

	/**
	 * Gets the gen cna drive test fee due fee indicator.
	 * 
	 * @return the gen cna drive test fee due fee indicator
	 */
	public Boolean getGenCnaDriveTestFeeDueFeeIndicator() {
		return genCnaDriveTestFeeDueFeeIndicator;
	}

	/**
	 * Gets the genCommDlAppFeeIndicator.
	 * 
	 * @return genCommDlAppFeeIndicator
	 */
	public Boolean getGenCommDlAppFeeIndicator() {
		return genCommDlAppFeeIndicator;
	}

	/**
	 * Get the genCommDlAppFeePaidIndicator.
	 *
	 * @return the genCommDlAppFeePaidIndicator
	 */
	public Boolean getGenCommDlAppFeePaidIndicator() {
		return genCommDlAppFeePaidIndicator;
	}

	/**
	 * Gets the genCommDlDrvFeeIndicator.
	 * 
	 * @return genCommDlDrvFeeIndicator
	 */
	public Boolean getGenCommDlDrvFeeIndicator() {
		return genCommDlDrvFeeIndicator;
	}

	/**
	 * Gets the history record10 year check.
	 *
	 * @return the history record10 year check
	 */
	public CodeSetElement getHistoryRecord10YearCheck() {
		return historyRecord10YearCheck;
	}

	/**
	 * Gets the ID Card.
	 * ID card is associated with an Applicant.
	 * 
	 * @return the idCard
	 */
	public IdCard getIdCard() {
		return this.getApplicant().getIdCard();
	}

	/**
	 * Gets the initial control cashier sequence number.
	 *
	 * @return the initial control cashier sequence number
	 */
	// Note: it is assumed that the history elements are ordered chronologically. 
	public String getInitialControlCashierSequenceNumber() {
		String number = null;
		if (!getProcessHistoryList().isEmpty()) {
			IProcessHistory firstHistoryElement = getProcessHistoryList()
					.get(0);
			number = firstHistoryElement.getControlCashierSeqNumber();
		}
		return number;
	}

	/**
	 * Gets the inquiry response code.
	 * 
	 * @return the inquiryResponseCode
	 */
	public CodeSetElement getInquiryResponseCode1() {
		return inquiryResponseCode1;
	}

	/**
	 * Gets the inquiry response code2.
	 * 
	 * @return the inquiry response code2
	 */
	public CodeSetElement getInquiryResponseCode2() {
		return inquiryResponseCode2;
	}

	/**
	 * Gets the checks if is name changed.
	 *
	 * @return the checks if is name changed
	 */
	public Boolean getIsNameChanged() {
		return isNameChanged;
	}

	/**
	 * Gets the Legal Presence Document.
	 * 
	 * @return Legal Presence Document
	 */
	public LegalPresenceDocument getLegalPresenceDocument() {
		return this.getApplicant().getLegalPresenceDocument();
	}

	/**
	 * Gets the Driver License.
	 * Driver License is associated with an Applicant.
	 * 
	 * @return the license
	 */
	public DriverLicense getLicense() {
		if (getApplicant() != null) {
			return getApplicant().getDriverLicense();
		}
		else {
			setApplicant(new Person());
			DriverLicense driverLicense = new DriverLicense();
			getApplicant().setDriverLicense(driverLicense);
			return getApplicant().getDriverLicense();
		}
	}

	/**
	 * returns whether a medical document review is required at HQ.
	 *
	 * @return the medical hq review required indicator
	 */
	public Boolean getMedicalHqReviewRequiredIndicator() {
		return medicalHqReviewRequiredIndicator;
	}

	/**
	 * Gets the Military Duty Code.
	 * 
	 * @return the militaryDutyCode
	 */
	public CodeSetElement getMilitaryDutyCode() {
		return militaryDutyCode;
	}

	/**
	 * Get the motorCycleRetestPaidIndicator.
	 *
	 * @return the motorCycleRetestPaidIndicator
	 */
	public Boolean getMotorCycleRetestPaidIndicator() {
		return motorCycleRetestPaidIndicator;
	}

	/**
	 * Gets the motor cycle retest req indicator.
	 * 
	 * @return the motor cycle retest req indicator
	 */
	public Boolean getMotorCycleRetestReqIndicator() {
		return motorCycleRetestReqIndicator;
	}

	/**
	 * Get the motorCycleRetestUsedIndicator.
	 *
	 * @return the motorCycleRetestUsedIndicator
	 */
	public Boolean getMotorCycleRetestUsedIndicator() {
		return motorCycleRetestUsedIndicator;
	}

	/**
	 * Gets the MC Training Code.
	 * 
	 * @return the motorCycleTrainingCode
	 */
	public CodeSetElement getMotorCycleTrainingCode() {
		return motorCycleTrainingCode;
	}

	/**
	 * Gets New Incomplete Application Reason Code.
	 * 
	 * @return the newIncompleteApplicationReasonCode
	 */
	public CodeSetElement getNewIncompleteApplicationReasonCode() {
		return newIncompleteApplicationReasonCode;
	}

	/**
	 * Gets the User Verified Bdlp Code.
	 * 
	 * @return the newUserVerifiedSsnCode
	 */
	public CodeSetElement getNewUserVerifiedBdlpCode() {
		return newUserVerifiedBdlpCode;
	}

	/**
	 * Gets the New User Verified Ssn Code.
	 * 
	 * @return the newUserVerifiedSsnCode
	 */
	public CodeSetElement getNewUserVerifiedSsnCode() {
		return newUserVerifiedSsnCode;
	}

	/**
	 * Get the nonCommercialDriveRetestFeePaidIndicator.
	 *
	 * @return the nonCommercialDriveRetestFeePaidIndicator
	 */
	public Boolean getNonCommercialDriveRetestFeePaidIndicator() {
		return nonCommercialDriveRetestFeePaidIndicator;
	}

	/**
	 * Gets the non commercial drive retest fee req indicator.
	 * 
	 * @return the non commercial drive retest fee req indicator
	 */
	public Boolean getNonCommercialDriveRetestFeeReqIndicator() {
		return nonCommercialDriveRetestFeeReqIndicator;
	}

	/**
	 * Get the nonCommercialDriveRetestFeeUsedIndicator.
	 *
	 * @return the nonCommercialDriveRetestFeeUsedIndicator
	 */
	public Boolean getNonCommercialDriveRetestFeeUsedIndicator() {
		return nonCommercialDriveRetestFeeUsedIndicator;
	}

	/**
	 * Gets the operational mode.
	 *
	 * @return the operationalMode
	 */
	public CodeSetElement getOperationalMode() {
		return operationalMode;
	}

	/**
	 * Gets the Driver Education and Training Code.
	 * 
	 * @return the driverEdnAndTrainingCode
	 */
	public CodeSetElement getOutOfStateDriverEducationAndTrainingWaiveCode() {
		return outOfStateDriverEducationAndTrainingWaiveCode;
	}

	/**
	 * Gets the outstanding knowledge exams.
	 *
	 * @return the outstandingKnowledgeExams
	 */
	public Set <KnowledgeExam> getOutstandingKnowledgeExams() {
		if (outstandingKnowledgeExams == null) {
			setOutstandingKnowledgeExams(new HashSet <KnowledgeExam>());
		}
		return outstandingKnowledgeExams;
	}

	/**
	 * Gets the paid invoice item.
	 *
	 * @return the paidInvoiceItem
	 */
	public InvoiceItem getPaidInvoiceItem() {
		return paidInvoiceItem;
	}

	/**
	 * Gets the Passport.
	 * 
	 * @return Passport
	 */
	public Passport getPassport() {
		return getApplicant().getPassport();
	}

	/**
	 * Gets the PDPS Eligibility indicator.
	 * The following logic is documented in the file: CDU_Further_Processing.doc
	 * along with the requirements for "CDU" tcode.
	 *
	 * @param currentUserContext the current user context
	 * @return PDPS Eligibility indicator
	 */
	public String getPdpsEligibilityIndicator(IUserContext currentUserContext) {
		String pdpsEligibilityIndicator = null;
		List <DrivingRecord> pdpsRecords = getConsolidatedPdpsRecords();
		Boolean isClearedByIssuance = isClearedByIssuance();
		//If Designated as �S�
		//If VFSMSG1C_CdlMessage1 is (ELIGIBLE, LICENSED, VALID, EXPIRED or not present) and
		//VFSMSG2C_CdlMessage2 is present and _not_ (ELIGIBLE, LICENSED, VALID, EXPIRED) and
		//VCSCCLSC_CurrentClassCommericalYes not = �*� - (Not Commercial Class)
		//Set VTSPDPEI_PdpsEligibilityIndicator = �N�
		if (!isApplicationClassCommercial()) {
			for (DrivingRecord pdpsRecord : pdpsRecords) {
				if (!isNullOrBlank(pdpsRecord)
						&& !isNullOrBlank(pdpsRecord.getDesignateAction())
						&& pdpsRecord.getDesignateAction().equalsIgnoreCase(
								SAME)) {
					String commercialStatusDesc = pdpsRecord
							.getCommercialLicenseStatusCode() != null ? pdpsRecord
							.getCommercialLicenseStatusCode().getDescription()
							: null;
					String nonCommercialStatusDesc = pdpsRecord
							.getNonCommercialLicenseStatusCode() != null ? pdpsRecord
							.getNonCommercialLicenseStatusCode()
							.getDescription() : null;
					if (isNullOrBlank(commercialStatusDesc)
							|| contains(commercialStatusDesc,
									PDPS_ELIGIBILITY_STATUS_DESC)) {
						if (!isNullOrBlank(nonCommercialStatusDesc)
								&& !contains(nonCommercialStatusDesc,
										PDPS_ELIGIBILITY_STATUS_DESC)) {
							pdpsEligibilityIndicator = PDPS_NOT_ELIGIBLE;
							break;
						}
					}
				}
			}
		}
		//If Designated as �Q� and
		//VCSCCLSC_CurrentClassCommericalYes not = �*� - (Not Commercial Class)
		//Set VTSPDPEI_PdpsEligibilityIndicator = �N�
		if (isAnyPdpsRecordDesignatedWithParticularDesignationCode(QUESTIONABLE)
				&& !isApplicationClassCommercial()) {
			pdpsEligibilityIndicator = PDPS_NOT_ELIGIBLE;
		}
		//1.
		//No hits on the PDPS database (VTSNRCDE_NdrResponseCode, is  'G' or 'N')  and 
		//record processed with no CNA condition and
		//VTSPDPEI_PdpsEligibilityIndicator not = �N� � set to `E� 
		if (isNullOrBlank(pdpsRecords)
				&& !isCdlisPdpsCnaConditionsPresent()
				&& !PDPS_NOT_ELIGIBLE
						.equalsIgnoreCase(pdpsEligibilityIndicator)) {
			pdpsEligibilityIndicator = PDPS_ELIGIBLE;
		}
		//2.
		//Designated as a �Q� or 
		//(�S� and Password Entered) � Set to �N�
		else if (isAnyPdpsRecordDesignatedWithParticularDesignationCode(QUESTIONABLE)
				|| (isAnyPdpsRecordDesignatedWithParticularDesignationCode(SAME) && isPasswordRequiredForPdpsRecords())) {
			pdpsEligibilityIndicator = PDPS_NOT_ELIGIBLE;
		}
		//3.
		//The user either didn�t designate it with an S or Q, or 
		//he did and a password was not entered and 
		//record processed with no CNA condition � set to `E�
		else if (!isAnyPdpsRecordDesignatedWithParticularDesignationCode(new String[] {
				SAME, QUESTIONABLE })
				&& !isCdlisPdpsCnaConditionsPresent()
				&& !PDPS_NOT_ELIGIBLE
						.equalsIgnoreCase(pdpsEligibilityIndicator)) {
			pdpsEligibilityIndicator = PDPS_ELIGIBLE;
		}
		else if (isAnyPdpsRecordDesignatedWithParticularDesignationCode(new String[] {
				SAME, QUESTIONABLE })
				&& !isPasswordRequiredForPdpsRecords()
				&& !isCdlisPdpsCnaConditionsPresent()
				&& !PDPS_NOT_ELIGIBLE
						.equalsIgnoreCase(pdpsEligibilityIndicator)) {
			pdpsEligibilityIndicator = PDPS_ELIGIBLE;
		}
		//4.
		//An issuance office and 
		//VFSCBISS_ClearedByIssuanceIndicatorYn = Y � set to `E�
		if (currentUserContext.isIssuanceOfficeOnly()
				&& TRUE.equals(isClearedByIssuance)) {
			pdpsEligibilityIndicator = PDPS_ELIGIBLE;
		}
		return pdpsEligibilityIndicator;
	}

	/**
	 * Gets the pdps inquiry indicator.
	 *
	 * @return the pdpsInquiryIndicator
	 */
	public String getPdpsInquiryIndicator() {
		return pdpsInquiryIndicator;
	}

	/**
	 * Gets the pdps result hits.
	 * 
	 * @return the pdpsResultHits
	 */
	public List <DrivingRecord> getPdpsResultHits1() {
		return pdpsResultHits1;
	}

	/**
	 * Gets the pdps result hits2.
	 * 
	 * @return the pdps result hits2
	 */
	public List <DrivingRecord> getPdpsResultHits2() {
		return pdpsResultHits2;
	}

	/**
	 * Gets the pending applied license classes.
	 *
	 * @return the pendingAppliedLicenseClasses
	 */
	public List <CodeSetElement> getPendingAppliedLicenseClasses() {
		return pendingAppliedLicenseClasses;
	}

	/**
	 * Gets the photoRetrieved.
	 * 
	 * @return the photoRetrieved
	 */
	public CodeSetElement getPhotoRetrieved() {
		return photoRetrieved;
	}

	/**
	 * Gets the photo taken type.
	 *
	 * @return the photoTakenType
	 */
	public CodeSetElement getPhotoTakenType() {
		return photoTakenType;
	}

	/**
	 * Gets the physical or mental problem code.
	 * 
	 * @return the physical or mental problem code
	 */
	public CodeSetElement getPhysicalOrMentalProblemCode() {
		return physicalOrMentalProblemCode;
	}

	/**
	 * Gets the previous user verified bdlp code.
	 *
	 * @return the previousUserVerifiedBdlpCode
	 */
	public CodeSetElement getPreviousUserVerifiedBdlpCode() {
		return previousUserVerifiedBdlpCode;
	}

	/**
	 * Gets the previous user verified SSN code.
	 * 
	 * @return the previous user verified SSN code
	 */
	public CodeSetElement getPreviousUserVerifiedSsnCode() {
		return previousUserVerifiedSsnCode;
	}

	/**
	 * Gets the prints the request document code from dl id transaction.
	 *
	 * @return the printRequestDocumentCodeFromDlIdTransaction
	 */
	public String getPrintRequestDocumentCodeFromDlIdTransaction() {
		return printRequestDocumentCodeFromDlIdTransaction;
	}

	/**
	 * Gets the prints the request types.
	 *
	 * @return the printRequestTypes
	 */
	public Set <PrintRequestTypes> getPrintRequestTypes() {
		if (printRequestTypes == null) {
			setPrintRequestTypes(new HashSet <PrintRequestTypes>());
		}
		return printRequestTypes;
	}

	/**
	 * Gets the renewal by mail no fee indicator.
	 * 
	 * @return the renewal by mail no fee indicator
	 */
	public Boolean getRenewalByMailNoFeeIndicator() {
		return renewalByMailNoFeeIndicator;
	}

	/**
	 * Gets the Social Security Document.
	 * 
	 * @return Social Security Document
	 */
	public SocialSecurityDocument getSocialSecurityDocument() {
		return getApplicant().getSocialSecurityDocument();
	}

	/**
	 * Gets the social security number.
	 *
	 * @return the social security number
	 */
	public String getSocialSecurityNumber() {
		SocialSecurityDocument socialSecurityDocument = getSocialSecurityDocument();
		if (!EaseUtil.isNullOrBlank(socialSecurityDocument)) {
			return socialSecurityDocument.getSsn();
		}
		return null;
	}

	/**
	 * Gets the total app fee amount paid.
	 *
	 * @return the totalAppFeeAmountPaid
	 */
	public int getTotalAppFeeAmountPaid() {
		return totalAppFeeAmountPaid;
	}

	/**
	 * Get total CDLIS and PDPS matched records.
	 *
	 * @return a list of matched records
	 */
	public List <DrivingRecord> getTotalCdlisAndPdpsMatchedRecords() {
		List <DrivingRecord> matchedRecords = new ArrayList <DrivingRecord>();
		if (EaseUtil.isNotNull(cdlisResultHits1)) {
			matchedRecords.addAll(cdlisResultHits1);
		}
		if (EaseUtil.isNotNull(cdlisResultHits2)) {
			matchedRecords.addAll(cdlisResultHits2);
		}
		if (EaseUtil.isNotNull(pdpsResultHits1)) {
			matchedRecords.addAll(pdpsResultHits1);
		}
		if (EaseUtil.isNotNull(pdpsResultHits2)) {
			matchedRecords.addAll(pdpsResultHits2);
		}
		return matchedRecords;
	}

	/**
	 * Gets the total pdps records count1.
	 *
	 * @return the totalPdpsRecordsCount1
	 */
	public int getTotalPdpsRecordsCount1() {
		return totalPdpsRecordsCount1;
	}

	/**
	 * Gets the total pdps records count2.
	 *
	 * @return the totalPdpsRecordsCount2
	 */
	public int getTotalPdpsRecordsCount2() {
		return totalPdpsRecordsCount2;
	}

	/**
	 * Gets the user entered bdlp code.
	 *
	 * @return the userEnteredBdlpCode
	 */
	public CodeSetElement getUserEnteredBdlpCode() {
		return userEnteredBdlpCode;
	}

	/**
	 * Gets the Voter Registration Requested.
	 * 
	 * @return the voterRegistationRequested
	 */
	public CodeSetElement getVoterRegistationRequested() {
		return voterRegistationRequested;
	}

	/**
	 * Checks for category fire fighter.
	 *
	 * @return true, if successful
	 */
	public boolean hasCategoryFireFighter() {
		if (!EaseUtil.isNullOrBlank(getApplicant())
				&& !EaseUtil.isNullOrBlank(getApplicant().getDriverLicense())) {
			List <CodeSetElement> categories = getApplicant()
					.getDriverLicense().getNewCategories();
			if (!EaseUtil.isNullOrBlank(categories)) {
				for (CodeSetElement category : categories) {
					if (!EaseUtil.isNullOrBlank(category)) {
						return ArrayUtils.contains(category.getCode(),
								FIRE_FIGHTER_CLASS_A, FIRE_FIGHTER_CLASS_B);
					}
				}
			}
		}
		return false;
	}

	/**
	 * Checks for cna conditions exists.
	 *
	 * @return true, if successful
	 */
	public boolean hasCnaConditionsExists() {
		return !EaseUtil.isNullOrBlank(getCnaConditions());
	}

	/**
	 * Checks if is cdlis pdps cna conditions present.
	 *
	 * @return true, if is cdlis pdps cna conditions present
	 */
	public boolean isCdlisPdpsCnaConditionsPresent() {
		if (!EaseUtil.isNullOrBlank(getCnaConditions())
				&& (getCnaConditions().contains(
						CnaConditionType.CNA_GET_CDLIS_PDPS_RESPONSE) || getCnaConditions()
						.contains(CnaConditionType.CNA_SEND_CDLIS_PDPS_INQUIRY))) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.document.impl.Application#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((acceptRecordIndicator == null) ? 0 : acceptRecordIndicator
						.hashCode());
		result = prime * result
				+ ((anotherPhoto == null) ? 0 : anotherPhoto.hashCode());
		result = prime * result
				+ ((attachmentCode == null) ? 0 : attachmentCode.hashCode());
		result = prime * result
				+ (backendUpdateRequiredWithoutCda ? 1231 : 1237);
		result = prime
				* result
				+ ((cdlisNotificationDate == null) ? 0 : cdlisNotificationDate
						.hashCode());
		result = prime
				* result
				+ ((cdlisNotificationType == null) ? 0 : cdlisNotificationType
						.hashCode());
		result = prime
				* result
				+ ((cdlisPdpsResponseIndicator == null) ? 0
						: cdlisPdpsResponseIndicator.hashCode());
		result = prime * result + (cdlisPdpsResultHits1Processed ? 1231 : 1237);
		result = prime * result + (cdlisPdpsResultHits2Processed ? 1231 : 1237);
		result = prime
				* result
				+ ((cdlisResultHits1 == null) ? 0 : cdlisResultHits1.hashCode());
		result = prime
				* result
				+ ((cdlisResultHits2 == null) ? 0 : cdlisResultHits2.hashCode());
		result = prime
				* result
				+ ((cdlisTransferType == null) ? 0 : cdlisTransferType
						.hashCode());
		result = prime
				* result
				+ ((changedApplicant == null) ? 0 : changedApplicant.hashCode());
		result = prime
				* result
				+ ((changedDriverEducationCode == null) ? 0
						: changedDriverEducationCode.hashCode());
		result = prime
				* result
				+ ((changedDriverEducationStatusCode == null) ? 0
						: changedDriverEducationStatusCode.hashCode());
		result = prime
				* result
				+ ((changedDriverTrainingCode == null) ? 0
						: changedDriverTrainingCode.hashCode());
		result = prime
				* result
				+ ((changedDriverTrainingStatusCode == null) ? 0
						: changedDriverTrainingStatusCode.hashCode());
		result = prime
				* result
				+ ((checkLegalPresence == null) ? 0 : checkLegalPresence
						.hashCode());
		result = prime
				* result
				+ ((classcDriveTestFailedFeeIndicator == null) ? 0
						: classcDriveTestFailedFeeIndicator.hashCode());
		result = prime
				* result
				+ ((classfDriveTestFailedFeeIndicator == null) ? 0
						: classfDriveTestFailedFeeIndicator.hashCode());
		result = prime
				* result
				+ ((comlDlDriveTestFeeUsedIndicator == null) ? 0
						: comlDlDriveTestFeeUsedIndicator.hashCode());
		result = prime
				* result
				+ ((dlPrintRequestDocumentCode == null) ? 0
						: dlPrintRequestDocumentCode.hashCode());
		result = prime
				* result
				+ ((driverEducationCode == null) ? 0 : driverEducationCode
						.hashCode());
		result = prime
				* result
				+ ((driverEducationRecordNumber == null) ? 0
						: driverEducationRecordNumber.hashCode());
		result = prime
				* result
				+ ((driverEducationStatusCode == null) ? 0
						: driverEducationStatusCode.hashCode());
		result = prime
				* result
				+ ((driverEducationStatusCodeReadOnlyForCda == null) ? 0
						: driverEducationStatusCodeReadOnlyForCda.hashCode());
		result = prime
				* result
				+ ((driverTrainingCode == null) ? 0 : driverTrainingCode
						.hashCode());
		result = prime
				* result
				+ ((driverTrainingRecordNumber == null) ? 0
						: driverTrainingRecordNumber.hashCode());
		result = prime
				* result
				+ ((driverTrainingStatusCode == null) ? 0
						: driverTrainingStatusCode.hashCode());
		result = prime
				* result
				+ ((driverTrainingStatusCodeReadOnlyForCda == null) ? 0
						: driverTrainingStatusCodeReadOnlyForCda.hashCode());
		result = prime * result
				+ ((eliHitCounter == null) ? 0 : eliHitCounter.hashCode());
		result = prime
				* result
				+ ((examsLastSentToAkts == null) ? 0 : examsLastSentToAkts
						.hashCode());
		result = prime * result
				+ ((existingSsn == null) ? 0 : existingSsn.hashCode());
		result = prime
				* result
				+ ((existingUserVerifiedBdlpCode == null) ? 0
						: existingUserVerifiedBdlpCode.hashCode());
		result = prime
				* result
				+ ((existingUserVerifiedSsnCode == null) ? 0
						: existingUserVerifiedSsnCode.hashCode());
		result = prime
				* result
				+ ((feeRequiredReasonCode == null) ? 0 : feeRequiredReasonCode
						.hashCode());
		result = prime
				* result
				+ ((fingerPrintImageRetrievalMap == null) ? 0
						: fingerPrintImageRetrievalMap.hashCode());
		result = prime
				* result
				+ ((fireFighterFeePaidIndicator == null) ? 0
						: fireFighterFeePaidIndicator.hashCode());
		result = prime
				* result
				+ ((fireFighterFeeReqIndicator == null) ? 0
						: fireFighterFeeReqIndicator.hashCode());
		result = prime
				* result
				+ ((genCnaDriveTestFeeDueFeeIndicator == null) ? 0
						: genCnaDriveTestFeeDueFeeIndicator.hashCode());
		result = prime
				* result
				+ ((genCommDlAppFeeIndicator == null) ? 0
						: genCommDlAppFeeIndicator.hashCode());
		result = prime
				* result
				+ ((genCommDlAppFeePaidIndicator == null) ? 0
						: genCommDlAppFeePaidIndicator.hashCode());
		result = prime
				* result
				+ ((genCommDlDrvFeeIndicator == null) ? 0
						: genCommDlDrvFeeIndicator.hashCode());
		result = prime
				* result
				+ ((historyRecord10YearCheck == null) ? 0
						: historyRecord10YearCheck.hashCode());
		result = prime
				* result
				+ ((inquiryResponseCode1 == null) ? 0 : inquiryResponseCode1
						.hashCode());
		result = prime
				* result
				+ ((inquiryResponseCode2 == null) ? 0 : inquiryResponseCode2
						.hashCode());
		result = prime * result
				+ ((isAbsentParent == null) ? 0 : isAbsentParent.hashCode());
		result = prime
				* result
				+ ((isCdlisNdrResponseAvailable == null) ? 0
						: isCdlisNdrResponseAvailable.hashCode());
		result = prime
				* result
				+ ((isCdlisPdpsCleared == null) ? 0 : isCdlisPdpsCleared
						.hashCode());
		result = prime
				* result
				+ ((isCommercialRemoveRestrictionIndicator == null) ? 0
						: isCommercialRemoveRestrictionIndicator.hashCode());
		result = prime
				* result
				+ ((isDlApplicationCompletedByHq == null) ? 0
						: isDlApplicationCompletedByHq.hashCode());
		result = prime
				* result
				+ ((isDlIdNumberForCnaCondition == null) ? 0
						: isDlIdNumberForCnaCondition.hashCode());
		result = prime
				* result
				+ ((isEligibleForRestrictionCoe == null) ? 0
						: isEligibleForRestrictionCoe.hashCode());
		result = prime
				* result
				+ ((isLegalPresenceCheckBypassIndicator == null) ? 0
						: isLegalPresenceCheckBypassIndicator.hashCode());
		result = prime
				* result
				+ ((isLimitedTermIndicator == null) ? 0
						: isLimitedTermIndicator.hashCode());
		result = prime * result
				+ (isLpvSecondaryVerificationRequired ? 1231 : 1237);
		result = prime * result
				+ ((isNameChanged == null) ? 0 : isNameChanged.hashCode());
		result = prime
				* result
				+ ((isNewLicenseNumberRequired == null) ? 0
						: isNewLicenseNumberRequired.hashCode());
		result = prime * result
				+ ((isOrganDonor == null) ? 0 : isOrganDonor.hashCode());
		result = prime
				* result
				+ ((isOriginalApplicationIndicator == null) ? 0
						: isOriginalApplicationIndicator.hashCode());
		result = prime
				* result
				+ ((isOriginalForCnaCondition == null) ? 0
						: isOriginalForCnaCondition.hashCode());
		result = prime
				* result
				+ ((isQuestionablePdpsIndicator == null) ? 0
						: isQuestionablePdpsIndicator.hashCode());
		result = prime * result + (isTemporaryLicensePrinted ? 1231 : 1237);
		result = prime
				* result
				+ ((legalPresenceEmployeeId == null) ? 0
						: legalPresenceEmployeeId.hashCode());
		result = prime
				* result
				+ ((medicalHqReviewRequiredIndicator == null) ? 0
						: medicalHqReviewRequiredIndicator.hashCode());
		result = prime
				* result
				+ ((militaryDutyCode == null) ? 0 : militaryDutyCode.hashCode());
		result = prime
				* result
				+ ((motorCycleRetestPaidIndicator == null) ? 0
						: motorCycleRetestPaidIndicator.hashCode());
		result = prime
				* result
				+ ((motorCycleRetestReqIndicator == null) ? 0
						: motorCycleRetestReqIndicator.hashCode());
		result = prime
				* result
				+ ((motorCycleRetestUsedIndicator == null) ? 0
						: motorCycleRetestUsedIndicator.hashCode());
		result = prime
				* result
				+ ((motorCycleTrainingCode == null) ? 0
						: motorCycleTrainingCode.hashCode());
		result = prime
				* result
				+ ((newIncompleteApplicationReasonCode == null) ? 0
						: newIncompleteApplicationReasonCode.hashCode());
		result = prime
				* result
				+ ((newUserVerifiedBdlpCode == null) ? 0
						: newUserVerifiedBdlpCode.hashCode());
		result = prime
				* result
				+ ((newUserVerifiedSsnCode == null) ? 0
						: newUserVerifiedSsnCode.hashCode());
		result = prime
				* result
				+ ((nonCommercialDriveRetestFeePaidIndicator == null) ? 0
						: nonCommercialDriveRetestFeePaidIndicator.hashCode());
		result = prime
				* result
				+ ((nonCommercialDriveRetestFeeReqIndicator == null) ? 0
						: nonCommercialDriveRetestFeeReqIndicator.hashCode());
		result = prime
				* result
				+ ((nonCommercialDriveRetestFeeUsedIndicator == null) ? 0
						: nonCommercialDriveRetestFeeUsedIndicator.hashCode());
		result = prime * result
				+ ((operationalMode == null) ? 0 : operationalMode.hashCode());
		result = prime
				* result
				+ ((outOfStateDriverEducationAndTrainingWaiveCode == null) ? 0
						: outOfStateDriverEducationAndTrainingWaiveCode
								.hashCode());
		result = prime
				* result
				+ ((outstandingKnowledgeExams == null) ? 0
						: outstandingKnowledgeExams.hashCode());
		result = prime * result
				+ ((paidInvoiceItem == null) ? 0 : paidInvoiceItem.hashCode());
		result = prime
				* result
				+ ((pdpsInquiryIndicator == null) ? 0 : pdpsInquiryIndicator
						.hashCode());
		result = prime * result
				+ ((pdpsResultHits1 == null) ? 0 : pdpsResultHits1.hashCode());
		result = prime * result
				+ ((pdpsResultHits2 == null) ? 0 : pdpsResultHits2.hashCode());
		result = prime
				* result
				+ ((pendingAppliedLicenseClasses == null) ? 0
						: pendingAppliedLicenseClasses.hashCode());
		result = prime * result
				+ ((photoRetrieved == null) ? 0 : photoRetrieved.hashCode());
		result = prime * result
				+ ((photoTakenType == null) ? 0 : photoTakenType.hashCode());
		result = prime
				* result
				+ ((physicalOrMentalProblemCode == null) ? 0
						: physicalOrMentalProblemCode.hashCode());
		result = prime
				* result
				+ ((previousUserVerifiedBdlpCode == null) ? 0
						: previousUserVerifiedBdlpCode.hashCode());
		result = prime
				* result
				+ ((previousUserVerifiedSsnCode == null) ? 0
						: previousUserVerifiedSsnCode.hashCode());
		result = prime
				* result
				+ ((printRequestDocumentCodeFromDlIdTransaction == null) ? 0
						: printRequestDocumentCodeFromDlIdTransaction
								.hashCode());
		result = prime
				* result
				+ ((printRequestTypes == null) ? 0 : printRequestTypes
						.hashCode());
		result = prime
				* result
				+ ((renewalByMailNoFeeIndicator == null) ? 0
						: renewalByMailNoFeeIndicator.hashCode());
		result = prime * result + totalAppFeeAmountPaid;
		result = prime * result + totalPdpsRecordsCount1;
		result = prime * result + totalPdpsRecordsCount2;
		result = prime
				* result
				+ ((userEnteredBdlpCode == null) ? 0 : userEnteredBdlpCode
						.hashCode());
		result = prime
				* result
				+ ((voterRegistationRequested == null) ? 0
						: voterRegistationRequested.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.document.impl.Application#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DlApplication other = (DlApplication) obj;
		if (acceptRecordIndicator == null) {
			if (other.acceptRecordIndicator != null)
				return false;
		}
		else if (!acceptRecordIndicator.equals(other.acceptRecordIndicator))
			return false;
		if (anotherPhoto == null) {
			if (other.anotherPhoto != null)
				return false;
		}
		else if (!anotherPhoto.equals(other.anotherPhoto))
			return false;
		if (attachmentCode == null) {
			if (other.attachmentCode != null)
				return false;
		}
		else if (!attachmentCode.equals(other.attachmentCode))
			return false;
		if (backendUpdateRequiredWithoutCda != other.backendUpdateRequiredWithoutCda)
			return false;
		if (cdlisNotificationDate == null) {
			if (other.cdlisNotificationDate != null)
				return false;
		}
		else if (!cdlisNotificationDate.equals(other.cdlisNotificationDate))
			return false;
		if (cdlisNotificationType == null) {
			if (other.cdlisNotificationType != null)
				return false;
		}
		else if (!cdlisNotificationType.equals(other.cdlisNotificationType))
			return false;
		if (cdlisPdpsResponseIndicator == null) {
			if (other.cdlisPdpsResponseIndicator != null)
				return false;
		}
		else if (!cdlisPdpsResponseIndicator
				.equals(other.cdlisPdpsResponseIndicator))
			return false;
		if (cdlisPdpsResultHits1Processed != other.cdlisPdpsResultHits1Processed)
			return false;
		if (cdlisPdpsResultHits2Processed != other.cdlisPdpsResultHits2Processed)
			return false;
		if (cdlisResultHits1 == null) {
			if (other.cdlisResultHits1 != null)
				return false;
		}
		else if (!cdlisResultHits1.equals(other.cdlisResultHits1))
			return false;
		if (cdlisResultHits2 == null) {
			if (other.cdlisResultHits2 != null)
				return false;
		}
		else if (!cdlisResultHits2.equals(other.cdlisResultHits2))
			return false;
		if (cdlisTransferType == null) {
			if (other.cdlisTransferType != null)
				return false;
		}
		else if (!cdlisTransferType.equals(other.cdlisTransferType))
			return false;
		if (changedApplicant == null) {
			if (other.changedApplicant != null)
				return false;
		}
		else if (!changedApplicant.equals(other.changedApplicant))
			return false;
		if (changedDriverEducationCode == null) {
			if (other.changedDriverEducationCode != null)
				return false;
		}
		else if (!changedDriverEducationCode
				.equals(other.changedDriverEducationCode))
			return false;
		if (changedDriverEducationStatusCode == null) {
			if (other.changedDriverEducationStatusCode != null)
				return false;
		}
		else if (!changedDriverEducationStatusCode
				.equals(other.changedDriverEducationStatusCode))
			return false;
		if (changedDriverTrainingCode == null) {
			if (other.changedDriverTrainingCode != null)
				return false;
		}
		else if (!changedDriverTrainingCode
				.equals(other.changedDriverTrainingCode))
			return false;
		if (changedDriverTrainingStatusCode == null) {
			if (other.changedDriverTrainingStatusCode != null)
				return false;
		}
		else if (!changedDriverTrainingStatusCode
				.equals(other.changedDriverTrainingStatusCode))
			return false;
		if (checkLegalPresence == null) {
			if (other.checkLegalPresence != null)
				return false;
		}
		else if (!checkLegalPresence.equals(other.checkLegalPresence))
			return false;
		if (classcDriveTestFailedFeeIndicator == null) {
			if (other.classcDriveTestFailedFeeIndicator != null)
				return false;
		}
		else if (!classcDriveTestFailedFeeIndicator
				.equals(other.classcDriveTestFailedFeeIndicator))
			return false;
		if (classfDriveTestFailedFeeIndicator == null) {
			if (other.classfDriveTestFailedFeeIndicator != null)
				return false;
		}
		else if (!classfDriveTestFailedFeeIndicator
				.equals(other.classfDriveTestFailedFeeIndicator))
			return false;
		if (comlDlDriveTestFeeUsedIndicator == null) {
			if (other.comlDlDriveTestFeeUsedIndicator != null)
				return false;
		}
		else if (!comlDlDriveTestFeeUsedIndicator
				.equals(other.comlDlDriveTestFeeUsedIndicator))
			return false;
		if (dlPrintRequestDocumentCode == null) {
			if (other.dlPrintRequestDocumentCode != null)
				return false;
		}
		else if (!dlPrintRequestDocumentCode
				.equals(other.dlPrintRequestDocumentCode))
			return false;
		if (driverEducationCode == null) {
			if (other.driverEducationCode != null)
				return false;
		}
		else if (!driverEducationCode.equals(other.driverEducationCode))
			return false;
		if (driverEducationRecordNumber == null) {
			if (other.driverEducationRecordNumber != null)
				return false;
		}
		else if (!driverEducationRecordNumber
				.equals(other.driverEducationRecordNumber))
			return false;
		if (driverEducationStatusCode == null) {
			if (other.driverEducationStatusCode != null)
				return false;
		}
		else if (!driverEducationStatusCode
				.equals(other.driverEducationStatusCode))
			return false;
		if (driverEducationStatusCodeReadOnlyForCda == null) {
			if (other.driverEducationStatusCodeReadOnlyForCda != null)
				return false;
		}
		else if (!driverEducationStatusCodeReadOnlyForCda
				.equals(other.driverEducationStatusCodeReadOnlyForCda))
			return false;
		if (driverTrainingCode == null) {
			if (other.driverTrainingCode != null)
				return false;
		}
		else if (!driverTrainingCode.equals(other.driverTrainingCode))
			return false;
		if (driverTrainingRecordNumber == null) {
			if (other.driverTrainingRecordNumber != null)
				return false;
		}
		else if (!driverTrainingRecordNumber
				.equals(other.driverTrainingRecordNumber))
			return false;
		if (driverTrainingStatusCode == null) {
			if (other.driverTrainingStatusCode != null)
				return false;
		}
		else if (!driverTrainingStatusCode
				.equals(other.driverTrainingStatusCode))
			return false;
		if (driverTrainingStatusCodeReadOnlyForCda == null) {
			if (other.driverTrainingStatusCodeReadOnlyForCda != null)
				return false;
		}
		else if (!driverTrainingStatusCodeReadOnlyForCda
				.equals(other.driverTrainingStatusCodeReadOnlyForCda))
			return false;
		if (eliHitCounter == null) {
			if (other.eliHitCounter != null)
				return false;
		}
		else if (!eliHitCounter.equals(other.eliHitCounter))
			return false;
		if (examsLastSentToAkts == null) {
			if (other.examsLastSentToAkts != null)
				return false;
		}
		else if (!examsLastSentToAkts.equals(other.examsLastSentToAkts))
			return false;
		if (existingSsn == null) {
			if (other.existingSsn != null)
				return false;
		}
		else if (!existingSsn.equals(other.existingSsn))
			return false;
		if (existingUserVerifiedBdlpCode == null) {
			if (other.existingUserVerifiedBdlpCode != null)
				return false;
		}
		else if (!existingUserVerifiedBdlpCode
				.equals(other.existingUserVerifiedBdlpCode))
			return false;
		if (existingUserVerifiedSsnCode == null) {
			if (other.existingUserVerifiedSsnCode != null)
				return false;
		}
		else if (!existingUserVerifiedSsnCode
				.equals(other.existingUserVerifiedSsnCode))
			return false;
		if (feeRequiredReasonCode == null) {
			if (other.feeRequiredReasonCode != null)
				return false;
		}
		else if (!feeRequiredReasonCode.equals(other.feeRequiredReasonCode))
			return false;
		if (fingerPrintImageRetrievalMap == null) {
			if (other.fingerPrintImageRetrievalMap != null)
				return false;
		}
		else if (!fingerPrintImageRetrievalMap
				.equals(other.fingerPrintImageRetrievalMap))
			return false;
		if (fireFighterFeePaidIndicator == null) {
			if (other.fireFighterFeePaidIndicator != null)
				return false;
		}
		else if (!fireFighterFeePaidIndicator
				.equals(other.fireFighterFeePaidIndicator))
			return false;
		if (fireFighterFeeReqIndicator == null) {
			if (other.fireFighterFeeReqIndicator != null)
				return false;
		}
		else if (!fireFighterFeeReqIndicator
				.equals(other.fireFighterFeeReqIndicator))
			return false;
		if (genCnaDriveTestFeeDueFeeIndicator == null) {
			if (other.genCnaDriveTestFeeDueFeeIndicator != null)
				return false;
		}
		else if (!genCnaDriveTestFeeDueFeeIndicator
				.equals(other.genCnaDriveTestFeeDueFeeIndicator))
			return false;
		if (genCommDlAppFeeIndicator == null) {
			if (other.genCommDlAppFeeIndicator != null)
				return false;
		}
		else if (!genCommDlAppFeeIndicator
				.equals(other.genCommDlAppFeeIndicator))
			return false;
		if (genCommDlAppFeePaidIndicator == null) {
			if (other.genCommDlAppFeePaidIndicator != null)
				return false;
		}
		else if (!genCommDlAppFeePaidIndicator
				.equals(other.genCommDlAppFeePaidIndicator))
			return false;
		if (genCommDlDrvFeeIndicator == null) {
			if (other.genCommDlDrvFeeIndicator != null)
				return false;
		}
		else if (!genCommDlDrvFeeIndicator
				.equals(other.genCommDlDrvFeeIndicator))
			return false;
		if (historyRecord10YearCheck == null) {
			if (other.historyRecord10YearCheck != null)
				return false;
		}
		else if (!historyRecord10YearCheck
				.equals(other.historyRecord10YearCheck))
			return false;
		if (inquiryResponseCode1 == null) {
			if (other.inquiryResponseCode1 != null)
				return false;
		}
		else if (!inquiryResponseCode1.equals(other.inquiryResponseCode1))
			return false;
		if (inquiryResponseCode2 == null) {
			if (other.inquiryResponseCode2 != null)
				return false;
		}
		else if (!inquiryResponseCode2.equals(other.inquiryResponseCode2))
			return false;
		if (isAbsentParent == null) {
			if (other.isAbsentParent != null)
				return false;
		}
		else if (!isAbsentParent.equals(other.isAbsentParent))
			return false;
		if (isCdlisNdrResponseAvailable == null) {
			if (other.isCdlisNdrResponseAvailable != null)
				return false;
		}
		else if (!isCdlisNdrResponseAvailable
				.equals(other.isCdlisNdrResponseAvailable))
			return false;
		if (isCdlisPdpsCleared == null) {
			if (other.isCdlisPdpsCleared != null)
				return false;
		}
		else if (!isCdlisPdpsCleared.equals(other.isCdlisPdpsCleared))
			return false;
		if (isCommercialRemoveRestrictionIndicator == null) {
			if (other.isCommercialRemoveRestrictionIndicator != null)
				return false;
		}
		else if (!isCommercialRemoveRestrictionIndicator
				.equals(other.isCommercialRemoveRestrictionIndicator))
			return false;
		if (isDlApplicationCompletedByHq == null) {
			if (other.isDlApplicationCompletedByHq != null)
				return false;
		}
		else if (!isDlApplicationCompletedByHq
				.equals(other.isDlApplicationCompletedByHq))
			return false;
		if (isDlIdNumberForCnaCondition == null) {
			if (other.isDlIdNumberForCnaCondition != null)
				return false;
		}
		else if (!isDlIdNumberForCnaCondition
				.equals(other.isDlIdNumberForCnaCondition))
			return false;
		if (isEligibleForRestrictionCoe == null) {
			if (other.isEligibleForRestrictionCoe != null)
				return false;
		}
		else if (!isEligibleForRestrictionCoe
				.equals(other.isEligibleForRestrictionCoe))
			return false;
		if (isLegalPresenceCheckBypassIndicator == null) {
			if (other.isLegalPresenceCheckBypassIndicator != null)
				return false;
		}
		else if (!isLegalPresenceCheckBypassIndicator
				.equals(other.isLegalPresenceCheckBypassIndicator))
			return false;
		if (isLimitedTermIndicator == null) {
			if (other.isLimitedTermIndicator != null)
				return false;
		}
		else if (!isLimitedTermIndicator.equals(other.isLimitedTermIndicator))
			return false;
		if (isLpvSecondaryVerificationRequired != other.isLpvSecondaryVerificationRequired)
			return false;
		if (isNameChanged == null) {
			if (other.isNameChanged != null)
				return false;
		}
		else if (!isNameChanged.equals(other.isNameChanged))
			return false;
		if (isNewLicenseNumberRequired == null) {
			if (other.isNewLicenseNumberRequired != null)
				return false;
		}
		else if (!isNewLicenseNumberRequired
				.equals(other.isNewLicenseNumberRequired))
			return false;
		if (isOrganDonor == null) {
			if (other.isOrganDonor != null)
				return false;
		}
		else if (!isOrganDonor.equals(other.isOrganDonor))
			return false;
		if (isOriginalApplicationIndicator == null) {
			if (other.isOriginalApplicationIndicator != null)
				return false;
		}
		else if (!isOriginalApplicationIndicator
				.equals(other.isOriginalApplicationIndicator))
			return false;
		if (isOriginalForCnaCondition == null) {
			if (other.isOriginalForCnaCondition != null)
				return false;
		}
		else if (!isOriginalForCnaCondition
				.equals(other.isOriginalForCnaCondition))
			return false;
		if (isQuestionablePdpsIndicator == null) {
			if (other.isQuestionablePdpsIndicator != null)
				return false;
		}
		else if (!isQuestionablePdpsIndicator
				.equals(other.isQuestionablePdpsIndicator))
			return false;
		if (isTemporaryLicensePrinted != other.isTemporaryLicensePrinted)
			return false;
		if (legalPresenceEmployeeId == null) {
			if (other.legalPresenceEmployeeId != null)
				return false;
		}
		else if (!legalPresenceEmployeeId.equals(other.legalPresenceEmployeeId))
			return false;
		if (medicalHqReviewRequiredIndicator == null) {
			if (other.medicalHqReviewRequiredIndicator != null)
				return false;
		}
		else if (!medicalHqReviewRequiredIndicator
				.equals(other.medicalHqReviewRequiredIndicator))
			return false;
		if (militaryDutyCode == null) {
			if (other.militaryDutyCode != null)
				return false;
		}
		else if (!militaryDutyCode.equals(other.militaryDutyCode))
			return false;
		if (motorCycleRetestPaidIndicator == null) {
			if (other.motorCycleRetestPaidIndicator != null)
				return false;
		}
		else if (!motorCycleRetestPaidIndicator
				.equals(other.motorCycleRetestPaidIndicator))
			return false;
		if (motorCycleRetestReqIndicator == null) {
			if (other.motorCycleRetestReqIndicator != null)
				return false;
		}
		else if (!motorCycleRetestReqIndicator
				.equals(other.motorCycleRetestReqIndicator))
			return false;
		if (motorCycleRetestUsedIndicator == null) {
			if (other.motorCycleRetestUsedIndicator != null)
				return false;
		}
		else if (!motorCycleRetestUsedIndicator
				.equals(other.motorCycleRetestUsedIndicator))
			return false;
		if (motorCycleTrainingCode == null) {
			if (other.motorCycleTrainingCode != null)
				return false;
		}
		else if (!motorCycleTrainingCode.equals(other.motorCycleTrainingCode))
			return false;
		if (newIncompleteApplicationReasonCode == null) {
			if (other.newIncompleteApplicationReasonCode != null)
				return false;
		}
		else if (!newIncompleteApplicationReasonCode
				.equals(other.newIncompleteApplicationReasonCode))
			return false;
		if (newUserVerifiedBdlpCode == null) {
			if (other.newUserVerifiedBdlpCode != null)
				return false;
		}
		else if (!newUserVerifiedBdlpCode.equals(other.newUserVerifiedBdlpCode))
			return false;
		if (newUserVerifiedSsnCode == null) {
			if (other.newUserVerifiedSsnCode != null)
				return false;
		}
		else if (!newUserVerifiedSsnCode.equals(other.newUserVerifiedSsnCode))
			return false;
		if (nonCommercialDriveRetestFeePaidIndicator == null) {
			if (other.nonCommercialDriveRetestFeePaidIndicator != null)
				return false;
		}
		else if (!nonCommercialDriveRetestFeePaidIndicator
				.equals(other.nonCommercialDriveRetestFeePaidIndicator))
			return false;
		if (nonCommercialDriveRetestFeeReqIndicator == null) {
			if (other.nonCommercialDriveRetestFeeReqIndicator != null)
				return false;
		}
		else if (!nonCommercialDriveRetestFeeReqIndicator
				.equals(other.nonCommercialDriveRetestFeeReqIndicator))
			return false;
		if (nonCommercialDriveRetestFeeUsedIndicator == null) {
			if (other.nonCommercialDriveRetestFeeUsedIndicator != null)
				return false;
		}
		else if (!nonCommercialDriveRetestFeeUsedIndicator
				.equals(other.nonCommercialDriveRetestFeeUsedIndicator))
			return false;
		if (operationalMode == null) {
			if (other.operationalMode != null)
				return false;
		}
		else if (!operationalMode.equals(other.operationalMode))
			return false;
		if (outOfStateDriverEducationAndTrainingWaiveCode == null) {
			if (other.outOfStateDriverEducationAndTrainingWaiveCode != null)
				return false;
		}
		else if (!outOfStateDriverEducationAndTrainingWaiveCode
				.equals(other.outOfStateDriverEducationAndTrainingWaiveCode))
			return false;
		if (outstandingKnowledgeExams == null) {
			if (other.outstandingKnowledgeExams != null)
				return false;
		}
		else if (!outstandingKnowledgeExams
				.equals(other.outstandingKnowledgeExams))
			return false;
		if (paidInvoiceItem == null) {
			if (other.paidInvoiceItem != null)
				return false;
		}
		else if (!paidInvoiceItem.equals(other.paidInvoiceItem))
			return false;
		if (pdpsInquiryIndicator == null) {
			if (other.pdpsInquiryIndicator != null)
				return false;
		}
		else if (!pdpsInquiryIndicator.equals(other.pdpsInquiryIndicator))
			return false;
		if (pdpsResultHits1 == null) {
			if (other.pdpsResultHits1 != null)
				return false;
		}
		else if (!pdpsResultHits1.equals(other.pdpsResultHits1))
			return false;
		if (pdpsResultHits2 == null) {
			if (other.pdpsResultHits2 != null)
				return false;
		}
		else if (!pdpsResultHits2.equals(other.pdpsResultHits2))
			return false;
		if (pendingAppliedLicenseClasses == null) {
			if (other.pendingAppliedLicenseClasses != null)
				return false;
		}
		else if (!pendingAppliedLicenseClasses
				.equals(other.pendingAppliedLicenseClasses))
			return false;
		if (photoRetrieved == null) {
			if (other.photoRetrieved != null)
				return false;
		}
		else if (!photoRetrieved.equals(other.photoRetrieved))
			return false;
		if (photoTakenType == null) {
			if (other.photoTakenType != null)
				return false;
		}
		else if (!photoTakenType.equals(other.photoTakenType))
			return false;
		if (physicalOrMentalProblemCode == null) {
			if (other.physicalOrMentalProblemCode != null)
				return false;
		}
		else if (!physicalOrMentalProblemCode
				.equals(other.physicalOrMentalProblemCode))
			return false;
		if (previousUserVerifiedBdlpCode == null) {
			if (other.previousUserVerifiedBdlpCode != null)
				return false;
		}
		else if (!previousUserVerifiedBdlpCode
				.equals(other.previousUserVerifiedBdlpCode))
			return false;
		if (previousUserVerifiedSsnCode == null) {
			if (other.previousUserVerifiedSsnCode != null)
				return false;
		}
		else if (!previousUserVerifiedSsnCode
				.equals(other.previousUserVerifiedSsnCode))
			return false;
		if (printRequestDocumentCodeFromDlIdTransaction == null) {
			if (other.printRequestDocumentCodeFromDlIdTransaction != null)
				return false;
		}
		else if (!printRequestDocumentCodeFromDlIdTransaction
				.equals(other.printRequestDocumentCodeFromDlIdTransaction))
			return false;
		if (printRequestTypes == null) {
			if (other.printRequestTypes != null)
				return false;
		}
		else if (!printRequestTypes.equals(other.printRequestTypes))
			return false;
		if (renewalByMailNoFeeIndicator == null) {
			if (other.renewalByMailNoFeeIndicator != null)
				return false;
		}
		else if (!renewalByMailNoFeeIndicator
				.equals(other.renewalByMailNoFeeIndicator))
			return false;
		if (totalAppFeeAmountPaid != other.totalAppFeeAmountPaid)
			return false;
		if (totalPdpsRecordsCount1 != other.totalPdpsRecordsCount1)
			return false;
		if (totalPdpsRecordsCount2 != other.totalPdpsRecordsCount2)
			return false;
		if (userEnteredBdlpCode == null) {
			if (other.userEnteredBdlpCode != null)
				return false;
		}
		else if (!userEnteredBdlpCode.equals(other.userEnteredBdlpCode))
			return false;
		if (voterRegistationRequested == null) {
			if (other.voterRegistationRequested != null)
				return false;
		}
		else if (!voterRegistationRequested
				.equals(other.voterRegistationRequested))
			return false;
		return true;
	}

	/**
	 * Checks if is absent parent.
	 * 
	 * @return the boolean
	 */
	public Boolean isAbsentParent() {
		return isAbsentParent;
	}

	/**
	 * Checks if is any cdlis record designated.
	 *
	 * @return true, if is any cdlis record designated
	 */
	public boolean isAnyCdlisRecordDesignated() {
		List <DrivingRecord> cdlisRecords = getConsolidatedCdlisRecords();
		if (cdlisRecords != null) {
			for (DrivingRecord cdlisRecord : cdlisRecords) {
				String designation = cdlisRecord.getDesignateAction();
				if (!EaseUtil.isNullOrBlank(designation)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if is any cdlis record designated with particular designation code.
	 *
	 * @param designationCodes the designation codes
	 * @return true, if is any cdlis record designated with particular designation code
	 */
	public boolean isAnyCdlisRecordDesignatedWithParticularDesignationCode(
			String... designationCodes) {
		if (designationCodes != null && designationCodes.length > 0) {
			List <String> designationCodesList = Arrays
					.asList(designationCodes);
			List <DrivingRecord> cdlisRecords = getConsolidatedCdlisRecords();
			if (cdlisRecords != null) {
				for (DrivingRecord cdlisRecord : cdlisRecords) {
					String designation = cdlisRecord.getDesignateAction();
					if (!EaseUtil.isNullOrBlank(designation)
							&& designationCodesList.contains(designation)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Checks if a given list of license class has any commercial license class.
	 * 
	 * @param licenseClasses the license classes to check
	 * 
	 * @return true, if any class is a commercial license class
	 */
	public boolean isAnyCommercialLicenseClassExist(
			List <CodeSetElement> licenseClasses) {
		if (!EaseUtil.isNullOrBlank(licenseClasses)) {
			for (CodeSetElement licenseClass : licenseClasses) {
				if (!EaseUtil.isNullOrBlank(licenseClass)
						&& isComercialLicenseClass(licenseClass.getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if is any non commercial license class exist.
	 *
	 * @param licenseClasses the license classes
	 * @return true, if is any non commercial license class exist
	 */
	public boolean isAnyNonCommercialLicenseClassExist(
			List <CodeSetElement> licenseClasses) {
		if (!EaseUtil.isNullOrBlank(licenseClasses)) {
			for (CodeSetElement licenseClass : licenseClasses) {
				if (!EaseUtil.isNullOrBlank(licenseClass)
						&& isNonComercialLicenseClass(licenseClass.getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if is any pdps record designated.
	 *
	 * @return true, if is any pdps record designated
	 */
	public boolean isAnyPdpsRecordDesignated() {
		List <DrivingRecord> pdpsRecords = getConsolidatedPdpsRecords();
		if (pdpsRecords != null) {
			for (DrivingRecord pdpsRecord : pdpsRecords) {
				String designation = pdpsRecord.getDesignateAction();
				if (!EaseUtil.isNullOrBlank(designation)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if is any pdps record designated with particular designation code.
	 *
	 * @param designationCodes the designation codes
	 * @return true, if is any pdps record designated with particular designation code
	 */
	public boolean isAnyPdpsRecordDesignatedWithParticularDesignationCode(
			String... designationCodes) {
		if (designationCodes != null && designationCodes.length > 0) {
			List <String> designationCodesList = Arrays
					.asList(designationCodes);
			List <DrivingRecord> pdpsRecords = getConsolidatedPdpsRecords();
			if (pdpsRecords != null) {
				for (DrivingRecord pdpsRecord : pdpsRecords) {
					String designation = pdpsRecord.getDesignateAction();
					if (!EaseUtil.isNullOrBlank(designation)
							&& designationCodesList.contains(designation)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Gets the pdps record designated as.
	 *
	 * @return the pdps record designated as
	 */
	/*	private DrivingRecord getPdpsRecordDesignatedAs(String designate) {
			List <DrivingRecord> pdpsRecords = getConsolidatedPdpsRecords();
			if (!isNullOrBlank(pdpsRecords)) {
				for (DrivingRecord pdpsRecord : pdpsRecords) {
					if (!isNullOrBlank(pdpsRecord)
							&& !isNullOrBlank(designate)
							&& designate.equalsIgnoreCase(pdpsRecord
									.getDesignateAction())) {
						return pdpsRecord;
					}
				}
			}
			return null;
		}*/
	/**
	 * Checks if is application class commercial.
	 *
	 * @return true, if is application class commercial
	 */
	public boolean isApplicationClassCommercial() {
		if (!EaseUtil.isNullOrBlank(getApplicant())
				&& !EaseUtil.isNullOrBlank(getApplicant().getDriverLicense())) {
			return isAnyCommercialLicenseClassExist(getApplicant()
					.getDriverLicense().getAppliedLicenseClasses());
		}
		else {
			return false;
		}
	}

	/**
	 * Checks if is backend update required without cda.
	 *
	 * @return true, if is backend update required without cda
	 */
	public boolean isBackendUpdateRequiredWithoutCda() {
		return backendUpdateRequiredWithoutCda;
	}

	/**
	 * Checks if is birthdate changed.
	 *
	 * @return true, if is bd changed
	 */
	public boolean isBirthdateChanged() {
		Person currentApplicant = getApplicant();
		Person changedApplicant = getChangedApplicant();
		if (!EaseUtil.isNullOrBlank(currentApplicant)
				&& !EaseUtil.isNullOrBlank(changedApplicant)) {
			if (!EaseUtil.isNullOrBlank(currentApplicant.getBirthDate())
					&& !EaseUtil.isNullOrBlank(changedApplicant.getBirthDate())) {
				if (!currentApplicant.getBirthDate().equals(
						changedApplicant.getBirthDate())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if is cdlis ndr response available.
	 * 
	 * @return the boolean
	 */
	public Boolean isCdlisNdrResponseAvailable() {
		return isCdlisNdrResponseAvailable;
	}

	/**
	 * Checks if is cdlis pdps result hits processed.
	 * 
	 * @return true, if is cdlis pdps result hits processed
	 */
	public boolean isCdlisPdpsResultHits1Processed() {
		return cdlisPdpsResultHits1Processed;
	}

	/**
	 * Checks if is cdlis pdps result hits2 processed.
	 * 
	 * @return true, if is cdlis pdps result hits2 processed
	 */
	public boolean isCdlisPdpsResultHits2Processed() {
		return cdlisPdpsResultHits2Processed;
	}

	/**
	 * Gets the Legal Presence Check Indicator.
	 * 
	 * @return the checkLegalPresence
	 */
	public Boolean isCheckLegalPresence() {
		return checkLegalPresence;
	}

	/**
	 * Gets the Cleared By Issuance.
	 * 
	 * @return the isCdlisPdpsCleared
	 */
	public Boolean isClearedByIssuance() {
		return isCdlisPdpsCleared;
	}

	/**
	 * Checks if a given license class belongs to a commercial license class.
	 * 
	 * @param licenseClass the license class to check
	 * 
	 * @return true, if it is a commercial license class
	 */
	public boolean isComercialLicenseClass(String licenseClass) {
		return (COMM_LICENSE_CLASSES.indexOf(licenseClass) >= 0) ? true : false;
	}

	/**
	 * Gets the Commercial Remove Restriction Indicator.
	 * 
	 * @return the isCommercialRemoveRestrictionIndicator
	 */
	public Boolean isCommercialRemoveRestrictionIndicator() {
		return isCommercialRemoveRestrictionIndicator;
	}

	/**
	 * Gets the DL Application Completed by HQ Indicator.
	 * 
	 * @return the isDlApplicationCompletedByHQ
	 */
	public Boolean isDlApplicationCompletedByHq() {
		return isDlApplicationCompletedByHq;
	}

	/**
	 * Checks if is dl id number for cna condition.
	 * 
	 * @return the boolean
	 */
	public Boolean isDlIdNumberForCnaCondition() {
		return isDlIdNumberForCnaCondition;
	}

	/**
	 * Checks if is dl or id number changed.
	 *
	 * @return true, if is dl id number changed
	 */
	public boolean isDlOrIdNumberChanged() {
		Person currentApplicant = getApplicant();
		if (!EaseUtil.isNullOrBlank(currentApplicant)) {
			if (currentApplicant.hasDriverLicenceNumer()
					&& currentApplicant.hasPreviousDriverLicenceNumer()) {
				DriverLicense driverLicense = currentApplicant
						.getDriverLicense();
				String previousLicenseNumber = currentApplicant
						.getPreviousLicenseNumber();
				if (!driverLicense.hasTheSameLicenseAs(previousLicenseNumber)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method checks if DL exists.
	 *
	 * @return true if DL exists
	 */
	public boolean isDriverLicenseExist() {
		Person person = getApplicant();
		DriverLicense driverLicense = null;
		if (person != null && person.getDriverLicense() != null) {
			driverLicense = person.getDriverLicense();
		}
		if (driverLicense != null
				&& !EaseUtil.isNullOrBlank(driverLicense.getLicenseNumber())) {
			if (driverLicense.getExpirationDate() != null) {
				return true;
			}
			// If DL application was pended.
			else if (!EaseUtil
					.isNullOrBlank(getApplicationPendingIndicatorCode())
					&& getApplicationPendingIndicatorCode()
							.hasCodeEqualToAnyOf(DRIVER_LICENSE_PENDED,
									DL_ID_PENDED)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks if is eligible for restriction COE.
	 * 
	 * @return the isEligibleForRestrictionCoe
	 */
	public Boolean isEligibleForRestrictionCoe() {
		return isEligibleForRestrictionCoe;
	}

	/**
	 * Checks if is waiting period necessary for finger print response.
	 *
	 * @return true, if is waiting period necessary for finger print response
	 */
	public boolean isFingerPrintRetrievalProcessAlreadyDone() {
		String key = generateKeyForFingerPrintResponseWaitedForRequests();
		if (!EaseUtil.isNullOrBlank(key)) {
			Boolean value = getFingerPrintImageRetrievalMap().get(key);
			if (value != null && value) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Checks if is gender changed.
	 *
	 * @return true, if is gender changed
	 */
	public boolean isGenderChanged() {
		Person currentApplicant = getApplicant();
		Person changedApplicant = getChangedApplicant();
		if (!EaseUtil.isNullOrBlank(currentApplicant)
				&& !EaseUtil.isNullOrBlank(changedApplicant)) {
			if (!EaseUtil.isNullOrBlank(currentApplicant.getGenderCode())
					&& !EaseUtil
							.isNullOrBlank(changedApplicant.getGenderCode())) {
				if (!currentApplicant.getGenderCode().hasCodeEqualTo(
						changedApplicant.getGenderCode().getCode())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method checks if ID card exists.
	 *
	 * @return true if ID card exist
	 */
	public boolean isIdCardExist() {
		Person person = getApplicant();
		IdCard idCard = null;
		if (person != null && person.getIdCard() != null) {
			idCard = person.getIdCard();
		}
		if (idCard != null && idCard.getExpirationDate() != null
				&& !EaseUtil.isNullOrBlank(idCard.getLicenseNumber())) {
			return true;
		}
		// If ID application was pended.
		else if (!EaseUtil.isNullOrBlank(getApplicationPendingIndicatorCode())
				&& getApplicationPendingIndicatorCode().hasCodeEqualToAnyOf(
						ID_CARD_PENDED, DL_ID_PENDED)) {
			return true;
		}
		return false;
	}

	/**
	 * Gets the Legal Presence Check Bypass Indicator.
	 * 
	 * @return the isLegalPresenceCheckBypassIndicator
	 */
	public Boolean isLegalPresenceCheckBypassIndicator() {
		return isLegalPresenceCheckBypassIndicator;
	}

	/**
	 * Checks whether LPV doc needs to be reviewed by HQ.
	 *
	 * @return true, if is legal presence hq review required
	 */
	public boolean isLegalPresenceHqReviewRequired() {
		return (getNewUserVerifiedBdlpCode() != null && getNewUserVerifiedBdlpCode()
				.getCode().equals(NOT_VERIFIED_ELECTRONICALLY));
	}

	/**
	 * Gets the limited term indicator.
	 * 
	 * @return the limited term indicator
	 */
	public Boolean isLimitedTermIndicator() {
		return isLimitedTermIndicator;
	}

	/**
	 * Checks whether the LPV doc needs to be scanned.
	 *
	 * @return true, if is lpv doc scan required
	 */
	public boolean isLpvDocScanRequired() {
		if (getUserEnteredBdlpCode() == null) {
			return false;
		}
		else {
			return LPV_DOCTYPE_CDS_REQ_DOC_SCAN
					.contains(getUserEnteredBdlpCode().getCode())
					&& !(getExistingUserVerifiedBdlpCode() != null
							&& NOT_VERIFIED_ELECTRONICALLY
									.equals(getUserEnteredBdlpCode().getCode()) && NOT_VERIFIED_ELECTRONICALLY
								.equals(getExistingUserVerifiedBdlpCode()
										.getCode()));
		}
	}

	/**
	 * Checks whether a medical doc needs to be scanned. Per business rules,
	 * if the medical exp date has changed, or if the review required flag
	 * is set, then a document needs to be scanned
	 *
	 * @return true, if is medical doc scan required
	 */
	public boolean isMedicalDocScanRequired() {
		if (getApplicant() == null) {
			return false;
		}
		else {
			return getApplicant().isMedicalExpirationDateNew()
					|| isNotNullAndIsTrue(getMedicalHqReviewRequiredIndicator());
		}
	}

	/**
	 * Checks if is name changed.
	 *
	 * @return true, if is name changed
	 */
	public boolean isNameChanged() {
		Person currentApplicant = getApplicant();
		Person changedApplicant = getChangedApplicant();
		if (!EaseUtil.isNullOrBlank(currentApplicant)
				&& !EaseUtil.isNullOrBlank(changedApplicant)) {
			if ((!EaseUtil.isNullOrBlank(currentApplicant.getCurrentName()) && !EaseUtil
					.isNullOrBlank(changedApplicant.getCurrentName()))
					&& !currentApplicant.getCurrentName().equals(
							changedApplicant.getCurrentName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the New Number Required Indicator.
	 * 
	 * @return the isNewLicenseNumberRequired
	 */
	public Boolean isNewLicenseNumberRequired() {
		return isNewLicenseNumberRequired;
	}

	/**
	 * Checks if a given license class belongs to a non commercial license class.
	 * 
	 * @param licenseClass the license class to check
	 * 
	 * @return true, if it is a non commercial license class
	 */
	public boolean isNonComercialLicenseClass(String licenseClass) {
		return (NON_COMM_LIC_CLASSES.indexOf(licenseClass) >= 0) ? true : false;
	}

	/**
	 * Gets the Organ Donor Indicator.
	 * 
	 * @return the isOrganDonor
	 */
	public Boolean isOrganDonor() {
		return isOrganDonor;
	}

	/**
	 * Gets the Original Application Indicator.
	 * 
	 * @return the isOriginalApplicationIndicator
	 */
	public Boolean isOriginalApplicationIndicator() {
		return isOriginalApplicationIndicator;
	}

	/**
	 * Checks if is original for cna condition.
	 * 
	 * @return the boolean
	 */
	public Boolean isOriginalForCnaCondition() {
		return isOriginalForCnaCondition;
	}

	/**
	 * Checks if password is required.
	 *
	 * @return true, if successful
	 */
	public boolean isPasswordRequiredForPdpsRecords() {
		List <DrivingRecord> pdpsRecords = getConsolidatedPdpsRecords();
		Object[] validStatusCodes = { OUTPUT_COMM_STATUS_VAL,
				OUTPUT_COMM_STATUS_EXP, OUTPUT_COMM_STATUS_ELG,
				OUTPUT_COMM_STATUS_LIC };
		if (!EaseUtil.isNullOrBlank(pdpsRecords)) {
			for (DrivingRecord pdpsRecord : pdpsRecords) {
				if (!EaseUtil.isNullOrBlank(pdpsRecord)
						&& SAME.equalsIgnoreCase(pdpsRecord
								.getDesignateAction())) {
					//If either commercial or non-commercial status code is not valid
					if ((!EaseUtil.isNullOrBlank(pdpsRecord
							.getCommercialLicenseStatusCode()) && !ArrayUtils
							.contains(
									pdpsRecord.getCommercialLicenseStatusCode()
											.getCode(), validStatusCodes))
							|| (!EaseUtil.isNullOrBlank(pdpsRecord
									.getNonCommercialLicenseStatusCode()) && !ArrayUtils
									.contains(
											pdpsRecord
													.getNonCommercialLicenseStatusCode()
													.getCode(),
											validStatusCodes))) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Gets the Questionable Pdps Indicator.
	 * 
	 * @return the isQuestionablePdps
	 */
	public Boolean isQuestionablePdpsIndicator() {
		return isQuestionablePdpsIndicator;
	}

	/**
	 * Checks if is this transaction original original.
	 *
	 * @param ttc the previous ttc
	 * @return true, if is this transaction original original
	 */
	public boolean isThisTransactionOriginalOriginal(String ttc) {
		if (EaseUtil.isNotNullAndIsTrue(isOriginalApplicationIndicator())) {// renewal transaction cannot be originaloriginal
			if (ArrayUtils.contains(ttc, ITtcConstants.DLP, ITtcConstants.IDP)) {// Even though, DLP and IDP can be original transactions, but they can never be originaloroginal because record related to that license number already exists in backend.
				return false;
			}
			// if it's a original transaction and if DL already exists for ID transaction and vice-versa, then it cannot be originaloriginal transaction
			if (!doesIdExistForDlTransaction(ttc)
					&& !doesDlExistForIdTransaction(ttc)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Reset cdlis pdps user keyed data.
	 */
	public void resetCdlisPdpsUserKeyedData() {
		resetCdlisUserKeyedData();
		setClearedByIssuance(null);
	}

	/**
	* Reset cdlis user keyed data.
	*/
	protected void resetCdlisUserKeyedData() {
		//Reset only for multiple cdlis hits
		if (!EaseUtil.isNullOrBlank(cdlisResultHits1)
				&& cdlisResultHits1.size() >= 2) {
			resetDrivingRecords(cdlisResultHits1);
		}
		if (!EaseUtil.isNullOrBlank(cdlisResultHits2)
				&& cdlisResultHits2.size() >= 2) {
			resetDrivingRecords(cdlisResultHits2);
		}
	}

	/**
	* Reset driving records.
	*
	* @param drivingRecords the driving records
	*/
	protected void resetDrivingRecords(List <DrivingRecord> drivingRecords) {
		//1. Designate Action
		//2. CDS designate field
		//3. Record tried
		//4. IsApprovalPasswordRequiredAndEntered
		for (DrivingRecord cdlisRecord : drivingRecords) {
			if (!EaseUtil.isNullOrBlank(cdlisRecord)) {
				cdlisRecord.setDesignateAction(BLANK);
				cdlisRecord.setCdlDesignateField(BLANK);
				cdlisRecord.setCdlisRecordTried(false);
				cdlisRecord.setApprovalPasswordRequiredAndEntered(false);
			}
		}
	}

	/**
	 * Reset existing incomplete application reason.
	 *
	 * @param licenseType the license type
	 */
	public void resetExistingIncompleteApplicationReason(LicenseType licenseType) {
		if (licenseType.equals(LicenseType.DRIVER_LICENSE)) {
			this.getLicense().resetExistingIncompleteApplicationReasonCode();
		}
		else if (licenseType.equals(LicenseType.ID_CARD)) {
			this.getIdCard().resetExistingIncompleteApplicationReasonCode();
		}
	}

	/**
	 * Reset new incomplete application reason code.
	 */
	public void resetNewIncompleteApplicationReasonCode() {
		setNewIncompleteApplicationReasonCode(new CodeSetElement());
	}

	/**
	 * Sets the absent parent.
	 * 
	 * @param isAbsentParent the new absent parent
	 */
	public void setAbsentParent(boolean isAbsentParent) {
		this.isAbsentParent = isAbsentParent;
	}

	/**
	 * Set acceptRecordIndicator.
	 * 
	 * @param indicator the new accept record indicator
	 */
	public void setAcceptRecordIndicator(CodeSetElement indicator) {
		acceptRecordIndicator = indicator;
	}

	/**
	 * Sets the anotherPhoto.
	 * 
	 * @param anotherPhoto the anotherPhoto to set
	 */
	public void setAnotherPhoto(CodeSetElement anotherPhoto) {
		this.anotherPhoto = anotherPhoto;
	}

	/**
	 * Sets the backend update required without cda.
	 *
	 * @param backendUpdateRequiredWithoutCda the new backend update required without cda
	 */
	public void setBackendUpdateRequiredWithoutCda(
			boolean backendUpdateRequiredWithoutCda) {
		this.backendUpdateRequiredWithoutCda = backendUpdateRequiredWithoutCda;
	}

	/**
	 * Sets the cdlis ndr response available.
	 * 
	 * @param isCdlisNdrResponseAvailable the new cdlis ndr response available
	 */
	public void setCdlisNdrResponseAvailable(Boolean isCdlisNdrResponseAvailable) {
		this.isCdlisNdrResponseAvailable = isCdlisNdrResponseAvailable;
	}

	/**
	 * Sets the cdlis notification date.
	 *
	 * @param cdlisNotificationDate the new cdlis notification date
	 */
	public void setCdlisNotificationDate(Date cdlisNotificationDate) {
		this.cdlisNotificationDate = cdlisNotificationDate;
	}

	/**
	 * Sets the cdlis notification type.
	 *
	 * @param cdlisNotificationType the new cdlis notification type
	 */
	public void setCdlisNotificationType(CodeSetElement cdlisNotificationType) {
		this.cdlisNotificationType = cdlisNotificationType;
	}

	/**
	 * Sets the cdlis pdps response indicator.
	 *
	 * @param cdlisPdpsResponseIndicator the cdlisPdpsResponseIndicator to set
	 */
	public void setCdlisPdpsResponseIndicator(Boolean cdlisPdpsResponseIndicator) {
		this.cdlisPdpsResponseIndicator = cdlisPdpsResponseIndicator;
	}

	/**
	 * Sets the cdlis pdps result hits processed.
	 * 
	 * @param cdlisPdpsResultHitsProcessed the new cdlis pdps result hits processed
	 */
	public void setCdlisPdpsResultHits1Processed(
			boolean cdlisPdpsResultHitsProcessed) {
		this.cdlisPdpsResultHits1Processed = cdlisPdpsResultHitsProcessed;
	}

	/**
	 * Sets the cdlis pdps result hits2 processed.
	 * 
	 * @param cdlisPdpsResultHits2Processed the new cdlis pdps result hits2 processed
	 */
	public void setCdlisPdpsResultHits2Processed(
			boolean cdlisPdpsResultHits2Processed) {
		this.cdlisPdpsResultHits2Processed = cdlisPdpsResultHits2Processed;
	}

	/**
	 * Sets the cdlis result hits.
	 * 
	 * @param cdlisResultHits the cdlisResultHits to set
	 */
	public void setCdlisResultHits1(List <DrivingRecord> cdlisResultHits) {
		this.cdlisResultHits1 = cdlisResultHits;
	}

	/**
	 * Sets the cdlis result hits2.
	 * 
	 * @param cdlisResultHits2 the new cdlis result hits2
	 */
	public void setCdlisResultHits2(List <DrivingRecord> cdlisResultHits2) {
		this.cdlisResultHits2 = cdlisResultHits2;
	}

	/**
	 * Sets the cdlis transfer type.
	 * 
	 * @param cdlisTransferType the cdlisTransferType to set
	 */
	public void setCdlisTransferType(CodeSetElement cdlisTransferType) {
		this.cdlisTransferType = cdlisTransferType;
	}

	/**
	 * Sets the changed applicant.
	 *
	 * @param changedApplicant the changedApplicant to set
	 */
	public void setChangedApplicant(Person changedApplicant) {
		this.changedApplicant = changedApplicant;
	}

	/**
	 * Sets the changed DriverEducationCode.
	 * 
	 * @param changedDriverEducationCode the new changed driver education code
	 */
	public void setChangedDriverEducationCode(
			CodeSetElement changedDriverEducationCode) {
		this.changedDriverEducationCode = changedDriverEducationCode;
	}

	/**
	 * Sets the changed driver education status code.
	 * 
	 * @param changedDriverEducationStatusCode the new changed driver education status code
	 */
	public void setChangedDriverEducationStatusCode(
			CodeSetElement changedDriverEducationStatusCode) {
		this.changedDriverEducationStatusCode = changedDriverEducationStatusCode;
	}

	/**
	 * Sets the changed driver training code.
	 * 
	 * @param changedDriverTrainingCode the new changed driver training code
	 */
	public void setChangedDriverTrainingCode(
			CodeSetElement changedDriverTrainingCode) {
		this.changedDriverTrainingCode = changedDriverTrainingCode;
	}

	/**
	 * Sets the changed driver training status code.
	 * 
	 * @param changedDriverTrainingStatusCode the new changed driver training status code
	 */
	public void setChangedDriverTrainingStatusCode(
			CodeSetElement changedDriverTrainingStatusCode) {
		this.changedDriverTrainingStatusCode = changedDriverTrainingStatusCode;
	}

	/**
	 * Sets the Legal Presence Check Indicator.
	 * 
	 * @param checkLegalPresence the checkLegalPresence to set
	 */
	public void setCheckLegalPresence(Boolean checkLegalPresence) {
		this.checkLegalPresence = checkLegalPresence;
	}

	/**
	 * Set classcDriveTestFailedFeeIndicator.
	 *
	 * @param classcDriveTestFailedFeeIndicator the new classc drive test failed fee indicator
	 */
	public void setClasscDriveTestFailedFeeIndicator(
			Boolean classcDriveTestFailedFeeIndicator) {
		this.classcDriveTestFailedFeeIndicator = classcDriveTestFailedFeeIndicator;
	}

	/**
	 * Set classFDriveTestFailedFeeIndicator.
	 *
	 * @param classfDriveTestFailedFeeIndicator the new classf drive test failed fee indicator
	 */
	public void setClassfDriveTestFailedFeeIndicator(
			Boolean classfDriveTestFailedFeeIndicator) {
		this.classfDriveTestFailedFeeIndicator = classfDriveTestFailedFeeIndicator;
	}

	/**
	 * Sets the Cleared By Issuance.
	 * 
	 * @param clearedByIssuance the cleared by issuance
	 */
	public void setClearedByIssuance(Boolean clearedByIssuance) {
		this.isCdlisPdpsCleared = clearedByIssuance;
	}

	/**
	 * Sets the comlDlDriveTestFeeUsedIndicator.
	 * 
	 * @param comlDlDriveTestFeeUsedIndicator the comlDlDriveTestFeeUsedIndicator to set
	 */
	public void setComlDlDriveTestFeeUsedIndicator(
			Boolean comlDlDriveTestFeeUsedIndicator) {
		this.comlDlDriveTestFeeUsedIndicator = comlDlDriveTestFeeUsedIndicator;
	}

	/**
	 * Sets the Commercial Remove Restriction Indicator.
	 * 
	 * @param isCommercialRemoveRestrictionIndicator the isCommercialRemoveRestrictionIndicator to set
	 */
	public void setCommercialRemoveRestrictionIndicator(
			Boolean isCommercialRemoveRestrictionIndicator) {
		this.isCommercialRemoveRestrictionIndicator = isCommercialRemoveRestrictionIndicator;
	}

	/**
	 * Sets the DL Application Completed by HQ Indicator.
	 *
	 * @param isDlApplicationCompletedByHq the new dl application completed by hq
	 */
	public void setDlApplicationCompletedByHq(
			Boolean isDlApplicationCompletedByHq) {
		this.isDlApplicationCompletedByHq = isDlApplicationCompletedByHq;
	}

	/**
	 * Sets the dl id number for cna condition.
	 * 
	 * @param isDlIdNumberForCnaCondition the new dl id number for cna condition
	 */
	public void setDlIdNumberForCnaCondition(Boolean isDlIdNumberForCnaCondition) {
		this.isDlIdNumberForCnaCondition = isDlIdNumberForCnaCondition;
	}

	/**
	 * Sets the Dl Print Request Document Code.
	 * 
	 * @param dlPrintRequestDocumentCode the dlPrintRequestDocumentCode to set
	 */
	public void setDlPrintRequestDocumentCode(
			CodeSetElement dlPrintRequestDocumentCode) {
		this.dlPrintRequestDocumentCode = dlPrintRequestDocumentCode;
	}

	/**
	 * Sets the Driver Education Code.
	 * 
	 * @param driverEducationCode the driverEducationCode to set
	 */
	public void setDriverEducationCode(CodeSetElement driverEducationCode) {
		this.driverEducationCode = driverEducationCode;
	}

	/**
	 * Sets the Driver Education Record Number.
	 * 
	 * @param driverEducationRecordNumber the driverEducationRecordNumber to set
	 */
	public void setDriverEducationRecordNumber(
			String driverEducationRecordNumber) {
		this.driverEducationRecordNumber = driverEducationRecordNumber;
	}

	/**
	 * Sets the driverEducationStatusCode.
	 * 
	 * @param driverEducationStatusCode the driverEducationStatusCode to set
	 */
	public void setDriverEducationStatusCode(
			CodeSetElement driverEducationStatusCode) {
		this.driverEducationStatusCode = driverEducationStatusCode;
	}

	/**
	 * Sets the driver education status code read only for cda.
	 * CDA transaction cannot write to this field.
	 *
	 * @param driverEducationStatusCodeReadOnlyForCda the driverEducationStatusCodeReadOnlyForCda to set
	 */
	public void setDriverEducationStatusCodeReadOnlyForCda(
			CodeSetElement driverEducationStatusCodeReadOnlyForCda) {
		this.driverEducationStatusCodeReadOnlyForCda = driverEducationStatusCodeReadOnlyForCda;
	}

	/**
	 * Sets the Driver Training Code.
	 * 
	 * @param driverTrainingCode the driverTrainingCode to set
	 */
	public void setDriverTrainingCode(CodeSetElement driverTrainingCode) {
		this.driverTrainingCode = driverTrainingCode;
	}

	/**
	 * Sets the Driver Training Record Number.
	 * 
	 * @param driverTrainingRecordNumber the driverTrainingRecordNumber to set
	 */
	public void setDriverTrainingRecordNumber(String driverTrainingRecordNumber) {
		this.driverTrainingRecordNumber = driverTrainingRecordNumber;
	}

	/**
	 * Sets the driverTrainingStatusCode.
	 * 
	 * @param driverTrainingStatusCode the driverTrainingStatusCode to set
	 */
	public void setDriverTrainingStatusCode(
			CodeSetElement driverTrainingStatusCode) {
		this.driverTrainingStatusCode = driverTrainingStatusCode;
	}

	/**
	 * Sets the driver training status code read only for cda.
	 * CDA transaction cannot write to this field.
	 *
	 * @param driverTrainingStatusCodeReadOnlyForCda the driverTrainingStatusCodeReadOnlyForCda to set
	 */
	public void setDriverTrainingStatusCodeReadOnlyForCda(
			CodeSetElement driverTrainingStatusCodeReadOnlyForCda) {
		this.driverTrainingStatusCodeReadOnlyForCda = driverTrainingStatusCodeReadOnlyForCda;
	}

	/**
	 * Sets the isEligibleForRestrictionCOE.
	 *
	 * @param isEligibleForRestrictionCoe the new eligible for restriction coe
	 */
	public void setEligibleForRestrictionCoe(Boolean isEligibleForRestrictionCoe) {
		this.isEligibleForRestrictionCoe = isEligibleForRestrictionCoe;
	}

	/**
	 * Sets the eli hit counter.
	 *
	 * @param eliHitCounter the eliHitCounter to set
	 */
	public void setEliHitCounter(Integer eliHitCounter) {
		this.eliHitCounter = eliHitCounter;
	}

	/**
	 * Sets the exams last sent to akts.
	 *
	 * @param exams the new exams last sent to akts
	 */
	public void setExamsLastSentToAkts(Set <KnowledgeExam> exams) {
		examsLastSentToAkts = exams;
	}

	/**
	 * Sets the Existing Incomplete Application Reason Code to
	 * either Driver License or Id Card.
	 * 
	 * @param licenseType the License Type
	 * @param incompleteAppReasonCode the Incomplete Application Reason Code
	 */
	public void setExistingIncompleteApplicationReason(LicenseType licenseType,
			CodeSetElement incompleteAppReasonCode) {
		if (licenseType.equals(LicenseType.DRIVER_LICENSE)) {
			this.getLicense().setExistingIncompleteApplicationReasonCode(
					incompleteAppReasonCode);
		}
		else if (licenseType.equals(LicenseType.ID_CARD)) {
			this.getIdCard().setExistingIncompleteApplicationReasonCode(
					incompleteAppReasonCode);
		}
	}

	/**
	 * Sets the existing ssn.
	 * 
	 * @param existingSsn the existingSsn to set
	 */
	public void setExistingSsn(String existingSsn) {
		this.existingSsn = existingSsn;
	}

	/**
	 * Sets the existing user verified bdlp code.
	 * 
	 * @param existingUserVerifiedBdlpCode the existingUserVerifiedBdlpCode to set
	 */
	public void setExistingUserVerifiedBdlpCode(
			CodeSetElement existingUserVerifiedBdlpCode) {
		this.existingUserVerifiedBdlpCode = existingUserVerifiedBdlpCode;
	}

	/**
	 * Sets the Existing User Verified Ssn Code.
	 * 
	 * @param existingUserVerifiedSsnCode the existingUserVerifiedSsnCode to set
	 */
	public void setExistingUserVerifiedSsnCode(
			CodeSetElement existingUserVerifiedSsnCode) {
		this.existingUserVerifiedSsnCode = existingUserVerifiedSsnCode;
	}

	/**
	 *  Set fireFighterFeePaidIndicator.
	 * 
	 * @param fireFighterFeePaidIndicator the fireFighterFeePaidIndicator to set
	 */
	public void setFireFighterFeePaidIndicator(
			Boolean fireFighterFeePaidIndicator) {
		this.fireFighterFeePaidIndicator = fireFighterFeePaidIndicator;
	}

	/**
	 * Sets the fire fighter fee req indicator.
	 * 
	 * @param fireFighterFeeReqIndicator the new fire fighter fee req indicator
	 */
	public void setFireFighterFeeReqIndicator(Boolean fireFighterFeeReqIndicator) {
		this.fireFighterFeeReqIndicator = fireFighterFeeReqIndicator;
	}

	/**
	 * Sets the gen cna drive test fee due fee indicator.
	 * 
	 * @param genCnaDriveTestFeeDueFeeIndicator the new gen cna drive test fee due fee indicator
	 */
	public void setGenCnaDriveTestFeeDueFeeIndicator(
			Boolean genCnaDriveTestFeeDueFeeIndicator) {
		this.genCnaDriveTestFeeDueFeeIndicator = genCnaDriveTestFeeDueFeeIndicator;
	}

	/**
	 * Sets the genCommDlAppFeeIndicator.
	 * 
	 * @param genCommDlAppFeeIndicator the new gen comm dl app fee indicator
	 */
	public void setGenCommDlAppFeeIndicator(Boolean genCommDlAppFeeIndicator) {
		this.genCommDlAppFeeIndicator = genCommDlAppFeeIndicator;
	}

	/**
	 * Set genCommDlAppFeePaidIndicator.
	 *
	 * @param genCommDlAppFeePaidIndicator the genCommDlAppFeePaidIndicator to set
	 */
	public void setGenCommDlAppFeePaidIndicator(
			Boolean genCommDlAppFeePaidIndicator) {
		this.genCommDlAppFeePaidIndicator = genCommDlAppFeePaidIndicator;
	}

	/**
	 * Sets the genCommDlDrvFeeIndicator.
	 * 
	 * @param genCommDlDrvFeeIndicator the new gen comm dl drv fee indicator
	 */
	public void setGenCommDlDrvFeeIndicator(Boolean genCommDlDrvFeeIndicator) {
		this.genCommDlDrvFeeIndicator = genCommDlDrvFeeIndicator;
	}

	/**
	 * Sets the history record10 year check.
	 *
	 * @param historyRecord10YearCheck the new history record10 year check
	 */
	public void setHistoryRecord10YearCheck(
			CodeSetElement historyRecord10YearCheck) {
		this.historyRecord10YearCheck = historyRecord10YearCheck;
	}

	/**
	 * Sets the ID Card.
	 * ID card is associated with an Applicant.
	 * 
	 * @param idCard the idCard to set
	 */
	public void setIdCard(IdCard idCard) {
		this.getApplicant().setIdCard(idCard);
	}

	/**
	 * Sets the inquiry response code.
	 * 
	 * @param inquiryResponseCode the inquiryResponseCode to set
	 */
	public void setInquiryResponseCode1(CodeSetElement inquiryResponseCode) {
		this.inquiryResponseCode1 = inquiryResponseCode;
	}

	/**
	 * Sets the inquiry response code2.
	 * 
	 * @param inquiryResponseCode2 the new inquiry response code2
	 */
	public void setInquiryResponseCode2(CodeSetElement inquiryResponseCode2) {
		this.inquiryResponseCode2 = inquiryResponseCode2;
	}

	/**
	 * Sets the limited term indicator.
	 * 
	 * @param isLimitedTermIndicator the new limited term indicator
	 */
	public void setIsLimitedTermIndicator(Boolean isLimitedTermIndicator) {
		this.isLimitedTermIndicator = isLimitedTermIndicator;
	}

	/**
	 * Sets the checks if is name changed.
	 *
	 * @param isNameChanged the new checks if is name changed
	 */
	public void setIsNameChanged(Boolean isNameChanged) {
		this.isNameChanged = isNameChanged;
	}

	/**
	 * Sets the Legal Presence Check Bypass Indicator.
	 * 
	 * @param isLegalPresenceCheckBypassIndicator the isLegalPresenceCheckBypassIndicator to set
	 */
	public void setLegalPresenceCheckBypassIndicator(
			Boolean isLegalPresenceCheckBypassIndicator) {
		this.isLegalPresenceCheckBypassIndicator = isLegalPresenceCheckBypassIndicator;
	}

	/**
	 * Sets the Driver License.
	 * Driver License is associated with an Applicant.
	 * 
	 * @param license the license to set
	 */
	public void setLicense(DriverLicense license) {
		this.getApplicant().setDriverLicense(license);
	}

	/**
	 * Sets whether an HQ review of medical documents is required.
	 *
	 * @param medicalHqReviewRequiredIndicator the new medical hq review required indicator
	 */
	public void setMedicalHqReviewRequiredIndicator(
			Boolean medicalHqReviewRequiredIndicator) {
		this.medicalHqReviewRequiredIndicator = medicalHqReviewRequiredIndicator;
	}

	/**
	 * Sets the Military Duty Code.
	 * 
	 * @param militaryDutyCode the militaryDutyCode to set
	 */
	public void setMilitaryDutyCode(CodeSetElement militaryDutyCode) {
		this.militaryDutyCode = militaryDutyCode;
	}

	/**
	 * Set motorCycleRetestPaidIndicator.
	 *
	 * @param motorCycleRetestPaidIndicator the motorCycleRetestPaidIndicator to set
	 */
	public void setMotorCycleRetestPaidIndicator(
			Boolean motorCycleRetestPaidIndicator) {
		this.motorCycleRetestPaidIndicator = motorCycleRetestPaidIndicator;
	}

	/**
	 * Sets the motor cycle retest req indicator.
	 * 
	 * @param motorCycleRetestReqIndicator the new motor cycle retest req indicator
	 */
	public void setMotorCycleRetestReqIndicator(
			Boolean motorCycleRetestReqIndicator) {
		this.motorCycleRetestReqIndicator = motorCycleRetestReqIndicator;
	}

	/**
	 * Set motorCycleRetestUsedIndicator.
	 *
	 * @param motorCycleRetestUsedIndicator the motorCycleRetestUsedIndicator to set
	 */
	public void setMotorCycleRetestUsedIndicator(
			Boolean motorCycleRetestUsedIndicator) {
		this.motorCycleRetestUsedIndicator = motorCycleRetestUsedIndicator;
	}

	/**
	 * Sets the MC Training Code.
	 * 
	 * @param motorCycleTrainingCode the motorCycleTrainingCode to set
	 */
	public void setMotorCycleTrainingCode(CodeSetElement motorCycleTrainingCode) {
		this.motorCycleTrainingCode = motorCycleTrainingCode;
	}

	/**
	 * Sets the New Incomplete Application Reason Code.
	 * 
	 * @param newIncompleteApplicationReasonCode the newIncompleteApplicationReasonCode to set
	 */
	public void setNewIncompleteApplicationReasonCode(
			CodeSetElement newIncompleteApplicationReasonCode) {
		if (EaseUtil.isNotNull(newIncompleteApplicationReasonCode)) {
			this.newIncompleteApplicationReasonCode = new CodeSetElement(
					newIncompleteApplicationReasonCode.getName(),
					newIncompleteApplicationReasonCode.getCode(),
					newIncompleteApplicationReasonCode.getDescription(),
					newIncompleteApplicationReasonCode.getEffectiveDate(),
					newIncompleteApplicationReasonCode.getEndDate());
		}
		else {
			this.newIncompleteApplicationReasonCode = null;
		}
		//this.newIncompleteApplicationReasonCode = newIncompleteApplicationReasonCode;
	}

	/**
	 * Sets the New Number Required Indicator.
	 * 
	 * @param newLicenseNumberRequired the new license number required
	 */
	public void setNewLicenseNumberRequired(Boolean newLicenseNumberRequired) {
		this.isNewLicenseNumberRequired = newLicenseNumberRequired;
	}

	/**
	 * Sets the User Verified Bdlp Code.
	 * 
	 * @param bdlpCode the bdlp code
	 * 
	 * @return the newUserVerifiedSsnCode
	 */
	public void setNewUserVerifiedBdlpCode(CodeSetElement bdlpCode) {
		this.newUserVerifiedBdlpCode = bdlpCode;
	}

	/**
	 * Sets the New User Verified Ssn Code.
	 * 
	 * @param userVerifiedSsnCode the user verified ssn code
	 */
	public void setNewUserVerifiedSsnCode(CodeSetElement userVerifiedSsnCode) {
		this.newUserVerifiedSsnCode = userVerifiedSsnCode;
	}

	/**
	 * Set nonCommercialDriveRetestFeePaidIndicator.
	 *
	 * @param nonCommercialDriveRetestFeePaidIndicator the nonCommercialDriveRetestFeePaidIndicator to set
	 */
	public void setNonCommercialDriveRetestFeePaidIndicator(
			Boolean nonCommercialDriveRetestFeePaidIndicator) {
		this.nonCommercialDriveRetestFeePaidIndicator = nonCommercialDriveRetestFeePaidIndicator;
	}

	/**
	 * Sets the non commercial drive retest fee req indicator.
	 * 
	 * @param nonCommercialDriveRetestFeeReqIndicator the new non commercial drive retest fee req indicator
	 */
	public void setNonCommercialDriveRetestFeeReqIndicator(
			Boolean nonCommercialDriveRetestFeeReqIndicator) {
		this.nonCommercialDriveRetestFeeReqIndicator = nonCommercialDriveRetestFeeReqIndicator;
	}

	/**
	 * Set nonCommercialDriveRetestFeeUsedIndicator.
	 *
	 * @param nonCommercialDriveRetestFeeUsedIndicator the nonCommercialDriveRetestFeeUsedIndicator to set
	 */
	public void setNonCommercialDriveRetestFeeUsedIndicator(
			Boolean nonCommercialDriveRetestFeeUsedIndicator) {
		this.nonCommercialDriveRetestFeeUsedIndicator = nonCommercialDriveRetestFeeUsedIndicator;
	}

	/**
	 * Sets the operational mode.
	 *
	 * @param operationalMode the operationalMode to set
	 */
	public void setOperationalMode(CodeSetElement operationalMode) {
		this.operationalMode = operationalMode;
	}

	/**
	 * Sets the Organ Donor Indicator.
	 * 
	 * @param isOrganDonor the isOrganDonor to set
	 */
	public void setOrganDonor(Boolean isOrganDonor) {
		this.isOrganDonor = isOrganDonor;
	}

	/**
	 * Sets the Original Application Indicator.
	 * 
	 * @param isOriginalApplicationIndicator the isOriginalApplicationIndicator to set
	 */
	public void setOriginalApplicationIndicator(
			Boolean isOriginalApplicationIndicator) {
		this.isOriginalApplicationIndicator = isOriginalApplicationIndicator;
	}

	/**
	 * Sets the original for cna condition.
	 * 
	 * @param isOriginalForCnaCondition the new original for cna condition
	 */
	public void setOriginalForCnaCondition(Boolean isOriginalForCnaCondition) {
		this.isOriginalForCnaCondition = isOriginalForCnaCondition;
	}

	/**
	 * Sets the Driver Education and Training Code.
	 * 
	 * @param outOfStateDriverEducationAndTrainingWaiveCode the out of state driver education and training waive code
	 */
	public void setOutOfStateDriverEducationAndTrainingWaiveCode(
			CodeSetElement outOfStateDriverEducationAndTrainingWaiveCode) {
		this.outOfStateDriverEducationAndTrainingWaiveCode = outOfStateDriverEducationAndTrainingWaiveCode;
	}

	/**
	 * Sets the outstanding knowledge exams.
	 *
	 * @param exams the new outstanding knowledge exams
	 */
	public void setOutstandingKnowledgeExams(Set <KnowledgeExam> exams) {
		outstandingKnowledgeExams = exams;
	}

	/**
	 * Sets the paid invoice item.
	 *
	 * @param paidInvoiceItem the paidInvoiceItem to set
	 */
	public void setPaidInvoiceItem(InvoiceItem paidInvoiceItem) {
		this.paidInvoiceItem = paidInvoiceItem;
	}

	/**
	 * Sets the pdps inquiry indicator.
	 *
	 * @param pdpsInquiryIndicator the pdpsInquiryIndicator to set
	 */
	public void setPdpsInquiryIndicator(String pdpsInquiryIndicator) {
		this.pdpsInquiryIndicator = pdpsInquiryIndicator;
	}

	/**
	 * Sets the pdps result hits.
	 * 
	 * @param pdpsResultHits the pdpsResultHits to set
	 */
	public void setPdpsResultHits1(List <DrivingRecord> pdpsResultHits) {
		this.pdpsResultHits1 = pdpsResultHits;
	}

	/**
	 * Sets the pdps result hits2.
	 * 
	 * @param pdpsResultHits2 the new pdps result hits2
	 */
	public void setPdpsResultHits2(List <DrivingRecord> pdpsResultHits2) {
		this.pdpsResultHits2 = pdpsResultHits2;
	}

	/**
	 * Sets the pending applied license classes.
	 *
	 * @param pendingAppliedLicenseClasses the pendingAppliedLicenseClasses to set
	 */
	public void setPendingAppliedLicenseClasses(
			List <CodeSetElement> pendingAppliedLicenseClasses) {
		this.pendingAppliedLicenseClasses = pendingAppliedLicenseClasses;
	}

	/**
	 * Sets the photoRetrieved.
	 * 
	 * @param aCode the a code
	 */
	public void setPhotoRetrieved(CodeSetElement aCode) {
		//TODO - why is this a code set element? a simple boolean flag would not suffice?
		photoRetrieved = aCode;
	}

	/**
	 * Sets the photo taken type.
	 *
	 * @param photoTakenType the photoTakenType to set
	 */
	public void setPhotoTakenType(CodeSetElement photoTakenType) {
		this.photoTakenType = photoTakenType;
	}

	/**
	 * Sets the physical or mental problem code.
	 * 
	 * @param physicalOrMentalProblemCode the new physical or mental problem code
	 */
	public void setPhysicalOrMentalProblemCode(
			CodeSetElement physicalOrMentalProblemCode) {
		this.physicalOrMentalProblemCode = physicalOrMentalProblemCode;
	}

	/**
	 * Sets the previous user verified bdlp code.
	 *
	 * @param previousUserVerifiedBdlpCode the previousUserVerifiedBdlpCode to set
	 */
	public void setPreviousUserVerifiedBdlpCode(
			CodeSetElement previousUserVerifiedBdlpCode) {
		this.previousUserVerifiedBdlpCode = previousUserVerifiedBdlpCode;
	}

	/**
	 * Sets the previous user verified SSN code.
	 * 
	 * @param previousUserVerifiedSsnCode the new previous user verified SSN code
	 */
	public void setPreviousUserVerifiedSsnCode(
			CodeSetElement previousUserVerifiedSsnCode) {
		this.previousUserVerifiedSsnCode = previousUserVerifiedSsnCode;
	}

	/**
	 * Sets the prints the request document code from dl id transaction.
	 *
	 * @param printRequestDocumentCodeFromDlIdTransaction the printRequestDocumentCodeFromDlIdTransaction to set
	 */
	public void setPrintRequestDocumentCodeFromDlIdTransaction(
			String printRequestDocumentCodeFromDlIdTransaction) {
		this.printRequestDocumentCodeFromDlIdTransaction = printRequestDocumentCodeFromDlIdTransaction;
	}

	/**
	 * Sets the prints the request types.
	 *
	 * @param printRequestTypes the printRequestTypes to set
	 */
	public void setPrintRequestTypes(Set <PrintRequestTypes> printRequestTypes) {
		this.printRequestTypes = printRequestTypes;
	}

	/**
	 * Sets the Questionable Pdps Indicator.
	 * 
	 * @param questionablePdpsIndicator the questionable pdps indicator
	 */
	public void setQuestionablePdpsIndicator(Boolean questionablePdpsIndicator) {
		this.isQuestionablePdpsIndicator = questionablePdpsIndicator;
	}

	/**
	 * Sets the renewal by mail no fee indicator.
	 * 
	 * @param renewalByMailNoFeeIndicator the new renewal by mail no fee indicator
	 */
	public void setRenewalByMailNoFeeIndicator(
			Boolean renewalByMailNoFeeIndicator) {
		this.renewalByMailNoFeeIndicator = renewalByMailNoFeeIndicator;
	}

	/**
	 * Sets the total app fee amount paid.
	 *
	 * @param totalAppFeeAmountPaid the totalAppFeeAmountPaid to set
	 */
	public void setTotalAppFeeAmountPaid(int totalAppFeeAmountPaid) {
		this.totalAppFeeAmountPaid = totalAppFeeAmountPaid;
	}

	/**
	 * Sets the total pdps records count1.
	 *
	 * @param totalPdpsRecordsCount1 the totalPdpsRecordsCount1 to set
	 */
	public void setTotalPdpsRecordsCount1(int totalPdpsRecordsCount1) {
		this.totalPdpsRecordsCount1 = totalPdpsRecordsCount1;
	}

	/**
	 * Sets the total pdps records count2.
	 *
	 * @param totalPdpsRecordsCount2 the totalPdpsRecordsCount2 to set
	 */
	public void setTotalPdpsRecordsCount2(int totalPdpsRecordsCount2) {
		this.totalPdpsRecordsCount2 = totalPdpsRecordsCount2;
	}

	/**
	 * Sets the user entered bdlp code.
	 *
	 * @param userEnteredBdlpCode the userEnteredBdlpCode to set
	 */
	public void setUserEnteredBdlpCode(CodeSetElement userEnteredBdlpCode) {
		this.userEnteredBdlpCode = userEnteredBdlpCode;
	}

	/**
	 * Sets the Voter Registration Requested.
	 * 
	 * @param voterRegistationRequested the voterRegistationRequested to set
	 */
	public void setVoterRegistationRequested(
			CodeSetElement voterRegistationRequested) {
		this.voterRegistationRequested = voterRegistationRequested;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.document.impl.Application#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("applicant", getApplicant(), anIndent, aBuilder);
		outputKeyValue("cdlisResultHits1", cdlisResultHits1, anIndent, aBuilder);
		outputKeyValue("pdpsResultHits1", pdpsResultHits1, anIndent, aBuilder);
		outputKeyValue("inquiryResponseCode1", inquiryResponseCode1, anIndent,
				aBuilder);
		outputKeyValue("cdlisPdpsResultHits1Processed",
				cdlisPdpsResultHits1Processed, anIndent, aBuilder);
		outputKeyValue("cdlisResultHits2", cdlisResultHits2, anIndent, aBuilder);
		outputKeyValue("pdpsResultHits2", pdpsResultHits2, anIndent, aBuilder);
		outputKeyValue("inquiryResponseCode2", inquiryResponseCode2, anIndent,
				aBuilder);
		outputKeyValue("cdlisPdpsResultHits2Processed",
				cdlisPdpsResultHits2Processed, anIndent, aBuilder);
		outputKeyValue("cdlisTransferType", cdlisTransferType, anIndent,
				aBuilder);
		outputKeyValue("checkLegalPresence", checkLegalPresence, anIndent,
				aBuilder);
		outputKeyValue("dlPrintRequestDocumentCode",
				dlPrintRequestDocumentCode, anIndent, aBuilder);
		outputKeyValue("driverEducationCode", driverEducationCode, anIndent,
				aBuilder);
		outputKeyValue("driverEducationRecordNumber",
				driverEducationRecordNumber, anIndent, aBuilder);
		outputKeyValue("driverEducationStatusCode", driverEducationStatusCode,
				anIndent, aBuilder);
		outputKeyValue("driverTrainingCode", driverTrainingCode, anIndent,
				aBuilder);
		outputKeyValue("driverTrainingRecordNumber",
				driverTrainingRecordNumber, anIndent, aBuilder);
		outputKeyValue("driverTrainingStatusCode", driverTrainingStatusCode,
				anIndent, aBuilder);
		outputKeyValue("existingSsn", existingSsn, anIndent, aBuilder);
		outputKeyValue("existingUserVerifiedBdlpCode",
				existingUserVerifiedBdlpCode, anIndent, aBuilder);
		outputKeyValue("existingUserVerifiedSsnCode",
				existingUserVerifiedSsnCode, anIndent, aBuilder);
		outputKeyValue("fireFighterFeeReqIndicator",
				fireFighterFeeReqIndicator, anIndent, aBuilder);
		outputKeyValue("genCommDlAppFeeIndicator", genCommDlAppFeeIndicator,
				anIndent, aBuilder);
		outputKeyValue("genCommDlDrvFeeIndicator", genCommDlDrvFeeIndicator,
				anIndent, aBuilder);
		outputKeyValue("isAbsentParent", isAbsentParent, anIndent, aBuilder);
		outputKeyValue("isCdlisNdrResponseAvailable",
				isCdlisNdrResponseAvailable, anIndent, aBuilder);
		outputKeyValue("isCdlisPdpsCleared", isCdlisPdpsCleared, anIndent,
				aBuilder);
		outputKeyValue("isCommercialRemoveRestrictionIndicator",
				isCommercialRemoveRestrictionIndicator, anIndent, aBuilder);
		outputKeyValue("isDlApplicationCompletedByHQ",
				isDlApplicationCompletedByHq, anIndent, aBuilder);
		outputKeyValue("isEligibleForRestrictionCOE",
				isEligibleForRestrictionCoe, anIndent, aBuilder);
		outputKeyValue("isLegalPresenceCheckBypassIndicator",
				isLegalPresenceCheckBypassIndicator, anIndent, aBuilder);
		outputKeyValue("isLimitedTermIndicator", isLimitedTermIndicator,
				anIndent, aBuilder);
		outputKeyValue("isNewLicenseNumberRequired",
				isNewLicenseNumberRequired, anIndent, aBuilder);
		outputKeyValue("isOrganDonor", isOrganDonor, anIndent, aBuilder);
		outputKeyValue("isOriginalApplicationIndicator",
				isOriginalApplicationIndicator, anIndent, aBuilder);
		outputKeyValue("isQuestionablePdpsIndicator",
				isQuestionablePdpsIndicator, anIndent, aBuilder);
		outputKeyValue("militaryDutyCode", militaryDutyCode, anIndent, aBuilder);
		outputKeyValue("motorCycleRetestReqIndicator",
				motorCycleRetestReqIndicator, anIndent, aBuilder);
		outputKeyValue("motorCycleTrainingCode", motorCycleTrainingCode,
				anIndent, aBuilder);
		outputKeyValue("newIncompleteApplicationReasonCode",
				newIncompleteApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("newUserVerifiedBdlpCode", newUserVerifiedBdlpCode,
				anIndent, aBuilder);
		outputKeyValue("newUserVerifiedSsnCode", newUserVerifiedSsnCode,
				anIndent, aBuilder);
		outputKeyValue("nonCommercialDriveRetestFeeReqIndicator",
				nonCommercialDriveRetestFeeReqIndicator, anIndent, aBuilder);
		outputKeyValue("outOfStateDriverEducationAndTrainingWaiveCode",
				outOfStateDriverEducationAndTrainingWaiveCode, anIndent,
				aBuilder);
		outputKeyValue("physicalOrMentalProblemCode",
				physicalOrMentalProblemCode, anIndent, aBuilder);
		outputKeyValue("previousUserVerifiedBdlpCode",
				previousUserVerifiedBdlpCode, anIndent, aBuilder);
		outputKeyValue("previousUserVerifiedSsnCode",
				previousUserVerifiedSsnCode, anIndent, aBuilder);
		outputKeyValue("voterRegistationRequested", voterRegistationRequested,
				anIndent, aBuilder);
		outputKeyValue("changedDriverEducationCode",
				changedDriverEducationCode, anIndent, aBuilder);
		outputKeyValue("changedDriverTrainingCode", changedDriverTrainingCode,
				anIndent, aBuilder);
		outputKeyValue("changeddriverEducationStatusCode",
				changedDriverEducationStatusCode, anIndent, aBuilder);
		outputKeyValue("changedDriverTrainingStatusCode",
				changedDriverTrainingStatusCode, anIndent, aBuilder);
		outputKeyValue("totalPdpsRecordsCount1", totalPdpsRecordsCount1,
				anIndent, aBuilder);
		outputKeyValue("totalPdpsRecordsCount2", totalPdpsRecordsCount2,
				anIndent, aBuilder);
		outputKeyValue("totalAppFeeAmountPaid", totalAppFeeAmountPaid,
				anIndent, aBuilder);
		outputKeyValue("legalPresenceEmployeeId", legalPresenceEmployeeId,
				anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/**
	 * Update finger print response waited for requests.
	 *
	 */
	public void updateFingerPrintImageRetrievalMap() {
		String key = generateKeyForFingerPrintResponseWaitedForRequests();
		if (!EaseUtil.isNullOrBlank(key)) {
			Boolean value = getFingerPrintImageRetrievalMap().get(key);
			if (value != null && !value) {
				getFingerPrintImageRetrievalMap().put(key, Boolean.TRUE);
			}
		}
	}

	/**
	 * Sets the legal presence employee id.
	 *
	 * @param legalPresenceEmployeeId the legalPresenceEmployeeId to set
	 */
	public void setLegalPresenceEmployeeId(String legalPresenceEmployeeId) {
		this.legalPresenceEmployeeId = legalPresenceEmployeeId;
	}

	/**
	 * Gets the legal presence employee id.
	 *
	 * @return the legalPresenceEmployeeId
	 */
	public String getLegalPresenceEmployeeId() {
		return legalPresenceEmployeeId;
	}

	/**
	 * Sets the checks if is temporary license printed.
	 *
	 * @param isTemporaryLicensePrinted the new checks if is temporary license printed
	 */
	public void setIsTemporaryLicensePrinted(boolean isTemporaryLicensePrinted) {
		this.isTemporaryLicensePrinted = isTemporaryLicensePrinted;
	}

	/**
	 * Checks if is temporary license printed.
	 *
	 * @return true, if is temporary license printed
	 */
	public boolean isTemporaryLicensePrinted() {
		return isTemporaryLicensePrinted;
	}

	/**
	 * Sets the lpv secondary verification required.
	 *
	 * @param isLpvSecondaryVerificationRequired the new lpv secondary verification required
	 */
	public void setLpvSecondaryVerificationRequired(
			boolean isLpvSecondaryVerificationRequired) {
		this.isLpvSecondaryVerificationRequired = isLpvSecondaryVerificationRequired;
	}

	/**
	 * Checks if is lpv secondary verification required.
	 *
	 * @return true, if is lpv secondary verification required
	 */
	public boolean isLpvSecondaryVerificationRequired() {
		return isLpvSecondaryVerificationRequired;
	}
}
/**
 *  Modification History:
 *
 *  $Log: DlApplication.java,v $
 *  Revision 1.153.4.5  2014/07/31 18:08:00  mwlcr1
 *  3.1.2.2 Constants definition change from
 *  I - Northern Mariana Card TO
 *  I - Mexican Passport
 *
 *  3.1.2.2 Constants definition change from
 *  C - Indian Blood Decree TO
 *  C - Indian Blood Decree/North. Mariana /American Indian
 *
 *  Revision 1.153.4.4  2014/07/16 20:26:19  mwlcr1
 *  **2.2.3.18 - 2.2.3.18 When new keyed BD/LP code = �J�, system shall display the message: 0013-DATA DOES NOT MATCH VALID CODES. definition change
 *
 *  Revision 1.153.4.3  2014/07/15 17:34:08  mwlcr1
 *  /**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8' or '2' - adding number2
 *
 *  Revision 1.153.4.2  2014/07/07 15:15:13  mwlcr1
 *  Fixed comment error
 *
 *  Revision 1.153.4.1  2014/07/07 15:05:22  mwlcr1
 *  /**2.2.3.5 System shall format and send SCAN T-Code message when BD/LP code = 'Z' or '8'
 *
 *  Revision 1.153  2013/03/18 22:15:32  mwhys
 *  Added utility method getSocialSecurityNumber().
 *
 *  Revision 1.152  2013/03/08 01:31:45  mwhys
 *  Added field isLpvSecondaryVerificationRequired. (Defect 8667)
 *
 *  Revision 1.151  2013/02/28 00:45:23  mwsmr3
 *  Updated resetCdlisUserKeyedData and resetDrivingRecords methods
 *
 *  Revision 1.150  2013/02/27 23:02:08  mwrrv3
 *  Updated resetCdlisPdpsUserKeyedData() to reset clearedByIssuance flag. (Defect 8660)
 *
 *  Revision 1.149  2013/02/27 22:32:27  mwhys
 *  Added resetCdlisPdpsUserKeyedData(). (Defect 8660)
 *
 *  Revision 1.148  2013/02/20 22:17:39  mwhys
 *  Added a field isTemporaryLicensePrinted. (Defect 8637)
 *
 *  Revision 1.147  2013/02/06 20:45:39  mwhys
 *  Updated logic in getPdpsEligibilityIndicator() to check for CDLIS/PDPS CNA only.
 *  (Defect 8537 - DLA renewal upgrade manual mode)
 *
 *  Revision 1.146  2012/10/18 02:18:53  mwuxb
 *  Removed out of state indicator calculation methods.
 *
 *  Revision 1.145  2012/08/15 18:28:50  mwkfh
 *  fixed null pointer in isAnyNonCommercialLicenseClassExist
 *
 *  Revision 1.144  2012/08/15 16:34:14  mwkfh
 *  Fixed null pointer in isAnyCommercialLicenseClassExist licenseClass code
 *
 *  Revision 1.143  2012/08/15 16:16:26  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.142  2012/08/14 20:43:55  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.141  2012/04/25 23:04:09  mwhys
 *  Added legalPresenceEmployeeId.
 *
 *  Revision 1.140  2012/04/17 22:26:48  mwsec2
 *  AKTS branch code merged to Head
 *
 *  Revision 1.133.2.12  2012/04/17 18:12:25  mwsec2
 *  re-based branch with changes from Head
 *
 *  Revision 1.139  2012/04/05 19:04:40  mwsec2
 *  userEnteredBdlpCode added for FODI business logic
 *
 *  Revision 1.138  2012/03/14 01:57:02  mwxxw
 *  Pull up attribute: applicant to Application class.
 *
 *  Revision 1.137  2012/03/07 20:23:15  mwhys
 *  Updated getPdpsEligibilityIndicator() to check for license status descriptions instead
 *  of codes. (Defect 7201)
 *
 *  Revision 1.136  2012/03/06 19:10:58  mwsec2
 *  changed isLpvDocScanRequired per correction to requirements
 *
 *  Revision 1.135  2012/02/23 19:32:47  mwhys
 *  Regenerate equals() and hashCode(). (Defect 1050)
 *
 *  Revision 1.134  2012/02/23 19:28:36  mwhys
 *  Added printRequestDocumentCodeFromDlIdTransaction. (Defect 1050)
 *
 *  Revision 1.133  2012/01/30 23:53:46  mwsec2
 *  FODI integration code merged to HEAD
 *
 *  Revision 1.132  2011/12/14 00:06:47  mwhys
 *  Updated getPdpsEligibilityIndicator() with updated requirements.
 *
 *  Revision 1.131  2011/11/23 17:54:54  mwhys
 *  Updated field printRequestTypes (Defect 6934)
 *
 *  Revision 1.130  2011/11/08 01:01:15  mwhys
 *  Updated the logic in doesIdExistForDlTransaction() to look for expiration date before
 *  checking for status code. (PRD Defect 6848)
 *
 *  Revision 1.129  2011/11/02 22:49:54  mwhys
 *  Updated the logic in doesIdExistForDlTransaction() to look for status code and
 *  doesDlExistForIdTransaction() to look for existing license classes.
 *
 *  Revision 1.128  2011/10/12 20:44:16  mwrrv3
 *  Removed code related to FEE PAID status - Haresh.
 *
 *  Revision 1.127  2011/10/10 18:39:25  mwhxb3
 *  If original transaction if photo retake then fee is always not paid because fee was never required.
 *
 *  Revision 1.126  2011/10/07 22:32:50  mwhxb3
 *  Renamed to getFeePaidStatus.
 *
 *  Revision 1.125  2011/10/07 22:13:33  mwhxb3
 *  Determine Fee PAid status required for IDP.
 *
 *  Revision 1.124  2011/10/07 21:47:47  mwhxb3
 *  Modified Fee paid status related methods.
 *
 *  Revision 1.123  2011/10/07 21:00:24  mwhxb3
 *  Get Fee Paid status.
 *
 *  Revision 1.122  2011/09/20 21:20:03  mwuxb
 *  Removed method isApplicationRenewalAndFeeNotRequired
 *
 *  Revision 1.121  2011/09/06 17:47:33  mwhys
 *  Refactored userContext::isIssuanceOffice() with isIssuanceOfficeOnly().
 *
 *  Revision 1.120  2011/08/18 19:54:51  mwhys
 *  Added a property "eliHitCounter"
 *
 *  Revision 1.119  2011/08/15 21:44:30  mwhys
 *  Added clearNewUserVerifiedSsnCode()
 *
 *  Revision 1.118  2011/08/11 22:25:40  mwhys
 *  Rolled back previous change and added photoTakenType field.
 *
 *  Revision 1.117  2011/08/11 16:49:35  mwhys
 *  Added a field existingPhotoRequiredCode (to be used in CDA).
 *
 *  Revision 1.116  2011/08/02 22:13:32  mwhys
 *  Added methods to reset/clear SSN related fields.
 *
 *  Revision 1.115  2011/07/26 18:10:33  mwhys
 *  Added business methods to check for name/birthdate/gender change.
 *
 *  Revision 1.114  2011/07/20 20:24:19  mwhys
 *  Added 2 read only fields (DE and DT status codes) for CDA.
 *
 *  Revision 1.113  2011/07/19 17:47:44  mwhys
 *  Added a field pdpsInquiryIndicator.
 *
 *  Revision 1.112  2011/07/12 22:02:02  mwhxb3
 *  Get total CDLIS and PDPS matched records.
 *
 *  Revision 1.111  2011/07/07 21:53:16  mwhys
 *  Updted setNewIncompleteApplicationReasonCode()
 *
 *  Revision 1.110  2011/07/07 21:40:42  mwhys
 *  Added resetNewIncompleteApplicationReasonCode()
 *
 *  Revision 1.109  2011/06/24 20:38:40  mwtjc1
 *  backendUpdateRequiredWithoutCda added
 *
 *  Revision 1.108  2011/06/15 21:53:55  mwrrv3
 *  Added a field changedApplicant Defect # 6230. Committing on behalf of Hari Samala (mwhys)
 *
 *  Revision 1.107  2011/06/14 00:39:40  mwhys
 *  Updated for issuance office.
 *
 *  Revision 1.106  2011/06/13 21:59:56  mwhys
 *  Updated.
 *
 *  Revision 1.105  2011/06/13 21:24:51  mwhys
 *  Fixed defect 6214. Updated getPdpsEligibilityIndicator() with updated requirements.
 *
 *  Revision 1.104  2011/06/10 23:13:34  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.103  2011/06/09 23:57:41  mwhys
 *  Fixed UAT defect 732. Added hasCategoryFireFighter().
 *
 *  Revision 1.102  2011/06/09 22:44:08  mwrka1
 *  Fixed 6215
 *
 *  Revision 1.101  2011/06/09 21:24:09  mwhys
 *  Fixed defect 6214. Updated getPdpsEligibilityIndicator() as per new requirements.
 *
 *  Revision 1.100  2011/06/01 16:52:59  mwhys
 *  Added field previousUserVerifiedBdlpCode (defect 6122).
 *
 *  Revision 1.99  2011/06/01 00:38:54  mwkfh
 *  fixed possible null pointer in isThisTransactionOriginalOriginal
 *
 *  Revision 1.98  2011/05/31 22:04:02  mwtjc1
 *  utility method isThisTransactionOriginalOriginal  added
 *
 *  Revision 1.97  2011/05/26 00:49:39  mwxxw
 *  Fix defect 644.
 *
 *  Revision 1.96  2011/05/24 21:46:30  mwhys
 *  Rolled back changes in version 1.94 to version 1.93 as feeRequiredReasonCode field is present in Application class.
 *
 *  Revision 1.95  2011/05/24 21:06:01  mwtjc1
 *  tempSystemGeneratedIncompleteAppReasonCode is commented
 *
 *  Revision 1.94  2011/05/24 21:04:07  mwhys
 *  Added a field feeRequiredReasonCode. (Fix for defect 700).
 *
 *  Revision 1.93  2011/05/24 20:42:36  mwtjc1
 *  setTempSystemGeneratedIncompleteAppReasonCode is modified
 *
 *  Revision 1.92  2011/05/13 22:23:50  mwhxb3
 *  Return true if application is renewal and fees not required.
 *
 *  Revision 1.91  2011/05/08 22:39:07  mwhxb3
 *  lazy initialize the applicant and driver license.
 *
 *  Revision 1.90  2011/05/03 17:57:36  mwhys
 *  Fixed null pointer issue.
 *
 *  Revision 1.89  2011/05/02 18:44:00  mwtjc1
 *  tempSystemGeneratedIncompleteAppReasonCode added
 *
 *  Revision 1.88  2011/04/28 20:44:25  mwtjc1
 *  generateKeyForFingerPrintResponseWaitedForRequests is made private
 *
 *  Revision 1.87  2011/04/28 20:12:56  mwtjc1
 *  clearFingerPrintImageRetrievalMap is called within addInFingerPrintImageRetrievalMap method
 *
 *  Revision 1.86  2011/04/28 20:10:52  mwtjc1
 *  setFingerPrintImageRetrievalMap removed
 *
 *  Revision 1.85  2011/04/27 18:05:57  mwtjc1
 *  fingerPrintImageRetrievalMap and related business functionality methods added
 *
 *  Revision 1.84  2011/04/22 18:55:37  mwhys
 *  Added method getPassport().
 *
 *  Revision 1.83  2011/04/20 22:45:39  mwhys
 *  Fixed getPdpsEligibilityIndicator() which is used in the ELx converter.
 *
 *  Revision 1.82  2011/04/13 21:59:34  mwuxb
 *  Updates for CDLIS transfer indicator.
 *
 *  Revision 1.81  2011/04/13 21:26:25  mwtjc1
 *  isNameChanged added
 *
 *  Revision 1.80  2011/04/07 04:04:58  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.79.2.1  2011/04/02 21:22:08  mwhys
 *  (1) Regenerated hashCode() and equals() methods.
 *  (2) Modified copy method to include null check for Person.
 *
 *  Revision 1.79  2011/03/24 21:47:50  mwuxb
 *  Added logic for out of state transfer.
 *
 *  Revision 1.78  2011/03/24 00:41:55  mwuxb
 *  Removed incorrect logic from method - hasOutOfStateLicenseSurrendered
 *
 *  Revision 1.77  2011/03/17 00:46:16  mwuxb
 *  Removed the check for print document codes. - defect # 5432
 *
 *  Revision 1.76  2011/03/16 22:37:30  mwtjc1
 *  historyRecord10YearCheck added
 *
 *  Revision 1.75  2011/03/12 01:28:20  mwrrv3
 *  Added new field cdlisPdpsResponseIndicator to support UAT defect# 480.
 *
 *  Revision 1.74  2011/03/09 03:57:31  mwuxb
 *  Changes for out of state code - defect # 5230
 *
 *  Revision 1.73  2011/03/05 00:19:23  mwtjc1
 *  A few methods are moved from ConverterHelper
 *
 *  Revision 1.72  2011/03/03 22:06:14  mwtjc1
 *  isDlPrintRequestDocumentCodeMatchesWithParticularDocumentCode added
 *
 *  Revision 1.71  2011/03/03 21:58:47  mwtjc1
 *  cdlisNotificationDate added
 *
 *  Revision 1.70  2011/03/03 21:51:48  mwtjc1
 *  cdlisNotificationType added
 *
 *  Revision 1.69  2011/03/03 21:17:25  mwtjc1
 *  isAnyCdlisRecordDesignatedWithParticularDesignationCode and isAnyPdpsRecordDesignatedWithParticularDesignationCode
 *
 *  Revision 1.68  2011/03/03 19:36:20  mwtjc1
 *  null check in isAnyPdpsRecordDesignated and isAnyCdliseRecordDesignated methods added
 *
 *  Revision 1.67  2011/03/03 19:35:38  mwtjc1
 *  isAnyPdpsRecordDesignated and isAnyCdliseRecordDesignated methods added
 *
 *  Revision 1.66  2011/03/02 22:33:04  mwhys
 *  Logic for consolidating CDLIS and PDPS records is implemented.
 *
 *  Revision 1.65  2011/03/02 21:58:09  mwhys
 *  Added methods to getConsolidated Cdlis and Pdps Records. Logic need to be implemented.
 *
 *  Revision 1.64  2011/03/02 00:15:50  mwuxb
 *  Added totalAppFeeAmountPaid
 *
 *  Revision 1.63  2011/02/10 06:58:41  mwuxb
 *  Added pendingAppliedLicenseClasses
 *
 *  Revision 1.62  2011/02/06 22:40:56  mwuxb
 *  Added field fireFighterFeePaidIndicator.
 *
 *  Revision 1.61  2011/02/03 00:26:11  mwpxr4
 *  paidInvoiceItem added
 *
 *  Revision 1.60  2011/02/02 02:31:53  mwrrv3
 *  Rollback to previous version.
 *
 *  Revision 1.59  2011/02/02 02:01:53  mwrrv3
 *  Added fraudAppFromOriginalTtc attribute to identify the INC APP REASON CODE from original TTC or not.
 *
 *  Revision 1.58  2011/02/02 00:56:58  mwhxb3
 *  Added fee indicators.
 *
 *  Revision 1.57  2011/01/29 19:59:47  mwhys
 *  Added 2 fields for totalPdpsRecordsCount.
 *
 *  Revision 1.56  2011/01/27 19:50:20  mwtjc1
 *  renewalByMailNoFeeIndicator added
 *
 *  Revision 1.55  2011/01/27 03:51:11  mwtjc1
 *  genCnaDriveTestFeeDueFeeIndicator added
 *
 *  Revision 1.54  2011/01/27 03:48:50  mwyxg1
 *  add comlDlDriveTestFeeUsedIndicator
 *
 *  Revision 1.53  2011/01/22 22:26:51  mwpxp2
 *  Added todo for setPhotoRetrieved/1
 *
 *  Revision 1.52  2011/01/22 01:44:15  mwuxb
 *  Added variable isEligibleForRestrictionCOE
 *
 *  Revision 1.51  2011/01/17 01:20:10  mwpxp2
 *  Builk cleanup
 *
 *  Revision 1.50  2011/01/13 01:46:17  mwrka1
 *  Updated
 *
 *  Revision 1.49  2011/01/12 22:46:27  mwrka1
 *  Updated
 *
 *  Revision 1.48  2011/01/12 19:42:14  mwrrv3
 *  Moved nameWithSpecialCharacters to Person BO.
 *
 *  Revision 1.47  2011/01/12 18:37:16  mwrka1
 *  deep cloning
 *
 *  Revision 1.46  2011/01/11 00:20:03  mwrka1
 *  created properties for changedDriverTrainingStatusCode and changeddriverEducationStatusCode to develop D880 error message
 *
 *  Revision 1.45  2011/01/07 20:17:10  mwrrv3
 *  Added new attribute nameWithSpecialCharacters to allow special characters in the name field.
 *
 *  Revision 1.44  2011/01/04 23:41:15  mwgxk2
 *  Attributes added for CNA Conditions for HQ Inquiry Screen.
 *
 *  Revision 1.43  2010/12/30 19:06:24  mwyxg1
 *  add anotherPhoto
 *
 *  Revision 1.42  2010/12/29 22:45:00  mwyxg1
 *  add photoRetrieved
 *
 *  Revision 1.41  2010/12/17 19:20:22  mwskh1
 *  added changedDriverTrainingCode
 *
 *  Revision 1.40  2010/12/17 17:56:58  mwhxb3
 *  Added acceptRecordIndicator.
 *
 *  Revision 1.39  2010/12/15 18:19:00  mwskh1
 *  added changedDriverEducationCode
 *
 *  Revision 1.38  2010/12/15 00:13:41  mwpxr4
 *  Reverted to previous version.
 *
 *  Revision 1.36  2010/12/13 23:11:09  mwhys
 *  Removed unused variables (related to cdlis/pdps).
 *
 *  Revision 1.35  2010/12/13 02:57:13  mwpxr4
 *  Moved photorequired code from dlapp to app.
 *
 *  Revision 1.34  2010/12/13 00:15:53  mwhys
 *  Replaced CdlisRecord and PdpsRecord with DrivingRecord and added state variables which are used for two CDLIS/PDPS inquiries.
 *
 *  Revision 1.33  2010/12/09 00:22:38  mwpxp2
 *  Modified toStringOn to call super
 *
 *  Revision 1.32  2010/12/07 22:08:36  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.31  2010/12/07 02:42:34  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.30  2010/12/06 20:00:11  mwhys
 *  Removed licenseLocationCode object, as it is not needed.
 *
 *  Revision 1.29  2010/12/06 18:09:05  mwhys
 *  Added licenseLocationCode object to the state.
 *
 *  Revision 1.28  2010/12/04 00:49:34  mwhys
 *  Added isLimitedTermIndicator.
 *
 *  Revision 1.27  2010/12/02 00:15:47  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.26  2010/12/01 23:04:27  mwhys
 *  Added LEGAL PRESENCE PHASE 3 INDICATOR (isCdlisNdrResponseAvailable) field. This is set from the ELI record.
 *
 *  Revision 1.25  2010/12/01 00:12:39  mwhys
 *  Added fireFighterFeeReqIndicator.
 *
 *  Revision 1.24  2010/11/30 00:12:19  mwhys
 *  Added 2 indicators.
 *
 *  Revision 1.23  2010/11/24 01:15:35  mwhys
 *  Added indicators for DL app fee and DL drive fee.
 *
 *  Revision 1.22  2010/11/23 21:31:33  mwsyk1
 *  inquiryResponseCode added
 *
 *  Revision 1.20  2010/11/23 19:25:37  mwtjc1
 *  physicalOrMentalProblemCode added
 *
 *  Revision 1.19  2010/11/11 23:21:34  mwkfh
 *  added mergeCdlisResultHits & mergePdpsResultHits
 *
 *  Revision 1.18  2010/11/11 19:25:19  mwkfh
 *  added inquiryResponseCode
 *
 *  Revision 1.17  2010/11/10 18:52:47  mwskh1
 *  used cc in setNewIncompleteApplicationReasonCode
 *
 *  Revision 1.16  2010/11/09 23:42:53  mwskh1
 *  modified  to use the CodeSetElement copy constructor for the newIncompleteApplicationReasonCode setter
 *
 *  Revision 1.15  2010/10/15 21:30:54  mwuxb
 *  Added new variables - previousUserVerifiedSsnCode & existingSsn for SSN inquiry process.
 *
 *  Revision 1.14  2010/08/27 23:39:31  mwcsj3
 *  Added default values to Fee required and Original application indicators
 *
 *  Revision 1.13  2010/08/12 22:31:59  mwakg
 *  fix nullpointer
 *
 *  Revision 1.12  2010/08/05 18:13:52  mwcsj3
 *  Set default value of  isAbsentParent variable to false
 *
 *  Revision 1.11  2010/07/30 18:12:38  mwpxr4
 *  Corrected getter method.
 *
 *  Revision 1.10  2010/07/29 20:30:43  mwvxm6
 *  Added attribute isAbsentParent
 *
 *  Revision 1.9  2010/07/22 17:50:30  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.8  2010/07/13 22:36:07  mwyxg1
 *  add driverTrainingStatusCode and driverEducationStatusCode
 *
 *  Revision 1.7  2010/06/21 23:01:03  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.5.4.2  2010/06/20 18:07:14  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.6  2010/06/02 20:34:55  mwrsk
 *  Removed clone
 *
 *  Revision 1.5  2010/05/19 20:44:04  mwuxb
 *  Added attributes cdlisResponseCode and pdpsResponseCode
 *
 *  Revision 1.4  2010/05/06 16:08:37  mwuxb
 *  Pulled up applicationTypeCode to Application from DlApplication.
 *
 *  Revision 1.3  2010/04/19 20:12:51  mwuxb
 *  Added existing user verified bdlp code.
 *
 *  Revision 1.2  2010/04/19 20:08:44  mwuxb
 *  Changed User Verified BD/LP code to New User Verified BD/LP code.
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.68  2010/04/15 00:09:21  mwvxm6
 *  Moved dataEntryReceiptNumber to Application and changed type to String
 *
 *  Revision 1.67  2010/04/14 17:06:40  mwuxb
 *  Removed designate field from dlApplication
 *
 *  Revision 1.66  2010/04/14 16:47:58  mwuxb
 *  Updated
 *
 *  Revision 1.65  2010/04/14 16:45:02  mwuxb
 *  Updated
 *
 *  Revision 1.64  2010/04/14 01:32:36  mwvxm6
 *  Move fee and invoice related attributes to Application class since it is now shared with multiple license Applications
 *
 *  Revision 1.63  2010/04/14 00:24:05  mwuxb
 *  Removed attribute - isClearedByIssuanceIndicator since similar variable already present as isCdlisPdpsCleared
 *
 *  Revision 1.62  2010/04/13 22:49:30  mwuxb
 *  Added attribute isCommercialRemoveRestrictionIndicator
 *
 *  Revision 1.61  2010/04/12 23:45:28  mwvxm6
 *  Removed responseMessage from DlApplication
 *
 *  Revision 1.60  2010/04/12 23:42:09  mwvxm6
 *  Removed reasonCode from DlApplication
 *
 *  Revision 1.59  2010/04/12 23:40:15  mwvxm6
 *  Updated CNA condition to common class
 *
 *  Revision 1.58  2010/04/10 01:05:34  mwuxb
 *  Added attribute cdlisTransferType
 *
 *  Revision 1.57  2010/04/09 23:56:48  mwuxb
 *  Added variable isLegalPresenceCheckBypassIndicator
 *
 *  Revision 1.56  2010/04/06 22:02:43  mwvxm6
 *  Deleted duplicate attribute dataEntryRecieptCode
 *
 *  Revision 1.55  2010/04/06 00:06:53  mwuxb
 *  Added attribute existingUserVerifiedSsnCode
 *
 *  Revision 1.54  2010/04/06 00:04:16  mwuxb
 *  Updated attribute name from userVerifiedSsnCode to newUserVerifiedSsnCode
 *
 *  Revision 1.53  2010/04/02 23:48:14  mwuxb
 *  Added attribute isQuestionablePdpsIndicator
 *
 *  Revision 1.52  2010/03/30 22:08:22  mwuxb
 *  Moved mailToTemporaryAddress attribute from DlApplication to License class.
 *
 *  Revision 1.51  2010/03/29 19:01:15  mwhxa2
 *  updated for Incomplete App reason code changes
 *
 *  Revision 1.50  2010/03/29 18:56:07  mwhxa2
 *  Changed existingIncompleteApplicationReasonCode to CodeSetElement
 *
 *  Revision 1.49  2010/03/29 17:59:28  mwhxa2
 *  License Contains ExistingIncompleteAppReason
 *
 *  Revision 1.48  2010/03/29 17:52:27  mwhxa2
 *  DlApplication has access to DriverLicense and IdCard's Existing Incomplete App Reason Code.
 *  DlApplication contains only a single new Incomplete App reason
 *
 *  Revision 1.47  2010/03/29 17:21:16  mwhxa2
 *  Added getXXX() for existing/new incomplete application reason codes for DL, ID Card access from DlApplication
 *
 *  Revision 1.46  2010/03/28 21:47:20  mwsxd10
 *  Cdlis/Pdps result List added. These are DrivingRecord type
 *
 *  Revision 1.45  2010/03/27 22:10:15  mwcsj3
 *  Removed fix me
 *
 *  Revision 1.41  2010/03/26 17:48:06  mwpxr4
 *  Moved Cleared By Issuance Indicator from DriverRecord.
 *
 *  Revision 1.40  2010/03/20 22:15:57  mwuxb
 *  Updated attribute name to outOfStateDriverEducationAndTrainingWaiveCode
 *
 *  Revision 1.39  2010/03/20 21:56:38  mwuxb
 *  Changed outOfStateDriverEducationAndTrainingWaiveCode from String to CodeSetElement
 *
 *  Revision 1.38  2010/03/16 16:35:53  mwuxb
 *  Changed AppReasonCode to ApplicationReasonCode
 *
 *  Revision 1.37  2010/03/16 02:15:33  mwuxb
 *  Changed attribute names from dlPrintRequestDocCode to dlPrintRequestDocumentCode and originalAppIndicator to originalApplicationIndicator
 *
 *  Revision 1.36  2010/03/09 23:58:21  mwvxm6
 *  Removed DafRecordNumber from DL Application
 *
 *  Revision 1.35  2010/03/09 23:03:51  mwuxb
 *  Setter & Getter methods for an attribute newUserVerifiedSsnCode
 *
 *  Revision 1.34  2010/03/03 18:51:28  mwvxm6
 *  Updated attribute name to SsnServiceVerificationCode, and updated user verification code for Bdlp and Ssn verification
 *
 *  Revision 1.33  2010/03/03 03:06:13  mwrsk
 *  Changed to isNewLicenseNumberRequired  from newNumberRequired
 *
 *  Revision 1.32  2010/03/03 02:47:43  mwrsk
 *  Changed to isNewLicenseNumberRequired  from isNewNumberRequired
 *
 *  Revision 1.31  2010/03/03 02:29:16  mwrsk
 *  Changed to isNewLicenseNumberRequired from isNewNumberRequired
 *
 *  Revision 1.30  2010/02/26 23:21:14  mwvxm6
 *  Added CodeSetElement attribute bdlpCode
 *
 *  Revision 1.29  2010/02/26 20:23:00  mwvxm6
 *  Updated variable name to outOfStateDriverEducationAndTrainingWaiveCode
 *
 *  Revision 1.28  2010/02/25 22:07:49  mwuxb
 *  added attribute newIncompleteApplicationReasonCode
 *
 *  Revision 1.27  2010/02/25 21:57:38  mwuxb
 *  changed incompleteAppReasonCode to existingIncompleteApplicationReasonCode
 *
 *  Revision 1.26  2010/02/25 17:49:39  mwuxb
 *  added method isCNACondition(CnaConditionType cnaConditionType)
 *
 *  Revision 1.25  2010/02/25 02:13:13  mwrsk
 *  Made changes related to cnaConditionType
 *
 *  Revision 1.24  2010/02/25 01:49:53  mwrsk
 *  changed isCdlisPdpsCleared
 *
 *  Revision 1.23  2010/02/24 21:42:17  mwuxb
 *  Added attribute isCdlisPdpsCleared
 *
 *  Revision 1.22  2010/02/23 19:45:21  mwuxb
 *  Added attribute dlPrintRequestDocumentCode
 *
 *  Revision 1.21  2010/02/23 01:03:22  mwuxb
 *  Moved attribute isCdlisPdpsInquiryMade from DriverLicense class to this class
 *
 *  Revision 1.20  2010/02/17 17:50:55  mwuxb
 *  Changed String photoRequired attribute to CodeSetElement photoRequiredCode to
 *
 *  Revision 1.19  2010/02/17 00:14:09  mwuxb
 *  Updated draft model
 *
 *  Revision 1.18  2010/02/09 00:01:44  mwrsk
 *  added cnaCondition attribute
 *
 *  Revision 1.17  2010/02/04 01:03:45  mwrsk
 *  Delete CdlisPdpsRecord.java and use CdlisRecord.java & PdpsRecord.java
 *
 *  Revision 1.16  2010/01/28 19:49:20  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.15  2010/01/27 23:17:24  mwvxm6
 *  Moved the cdlis and pdps record lists from DlaProcessContext to DLApplication for the CDA converters. The current records are still in DlaProcessContext
 *
 *  Revision 1.14  2010/01/12 19:31:24  mwhxa2
 *  added reason code and response msg
 *
 *  Revision 1.13  2010/01/12 01:38:49  mwhxa2
 *  Added designate
 *
 *  Revision 1.12  2010/01/12 01:21:30  mwhxa2
 *  Updated setters for flags
 *
 *  Revision 1.11  2010/01/12 01:04:55  mwhxa2
 *  Implemented getLegalPresenceDocument()
 *
 *  Revision 1.10  2010/01/11 22:23:33  mwhxa2
 *  Implemented getLegalPresenceDocument()
 *
 *  Revision 1.9  2010/01/11 22:17:39  mwhxa2
 *  Implemented getSocialSecurityDocument()
 *
 *  Revision 1.8  2010/01/11 18:58:43  mwhxa2
 *  Changed the access to DriverLicense and IdCard.
 *  DlApplication-Person-DriverLicense
 *  DlApplication-Person-IdCard
 *
 *  Revision 1.7  2010/01/07 22:47:29  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.6  2010/01/07 22:29:28  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.5  2010/01/07 18:29:31  mwhxa2
 *  Domain Model changes - Draft 1
 *
 *  Revision 1.4  2010/01/06 00:01:55  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.3  2010/01/05 03:01:42  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:12  mwrsk
 *  Intial commit
 *
 *  Revision 1.42  2009/09/15 14:51:19  mwsmg6
 *  refactoring LicenseClass in DlApplication
 *
 *  Revision 1.41  2009/09/15 04:41:23  mwsmg6
 *  refactoring LicenseClass in DlApplication
 *
 *  Revision 1.40  2009/09/14 23:19:54  mwbvc
 *  default is true for legalPresence
 *
 *  Revision 1.39  2009/09/13 20:45:37  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.38  2009/09/13 00:33:11  mwcsj3
 *  Changed VoterRegistrationCode to CodeSetElement
 *
 *  Revision 1.37  2009/09/10 20:29:56  mwpxp2
 *  Added fixme; bulk cleanup
 *
 *  Revision 1.36  2009/09/10 04:35:59  mwsmg6
 *  LicenseClass
 *
 *  Revision 1.35  2009/09/08 23:28:20  mwsmg6
 *  removing CodeSetElement subclasses
 *
 *  Revision 1.34  2009/09/08 17:59:33  mwsmg6
 *  removing CodeSetElement subclasses
 *
 *  Revision 1.33  2009/09/01 22:05:20  mwcsj3
 *  Made changes to accommodate movement of isMinor from DlApplication to Person
 *
 *  Revision 1.32  2009/09/01 18:59:33  mwcsj3
 *  Over ridden method setMinor added
 *
 *  Revision 1.31  2009/08/31 20:11:39  mwcsj3
 *  Set isMinor default value to false
 *
 *  Revision 1.30  2009/08/28 17:40:51  mwrrv3
 *  Renamed attribute additionalOSDLInfo to additionalOsDlInfo.
 *
 *  Revision 1.29  2009/08/27 17:57:12  mwsmg6
 *  removed inappropriate and unused attribute (tryNumber)
 *
 *  Revision 1.28  2009/08/27 05:39:50  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.27  2009/08/19 20:41:11  mwakg
 *  Updated default attributes for DlApplication
 *
 *  Revision 1.26  2009/08/18 22:21:11  mwakg
 *  Removed TryNumber from DlApplication as it belongs to ProcessData rather than the in DlApplication.
 *
 *  Revision 1.25  2009/08/18 00:16:56  mwhxa2
 *  Fixing failing junit
 *
 *  Revision 1.24  2009/08/14 01:16:57  mwcsj3
 *  Added documents initialization
 *
 *  Revision 1.23  2009/08/10 17:17:50  mwrrv3
 *  Initialized new objects in the constructor.
 *
 *  Revision 1.22  2009/08/10 16:09:33  mwakg
 *  fixed binding issues for SearchPersonByNumber
 *
 *  Revision 1.21  2009/08/08 23:53:33  mwskd2
 *  Added feeRequired attribute.
 *
 *  Revision 1.20  2009/08/08 23:29:24  mwskd2
 *  added DesignateActionCode method
 *
 *  Revision 1.19  2009/08/08 21:20:01  mwrrv3
 *  Added tma (temporary mailing address) attribute.
 *
 *  Revision 1.18  2009/08/08 20:52:27  mwrrv3
 *  Changed data type String to CodeSetElement.
 *
 *  Revision 1.17  2009/08/06 22:31:57  mwskd2
 *  Added RPCode based on raghava discussion.
 *
 *  Revision 1.16  2009/08/06 01:02:04  mwrrv3
 *  Code formatted and remove annotations.
 *
 *  Revision 1.15  2009/08/05 21:29:56  mwrrv3
 *  Refactored License to DriverLicense.
 *
 *  Revision 1.14  2009/08/05 19:12:03  mwrrv3
 *  Created empty objects and assigned to the list in the constructor.
 *
 *  Revision 1.13  2009/08/05 17:51:12  mwskd2
 *  Added new attributes related to DL Application.
 *
 *  Revision 1.12  2009/08/05 16:21:45  mwgxk2
 *  Added new attributes.
 *
 *  Revision 1.11  2009/08/05 05:05:46  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.10  2009/08/05 04:35:09  mwrrv3
 *  Added new attributes
 *
 *  Revision 1.9  2009/08/05 00:20:49  mwrrv3
 *  Added IdCard.
 *
 *  Revision 1.8  2009/08/04 17:55:38  mwyxg1
 *  update constructor
 *
 *  Revision 1.7  2009/08/03 20:41:35  mwrrv3
 *  Added default constructor and created new objects in side default constructor and added comments.
 *
 *  Revision 1.6  2009/07/30 18:49:49  mwrrv3
 *  Moved documents to Application.
 *
 *  Revision 1.5  2009/07/27 23:50:28  mwrrv3
 *  Added documents attribute to DlApplication and added methods to get SSN and LP document.
 *
 *  Revision 1.4  2009/07/26 23:18:54  mwrrv3
 *  Moved some of the attributes from DriverLicenseApplication to DlApplication class.
 *
 *  Revision 1.3  2009/07/21 18:33:58  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.2  2009/07/14 23:44:34  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 01:06:06  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:26  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
