/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.fw.service.IRequest;

import java.util.List;

/**
 * Description: I am interface for request to inventory about its state, 
 * e.g. thresholds
 * 
 * File: IInventoryStateRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/10/07 16:59:00 $
 * Last Changed By: $Author: mwkfh $
 */
public interface IInventoryStateRequest extends IRequest {
	/**
	 * Execute - this supports command pattern - no knowledge of the target service required
	 * 
	 * @return the inventory service response
	 */
	IInventoryStatusRequestResponse execute();

	/**
	 * Gets the thresholds.
	 * 
	 * @return the thresholds
	 */
	public List <IItemThreshold> getThresholds();
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryStateRequest.java,v $
 *  Revision 1.2  2010/10/07 16:59:00  mwkfh
 *  added execute
 *
 *  Revision 1.1  2010/09/20 23:18:15  mwpxp2
 *  Initial
 *
 */
