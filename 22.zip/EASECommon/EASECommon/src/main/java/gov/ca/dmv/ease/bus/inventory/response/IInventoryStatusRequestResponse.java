/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.response;

import java.util.List;

import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.fw.service.IResponse;

/**
 * Description: I am interface for responses for inventory requests related
 * to its state, such as low points and current counts
 * 
 * File: IInventoryStatusRequestResponse.java
 * Module:  gov.ca.dmv.ease.bus.inventory.response
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/20 22:38:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IInventoryStatusRequestResponse extends IResponse {
	/**
	 * Gets the thresholds.
	 * 
	 * @return the thresholds
	 */
	public List <IItemThreshold> getThresholds();

	/**
	 * Gets the threshold for item code.
	 * 
	 * @param aCode the a code
	 * 
	 * @return the threshold for item code
	 */
	public IItemThreshold getThresholdForItemCode(String aCode);
}
/**
 *  Modification History:
 *
 *  $Log: IInventoryStatusRequestResponse.java,v $
 *  Revision 1.1  2010/09/20 22:38:20  mwpxp2
 *  Initial
 *
 */
