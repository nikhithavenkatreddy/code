/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.service;

import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddInventoryRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.AddStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.DeleteInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetCurrentItemCountRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.GetLowestSequenceRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.IssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.ManuallyIssueMultipleInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.MoveInventoryItemRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RemoveStationInventoryAssignmentRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.RestoreInventoryItemsAvailabilityRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SeedInventoryFromDmvaRequest;
import gov.ca.dmv.ease.bus.inventory.request.impl.SetItemCountThresholdRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryItemResponse;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryStatusRequestResponse;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemResponse;
import gov.ca.dmv.ease.bus.inventory.response.IIssuedInventoryItemsResponse;

/**
 * Description: I am interface for Inventory Service
 * File: ILocalInventoryService.java
 * Module:  gov.ca.dmv.ease.bus.dl.service.inventory
 * Created: Aug 31, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.11 $
 * Last Changed: $Date: 2011/11/04 16:39:19 $
 * Last Changed By: $Author: mwkfh $
 */
public interface ILocalInventoryService {
	/**
	 * Execute.
	 * 
	 * @param addInventoryItemRequest the add inventory item request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			AddInventoryItemRequest addInventoryItemRequest);

	/**
	 * Execute.
	 * 
	 * @param addInventoryRequest the add inventory request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(AddInventoryRequest addInventoryRequest);

	/**
	 * Execute.
	 * 
	 * @param addStationInventoryAssignmentRequest the add station inventory assignment request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			AddStationInventoryAssignmentRequest addStationInventoryAssignmentRequest);

	/**
	 * Execute.
	 * 
	 * @param deleteInventoryItemRequest the delete inventory item request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			DeleteInventoryItemRequest deleteInventoryItemRequest);

	/**
	 * Execute.
	 * 
	 * @param getCurrentItemCountRequest the get current item count request
	 * 
	 * @return the inventory service response
	 */
	IInventoryStatusRequestResponse execute(
			GetCurrentItemCountRequest getCurrentItemCountRequest);

	/**
	 * Execute.
	 * 
	 * @param getLowestSequenceRequest the inventory item request
	 * Expected to return the lowest sequenceNo available for a given location (office [, station])
	 * 
	 * @return the inventory service response
	 */
	IInventoryItemResponse execute(
			GetLowestSequenceRequest getLowestSequenceRequest);

	/**
	 * Execute.
	 * 
	 * @param issueInventoryItemRequest the issue inventory item request
	 * Expected to return the lowest sequenceNo available for a given location (office [, station])
	 * 
	 * @return the inventory service response
	 */
	IIssuedInventoryItemResponse execute(
			IssueInventoryItemRequest issueInventoryItemRequest);

	/**
	 * Execute.
	 * 
	 * @param issueMultipleInventoryItemsRequest the issue inventory items request
	 * Expected to return a list of the lowest sequenceNo available for a given location (office [, station])
	 * 
	 * @return the inventory service response
	 */
	IIssuedInventoryItemsResponse execute(
			IssueMultipleInventoryItemsRequest issueMultipleInventoryItemsRequest);

	/**
	 * Execute.
	 * 
	 * @param manuallyIssueMultipleInventoryItemsRequest the manually issue inventory items request
	 * Expected to update list to issued
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			ManuallyIssueMultipleInventoryItemsRequest manuallyIssueMultipleInventoryItemsRequest);

	/**
	 * Execute.
	 * 
	 * @param moveInventoryItemRequest the move inventory item request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			MoveInventoryItemRequest moveInventoryItemRequest);

	/**
	 * Execute.
	 * 
	 * @param removeStationInventoryAssignmentRequest the remove station inventory assignment request
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			RemoveStationInventoryAssignmentRequest removeStationInventoryAssignmentRequest);

	/**
	 * Execute.
	 * 
	 * @param restoreInventoryItemsAvailabilityRequest the inventory items restore availability request
	 * Expected to update list to issued
	 * 
	 * @return the inventory service response
	 */
	IInventoryServiceResponse execute(
			RestoreInventoryItemsAvailabilityRequest restoreInventoryItemsAvailabilityRequest);

	/**
	 * Execute.
	 * 
	 * @param aRequest the a request
	 * 
	 * @return the i response
	 */
	IInventoryServiceResponse execute(SeedInventoryFromDmvaRequest aRequest);

	/**
	 * Execute.
	 * 
	 * @param setItemCountThresholdRequest the set item count threshold request
	 * 
	 * @return the inventory service response
	 */
	IInventoryStatusRequestResponse execute(
			SetItemCountThresholdRequest aRequest);
}
/**
 *  Modification History:
 *
 *  $Log: ILocalInventoryService.java,v $
 *  Revision 1.11  2011/11/04 16:39:19  mwkfh
 *  added GetLowestSequence
 *
 *  Revision 1.10  2011/07/13 17:31:06  mwkfh
 *  added RemoveStationInventoryAssignmentRequest
 *
 *  Revision 1.9  2011/07/12 00:11:16  mwkfh
 *  added AddStationInventoryAssignmentRequest
 *
 *  Revision 1.8  2011/06/08 18:55:33  mwkfh
 *  added AddInventoryRequest
 *
 *  Revision 1.7  2010/12/08 19:03:12  mwkfh
 *  added RestoreInventoryItemsAvailabilityRequest
 *
 *  Revision 1.6  2010/12/07 00:19:36  mwkfh
 *  added ManuallyIssue and IssueMultiple
 *
 *  Revision 1.5  2010/12/05 00:06:16  mwkfh
 *  added IssueMultipleInventoryItemsRequest/Response
 *
 *  Revision 1.4  2010/10/15 18:42:27  mwkfh
 *  added IIssuedInventoryItemResponse
 *
 *  Revision 1.3  2010/09/20 23:13:19  mwpxp2
 *  Added executes for GetCurrentItemCountRequest and SetItemCountThresholdRequest
 *
 *  Revision 1.2  2010/09/20 22:40:47  mwpxp2
 *  Switched over to interfaces as types of produced requests
 *
 *  Revision 1.1  2010/09/20 20:29:12  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.4  2010/09/20 18:25:54  mwpxp2
 *  Added executes for GetCurrentItemCountRequest and SetItemCountThresholdRequest
 *
 *  Revision 1.3  2010/09/16 22:38:53  mwpxp2
 *  Added execute for IssueInventoryItemRequest
 *
 *  Revision 1.2  2010/09/14 19:00:51  mwpxp2
 *  Refactored to use four types of requests: add, remove, move, seed
 *
 *  Revision 1.1  2010/09/01 00:08:18  mwpxp2
 *  Initial
 *
 */
