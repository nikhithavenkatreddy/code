/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item;

import gov.ca.dmv.ease.bo.IBusinessObject;

/**
 * Description: I am interface for manipulating threshold pertaining to inventory items
 * 
 * File: IItemThreshold.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/09/20 22:35:28 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IItemThreshold extends IItemLocation, IBusinessObject {
	/**
	 * Gets the current count.
	 * 
	 * @return the current count
	 */
	int getCurrentCount();

	/**
	 * Gets the item code.
	 * 
	 * @return the item code
	 */
	String getItemCode();

	/**
	 * Gets the low point count.
	 * 
	 * @return the low point count
	 */
	int getLowPointCount();

	/**
	 * Checks if is for code.
	 * 
	 * @param code the code
	 * 
	 * @return true, if is for code
	 */
	boolean isForCode(String code);
}
/**
 *  Modification History:
 *
 *  $Log: IItemThreshold.java,v $
 *  Revision 1.3  2010/09/20 22:35:28  mwpxp2
 *  Added isForCode/1
 *
 *  Revision 1.2  2010/09/20 22:17:26  mwpxp2
 *  Extended from IBusinessObject
 *
 *  Revision 1.1  2010/09/20 18:13:07  mwpxp2
 *  Initial
 *
 */
