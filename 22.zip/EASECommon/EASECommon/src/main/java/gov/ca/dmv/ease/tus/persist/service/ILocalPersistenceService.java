/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 *  http://www.california.gov
 */
package gov.ca.dmv.ease.tus.persist.service;

import gov.ca.dmv.ease.tus.persist.request.impl.AddLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.DeleteLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.IssueMultipleLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.MoveLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.RetrieveLowestSequenceRequest;
import gov.ca.dmv.ease.tus.persist.request.impl.SeedLocalInventoryRequest;
import gov.ca.dmv.ease.tus.persist.response.impl.AddLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.DeleteLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.IssueMultipleLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.MoveLocalInventoryResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.RetrieveLowestSequenceResponse;
import gov.ca.dmv.ease.tus.persist.response.impl.SeedLocalInventoryResponse;

/**
 * Description: I am the interface to the inventory persistence service. 
 * File: ILocalPersistenceService.java 
 * Module: gov.ca.dmv.ease.tus.persist.service 
 * Created: Sep 12, 2010
 * @author MWKFH
 * @version $Revision: 1.6 $ 
 * Last Changed: $Date: 2011/11/03 23:43:18 $ 
 * Last Changed By: $Author: mwkfh $
 */
public interface ILocalPersistenceService {
	/**
	 * Execute.
	 * 
	 * @param addLocalInventoryRequest the add persistence request
	 * 
	 * @return the persistence service response
	 */
	AddLocalInventoryResponse execute(
			AddLocalInventoryRequest addLocalInventoryRequest);

	/**
	 * Execute.
	 * 
	 * @param deleteLocalInventoryRequest the delete persistence request
	 * 
	 * @return the persistence service response
	 */
	DeleteLocalInventoryResponse execute(
			DeleteLocalInventoryRequest deleteLocalInventoryRequest);

	/**
	 * Execute.
	 * 
	 * @param issueLocalInventoryRequest the issue persistence request
	 * 
	 * @return the persistence service response
	 */
	IssueLocalInventoryResponse execute(
			IssueLocalInventoryRequest issueLocalInventoryRequest);

	/**
	 * Execute.
	 * 
	 * @param issueMultipleLocalInventoryRequest the issue persistence request
	 * 
	 * @return the persistence service response
	 */
	IssueMultipleLocalInventoryResponse execute(
			IssueMultipleLocalInventoryRequest issueMultipleLocalInventoryRequest);

	/**
	 * Execute.
	 * 
	 * @param movePersistenceRequest the location move persistence request
	 * 
	 * @return the persistence service response
	 */
	MoveLocalInventoryResponse execute(
			MoveLocalInventoryRequest movePersistenceRequest);

	/**
	 * Execute.
	 * 
	 * @param retrieveLowestSequenceRequest the retrieve persistence request
	 * 
	 * @return the persistence service response
	 */
	RetrieveLowestSequenceResponse execute(
			RetrieveLowestSequenceRequest retrieveLowestSequenceRequest);

	/**
	 * Execute.
	 * 
	 * @param seedLocalInventoryPersistenceRequest the seed persistence request
	 * 
	 * @return the persistence service response
	 */
	SeedLocalInventoryResponse execute(
			SeedLocalInventoryRequest seedPersistenceRequest);
}
/**
 *  Modification History:
 *
 *  $Log: ILocalPersistenceService.java,v $
 *  Revision 1.6  2011/11/03 23:43:18  mwkfh
 *  added execute RetrieveLowestSequenceRequest
 *
 *  Revision 1.5  2011/06/09 18:32:21  mwkfh
 *  added DeleteLocalInventoryRequest
 *
 *  Revision 1.4  2011/06/08 17:33:31  mwkfh
 *  added AddLocalInventoryRequest
 *
 *  Revision 1.3  2010/12/05 00:03:18  mwkfh
 *  added IssueMultipleLocalInventoryReequest/Response
 *
 *  Revision 1.2  2010/12/03 16:52:09  mwkfh
 *  added move local inventory
 *
 *  Revision 1.1  2010/09/20 18:25:44  mwkfh
 *  moved from EASEDL
 *
 *  Revision 1.3  2010/09/20 16:49:52  mwkfh
 *  added issue local inv item
 *
 *  Revision 1.2  2010/09/14 16:31:33  mwkfh
 *  updated local inventory persistence
 *
 *  Revision 1.1  2010/09/14 00:44:03  mwkfh
 *  made LocalPersistenceService non-static
 *
 */
