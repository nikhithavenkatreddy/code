/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.impl;

import gov.ca.dmv.ease.bo.IWithInventoryItem;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.logging.IAuditable;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * Description: License captures the common attributes like license number,
 * license start date, expiration date, license type, license status. 
 * File: License.java 
 * Module: gov.ca.dmv.ease.bo.license.impl Created: Apr 28, 2009
 * @author MWCSJ3
 * @version $Revision: 1.28 $ 
 * Last Changed: $Date: 2012/04/05 20:39:18 $ 
 * Last Changed By: $Author: mwhys $
 */
public abstract class License extends BusinessObject implements Serializable,
		IWithInventoryItem, IAuditable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9158228178768407386L;
	/** Holds license cancellation effective date. */
	private Date cancellationEffectiveDate;
	/** This represents the current term of license. */
	private String currentTermOfLicense;
	/** Holds license effective date. */
	private Date effectiveDate;
	/** The Previous Incomplete Application Reason. */
	private CodeSetElement existingIncompleteApplicationReasonCode;
	/** The DL/ID expiration date. */
	private Date expirationDate;
	/** This represents the fee due date year. */
	private String feeDueYear;
	/** The Fingerprint Information. */
	private FingerprintInformation fingerprintInformation;
	/** The issued. */
	private Boolean inventoryItemIssued = false;
	/** The issued date. */
	private Date inventoryItemIssuedDate;
	/** The inventory item type code. */
	private String inventoryItemTypeCode;
	/** The inventory item Transaction Type Code. */
	private String inventoryItemTypeTransactionCode;
	/** The Value to indicate if DL/ID is mailed/ to be mail to Temporary Mailing Address. TMA*/
	private Boolean isMailToTemporaryAddress;
	/** This represents the last renewal date. */
	private Date lastRenewalDate;
	/** The license location code. (S - Surrendered, L - Lost */
	private CodeSetElement licenseLocation;
	/** The license location status code. (CN - CORR NEEDED, HD - HELD IN DSR, HI - ISSUANCE, RA - RETAKE APP*/
	private CodeSetElement licenseLocationStatus;
	/** The license number. */
	private String licenseNumber;
	/** License State (CA, NY, NY etc). */
	private String licenseState;
	/** Holds the license status (suspended, revoked, etc...) */
	private CodeSetElement licenseStatusCode;
	/** The minor code. */
	private CodeSetElement minorCode;
	/** The new expiration date. */
	private Date newExpirationDate;
	/** The new minor guarantor code. */
	private CodeSetElement newMinorGuarantorCode;
	/** The Photo Information. */
	private PhotoInformation photoInformation;
	/** The Suspense Due Date. This holds the date on which suspension is scheduled for this driver license. */
	private Date suspenseDueDate;
	/** The limited term fee due year. */
	private String limitedTermFeeDueYear;
	
	/**
	 * Instantiates a new license.
	 */
	public License() {
	}
	
	/**
	 * Instantiates a new license.
	 *
	 * @param dataToCopy the data to copy
	 */
	public License(License dataToCopy) {
		super();
		copy(dataToCopy);
	}
	
	/**
	 * Copy.
	 *
	 * @param objectToCopy the data to copy
	 */
	protected void copy(License objectToCopy) {
		if (objectToCopy == null) {
			throw new EaseValidationException(
					"non-null argument expected in copy method for " + this);
		}
		super.copy(objectToCopy);
		if (EaseUtil.isNotNull(objectToCopy.getCancellationEffectiveDate())) {
			setCancellationEffectiveDate(new Date(objectToCopy
					.getCancellationEffectiveDate().getTime()));
		}
		else {
			setCancellationEffectiveDate(null);
		}
		setCurrentTermOfLicense(objectToCopy.getCurrentTermOfLicense());
		if (EaseUtil.isNotNull(objectToCopy.getEffectiveDate())) {
			setEffectiveDate(new Date(objectToCopy.getEffectiveDate().getTime()));
		}
		else {
			setEffectiveDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy
				.getExistingIncompleteApplicationReasonCode())) {
			setExistingIncompleteApplicationReasonCode(objectToCopy
					.getExistingIncompleteApplicationReasonCode().copy());
		}
		else {
			setExistingIncompleteApplicationReasonCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getExpirationDate())) {
			setExpirationDate(new Date(objectToCopy.getExpirationDate()
					.getTime()));
		}
		else {
			setExpirationDate(null);
		}
		setFeeDueYear(objectToCopy.getFeeDueYear());
		if (EaseUtil.isNotNull(objectToCopy.getFingerprintInformation())) {
			setFingerprintInformation(new FingerprintInformation(objectToCopy
					.getFingerprintInformation()));
		}
		else {
			setFingerprintInformation(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getInventoryItemIssued())) {
			setInventoryItemIssued(new Boolean(objectToCopy
					.getInventoryItemIssued()));
		}
		else {
			setInventoryItemIssued(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getInventoryItemIssuedDate())) {
			setInventoryItemIssuedDate(new Date(objectToCopy
					.getInventoryItemIssuedDate().getTime()));
		}
		else {
			setInventoryItemIssuedDate(null);
		}
		setInventoryItemTypeCode(objectToCopy.getInventoryItemTypeCode());
		setInventoryItemTypeTransactionCode(objectToCopy
				.getInventoryItemTypeTransactionCode());
		setMailToTemporaryAddress(objectToCopy.isMailToTemporaryAddress());
		if (EaseUtil.isNotNull(objectToCopy.getLastRenewalDate())) {
			setLastRenewalDate(new Date(objectToCopy.getLastRenewalDate()
					.getTime()));
		}
		else {
			setLastRenewalDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getLicenseLocation())) {
			setLicenseLocation(objectToCopy.getLicenseLocation().copy());
		}
		else {
			setLicenseLocation(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getLicenseLocationStatus())) {
			setLicenseLocationStatus(objectToCopy.getLicenseLocationStatus()
					.copy());
		}
		else {
			setLicenseLocationStatus(null);
		}
		setLicenseNumber(objectToCopy.getLicenseNumber());
		setLicenseState(objectToCopy.getLicenseState());
		if (EaseUtil.isNotNull(objectToCopy.getLicenseStatusCode())) {
			setLicenseStatusCode(objectToCopy.getLicenseStatusCode().copy());
		}
		else {
			setLicenseStatusCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getMinorCode())) {
			setMinorCode(objectToCopy.getMinorCode().copy());
		}
		else {
			setMinorCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getNewExpirationDate())) {
			setNewExpirationDate(new Date(objectToCopy.getNewExpirationDate()
					.getTime()));
		}
		else {
			setNewExpirationDate(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getNewMinorGuarantorCode())) {
			setNewMinorGuarantorCode(objectToCopy.getNewMinorGuarantorCode()
					.copy());
		}
		else {
			setNewMinorGuarantorCode(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getPhotoInformation())) {
			setPhotoInformation(new PhotoInformation(objectToCopy
					.getPhotoInformation()));
		}
		else {
			setPhotoInformation(null);
		}
		if (EaseUtil.isNotNull(objectToCopy.getSuspenseDueDate())) {
			setSuspenseDueDate(new Date(objectToCopy.getSuspenseDueDate()
					.getTime()));
		}
		else {
			setSuspenseDueDate(null);
		}
		setLimitedTermFeeDueYear(objectToCopy.getLimitedTermFeeDueYear());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((cancellationEffectiveDate == null) ? 0
						: cancellationEffectiveDate.hashCode());
		result = prime
				* result
				+ ((currentTermOfLicense == null) ? 0 : currentTermOfLicense
						.hashCode());
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime
				* result
				+ ((existingIncompleteApplicationReasonCode == null) ? 0
						: existingIncompleteApplicationReasonCode.hashCode());
		result = prime * result
				+ ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime * result
				+ ((feeDueYear == null) ? 0 : feeDueYear.hashCode());
		result = prime
				* result
				+ ((fingerprintInformation == null) ? 0
						: fingerprintInformation.hashCode());
		result = prime
				* result
				+ ((inventoryItemIssued == null) ? 0 : inventoryItemIssued
						.hashCode());
		result = prime
				* result
				+ ((inventoryItemIssuedDate == null) ? 0
						: inventoryItemIssuedDate.hashCode());
		result = prime
				* result
				+ ((inventoryItemTypeCode == null) ? 0 : inventoryItemTypeCode
						.hashCode());
		result = prime
				* result
				+ ((inventoryItemTypeTransactionCode == null) ? 0
						: inventoryItemTypeTransactionCode.hashCode());
		result = prime
				* result
				+ ((isMailToTemporaryAddress == null) ? 0
						: isMailToTemporaryAddress.hashCode());
		result = prime * result
				+ ((lastRenewalDate == null) ? 0 : lastRenewalDate.hashCode());
		result = prime * result
				+ ((licenseLocation == null) ? 0 : licenseLocation.hashCode());
		result = prime
				* result
				+ ((licenseLocationStatus == null) ? 0 : licenseLocationStatus
						.hashCode());
		result = prime * result
				+ ((licenseNumber == null) ? 0 : licenseNumber.hashCode());
		result = prime * result
				+ ((licenseState == null) ? 0 : licenseState.hashCode());
		result = prime
				* result
				+ ((licenseStatusCode == null) ? 0 : licenseStatusCode
						.hashCode());
		result = prime
				* result
				+ ((limitedTermFeeDueYear == null) ? 0 : limitedTermFeeDueYear
						.hashCode());
		result = prime * result
				+ ((minorCode == null) ? 0 : minorCode.hashCode());
		result = prime
				* result
				+ ((newExpirationDate == null) ? 0 : newExpirationDate
						.hashCode());
		result = prime
				* result
				+ ((newMinorGuarantorCode == null) ? 0 : newMinorGuarantorCode
						.hashCode());
		result = prime
				* result
				+ ((photoInformation == null) ? 0 : photoInformation.hashCode());
		result = prime * result
				+ ((suspenseDueDate == null) ? 0 : suspenseDueDate.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		License other = (License) obj;
		if (cancellationEffectiveDate == null) {
			if (other.cancellationEffectiveDate != null)
				return false;
		}
		else if (!cancellationEffectiveDate
				.equals(other.cancellationEffectiveDate))
			return false;
		if (currentTermOfLicense == null) {
			if (other.currentTermOfLicense != null)
				return false;
		}
		else if (!currentTermOfLicense.equals(other.currentTermOfLicense))
			return false;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		}
		else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (existingIncompleteApplicationReasonCode == null) {
			if (other.existingIncompleteApplicationReasonCode != null)
				return false;
		}
		else if (!existingIncompleteApplicationReasonCode
				.equals(other.existingIncompleteApplicationReasonCode))
			return false;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		}
		else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (feeDueYear == null) {
			if (other.feeDueYear != null)
				return false;
		}
		else if (!feeDueYear.equals(other.feeDueYear))
			return false;
		if (fingerprintInformation == null) {
			if (other.fingerprintInformation != null)
				return false;
		}
		else if (!fingerprintInformation.equals(other.fingerprintInformation))
			return false;
		if (inventoryItemIssued == null) {
			if (other.inventoryItemIssued != null)
				return false;
		}
		else if (!inventoryItemIssued.equals(other.inventoryItemIssued))
			return false;
		if (inventoryItemIssuedDate == null) {
			if (other.inventoryItemIssuedDate != null)
				return false;
		}
		else if (!inventoryItemIssuedDate.equals(other.inventoryItemIssuedDate))
			return false;
		if (inventoryItemTypeCode == null) {
			if (other.inventoryItemTypeCode != null)
				return false;
		}
		else if (!inventoryItemTypeCode.equals(other.inventoryItemTypeCode))
			return false;
		if (inventoryItemTypeTransactionCode == null) {
			if (other.inventoryItemTypeTransactionCode != null)
				return false;
		}
		else if (!inventoryItemTypeTransactionCode
				.equals(other.inventoryItemTypeTransactionCode))
			return false;
		if (isMailToTemporaryAddress == null) {
			if (other.isMailToTemporaryAddress != null)
				return false;
		}
		else if (!isMailToTemporaryAddress
				.equals(other.isMailToTemporaryAddress))
			return false;
		if (lastRenewalDate == null) {
			if (other.lastRenewalDate != null)
				return false;
		}
		else if (!lastRenewalDate.equals(other.lastRenewalDate))
			return false;
		if (licenseLocation == null) {
			if (other.licenseLocation != null)
				return false;
		}
		else if (!licenseLocation.equals(other.licenseLocation))
			return false;
		if (licenseLocationStatus == null) {
			if (other.licenseLocationStatus != null)
				return false;
		}
		else if (!licenseLocationStatus.equals(other.licenseLocationStatus))
			return false;
		if (licenseNumber == null) {
			if (other.licenseNumber != null)
				return false;
		}
		else if (!licenseNumber.equals(other.licenseNumber))
			return false;
		if (licenseState == null) {
			if (other.licenseState != null)
				return false;
		}
		else if (!licenseState.equals(other.licenseState))
			return false;
		if (licenseStatusCode == null) {
			if (other.licenseStatusCode != null)
				return false;
		}
		else if (!licenseStatusCode.equals(other.licenseStatusCode))
			return false;
		if (limitedTermFeeDueYear == null) {
			if (other.limitedTermFeeDueYear != null)
				return false;
		}
		else if (!limitedTermFeeDueYear.equals(other.limitedTermFeeDueYear))
			return false;
		if (minorCode == null) {
			if (other.minorCode != null)
				return false;
		}
		else if (!minorCode.equals(other.minorCode))
			return false;
		if (newExpirationDate == null) {
			if (other.newExpirationDate != null)
				return false;
		}
		else if (!newExpirationDate.equals(other.newExpirationDate))
			return false;
		if (newMinorGuarantorCode == null) {
			if (other.newMinorGuarantorCode != null)
				return false;
		}
		else if (!newMinorGuarantorCode.equals(other.newMinorGuarantorCode))
			return false;
		if (photoInformation == null) {
			if (other.photoInformation != null)
				return false;
		}
		else if (!photoInformation.equals(other.photoInformation))
			return false;
		if (suspenseDueDate == null) {
			if (other.suspenseDueDate != null)
				return false;
		}
		else if (!suspenseDueDate.equals(other.suspenseDueDate))
			return false;
		return true;
	}
	
	/**
	 * Gets the cancellation effective date.
	 *
	 * @return the cancellationEffectiveDate
	 */
	public Date getCancellationEffectiveDate() {
		return cancellationEffectiveDate;
	}
	
	/**
	 * Gets the current term of license.
	 *
	 * @return the currentTermOfLicense
	 */
	public String getCurrentTermOfLicense() {
		return currentTermOfLicense;
	}
	
	/**
	 * Gets the effective date.
	 * 
	 * @return the effective date
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	
	/**
	 * Gets the Existing Incomplete Application Reason Code.
	 * 
	 * @return the existingIncompleteApplicationReasonCode
	 */
	public CodeSetElement getExistingIncompleteApplicationReasonCode() {
		return this.existingIncompleteApplicationReasonCode;
	}
	
	/**
	 * Gets the expiration date.
	 * 
	 * @return the expirationDate
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}
	
	/**
	 * Get the driver license exipration year (yyyy).
	 * 
	 * @return String year
	 */
	public String getExpirationYear() {
		String strDate = "NONE";
		if (getExpirationDate() != null) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(getExpirationDate());
			strDate = String.valueOf(calendar.get(Calendar.YEAR));
		}
		return strDate;
	}
	
	/**
	 * Gets the Fee Due Date.
	 * 
	 * @return the feeDueDate
	 */
	public String getFeeDueYear() {
		return feeDueYear;
	}
	
	/**
	 * Gets the fingerprint information.
	 *
	 * @return the fingerprintInformation
	 */
	public FingerprintInformation getFingerprintInformation() {
		return fingerprintInformation;
	}
	
	/**
	 * Gets the issued.
	 * 
	 * @return the issued
	 */
	public Boolean getInventoryItemIssued() {
		return inventoryItemIssued;
	}
	
	/**
	 * Gets the issued date.
	 * 
	 * @return the issued date
	 */
	public Date getInventoryItemIssuedDate() {
		return inventoryItemIssuedDate;
	}
	
	/**
	 * Gets the Inventory Item Sequence No.
	 * 
	 * @return Inventory Item Sequence No
	 */
	public String getInventoryItemSequenceNo() {
		return licenseNumber;
	}
	
	/**
	 * Gets the Inventory Item Type Code.
	 * 
	 * @return Inventory Item Type Code
	 */
	public String getInventoryItemTypeCode() {
		return inventoryItemTypeCode;
	}
	
	/**
	 * Gets the typeTransactionCode.
	 * 
	 * @return the typeTransactionCode
	 */
	public String getInventoryItemTypeTransactionCode() {
		return inventoryItemTypeTransactionCode;
	}
	
	/**
	 * Gets the Last Renewal Date.
	 * 
	 * @return the lastRenewalDate
	 */
	public Date getLastRenewalDate() {
		return lastRenewalDate;
	}
	
	/**
	 * Gets the License Location.
	 * 
	 * @return the licenseLocation
	 */
	public CodeSetElement getLicenseLocation() {
		return licenseLocation;
	}
	
	/**
	 * Gets the license location status.
	 *
	 * @return the licenseLocationStatus
	 */
	public CodeSetElement getLicenseLocationStatus() {
		return licenseLocationStatus;
	}
	
	/**
	 * Gets the license number.
	 * 
	 * @return the licenseNumber
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}
	
	/**
	 * Gets the License Issuing State.
	 * 
	 * @return the licenseState
	 */
	public String getLicenseState() {
		return licenseState;
	}
	
	/**
	 * Gets the license status code.
	 * 
	 * @return the license status code
	 */
	public CodeSetElement getLicenseStatusCode() {
		return licenseStatusCode;
	}
	
	/**
	 * Gets the limited term fee due year.
	 *
	 * @return the limitedTermFeeDueYear
	 */
	public String getLimitedTermFeeDueYear() {
		return limitedTermFeeDueYear;
	}
	
	/**
	 * Gets the new expiration date.
	 *
	 * @return the newExpirationDate
	 */
	public Date getNewExpirationDate() {
		return newExpirationDate;
	}
	
	/**
	 * Gets the Minor Code.
	 * 
	 * @return the minorCode
	 */
	public CodeSetElement getMinorCode() {
		return minorCode;
	}
	
	/**
	 * Gets the new minor guarantor code.
	 *
	 * @return the newMinorGuarantorCode
	 */
	public CodeSetElement getNewMinorGuarantorCode() {
		return newMinorGuarantorCode;
	}
	
	/**
	 * Gets the Photo Information.
	 * 
	 * @return the photoInformation
	 */
	public PhotoInformation getPhotoInformation() {
		return photoInformation;
	}
	
	/**
	 * Gets the suspense due date.
	 * 
	 * @return the suspenseDueDate
	 */
	public Date getSuspenseDueDate() {
		return suspenseDueDate;
	}
	
	/**
	 * Checks if is mail to temporary address.
	 *
	 * @return the isMailToTemporaryAddress
	 */
	public Boolean isMailToTemporaryAddress() {
		return isMailToTemporaryAddress;
	}
	
	/**
	 * This method is used for Output Auditing.
	 * 
	 * @param aStringBuilder the String Buffer
	 */
	public void outputAuditLog(StringBuilder aStringBuilder) {
		aStringBuilder.append(',').append("LicenceNumber = ").append(
				licenseNumber);
		aStringBuilder.append(',').append("LicenseState = ").append(
				licenseState);
		aStringBuilder.append(',').append("EffectiveDate = ").append(
				effectiveDate);
		aStringBuilder.append(',').append("ExpirationDate = ").append(
				expirationDate);
	}
	
	/**
	 * Sets the cancellation effective date.
	 *
	 * @param cancellationEffectiveDate the cancellationEffectiveDate to set
	 */
	public void setCancellationEffectiveDate(Date cancellationEffectiveDate) {
		this.cancellationEffectiveDate = cancellationEffectiveDate;
	}
	
	/**
	 * Sets the Current Term of License.
	 * 
	 * @param currentTermOfLicense the currentTermOfLicense to set
	 */
	public void setCurrentTermOfLicense(String currentTermOfLicense) {
		this.currentTermOfLicense = currentTermOfLicense;
	}
	
	/**
	 * Sets the effective date.
	 * 
	 * @param effectiveDate  the new effective date
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	/**
	 * Sets the Existing Incomplete Application Reason Code.
	 * 
	 * @param existingIncompleteApplicationReasonCode the existingIncompleteApplicationReasonCode to set
	 */
	public void setExistingIncompleteApplicationReasonCode(
			CodeSetElement existingIncompleteApplicationReasonCode) {
		if (EaseUtil.isNotNull(existingIncompleteApplicationReasonCode)) {
			this.existingIncompleteApplicationReasonCode = new CodeSetElement(
					existingIncompleteApplicationReasonCode.getName(),
					existingIncompleteApplicationReasonCode.getCode(),
					existingIncompleteApplicationReasonCode.getDescription(),
					existingIncompleteApplicationReasonCode.getEffectiveDate(),
					existingIncompleteApplicationReasonCode.getEndDate());
		}
	}
	
	/**
	 * Reset existing incomplete application reason code.
	 */
	public void resetExistingIncompleteApplicationReasonCode() {
		setExistingIncompleteApplicationReasonCode(new CodeSetElement());
	}
	
	/**
	 * Sets the expiration date.
	 * 
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	/**
	 * Sets the Fee Due Date.
	 * 
	 * @param feeDueDate the feeDueDate to set
	 */
	public void setFeeDueYear(String feeDueDate) {
		this.feeDueYear = feeDueDate;
	}
	
	/**
	 * Sets the fingerprint information.
	 *
	 * @param fingerprintInformation the fingerprintInformation to set
	 */
	public void setFingerprintInformation(
			FingerprintInformation fingerprintInformation) {
		this.fingerprintInformation = fingerprintInformation;
	}
	
	/**
	 * Sets the issued.
	 * 
	 * @param issued
	 *            the issued to set
	 */
	public void setInventoryItemIssued(Boolean issued) {
		this.inventoryItemIssued = issued;
	}
	
	/**
	 * Sets the issued date.
	 * 
	 * @param issuedDate
	 *            the new issued date
	 */
	public void setInventoryItemIssuedDate(Date issuedDate) {
		this.inventoryItemIssuedDate = issuedDate;
	}
	
	/**
	 * Sets the Inventory Item Sequence No.
	 *
	 * @param inventoryItemSequenceNo the new inventory item sequence no
	 */
	public void setInventoryItemSequenceNo(String inventoryItemSequenceNo) {
		this.licenseNumber = inventoryItemSequenceNo;
	}
	
	/**
	 * Sets the Inventory Item Type Code.
	 *
	 * @param inventoryItemTypeCode the new inventory item type code
	 */
	public void setInventoryItemTypeCode(String inventoryItemTypeCode) {
		this.inventoryItemTypeCode = inventoryItemTypeCode;
	}
	
	/**
	 * Sets the typeTransactionCode.
	 * 
	 * @param typeTransactionCode the typeTransactionCode to set
	 */
	public void setInventoryItemTypeTransactionCode(String typeTransactionCode) {
		this.inventoryItemTypeTransactionCode = typeTransactionCode;
	}
	
	/**
	 * Sets the Last Renewal Date.
	 * 
	 * @param lastRenewalDate the lastRenewalDate to set
	 */
	public void setLastRenewalDate(Date lastRenewalDate) {
		this.lastRenewalDate = lastRenewalDate;
	}
	
	/**
	 * Sets the License Location.
	 * 
	 * @param licenseLocation the licenseLocation to set
	 */
	public void setLicenseLocation(CodeSetElement licenseLocation) {
		this.licenseLocation = licenseLocation;
	}
	
	/**
	 * Sets the license location status.
	 *
	 * @param licenseLocationStatus the licenseLocationStatus to set
	 */
	public void setLicenseLocationStatus(CodeSetElement licenseLocationStatus) {
		this.licenseLocationStatus = licenseLocationStatus;
	}
	
	/**
	 * Sets the license number.
	 * 
	 * @param licenseNumber the licenseNumber to set
	 */
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	
	/**
	 * Sets the License State.
	 * 
	 * @param licenseState the licenseState to set
	 */
	public void setLicenseState(String licenseState) {
		this.licenseState = licenseState;
	}
	
	/**
	 * Sets the license status code.
	 * 
	 * @param licenseStatusCode the new license status code
	 */
	public void setLicenseStatusCode(CodeSetElement licenseStatusCode) {
		this.licenseStatusCode = licenseStatusCode;
	}
	
	/**
	 * Sets the limited term fee due year.
	 *
	 * @param limitedTermFeeDueYear the limitedTermFeeDueYear to set
	 */
	public void setLimitedTermFeeDueYear(String limitedTermFeeDueYear) {
		this.limitedTermFeeDueYear = limitedTermFeeDueYear;
	}
	
	/**
	 * Sets the mail to temporary address.
	 *
	 * @param isMailToTemporaryAddress the isMailToTemporaryAddress to set
	 */
	public void setMailToTemporaryAddress(Boolean isMailToTemporaryAddress) {
		this.isMailToTemporaryAddress = isMailToTemporaryAddress;
	}
	
	/**
	 * Sets the Minor Code.
	 * 
	 * @param minorCode the minorCode to set
	 */
	public void setMinorCode(CodeSetElement minorCode) {
		this.minorCode = minorCode;
	}
	
	/**
	 * Sets the new expiration date.
	 *
	 * @param newExpirationDate the newExpirationDate to set
	 */
	public void setNewExpirationDate(Date newExpirationDate) {
		this.newExpirationDate = newExpirationDate;
	}
	
	/**
	 * Sets the new minor guarantor code.
	 *
	 * @param newMinorGuarantorCode the newMinorGuarantorCode to set
	 */
	public void setNewMinorGuarantorCode(CodeSetElement newMinorGuarantorCode) {
		this.newMinorGuarantorCode = newMinorGuarantorCode;
	}
	
	/**
	 * Sets the Photo Information.
	 * 
	 * @param photoInformation the photoInformation to set
	 */
	public void setPhotoInformation(PhotoInformation photoInformation) {
		this.photoInformation = photoInformation;
	}
	
	/**
	 * Sets the suspense due date.
	 * 
	 * @param suspenseDueDate the suspenseDueDate to set
	 */
	public void setSuspenseDueDate(Date suspenseDueDate) {
		this.suspenseDueDate = suspenseDueDate;
	}
	
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("cancellationEffectiveDate", cancellationEffectiveDate,
				anIndent, aBuilder);
		outputKeyValue("currentTermOfLicense", currentTermOfLicense, anIndent,
				aBuilder);
		outputKeyValue("effectiveDate", effectiveDate, anIndent, aBuilder);
		outputKeyValue("existingIncompleteApplicationReasonCode",
				existingIncompleteApplicationReasonCode, anIndent, aBuilder);
		outputKeyValue("expirationDate", expirationDate, anIndent, aBuilder);
		outputKeyValue("feeDueYear", feeDueYear, anIndent, aBuilder);
		outputKeyValue("fingerprintInformation", fingerprintInformation,
				anIndent, aBuilder);
		outputKeyValue("inventoryItemIssued", inventoryItemIssued, anIndent,
				aBuilder);
		outputKeyValue("inventoryItemIssuedDate", inventoryItemIssuedDate,
				anIndent, aBuilder);
		outputKeyValue("inventoryItemTypeCode", inventoryItemTypeCode,
				anIndent, aBuilder);
		outputKeyValue("inventoryItemTypeTransactionCode",
				inventoryItemTypeTransactionCode, anIndent, aBuilder);
		outputKeyValue("isMailToTemporaryAddress", isMailToTemporaryAddress,
				anIndent, aBuilder);
		outputKeyValue("lastRenewalDate", lastRenewalDate, anIndent, aBuilder);
		outputKeyValue("licenseLocation", licenseLocation, anIndent, aBuilder);
		outputKeyValue("licenseLocationStatus", licenseLocationStatus,
				anIndent, aBuilder);
		outputKeyValue("licenseNumber", licenseNumber, anIndent, aBuilder);
		outputKeyValue("licenseState", licenseState, anIndent, aBuilder);
		outputKeyValue("licenseStatusCode", licenseStatusCode, anIndent,
				aBuilder);
		outputKeyValue("minorCode", minorCode, anIndent, aBuilder);
		outputKeyValue("newExpirationDate", newExpirationDate, anIndent,
				aBuilder);
		outputKeyValue("newMinorGuarantorCode", newMinorGuarantorCode,
				anIndent, aBuilder);
		outputKeyValue("photoInformation", photoInformation, anIndent, aBuilder);
		outputKeyValue("suspenseDueDate", suspenseDueDate, anIndent, aBuilder);
		outputKeyValue("limitedTermFeeDueYear", limitedTermFeeDueYear,
				anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}
	
	/**
	 * Check if license number is present.
	 *
	 * @return a boolean
	 */
	public boolean hasLicenseNumber() {
		if (EaseUtil.isNullOrBlank(licenseNumber)) {
			return false;
		}
		return true;
	}
	
	/**
	 * Check if a license number is same as another license number.
	 *
	 * @param anotherNumber the another number
	 * @return a boolean
	 */
	public boolean hasTheSameLicenseAs(String anotherNumber) {
		if (hasLicenseNumber()) {
			if (licenseNumber.equals(anotherNumber)) {
				return true;
			}
		}
		return false;
	}
}
/**
 * Modification History:
 * 
 * $Log: License.java,v $
 * Revision 1.28  2012/04/05 20:39:18  mwhys
 * Moved limitedTermFeeDueYear from DriverLicense and IdCard classes.
 * Regenerated equals(), hashCode(), and updated copy().
 *
 * Revision 1.27  2011/07/12 22:58:23  mwhxb3
 * Added
 *  1: hasLicenseNumber - Check if license number is present
 *  2: hasTheSameLicenseAs - Check if a license number is same as another license number.
 *
 * Revision 1.26  2011/07/07 21:52:46  mwhys
 * Updated setExistingIncompleteApplicationReasonCode().
 *
 * Revision 1.25  2011/07/07 21:40:59  mwhys
 * Added resetExistingIncompleteApplicationReasonCode()
 *
 * Revision 1.24  2011/04/07 04:04:51  mwhys
 * Merged CopyFunctionality branch into HEAD.
 *
 * Revision 1.23.2.8  2011/04/05 18:16:08  mwhys
 * Moved the code that throws exception from copy-constructor to copy-method.
 *
 * Revision 1.23.2.7  2011/04/04 23:56:24  mwkfh
 * updated copy method
 *
 * Revision 1.23.2.6  2011/04/04 21:01:00  mwkfh
 * updated copy
 *
 * Revision 1.23.2.5  2011/04/04 20:21:55  mwkfh
 * added exception to copy constructor
 *
 * Revision 1.23.2.4  2011/04/04 18:58:27  mwkfh
 * added null check to copy
 *
 * Revision 1.23.2.3  2011/04/04 18:41:45  mwkfh
 * updated copy
 *
 * Revision 1.23.2.2  2011/04/04 18:37:33  mwkfh
 * updated copy
 *
 * Revision 1.23.2.1  2011/04/04 02:06:03  mwark
 * Modified the setter to have the copy constructor.
 *
 * Revision 1.23  2011/03/29 22:45:53  mwtjc1
 * copy method of CodeSetElement is used
 *
 * Revision 1.22  2011/03/25 21:13:19  mwtjc1
 * copy constructor added
 *
 * Revision 1.21  2011/02/01 22:52:05  mwuxb
 * Added new expiration date field - the expiration date which gets calculate in the current transaction.
 *
 * Revision 1.20  2010/12/30 18:16:17  mwuxb
 * Pulled up suspenseDueDate to License level, it is applicable to DL or ID.
 *
 * Revision 1.19  2010/12/07 22:08:54  mwpxp2
 * Implemented ITreePrintable
 *
 * Revision 1.18  2010/12/07 03:57:06  mwpxp2
 * Added toStringOn/1
 *
 * Revision 1.17  2010/12/07 02:04:39  mwpxp2
 * Added toStringOn/1
 *
 * Revision 1.16  2010/12/02 00:15:46  mwhys
 * Moved EaseUtil to .impl package.
 *
 * Revision 1.15  2010/11/11 19:42:03  mwtjc1
 * inventoryItemIssued initialized to false
 *
 * Revision 1.14  2010/11/09 23:41:58  mwskh1
 * modified to use the CodeSetElement copy constructor for the  exisingIncompleteApplicationReasonCode setter
 *
 * Revision 1.13  2010/11/02 20:29:00  mwkfh
 * mapped InventoryItemSequenceNo to licenseNumber property
 *
 * Revision 1.12  2010/10/22 22:18:54  mwkfh
 * License no longer extends inv item but implements IWithInvItem
 *
 * Revision 1.11  2010/08/12 18:56:15  mwcsj3
 * Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 * Revision 1.10  2010/07/22 17:50:32  mwpxp2
 * Bulk cleanup and format
 *
 * Revision 1.9  2010/06/21 23:01:02  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.5.2.2  2010/06/20 18:07:12  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.8  2010/06/11 00:28:05  mwvxm6
 * Added licenseLocationStatus methods
 *
 * Revision 1.7  2010/06/11 00:22:29  mwvxm6
 * Added licenseLocationStatus
 *
 * Revision 1.6  2010/06/07 16:53:59  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.5  2010/05/27 14:37:53  mwrsk
 * Added equals and hashcode methods for fixing Junit tests mwlft1
 *
 * Revision 1.4  2010/05/11 22:17:20  mwuxb
 * Removed expirationText attribute
 *
 * Revision 1.3  2010/05/07 00:41:28  mwvxm6
 * Added Comments
 *
 * Revision 1.2  2010/04/22 01:12:10  mwvxm6
 * Added FingerprintInformation class which is an attribute of License to capture Fingerprint Information from bridge code messages
 *
 * Revision 1.1  2010/04/15 18:31:14  mwvxm6
 * Initial commit of bo packages move to Common
 *
 * Revision 1.14  2010/04/12 16:54:44  mwvxm6
 * Moved attribute licenseLocation from DriverLicense to License class
 *
 * Revision 1.13  2010/04/08 23:28:08  mwvxm6
 * Added attribute cancellationEffectiveDate
 *
 * Revision 1.12  2010/04/08 22:18:34  mwvxm6
 * Changed the name of attribute feeDueDate to feeDueYear
 *
 * Revision 1.11  2010/04/05 18:47:50  mwpxr4
 * Moved new Minor Guarantor code from DriverLicense to License
 *
 * Revision 1.10  2010/03/30 21:46:51  mwuxb
 * Added attribute isMailToTemporaryAddress
 *
 * Revision 1.9  2010/03/29 18:55:51  mwhxa2
 * Changed existingIncompleteApplicationReasonCode to CodeSetElement
 *
 * Revision 1.8  2010/03/29 17:51:27  mwhxa2
 * License Contains ExistingIncompleteAppReason
 *
 * Revision 1.7  2010/03/29 17:05:43  mwhxa2
 * Adding existingIncompleteApplicationReasonCode and newIncompleteApplicationReasonCode attributes
 *
 * Revision 1.6  2010/03/03 18:41:23  mwvxm6
 * Removed VR related attribute personEntityCode
 *
 * Revision 1.5  2010/01/29 23:04:05  mwhxa2
 * Added Photo Information
 *
 * Revision 1.4  2010/01/28 22:21:40  mwhxa2
 * Updated Java Docs
 *
 * Revision 1.3  2010/01/11 21:04:47  mwhxa2
 * Person is now tied to DlApplication instead of license
 *
 * Revision 1.2  2010/01/07 18:29:40  mwhxa2
 * Domain Model changes - Draft 1
 *
 * Revision 1.1  2009/11/23 16:25:12  mwrsk
 * Intial commit
 *
 * Revision 1.17  2009/10/15 18:13:17  mwrka1
 * followed by PMD rules
 *
 * Revision 1.16  2009/10/03 21:06:34  mwpxp2
 * Adjusted imports for fw refactorings; bulk cleanup
 *
 * Revision 1.15  2009/09/28 21:23:26  mwrsk
 * IAuditable & ILoggable moved to framework project
 *
 * Revision 1.14  2009/09/13 20:45:39  mwakg
 * Merging CodeSetCleaning branch into trunk
 *
 * Revision 1.13.2.1  2009/09/12 19:08:52  mwakg
 * Removed CodeSetElement sub classes
 *
 * Revision 1.13  2009/08/27 22:20:39  mwvkk1
 * implemented Iauditable interface
 * Revision 1.12 2009/08/27 05:39:52 mwpxp2 Bulk cleanup
 * 
 * Revision 1.11 2009/08/26 17:42:25 mwsyk1 Added minor code
 * 
 * Revision 1.10 2009/08/22 23:21:48 mwrrv3 Implemented equals and hashCode
 * methods.
 * 
 * Revision 1.9 2009/08/13 18:29:55 mwcsj3 Updated Id expiration year method
 * 
 * Revision 1.8 2009/08/13 18:07:42 mwcsj3 Added getExpirationYear() method
 * 
 * Revision 1.7 2009/08/05 16:41:08 mwgxk2 Added new attribute license state.
 * 
 * Revision 1.6 2009/08/03 20:41:35 mwrrv3 Added default constructor and created
 * new objects in side default constructor and added comments.
 * 
 * Revision 1.5 2009/07/30 22:58:48 mwrrv3 Removed LicenseState reference.
 * 
 * Revision 1.4 2009/07/30 00:27:22 mwrrv3 Added new attributes for DL/ID card.
 * 
 * Revision 1.3 2009/07/27 21:41:37 mwcsj3 Added class header
 * 
 * Revision 1.2 2009/07/14 23:44:31 mwpxp2 Initial move to hnode20
 * 
 * Revision 1.1 2009-07-12 07:41:32 ppalacz Moved to .impl package; added file
 * decorations, todos
 * 
 * Revision 1.1 2009-07-10 07:09:24 ppalacz Synch $Revision 1.1 Apr 28, 2009
 * 2:35:43 PM MWCSJ3 $Initial ITM commit $ $Revision 1.1 Apr 28, 2009 2:35:43 PM
 * MWCSJ3 $Initial $
 */
