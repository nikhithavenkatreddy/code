/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: I group constants for EASE Com
 * File: ICommonErrorMessageConstants.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Oct 21, 2010 
 * @author MWKFH  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/12/08 18:10:49 $
 * Last Changed By: $Author: mwkfh $
 */
public interface ICommonErrorMessageConstants {
	/* Inventory Item errors */
	public static final String UNABLE_TO_ADD_INV_ITEM_RESPONSE = "UNABLE TO ADD INVENTORY ITEM RESPONSE";
	public static final String UNABLE_TO_RETRIEVE_INV_ITEM_CODE = "UNABLE TO RETRIEVE INVENTORY ITEM CODE";
	/* Sequence Pattern errors */
	public static final String BOUNDARIES_OUT_OF_ORDER = "Boundaries out of order!  Lower is greater than upper.";
	public static final String BOUNDARY_OUTSIDE_OF_RANGE = "Boundary outside of range!";
	public static final String EXPECTED_SPACE_IN_BOUNDARY = "Expected space in boundary!";
	public static final String INVALID_CHARS_IN_PATTERN = "Invalid characters in pattern!";
	public static final String PATTERN_AND_BOUNDARY_LENGTHS_NOT_MATCH = "Pattern and boundary lengths do not match!";
	public static final String PATTERN_NOT_CORRECT_SIZE = "Pattern not correct size!";
	public static final String NOT_ENOUGH_INVENTORY_TO_ISSUE = "Not enough inventory items available to issue.";
}
/**
 *  Modification History:
 *
 *  $Log: ICommonErrorMessageConstants.java,v $
 *  Revision 1.3  2010/12/08 18:10:49  mwkfh
 *  added NOT_ENOUGH_INVENTORY_TO_ISSUE
 *
 *  Revision 1.2  2010/11/02 18:23:09  mwkfh
 *  added error message constants
 *
 *  Revision 1.1  2010/10/22 16:16:46  mwkfh
 *  new error message constants for common
 *
 */
