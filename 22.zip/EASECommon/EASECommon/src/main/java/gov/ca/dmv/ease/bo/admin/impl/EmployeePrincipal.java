/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.admin.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;

/**
 * Description: This class is used to store the employee principal info.  
 * File: EmployeePrincipal.java
 * Module:  gov.ca.dmv.ease.bo.admin.impl
 * Created: Aug 12, 2009
 * @author MWRSK
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:32 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EmployeePrincipal extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7854197730449269533L;
	/** The principal id. */
	private String principalId;

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		EmployeePrincipal other = (EmployeePrincipal) obj;
		if (principalId == null) {
			if (other.principalId != null) {
				return false;
			}
		}
		else if (!principalId.equals(other.principalId)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the principal id.
	 * 
	 * @return the principal id
	 */
	public String getPrincipalId() {
		return principalId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((principalId == null) ? 0 : principalId.hashCode());
		return result;
	}

	/**
	 * Sets the principal id.
	 * 
	 * @param principalId the new principal id
	 */
	public void setPrincipalId(String principalId) {
		this.principalId = principalId;
	}
}
/**
 *  Modification History:
 * 
 *  $$Log: EmployeePrincipal.java,v $
 *  $Revision 1.2  2010/07/22 17:50:32  mwpxp2
 *  $Bulk cleanup and format
 *  $
 *  $Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  $Initial commit of bo packages move to Common
 *  $
 *  $Revision 1.3  2010/02/23 22:52:19  mwvxm6
 *  $Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *  $
 *  $Revision 1.2  2010/01/28 19:49:20  mwhxa2
 *  $Updated Java Docs
 *  $
 *  $Revision 1.1  2009/11/23 16:25:16  mwrsk
 *  $Intial commit
 *  $
 *  $Revision 1.13  2009/10/11 00:26:35  mwakg
 *  $Fixed unit tests
 *  $
 *  $Revision 1.12  2009/10/10 20:40:31  mwakg
 *  $Fixed equals of EmployeePrincipal class
 *  $
 *  $Revision 1.11  2009/10/07 01:16:49  mwvxm6
 *  $DB2SequenceAnnotationTesting with Business Objects now use the SEQUENCE ID generation strategy for DB2. Fixed annotations.
 *  $
 *  $Revision 1.10  2009/08/27 05:39:44  mwpxp2
 *  $Bulk cleanup
 *  $
 *  $Revision 1.9  2009/08/22 23:19:32  mwrrv3
 *  $Implemented equals and hashCode methods.
 *  $
 *  $Revision 1.8  2009/08/19 18:41:31  mwrrv3
 *  $Updated the annotations (table name and column names).
 *  $
 *  $Revision 1.7  2009/08/12 17:24:49  mwrsk
 *  $Format code
 *  $
 *  $Revision 1.6  2009/08/12 17:24:23  mwrsk
 *  $Add modification history
 *  $$
*/
