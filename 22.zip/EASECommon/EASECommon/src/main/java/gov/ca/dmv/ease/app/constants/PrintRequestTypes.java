/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.app.constants;

/**
 * Description: Print Request Types
 * File: PrintRequestTypes.java
 * Module:  gov.ca.dmv.ease.app.constants
 * Created: Apr 14, 2010 
 * @author MWYXG1  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/06/15 21:53:08 $
 * Last Changed By: $Author: mwrrv3 $
 */
public enum PrintRequestTypes {
	ADD_COURT_RESTRICTION_PAYMENT_RECEIPT, ADDL_INSTRUCTION_PERMIT_LIMITATIONS_LDD0612, AUTOMATED_DL22_LICENSE, CDLIS_AND_NDR_MATCHES_REPORT, COUNSELOR_INQUIRY_DOCUMENT, DL_RECEIPT, DRIVING_SCHOOL_INSTRUCTOR_PERMIT, FR_PENALITY_FEE_PAYMENT, FTA_FTP_DOCUMENT, FTA_FTP_PAYMENT_RECEIPT_DOCUMENT, /*
	 * FCP specific documents
	 */
	FTA_RELEASE_CERT_UPDATE_DOCUMENT, FTP_RELEASE_CERT_UPDATE_DOCUMENT, /** 
	 * 69U specific documents
	 */
	ID_CARD_VOLUNTARY_CANCELLATION, INSTRUCTION_PERMIT_LDD0611, ISSUANCE_REFERRAL_DOUBLES_LDP0741, ISSUANCE_REFERRAL_FOR_UPDATE_LDP0742, ISSUANCE_REFERRAL_LDP0742,
	/*
	 * 05M specific documents
	 */
	MEDICAL_REPORT_UPDATE_DOCUMENT,
	/*
	 * 92M docs
	 */
	MISC_FIXED_FEE_ITEMS_DOCUMENT, MISC_TEMPORARY_LICENSE, /*
	 * 98M specific documents
	 */
	MISCELLANEOUS_VARIED_FEE_DOCUMENT, /*
	 * SP specific documents
	 */
	OCCUPATIONAL_LICENSING_REFERRAL_DOCUMENT, OCCUPATIONAL_LICENSING_SALES_PERSON_NUMBER_ASSIGNMENT_DOCUMENT, ORGAN_DONOR_1_LDD0851, ORGAN_DONOR_2_LDD0852, /** 
	 * DLA specific documents
	 */
	PDPS_AND_NDR_MATCHES_REPORT, /** 
	 * 30U specific documents
	 */
	PHOTO_RETAKE_NOTIFICATION_DOCUMENT, PRT_HEADQUART_NOTICE_DOCUMENT, /*
	 * PRT specific documents
	 */
	PRT_RECEIPT_OF_PROOF_OF_FILING_DOCUMENT, /*
	 * 04M specific documents
	 */
	REISSUE_FEE_RECEIPT, REMOVE_COURT_RESTRICTION_PAYMENT_RECEIPT, /*
	 * 60U docs
	 */
	SERVICE_OF_ORDER_DOCUMENT, SPECIAL_CERTIFICATE_PAYMENT_RECEIPT, STATE_OF_RECORD_DOCUMENT, /** CDA **/
	INTERIM_LICENSE_LDD0602, TEMP_LICENSE_LDD0602, TEST_RESULTS_1_LDD0631, TEST_RESULTS_2_LDD0632, TRANSACTION_RECEIPT, DL_ID_CHANGE_RECEIPT_LDD0761,
	/*
	 * 10Q specific documents
	 */
	TRANSIT_TRAINING_RECEIPT, VEHICLE_SALES_PERSON_TEMPORARY_PERMIT_DOCUMENT, VEHICLE_SALES_PERSON_TEMPORARY_RECEIPT_DOCUMENT, VOTER_REGISTRATION_LDD0861,
	/**
	 * DIR specfic documents
	 */
	DL_INFO_RECEIPT, DL_INFO_CUSTOMER_RECEIPT
}
/**
 *  Modification History:
 *
 *  $Log: PrintRequestTypes.java,v $
 *  Revision 1.4  2011/06/15 21:53:08  mwrrv3
 *  Added the Constant for DL_ID Change Receipt Defect # 6230 -- Amar Bade
 *
 *  Revision 1.3  2011/05/23 20:46:29  mwkfh
 *  DIR merge
 *
 *  Revision 1.2.2.2  2011/05/18 16:45:35  mwrrv3
 *  DIR implementation Constants updated -- Amar Bade
 *
 *  Revision 1.2.2.1  2011/05/13 17:13:53  mwrrv3
 *  Print funcationality implemented for the DIR TTC -- Amar Bade
 *
 *  Revision 1.2  2011/04/07 18:17:16  mwxxw
 *  Add new enum: TEMP_LICENSE_LDD0602.
 *
 *  Revision 1.1  2011/04/06 00:32:17  mwxxw
 *  New files add for calculation printClassCode for printed docs.
 *
 *  Revision 1.19  2010/11/18 23:56:13  mwpxp2
 *  Added missing javadoc; sorted
 *
 *  Revision 1.18  2010/09/20 17:51:37  mwllh
 *  Added print request type MISCELLANEOUS_VARIED_FEE_DOCUMENT for 98M process
 *
 *  Revision 1.17  2010/09/15 19:15:01  mwrrv2
 *  Updated logic.
 *
 *  Revision 1.16  2010/09/15 18:43:53  mwgxd3
 *  add MISC_FIXED_FEE_ITEMS_DOCUMENT for 92M
 *
 *  Revision 1.15  2010/09/12 23:23:07  mwjxa11
 *  Added StateOfRecord print type
 *
 *  Revision 1.14  2010/09/07 18:06:12  mwcsj3
 *  Added print type medical record update document
 *
 *  Revision 1.13  2010/09/04 21:09:48  mwyxg1
 *  add PRT print types
 *
 *  Revision 1.12  2010/09/03 21:51:42  mwtjc1
 *  fcp related documents added
 *
 *  Revision 1.11  2010/08/31 20:05:47  mwllh
 *  Added logic for 22M TTC
 *
 *  Revision 1.10  2010/08/31 00:02:50  mwrrv2
 *  Updated.
 *
 *  Revision 1.9  2010/08/27 21:41:14  mwrrv2
 *  Updated.
 *
 *  Revision 1.8  2010/08/27 21:30:16  mwrrv2
 *  Updated.
 *
 *  Revision 1.7  2010/08/27 20:06:59  mwrrv2
 *  Updated.
 *
 *  Revision 1.6  2010/08/26 18:11:41  mwrrv2
 *  Updated.
 *
 *  Revision 1.5  2010/08/24 16:50:34  mwrrv2
 *  Updated to support Group 5 ttc.
 *
 *  Revision 1.4  2010/08/23 23:05:05  mwyxg1
 *  remove core constants package
 *
 *  Revision 1.11  2010/08/10 16:28:30  mwrrv2
 *  Added 07Q-CounselorInquiry related document types.
 *
 *  Revision 1.10  2010/07/30 21:47:36  mwtjc1
 *  VEHICLE_SALES_PERSON_TEMPORARY_RECEIPT_DOCUMENT added
 *
 *  Revision 1.9  2010/07/30 21:23:17  mwtjc1
 *  VEHICLE_SALES_PERSON_TEMPORARY_PERMIT_DOCUMENT added
 *
 *  Revision 1.8  2010/07/30 21:06:07  mwtjc1
 *  OCCUPATIONAL_LICENSING_SALES_PERSON_NUMBER_ASSIGNMENT_DOCUMENT added
 *
 *  Revision 1.7  2010/07/30 01:01:15  mwtjc1
 *  OCCUPATIONAL_LICENSING_REFERRAL_DOCUMENT added
 *
 *  Revision 1.6  2010/07/26 21:02:28  mwrrv2
 *  Added constants to support 69U ttc.
 *
 *  Revision 1.5  2010/07/23 00:30:30  mwcsj3
 *  Added ISSUANCE_REFERRAL_FOR_UPDATE_LDP0742 for issuance print request
 *
 *  Revision 1.4  2010/07/20 23:57:52  mwcsj3
 *  Added DL_RECEIPT
 *
 *  Revision 1.3  2010/07/20 22:10:47  mwrrv2
 *  Added printing support for 30U ttc.
 *
 *  Revision 1.2  2010/05/06 04:02:15  mwbxp5
 *  Added print related code---Balaji
 *
 *  Revision 1.1  2010/04/15 21:32:26  mwyxg1
 *  refactor
 *
 *  Revision 1.1  2010/04/15 21:31:02  mwyxg1
 *  refactor to core
 *
 *  Revision 1.2  2010/04/15 21:27:35  mwyxg1
 *  add CDA print types
 *
 *  Revision 1.1  2010/04/15 00:53:53  mwyxg1
 *  add new
 *
 */
