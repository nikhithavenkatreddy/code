/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bus.inventory.request.impl;

import gov.ca.dmv.ease.bo.inventory.item.IInventoryItem;
import gov.ca.dmv.ease.bo.sequence.IContiguousItemSequence;
import gov.ca.dmv.ease.bus.inventory.request.IInventoryItemsRequest;
import gov.ca.dmv.ease.bus.inventory.response.IInventoryServiceResponse;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I add inventory to the system.
 * File: AddInventoryRequest.java
 * Module:  gov.ca.dmv.ease.bus.inventory.request.impl
 * Created: Jun 8, 2011 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/06/08 18:55:33 $
 * Last Changed By: $Author: mwkfh $
 */
public class AddInventoryRequest extends AbstractInventoryItemsRequest
		implements IInventoryItemsRequest {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8395765673837938504L;
	/** The all sequences. */
	private IContiguousItemSequence contiguousItemSequence;

	/**
	 * Instantiates a new seed inventory from dmva request.
	 */
	protected AddInventoryRequest() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param context the context
	 */
	protected AddInventoryRequest(IUserContext context) {
		super(context);
	}

	/**
	 * Instantiates a new add inventory request.
	 * 
	 * @param aSequence the a sequence
	 */
	public AddInventoryRequest(IUserContext context,
			IContiguousItemSequence aSequence) {
		super(context);
		setContiguousItemSequence(aSequence);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#execute()
	 */
	public IInventoryServiceResponse execute() {
		return getService().execute(this);
	}

	/**
	 * Gets the contiguousItemSequence.
	 * 
	 * @return the contiguousItemSequence
	 */
	public IContiguousItemSequence getContiguousItemSequence() {
		return contiguousItemSequence;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bus.dl.inventory.request.impl.AbstractInventoryRequest#getItemCount()
	 */
	@Override
	public int getItemCount() {
		if (EaseUtil.isNotNull(contiguousItemSequence)) {
			return contiguousItemSequence.getItemCount();
		}
		else {
			return 0;
		}
	}

	/**
	 * Gets the item list.
	 * 
	 * @return the item list
	 */
	public List <IInventoryItem> getItemList() {
		if (EaseUtil.isNotNull(contiguousItemSequence)) {
			return contiguousItemSequence.asItemList();
		}
		else {
			return new ArrayList <IInventoryItem>();
		}
	}

	/**
	 * Sets the contiguousItemSequence.
	 * 
	 * @param aSequence the contiguousItemSequence
	 */
	protected void setContiguousItemSequence(IContiguousItemSequence aSequence) {
		this.contiguousItemSequence = aSequence;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AddInventoryRequest.java,v $
 *  Revision 1.1  2011/06/08 18:55:33  mwkfh
 *  added AddInventoryRequest
 *
 */
