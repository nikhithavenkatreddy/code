/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.item.impl;

import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.inventory.item.IItemThreshold;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: I am default implementation of IItemThreshold
 * File: ItemThreshold.java
 * Module:  gov.ca.dmv.ease.bo.inventory.item.impl
 * Created: Sep 20, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.7 $
 * Last Changed: $Date: 2011/09/23 22:00:33 $
 * Last Changed By: $Author: mwkfh $
 */
public class ItemThreshold extends BusinessObject implements IItemThreshold {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4614789640414672556L;
	/** The current count. */
	private Integer currentCount;
	/** The item code. */
	private String itemCode;
	/** The low point count. */
	private Integer lowPointCount;
	/** The office id. */
	private String officeId;
	/** The station id. */
	private String stationId;

	/**
	 * The Default Constructor.
	 */
	protected ItemThreshold() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param anOfficeId the an office id
	 * @param anItemCode the an item code
	 * @param aLowPointCount the a low point count
	 * @param aCurrentCount the a current count
	 */
	public ItemThreshold(String anItemCode, String anOfficeId,
			int aLowPointCount, int aCurrentCount) {
		super();
		setItemCode(anItemCode);
		setOfficeId(anOfficeId);
		setLowPointCount(aLowPointCount);
		setCurrentCount(aCurrentCount);
	}

	/**
	 * The Constructor.
	 * 
	 * @param anOfficeId the an office id
	 * @param stationId the station id
	 * @param anItemCode the an item code
	 * @param aLowPointCount the a low point count
	 * @param aCurrentCount the a current count
	 */
	public ItemThreshold(String anItemCode, String anOfficeId,
			String stationId, int aLowPointCount, int aCurrentCount) {
		super();
		setItemCode(anItemCode);
		setOfficeId(anOfficeId);
		setStationId(stationId);
		setLowPointCount(aLowPointCount);
		setCurrentCount(aCurrentCount);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#changeToOffice()
	 */
	public void changeToOffice() {
		if (!EaseUtil.isNullOrBlank(stationId) && stationId.length() > 1) {
			stationId = stationId.substring(0, 2) + "#";
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ItemThreshold)) {
			return false;
		}
		ItemThreshold other = (ItemThreshold) obj;
		if (currentCount == null) {
			if (other.currentCount != null) {
				return false;
			}
		}
		else if (!currentCount.equals(other.currentCount)) {
			return false;
		}
		if (itemCode == null) {
			if (other.itemCode != null) {
				return false;
			}
		}
		else if (!itemCode.equals(other.itemCode)) {
			return false;
		}
		if (lowPointCount == null) {
			if (other.lowPointCount != null) {
				return false;
			}
		}
		else if (!lowPointCount.equals(other.lowPointCount)) {
			return false;
		}
		if (officeId == null) {
			if (other.officeId != null) {
				return false;
			}
		}
		else if (!officeId.equals(other.officeId)) {
			return false;
		}
		if (stationId == null) {
			if (other.stationId != null) {
				return false;
			}
		}
		else if (!stationId.equals(other.stationId)) {
			return false;
		}
		return true;
	}

	/**
	 * Gets the current count.
	 * 
	 * @return the currentCount
	 */
	public int getCurrentCount() {
		return currentCount.intValue();
	}

	/**
	 * Gets the item code.
	 * 
	 * @return the itemCode
	 */
	public String getItemCode() {
		return itemCode;
	}

	/**
	 * Gets the low point count.
	 * 
	 * @return the lowPointCount
	 */
	public int getLowPointCount() {
		return lowPointCount.intValue();
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}

	/**
	 * Gets the station id.
	 * 
	 * @return the stationId
	 */
	public String getStationId() {
		return stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((currentCount == null) ? 0 : currentCount.hashCode());
		result = prime * result
				+ ((itemCode == null) ? 0 : itemCode.hashCode());
		result = prime * result
				+ ((lowPointCount == null) ? 0 : lowPointCount.hashCode());
		result = prime * result
				+ ((officeId == null) ? 0 : officeId.hashCode());
		result = prime * result
				+ ((stationId == null) ? 0 : stationId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemLocation#isAssignedToStation()
	 */
	public boolean isAssignedToStation() {
		return getStationId() != null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.inventory.item.IItemThreshold#isForCode(java.lang.String)
	 */
	public boolean isForCode(String aCode) {
		return getItemCode().equals(aCode);
	}

	/**
	 * Sets the current count.
	 * 
	 * @param currentCount the currentCount to set
	 */
	protected void setCurrentCount(Integer currentCount) {
		this.currentCount = currentCount;
	}

	/**
	 * Sets the item code.
	 * 
	 * @param itemCode the itemCode to set
	 */
	protected void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * Sets the low point count.
	 * 
	 * @param lowPointCount the lowPointCount to set
	 */
	protected void setLowPointCount(Integer lowPointCount) {
		this.lowPointCount = lowPointCount;
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId the officeId to set
	 */
	protected void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * Sets the station id.
	 * 
	 * @param stationId the stationId to set
	 */
	protected void setStationId(String stationId) {
		this.stationId = stationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append(" office: ").append(officeId);
		aBuilder.append(" station: ").append(stationId);
		aBuilder.append(" itemCode: ").append(itemCode);
		aBuilder.append(" currentCount: ").append(currentCount);
		aBuilder.append(" lowPointCount: ").append(lowPointCount);
		aBuilder.append(" ]");
		return aBuilder.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: ItemThreshold.java,v $
 *  Revision 1.7  2011/09/23 22:00:33  mwkfh
 *  added changeToOffice
 *
 *  Revision 1.6  2010/10/15 20:33:58  mwkfh
 *  added protected default constructor
 *
 *  Revision 1.5  2010/10/05 22:27:27  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.4  2010/09/20 22:35:09  mwpxp2
 *  Added isForCode/1
 *
 *  Revision 1.3  2010/09/20 22:16:54  mwpxp2
 *  Added javadoc; added equals/1, hashCode/0
 *
 *  Revision 1.2  2010/09/20 22:15:19  mwpxp2
 *  Inherited from BusinessObject
 *
 *  Revision 1.1  2010/09/20 18:18:27  mwpxp2
 *  Initial
 *
 */
