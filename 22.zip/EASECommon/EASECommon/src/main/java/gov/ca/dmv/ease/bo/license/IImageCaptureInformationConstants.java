/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license;

/**
 * Description: //TODO - provide description!
 * File: IImageCaptureInformationConstants.java
 * Module:  gov.ca.dmv.ease.bo.license
 * Created: May 6, 2011 
 * @author MWRKA1  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2011/05/06 18:02:42 $
 * Last Changed By: $Author: mwrka1 $
 */
public interface IImageCaptureInformationConstants {
	/** The LOCK. */
	String LOCK = "L";
	/** The DONE. */
	String DONE = "D";
}
/**
 *  Modification History:
 *
 *  $Log: IImageCaptureInformationConstants.java,v $
 *  Revision 1.1  2011/05/06 18:02:42  mwrka1
 *  Fixed 890 validation rules
 *
 */
