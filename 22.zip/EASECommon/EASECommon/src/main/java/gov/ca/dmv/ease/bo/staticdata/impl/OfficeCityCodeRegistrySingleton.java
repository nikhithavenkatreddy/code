/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.staticdata.impl;

import gov.ca.dmv.ease.bo.staticdata.IOfficeCityCodeRegistrySingleton;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description: I am this and that
 * File: .java
 * Module:
 * Created: Jul 28, 2009
 * 
 * @author MWRRV3
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2011/04/18 20:55:07 $
 * Last Changed By: $Author: mwsxl7 $
 */
public class OfficeCityCodeRegistrySingleton implements
		IOfficeCityCodeRegistrySingleton {
	/** The office city codes singleton. */
	//	private static CodeSetRegistrySingleton CODESET_SINGLETON = null;
	/** The Constant DEFAULT_SIZE. */
	private static final int DEFAULT_SIZE = 32;
	/** The Constant NO_OFFICE_CITY_CODES. */
	private static final int NO_OFFICE_CITY_CODES = 0;
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8475464273480554556L;
	/** The code sets. */
	private Map <String, List <CityCodeDetail>> officeCityCodes;

	/**
	 * Instantiates a new office city code registry impl.
	 */
	private OfficeCityCodeRegistrySingleton() {
		officeCityCodes = new HashMap <String, List <CityCodeDetail>>();
	}

	/**
	 * Clean office city code.
	 * 
	 * @param cityCodeDetail the city code detail
	 */
	private void cleanOfficeCityCode(CityCodeDetail cityCodeDetail) {
		if (cityCodeDetail != null) {
			// Trim codeset name
			// Set CodeSet to CodeSetElement
			cityCodeDetail.setCityCode(cityCodeDetail.getCityCode().trim());
			// Trim CodeSetElement code
			cityCodeDetail
					.setCityName(cityCodeDetail.getCityName() != null ? cityCodeDetail
							.getCityName().trim()
							: null);
			// Trim CodeSetElement name
			cityCodeDetail
					.setCountyCode(cityCodeDetail.getCountyCode() != null ? cityCodeDetail
							.getCountyCode().trim()
							: null);
			// Trim CodeSetElement description
			cityCodeDetail
					.setZipCode(cityCodeDetail.getZipCode() != null ? cityCodeDetail
							.getZipCode().trim()
							: null);
		}
	}

	/**
	 * Gets the code sets.
	 * 
	 * @return the codeSets
	 */
	protected Map <String, List <CityCodeDetail>> getOfficeCityCodes() {
		if (officeCityCodes == null) {
			setOfficeCityCodes(new HashMap <String, List <CityCodeDetail>>(
					DEFAULT_SIZE));
		}
		return officeCityCodes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#isEmpty()
	 */
	public boolean isEmpty() {
		return officeCityCodes == null || officeCityCodes.isEmpty();
	}

	/**
	 * Reset.
	 */
	public void reset() {
		setOfficeCityCodes(null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.bo.code.ICodeSetRegistrySingleton#size()
	 */
	public int size() {
		if (isEmpty()) {
			return NO_OFFICE_CITY_CODES;
		}
		return officeCityCodes.size();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.IOfficeCityCodeRegistrySingleton#getOfficeCityCode(java.lang.String, java.lang.String)
	 */
	public CityCodeDetail getOfficeCityCode(String officeId, String cityCode) {
		List <CityCodeDetail> cityCodes = getOfficeCityCodes().get(officeId);
		if (cityCodes == null) {
			throw new EaseValidationException("No city codes for office: "
					+ officeId);
		}
		CityCodeDetail cityCodeDetail = getCityCodeDetail(cityCodes, cityCode);
		if (cityCodeDetail == null) {
			throw new EaseValidationException(
					"No office city code with office id : " + officeId
							+ " city code: " + cityCode);
		}
		else {
			return cityCodeDetail;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.ICodeSet#getElementWithCode(java.lang.String)
	 */
	/**
	 * Gets the city code detail.
	 * 
	 * @param cityCodes the city codes
	 * @param cityCode the city code
	 * 
	 * @return the city code detail
	 */
	public CityCodeDetail getCityCodeDetail(List <CityCodeDetail> cityCodes,
			String cityCode) {
		if (!EaseUtil.isNullOrBlank(cityCodes) && EaseUtil.isNotNull(cityCode)) {
			for (CityCodeDetail cityCodeElem : cityCodes) {
				if (cityCode.equals(cityCodeElem.getCityCode())) {
					return cityCodeElem;
				}
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.IOfficeCityCodeRegistrySingleton#register(gov.ca.dmv.ease.bo.code.impl.CityCodeDetail, java.lang.String)
	 */
	public void register(CityCodeDetail cityCodeDetail, String officeId) {
		cleanOfficeCityCode(cityCodeDetail);
		if (getOfficeCityCodes().containsKey(officeId)) {
			((ArrayList <CityCodeDetail>) getOfficeCityCodes().get(officeId))
					.add(cityCodeDetail);
		}
		else {
			List <CityCodeDetail> cityCodeList = new ArrayList <CityCodeDetail>();
			cityCodeList.add(cityCodeDetail);
			getOfficeCityCodes().put(officeId, cityCodeList);
		}
	}

	/**
	 * Sets the office city codes.
	 * 
	 * @param officeCityCodes the officeCityCodes to set
	 */
	public void setOfficeCityCodes(
			Map <String, List <CityCodeDetail>> officeCityCodes) {
		this.officeCityCodes = officeCityCodes;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.code.IOfficeCityCodeRegistrySingleton#getAllOfficeCityCodes()
	 */
	public Map <String, List <CityCodeDetail>> getAllOfficeCityCodes() {
		return getOfficeCityCodes();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: OfficeCityCodeRegistrySingleton.java,v $
 *  Revision 1.4  2011/04/18 20:55:07  mwsxl7
 *  fixed getCityCodeDetail to return element if found and added null checks - mwkfh
 *
 *  Revision 1.3  2011/04/18 16:50:21  mwkfh
 *  unobsoleted - referenced in xml
 *
 *  Revision 1.1  2011/04/18 16:48:28  mwkfh
 *  obsoleted - not used
 *
 *  Revision 1.1  2010/10/08 20:52:31  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 */
