/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.impl;

import gov.ca.dmv.ease.app.constants.ICommonErrorMessageConstants;
import gov.ca.dmv.ease.bo.sequence.ISequenceConstants;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequencePatternException;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: I am implementation of ISequencePattern
 * File: SequencePattern.java
 * Module:  gov.ca.dmv.ease.bo.sequence.impl
 * Created: Sep 3, 2010
 * 
 * @author MWPXP2
 * @version $Revision: 1.12 $
 * Last Changed: $Date: 2011/01/17 18:45:22 $
 * Last Changed By: $Author: mwkfh $
 */
public class SequencePattern implements ISequencePattern {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2005874669814881976L;
	/** The description. */
	private String description;
	/** The lower sequence boundary. */
	private String lowerSequenceBoundary;
	/** The upper sequence boundary. */
	private String upperSequenceBoundary;
	/** The value. */
	private String value;

	/**
	 * Instantiates a new sequence pattern.
	 */
	protected SequencePattern() {
		super();
	}

	/**
	 * Instantiates a new sequence pattern.
	 * 
	 * @param aValue the a value
	 */
	protected SequencePattern(String aValue) {
		super();
		setValue(aValue);
	}

	/**
	 * Instantiates a new sequence pattern.
	 * 
	 * @param aDesc the a desc
	 * @param aPatternValue the a pattern value
	 * @param aSeqStart the a seq start
	 * @param aSeqEnd the a seq end
	 */
	public SequencePattern(String aDesc, String aPatternValue,
			String aSeqStart, String aSeqEnd) {
		super();
		setDescription(aDesc);
		setValue(aPatternValue);
		setLowerSequenceBoundary(Sequence.addTrimmedSpaces(aSeqStart,
				aPatternValue));
		setUpperSequenceBoundary(Sequence.addTrimmedSpaces(aSeqEnd,
				aPatternValue));
		validate();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SequencePattern other = (SequencePattern) obj;
		if (description == null) {
			if (other.description != null) {
				return false;
			}
		}
		else if (!description.equals(other.description)) {
			return false;
		}
		if (lowerSequenceBoundary == null) {
			if (other.lowerSequenceBoundary != null) {
				return false;
			}
		}
		else if (!lowerSequenceBoundary.equals(other.lowerSequenceBoundary)) {
			return false;
		}
		if (upperSequenceBoundary == null) {
			if (other.upperSequenceBoundary != null) {
				return false;
			}
		}
		else if (!upperSequenceBoundary.equals(other.upperSequenceBoundary)) {
			return false;
		}
		if (value == null) {
			if (other.value != null) {
				return false;
			}
		}
		else if (!value.equals(other.value)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePattern#getDescription()
	 */
	public String getDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePattern#getLowerSequenceBoundary()
	 */
	public String getLowerSequenceBoundary() {
		return lowerSequenceBoundary;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePattern#getSize()
	 */
	public int getSize() {
		if (value == null) {
			return 0;
		}
		else {
			return value.length();
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePattern#getUpperSequenceBoundary()
	 */
	public String getUpperSequenceBoundary() {
		return upperSequenceBoundary;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequencePattern#getValue()
	 */
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime
				* result
				+ ((lowerSequenceBoundary == null) ? 0 : lowerSequenceBoundary
						.hashCode());
		result = prime
				* result
				+ ((upperSequenceBoundary == null) ? 0 : upperSequenceBoundary
						.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	/**
	 * Sets the description.
	 * 
	 * @param description the new description
	 */
	protected void setDescription(String description) {
		this.description = description;
	}

	protected void setLowerSequenceBoundary(String lowerSequenceBoundary) {
		this.lowerSequenceBoundary = lowerSequenceBoundary;
	}

	protected void setUpperSequenceBoundary(String upperSequenceBoundary) {
		this.upperSequenceBoundary = upperSequenceBoundary;
	}

	/**
	 * Sets the value.
	 * 
	 * @param aValue the a value
	 */
	protected void setValue(String aValue) {
		value = aValue;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder aBuilder = new StringBuilder(32);
		aBuilder.append(getClass().getSimpleName()).append(" [ ");
		aBuilder.append('"').append(getValue()).append("\", ");
		aBuilder.append('"').append(getLowerSequenceBoundary()).append("\", ");
		aBuilder.append('"').append(getUpperSequenceBoundary()).append("\", ");
		aBuilder.append('"').append(getDescription()).append("\"]");
		return aBuilder.toString();
	}

	/**
	 * Validates pattern
	 */
	private void validate() {
		validatePatternLength();
		validatePatternValues();
		validateBoundaryLength();
		validateBoundaryRange();
		validateBoundaryOrder();
	}

	/**
	 * Validates pattern length
	 */
	private void validatePatternLength() {
		//valid pattern size
		if (ISequenceConstants.PATTERN_SIZE != value.length()) {
			throw new SequencePatternException(
					ICommonErrorMessageConstants.PATTERN_NOT_CORRECT_SIZE);
		}
	}

	/**
	 * Validates pattern values
	 */
	private void validatePatternValues() {
		//valid chars in pattern
		boolean isValidPatternValue;
		for (char patternChar : value.toCharArray()) {
			isValidPatternValue = false;
			for (char validChar : ISequenceConstants.VALID_PATTERN_VALUES) {
				if (validChar == patternChar) {
					isValidPatternValue = true;
					break;
				}
			}
			if (!isValidPatternValue) {
				throw new SequencePatternException(
						ICommonErrorMessageConstants.INVALID_CHARS_IN_PATTERN);
			}
		}
	}

	/**
	 * Validates pattern & boundary lengths
	 */
	private void validateBoundaryLength() {
		//boundaries same length as pattern
		if ((lowerSequenceBoundary == null)
				|| (upperSequenceBoundary == null)
				|| (value.length() != lowerSequenceBoundary.length())
				|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && (value
						.length() != upperSequenceBoundary.length()))) {
			throw new SequencePatternException(
					ICommonErrorMessageConstants.PATTERN_AND_BOUNDARY_LENGTHS_NOT_MATCH);
		}
	}

	/**
	 * Validates boundary range
	 */
	private void validateBoundaryRange() {
		//valid chars in boundaries
		for (int index = 0; index < value.length(); index++) {
			if (ISequenceConstants.ALPHA == value.charAt(index)) {
				//A - Z
				if (lowerSequenceBoundary.charAt(index) < ISequenceConstants.MIN_ALPHA
						|| lowerSequenceBoundary.charAt(index) > ISequenceConstants.MAX_ALPHA
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && upperSequenceBoundary
								.charAt(index) < ISequenceConstants.MIN_ALPHA)
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && upperSequenceBoundary
								.charAt(index) > ISequenceConstants.MAX_ALPHA)) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.BOUNDARY_OUTSIDE_OF_RANGE);
				}
			}
			else if (ISequenceConstants.INCREMENTING_DIGIT == value
					.charAt(index)) {
				//0 - 9
				if (lowerSequenceBoundary.charAt(index) < ISequenceConstants.MIN_DIGIT
						|| lowerSequenceBoundary.charAt(index) > ISequenceConstants.MAX_DIGIT
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && upperSequenceBoundary
								.charAt(index) < ISequenceConstants.MIN_DIGIT)
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && upperSequenceBoundary
								.charAt(index) > ISequenceConstants.MAX_DIGIT)) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.BOUNDARY_OUTSIDE_OF_RANGE);
				}
			}
			else if (ISequenceConstants.FIXED_DIGIT == value.charAt(index)) {
				//0 - 9 or A - Z
				if (!((lowerSequenceBoundary.charAt(index) >= ISequenceConstants.MIN_DIGIT && lowerSequenceBoundary
						.charAt(index) <= ISequenceConstants.MAX_DIGIT) || (lowerSequenceBoundary
						.charAt(index) >= ISequenceConstants.MIN_ALPHA && lowerSequenceBoundary
						.charAt(index) <= ISequenceConstants.MAX_ALPHA))
						&& ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && !((upperSequenceBoundary
								.charAt(index) >= ISequenceConstants.MIN_DIGIT && upperSequenceBoundary
								.charAt(index) <= ISequenceConstants.MAX_DIGIT) || (upperSequenceBoundary
								.charAt(index) >= ISequenceConstants.MIN_ALPHA && upperSequenceBoundary
								.charAt(index) <= ISequenceConstants.MAX_ALPHA)))) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.BOUNDARY_OUTSIDE_OF_RANGE);
				}
			}
			else if (ISequenceConstants.SPACE_FILLER == value.charAt(index)) {
				//SPACE
				if (lowerSequenceBoundary.charAt(index) != ISequenceConstants.SPACE
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && upperSequenceBoundary
								.charAt(index) != ISequenceConstants.SPACE)) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.EXPECTED_SPACE_IN_BOUNDARY);
				}
			}
			else if (ISequenceConstants.INCREMENTING_DIGIT_WITH_LEADING_SPACE == value
					.charAt(index)) {
				//SPACE or 0 - 9
				if (((lowerSequenceBoundary.charAt(index) < ISequenceConstants.MIN_DIGIT || lowerSequenceBoundary
						.charAt(index) > ISequenceConstants.MAX_DIGIT) && (lowerSequenceBoundary
						.charAt(index) != ISequenceConstants.SPACE))
						|| ((!EaseUtil.isNullOrBlank(upperSequenceBoundary)) && ((upperSequenceBoundary
								.charAt(index) < ISequenceConstants.MIN_DIGIT || upperSequenceBoundary
								.charAt(index) > ISequenceConstants.MAX_DIGIT) && (upperSequenceBoundary
								.charAt(index) != ISequenceConstants.SPACE)))) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.BOUNDARY_OUTSIDE_OF_RANGE);
				}
			}
			//TODO: add validation for other types of values when necessary
		}
	}

	/**
	 * Validates boundary order
	 */
	private void validateBoundaryOrder() {
		//upper boundary > lower boundary
		if (!EaseUtil.isNullOrBlank(upperSequenceBoundary)) {
			for (int index = 0; index < value.length(); index++) {
				if (lowerSequenceBoundary.charAt(index) > upperSequenceBoundary
						.charAt(index)) {
					throw new SequencePatternException(
							ICommonErrorMessageConstants.BOUNDARIES_OUT_OF_ORDER);
				}
				else if (lowerSequenceBoundary.charAt(index) < upperSequenceBoundary
						.charAt(index)) {
					break;
				}
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequencePattern.java,v $
 *  Revision 1.12  2011/01/17 18:45:22  mwkfh
 *  added null check to validateBoundaryLength
 *
 *  Revision 1.11  2010/12/31 23:27:36  mwkfh
 *  removed addTrimmedSpaces
 *
 *  Revision 1.10  2010/12/23 06:18:22  mwkkc
 *  Merged Production code from Branch
 *
 *  Revision 1.8.4.1  2010/12/23 03:13:54  mwkkc
 *  Rebase from head - Common
 *
 *  Revision 1.9  2010/12/20 19:14:23  mwkfh
 *  refactored addTrimmedSpaces
 *
 *  Revision 1.8  2010/12/14 22:05:51  mwkfh
 *  updated validateBoundaryRange for fixed digit
 *
 *  Revision 1.7  2010/11/03 15:05:40  mwkfh
 *  updated SPACE_FILLER in validateBoundaryRange
 *
 *  Revision 1.6  2010/10/29 17:26:53  mwkfh
 *  added method addTrimmedSpaces
 *
 *  Revision 1.5  2010/10/22 16:17:55  mwkfh
 *  added validate called on construction
 *
 *  Revision 1.4  2010/09/11 00:27:51  mwpxp2
 *  Modified toString/0 to quote string values
 *
 *  Revision 1.3  2010/09/08 00:04:23  mwpxp2
 *  Added equals/0, hashCode/0; unit tested ok
 *
 *  Revision 1.2  2010/09/07 22:59:21  mwpxp2
 *  Adjusted per interface mods; added toString/0
 *
 *  Revision 1.1  2010/09/04 05:53:51  mwpxp2
 *  Initial, in progress
 *
 */
