/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.citation.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;

import java.io.Serializable;

/**
 * Description: This class is used to capture information of the violation. 
 * File: SectionViolated.java
 * Module:  gov.ca.dmv.ease.bo.application.impl
 * Created: Apr 22, 2010 
 * @author MWVXM6  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2012/09/05 18:20:14 $
 * Last Changed By: $Author: mwhys $
 */
public class SectionViolated implements Serializable {
	/** The serialVersionUID */
	private static final long serialVersionUID = -4817603927592635738L;
	/** The field is set to D to indicate Dismissed. */
	private CodeSetElement dismissedCode;
	/** The 6 position Section Violated Number. */
	private String sectionViolatedNumber;
	/** The Section Violated Code. */
	private CodeSetElement statuteCode;

	/**
	 * @return the dismissedCode
	 */
	public CodeSetElement getDismissedCode() {
		return dismissedCode;
	}

	/**
	 * @return the sectionViolatedNumber
	 */
	public String getSectionViolatedNumber() {
		return sectionViolatedNumber;
	}

	/**
	 * @return the statuteCode
	 */
	public CodeSetElement getStatuteCode() {
		return statuteCode;
	}

	/**
	 * @param dismissedCode the dismissedCode to set
	 */
	public void setDismissedCode(CodeSetElement dismissedCode) {
		this.dismissedCode = dismissedCode;
	}

	/**
	 * @param sectionViolatedNumber the sectionViolatedNumber to set
	 */
	public void setSectionViolatedNumber(String sectionViolatedNumber) {
		this.sectionViolatedNumber = sectionViolatedNumber;
	}

	/**
	 * @param statuteCode the statuteCode to set
	 */
	public void setStatuteCode(CodeSetElement statuteCode) {
		this.statuteCode = statuteCode;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SectionViolated.java,v $
 *  Revision 1.4  2012/09/05 18:20:14  mwhys
 *  implements Serializable. (Defect 7189)
 *
 *  Revision 1.3.22.1  2010/12/19 21:11:10  mwhys
 *   implements Serializable.
 *
 *
 */
