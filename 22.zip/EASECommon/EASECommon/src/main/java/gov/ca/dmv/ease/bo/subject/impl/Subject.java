/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.subject.impl;

import gov.ca.dmv.ease.bo.impl.BaseBusinessObject;
import gov.ca.dmv.ease.bo.locator.AddressType;
import gov.ca.dmv.ease.bo.locator.NonAddressType;
import gov.ca.dmv.ease.bo.locator.impl.Address;
import gov.ca.dmv.ease.bo.locator.impl.Locator;
import gov.ca.dmv.ease.bo.locator.impl.NonAddressLocator;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: Subject is a common representation for entities that can be
 * subject to DMV transactions that is, which can be owners or be granted
 * a License of some kind.
 * File: Subject.java
 * Module:  gov.ca.dmv.ease.bo.subject.impl
 * Created: Apr 28, 2009
 * @author MWRRV3
 * @version $Revision: 1.16 $
 * Last Changed: $Date: 2011/04/11 18:23:50 $
 * Last Changed By: $Author: mwkfh $
 */
public abstract class Subject extends BaseBusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8705748261579427070L;
	/** The effective end date. */
	private Date effectiveEndDate;
	/** The effective start date. */
	private Date effectiveStartDate;
	/** The existing locator. Holds the existing locators present on the existing driver record. */
	private List <Locator> existingLocators = new ArrayList <Locator>();
	/** The locator. Holds the new locators. */
	private List <Locator> locators = new ArrayList <Locator>();

	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	protected void copy(Subject dataToCopy) {
		super.copy(dataToCopy);
		if (EaseUtil.isNotNull(dataToCopy.getEffectiveEndDate())) {
			setEffectiveEndDate(new Date(dataToCopy.getEffectiveEndDate()
					.getTime()));
		}
		else {
			setEffectiveEndDate(null);
		}
		if (EaseUtil.isNotNull(dataToCopy.getEffectiveStartDate())) {
			setEffectiveStartDate(new Date(dataToCopy.getEffectiveStartDate()
					.getTime()));
		}
		else {
			setEffectiveStartDate(null);
		}
		copyLocators(dataToCopy.getLocators());
		copyExistingLocators(dataToCopy.getExistingLocators());
	}

	/**
	 * Copy existing locators.
	 *
	 * @param existingLocatorsToCopy the existing locators to copy
	 */
	private void copyExistingLocators(List <Locator> existingLocatorsToCopy) {
		if (EaseUtil.isNotNull(existingLocatorsToCopy)) {
			for (Locator locatorToCopy : existingLocatorsToCopy) {
				if (!EaseUtil.isNullOrBlank(locatorToCopy)) {
					if (locatorToCopy instanceof Address) {
						addExistingAddress(new Address((Address) locatorToCopy));
					}
					else if (locatorToCopy instanceof NonAddressLocator) {
						addNonAddressLocator(new NonAddressLocator(
								(NonAddressLocator) locatorToCopy));
					}
				}
			}
		}
	}

	/**
	 * Copy locators.
	 *
	 * @param locatorsToCopy the locators to copy
	 */
	private void copyLocators(List <Locator> locatorsToCopy) {
		if (EaseUtil.isNotNull(locatorsToCopy)) {
			for (Locator locatorToCopy : locatorsToCopy) {
				if (!EaseUtil.isNullOrBlank(locatorToCopy)) {
					if (locatorToCopy instanceof Address) {
						addAddress(new Address((Address) locatorToCopy));
					}
					else if (locatorToCopy instanceof NonAddressLocator) {
						addNonAddressLocator(new NonAddressLocator(
								(NonAddressLocator) locatorToCopy));
					}
				}
			}
		}
	}

	/**
	 * This method adds the address to an address list of new addresses.
	 * 
	 * Note: If the address type of the address being passed already exists, it
	 * replaces the existing address with the address being passed.
	 *  
	 * @param address the address
	 */
	public void addAddress(Address address) {
		addAddress(address, true);
	}

	/**
	 * This method adds the address or non address locator to an existing locator list.
	 * If ReplaceIfExists is true, then if an Address of the same Address Type exists,
	 * it over-writes the existing Address.
	 * If ReplaceIfExists is false, then Address is added to Address List.
	 * 
	 * NOTE - If ReplaceIfExists is false, there is possibility of having more than
	 * one Address of a AddressType e.g. 2 Residential Addresses
	 *
	 * @param addressToAdd the address to add
	 * @param replaceIfExists If true would replace the existing address or non address based on type of Locator.
	 */
	private void addAddress(Locator addressToAdd, boolean replaceIfExists) {
		if (EaseUtil.isNotNull(this.getLocators())) {
			//Over existing Address of this Address Type, if any Exists
			if (replaceIfExists && this.getLocators().size() > 0) {
				//Indicator for checking if Address of this Address Type Exists
				boolean addressTypeFound = false;
				//Iterate through the Locators
				for (int index = 0; index < this.getLocators().size(); index++) {
					Locator locator = this.getLocators().get(index);
					//Check for Instance of Address
					if (locator instanceof Address
							&& addressToAdd instanceof Address) {
						Address existingAddress = (Address) locator;
						//Check if an Address of that Address Type exists
						if (((Address) addressToAdd).getAddressType().equals(
								existingAddress.getAddressType())) {
							//Remove the Existing Address
							this.getLocators().remove(index);
							//Add the new Address
							this.getLocators().add(index, addressToAdd);
							//Over-write Indicator
							addressTypeFound = true;
							//break
							break;
						}
					}
					//Check for Instance of Non Address Locator
					if (locator instanceof NonAddressLocator
							&& addressToAdd instanceof NonAddressLocator) {
						NonAddressLocator existingNonAddress = (NonAddressLocator) locator;
						//Check if a NonAddressLocator of that Type exists
						if (((NonAddressLocator) addressToAdd)
								.getContactMethodType().equals(
										existingNonAddress
												.getContactMethodType())) {
							//Remove the Existing Non Address Locator.
							this.getLocators().remove(index);
							//Add the new Non Address Locator.
							this.getLocators().add(index, addressToAdd);
							//Over-write Indicator
							addressTypeFound = true;
							//break
							break;
						}
					}
				}
				//If not over-write then Add to the Locator List
				if (!addressTypeFound) {
					if (addressToAdd instanceof Address) {
						//Add the Address to the Locators
						this.getLocators().add(addressToAdd);
					}
					else if (addressToAdd instanceof NonAddressLocator) {
						//Add the Non Address locator to the Locators
						this.getLocators().add(addressToAdd);
					}
				}
			}
			else {
				//Do not over-write the Address of this Address Type, if it Exists
				//Instead Add the Address to the Locators
				if (addressToAdd instanceof Address) {
					//Add the Address to the Locators
					this.getLocators().add(addressToAdd);
				}
				else if (addressToAdd instanceof NonAddressLocator) {
					//Add the Non Address locator to the Locators
					this.getLocators().add(addressToAdd);
				}
			}
		}
	}

	/**
	 * This method adds the address to an address list of previous/old addresses of an existing driver record.
	 * Note - This method will be use only once to set a previous address of an existing driver record in the search person by number converter.
	 * If Address of the same address type already exists do not add any address.
	 *
	 * @param address the address
	 */
	public void addExistingAddress(Address address) {
		if (EaseUtil.isNotNull(this.getExistingLocators())) {
			if (this.getExistingLocators().size() > 0) {
				//Iterate through Existing Locators
				for (Locator existingLocator : this.getExistingLocators()) {
					if (existingLocator instanceof Address) {
						Address existingAddress = (Address) existingLocator;
						//Check if Address of that Address Type already exists
						if (existingAddress.getAddressType().equals(
								address.getAddressType())) {
							//Do not add address if address of the same address type is already exist
							return;
						}
					}
				}
				//Address of the same address type does not exist, so add the address to existing locators 
				this.getExistingLocators().add(address);
			}
			else {
				//Existing Locators does not contain any address so add address to the list. 
				this.getExistingLocators().add(address);
			}
		}
	}

	/**
	 * This method adds the non address locator to an non address locator list of new addresses.
	 * 
	 * Note: If the non address type of the non address locator being passed already exists, it
	 * replaces the existing non address with the non address locator being passed.
	 *  
	 * @param nonAddressLocator the address
	 */
	public void addNonAddressLocator(NonAddressLocator nonAddressLocator) {
		addAddress(nonAddressLocator, true);
	}

	/**
	 * Get the organization address.
	 * 
	 * @return Address
	 */
	public Address getAddress() {
		Address address = null;
		List <Locator> locators = getLocators();
		for (Locator locator : locators) {
			if (locator instanceof Address) {
				address = (Address) locator;
				break;
			}
		}
		return address;
	}

	/**
	 * This method returns an Address from the Locators.
	 * Note - If single Address exists for an AddressType, it returns the Address.
	 * In case if more than one Address Exists for an Address Type,
	 * it returns the first Address for the input Address Type.
	 *
	 * @param addressType the address type
	 * @return Address for an input AddressType
	 */
	public Address getAddress(AddressType addressType) {
		Address address = null;
		//Check if Locator is not null and not empty
		if (!EaseUtil.isNullOrBlank(this.getLocators())) {
			//Iterate through the Locators
			for (Locator locator : this.getLocators()) {
				//Check if Locator is instance of Address
				if (locator instanceof Address) {
					//Check if the Address Type Matches
					if (((Address) locator).getAddressType()
							.equals(addressType)) {
						//Match found, return the Address
						address = (Address) locator;
						//Break
						break;
					}
				}
			}
		}
		return address;
	}

	/**
	 * This method returns Addresses.
	 * Note - In case if more than one Address Exists for an Address Type,
	 * it returns all the Addresses of input Address Type.
	 *
	 * @param addressType the address type
	 * @return list of Address for an input AddressType
	 */
	//TODO Remove this method if not required. There should be only one address exist for a given address type. 
	public List <Address> getAddresses(AddressType addressType) {
		List <Address> addresses = new ArrayList <Address>();
		if (!EaseUtil.isNullOrBlank(this.getLocators())) {
			for (Locator locator : this.getLocators()) {
				if (locator instanceof Address) {
					if (((Address) locator).getAddressType()
							.equals(addressType)) {
						addresses.add((Address) locator);
					}
				}
			}
		}
		return addresses;
	}

	/**
	 * Gets the effective end date.
	 * 
	 * @return the effectiveEndDate
	 */
	public Date getEffectiveEndDate() {
		return effectiveEndDate;
	}

	/**
	 * Gets the effective start date.
	 * 
	 * @return the effectiveStartDate
	 */
	public Date getEffectiveStartDate() {
		return effectiveStartDate;
	}

	/**
	 * This method returns an Address from the Existing Locators.
	 *
	 * @param addressType the address type
	 * @return Address for an input AddressType
	 */
	public Address getExistingAddress(AddressType addressType) {
		Address address = null;
		//Check if Existing Locator is not null and not empty
		if (!EaseUtil.isNullOrBlank(this.getExistingLocators())) {
			//Iterate through the Locators
			for (Locator existingLocator : this.getExistingLocators()) {
				//Check if existingLocator is instance of Address
				if (existingLocator instanceof Address) {
					//Check if the Address Type Matches
					if (((Address) existingLocator).getAddressType().equals(
							addressType)) {
						//Match found, return the Address
						address = (Address) existingLocator;
						//Break
						break;
					}
				}
			}
		}
		return address;
	}

	/**
	 * Gets the effective date of Existing Address.
	 *
	 * @param addressType the address type
	 * @return the address effective date
	 */
	public Date getExistingAddressEffectiveDate(AddressType addressType) {
		if (!EaseUtil.isNullOrBlank(this.getExistingAddress(addressType))) {
			return getExistingAddress(addressType).getEffectiveDate();
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the existing locators.
	 *
	 * @return the existingLocators
	 */
	public List <Locator> getExistingLocators() {
		return existingLocators;
	}

	/**
	 * Get the phone number in the (xxx) format.
	 * 
	 * @return the phone number
	 */
	public String getFormattedPhoneAreaCode() {
		String areaCode = getPhoneAreaCode();
		return (EaseUtil.isNotBlank(areaCode) ? "(" + areaCode + ")" : areaCode);
	}

	/**
	 * Get the phone number in the xxx-xxxx format.
	 * 
	 * @return the phone number
	 */
	public String getFormattedPhoneNumber() {
		String formattedSubscriberNumber = "";
		String subscriberNumber = getSubscriberNumber();
		if (subscriberNumber != null && subscriberNumber.length() == 10) {
			String number1 = subscriberNumber.substring(3, 6);
			String number2 = subscriberNumber.substring(6);
			formattedSubscriberNumber = number1 + "-" + number2;
		}
		return formattedSubscriberNumber;
	}

	/**
	 * Gets the Locator.
	 * 
	 * @return the locator
	 */
	public List <Locator> getLocators() {
		return locators;
	}

	/**
	 * Gets the effective date of New Address.
	 *
	 * @param addressType the address type
	 * @return the address effective date
	 */
	public Date getNewAddressEffectiveDate(AddressType addressType) {
		if (!EaseUtil.isNullOrBlank(this.getAddress(addressType))) {
			return getAddress(addressType).getEffectiveDate();
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the non address locator.
	 * 
	 * @param nonAddressType the non address type
	 * 
	 * @return the non address locator
	 */
	public NonAddressLocator getNonAddressLocator(NonAddressType nonAddressType) {
		NonAddressLocator nonAddressLocator = null;
		//Check if Locator is not null and not empty
		if (!EaseUtil.isNullOrBlank(this.getLocators())) {
			//Iterate through the Locators
			for (Locator locator : this.getLocators()) {
				//Check if Locator is instance of Address
				if (locator instanceof NonAddressLocator) {
					//Check if the Address Type Matches
					if (((NonAddressLocator) locator).getContactMethodType()
							.equals(nonAddressType)) {
						//Match found, return the Address
						nonAddressLocator = (NonAddressLocator) locator;
						//Break
						break;
					}
				}
			}
		}
		return nonAddressLocator;
	}

	/**
	 * Gets the non address type.
	 * 
	 * @param nonAddressType the non address type
	 * 
	 * @return the non address type
	 */
	public String getNonAddressType(NonAddressType nonAddressType) {
		String phoneNumber = null;
		if (!EaseUtil.isNullOrBlank(this.getLocators())) {
			for (Locator locator : this.getLocators()) {
				if (locator instanceof NonAddressLocator) {
					NonAddressLocator nonAddressLocator = (NonAddressLocator) locator;
					if (nonAddressLocator.getContactMethodType() == nonAddressType) {
						phoneNumber = nonAddressLocator.getContact();
						break;
					}
				}
			}
		}
		return phoneNumber;
	}

	/**
	 * Get the phone number in the xxx format.
	 * 
	 * @return the phone number
	 */
	public String getPhoneAreaCode() {
		String areaCode = "";
		List <Locator> locators = getLocators();
		for (Locator locator : locators) {
			if (locator instanceof NonAddressLocator) {
				NonAddressLocator nonAddressLocator = (NonAddressLocator) locator;
				if (nonAddressLocator.getContactMethodType().equals(
						NonAddressType.HOME_PHONE)) {
					String phoneNumber = nonAddressLocator.getContact();
					if (phoneNumber != null && phoneNumber.length() > 3) {
						areaCode = phoneNumber.substring(0, 3);
					}
					break;
				}
			}
		}
		return areaCode;
	}

	/**
	 * Get the subscriber number in the xxxxxxx format.
	 * 
	 * @return the phone number
	 */
	public String getSubscriberNumber() {
		String subscriberNumber = "";
		List <Locator> locators = getLocators();
		for (Locator locator : locators) {
			if (locator instanceof NonAddressLocator) {
				NonAddressLocator nonAddressLocator = (NonAddressLocator) locator;
				if (nonAddressLocator.getContactMethodType().equals(
						NonAddressType.HOME_PHONE)) {
					subscriberNumber = nonAddressLocator.getContact();
					break;
				}
			}
		}
		return subscriberNumber;
	}

	/**
	 * Get the phone's subscriber number prefix.
	 * 
	 * @return the phone's subscriber number prefix
	 */
	public String getSubscriberNumberPrefix() {
		String subscriberNumberPrefix = "";
		String subscriberNumber = getSubscriberNumber();
		if (subscriberNumber != null && subscriberNumber.length() == 10) {
			subscriberNumberPrefix = subscriberNumber.substring(3, 6);
		}
		return subscriberNumberPrefix;
	}

	/**
	 * Get the phone's subscriber number suffix.
	 * 
	 * @return the phone's subscriber number suffix
	 */
	public String getSubscriberNumberSuffix() {
		String subscriberNumberSuffix = "";
		String subscriberNumber = getSubscriberNumber();
		if (subscriberNumber != null && subscriberNumber.length() == 10) {
			subscriberNumberSuffix = subscriberNumber.substring(6);
		}
		return subscriberNumberSuffix;
	}

	/**
	 * Sets the effective end date.
	 * 
	 * @param effectiveEndDate the effectiveEndDate to set
	 */
	public void setEffectiveEndDate(Date effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	/**
	 * Sets the effective start date.
	 * 
	 * @param effectiveStartDate the effectiveStartDate to set
	 */
	public void setEffectiveStartDate(Date effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#toStringOn(java.lang.StringBuilder, int)
	 */
	@Override
	public void toStringOn(StringBuilder aBuilder, int anIndent) {
		outputKeyValue("effectiveEndDate", effectiveEndDate, anIndent, aBuilder);
		outputKeyValue("effectiveStartDate", effectiveStartDate, anIndent,
				aBuilder);
		outputKeyValue("existingLocators", existingLocators, anIndent, aBuilder);
		outputKeyValue("locators", locators, anIndent, aBuilder);
		super.toStringOn(aBuilder, anIndent);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((effectiveEndDate == null) ? 0 : effectiveEndDate.hashCode());
		result = prime
				* result
				+ ((effectiveStartDate == null) ? 0 : effectiveStartDate
						.hashCode());
		result = prime
				* result
				+ ((existingLocators == null) ? 0 : existingLocators.hashCode());
		result = prime * result
				+ ((locators == null) ? 0 : locators.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subject other = (Subject) obj;
		if (effectiveEndDate == null) {
			if (other.effectiveEndDate != null)
				return false;
		}
		else if (!effectiveEndDate.equals(other.effectiveEndDate))
			return false;
		if (effectiveStartDate == null) {
			if (other.effectiveStartDate != null)
				return false;
		}
		else if (!effectiveStartDate.equals(other.effectiveStartDate))
			return false;
		if (existingLocators == null) {
			if (other.existingLocators != null)
				return false;
		}
		else if (!existingLocators.equals(other.existingLocators))
			return false;
		if (locators == null) {
			if (other.locators != null)
				return false;
		}
		else if (!locators.equals(other.locators))
			return false;
		return true;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: Subject.java,v $
 *  Revision 1.16  2011/04/11 18:23:50  mwkfh
 *  fixed bug in addAddress
 *
 *  Revision 1.15  2011/04/07 04:04:55  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.14.18.1  2011/04/02 20:50:20  mwhys
 *  (1) Regenerated hashCode() and equals() methods.
 *  (2) Updated copy method.
 *
 *  Revision 1.14  2010/12/07 22:11:39  mwpxp2
 *  Implemented ITreePrintable
 *
 *  Revision 1.13  2010/12/07 03:57:52  mwpxp2
 *  Added toStringOn/1
 *
 *  Revision 1.12  2010/12/02 00:15:47  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.11  2010/07/22 17:50:29  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.10  2010/06/21 23:01:01  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.6.8.2  2010/06/20 18:07:11  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.9  2010/06/16 17:06:41  mwrsk
 *  added getSubscriberNumberSuffix() & getSubscriberNumberPrefix()
 *
 *  Revision 1.8  2010/06/16 16:44:59  mwrsk
 *  Added getPhoneNumber() and getAreaCode()
 *
 *  Revision 1.7  2010/06/03 17:13:09  mwvxm6
 *  Moved NonAddressLocator methods to Subject
 *
 *  Revision 1.6  2010/05/03 18:32:38  mwuxb
 *  Added helper methods for Non Address Locator
 *
 *  Revision 1.5  2010/04/29 17:08:25  mwvxm6
 *  Comments and code cleanup
 *
 *  Revision 1.4  2010/04/22 00:15:03  mwuxb
 *  Updated helper methods for effective date.
 *
 *  Revision 1.3  2010/04/21 22:38:09  mwuxb
 *  Updated effective date Helper method
 *
 *  Revision 1.2  2010/04/21 21:36:37  mwuxb
 *  Added Helper method
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.21  2010/04/15 01:14:25  mwuxb
 *  Removed Add Phone Number method
 *
 *  Revision 1.20  2010/04/15 01:08:36  mwuxb
 *  Added Helper Method for non address type
 *
 *  Revision 1.19  2010/03/31 21:13:16  mwuxb
 *  Updates for adding existing address
 *
 *  Revision 1.18  2010/03/30 00:54:02  mwuxb
 *  Added existing Locators to hold previous address information.
 *
 *  Revision 1.17  2010/03/24 22:06:08  mwtjc1
 *  logic of addAddress method is changed
 *
 *  Revision 1.16  2010/02/23 22:52:19  mwvxm6
 *  Removed hibernate annotation from BO's. Will now use hbm xml mapping files
 *
 *  Revision 1.15  2010/02/18 23:32:24  mwrsk
 *  changed addAddress(Address address, boolean replaceIfExists) to private
 *
 *  Revision 1.14  2010/02/18 22:06:39  mwrsk
 *  added addAddress(Address address)
 *
 *  Revision 1.13  2010/02/18 18:35:07  mwhxa2
 *  Modified addAddress()
 *
 *  Revision 1.12  2010/02/16 21:29:06  mwhxa2
 *  Removing Prior Locator as its not required
 *
 *  Revision 1.11  2010/02/12 00:26:08  mwrsk
 *  Changed addressTypeCode to addressType
 *
 *  Revision 1.10  2010/02/12 00:18:49  mwrsk
 *  Changed adding address to subject
 *
 *  Revision 1.9  2010/01/29 19:31:29  mwhxa2
 *  Added getPhoneNumbers() and getAddresses()
 *
 *  Revision 1.8  2010/01/28 22:48:46  mwhxa2
 *  Updated Java Docs
 *
 *  Revision 1.7  2010/01/13 22:24:19  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.6  2010/01/12 02:47:11  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.5  2010/01/06 00:29:06  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.4  2010/01/06 00:01:55  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.3  2010/01/05 03:01:42  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.2  2010/01/04 18:29:08  mwvxm6
 *  BO Refactoring. List Variabe renaming. Attribute type changes from prmitive to Objects. Spring DI to replace news in constructors. Dummy Helper class methods in place of BO logic.
 *
 *  Revision 1.1  2009/11/23 16:25:13  mwrsk
 *  Intial commit
 *
 *  Revision 1.14  2009/09/29 02:20:02  mwhxa2
 *  Extends BaseBusinessObject
 *
 *  Revision 1.13  2009/09/09 21:29:04  mwsmg6
 *  cleanup
 *
 *  Revision 1.12  2009/09/02 15:55:26  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.11  2009/09/02 15:43:42  mwsmg6
 *  removal of CodeSetElements from the business tier
 *
 *  Revision 1.10  2009/08/27 05:39:48  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.9  2009/08/22 23:21:47  mwrrv3
 *  Implemented equals and hashCode methods.
 *
 *  Revision 1.8  2009/08/19 18:41:52  mwrrv3
 *  Updated the annotations (table name and column names).
 *
 *  Revision 1.7  2009/08/18 02:00:13  mwrrv3
 *  Changed private to protected.
 *
 *  Revision 1.6  2009/08/05 05:17:17  mwrrv3
 *  Refactored Set to List.
 *
 *  Revision 1.5  2009/07/30 23:01:51  mwrrv3
 *  Implemented addPhoneNumber method and removed identifyingDocuments reference.
 *
 *  Revision 1.4  2009/07/28 00:05:45  mwrrv3
 *  Code formated and added comments.
 *
 *  Revision 1.3  2009/07/21 18:33:58  mwrrv3
 *  Modified the business objects.
 *
 *  Revision 1.2  2009/07/14 23:44:25  mwpxp2
 *  Initial move to hnode20
 *
 *  Revision 1.1  2009-07-12 00:55:16  ppalacz
 *  Moved to .impl package; added file decorations, todos
 *
 *  Revision 1.1  2009-07-10 07:09:24  ppalacz
 *  Synch
 *
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial ITM commit
 *  $
 *  $Revision 1.1  Apr 28, 2009 2:35:43 PM  MWCSJ3
 *  $Initial
 *  $
 */
