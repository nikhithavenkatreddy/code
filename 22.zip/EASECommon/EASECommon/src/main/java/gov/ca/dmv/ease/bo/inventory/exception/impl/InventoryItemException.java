/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: I am exception superclass regarding Inventory Items
 * File: InventoryItemException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Sep 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/22 20:55:38 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class InventoryItemException extends InventoryException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6446576930452328824L;

	/**
	 * Instantiates a new inventory item exception.
	 */
	public InventoryItemException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public InventoryItemException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public InventoryItemException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public InventoryItemException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: InventoryItemException.java,v $
 *  Revision 1.1  2010/09/22 20:55:38  mwpxp2
 *  Initial
 *
 */
