/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.financial;

/**
 * Description: Enumeration to determine the types of Fee Status - fee paid, fee used, fee due. 
 * 
 * File: FeeStatusType.java
 * Module:  gov.ca.dmv.ease.bo.financial
 * Created: Mar 4, 2010 
 * @author MWUXB  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/07/22 17:50:33 $
 * Last Changed By: $Author: mwpxp2 $
 */
public enum FeeStatusType {
	FEE_DUE, FEE_NOT_DUE, FEE_NOT_PAID, FEE_NOT_USED, FEE_PAID, FEE_USED
}
/**
 *  Modification History:
 * 
 *  $Log: FeeStatusType.java,v $
 *  Revision 1.2  2010/07/22 17:50:33  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.1  2010/04/15 18:31:15  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.2  2010/03/20 22:41:02  mwuxb
 *  Added more status types
 *
 *  Revision 1.1  2010/03/05 00:50:24  mwuxb
 *  Initial Commit
 *
*/
