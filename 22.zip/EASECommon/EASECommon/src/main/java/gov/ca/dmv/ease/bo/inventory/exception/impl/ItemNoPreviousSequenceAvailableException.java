/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: I am to be used in inventory item sequence generation
 * File: ItemNoPreviousSequenceAvailableException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Sep 22, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2010/09/22 20:56:20 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ItemNoPreviousSequenceAvailableException extends
		InventoryItemException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8631108940631915220L;

	/**
	 * Instantiates a new item no previous sequence available exception.
	 */
	public ItemNoPreviousSequenceAvailableException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public ItemNoPreviousSequenceAvailableException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public ItemNoPreviousSequenceAvailableException(String message,
			Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public ItemNoPreviousSequenceAvailableException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ItemNoPreviousSequenceAvailableException.java,v $
 *  Revision 1.1  2010/09/22 20:56:20  mwpxp2
 *  Initial
 *
 */
