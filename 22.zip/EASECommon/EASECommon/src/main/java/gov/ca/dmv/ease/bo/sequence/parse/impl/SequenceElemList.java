/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence.parse.impl;

import gov.ca.dmv.ease.bo.sequence.ISequence;
import gov.ca.dmv.ease.bo.sequence.ISequenceElem;
import gov.ca.dmv.ease.bo.sequence.ISequencePattern;
import gov.ca.dmv.ease.bo.sequence.exception.impl.SequenceParsingException;
import gov.ca.dmv.ease.bo.sequence.impl.Sequence;
import gov.ca.dmv.ease.bo.sequence.impl.SequenceElem;
import gov.ca.dmv.ease.bo.sequence.parse.ISequenceElemList;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: I am default implementation of ISequenceElem
 * 
 * File: SequenceElemList.java
 * Module:  gov.ca.dmv.ease.bo.sequence.impl
 * Created: Sep 8, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2010/10/09 00:18:43 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SequenceElemList implements ISequenceElemList {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -852937359930495880L;
	/** The Constant CR. */
	private static final char CR = '\n';
	/** The elems. */
	private List <ISequenceElem> elems;

	/**
	 * Instantiates a new sequence elem list.
	 */
	public SequenceElemList() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElemList#addElem(gov.ca.dmv.ease.bo.sequence.ISequenceElem)
	 */
	public void addElem(ISequenceElem anElem) {
		getElems().add(anElem);
	}

	/**
	 * Adds the elem first.
	 * 
	 * @param anElem the an elem
	 */
	private void addElemFirst(ISequenceElem anElem) {
		getElems().add(0, anElem);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElemList#asSequence()
	 */
	public ISequence asSequence(ISequencePattern aPattern) {
		int size = getSize();
		StringBuilder aSeqValue = new StringBuilder(size);
		StringBuilder aPatternValue = new StringBuilder(size);
		for (ISequenceElem anElem : getElems()) {
			aSeqValue.append(anElem.getCharValue());
			aPatternValue.append(anElem.getPatternChar());
		}
		return new Sequence(aSeqValue.toString(), aPattern);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElemList#getElems()
	 */
	public List <ISequenceElem> getElems() {
		if (elems == null) {
			setElems(new ArrayList <ISequenceElem>());
		}
		return elems;
	}

	/**
	 * Gets the elems reversed.
	 * 
	 * @return the elems reversed
	 */
	private List <ISequenceElem> getElemsReversed() {
		if (elems == null) {
			throw new SequenceParsingException("null elems in " + this);
		}
		int size = getElems().size();
		if (size == 1) {
			return elems;
		}
		else {
			List <ISequenceElem> aList = new ArrayList <ISequenceElem>(size);
			for (int i = size; i > 0; i--) {
				aList.add(elems.get(i - 1));
			}
			return aList;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElemList#getNext()
	 */
	public ISequenceElemList getNext() {
		SequenceElemList aNext = new SequenceElemList();
		ISequenceElem aNextElem = null;
		ISequenceElem lastIncrementableElem = null;
		ISequenceElem prevElem = null;
		for (ISequenceElem anElem : getElemsReversed()) {
			//			System.out.println("elem: " + anElem);
			//			System.out.println("\tlastIncrementable: " + lastIncrementableElem);
			//			System.out.println("\tprevious: " + prevElem);
			if (prevElem == null) {
				aNextElem = anElem.getNext();
			}
			else {
				if (lastIncrementableElem == null) {
					aNextElem = anElem.getNext();
				}
				else {
					if (lastIncrementableElem.isOverOrUnder()) {
						if (lastIncrementableElem.isOver()) {
							aNextElem = anElem.getNext();
						}
						else {
							if (lastIncrementableElem.isUnder()) {
								aNextElem = anElem.getPrevious();
							}
							else {
								throw new SequenceParsingException(
										"Unexpected state of " + anElem);
							}
						}
					}
					else {
						aNextElem = new SequenceElem(anElem);
					}
				}
			}
			prevElem = aNextElem;
			if (!aNextElem.isFixed()) {
				lastIncrementableElem = aNextElem;
			}
			//			System.out.println("\tnext: " + aNextElem);
			aNext.addElemFirst(aNextElem);
		}
		return aNext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.sequence.ISequenceElemList#getPrevious()
	 */
	public ISequenceElemList getPrevious() {
		SequenceElemList aPrev = new SequenceElemList();
		ISequenceElem aPrevElem = null;
		ISequenceElem lastIncrementableElem = null;
		ISequenceElem prevElem = null;
		for (ISequenceElem anElem : getElemsReversed()) {
			if (prevElem == null) {
				aPrevElem = anElem.getPrevious();
			}
			else {
				if (lastIncrementableElem == null) {
					aPrevElem = anElem.getPrevious();
				}
				else {
					if (lastIncrementableElem.isOverOrUnder()) {
						if (lastIncrementableElem.isOver()) {
							aPrevElem = anElem.getNext();
						}
						else {
							if (lastIncrementableElem.isUnder()) {
								aPrevElem = anElem.getPrevious();
							}
							else {
								throw new SequenceParsingException(
										"Unexpected state of " + anElem);
							}
						}
					}
					else {
						aPrevElem = new SequenceElem(anElem);
					}
				}
			}
			prevElem = aPrevElem;
			if (!aPrevElem.isFixed()) {
				lastIncrementableElem = aPrevElem;
			}
			aPrev.addElemFirst(aPrevElem);
		}
		return aPrev;
	}

	/**
	 * Gets the size.
	 * 
	 * @return the size
	 */
	public int getSize() {
		if (elems == null) {
			return 0;
		}
		else {
			return elems.size();
		}
	}

	/**
	 * Sets the elems.
	 * 
	 * @param aList the a list
	 */
	protected void setElems(List <ISequenceElem> aList) {
		elems = aList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		int size = getSize();
		StringBuilder aBuilder1 = new StringBuilder(size);
		StringBuilder aBuilder2 = new StringBuilder(size);
		StringBuilder aBuilder3 = new StringBuilder(size);
		StringBuilder aBuilder4 = new StringBuilder(size);
		StringBuilder aBuilder5 = new StringBuilder(size * 4 + 16);
		for (ISequenceElem anelem : getElems()) {
			aBuilder1.append(anelem.getCharValue());
			aBuilder2.append(anelem.getPatternChar());
			aBuilder3.append(anelem.getMinChar());
			aBuilder4.append(anelem.getMaxChar());
		}
		aBuilder5.append(CR);
		aBuilder5.append(aBuilder1.toString()).append(CR);
		aBuilder5.append(aBuilder2.toString()).append(CR);
		aBuilder5.append(aBuilder3.toString()).append(CR);
		aBuilder5.append(aBuilder4.toString()).append(CR);
		return aBuilder5.toString();
	}

	public ISequenceElem getElemAt(int index) {
		return getElems().get(index);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SequenceElemList.java,v $
 *  Revision 1.3  2010/10/09 00:18:43  mwpxp2
 *  Added getElemAt/1
 *
 *  Revision 1.2  2010/10/06 00:35:30  mwpxp2
 *  Commented out console output
 *
 *  Revision 1.1  2010/09/30 18:51:12  mwpxp2
 *  Moved in to parse package
 *
 *  Revision 1.5  2010/09/30 07:46:15  mwpxp2
 *  Corrected getNext/0 and getPrevious/0
 *
 *  Revision 1.4  2010/09/11 00:27:42  mwpxp2
 *  Changed asSequence/0 to asSequence/1
 *
 *  Revision 1.3  2010/09/10 01:05:40  mwpxp2
 *  Added toString/0
 *
 *  Revision 1.2  2010/09/09 01:28:27  mwpxp2
 *  Partial unit test ok
 *
 *  Revision 1.1  2010/09/09 00:46:59  mwpxp2
 *  Initial, untested
 *
 */
