/** * 
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.license.testresult.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.impl.BusinessObject;
import gov.ca.dmv.ease.bo.license.testresult.DriveAndLawTestResultType;
import gov.ca.dmv.ease.fw.exception.impl.EaseValidationException;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Description: This class holds Drive and Law Test Results Information.
 * File: DriveAndLawTestResultGroup.java
 * Module:  gov.ca.dmv.ease.bo.license.testresult.impl
 * Created: Jan 6, 2010 
 * @author MWHXA2  
 * @version $Revision: 1.23 $
 * Last Changed: $Date: 2012/08/15 16:23:22 $
 * Last Changed By: $Author: mwrrv3 $
 */
public class DriveAndLawTestResultGroup extends BusinessObject {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7592725144306899330L;
	/** Holds Drive and Law Test Result Items Records. */
	private List <DriveAndLawTestResult> driveAndLawTestResultItems;
	/** Law Test Failure Date. */
	private Date lawTestFailureDate;
	/** Holds Oral Test Result. */
	private CodeSetElement oralTestResultCode;
	/** Holds Vision Test Result Code. */
	private CodeSetElement visionTestResultCode;
	/** The previous law test failure date. */
	private Date previousLawTestFailureDate;

	/**
	 * @return the previousDriveTestFailureDate
	 */
	public Date getPreviousLawTestFailureDate() {
		return previousLawTestFailureDate;
	}

	/**
	 * @param previousDriveTestFailureDate the previousDriveTestFailureDate to set
	 */
	public void setPreviousLawTestFailureDate(Date previousLawTestFailureDate) {
		this.previousLawTestFailureDate = previousLawTestFailureDate;
	}

	/**
	 * Default Constructor.
	 */
	public DriveAndLawTestResultGroup() {
	}

	/**
	 * Overloaded Constructor.
	 *
	 * @param dataToCopy the data to copy
	 */
	public DriveAndLawTestResultGroup(DriveAndLawTestResultGroup dataToCopy) {
		super();
		copy(dataToCopy);
	}

	/**
	 * Copy.
	 *
	 * @param dataToCopy the data to copy
	 */
	private void copy(DriveAndLawTestResultGroup dataToCopy) {
		if (dataToCopy == null) {
			throw new EaseValidationException(
					"non-null DriveAndLawTestResultGroup argument expected in copy method in "
							+ this);
		}
		super.copy(dataToCopy);
		copyDriveAndLawTestResult(dataToCopy.getDriveAndLawTestResults());
		//Copy Law Test Failure Date
		if (isNotNull(dataToCopy.getLawTestFailureDate())) {
			setLawTestFailureDate(new Date(dataToCopy.getLawTestFailureDate()
					.getTime()));
		}
		else {
			setLawTestFailureDate(null);
		}
		//Copy Law Test Failure Date
		if (isNotNull(dataToCopy.getPreviousLawTestFailureDate())) {
			setPreviousLawTestFailureDate(new Date(dataToCopy
					.getPreviousLawTestFailureDate().getTime()));
		}
		else {
			setPreviousLawTestFailureDate(null);
		}
		//Copy Oral Test Result
		if (isNotNull(dataToCopy.getOralTestResultCode())) {
			setOralTestResultCode(new CodeSetElement(dataToCopy
					.getOralTestResultCode()));
		}
		else {
			setOralTestResultCode(null);
		}
		//Copy Vision Test Result
		if (isNotNull(dataToCopy.getVisionTestResultCode())) {
			setVisionTestResultCode(new CodeSetElement(dataToCopy
					.getVisionTestResultCode()));
		}
		else {
			setVisionTestResultCode(null);
		}
	}

	/**
	 * Copy the drive and test result to the list.
	 *
	 * @param driveAndLawTestResultsToCopy the drive and law test results to copy
	 */
	private void copyDriveAndLawTestResult(
			List <DriveAndLawTestResult> driveAndLawTestResultsToCopy) {
		if (isNotNull(driveAndLawTestResultsToCopy)) {
			for (DriveAndLawTestResult driveAndLawTestResult : driveAndLawTestResultsToCopy) {
				addDriveAndLawTestResult(new DriveAndLawTestResult(
						driveAndLawTestResult));
			}
		}
	}

	/**
	 * Adds the drive test result.
	 * 
	 * @param driveAndLawTestResult the drive test result
	 */
	public void addDriveAndLawTestResult(
			DriveAndLawTestResult driveAndLawTestResult) {
		//Check if Results is not null
		if (!EaseUtil.isNotNull(driveAndLawTestResultItems)) {
			driveAndLawTestResultItems = new ArrayList <DriveAndLawTestResult>();
		}
		driveAndLawTestResultItems.add(driveAndLawTestResult);
	}

	/**
	 * This method removes the input drive and law test result from the list of 
	 * test results.
	 * 
	 * @param aDriveAndLawTestResult the input drive and law test result
	 * @return true if removed from the test results
	 */
	public boolean deleteDriveAndLawTestResult(
			DriveAndLawTestResult aDriveAndLawTestResult) {
		boolean isDeleted = false;
		//Check if Results is not null
		if (EaseUtil.isNotNull(driveAndLawTestResultItems)) {
			isDeleted = driveAndLawTestResultItems
					.remove(aDriveAndLawTestResult);
		}
		return isDeleted;
	}

	/**
	 * This method removes the last drive and law test result from the list of 
	 * test results; for input drive and law test result type.
	 * 
	 * Removes the last drive and law test result of the input type.
	 * 
	 * @param driveAndLawTestResultType the input drive and law test result type
	 * @return true if removed from the test results
	 */
	public boolean deleteDriveAndLawTestResult(
			DriveAndLawTestResultType driveAndLawTestResultType) {
		boolean isDeleted = false;
		//Check if Results is not null
		if (!EaseUtil.isNullOrBlank(driveAndLawTestResultItems)) {
			int lastIndex = driveAndLawTestResultItems.size() - 1;
			//iterate in reverse
			for (int i = lastIndex; i >= 0; i--) {
				if (driveAndLawTestResultItems.get(i)
						.getDriveAndLawTestResultType().equals(
								driveAndLawTestResultType)) {
					driveAndLawTestResultItems.remove(i);
					isDeleted = true;
					break;
				}
			}
		}
		return isDeleted;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// FIXME NEED TO FIX
		return super.equals(obj);
	}

	/**
	 * This method returns Drive Test Results for the given Drive and Law Test Result Type.
	 * 
	 * @param driveAndLawTestResultType the requisite {@link DriveAndLawTestResultType}
	 * @return list of Required Drive Test Results
	 * @see DriveAndLawTestResult
	 **/
	public List <DriveAndLawTestResult> getDriveAndLawTestResults(
			DriveAndLawTestResultType driveAndLawTestResultType) {
		List <DriveAndLawTestResult> requiredDriveTestResults = new ArrayList <DriveAndLawTestResult>();
		//Check if Results exist
		if (!EaseUtil.isNullOrBlank(getDriveAndLawTestResults())) {
			//Iterate the Test Results
			for (DriveAndLawTestResult driveAndLawTestResultItem : getDriveAndLawTestResults()) {
				//Check if Result Type exists
				if (!EaseUtil.isNullOrBlank(driveAndLawTestResultItem
						.getDriveAndLawTestResultType())
						&& driveAndLawTestResultItem
								.getDriveAndLawTestResultType().equals(
										driveAndLawTestResultType)) {
					//Add to return list
					requiredDriveTestResults.add(driveAndLawTestResultItem);
				}
			}
		}
		return requiredDriveTestResults;
	}
	
	
	/**
	 * This method returns Drive TestResults for given Drive and Law Test Result Type and Result Type.
	 * To be used for AMCKTS waive tests only.
	 *
	 */
	
	public boolean isDriveAndLawTestWaived(
			DriveAndLawTestResultType driveAndLawTestResultType, String testResultType) {
		Object passedCodes [] = { "P", "S", "A"};
		//Check if Results exist
		if (!EaseUtil.isNullOrBlank(getDriveAndLawTestResults())) {
			//Iterate the Test Results
			for (DriveAndLawTestResult driveAndLawTestResultItem : getDriveAndLawTestResults()) {
				//Check if Result Type exists
				if (!EaseUtil.isNullOrBlank(driveAndLawTestResultItem
						.getDriveAndLawTestResultType())
						&& driveAndLawTestResultItem
								.getDriveAndLawTestResultType().equals(
										driveAndLawTestResultType)){
					if (testResultType.equalsIgnoreCase(driveAndLawTestResultItem.getTestResultCode().getCode()) ||
							//Do not waive exams previously failed;
								!(ArrayUtils.contains(driveAndLawTestResultItem.getTestResultCode().getCode(), passedCodes))) {
						return true;
					}		
						
				}
			}

		}
		return false;
	}
	

	/**
	 * Gets the drive and law test results.
	 *
	 * @return the drive and law test results
	 */
	public List <DriveAndLawTestResult> getDriveAndLawTestResults() {
		return driveAndLawTestResultItems;
	}

	/**
	 * Gets the Law Test Failure Date.
	 *
	 * @return the lawTestFailureDate
	 */
	public Date getLawTestFailureDate() {
		return lawTestFailureDate;
	}

	/**
	 * Gets the Oral Test Result Code.
	 * 
	 * @return the oralTestResultCode
	 */
	public CodeSetElement getOralTestResultCode() {
		return oralTestResultCode;
	}

	/**
	 * Gets the Vision Test Result Code.
	 * 
	 * @return the visionTestResultCode
	 */
	public CodeSetElement getVisionTestResultCode() {
		return visionTestResultCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.bo.impl.BusinessObject#hashCode()
	 */
	@Override
	public int hashCode() {
		//FIXME NEED TO FIX
		return super.hashCode();
	}

	/**
	 * Return true if DriveAndLawTestResultItems list is Empty.
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return driveAndLawTestResultItems == null
				|| driveAndLawTestResultItems.isEmpty();
		//		boolean isEmpty = true;
		//		if (driveAndLawTestResultItems.size() > 0) {
		//			isEmpty = false;
		//		}
		//		return isEmpty;
	}

	/**
	 * Sets the Law Test Failure Date.
	 *
	 * @param lawTestFailureDate the lawTestFailureDate to set
	 */
	public void setLawTestFailureDate(Date lawTestFailureDate) {
		this.lawTestFailureDate = lawTestFailureDate;
	}

	/**
	 * Sets the Oral Test Result Code.
	 * 
	 * @param oralTestResultCode the oralTestResultCode to set
	 */
	public void setOralTestResultCode(CodeSetElement oralTestResultCode) {
		this.oralTestResultCode = oralTestResultCode;
	}

	/**
	 * Sets the Vision Test Result Code.
	 *
	 * @param visionTestResultCode the new vision test result code
	 */
	public void setVisionTestResultCode(CodeSetElement visionTestResultCode) {
		this.visionTestResultCode = visionTestResultCode;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DriveAndLawTestResultGroup.java,v $
 *  Revision 1.23  2012/08/15 16:23:22  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.22  2012/07/23 23:41:58  mwgxd3
 *  AKTS - defect 32
 *
 *  Revision 1.21  2012/07/18 01:13:18  mwgxd3
 *  AKTS defect 32
 *
 *  Revision 1.20  2011/05/14 00:25:20  mwrka1
 *  rollback
 *
 *  Revision 1.18  2011/05/07 23:09:18  mwrka1
 *  Fixed 5560
 *
 *  Revision 1.17  2011/05/07 23:01:52  mwrka1
 *  Fixed 5560
 *
 *  Revision 1.16  2011/05/07 22:59:02  mwrka1
 *  Fixed 5560
 *
 *  Revision 1.15  2011/04/07 04:04:55  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.14.18.6  2011/04/05 21:06:05  mwhys
 *  Updated.
 *
 *  Revision 1.14.18.5  2011/04/05 20:52:21  mwhys
 *  Refactored.
 *
 *  Revision 1.14.18.4  2011/04/05 20:28:17  mwrrv3
 *  Updated the copy method.
 *
 *  Revision 1.14.18.3  2011/04/04 23:20:29  mwkfh
 *  updated copy method
 *
 *  Revision 1.14.18.2  2011/04/04 18:59:15  mwrrv3
 *  Updated the overloaded constructor.
 *
 *  Revision 1.14.18.1  2011/04/04 00:32:41  mwrrv3
 *  Added copyConstructor functionality to this class.
 *
 *  Revision 1.14  2010/12/02 00:15:46  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.13  2010/08/10 17:51:56  mwhxa2
 *  Removing getter for driveAndLawTestResultItems
 *
 *  Revision 1.12  2010/08/09 21:01:42  mwhxa2
 *  Added getter for driveAndLawTestResultItems
 *
 *  Revision 1.11  2010/07/23 16:32:43  mwpxp2
 *  Corrected isempty
 *
 *  Revision 1.10  2010/07/22 23:27:51  mwhxb3
 *  Added method to check if DriveAndLawTestResultItems list is Empty.
 *
 *  Revision 1.9  2010/07/22 17:50:31  mwpxp2
 *  Bulk cleanup and format
 *
 *  Revision 1.8  2010/06/21 23:01:03  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.5.2.2  2010/06/20 18:07:14  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.7  2010/06/02 20:41:57  mwrsk
 *  Remove clone()
 *
 *  Revision 1.6  2010/05/31 22:42:16  mwrsk
 *  corrected the delete for loop  mwlft1
 *
 *  Revision 1.5  2010/05/28 16:11:48  mwuxb
 *  Removed variable foreignLanguageCode from BO DriveAndLawTestResultGroup - foreign language field should be use from DriverLicense BO
 *
 *  Revision 1.4  2010/04/21 00:55:15  mwrsk
 *  Updated deleteDriveAndLawTestResult() to break from the loop
 *
 *  Revision 1.3  2010/04/19 20:57:42  mwhxa2
 *  updated delete logic
 *
 *  Revision 1.2  2010/04/19 18:45:50  mwhxa2
 *  Added deleteDriveAndLawTestResult
 *
 *  Revision 1.1  2010/04/15 18:31:14  mwvxm6
 *  Initial commit of bo packages move to Common
 *
 *  Revision 1.11  2010/04/05 18:34:35  mwtjc1
 *  updated
 *
 *  Revision 1.10  2010/03/18 17:21:34  mwhxa2
 *  added methods to get(), add() and delete() for test results
 *
 *  Revision 1.9  2010/03/18 15:29:28  mwrsk
 *  updates to reflect test result changes
 *
 *  Revision 1.8  2010/03/10 19:21:08  mwuxb
 *  Updates for getDriveTestResults
 *
 *  Revision 1.7  2010/02/24 19:23:40  mwuxb
 *  Added method getDriveTestResults(DriveTestResultType driveTestResultType)
 *
 *  Revision 1.6  2010/02/24 01:17:48  mwuxb
 *  Changed attribute from foreignLanguageTestResultCode to foreignLanguageCode
 *
 *  Revision 1.5  2010/02/18 23:10:59  mwrsk
 *  added addDriveAndLawTestResultItem()
 *
 *  Revision 1.4  2010/02/17 17:48:01  mwuxb
 *  Added lawTestFailureDate attribute
 *
 *  Revision 1.3  2010/01/29 15:27:54  mwrsk
 *  renamed "driveAndLawTestResultItem" to "driveAndLawTestResultItems"
 *
 *  Revision 1.2  2010/01/29 15:17:46  mwrsk
 *  renamed visionTestResult, oralTestResult, foreignLanguageTestResult to include "Code" suffix
 *
 *  Revision 1.1  2010/01/28 22:43:26  mwrsk
 *  Moved enum to its own class & renamed package name from test to testresult
 *
 *  Revision 1.2  2010/01/08 02:14:24  mwrsk
 *  rename classname
 *
 *  Revision 1.1  2010/01/07 18:29:48  mwhxa2
 *  Domain Model changes - Draft 1
 *
*/
