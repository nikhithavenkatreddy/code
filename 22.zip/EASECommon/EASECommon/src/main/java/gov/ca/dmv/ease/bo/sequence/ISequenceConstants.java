/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.bo.sequence;

/**
 * Description: I group constants for sequence processign
 * File: ISequenceConstants.java
 * Module:  gov.ca.dmv.ease.bo.sequence
 * Created: Sep 3, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2010/10/22 16:17:32 $
 * Last Changed By: $Author: mwkfh $
 */
public interface ISequenceConstants {
	//  * A=Alpha Character (A-Z)
	//    * I=Incrementing Digit (0-9)
	//    * S=Space Character
	//    * N=Numeric Non-incrementing Digit (0-9)
	//    * X=Either A or N
	//    * Z=I with leading S
	/** The pattern size */
	int PATTERN_SIZE = 8;
	/** The ALPHA. */
	char ALPHA = 'A';
	/** The ALPHANUM. */
	char ALPHANUM = 'X';
	/** Numeric Non-incrementing Digit (0-9). */
	char FIXED_DIGIT = 'N';
	/** The INCREMENTING digit. */
	char INCREMENTING_DIGIT = 'I';
	/** I with leading S. */
	char INCREMENTING_DIGIT_WITH_LEADING_SPACE = 'Z';
	/** The MA x_ alpha. */
	char MAX_ALPHA = 'Z';
	/** The MA x_ digit. */
	char MAX_DIGIT = '9';
	/** The MI n_ alpha. */
	char MIN_ALPHA = 'A';
	/** The MI n_ digit. */
	char MIN_DIGIT = '0';
	/** The SPACE. */
	char SPACE = ' ';
	/** The SPAC e_ filler. */
	char SPACE_FILLER = 'S';
	/** Valid Pattern chars */
	/* Note: Only A, I, S are used in DL */
	char[] VALID_PATTERN_VALUES = { ALPHA, ALPHANUM, FIXED_DIGIT,
			INCREMENTING_DIGIT, INCREMENTING_DIGIT_WITH_LEADING_SPACE,
			SPACE_FILLER };
}
/**
 *  Modification History:
 *
 *  $Log: ISequenceConstants.java,v $
 *  Revision 1.4  2010/10/22 16:17:32  mwkfh
 *  added pattern size and valid values
 *
 *  Revision 1.3  2010/09/08 21:30:53  mwpxp2
 *  Added constants
 *
 *  Revision 1.2  2010/09/08 21:07:40  mwpxp2
 *  Added MIN~, MAX~ constants
 *
 *  Revision 1.1  2010/09/04 05:53:51  mwpxp2
 *  Initial, in progress
 *
 */
