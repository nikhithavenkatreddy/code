/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2010
 * http://www.california.gov
 */
/**
 * 
 */
package gov.ca.dmv.ease.bo.inventory.exception.impl;

/**
 * Description: Exception to be thrown when item assumed issued has not been issued
 * File: NotYetIssuedException.java
 * Module:  gov.ca.dmv.ease.bo.inventory.exception.impl
 * Created: Aug 30, 2010 
 * @author MWPXP2  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2010/09/22 20:57:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class NotYetIssuedException extends InventoryItemException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -437103885422326775L;

	/**
	 * Instantiates a new not yet issued exception.
	 */
	public NotYetIssuedException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public NotYetIssuedException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public NotYetIssuedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public NotYetIssuedException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: NotYetIssuedException.java,v $
 *  Revision 1.2  2010/09/22 20:57:06  mwpxp2
 *  hierarchy mod
 *
 *  Revision 1.1  2010/08/31 03:15:22  mwpxp2
 *  Initial
 *
 */
