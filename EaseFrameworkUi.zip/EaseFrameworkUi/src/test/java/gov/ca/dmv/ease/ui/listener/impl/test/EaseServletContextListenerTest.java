/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2011
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener;

import javax.servlet.ServletContext;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.mock.web.MockServletContext;

/**
 * Description: I am unit test for EaseServletContextListener
 * File: EaseServletContextListenerTest.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl.test
 * Created: Jul 28, 2011 
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseServletContextListenerTest extends EaseServletContextListener {
	/** The Constant TEST_GEN_CTX. */
	private static final GenericApplicationContext TEST_GEN_CTX = new GenericApplicationContext();
	/** The Constant TEST_NON_SPRING. */
	private static final String TEST_NON_SPRING = "some";
	/** The Constant TEST_SERVLET_CTX. */
	private static final ServletContext TEST_SERVLET_CTX = createServletCtx();

	/**
	 * Creates the servlet ctx.
	 *
	 * @return the servlet context
	 */
	private static ServletContext createServletCtx() {
		return new MockServletContext();
	}

	/**
	 * Instantiates a new ease servlet context listener test.
	 */
	public EaseServletContextListenerTest() {
		super();
	}

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#hasSpringPackage(java.lang.String)}.
	 */
	@Test
	public void test02HasSpringPackage() {
		assertFalse(hasSpringPackage(null));
		assertFalse(hasSpringPackage("some" + SPRING_PACKAGE));
		assertTrue(hasSpringPackage(SPRING_PACKAGE + "some"));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#asString(javax.servlet.ServletContext)}.
	 */
	@Test
	public void test04AsString() {
		String res = asString(TEST_SERVLET_CTX);
		assertNotNull(res);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#cleanSpringAppContextImpl1(java.lang.Object)}.
	 */
	@Test
	public void test20CleanSpringAppContextImpl1() {
		assertTrue(cleanSpringAppContextImpl1(TEST_GEN_CTX));
		assertFalse(cleanSpringAppContextImpl1(TEST_NON_SPRING));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#processSpringKeyValue(java.lang.String, java.lang.Object, java.lang.String)}.
	 */
	@Test
	public void test20ProcessSpringKeyValue() {
		assertTrue(processSpringKeyValue("some", TEST_GEN_CTX, TEST_GEN_CTX
				.toString()));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#cleanSpringAppContextImpl2(java.lang.Object)}.
	 */
	@Test
	public void test22CleanSpringAppContextImpl2() {
		assertTrue(cleanSpringAppContextImpl2(TEST_GEN_CTX));
		assertFalse(cleanSpringAppContextImpl2(TEST_NON_SPRING));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#cleanSpringInterface(java.lang.Object)}.
	 */
	@Test
	public void test24CleanSpringInterface() {
		assertTrue(cleanSpringInterface(TEST_GEN_CTX));
		assertFalse(cleanSpringInterface(TEST_NON_SPRING));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#processKeyValue(java.lang.String, java.lang.Object)}.
	 */
	@Test
	public void test30ProcessKeyValueWithTrue() {
		boolean res = processKeyValue("some", TEST_GEN_CTX);
		assertTrue(res);
	}

	/**
	 * Test31 process key value with false.
	 */
	@Test
	public void test31ProcessKeyValueWithFalse() {
		boolean res = processKeyValue("some", TEST_NON_SPRING);
		assertFalse(res);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#processSpringAppContextImpl1(java.lang.String, java.lang.Object, java.lang.String)}.
	 */
	@Test
	public void test32ProcessSpringAppContextImpl1() {
		boolean res = processSpringAppContextImpl1("some", TEST_GEN_CTX,
				TEST_GEN_CTX.toString());
		assertFalse(res);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#processSpringAppContextImpl2(java.lang.String, java.lang.Object, java.lang.String)}.
	 */
	@Test
	public void test34ProcessSpringAppContextImpl2() {
		boolean res = processSpringAppContextImpl2("some", TEST_GEN_CTX,
				TEST_GEN_CTX.toString());
		assertTrue(res);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#processSpringAppContextInterface(java.lang.String, java.lang.Object, java.lang.String)}.
	 */
	@Test
	public void test36ProcessSpringAppContextInterface() {
		boolean res = processSpringAppContextInterface("some", TEST_GEN_CTX,
				TEST_GEN_CTX.toString());
		assertFalse(res);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#closeApplicationContext(org.springframework.context.support.AbstractApplicationContext)}.
	 */
	@Test
	public void test40CloseApplicationContext() {
		assertTrue(closeApplicationContext(TEST_GEN_CTX));
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.EaseServletContextListener#closeApplicationContextInterface(org.springframework.context.ApplicationContext)}.
	 */
	@Test
	public void test42CloseApplicationContextInterface() {
		assertTrue(closeApplicationContextInterface(TEST_GEN_CTX));
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseServletContextListenerTest.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2011/07/29 04:57:22  mwpxp2
 *  Initial; executes ok
 *
 */
