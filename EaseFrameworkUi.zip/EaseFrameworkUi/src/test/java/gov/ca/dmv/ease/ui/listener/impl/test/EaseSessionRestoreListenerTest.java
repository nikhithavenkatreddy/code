/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl.test;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isA;
import static org.easymock.classextension.EasyMock.createMock;
import static org.easymock.classextension.EasyMock.replay;
import static org.easymock.classextension.EasyMock.verify;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.ui.listener.impl.EaseSessionRestoreListener;

import javax.faces.application.Application;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.servlet.ServletContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.web.context.WebApplicationContext;

/**
 * Description: The purpose of this class is to test the EaseSessionRestoreListener class.
 * File: EaseSessionRestoreListenerTest.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl.test
 * Created: Aug 31, 2010 
 * @author MWKFH  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
@ContextConfiguration(locations = { "classpath:/test-applicationContext-fw-services.xml" })
public class EaseSessionRestoreListenerTest extends
		AbstractJUnit4SpringContextTests {
	/** The request header extractor. */
	private EaseSessionRestoreListener easeSessionRestoreListener;
	/** Mocked PhaseEvent */
	private PhaseEvent mockPhaseEvent;
	/** Mocked FacesContext */
	private FacesContext mockFacesContext;
	/** Mocked Application */
	private Application mockApplication;
	/** Mocked ViewHandler */
	private ViewHandler mockViewHandler;
	/** Mocked ExternalContext */
	private ExternalContext mockExternalContext;
	/** Mocked ServletContext */
	private ServletContext mockServletContext;
	/** Mocked ApplicationContext */
	private WebApplicationContext mockWebApplicationContext;
	/** Mocked SessionData */
	private SessionData mockSessionData;
	/** Mocked UserContext */
	private UserContext mockUserContext;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		mockFacesContext = createMock(FacesContext.class);
		mockApplication = createMock(Application.class);
		mockViewHandler = createMock(ViewHandler.class);
		mockExternalContext = createMock(ExternalContext.class);
		mockPhaseEvent = createMock(PhaseEvent.class);
		mockServletContext = createMock(ServletContext.class);
		mockWebApplicationContext = createMock(WebApplicationContext.class);
		mockSessionData = new SessionData();
		mockUserContext = (UserContext) UserContext.getDefaultInstanceForDb();
		easeSessionRestoreListener = new EaseSessionRestoreListener();
		assertNotNull(easeSessionRestoreListener);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		mockFacesContext = null;
		mockApplication = null;
		mockViewHandler = null;
		mockExternalContext = null;
		mockPhaseEvent = null;
		mockServletContext = null;
		mockWebApplicationContext = null;
		mockSessionData = null;
		mockUserContext = null;
		easeSessionRestoreListener = null;
		assertNull(easeSessionRestoreListener);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionRestoreListener#getPhaseId()}.
	 */
	@Test
	public void testGetPhaseId() {
		assertEquals(PhaseId.RESTORE_VIEW, easeSessionRestoreListener
				.getPhaseId());
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionRestoreListener#beforePhase()}.
	 */
	@Test
	public void testBeforePhase() {
		expect(mockPhaseEvent.getFacesContext()).andReturn(mockFacesContext);
		expect(mockFacesContext.getExternalContext()).andReturn(
				mockExternalContext);
		expect(mockExternalContext.getContext()).andReturn(mockServletContext);
		expect(
				mockServletContext
						.getAttribute("org.springframework.web.context.WebApplicationContext.ROOT"))
				.andReturn(mockWebApplicationContext);
		expect(mockWebApplicationContext.getBean("sessionData")).andReturn(
				mockSessionData);
		expect(mockWebApplicationContext.getBean("userContext")).andReturn(
				mockUserContext);
		expect(mockFacesContext.getApplication()).andReturn(mockApplication);
		expect(mockApplication.getViewHandler()).andReturn(mockViewHandler);
		expect(
				mockViewHandler.createView(isA(FacesContext.class),
						isA(String.class))).andReturn(new UIViewRoot());
		mockFacesContext.setViewRoot(isA(UIViewRoot.class));
		mockFacesContext.renderResponse();
		expectLastCall();
		replay(mockPhaseEvent, mockFacesContext, mockApplication,
				mockViewHandler, mockExternalContext, mockServletContext,
				mockWebApplicationContext);
		easeSessionRestoreListener.beforePhase(mockPhaseEvent);
		verify(mockPhaseEvent, mockFacesContext, mockApplication,
				mockViewHandler, mockExternalContext, mockServletContext,
				mockWebApplicationContext);
	}

	/**
	 * Test method for {@link gov.ca.dmv.ease.ui.listener.impl.impl.EaseSessionRestoreListener#afterPhase()}.
	 */
	@Test
	public void testAfterPhase() {
		easeSessionRestoreListener.afterPhase(mockPhaseEvent);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseSessionRestoreListenerTest.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/09/20 23:52:54  mwkfh
 *  fixed errors
 *
 *  Revision 1.2  2010/09/30 23:15:30  mwkfh
 *  updated test
 *
 *  Revision 1.1  2010/09/24 16:03:43  mwkfh
 *  new tests
 *
 */
