/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.aspect.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 * Description: I am the abstract audit aspect class and I define the common behavior
 *
 * 
 */
@Aspect
public class AspectCrossProjectTest {
	/**
	* Logger for this class
	*/
	public static final Log LOGGER = LogFactory
			.getLog(AspectCrossProjectTest.class);

	@Before("execution(* gov.ca.dmv.ease.aspect.util.impl.WeaveMe.testAspect1())")
	public void test1(JoinPoint joinPoint) {
		LOGGER.info("WeaveMe aspect test");
	}

	@Before("execution(* gov.ca.dmv.ease.aspect.impl.WeaveMeLocal.testAspect1())")
	public void test2(JoinPoint joinPoint) {
		LOGGER.info("WeaveMeLocal aspect test 1");
	}
}
/**
 *  Modification History:
 *
 *  $Log: AspectCrossProjectTest.java,v $
 *  Revision 1.2  2013/01/29 18:31:56  mwpxr5
 *  PMD coverage update
 *
 *  Revision 1.1  2012/10/07 04:39:54  mwxxw
 *  Add these files to test cross project weaving.
 *
 *  
*/
