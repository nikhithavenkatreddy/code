package gov.ca.dmv.ease.aspect.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class WeaveMeLocal {
	/**
	* Logger for this class
	*/
	public static final Log LOGGER = LogFactory.getLog(WeaveMeLocal.class);

	public static void main(String args[]) {
		LOGGER.info("WeaveMeLocal!");
		WeaveMeLocal weaveMeLocal = new WeaveMeLocal();
		weaveMeLocal.testAspect1();
	}

	public void testAspect1() {
		LOGGER.info("Weave me local");
		return;
	}
}
