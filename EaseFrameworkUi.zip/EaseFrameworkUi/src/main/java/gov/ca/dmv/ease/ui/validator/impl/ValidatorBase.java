/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.validator.Validator;

/**
 * Description: ValidatorBase is a base class for validators
 * //TODO - and that means what?
 * File: ValidatorBase.java
 * Module:  gov.ca.dmv.ease.ui.validator.impl
 * Created: Oct 19, 2009 
 * @author mwbvc  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class ValidatorBase implements Validator, StateHolder {
	/**
	 * Restore attached state.
	 * 
	 * @param context the context
	 * @param stateObj the state obj
	 * 
	 * @return the object
	 * 
	 * @throws IllegalStateException the illegal state exception
	 */
	public static Object restoreAttachedState(FacesContext context,
			Object stateObj) throws IllegalStateException {
		if (context == null) {
			throw new NullPointerException("context");
		}
		if (stateObj == null) {
			return null;
		}
		if (stateObj instanceof AttachedListStateWrapper) {
			List <?> lst = ((AttachedListStateWrapper) stateObj)
					.getWrappedStateList();
			List <Object> restoredList = new ArrayList <Object>(lst.size());
			for (Iterator <?> it = lst.iterator(); it.hasNext();) {
				restoredList.add(restoreAttachedState(context, it.next()));
			}
			return restoredList;
		}
		else if (stateObj instanceof AttachedStateWrapper) {
			Class <?> clazz = ((AttachedStateWrapper) stateObj).getClazz();
			Object restoredObject;
			try {
				restoredObject = clazz.newInstance();
			}
			catch (InstantiationException e) {
				throw new RuntimeException(
						"Could not restore StateHolder of type "
								+ clazz.getName()
								+ " (missing no-args constructor?)", e);
			}
			catch (IllegalAccessException e) {
				throw new RuntimeException(e);
			}
			if (restoredObject instanceof StateHolder) {
				Object wrappedState = ((AttachedStateWrapper) stateObj)
						.getWrappedStateObject();
				((StateHolder) restoredObject).restoreState(context,
						wrappedState);
			}
			return restoredObject;
		}
		else {
			return stateObj;
		}
	}

	/**
	 * Save attached state.
	 * 
	 * @param context the context
	 * @param attachedObject the attached object
	 * 
	 * @return the object
	 */
	public static Object saveAttachedState(FacesContext context,
			Object attachedObject) {
		if (attachedObject == null) {
			return null;
		}
		if (attachedObject instanceof List) {
			@SuppressWarnings("unchecked")
			List <Object> list = (List <Object>) attachedObject;
			List <Object> lst = new ArrayList <Object>(list.size());
			for (//@SuppressWarnings("unchecked")
			Iterator <Object> it = list.iterator(); it.hasNext();) {
				lst.add(saveAttachedState(context, it.next()));
			}
			return new AttachedListStateWrapper(lst);
		}
		else if (attachedObject instanceof StateHolder) {
			if (((StateHolder) attachedObject).isTransient()) {
				return null;
			}
			else {
				return new AttachedStateWrapper(attachedObject.getClass(),
						((StateHolder) attachedObject).saveState(context));
			}
		}
		else if (attachedObject instanceof Serializable) {
			return attachedObject;
		}
		else {
			return new AttachedStateWrapper(attachedObject.getClass(), null);
		}
	}

	/** The detail message. */
	private String detailMessage = null;
	/** The summary message. */
	private String summaryMessage = null;
	/** The transients. */
	private boolean transients = false;
	// from UIComponentBase
	/** The value binding map. */
	private Map <String, Object> valueBindingMap = null;

	/**
	 * Gets the detail message.
	 * 
	 * @return the detail message
	 */
	public String getDetailMessage() {
		if (detailMessage != null) {
			return detailMessage;
		}
		ValueBinding valueBinding = getValueBinding("detailMessage");
		return valueBinding != null ? (String) valueBinding.getValue(FacesUtils
				.getFacesContext()) : null;
	}

	/**
	 * Gets the summary message.
	 * 
	 * @return the summary message
	 */
	public String getSummaryMessage() {
		if (summaryMessage != null) {
			return summaryMessage;
		}
		ValueBinding valueBinding = getValueBinding("summaryMessage");
		return valueBinding != null ? (String) valueBinding.getValue(FacesUtils
				.getFacesContext()) : null;
	}

	/**
	 * Gets the value binding.
	 * 
	 * @param name the name
	 * 
	 * @return the value binding
	 */
	public ValueBinding getValueBinding(String name) {
		if (name == null) {
			throw new NullPointerException("name");
		}
		if (valueBindingMap == null) {
			return null;
		}
		else {
			return (ValueBinding) valueBindingMap.get(name);
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.StateHolder#isTransient()
	 */
	public boolean isTransient() {
		return transients;
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.StateHolder#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		summaryMessage = (String) values[0];
		detailMessage = (String) values[1];
		restoreValueBindingMap(context, values[2]);
	}

	/**
	 * Restore value binding map.
	 * 
	 * @param context the context
	 * @param stateObj the state obj
	 */
	private void restoreValueBindingMap(FacesContext context, Object stateObj) {
		if (stateObj != null) {
			Map stateMap = (Map) stateObj;
			int initCapacity = (stateMap.size() * 4 + 3) / 3;
			valueBindingMap = new HashMap <String, Object>(initCapacity);
			for (Iterator it = stateMap.entrySet().iterator(); it.hasNext();) {
				Map.Entry entry = (Map.Entry) it.next();
				valueBindingMap.put((String) entry.getKey(),
						restoreAttachedState(context, entry.getValue()));
			}
		}
		else {
			valueBindingMap = null;
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.StateHolder#saveState(javax.faces.context.FacesContext)
	 */
	public Object saveState(FacesContext context) {
		Object[] state = new Object[3];
		state[0] = summaryMessage;
		state[1] = detailMessage;
		state[2] = saveValueBindingMap(context);
		return state;
	}

	/**
	 * Save value binding map.
	 * 
	 * @param context the context
	 * 
	 * @return the object
	 */
	private Object saveValueBindingMap(FacesContext context) {
		if (valueBindingMap != null) {
			int initCapacity = (valueBindingMap.size() * 4 + 3) / 3;
			HashMap stateMap = new HashMap(initCapacity);
			for (Iterator it = valueBindingMap.entrySet().iterator(); it
					.hasNext();) {
				Map.Entry entry = (Map.Entry) it.next();
				stateMap.put(entry.getKey(),
						saveAttachedState(context, entry.getValue()));
			}
			return stateMap;
		}
		else {
			return null;
		}
	}

	/**
	 * Sets the detail message.
	 * 
	 * @param message the new detail message
	 */
	public void setDetailMessage(String message) {
		detailMessage = message;
	}

	/**
	 * Sets the summary message.
	 * 
	 * @param message the new summary message
	 */
	public void setSummaryMessage(String message) {
		summaryMessage = message;
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.StateHolder#setTransient(boolean)
	 */
	public void setTransient(boolean newTransientValue) {
		transients = newTransientValue;
	}

	/**
	 * Sets the value binding.
	 * 
	 * @param name the name
	 * @param binding the binding
	 */
	public void setValueBinding(String name, ValueBinding binding) {
		if (name == null) {
			throw new NullPointerException("name in "
					+ getClass().getSimpleName());
		}
		if (valueBindingMap == null) {
			valueBindingMap = new HashMap <String, Object>();
		}
		valueBindingMap.put(name, binding);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ValidatorBase.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.6  2012/08/25 18:23:12  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.5  2012/08/25 18:11:42  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.4  2011/06/02 22:48:33  mwpxp2
 *  valueBindingMap parms changed to <String, Object>
 *
 *  Revision 1.3  2011/06/02 22:44:41  mwpxp2
 *  Parametrized valueBindingMap
 *
 *  Revision 1.2  2010/03/23 00:08:38  mwpxp2
 *  Fixed javadoc, file footer
 *
 */
