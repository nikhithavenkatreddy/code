/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText;

import javax.faces.component.UIComponent;

/**
 * Description: This class is the extension of @see AbstractInputTextTag with an extra setter and getter property called 
 * codesetname used to convert a String to CodeSetName and vice versa.
 * File: CodedInputTextTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CodedInputTextTag extends AbstractInputTextTag {
	/** The code set name. */
	private String codeSetName = null;
	/** The Office ID. */
	private String officeId = null;

	/**
	 * Instantiates a new coded input text tag.
	 */
	public CodedInputTextTag() {
		super();
	}

	/**
	 * Gets the code set name.
	 * 
	 * @return the codeSetName
	 */
	public String getCodeSetName() {
		return codeSetName;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return HtmlCodedInputText.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.CodedInputText";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#release()
	 */
	@Override
	public void release() {
		super.release();
		codeSetName = null;
		officeId = null;
	}

	/**
	 * Sets the code set name.
	 * 
	 * @param codeSetName the codeSet to set
	 */
	public void setCodeSetName(String codeSetName) {
		this.codeSetName = codeSetName;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		((HtmlCodedInputText) component).setCodeSetName(codeSetName);
		((HtmlCodedInputText) component).setOfficeId(officeId);
	}

	/**
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	/**
	 * @return the officeId
	 */
	public String getOfficeId() {
		return officeId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CodedInputTextTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/08 20:50:58  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
