package gov.ca.dmv.ease.ui.handler.impl;

import gov.ca.dmv.ease.app.action.IActionsRegistry;
import gov.ca.dmv.ease.app.action.impl.Action;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessage;
import gov.ca.dmv.ease.fw.error.impl.ErrorMessageCollector;
import gov.ca.dmv.ease.fw.logging.ILoggable;
import gov.ca.dmv.ease.fw.process.IProcessContext;
import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.process.IUserContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.ui.handler.IActionsHandler;
import gov.ca.dmv.ease.ui.handler.IHandlerTokenData;
import gov.ca.dmv.ease.ui.page.BasePage;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.MessageSource;

/**
 * Description: I handle button actions and building faces messages from message collector.
 *
 *  // FIXME Remove DL-specific logic, string literals, etc. out of this framework class
 *
 * File: ActionsHandler.java
 * Module:  gov.ca.dmv.ease.ui.handler.impl
 * Created: April, 2009
 * @author MWRRV3
 * @version $Revision: 1.5 $
 * Last Changed: $Date: 2013/09/03 17:49:28 $
 * Last Changed By: $Author: mwsec2 $
 */
public class ActionsHandler implements ILoggable, IActionsHandler {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6712969408465717766L;
	/** The Constant ACTION_IDENTIFIER_KEY. */
	private final static String ACTION_IDENTIFIER_KEY = "ACTION";
	/** The BUTTON s_ map. */
	private final static Map <String, String> BUTTONS_MAP = populateTheButtonsMap();
	/** The Constant BYPASS_VALIDATION_BUTTONS. */
	private final static String[] BYPASS_VALIDATION_BUTTONS = new String[] {
			"AccumulateFee", "AltPrint", "AnotherCo", "AnotherInquiry",
			"AnotherTry", "BrowseWithoutValidation", "Cancel",
			"CounselorReferral", "DeductFee", "Fallback", "FeeDetail",
			"FtaFtp", "ModifyAppInfo", "MoreActions", "MoreNames", "MoreTries",
			"NewInquiry", "Reprint", "ResetMode", "Restart", "Retry",
			"ServeAllMoreActions" };
	/** DL and ID ttc's. */
	private static final String[] DL_ID_INFO_MESSAGE = { "DLA", "DLC", "DLD",
			"DLE", "DLP", "DRT", "IDA", "IDS", "IDC", "IDP", "IRT", "30U" };
	/** DL ttc's. */
	private static final String[] DL_TTCS = { "DLA", "DLC", "DLD", "DLE",
			"DLP", "DRT" };
	/** ID ttc's. */
	private static final String[] ID_TTCS = { "IDA", "IDS", "IDC", "IDP", "IRT" };
	/** The BUILD number literal. */
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(ActionsHandler.class);

	/**
	 * Populate the buttons map.
	 */
	private static Map <String, String> populateTheButtonsMap() {
		HashMap <String, String> buttons = new HashMap <String, String>();
		buttons.put("Enter", "ENTER");
		buttons.put("Cancel", "CANCEL");
		buttons.put("CnaBypass", "CNA BYPASS");
		buttons.put("ReceiptOnly", "RECEIPT ONLY");
		buttons.put("Fallback", "Fallback");
		buttons.put("Restart", "RESTART");
		buttons.put("RestartWithValidation", "RESTART");
		buttons.put("BrowseWithoutValidation", "BROWSE");
		buttons.put("AnotherInquiry", "ANOTHER INQUIRY");
		buttons.put("FeeDetail", "FEE DETAIL");
		buttons.put("Reprint", "REPRINT");
		buttons.put("ResetMode", "RESET MODE");
		buttons.put("CounselorReferral", "COUNSELOR REFERRAL");
		buttons.put("CounselorInq", "COUNSELOR INQ");
		buttons.put("NoMoreTries", "NO MORE TRIES");
		buttons.put("MoreNames", "MORE NAMES");
		buttons.put("CollectData", "COLLECT DATA");
		buttons.put("UpdatePending", "UPDATE PENDING");
		buttons.put("Corrections", "CORRECTIONS");
		buttons.put("DafUpdate", "DAF UPDATE");
		buttons.put("PrintTestResults", "PRINT TEST RESULTS");
		buttons.put("Browse", "BROWSE");
		buttons.put("UpdateAll", "UPDATE ALL");
		buttons.put("Display", "DISPLAY");
		buttons.put("Purge", "PURGE");
		buttons.put("BrowseFwd", "BROWSE FWD");
		buttons.put("BrowseBwd", "BROWSE BWD");
		buttons.put("DisplayNext", "DISPLAY NEXT");
		buttons.put("AnotherForm", "ANOTHER FORM");
		buttons.put("RetainData", "RETAIN DATA");
		buttons.put("ModifyAppInfo", "MODIFY APP INFO");
		buttons.put("CustomerCopy", "CUSTOMER COPY");
		buttons.put("AnotherCo", "ANOTHER CO");
		buttons.put("AnotherTry", "ANOTHER TRY");
		buttons.put("UpdateOnly", "UPDATE ONLY");
		buttons.put("AdditionalRecord", "ADD'L R/C");
		buttons.put("Pay", "PAY");
		buttons.put("ServeAll", "SERVE ALL");
		buttons.put("MoreActions", "MORE ACTIONS");
		buttons.put("ServeAllMoreActions", "SERVE ALL/MORE ACTIONS");
		buttons.put("FtaFtp", "FTA/FTP LIST");
		buttons.put("MoreTries", "MORE TRIES");
		buttons.put("NewInquiry", "NEW INQUIRY");
		buttons.put("Suspense", "SUSPENSE");
		buttons.put("Retry", "RETRY");
		buttons.put("Problem", "PROBLEM");
		buttons.put("AccumulateFee", "ACCUMULATE FEE");
		buttons.put("DeductFee", "DEDUCT FEE");
		buttons.put("NewRequest", "NEW REQUEST");
		buttons.put("AltPrint", "ALTERNATE PRINTER");
		buttons.put("DatabaseStatus", "DATABASE STATUS");
		return buttons;
	}

	/** Build Information from build.properties file. */
	private transient MessageSource buildInfo;
	/** The button1. */
	protected transient HtmlCommandButton button1; //FIXME replace with List<HtmlCommandButton>
	/** The button10. */
	protected transient HtmlCommandButton button10; //FIXME replace with List<HtmlCommandButton>
	/** The button11. */
	protected transient HtmlCommandButton button11; //FIXME replace with List<HtmlCommandButton>
	/** The button12. */
	protected transient HtmlCommandButton button12; //FIXME replace with List<HtmlCommandButton>
	/** The button2. */
	protected transient HtmlCommandButton button2; //FIXME replace with List<HtmlCommandButton>
	/** The button3. */
	protected transient HtmlCommandButton button3; //FIXME replace with List<HtmlCommandButton>
	/** The button4. */
	protected transient HtmlCommandButton button4; //FIXME replace with List<HtmlCommandButton>
	/** The button5. */
	protected transient HtmlCommandButton button5; //FIXME replace with List<HtmlCommandButton>
	/** The button6. */
	protected transient HtmlCommandButton button6; //FIXME replace with List<HtmlCommandButton>
	/** The button7. */
	protected transient HtmlCommandButton button7; //FIXME replace with List<HtmlCommandButton>
	/** The button8. */
	protected transient HtmlCommandButton button8; //FIXME replace with List<HtmlCommandButton>
	/** The button9. */
	protected transient HtmlCommandButton button9; //FIXME replace with List<HtmlCommandButton>
	/** Messages for business validations. */
	private transient MessageSource messagesBus;
	/** The session context. */
	private transient ISessionContext sessionContext;
	/** The terminal id. */
	private transient String terminalId;
	/** The token. */
	private transient String token; //TODO - why an instance variable at all?
	/** The view id. */
	private transient String viewId;//TODO - why an instance variable at all?

	/**
	 * Instantiates a new actions handler.
	 */
	public ActionsHandler() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#buildFacesMessages(gov.ca.dmv.ease.app.context.impl.ProcessContext)
	 */
	public void buildFacesMessages(ProcessContext context) {
		Map <String, ErrorMessage> errors = context.getValidationMessages();
		FacesContext facesContext = FacesContext.getCurrentInstance();
		for (String errorKey : errors.keySet()) {
			String errorField = errors.get(errorKey).getErrorField();
			String[] messageParams = errors.get(errorKey) != null ? errors.get(
					errorKey).getMessageParameters() : null;
			String errorMessage = messagesBus.getMessage(errorKey,
					messageParams, "Default", null);
			StringBuilder errorMessageWithCode = new StringBuilder("");
			// Check if the error message is not default then prepend error code
			// with error message otherwise return the error code only.
			errorMessageWithCode.append(errorKey != null ? errorKey
					.toUpperCase() : errorKey);
			if (!"Default".equalsIgnoreCase(errorMessage)) {
				errorMessageWithCode.append(" - ").append(
						errorMessage != null ? errorMessage.toUpperCase() : "")
						.append("-brErrorMsg");
			}
			else {
				errorMessageWithCode.append("-brErrorMsg");
				logError(errorKey, context);
			}
			//FCP TTC, if you get an information message without error code then
			//show only the error message (no error code).
			if ("UPDATE_ONLY_INFO_MESSAGE".equalsIgnoreCase(errorKey)) {
				errorMessageWithCode = new StringBuilder();
				errorMessageWithCode.append(errorMessage).append("-brErrorMsg");
			}
			FacesMessage facesMessage = new FacesMessage(errorMessageWithCode
					.toString(), errorField == null ? "" : errorField);
			facesContext.addMessage(null, facesMessage);
		}
		errors.clear();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#buttonAction()
	 */
	public String buttonAction() {
		//TODO - why public? method not called
		BasePage page = null;
		String buttonName = "";
		try {
			// Invoke framework methods
			ProcessContext context = ((ProcessContext) EaseProxyUtils
					.getProxyObject(getCurrentProcessContext()));
			buttonName = context.getSelectedAction() != null ? context
					.getSelectedAction().getName() : "";
			page = getPage();
			if (page != null) {
				if (!buttonName.equalsIgnoreCase("RESTART")
						&& !buttonName.equalsIgnoreCase("CANCEL")) {
					page.submitPreProcessing();
				}
			}
			//Right now we implemented the invoking BR validations in backing bean for test results 1 and test results 2.
			if (page != null
					&& ("EnterTestResultsPage".equalsIgnoreCase(page
							.getBackingName()) || "EnterCdlTestResultsPage"
							.equalsIgnoreCase(page.getBackingName()))) {
				//If any validation errors (backing bean invoke BR validations) convert them and set it to faces context.
				if (!buttonName.equalsIgnoreCase("RESTART")
						&& !buttonName.equalsIgnoreCase("CANCEL")
						&& context.hasValidationErrors()) {
					buildFacesMessages(context);
					//Return to the same page
					return "";
				}
				else {
					//If the button is Restart or Cancel then set the validations to empty in order to proceed.
					context
							.setValidationMessageObject(new ErrorMessageCollector());
				}
			}
			//Activity interaction
			context.resume(null);
			// Check if any Validation Messages Exist
			boolean ifErrors = context.hasValidationErrors();
			//Invoke Setup buttons to get the latest buttons (some time buttons are not refreshing)
			setupButtons();
			if (ifErrors) {
				//Convert the errors and set it to faces context.
				buildFacesMessages(context);
				if (page != null
						&& ("EnterTestResultsPage".equalsIgnoreCase(page
								.getBackingName()) || "EnterCdlTestResultsPage"
								.equalsIgnoreCase(page.getBackingName()))) {
					//If any validation errors (backing bean invoke BR validations) convert them and set it to faces context.
					if (buttonName.equalsIgnoreCase("ENTER")
							|| buttonName.equalsIgnoreCase("CORRECTIONS")
							|| buttonName.equalsIgnoreCase("UPDATEPENDING")
							|| buttonName.equalsIgnoreCase("DAFUPDATE")
							|| buttonName.equalsIgnoreCase("PRINTTESTRESULTS")) {
						//Return to the same page
						return "";
					}
				}
			}
		}
		catch (Exception e) {
			FacesUtils
					.addErrorMessage("There was a problem executing the process.  The error received was "
							+ e.getMessage());
			handleException(e, getCurrentProcessContext());
		}
		return ((ProcessContext) EaseProxyUtils.getProxyObject(this
				.getCurrentProcessContext())).getCurrentInteractionActivity()
				.getClass().getSimpleName();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#buttonActionEvent(javax.faces.event.ActionEvent)
	 */
	public void buttonActionEvent(ActionEvent actionEvent) {
		((ProcessContext) EaseProxyUtils.getProxyObject(this
				.getCurrentProcessContext()))
				.setSelectedAction((Action) actionEvent.getComponent()
						.getAttributes().get(ACTION_IDENTIFIER_KEY));
	}

	/**
	 * Cause all buttons not to render
	 * Note: Assume all buttons not rendered.
	 */
	private void disableAllButtons() {
		getButton1().setRendered(false);
		getButton2().setRendered(false);
		getButton3().setRendered(false);
		getButton4().setRendered(false);
		getButton5().setRendered(false);
		getButton6().setRendered(false);
		getButton7().setRendered(false);
		getButton8().setRendered(false);
		getButton9().setRendered(false);
		getButton10().setRendered(false);
		getButton11().setRendered(false);
		getButton12().setRendered(false);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#generateToken()
	 */
	public String generateToken() {
		// TODO replace with UUID
		//FIXME - should be called from getToken, and most likely does not need an instance variable
		//FIXME - token and viewid are accessed from a single method: gov.ca.dmv.ease.ui.util.impl.SynchronizationFilter.doFilter(ServletRequest, ServletResponse, FilterChain)
		token = Long.toString(System.currentTimeMillis());
		viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		// path = FacesUtils.getFacesContext().getExternalContext().getRequestServletPath();
		return token;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getBuildInfo()
	 */
	public MessageSource getBuildInfo() {
		return buildInfo;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getBuildNumber()
	 */
	public String getBuildNumber() {
		return buildInfo.getMessage("BUILD_NUMBER", null, "Default", null);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton1()
	 */
	public HtmlCommandButton getButton1() {
		return button1;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton10()
	 */
	public HtmlCommandButton getButton10() {
		return button10;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton11()
	 */
	public HtmlCommandButton getButton11() {
		return button11;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton12()
	 */
	public HtmlCommandButton getButton12() {
		return button12;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton2()
	 */
	public HtmlCommandButton getButton2() {
		return button2;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton3()
	 */
	public HtmlCommandButton getButton3() {
		return button3;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton4()
	 */
	public HtmlCommandButton getButton4() {
		return button4;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton5()
	 */
	public HtmlCommandButton getButton5() {
		return button5;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton6()
	 */
	public HtmlCommandButton getButton6() {
		return button6;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton7()
	 */
	public HtmlCommandButton getButton7() {
		return button7;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton8()
	 */
	public HtmlCommandButton getButton8() {
		return button8;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getButton9()
	 */
	public HtmlCommandButton getButton9() {
		return button9;
	}

	/**
	 * Gets the button name.
	 *
	 * @param value the value
	 * @return the button name
	 */
	private String getButtonName(String value) {
		return BUTTONS_MAP.get(value);
	}

	/**
	 * Checks if is bypass validation.
	 *
	 * @param name the name
	 * @return true, if is bypass validation
	 */
	private boolean getBypassValidation(String name) {
		return ArrayUtils.contains(BYPASS_VALIDATION_BUTTONS, name);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getContextPath()
	 */
	public String getContextPath() {
		String strContextPath = FacesUtils.getFacesContext()
				.getExternalContext().getRequestContextPath();
		return strContextPath.substring(1);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getCurrentMasterFileStatus()
	 */
	public String getCurrentMasterFileStatus() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getCurrentMode()
	 */
	public String getCurrentMode() {
		try {
			if (getCurrentProcessContext() != null
					&& getCurrentProcessContext().getUserContext() != null
					&& getCurrentProcessContext().getUserContext()
							.getFunctionalMode() != null
					&& getCurrentProcessContext().getUserContext()
							.getOperationalMode() != null) {
				return getCurrentProcessContext().getUserContext()
						.getOperationalMode().getCode()
						+ ""
						+ getCurrentProcessContext().getUserContext()
								.getFunctionalMode().getCode();
			}
		}
		catch (Exception e) {
			handleException(e, getCurrentProcessContext());
		}
		return "";
	}

	/**
	 * Gets the current process context.
	 *
	 * @return the current process context
	 */
	protected IProcessContext getCurrentProcessContext() {
		return getSessionContext().getCurrentProcessContext();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getCurrentProcessorPartnerStatus()
	 */
	public String getCurrentProcessorPartnerStatus() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getCurrentScreenName()
	 */
	public String getCurrentScreenName() {
		String viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		return ArrayUtils.capitalize(viewId.substring(
				viewId.lastIndexOf("/") + 1, viewId.indexOf(".jspx")));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getLastCashierSeqNumber()
	 */
	public String getLastCashierSeqNumber() {
		return "2"; //null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getLastRatingSeqNumber()
	 */
	public String getLastRatingSeqNumber() {
		return null;
	}

	/**
	 * Gets the page.
	 *
	 * @return the page
	 */
	private BasePage getPage() {
		String pageName = null;
		pageName = FacesUtils.getRequestParameter("MAIN_FORM:PageName");
		if (pageName == null) {
			return null;
		}
		return (BasePage) FacesUtils.getManagedBean(pageName);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getPrevScreenName()
	 */
	public String getPrevScreenName() {
		return null;
	}

	//	/**
	//	 * Gets the next activity.
	//	 *
	//	 * @return the next activity
	//	 */
	//	public InteractionActivity getNextInteractionActivity() {
	//		return (InteractionActivity) getCurrentProcessContext()
	//				.getNextActivity();
	//	}
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getProcessorId()
	 */
	public String getProcessorId() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getProcessorMode()
	 */
	public String getProcessorMode() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getRdfSuspenseStatus()
	 */
	public String getRdfSuspenseStatus() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getSelectedAction(javax.faces.event.ActionEvent)
	 */
	public String getSelectedAction(ActionEvent actionEvent) {
		return (String) actionEvent.getComponent().getAttributes().get(
				ACTION_IDENTIFIER_KEY);
	}

	/**
	 * Return top level ProcessContext
	 *
	 * Note: The top level ProcessContext is always of
	 * type SessionContext.
	 *
	 * @return SessionContext
	 */
	private ISessionContext getSessionContext() {
		return sessionContext;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getSystemMilitaryTime()
	 */
	public String getSystemMilitaryTime() {
		return ArrayUtils.capitalize(now("HH:mm"));
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getTerminalId()
	 */
	public String getTerminalId() {
		IUserContext userContext = getCurrentProcessContext().getUserContext();
		if ((userContext != null) && (userContext.getStationId() != null)) {
			terminalId = getCurrentProcessContext().getUserContext()
					.getStationId();
		}
		return terminalId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getToken()
	 */
	public String getToken() {
		//TODO -token can be generated on demand - can it not?
		return token;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getTokenData()
	 */
	public IHandlerTokenData getTokenData() {
		return new HandlerTokenData(getToken(), getViewId());
	}

	//Operator and Page Info details
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getTransactionScreenId()
	 */
	public String getTransactionScreenId() {
		String viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		String screenName = viewId.substring(viewId.lastIndexOf("/") + 1,
				viewId.indexOf(".jspx"));
		if (screenName != null) {
			screenName = String.valueOf(Character.toUpperCase(screenName
					.charAt(0)))
					+ screenName.substring(1);
		}
		return screenName;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getTypeTransactionCode()
	 */
	public String getTypeTransactionCode() {
		IUserContext userContext = getCurrentProcessContext().getUserContext();
		if ((userContext != null) && (userContext.getTtc() != null)) {
			if ("DLMENU".equalsIgnoreCase(userContext.getTtc().toUpperCase())) {
				return "";
			}
			else {
				return userContext.getTtc().toUpperCase();
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getViewId()
	 */
	public String getViewId() {
		return viewId;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getWorkDate()
	 */
	public Date getWorkDate() {
		return CurrentDateProvider.getInstance().getCurrentDate();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#getWorkSetId()
	 */
	public String getWorkSetId() {
		String officeId = (getCurrentProcessContext().getUserContext()
				.getOfficeId() == null) ? "" : getCurrentProcessContext()
				.getUserContext().getOfficeId();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("DDD");
		String dayOfYear = (getCurrentProcessContext().getUserContext()
				.getWorkDate() == null) ? "" : simpleDateFormat.format(this
				.getCurrentProcessContext().getUserContext().getWorkDate());
		String employeeId = (getCurrentProcessContext().getUserContext()
				.getTechId() == null) ? "" : getCurrentProcessContext()
				.getUserContext().getTechId();
		return (officeId != null ? officeId.toUpperCase() : "") + dayOfYear
				+ (employeeId != null ? employeeId.toUpperCase() : "");
	}

	/**
	 * Handles the exception.
	 * 
	 * @param e the exception
	 * @param processContext the process context
	 */
	protected void handleException(Exception e, IProcessContext processContext) {
		//Note: aspect uses the process context for state info
		logError(ExceptionUtils.getStackTrace(e), processContext);
	}

	/**
	 * @param errorMessage
	 * @param processContext
	 */
	protected void logError(String errorMessage, IProcessContext processContext) {
		StringBuilder logMessage = new StringBuilder();
		logMessage.append("\nERROR INCIDENT ").append("\n");
		logMessage.append("REQUEST URI: ").append(
				FacesUtils.getRequest().getRequestURI()).append("\n");
		logMessage.append("CURRENT ACTIVITY: ").append(
				processContext.getCurrentActivity().getActivityName()).append(
				"\n");
		logMessage.append("CURRENT TTC: ").append(
				processContext.getUserContext().getTtc()).append("\n");
		logMessage.append("ERROR INFO: ").append(errorMessage).append("\n");
		logMessage.append("USER INFO: ").append(
				processContext.getUserContext().toString()).append("\n");
		LOGGER.error(logMessage.toString());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#mockButtonAction()
	 */
	public String mockButtonAction() {
		return FacesUtils.getRequestParameter("MAIN_FORM:PageName");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#now(java.lang.String)
	 */
	public String now(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
		return simpleDateFormat.format(cal.getTime());
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.fw.logging.ILoggable#outputAppLog(java.lang.StringBuilder)
	 */
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#outputAppLog(java.lang.StringBuilder)
	 */
	public void outputAppLog(StringBuilder aStringBuilder) {
		aStringBuilder.append("CREATED_BY="
				+ ((UserContext) getCurrentProcessContext().getUserContext())
						.getUserName() + ",");
		aStringBuilder.append("CREATED_DATE="
				+ Calendar.getInstance().getTime() + ",");
		aStringBuilder.append("LOG_ENTRY=");
		Map <String, ErrorMessage> errors = getCurrentProcessContext()
				.getMessageCollector().getValidationMessages();
		for (String errorKey : errors.keySet()) {
			String errorMessage = errors.get(errorKey).getErrorText();
			aStringBuilder.append(errorMessage + ";");
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#popupButtonAction()
	 */
	public String popupButtonAction() {
		BasePage page = null;
		try {
			page = getPage();
			if (page != null) {
				page.submitPreProcessing();
			}
		}
		catch (Exception e) {
			FacesUtils
					.addErrorMessage("There was a problem executing the process of popup page.  The error received was "
							+ e.getMessage());
			handleException(e, getCurrentProcessContext());
		}
		return "CloseWindow";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setBuildInfo(org.springframework.context.MessageSource)
	 */
	public void setBuildInfo(MessageSource buildInfo) {
		this.buildInfo = buildInfo;
	}

	/**
	 * Sets the action decorators.
	 *
	 * @param aButton the new button1
	 */
	/*	public void setActionDecorators(Map <String, UiActionDecorator> aMap) {
			actionDecorators = aMap;
		}*/
	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton1(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton1(HtmlCommandButton aButton) {
		button1 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton10(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton10(HtmlCommandButton aButton) {
		button10 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton11(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton11(HtmlCommandButton aButton) {
		button11 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton12(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton12(HtmlCommandButton aButton) {
		button12 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton2(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton2(HtmlCommandButton aButton) {
		button2 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton3(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton3(HtmlCommandButton aButton) {
		button3 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton4(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton4(HtmlCommandButton aButton) {
		button4 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton5(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton5(HtmlCommandButton aButton) {
		button5 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton6(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton6(HtmlCommandButton aButton) {
		button6 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton7(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton7(HtmlCommandButton aButton) {
		button7 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton8(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton8(HtmlCommandButton aButton) {
		button8 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setButton9(javax.faces.component.html.HtmlCommandButton)
	 */
	public void setButton9(HtmlCommandButton aButton) {
		button9 = aButton;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setMessagesBus(org.springframework.context.MessageSource)
	 */
	public void setMessagesBus(MessageSource aSource) {
		messagesBus = aSource;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setSessionContext(gov.ca.dmv.ease.fw.process.ISessionContext)
	 */
	public void setSessionContext(ISessionContext aCtx) {
		sessionContext = aCtx;
	}

	/**
	 * Setup the HtmlCommandButton.
	 *
	 * @param index the index
	 * @param action the action
	 * @param buttonName the button name
	 * @param bypassValidation the bypass validation
	 */
	/*@SuppressWarnings("unchecked")
	private void setupButton(boolean bypassValidation, String value,
				Action action, int index) {
			HtmlCommandButton button = getButton(index);
			button.setRendered(true);
			button.setDisabled(!action.isEnabled());
			button.setValue(getButtonName(value));
			button.setImmediate(bypassValidation);
			button.getAttributes().put(ACTION_IDENTIFIER_KEY, action);
	}*/
	/**
	 * Set up a button based on the parameters.
	 */
	@SuppressWarnings("unchecked")
	private void setupButton(int index, Action action, String buttonName,
			boolean bypassValidation) {
		switch (index) {
		case 1:
			getButton1().setRendered(true);
			getButton1().setDisabled(!action.isEnabled());
			getButton1().setValue(buttonName);
			if (getCurrentScreenName().equals("Ftaftpreleasecertupdate")
					&& action.getKey().equals(IActionsRegistry.BROWSE_ACTION)) {
				getButton1().setImmediate(true);
			}
			else {
				getButton1().setImmediate(bypassValidation);
			}
			getButton1().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			//getButton1().setOnclick("return processButtonAction();");
			//For the CollectAddress page we need to show the status bar.
			String ttc = ((ProcessContext) EaseProxyUtils.getProxyObject(this
					.getCurrentProcessContext())).getUserContext().getTtc();
			if (ArrayUtils.contains(DL_ID_INFO_MESSAGE, ttc)) {
				String pageName = getTransactionScreenId();
				if (pageName != null
						&& ("CollectAddress".equalsIgnoreCase(pageName))) {
					getButton1().setOnclick("return processButtonAction();");
				}
				else if ("CdlisPdpsInquiry".equalsIgnoreCase(pageName)) {
					if (ArrayUtils.contains(DL_TTCS, ttc)) {
						getButton1()
								.setOnclick("return processSsnDLInquiry();");
					}
					else if (ArrayUtils.contains(ID_TTCS, ttc)) {
						getButton1()
								.setOnclick("return processSsnIDInquiry();");
					}
				}
				else if ("collectApplicationInfo".equalsIgnoreCase(pageName)) {
					getButton1()
							.setOnclick(
									"return processDlIdInquiryForCollectAppInfoPage();");
				}
				else {
					getButton1().setOnclick(null);
				}
			}
			break;
		case 2:
			getButton2().setRendered(true);
			getButton2().setDisabled(!action.isEnabled());
			getButton2().setValue(buttonName);
			getButton2().setImmediate(bypassValidation);
			getButton2().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			/*if (buttonName.equalsIgnoreCase("CNA BYPASS")) {
				getButton2().setDisabled(true);
			}
			else {
				getButton2().setDisabled(false);
			}*/
			break;
		case 3:
			getButton3().setRendered(true);
			getButton3().setDisabled(!action.isEnabled());
			getButton3().setValue(buttonName);
			getButton3().setImmediate(bypassValidation);
			if (buttonName.equalsIgnoreCase("Exit")) {
				getButton3().setOnclick("return invalidateSession()");
			}
			else {
				getButton3().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			}
			break;
		case 4:
			getButton4().setRendered(true);
			getButton4().setDisabled(!action.isEnabled());
			getButton4().setValue(buttonName);
			getButton4().setImmediate(bypassValidation);
			getButton4().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			if (buttonName.equalsIgnoreCase("COUNSELOR REFERRAL")) {
				getButton4().setDisabled(true);
			}
			else {
				getButton4().setDisabled(false);
			}
			break;
		case 5:
			getButton5().setRendered(true);
			getButton5().setDisabled(!action.isEnabled());
			getButton5().setValue(buttonName);
			getButton5().setImmediate(bypassValidation);
			getButton5().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			if (buttonName.equalsIgnoreCase("Ignore")
					|| buttonName.equalsIgnoreCase("Reset")) {
				getButton5().setDisabled(true);
			}
			else {
				getButton5().setDisabled(false);
			}
			break;
		case 6:
			getButton6().setRendered(true);
			getButton6().setDisabled(!action.isEnabled());
			getButton6().setValue(buttonName);
			getButton6().setImmediate(bypassValidation);
			getButton6().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		case 7:
			getButton7().setRendered(true);
			getButton7().setDisabled(!action.isEnabled());
			getButton7().setValue(buttonName);
			String pageName = getTransactionScreenId();
			if (pageName != null
					&& ("EnterCdlTestResults".equalsIgnoreCase(pageName))
					&& action.getKey().equals(IActionsRegistry.FALLBACK)) {
				getButton7().setImmediate(false);
			}
			else {
				getButton7().setImmediate(bypassValidation);
			}
			getButton7().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		case 8:
			getButton8().setRendered(true);
			getButton8().setDisabled(!action.isEnabled());
			getButton8().setValue(buttonName);
			getButton8().setImmediate(bypassValidation);
			getButton8().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			if (buttonName.equalsIgnoreCase("Print All")) {
				getButton8().setOnclick("printTextAreaContent()");
			}
			if (buttonName.equalsIgnoreCase("Print")) {
				getButton8().setOnclick("printPanelContent()");
			}
			break;
		case 9:
			getButton9().setRendered(true);
			getButton9().setDisabled(!action.isEnabled());
			getButton9().setValue(buttonName);
			getButton9().setImmediate(bypassValidation);
			getButton9().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		case 10:
			getButton10().setRendered(true);
			getButton10().setDisabled(!action.isEnabled());
			getButton10().setValue(buttonName);
			getButton10().setImmediate(bypassValidation);
			getButton10().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		case 11:
			getButton11().setRendered(true);
			getButton11().setDisabled(!action.isEnabled());
			getButton11().setValue(buttonName);
			getButton11().setImmediate(bypassValidation);
			getButton11().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		case 12:
			getButton12().setRendered(true);
			getButton12().setDisabled(!action.isEnabled());
			getButton12().setValue(buttonName);
			getButton12().setImmediate(bypassValidation);
			getButton12().getAttributes().put(ACTION_IDENTIFIER_KEY, action);
			break;
		default:
			break;
		}
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.handler.impl.IA#setupButtons()
	 */
	public void setupButtons() {
		List <Action> availableActions = (getCurrentProcessContext()
				.getCurrentInteractionActivity())
				.getAvailableActions((ProcessContext) EaseProxyUtils
						.getProxyObject(getCurrentProcessContext()));
		//UiActionDecorator uiActionDecorator;
		disableAllButtons();
		int index = 1;
		for (Action action : availableActions) {
			setupButton(index, action, getButtonName(action.getName()),
					getBypassValidation(action.getName()));
			index++;
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: ActionsHandler.java,v $
 *  Revision 1.5  2013/09/03 17:49:28  mwsec2
 *  instances variables made transient to fix non-serializable issue
 *
 *  Revision 1.4  2013/05/10 22:59:01  mwskh1
 *  CDLIS 5.2 - made getCurrentProcessContext protected
 *
 *  Revision 1.3  2013/05/07 23:14:57  mwsec2
 *  changed the initialization of the buttons map so that it is done at class load (avoid threadsafety issue); removed unused methods
 *
 *  Revision 1.2  2013/05/06 20:49:59  mwsec2
 *  enhanced error message info to log
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.152  2012/09/28 18:39:38  mwkfh
 *  added handleException
 *
 *  Revision 1.151  2012/09/27 00:18:41  mwpxp2
 *  Added serialVersionUID
 *
 *  Revision 1.150  2012/09/27 00:11:10  mwpxp2
 *  Implemented IActionsHandler; not abstract yet
 *
 *  Revision 1.149  2012/08/15 23:17:41  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.148  2012/07/17 23:44:03  mwrrv3
 *  Removed CounselorInq button from the bypass validations (defect# 1168).
 *
 *  Revision 1.147  2012/06/01 21:40:51  mwhys
 *  Access modifier of buildFacesMessages() is changed from private to public. (Session Management)
 *
 *  Revision 1.146  2012/03/27 23:05:23  mwpxp2
 *  Added IHandlerTokenData getTokenData()
 *
 *  Revision 1.145  2011/12/14 22:55:22  mwhys
 *  Removed cnabypass from BYPASS_VALIDATION_BUTTONS.
 *
 *  Revision 1.144  2011/12/06 00:33:37  mwhys
 *  Added CounselorInq to BYPASS_VALIDATION_BUTTONS. (Defect 1055)
 *
 *  Revision 1.143  2011/11/01 00:09:17  mwrrv3
 *  Added Another Try button to the bypass validation array so that system can bypass validations.
 *
 *  Revision 1.142  2011/10/01 00:58:41  mwrrv3
 *  Remove code related to HELP content.
 *
 *  Revision 1.141.4.1  2011/09/30 23:22:56  mwrrv3
 *  Remove code related to HELP content.
 *
 *  Revision 1.141  2011/08/22 23:45:24  mwsyk1
 *  Updated actions handler because setup buttons are incorrect.
 *
 *  Revision 1.140  2011/08/17 17:33:03  mwark
 *  Database status button is added.
 *
 *  Revision 1.139  2011/08/16 20:06:49  mwpxp2
 *  Added todos and fixmes
 *
 *  Revision 1.138  2011/08/16 00:21:22  mwark
 *  Modified to follow naming conventions and changed method access for few methods.
 *
 *  Revision 1.137  2011/08/13 22:37:38  mwrrv3
 *  Updated for memory issues, removed UiActionsDecorator usage.
 *
 *  Revision 1.136  2011/06/10 23:13:14  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.135  2011/06/09 18:39:43  mwyxg1
 *  clean up
 *
 *  Revision 1.134  2011/06/03 03:16:48  mwrka1
 *  reverted back latest verson
 *
 *  Revision 1.132  2011/04/13 18:20:40  mwrrv3
 *  Added buildInfo property to get the build number from properties file.
 *
 *  Revision 1.131  2011/04/12 00:23:25  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.130  2011/04/07 23:21:58  mwkkc
 *  Version Update
 *
 *  Revision 1.129  2011/04/07 23:01:47  mwkkc
 *  Version Update
 *
 *  Revision 1.128  2011/04/07 04:04:40  mwhys
 *  Merged CopyFunctionality branch into HEAD.
 *
 *  Revision 1.127  2011/04/06 20:48:16  mwkkc
 *  Version Update BCTR plus Copy
 *
 *  Revision 1.126  2011/03/31 20:37:13  mwkkc
 *  Version Update
 *
 *  Revision 1.125  2011/03/30 18:21:32  mwkkc
 *  Version Update
 *
 *  Revision 1.124  2011/03/22 23:46:07  mwkkc
 *  Version Update
 *
 *  Revision 1.123  2011/03/21 22:57:12  mwkkc
 *  Version Update
 *
 *  Revision 1.122  2011/03/18 01:49:18  mwkkc
 *  Version Update
 *
 *  Revision 1.121  2011/03/17 00:43:31  mwkkc
 *  Version Update
 *
 *  Revision 1.120  2011/03/15 22:37:30  mwkkc
 *  Version Update
 *
 *  Revision 1.119  2011/03/15 02:58:16  mwkkc
 *  Version Update
 *
 *  Revision 1.118  2011/03/14 06:29:37  mwkkc
 *  Version Update
 *
 *  Revision 1.117  2011/03/13 15:56:00  mwkkc
 *  Version Update
 *
 *  Revision 1.116  2011/03/12 23:21:16  mwkkc
 *  Version Update
 *
 *  Revision 1.115  2011/03/10 17:48:13  mwkkc
 *  Version Update
 *
 *  Revision 1.114  2011/03/07 01:25:10  mwkkc
 *  Version Update
 *
 *  Revision 1.113  2011/03/05 23:10:54  mwkkc
 *  Version Update
 *
 *  Revision 1.112  2011/03/03 19:55:37  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.111  2011/03/03 19:54:35  mwsyk1
 *  Reverted to version 1.108
 *
 *  Revision 1.108  2011/02/23 18:53:47  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.107  2011/02/17 20:08:21  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.106  2011/02/14 00:44:20  mwkkc
 *  6.0.2.2
 *
 *  Revision 1.105  2011/02/13 23:37:50  mwkkc
 *  2.0.6.3
 *
 *  Revision 1.104  2011/02/13 02:59:04  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.103  2011/02/12 00:20:21  mwkkc
 *  2.0.6.1
 *
 *  Revision 1.102  2011/02/11 05:56:15  mwkkc
 *  After code review
 *
 *  Revision 1.101  2011/02/10 17:41:23  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.100  2011/02/09 18:05:19  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.99  2011/02/08 00:32:56  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.98  2011/02/07 17:32:59  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.97  2011/02/04 22:33:56  mwnrk
 *  INQUIRY IN PROCESS informational message code added.
 *
 *  Revision 1.96  2011/02/02 23:33:23  mwhys
 *   Build Number Updated.
 *
 *  Revision 1.95  2011/02/02 01:00:01  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.94  2011/02/01 19:20:09  mwrrv3
 *  Removed onclick for second button.
 *
 *  Revision 1.93  2011/01/30 02:46:59  mwrrv3
 *  Updated the build number to 8b9.
 *
 *  Revision 1.92  2011/01/29 03:24:28  mwjxa11
 *  Updated with new build number
 *
 *  Revision 1.91  2011/01/28 16:57:08  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.90  2011/01/25 23:25:50  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.89  2011/01/25 00:29:15  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.88  2011/01/22 17:26:17  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.87  2011/01/21 16:20:20  mwrxn3
 *  Build Number Updated
 *
 *  Revision 1.86  2011/01/21 01:32:24  mwjxa11
 *  Updated
 *
 *  Revision 1.85  2011/01/19 20:34:57  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.84  2011/01/18 02:13:21  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.83  2011/01/15 20:24:36  mwpxp2
 *  Made build number static; cleaned up; added missing javadoc; added todos
 *
 *  Revision 1.82  2011/01/15 18:41:36  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.81  2011/01/14 23:06:43  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.80  2011/01/13 18:30:48  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.79  2011/01/13 18:12:58  mwsyk1
 *  Build Number Updated
 *
 *  Revision 1.78  2011/01/07 20:07:41  mwrrv3
 *  Added code related to counselor inquiry button in the inquiry response screen.
 *
 *  Revision 1.77  2011/01/05 03:41:33  mwsyk1
 *  build number updated
 *
 *  Revision 1.76  2011/01/04 23:00:59  mwsyk1
 *  Build number updated
 *
 *  Revision 1.75  2011/01/04 22:54:36  mwsyk1
 *  Build number added
 *
 *  Revision 1.74  2011/01/01 00:30:29  mwrka1
 *  Updated
 *
 *  Revision 1.73  2010/12/30 23:55:06  mwrrv3
 *  Moved setupButtons to before checking errors.
 *
 *  Revision 1.72  2010/12/28 00:27:12  mwnrk
 *  Fix for Informational Messages.
 *
 *  Revision 1.71  2010/12/27 00:38:20  mwrrv3
 *  Fixed the getWorkSetId method to get the upper case letters.
 *
 *  Revision 1.70  2010/12/24 19:14:44  mwnrk
 *  Fix for INS Inquiry in process , Informational Message.
 *
 *  Revision 1.69  2010/12/16 18:55:29  mwnrk
 *  code added to support ssnInquiry is in process Informational Message.
 *
 *  Revision 1.68  2010/12/15 18:19:27  mwsec2
 *  fixme added
 *
 *  Revision 1.67  2010/12/12 00:47:24  mwgxk2
 *  Terminal Id Fix.
 *
 *  Revision 1.66  2010/12/11 19:49:15  mwnrk
 *  Fix for Informational Message.
 *
 *  Revision 1.65  2010/12/09 22:11:46  mwrrv3
 *  Updated the logic for buildFacesMessage to support both error messages with and without error code.
 *
 *  Revision 1.64  2010/12/04 19:27:51  mwrrv3
 *  Added null check for errorField.
 *
 *  Revision 1.63  2010/12/03 21:02:05  mwrrv3
 *  Update the code to support business rule validation field focus.
 *
 *  Revision 1.62  2010/12/03 02:34:25  mwrrv3
 *  getWorkDate method set the date as Current Date instead of Work Date -- Amar Bade
 *
 *  Revision 1.61  2010/12/01 01:30:09  mwtjc1
 *  For Ftaftpreleasecertupdate page, Browse button's immediate property is set to ture in setupButton method
 *
 *  Revision 1.60  2010/11/24 22:20:05  mwnrk
 *  Code implemented for Informational Messages.
 *
 *  Revision 1.59  2010/11/08 00:58:38  mwrrv3
 *  Updated the code to support DAF Update and Print Test Results.
 *
 *  Revision 1.58  2010/11/07 22:36:54  mwrrv3
 *  Removed start clock functionality.
 *
 *  Revision 1.57  2010/11/04 20:15:53  mwtjc1
 *  setupButtons() is called before buildFacesMessage method
 *
 *  Revision 1.56  2010/10/14 21:14:32  mwrrv3
 *  Added UPDATEPENDING button to the if condition, defect# 2252.
 *
 *  Revision 1.55  2010/10/11 18:41:45  mwrrv3
 *  Updated the code to support Modify Test Results.
 *
 *  Revision 1.54  2010/10/07 17:26:41  mwrrv3
 *  Fixed the footer related issues (current mode).
 *
 *  Revision 1.53  2010/09/28 18:07:55  mwtjc1
 *  buildFacesMessages is changed to support error message parameters
 *
 *  Revision 1.52  2010/09/28 17:34:25  mwpxp2
 *  Removed 128 occurrences of this~
 *
 *  Revision 1.51  2010/09/28 16:39:12  mwazg5
 *  Cleaned up '.this' from disableAllButtons function
 *
 *  Revision 1.50  2010/09/27 17:13:02  mwazg5
 *  Cleaned up the TODO for temporary fix with session management.
 *
 *  Revision 1.49  2010/09/25 00:46:25  mwazg5
 *  Changed the disableAllButtons to remove the checks for null for all buttons
 *
 *  Revision 1.48  2010/09/13 04:39:52  mwhys
 *  Made all the Rules and Services static for Session Management.
 *
 *  Revision 1.47  2010/09/07 23:47:48  mwrrv3
 *  Added code to support the test results 1 & 2 validation error messages.
 *
 *  Revision 1.46  2010/08/16 19:23:56  mwkkc
 *  Different method call for setting StartClock.
 *
 *  Revision 1.45  2010/08/14 23:31:25  mwrrv3
 *  Removed onclick function for ENTER button for Enter Payment screen.
 *
 *  Revision 1.44  2010/08/12 18:55:55  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.43  2010/08/10 18:32:32  mwkkc
 *  set the start clock time
 *
 *  Revision 1.42  2010/07/30 21:09:15  mwskd2
 *  enable property is added to all the buttons through setUpButton method
 *
 *  Revision 1.41  2010/07/13 17:11:02  mwkfh
 *  relocated session restore packages
 *
 *  Revision 1.40  2010/07/10 01:09:05  mwrrv3
 *  Modified the code to support invoking business rule validation in Backing Bean for test results 1 & 2.
 *
 *  Revision 1.39  2010/07/08 02:04:40  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.38  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.36.2.5  2010/06/20 20:03:06  mwakg
 *  Fixed API and 07Q navigations
 *
 *  Revision 1.36.2.4  2010/06/20 18:44:06  mwakg
 *  Fixed API and updated java docs
 *
 *  Revision 1.36.2.3  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.37  2010/06/08 17:16:16  mwrrv3
 *  Appended brErrorMsg to the business rule message to distinguish UI error messages.
 *
 *  Revision 1.36.2.2  2010/06/14 22:36:47  mwakg
 *  Rebased code in branch from Head - June 14, 2010
 *
 *  Revision 1.37  2010/06/08 17:16:16  mwrrv3
 *  Appended brErrorMsg to the business rule message to distinguish UI error messages.
 *
 *  Revision 1.36  2010/05/27 20:55:05  mwskd2
 *  cna bypass is enabled back
 *
 *  Revision 1.35  2010/05/20 00:34:25  mwrrv3
 *  Modified the code to display the TTC in upper case and screen name in camel case.
 *
 *  Revision 1.34  2010/05/14 04:45:40  mwvkm
 *  Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 *  Revision 1.33  2010/05/14 00:29:23  mwrrv3
 *  Removed PF from the button names.
 *
 *  Revision 1.32  2010/05/10 22:17:28  mwrpk
 *  SLTT - more work needed, replace mockbutton action with topbusiness process
 *
 *  Revision 1.31  2010/05/10 02:13:04  mwskd2
 *  removed approval ttc logic
 *
 *  Revision 1.30  2010/05/10 01:59:33  mwskd2
 *  ignore and reset buttons disabled
 *
 *  Revision 1.28  2010/05/05 00:09:44  mwvkm
 *  Chnaged the sessionContext type to ISessionContext
 *
 *  Revision 1.27  2010/05/04 00:13:26  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.26  2010/05/03 23:35:12  mwrrv3
 *  Added hard-coded values to the footer.
 *
 *  Revision 1.25  2010/05/02 18:26:36  mwskd2
 *  Help text content
 *
 *  Revision 1.24  2010/04/29 17:55:01  mwcsj3
 *  Merged Validation rules support changes from  BRF_INTEGRATION_BRANCH to Head
 *
 *  Revision 1.23  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.22  2010/04/16 02:19:57  mwrrv3
 *  Added error code before the message.
 *
 *  Revision 1.21  2010/04/16 02:15:09  mwrrv3
 *  Added messagesBus bean to get the error message from applicationMessages-bus.properties file.
 *
 *  Revision 1.20  2010/04/15 00:53:12  mwrka1
 *  printstacktrace statement added for development debug. it must  be removed
 *
 *  Revision 1.19  2010/04/08 18:24:23  mwcsj3
 *  Cleaned up, removed all unused and redundant methods
 *
 *  Revision 1.18  2010/04/07 22:19:16  mwcsj3
 *  Cleaned up Activity and subclasses, removed all unused and redundant methods
 *
 *  Revision 1.17  2010/04/06 02:11:26  mwskd2
 *  popupButtonActon() method is added for popupaction
 *
 *  Revision 1.16  2010/04/01 00:11:44  mwakg
 *  Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 *  Revision 1.15  2010/03/27 01:05:52  mwsxd10
 *  getPreviousInteractionActivity() method is called for showing validation or error messages on same screen.
 *
 *  Revision 1.14  2010/03/23 00:01:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.13  2010/03/21 21:24:55  mwakg
 *  Removed setting of ID as name as this will not work
 *
 *  Revision 1.12  2010/03/21 00:30:14  mwakg
 *  Returning the class name from buttonAction instead of activity name for navigation rules. This allows us to not define navigation rules for the same interaction activity
 *
 *  Revision 1.11  2010/03/21 00:09:51  mwakg
 *  Refactored Action class
 *
 *  Revision 1.10  2010/03/18 17:00:37  mwakg
 *  Removed instances of action classes and using generic Action class
 *
 *  Revision 1.9  2010/03/18 02:40:37  mwakg
 *  Setting the button positions based on the transitions keys position
 *
 *  Revision 1.8  2010/03/18 00:54:28  mwcsj3
 *  Reverted changes made to setupButtons() to accommodate multiple transitions
 *
 *  Revision 1.7  2010/03/11 22:22:16  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.6.2.2  2010/03/08 19:48:05  mwcsj3
 *  Deleted System.out.println()
 *
 *  Revision 1.6.2.1  2010/03/04 03:00:34  mwcsj3
 *  Made changes to accommodate multiple transitions
 *
 *  Revision 1.6  2010/01/15 02:52:56  mwkkc
 *  Support for JCL
 *
 *  Revision 1.5  2010/01/14 18:31:23  mwpzs3
 *  move to JCL logging
 *
 *  Revision 1.4  2010/01/14 02:34:36  mwskd2
 *  new files
 *
 *  Revision 1.3  2009/12/29 19:56:50  mwskd2
 *  onclick method is added for exit button and exit button session invalidate logic is removed
 *
 *  Revision 1.2  2009/12/23 18:50:10  mwrrv3
 *  getContextPath method added
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.6  2009/11/15 21:00:26  mwakg
 *  Removed sysout statment
 *
 *  Revision 1.5  2009/11/09 17:43:07  mwskd2
 *  exit button logic is added
 *
 *  Revision 1.4  2009/11/03 22:21:09  mwbvc
 *  capitalizing the footer text
 *
 *  Revision 1.3  2009/10/27 18:14:07  mwskd2
 *  removed the id attribute for buttons except enter button
 *
 *  Revision 1.2  2009/10/27 17:03:47  mwskd2
 *  Added comments
 *
 *  Revision 1.1  2009/10/22 00:40:40  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.55  2009/10/21 23:52:17  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.54  2009/10/03 21:36:16  mwpxp2
 *  Adjusted imports for fw, apph refactorings; added javadoc
 *
 *  Revision 1.53  2009/09/28 21:34:03  mwrsk
 *  IAuditable & ILoggable moved to framework project
 *
 *  Revision 1.52  2009/09/23 22:32:45  mwjjl7
 *  update error message
 *
 *  Revision 1.51  2009/09/23 19:58:52  mwakg
 *  Fixed ActionsHandler to use print message in exception instead of the exception name
 *
 *  Revision 1.50  2009/09/17 21:30:33  mwsxd10
 *  ILoggable for technical logging.
 *
 *  Revision 1.49  2009/09/17 00:07:56  mwbvc
 *  setRendered false for button11 and 12
 *
 *  Revision 1.48  2009/09/17 00:04:02  mwbvc
 *  Button11 and Button 12
 *
 *  Revision 1.47  2009/09/15 23:07:28  mwpxm2
 *  Synchronized form and browser protection
 *
 *  Revision 1.46  2009/09/14 23:30:10  mwakg
 *  Printing the exceptions to log file and development console
 *
 *  Revision 1.45  2009/09/14 21:48:34  mwskd2
 *  added printing related code
 *
 *  Revision 1.44  2009/09/14 01:33:46  mwskd2
 *  segment type is changed to string from codesetelement
 *
 *  Revision 1.43  2009/09/13 22:37:30  mwakg
 *  Fixed null pointer exception when an error accours
 *
 *  Revision 1.42  2009/09/13 22:15:39  mwakg
 *  Catching all exceptions and showing on screen
 *
 *  Revision 1.41  2009/09/13 20:45:21  mwakg
 *  Merging CodeSetCleaning branch into trunk
 *
 *  Revision 1.40.2.1  2009/09/13 01:34:23  mwakg
 *  Reading data from Database instead of XML for CodeSetService
 *
 *  Revision 1.40  2009/09/08 22:49:42  mwbvc
 *  removed unused imports
 *
 *  Revision 1.39  2009/09/03 17:02:03  mwjjl7
 *  fix button handling
 *
 *  Revision 1.38  2009/09/03 04:18:17  mwjjl7
 *  refactor for action handling specification
 *
 *  Revision 1.37  2009/08/31 21:08:36  mwbvc
 *  changed workSetID from systemDate to workDate
 *
 *  Revision 1.36  2009/08/31 18:13:54  mwakg
 *  Clearing the view mode before executing the business process
 *
 *  Revision 1.35  2009/08/28 21:05:47  mwbvc
 *  removed unused import and changed the workSetId by including the techId
 *
 *  Revision 1.34  2009/08/28 04:14:32  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.33  2009/08/28 01:48:30  mwbvc
 *  changed the workdate
 *
 *  Revision 1.32  2009/08/28 00:51:06  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.31  2009/08/27 21:27:46  mwsmg6
 *  law of Demeter
 *
 *  Revision 1.30  2009/08/27 20:59:04  mwsmg6
 *  corrected method name
 *
 *  Revision 1.29  2009/08/27 19:06:44  mwsmg6
 *  formatting
 *
 *  Revision 1.28  2009/08/27 16:36:45  mwsmg6
 *  corrected import
 *
 *  Revision 1.27  2009/08/27 08:30:16  mwpxp2
 *  Fixed imports to reflect fw migration; bulk cleanup
 *
 */
