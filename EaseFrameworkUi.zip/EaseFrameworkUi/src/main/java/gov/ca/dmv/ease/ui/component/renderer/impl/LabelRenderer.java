/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import java.util.Iterator;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This class is the extension of @see Renderer for the Output Label component. When the associated InputText 
 * component has an error, then it will have its styleclass changed to an error styleclass.
 * File: LabelRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: Oct 26, 2009
 * @author MWJJL7
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class LabelRenderer extends Renderer {
	/**
	* Logger for this class
	*/
	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(LabelRenderer.class);

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void encodeBegin(FacesContext context, UIComponent component)
			throws java.io.IOException {
		ResponseWriter writer = context.getResponseWriter();
		Map <String, Object> attrs = component.getAttributes();
		String inputId = (String) attrs.get("for");
		String value = (String) attrs.get("value");
		/*In order to support Accessibility the following three lines of code added*/
		if (!(inputId.trim().equalsIgnoreCase("motorCycle".trim()) || inputId
				.trim().equalsIgnoreCase("newNumberRequested".trim()))) {
			if (!(inputId.trim().equalsIgnoreCase(
					"clearedByIssuanceIndicator".trim()) || inputId.trim()
					.equalsIgnoreCase("removeRestrictionIndicator".trim()))) {
				value = StringUtils.chop(value) + ":";
			}
		}
		//End Accessibility logic
		UIInput input = null;
		if (!StringUtils.isEmpty(inputId)) {
			try {
				if (component.findComponent(inputId) instanceof UIInput) {
					input = (UIInput) component.findComponent(inputId);
				}
			}
			catch (Exception exception) {
				LOGGER
						.debug("encodeBegin(FacesContext, UIComponent) - There is an error in encode begin");
				LOGGER.error("encodeBegin(FacesContext, UIComponent)",
						exception);
			}
		}
		writer.startElement("label", component);
		String styleClass = (String) component.getAttributes()
				.get("styleClass");
		boolean hasErrors = hasMessages(context, input);
		if (styleClass != null) {
			if (hasErrors) {
				styleClass += " error";
			}
			writer.writeAttribute("class", styleClass, null);
		}
		else if (hasErrors) {
			writer.writeAttribute("class", "error", null);
		}
		String renderedId = (input != null) ? input.getClientId(context)
				: component.getClientId(context);
		writer.writeAttribute("for", renderedId, null);
		writer.write(value);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void encodeEnd(FacesContext context, UIComponent component)
			throws java.io.IOException {
		ResponseWriter writer = context.getResponseWriter();
		Map <String, Object> attrs = component.getAttributes();
		String labelId = (String) attrs.get("for");
		UIInput input = null;
		if (!StringUtils.isEmpty(labelId)) {
			try {
				if (component.findComponent(labelId) instanceof UIInput) {
					input = (UIInput) component.findComponent(labelId);
				}
			}
			catch (Exception e) {
				LOGGER.error("encodeEnd(FacesContext, UIComponent)", e);
			}
		}
		if ((input != null) && input.isRequired()) {
			writer.write("<span class=\"req\">*</span>");
		}
		else {
			writer.write("<span class=\"req\">&nbsp;</span>");
		}
		writer.endElement("label");
	}

	/**
	 * Checks for messages.
	 * 
	 * @param context the context
	 * @param component the component
	 * 
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	private boolean hasMessages(FacesContext context, UIComponent component) {
		if (component == null) {
			return false;
		}
		String compId = component.getClientId(context);
		Iterator <String> clientIds = context.getClientIdsWithMessages();
		boolean found = false;
		while (clientIds.hasNext()) {
			String clientId = clientIds.next();
			if (clientId != null && clientId.equals(compId)) {
				found = true;
				break;
			}
		}
		return found;
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	/**
	 * Checks if is renders children.
	 * 
	 * @return true, if is renders children
	 */
	public boolean isRendersChildren() {
		return false;
	}
}
/**
 *  Modification History:
 *
 *  $Log: LabelRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2011/03/23 23:46:58  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.6  2010/10/14 01:03:35  mwnrk
 *  Fixed Accessibility issues
 *
 *  Revision 1.5  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
