/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.webapp.UIComponentTag;

/**
 * Description: This class is the extension of @see UIComponentTag with all the setter and getter properties 
 * of a basic component tag
 * File: AbstractBaseTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractBaseTag extends UIComponentTag {
	/** The accesskey. */
	private String accesskey;
	/** The alt. */
	private String alt;
	/** The dir. */
	private String dir;
	/** The disabled. */
	private String disabled;
	/** The lang. */
	private String lang;
	/** The onclick. */
	private String onclick;
	/** The ondblclick. */
	private String ondblclick;
	/** The onkeydown. */
	private String onkeydown;
	/** The onkeypress. */
	private String onkeypress;
	/** The onkeyup. */
	private String onkeyup;
	/** The onmousedown. */
	private String onmousedown;
	/** The onmousemove. */
	private String onmousemove;
	/** The onmouseout. */
	private String onmouseout;
	/** The onmouseover. */
	private String onmouseover;
	/** The onmouseup. */
	private String onmouseup;
	/** The style. */
	private String style;
	/** The style class. */
	private String styleClass;
	/** The tabindex. */
	private String tabindex;
	/** The title. */
	private String title;

	/**
	 * This method adds a particular attribute to the component
	 * 
	 * @param component the component
	 * @param key the key
	 * @param value the value
	 */
	protected void addAttribute(UIComponent component, String key, Object value) {
		Application application = getFacesContext().getApplication();
		if (key != null && value != null) {
			if (isBindingExpression(value)) {
				component.setValueBinding(key, application
						.createValueBinding((String) value));
			}
			// TODO - Consider attributes of type validator/converter/listener 
			else {
				component.getAttributes().put(key, value);
			}
		}
	}

	/**
	 * Gets the accesskey.
	 * 
	 * @return the accesskey
	 */
	public String getAccesskey() {
		return accesskey;
	}

	/**
	 * Gets the alt.
	 * 
	 * @return the alt
	 */
	public String getAlt() {
		return alt;
	}

	/**
	 * Gets the dir.
	 * 
	 * @return the dir
	 */
	public String getDir() {
		return dir;
	}

	/**
	 * Gets the disabled.
	 * 
	 * @return the disabled
	 */
	public String getDisabled() {
		return disabled;
	}

	/**
	 * Gets the lang.
	 * 
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * Gets the onclick.
	 * 
	 * @return the onclick
	 */
	public String getOnclick() {
		return onclick;
	}

	/**
	 * Gets the ondblclick.
	 * 
	 * @return the ondblclick
	 */
	public String getOndblclick() {
		return ondblclick;
	}

	/**
	 * Gets the onkeydown.
	 * 
	 * @return the onkeydown
	 */
	public String getOnkeydown() {
		return onkeydown;
	}

	/**
	 * Gets the onkeypress.
	 * 
	 * @return the onkeypress
	 */
	public String getOnkeypress() {
		return onkeypress;
	}

	/**
	 * Gets the onkeyup.
	 * 
	 * @return the onkeyup
	 */
	public String getOnkeyup() {
		return onkeyup;
	}

	/**
	 * Gets the onmousedown.
	 * 
	 * @return the onmousedown
	 */
	public String getOnmousedown() {
		return onmousedown;
	}

	/**
	 * Gets the onmousemove.
	 * 
	 * @return the onmousemove
	 */
	public String getOnmousemove() {
		return onmousemove;
	}

	/**
	 * Gets the onmouseout.
	 * 
	 * @return the onmouseout
	 */
	public String getOnmouseout() {
		return onmouseout;
	}

	/**
	 * Gets the onmouseover.
	 * 
	 * @return the onmouseover
	 */
	public String getOnmouseover() {
		return onmouseover;
	}

	/**
	 * Gets the onmouseup.
	 * 
	 * @return the onmouseup
	 */
	public String getOnmouseup() {
		return onmouseup;
	}

	/**
	 * Gets the style.
	 * 
	 * @return the style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * Gets the style class.
	 * 
	 * @return the style class
	 */
	public String getStyleClass() {
		return styleClass;
	}

	/**
	 * Gets the tabindex.
	 * 
	 * @return the tabindex
	 */
	public String getTabindex() {
		return tabindex;
	}

	/**
	 * Gets the title.
	 * 
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * This method checks the presence of binding expression.
	 * 
	 * @param value the value
	 * 
	 * @return true, if is binding expression
	 */
	protected boolean isBindingExpression(Object value) {
		return (value != null && value instanceof String
				&& ((String) value).startsWith("#{") && ((String) value)
				.endsWith("}"));
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#release()
	 */
	@Override
	public void release() {
		super.release();
		styleClass = null;
		onclick = null;
		ondblclick = null;
		onkeydown = null;
		onkeypress = null;
		onkeyup = null;
		onmousedown = null;
		onmousemove = null;
		onmouseout = null;
		onmouseover = null;
		onmouseup = null;
		disabled = null;
		alt = null;
		lang = null;
		dir = null;
		tabindex = null;
		accesskey = null;
		title = null;
		style = null;
	}

	/**
	 * Sets the accesskey.
	 * 
	 * @param accesskey the new accesskey
	 */
	public void setAccesskey(String accesskey) {
		this.accesskey = accesskey;
	}

	/**
	 * Sets the alt.
	 * 
	 * @param alt the new alt
	 */
	public void setAlt(String alt) {
		this.alt = alt;
	}

	/**
	 * Sets the dir.
	 * 
	 * @param dir the new dir
	 */
	public void setDir(String dir) {
		this.dir = dir;
	}

	/**
	 * Sets the disabled.
	 * 
	 * @param disabled the new disabled
	 */
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	/**
	 * Sets the lang.
	 * 
	 * @param lang the new lang
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}

	/**
	 * Sets the onclick.
	 * 
	 * @param onclick the new onclick
	 */
	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

	/**
	 * Sets the ondblclick.
	 * 
	 * @param ondblclick the new ondblclick
	 */
	public void setOndblclick(String ondblclick) {
		this.ondblclick = ondblclick;
	}

	/**
	 * Sets the onkeydown.
	 * 
	 * @param onkeydown the new onkeydown
	 */
	public void setOnkeydown(String onkeydown) {
		this.onkeydown = onkeydown;
	}

	/**
	 * Sets the onkeypress.
	 * 
	 * @param onkeypress the new onkeypress
	 */
	public void setOnkeypress(String onkeypress) {
		this.onkeypress = onkeypress;
	}

	/**
	 * Sets the onkeyup.
	 * 
	 * @param onkeyup the new onkeyup
	 */
	public void setOnkeyup(String onkeyup) {
		this.onkeyup = onkeyup;
	}

	/**
	 * Sets the onmousedown.
	 * 
	 * @param onmousedown the new onmousedown
	 */
	public void setOnmousedown(String onmousedown) {
		this.onmousedown = onmousedown;
	}

	/**
	 * Sets the onmousemove.
	 * 
	 * @param onmousemove the new onmousemove
	 */
	public void setOnmousemove(String onmousemove) {
		this.onmousemove = onmousemove;
	}

	/**
	 * Sets the onmouseout.
	 * 
	 * @param onmouseout the new onmouseout
	 */
	public void setOnmouseout(String onmouseout) {
		this.onmouseout = onmouseout;
	}

	/**
	 * Sets the onmouseover.
	 * 
	 * @param onmouseover the new onmouseover
	 */
	public void setOnmouseover(String onmouseover) {
		this.onmouseover = onmouseover;
	}

	/**
	 * Sets the onmouseup.
	 * 
	 * @param onmouseup the new onmouseup
	 */
	public void setOnmouseup(String onmouseup) {
		this.onmouseup = onmouseup;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		addAttribute(component, "onclick", onclick);
		addAttribute(component, "ondblclick", ondblclick);
		addAttribute(component, "onkeydown", onkeydown);
		addAttribute(component, "onkeypress", onkeypress);
		addAttribute(component, "onkeyup", onkeyup);
		addAttribute(component, "onmousedown", onmousedown);
		addAttribute(component, "onmousemove", onmousemove);
		addAttribute(component, "onmouseout", onmouseout);
		addAttribute(component, "onmouseover", onmouseover);
		addAttribute(component, "onmouseup", onmouseup);
		addAttribute(component, "disabled", disabled);
		addAttribute(component, "alt", alt);
		addAttribute(component, "lang", lang);
		addAttribute(component, "dir", dir);
		addAttribute(component, "tabindex", tabindex);
		addAttribute(component, "accesskey", accesskey);
		addAttribute(component, "title", title);
		addAttribute(component, "style", style);
		addAttribute(component, "styleClass", styleClass);
	}

	/**
	 * Sets the style.
	 * 
	 * @param style the new style
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * Sets the style class.
	 * 
	 * @param styleClass the new style class
	 */
	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	/**
	 * Sets the tabindex.
	 * 
	 * @param tabindex the new tabindex
	 */
	public void setTabindex(String tabindex) {
		this.tabindex = tabindex;
	}

	/**
	 * Sets the title.
	 * 
	 * @param title the new title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractBaseTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
