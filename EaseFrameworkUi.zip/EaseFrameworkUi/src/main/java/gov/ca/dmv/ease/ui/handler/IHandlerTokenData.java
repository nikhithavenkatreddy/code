/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.handler;

import java.io.Serializable;

/**
 * Description: I am interface to allow for retrieval of view id and corresponding timestamp/token in a single call.
 * File: IHandlerTokenData.java
 * Module:  gov.ca.dmv.ease.ui.handler
 * Created: Mar 27, 2012 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface IHandlerTokenData extends Serializable {
	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	String getToken();

	/**
	 * Gets the view id.
	 *
	 * @return the view id
	 */
	String getViewId();
}
/**
 *  Modification History:
 *
 *  $Log: IHandlerTokenData.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/03/27 22:55:45  mwpxp2
 *  Initial
 *
 */
