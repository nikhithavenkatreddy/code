/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

import java.util.Map;

/**
 * Description: This class is the extension of ListOrderedMap to instantiate the class. Because the super class has protected constructor 
 * which cannot be instantiated without subclassing it. 
 * File: ListOrderedMap.java
 * Module:  gov.ca.dmv.ease.ui.util.impl
 * Created: Oct 27, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class ListOrderedMap extends
		org.apache.commons.collections.map.ListOrderedMap {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 697528985732681523L;

	/**
	 * Instantiates a new list ordered map.
	 * 
	 * @param map the map
	 */
	public ListOrderedMap(Map <String, String> map) {
		super(map);
	}
}
/**
 *  Modification History:
 *
 *  $Log: ListOrderedMap.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 00:06:13  mwpxp2
 *  Fixed file footer
 *
 */
