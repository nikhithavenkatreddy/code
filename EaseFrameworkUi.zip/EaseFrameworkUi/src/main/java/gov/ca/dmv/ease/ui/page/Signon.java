/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.page;

import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

/**
 * Description: Backing bean for signon.jspx.
 * The backing bean defines properties and methods associated with the UI components used on the signon.jspx
 * This class extends the DlBasePage which supplies the current DL Process Context
 * <p>
 * File: Signon.java
 * Module:  gov.ca.dmv.ease.ui.page
 * Created: Oct 14, 2009 
 * @author MWRPK  
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2017/05/11 16:26:46 $
 * Last Changed By: $Author: mwskh1 $
 */
public class Signon extends BasePage {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4582808064880872298L;
	/** The dummy. */
	private String dummy;

	/**
	 * Get the value of the dummy attribute 
	 * 
	 * @return The dummy value as a String 
	 */
	public String getDummy() {
		return dummy;
	}

	/**
	 * Set the value of the dummy attribute.
	 * 
	 * @param The new dummy value as a String 
	*/
	public void setDummy(String dummy) {
		this.dummy = EaseUtil.convertBlankToNull(dummy);
	}
}
/**
 *  Modification History:
 *
 *  $Log: Signon.java,v $
 *  Revision 1.2  2017/05/11 16:26:46  mwskh1
 *  WAS 8.5.5, Java 7 setting changes
 *
 *  Revision 1.1.6.2  2017/05/10 23:29:32  mwjmf6
 *  Remove commented code
 *
 *  Revision 1.1.6.1  2017/03/20 17:22:35  mwjmf6
 *  Convert any blank values to null in setter methods.
 *  EaseUtil.convertBlankToNull( )
 *
 *  Revision 1.1.6.1  2017/03/20 17:22:35  mwjmf6
 *  Convert any blank values to null in setter methods.
 *  EaseUtil.convertBlankToNull( )
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 00:02:52  mwpxp2
 *  Fixed file footer
 *
 */
