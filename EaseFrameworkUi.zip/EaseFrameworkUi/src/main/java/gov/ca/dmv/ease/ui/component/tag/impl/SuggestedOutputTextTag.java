/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;

import javax.faces.component.UIComponent;
import javax.faces.webapp.UIComponentTag;

/**
 * Description: This class is the extension of @see UIComponentTag.
 * File: SuggestedInputTextTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SuggestedOutputTextTag extends UIComponentTag {
	/**
	 * Instantiates a new suggested input text tag.
	 */
	public SuggestedOutputTextTag() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return HtmlSuggestedInputText.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.SuggestedOutputText";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#release()
	 */
	@Override
	public void release() {
		super.release();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SuggestedOutputTextTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/04/06 18:44:52  mwrrv3
 *  Added new render for converting code set element to string.
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
