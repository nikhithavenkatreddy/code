/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.util.impl;

import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

import org.springframework.aop.framework.ProxyFactoryBean;

/**
 * Description:
 * 
 * Breadcrumb - Utility to get the TTC elements or activities.
 *  //FIXME - fix raw type warnings
 *  
 * <p>
 * This program gets the TTC from the Session(ProcessContext) and builds a Map of activities in that ttc.
 * <p>
 * Example:
 * <code>getBreadcrumbs() with DLA TTC from the session
 * </code>
 * Might write out:
 * <code>
 * HQ Inquiry,Collect DL Data,Process Payment,Process Manual Inventory,Review Documents
 * </code>
 * 
 * @author MWRPK
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
@SuppressWarnings("unchecked")
public class Breadcrumb {
	/** The bread crumbs map. */
	protected Map <String, Map <String, String[]>> breadcrumbs;
	/** The session context. */
	protected ISessionContext sessionContext;

	/**
	 * returns the section of a panel.
	 *
	 * @return the bread crumbs
	 */
	public String getBreadcrumbs() {
		return getTtcActivities(FacesUtils.getCurrentScreenName());
	}

	/**
	 * Gets the check last elm.
	 * 
	 * @return the check last elm
	 */
	public Object getCheckLastElm() {
		Object[] ttcMap = this.getTtcMap();
		int mapSize = ttcMap != null ? ttcMap.length : 0;
		return ttcMap != null ? ttcMap[mapSize - 1] : null;
	}

	/**
	 * Gets the current ttc.
	 * 
	 * @return the current ttc
	 */
	protected String getCurrentTtc() {
		return this.getSessionContext().getUserContext().getTtc();
	}

	/**
	 * Gets the session context.
	 *
	 * @return the sessionContext
	 */
	public ISessionContext getSessionContext() {
		return this.sessionContext;
	}

	/**
	 * returns the TTC the page belongs to.
	 * 
	 * @param pageName the page name
	 * 
	 * @return the TTC
	 */
	private String getTtcActivities(String pageName) {
		Iterator it = this.breadcrumbs.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			String key = pairs.getKey().toString();
			String ttc = this.getCurrentTtc();
			if (key != null && key.equalsIgnoreCase(ttc)) {
				Map <String, String[]> value = (Map <String, String[]>) pairs
						.getValue();
				Iterator it1 = value.entrySet().iterator();
				while (it1.hasNext()) {
					Map.Entry pairs1 = (Map.Entry) it1.next();
					String[] values = (String[]) pairs1.getValue();
					if (ArrayUtils.contains(values, pageName)) {
						return pairs1.getKey().toString();
					}
				}
			}
		}
		return null;
	}

	/**
	 * Gets the TTC Array by Current TTC name.
	 *
	 * @return the TTC Map
	 */
	public Object[] getTtcMap() {
		Iterator it = this.breadcrumbs.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			String key = pairs.getKey().toString();
			String ttc = this.getCurrentTtc();
			if (key.equalsIgnoreCase(ttc)) {
				Map <String, String[]> value = (Map <String, String[]>) pairs
						.getValue();
				return value.keySet().toArray();
			}
		}
		return new Object[0];
	}

	/**
	 * Checks if the page is eligible for showing breadCrumb.
	 *
	 * @return true, if is bread crumb eligible
	 */
	public boolean isBreadCrumbEligible() {
		Object[] ttcMap = getTtcMap();
		//FIXME: Arrays.asList is unnecessary collection alloaction
		//FIXME: rewrite as standard ifs
		return ttcMap != null ? (Arrays.asList(ttcMap).contains(
				this.getBreadcrumbs()) ? true : false) : false;
	}

	/**
	 * Injecting bread crumb map from the application context.
	 *
	 * @param breadcrumbs the bread crumbs
	 */
	public void setBreadcrumb(Map <String, Map <String, String[]>> breadcrumbs) {
		this.breadcrumbs = breadcrumbs;
	}

	/**
	 * Sets the session context.
	 *
	 * @param sessionContext the sessionContext to set
	 */
	public void setSessionContext(ISessionContext sessionContext) {
		this.sessionContext = sessionContext;
	}

	/**
	 * Sets the session context.
	 *
	 * @param sessionContext the new session context
	 * @throws Exception the exception
	 */
	public void setSessionContext(ProxyFactoryBean sessionContext)
			throws Exception {
		this.sessionContext = (ISessionContext) sessionContext
				.getTargetSource().getTarget();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		Iterator it = this.breadcrumbs.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			String key = pairs.getKey().toString();
			output.append(key + "-- { ");
			Map <String, String[]> value = (Map <String, String[]>) pairs
					.getValue();
			Iterator it1 = value.entrySet().iterator();
			while (it1.hasNext()) {
				Map.Entry pairs1 = (Map.Entry) it1.next();
				output.append(pairs1.getKey() + " = "
						+ Arrays.toString((String[]) pairs1.getValue()));
			}
			output.append("},  ");
		}
		return output.toString();
	}
}
/**
 *  Modification History:
 *
 *  $Log: Breadcrumb.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2012/08/25 18:30:22  mwpxp2
 *  Added fixmes
 *
 *  Revision 1.9  2012/08/09 23:53:04  mwrrv3
 *  Refractored the code.
 *
 *  Revision 1.8  2011/06/13 18:22:31  mwyxg1
 *  clean up
 *
 *  Revision 1.7  2011/06/10 23:13:13  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.6  2010/08/12 18:55:57  mwcsj3
 *  Replaced StringBuffer with StringBuilder introduced in JDK 5.0 for performance enhancements
 *
 *  Revision 1.5  2010/05/05 00:09:44  mwvkm
 *  Chnaged the sessionContext type to ISessionContext
 *
 *  Revision 1.4  2010/04/22 19:29:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/04/01 00:11:44  mwakg
 *  Removed usage of EaseHttpSessionListener. UserContext and SessionContext are now spring beans with session scope and they are initialized using spring init-method and destroy-method tags. They are injected where required
 *
 *  Revision 1.2  2010/03/23 00:08:58  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2010/02/19 01:14:41  mwrpk
 *  breadcrumb changes
 *
 */
