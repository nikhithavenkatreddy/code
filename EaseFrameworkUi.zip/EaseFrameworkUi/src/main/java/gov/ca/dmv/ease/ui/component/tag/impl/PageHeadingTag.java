/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.UiPageHeading;

import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

/**
 * Description: custom JSF component to support page heading <p>
 * File: PageHeadingTag.java
 * Module:  gov.ca.dmv.ease.ui.jsf
 * Created: Oct 14, 2009 
 * @author MWRPK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class PageHeadingTag extends AbstractBaseTag {
	// Declare a bean property for the pageHeading attribute.
	public String pageHeading = null;

	// Associate the renderer and component type.
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return UiPageHeading.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.AbstractBaseTag#release()
	 */
	@Override
	public void release() {
		super.release();
		pageHeading = null;
	}

	/**
	 * Set the value of the pageHeading attribute.
	 * 
	 * @param The new pageHeading value as a String 
	 */
	public void setPageHeading(String pageHeading) {
		this.pageHeading = pageHeading;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.AbstractBaseTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		// set pageHeading
		if (pageHeading != null) {
			if (isValueReference(pageHeading)) {
				FacesContext context = FacesContext.getCurrentInstance();
				Application app = context.getApplication();
				ValueBinding vb = app.createValueBinding(pageHeading);
				component.setValueBinding("pageHeading", vb);
			}
			else {
				component.getAttributes().put("pageHeading", pageHeading);
			}
		}
	}
}
/**
 *  Modification History:
 * 
 *  $Log: PageHeadingTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.3  2009/10/27 23:29:07  mwrpk
 *  Adding comments
 *
 *  Revision 1.2  2009/08/27 00:29:29  mwskd2
 *  extended abstractBaseClass to get use of some attributes
 *
 *  Revision 1.1  2009/08/11 18:23:36  mwbvc
 *  Component classes to support pageHeading Tag
 *
 *  Revision 1.3  2009/08/03 22:22:03  mwbvc
 *  custom JSF component for DIV tag - to use the DIV with rendered attribute
 *
*/
