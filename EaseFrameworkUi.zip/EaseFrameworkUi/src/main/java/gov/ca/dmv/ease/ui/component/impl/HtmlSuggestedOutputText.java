/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;

/**
 * Description: This class is the extension of @see HtmlCodedInputText with a capability of handling alphanumeric and
 * codesetname with suggestions.
 * File: HtmlSuggestedInputText.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlSuggestedOutputText extends HtmlOutputText {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.SuggestedOutputText";

	/**
	 * Instantiates a new html suggested input text.
	 */
	public HtmlSuggestedOutputText() {
		setRendererType("gov.ca.dmv.ease.SuggestedOutputText");
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext _context, Object _state) {
		Object values[] = (Object[]) _state;
		super.restoreState(_context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext _context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(_context);
		return values;
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlSuggestedOutputText.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2010/04/06 18:44:52  mwrrv3
 *  Added new render for converting code set element to string.
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
