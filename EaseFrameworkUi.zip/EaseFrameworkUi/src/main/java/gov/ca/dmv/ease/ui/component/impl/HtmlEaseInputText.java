/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.html.HtmlInputText;
import javax.faces.context.FacesContext;

/**
 *  Description: This class is the extension of @see HtmlInputText
 * File: HtmlEaseInputText.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: May 06, 2009
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlEaseInputText extends HtmlInputText {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.EaseInputText";

	/**
	 * Instantiates a new html coded input text.
	 */
	public HtmlEaseInputText() {
		setRendererType("gov.ca.dmv.ease.EaseInputText");
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.html.HtmlInputText#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext _context, Object _state) {
		Object values[] = (Object[]) _state;
		super.restoreState(_context, values[0]);
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.html.HtmlInputText#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext _context) {
		Object values[] = new Object[2];
		values[0] = super.saveState(_context);
		return values;
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlEaseInputText.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/05/07 00:59:46  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *
 *  Revision 1.1  2010/05/07 00:52:18  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *
 */
