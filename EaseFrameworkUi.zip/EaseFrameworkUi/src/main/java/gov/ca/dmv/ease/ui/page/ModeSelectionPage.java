/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.page;

import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.COUNTER;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.DRIVING_LICNSE_WORK_TYPE;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.MAIL;
import static gov.ca.dmv.ease.dl.core.constants.IEaseModes.MANUAL;
import static gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper.FORMATTER_MM_DD_YYCC;
import static gov.ca.dmv.ease.ecs.convert.util.impl.EcsConverterHelper.convertStringToDate;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNotNull;
import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

/**
 * Description: Backing bean for modeSelection.jspx. The backing bean defines
 * properties and methods associated with the UI components used on the
 * modeSelection.jspx This class extends the BasePage which supplies the current
 * Process Context.
 * <p>
 * File: ModeSelectionPage.java 
 * Module: gov.ca.dmv.ease.ui.page 
 * Created: Oct 14, 2009
 * @author MWRPK
 * @version $Revision: 1.4 $ 
 * Last Changed: $Date: 2017/05/11 16:26:46 $ 
 * Last Changed By: $Author: mwskh1 $
 */
public class ModeSelectionPage extends BasePage {
	private static final String PRINTER_ID_NOT_CONFIGURED = "PRINTER ID AND ALTERNATE PRINTER ID NOT CONFIGURED-brErrorMsg";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -183911877109834127L;
	/** The functionalMode Mode 1 (C-Counter, M-Manual etc). */
	private String functionalMode;
	/** The office id. */
	private String officeId;
	/** The office and technician id combination. */
	private String officeTechId;
	/** The operationalMode Mode 2 (D-Driver License, V-Vehicle Registration). */
	private String operationalMode;
	/** The work date. */
	private Date workDate;
	/** The Operational Modes. */
	private List <SelectItem> operationalModes;
	/** The Functional Modes. */
	private List <SelectItem> functionalModes;

	/**
	 * Get the office id - technician id combination.
	 * @return
	 */
	public String getOfficeTechId() {
		//return officeTechId as "212-I2"
		return getUserContext().getOriginalOfficeId() + "-"
				+ getUserContext().getOriginalTechId();
	}

	/**
	 * Set the user selected office id-technician id combination.
	 * @param officeTechId
	 */
	public void setOfficeTechId(String officeTechId) {
		this.officeTechId = EaseUtil.convertBlankToNull(officeTechId);
	}

	/**
	 * Gets the WorkDateList. Dynamically build date list; stored in the user
	 * context - for the work date drop down elements.
	 * 
	 * @return the WorkDateList
	 */
	public List <SelectItem> getWorkDateList() {
		SimpleDateFormat sdf = new SimpleDateFormat(FORMATTER_MM_DD_YYCC);
		List <Date> workDateList = getUserContext().getAuthdWorkDates();
		int listSize = 0;
		if (workDateList != null) {
			listSize = workDateList.size();
		}
		List <SelectItem> list = new ArrayList <SelectItem>(listSize + 1);
		for (int i = 0; i < listSize; i++) {
			list.add(new SelectItem(convertStringToDate(
					sdf.format(workDateList.get(i)), FORMATTER_MM_DD_YYCC), sdf
					.format(workDateList.get(i))));
		}
		list.add(0, new SelectItem("", ""));
		// list.add(new SelectItem(convertStringToDate("12222010",
		// FORMATTER_MM_DD_YYCC), "12222010"));
		// list.add(new SelectItem(convertStringToDate("02232014",
		// FORMATTER_MM_DD_YYCC), "02232014"));
		return list;
	}

	/**
	 * Get the value of the functionalMode attribute from the current process
	 * context.
	 * 
	 * @return The functionalMode value as a String
	 */
	public String getFunctionalMode() {
		try {
			return (getUserContext().getFunctionalMode() == null ? DEFAULT_FUNCTION_WORK_TYPE_DRIVER_LICENSE
					: getUserContext().getFunctionalMode().getCode());
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage functionalMode "
					+ e.getMessage());
		}
		return functionalMode;
	}

	/**
	 * Gets the office id.
	 * 
	 * @return the office id
	 */
	public String getOfficeId() {
		officeId = getUserContext().getOfficeId();
		return officeId;
	}

	/**
	 * Get the value of the VCSCMS2 attribute from the current process context.
	 * 
	 * @return The VCSCMS2 value as a String
	 */
	public String getOperationalMode() {
		try {
			if (!isNullOrBlank(getUserContext().getOfficeId())) {
				return (getUserContext().getOperationalMode() == null ? DEFAULT_OPERATION_PROCESS_TYPE_COUNTER
						: getUserContext().getOperationalMode().getCode());
			}
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage operationalMode "
					+ e.getMessage());
		}
		return operationalMode;
	}

	/**
	 * Get the value of the workDate attribute.
	 * 
	 * @return The workDate value as a Date
	 */
	public Date getWorkDate() {
		try {
			// If user is logging on first time then set the default work date
			// to the first item in the work dates list otherwise empty.
			// Defect#: 3447
			if (getUserContext().getOperationalMode() != null) {
				workDate = getUserContext().getWorkDate();
			}
			else {
				List <Date> workDateList = getUserContext().getAuthdWorkDates();
				if (!isNullOrBlank(workDateList) && workDateList.size() > 0) {
					SimpleDateFormat sdf = new SimpleDateFormat(
							FORMATTER_MM_DD_YYCC);
					return convertStringToDate(sdf.format(workDateList.get(0)),
							FORMATTER_MM_DD_YYCC);
				}
				else {
					return null;
				}
			}
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage WorkDate "
					+ e.getMessage());
		}
		return workDate;
	}

	/**
	 * Set the value of the VCSCMS1 attribute from the current process context.
	 * 
	 * @param VCSCMS1
	 *            the new vCSCM s1
	 */
	public void setFunctionalMode(String functionalMode) {
		this.functionalMode = EaseUtil.convertBlankToNull(functionalMode);
		try {
			getUserContext().setFunctionalMode(
					new CodeSetElement(this.functionalMode, this.functionalMode,
							this.functionalMode));
			return;
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage functionalMode "
					+ e.getMessage());
		}
	}

	/**
	 * Sets the office id.
	 * 
	 * @param officeId
	 *            the new office id
	 */
	public void setOfficeId(String officeId) {
		this.officeId = EaseUtil.convertBlankToNull(officeId);
	}

	/**
	 * Set the value of the VCSCMS2 attribute from the current process context.
	 * 
	 * @param VCSCMS2
	 *            the new vCSCM s2
	 */
	public void setOperationalMode(String operationalMode) {
		this.operationalMode = EaseUtil.convertBlankToNull(operationalMode);
		try {
			getUserContext().setOperationalMode(
					new CodeSetElement(this.operationalMode, this.operationalMode,
							this.operationalMode));
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage setOperationalMode "
					+ e.getMessage());
		}
	}

	/**
	 * Set the value of the workDate attribute.
	 * 
	 * @param workDate
	 *            the new work date
	 */
	public void setWorkDate(Date workDate) {
		try {
			getUserContext().setWorkDate(workDate);
		}
		catch (Exception e) {
			LOGGER.error("Binding Error: ModeSelectionPage setWorkDate "
					+ e.getMessage());
		}
		this.workDate = workDate;
	}

	/**
	 * @return the operationalModes
	 */
	public List <SelectItem> getOperationalModes() {
		operationalModes = new ArrayList <SelectItem>();
		if (!isNullOrBlank(getUserContext().getOperationalModes())) {
			for (String key : getUserContext().getOperationalModes().keySet()) {
				operationalModes.add(new SelectItem(key, key + " - "
						+ getUserContext().getOperationalModes().get(key)));
			}
		}
		return operationalModes;
	}

	/**
	 * @param operationalModes
	 *            the operationalModes to set
	 */
	public void setOperationalModes(List <SelectItem> operationalModes) {
		this.operationalModes = operationalModes;
	}

	/**
	 * If the mode is Counter (C) or Mail (P) then Work Date is required if
	 * Manual(M) or Travel(T) Work Date is not required
	 * 
	 * @return boolean
	 */
	public boolean isWorkDateRequired() {
		if (!isNullOrBlank(getUserContext().getOperationalMode())) {
			String modeType = getUserContext().getOperationalMode().getCode();
			if (COUNTER.equalsIgnoreCase(modeType)
					|| MAIL.equalsIgnoreCase(modeType)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.ca.dmv.ease.ui.page.BasePage#renderPreProcessing()
	 */
	@Override
	public void renderPreProcessing() {
		if (getUserContext().getPrimaryPrinterId() == null
				|| getUserContext().getAlternatePrinterId() == null) {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			facesContext.addMessage(null, new FacesMessage(
					PRINTER_ID_NOT_CONFIGURED));
		}
		// If the office is issuance then set the default mode to Manual.
		if (getUserContext().isIssuanceOfficeOnly()) {
			setOperationalMode(MANUAL);
		}
	}

	@Override
	public String getFocusField() {
		return getFocusField("workDate");
	}

	@Override
	public void submitPreProcessing() {
		// If the mode is counter then replace the technician id with the
		// original technician (from security TIM/TAMe) id because in other
		// modes like Manual mode we will overwrite the technician id.
		String originalTechId = getUserContext().getOriginalTechId();
		String originalOfficeId = getUserContext().getOriginalOfficeId();
		if (getUserContext().getOperationalMode() != null) {
			if (getUserContext().getOperationalMode().getCode()
					.equalsIgnoreCase(COUNTER)
					|| getUserContext().getOperationalMode().getCode()
							.equalsIgnoreCase(MAIL)) {
				getUserContext().setTechId(originalTechId);
			}
		}
		if (getUserContext().isIssHqServicesFlag()) {
			getUserContext().setTechId(originalTechId);
			getUserContext().setOfficeId(originalOfficeId);
		}
		// If the user has issuance role then get the office id and technician
		// id with delimiter as '-' then split and update the user context.
		if (isIssuanceOffice() && !getUserContext().isIssHqServicesFlag()) {
			// OfficeId-Tech Id: 212-I2
			if (officeTechId != null) {
				// Office Id: 212
				String officeId = officeTechId.substring(0, 3);
				// Tech Id: I2
				String techId = officeTechId.substring(4, 6);
				// Update the user context with the user selection.
				getUserContext().setTechId(techId);
				getUserContext().setOfficeId(officeId);
			}
		}
	}

	/**
	 * @param functionalModes
	 *            the functionalModes to set
	 */
	public void setFunctionalModes(List <SelectItem> functionalModes) {
		this.functionalModes = functionalModes;
	}

	/**
	 * Return the list of possible functional modes. Right now only Drivers License.
	 * @return the functionalModes
	 */
	public List <SelectItem> getFunctionalModes() {
		functionalModes = new ArrayList <SelectItem>();
		if (!isNullOrBlank(getUserContext().getOfficeId())) {
			functionalModes.add(new SelectItem(DRIVING_LICNSE_WORK_TYPE,
					"D - Drivers License"));
		}
		return functionalModes;
	}

	/**
	 * Get the work date errors
	 * 
	 * @return
	 */
	public String getWorkDateError() {
		// Iterate the error messages until UI focus field is not null.
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages();
		while (isNotNull(messages) && messages.hasNext()) {
			FacesMessage facesMessage = (FacesMessage) messages.next();
			if (facesMessage != null
					&& !isNullOrBlank(facesMessage.getSummary())
					&& (facesMessage.getSummary().contains("0306") || facesMessage
							.getSummary().contains("0307"))) {
				String errorMessage = facesMessage.getSummary();
				messages.remove();
				return errorMessage.replace("-brErrorMsg", "");
			}
		}
		return null;
	}

	/**
	 * Checks if is office id display.
	 * 
	 * @return true, if is office id display
	 */
	public boolean isIssuanceOffice() {
		return getUserContext().isIssuanceOfficeOnly();
	}

	/**
	 * Return the list of possible issuance office and technician id list.
	 * @return List
	 */
	public List <SelectItem> getOfficeTechIdList() {
		List <SelectItem> newOfficeTechIdList = new ArrayList <SelectItem>();
		List <String> officeTechIdList = getUserContext()
				.getIssuanceOfficeTechList();
		if (officeTechIdList != null) {
			for (String officeTechIdItem : officeTechIdList) {
				newOfficeTechIdList.add(new SelectItem(officeTechIdItem,
						officeTechIdItem.replace("-", " - ")));
			}
		}
		return newOfficeTechIdList;
	}
}
/**
 * Modification History:
 * 
 * $Log: ModeSelectionPage.java,v $
 * Revision 1.4  2017/05/11 16:26:46  mwskh1
 * WAS 8.5.5, Java 7 setting changes
 *
 * Revision 1.3.2.2  2017/05/10 23:29:32  mwjmf6
 * Remove commented code
 *
 * Revision 1.3.2.1  2017/03/20 17:22:35  mwjmf6
 * Convert any blank values to null in setter methods.
 * EaseUtil.convertBlankToNull( )
 *
 * Revision 1.3.2.1  2017/03/20 17:22:35  mwjmf6
 * Convert any blank values to null in setter methods.
 * EaseUtil.convertBlankToNull( )
 *
 * Revision 1.3  2015/07/28 19:48:21  mwnxg5
 * Modified ISS_HQ_SERVICES functionality
 *
 * Revision 1.2  2012/10/05 18:46:50  mwrrv3
 * Code refractor and removed related to asterisk in front of the primary office id and tech id (Issuance).
 *
 * Revision 1.1  2012/10/01 02:58:07  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.32  2012/08/14 20:40:05  mwrrv3
 * Code clean up and fixed PMD issues.
 *
 * Revision 1.31  2012/07/20 16:58:29  mwrrv3
 * Updated the code to add asterisk (*) for the home office indicator.
 *
 * Revision 1.30  2012/06/02 18:02:52  mwsxv5
 * related to Issuance fix.
 * Revision 1.29 2012/06/01 05:26:09 mwsxv5
 * Issuance related changes Revision 1.28 2012/03/10 05:43:52 mwsxv5 Work date
 * informational and error message changes.
 * 
 * Revision 1.27 2011/12/13 02:16:05 mwrrv3 Removed empty item from the
 * getFunctionalModes() list.
 * 
 * Revision 1.26 2011/11/10 20:09:09 mwrrv3 Updated the code to take of if
 * office and tech id are null.
 * 
 * Revision 1.25 2011/09/14 22:46:33 mwrrv3 Updated the code for issuance
 * (default for Mode1 is MANUAL).
 * 
 * Revision 1.24 2011/09/14 22:46:15 mwrrv3 Updated the code for issuance
 * (default for Mode1 is MANUAL).
 * 
 * Revision 1.23 2011/06/17 23:53:32 mwyxg1 remove getUserContext, same as super
 * class
 * 
 * Revision 1.22 2011/06/17 20:23:53 mwyxg1 modify getUserContext for
 * performance
 * 
 * Revision 1.21 2011/01/03 00:55:38 mwrrv3 Modified the code to fix defect#
 * 3447 related to default work date.
 * 
 * Revision 1.20 2010/12/29 19:53:53 mwrrv3 Added MAIL mode to get the original
 * tech id.
 * 
 * Revision 1.19 2010/12/29 18:49:58 mwrrv3 Added submitPreProcessing to set the
 * original tech id to the tech id field in the user context.
 * 
 * Revision 1.18 2010/12/23 06:10:40 mwkkc Merged Production code from Branch
 * 
 * Revision 1.14.2.4 2010/12/23 01:29:49 mwkkc Rebase from head - Arch
 * 
 * Revision 1.17 2010/12/22 19:07:53 mwrrv3 Updated the logic for mode selection
 * page.
 * 
 * Revision 1.16 2010/12/21 18:15:59 mwrrv3 Work Date Drop Down dates default
 * set as todays Date -- Amar Bade
 * 
 * Revision 1.15 2010/12/20 01:36:04 mwrrv3 Code formatted and updated the
 * logic.
 * 
 * Revision 1.14 2010/12/13 18:17:23 mwrrv3 Constants added from "IEaseModes "
 * for Modes -- Amar Bade
 * 
 * Revision 1.13 2010/12/12 02:22:25 mwgxk2 Printer Id informational Message.
 * 
 * Revision 1.12 2010/12/11 22:15:09 mwrrv3 SLTT Implementation changes Work
 * Date changed as list -- Amar Bade
 * 
 * Revision 1.11 2010/12/03 21:02:06 mwrrv3 Update the code to support business
 * rule validation field focus.
 * 
 * Revision 1.10 2010/12/02 02:03:27 mwrrv3 Codeset values is replaced with
 * Dropdown for Mode Selection. We get the values from the DB, CodeSet is
 * obsolete.-- SLTT implementation -- Amar Bade
 * 
 * Revision 1.9 2010/11/09 21:30:43 mwsyk1 Reverted to version 1.7
 * 
 * Revision 1.7 2010/09/03 21:27:25 mwrrv3 Added mapping for the work date
 * field.
 * 
 * Revision 1.6 2010/08/04 00:02:21 mwazg5 Setup for default operation and
 * function codes
 * 
 * Revision 1.5 2010/07/13 17:11:03 mwkfh relocated session restore packages
 * 
 * Revision 1.4 2010/07/08 02:04:43 mwpxp2 Bulk cleanup
 * 
 * Revision 1.3 2010/06/21 23:00:48 mwcsj3 Merged
 * SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 * 
 * Revision 1.1.2.1 2010/06/20 18:06:58 mwakg Rebased to June 20, 2010
 * 
 * Revision 1.2 2010/06/15 20:48:30 mwskd2 changed from cryptic names to
 * meaningful names
 * 
 * Revision 1.1 2010/05/28 17:36:32 mwrpk changing mode_Selection to
 * modeSelection
 * 
 * Revision 1.8 2010/05/20 19:07:01 mwrpk Adding office Id Revision 1.7
 * 2010/05/19 21:31:13 mwrpk Code clean up Revision 1.6 2010/05/13 23:13:39
 * mwrpk SLTT changes Revision 1.5 2010/05/10 22:18:24 mwrpk SLTT work
 * 
 * Revision 1.4 2010/04/22 19:29:58 mwpxp2 Bulk cleanup
 * 
 * Revision 1.3 2010/03/29 16:13:19 mwbxp5 Changed names of methods form
 * getmodeI and getModeII to getOperationalMode and getFunctionalMode. Revision
 * 1.2 2010/03/23 00:02:52 mwpxp2 Fixed file footer
 * 
 */
