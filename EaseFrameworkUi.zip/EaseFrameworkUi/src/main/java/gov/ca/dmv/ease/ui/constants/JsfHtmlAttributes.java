/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.constants;

import static gov.ca.dmv.ease.fw.util.impl.ArrayUtils.concat;

/**
 * Description: This interface contains all the attribute names that are
 * required for an HTML component.
 * //FIXME - validity of this code is physical order-specific
 * 
 * File: JsfHtmlAttributes.java
 * Module:  gov.ca.dmv.ease.ui.constants
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface JsfHtmlAttributes {
	/** The ACCESSKEY_ATTR. */
	String ACCESSKEY_ATTR = "accesskey";
	/** The ACTION_ATTR. */
	String ACTION_ATTR = "action";
	/** The ALIGN_ATTR. */
	String ALIGN_ATTR = "align";
	/** The ALT_ATTR. */
	String ALT_ATTR = "alt";
	/** The ANCHOR_ELEM. */
	String ANCHOR_ELEM = "a";
	/** The BGCOLOR_ATTR. */
	String BGCOLOR_ATTR = "bgcolor";
	/** The BINDING_ATTR*/
	String BINDING_ATTR = "binding";
	/** The BORDER_ATTR. */
	String BORDER_ATTR = "border";
	/** The BR_ELEM. */
	String BR_ELEM = "br";
	/** The BUTTON_ELEM. */
	String BUTTON_ELEM = "button";
	String LAYOUT_ATTR = "layout";
	/** The CELLPADDING_ATTR. */
	String CELLPADDING_ATTR = "cellpadding";
	/** The CELLSPACING_ATTR. */
	String CELLSPACING_ATTR = "cellspacing";
	/** The CLASS_ATTR. */
	String CLASS_ATTR = "class";
	/** The COLSPAN_ATTR. */
	String COLSPAN_ATTR = "colspan";
	/** The COLUMN_CLASSES_ATTR. */
	String COLUMN_CLASSES_ATTR = "columnClasses";
	/** The COLUMNS_ATTR. */
	String COLUMNS_ATTR = "columns";
	/** The COMMAND_CLASS_ATTR. */
	String COMMAND_CLASS_ATTR = "commandClass";
	/** The CONVERTER_ATTR. */
	String CONVERTER_ATTR = "converter";
	/** The DATAFLD_ATTR. */
	String DATAFLD_ATTR = "datafld";
	/** The DATAFORMATAS_ATTR. */
	String DATAFORMATAS_ATTR = "dataformatas";
	/** The DATASRC_ATTR. */
	String DATASRC_ATTR = "datasrc";
	/** The DIR_ATTR. */
	String DIR_ATTR = "dir";
	/** The DISABLED_ATTR. */
	String DISABLED_ATTR = "disabled";
	/** The DIV_ELEM. */
	String DIV_ELEM = "div";
	/** The FILE_ATTR. */
	String FILE_ATTR = "file";
	/** The FOOTER_CLASS_ATTR. */
	String FOOTER_CLASS_ATTR = "footerClass";
	/** The FORM_ELEM. */
	String FORM_ELEM = "form";
	/** The FORM_ID. */
	String FORM_ID = "MAIN_FORM";
	/** The FRAME_ATTR. */
	String FRAME_ATTR = "frame";
	/** The H1_ELEM. */
	String H1_ELEM = "h1";
	/** The H2_ELEM. */
	String H2_ELEM = "h2";
	/** The H3_ELEM. */
	String H3_ELEM = "h3";
	/** The H4_ELEM. */
	String H4_ELEM = "h4";
	/** The H5_ELEM. */
	String H5_ELEM = "h5";
	/** The H6_ELEM. */
	String H6_ELEM = "h6";
	/** The HEADER_CLASS_ATTR. */
	String HEADER_CLASS_ATTR = "headerClass";
	/** The HEIGHT_ATTR. */
	String HEIGHT_ATTR = "height";
	/** The HREF_PARAM_NAME_FROM_VALUE_SEPARATOR. */
	String HREF_PARAM_NAME_FROM_VALUE_SEPARATOR = "=";
	/** The HREF_PARAM_SEPARATOR. */
	String HREF_PARAM_SEPARATOR = "&";
	/** The HREF_PATH_FROM_PARAM_SEPARATOR. */
	String HREF_PATH_FROM_PARAM_SEPARATOR = "?";
	/** The HRE f_ pat h_ separator. */
	String HREF_PATH_SEPARATOR = "/";
	/** The ID_ATTR. */
	String ID_ATTR = "id";
	/** The IMAGE_ATTR. */
	String IMAGE_ATTR = "image";
	/** The IMG_ELEM. */
	String IMG_ELEM = "img";
	/** The IMMEDIATE_ATTR. */
	String IMMEDIATE_ATTR = "immediate";
	/** The INPUT_ELEM. */
	String INPUT_ELEM = "input";
	/** The INPUT_TYPE_BUTTON. */
	String INPUT_TYPE_BUTTON = "button";
	/** The INPUT_TYPE_CHECKBOX. */
	String INPUT_TYPE_CHECKBOX = "checkbox";
	/** The INPUT_TYPE_HIDDEN. */
	String INPUT_TYPE_HIDDEN = "hidden";
	/** The INPUT_TYPE_IMAGE. */
	String INPUT_TYPE_IMAGE = "image";
	/** The INPUT_TYPE_PASSWORD. */
	String INPUT_TYPE_PASSWORD = "password";
	/** The INPUT_TYPE_RADIO. */
	String INPUT_TYPE_RADIO = "radio";
	/** The INPUT_TYPE_SUBMIT. */
	String INPUT_TYPE_SUBMIT = "submit";
	/** The INPUT_TYPE_TEXT. */
	String INPUT_TYPE_TEXT = "text";
	/** The LABEL_ATTR. */
	String LABEL_ATTR = "label";
	/** The LABEL_ELEM. */
	String LABEL_ELEM = "label";
	/** The LANG_ATTR. */
	String LANG_ATTR = "lang";
	/** The LI_ELEM. */
	String LI_ELEM = "li";
	/** The LINK_ELEM. */
	String LINK_ELEM = "link";
	/** The MAXLENGTH_ATTR. */
	String MAXLENGTH_ATTR = "maxlength";
	/** The NAME_ATTR. */
	String NAME_ATTR = "name";
	/** The NBS p_ entity. */
	String NBSP_ENTITY = "&#160;";
	/** The OL_ELEM. */
	String OL_ELEM = "ol";
	/** The ONBLUR_ATTR. */
	String ONBLUR_ATTR = "onblur";
	/** The ONCHANGE_ATTR. */
	String ONCHANGE_ATTR = "onchange";
	/** The ONCLICK_ATTR. */
	String ONCLICK_ATTR = "onclick";
	/** The ONDBLCLICK_ATTR. */
	String ONDBLCLICK_ATTR = "ondblclick";
	/** The ONFOCUS_ATTR. */
	String ONFOCUS_ATTR = "onfocus";
	/** The ONKEYDOWN_ATTR. */
	String ONKEYDOWN_ATTR = "onkeydown";
	/** The ONKEYPRESS_ATTR. */
	String ONKEYPRESS_ATTR = "onkeypress";
	/** The ONKEYUP_ATTR. */
	String ONKEYUP_ATTR = "onkeyup";
	/** The ONMOUSEDOWN_ATTR. */
	String ONMOUSEDOWN_ATTR = "onmousedown";
	/** The ONMOUSEMOVE_ATTR. */
	String ONMOUSEMOVE_ATTR = "onmousemove";
	/** The ONMOUSEOUT_ATTR. */
	String ONMOUSEOUT_ATTR = "onmouseout";
	/** The ONMOUSEOVER_ATTR. */
	String ONMOUSEOVER_ATTR = "onmouseover";
	/** The ONMOUSEUP_ATTR. */
	String ONMOUSEUP_ATTR = "onmouseup";
	/** The ONSELECT_ATTR. */
	String ONSELECT_ATTR = "onselect";
	/** The ONSUBMIT_ATTR. */
	String ONSUBMIT_ATTR = "onsubmit";
	/** The OPTGROUP_ELEM. */
	String OPTGROUP_ELEM = "optgroup";
	/** The OPTION_ELEM. */
	String OPTION_ELEM = "option";
	/** The PANEL_CLASS_ATTR. */
	String PANEL_CLASS_ATTR = "panelClass";
	/** The READONLY_ATTR. */
	String READONLY_ATTR = "readonly";
	/** The RENDERED_ATTR. */
	String RENDERED_ATTR = "rendered";
	String REQUIRED_ATTR = "required";
	/** The ROW_CLASSES_ATTR. */
	String ROW_CLASSES_ATTR = "rowClasses";
	/** The RULES_ATTR. */
	String RULES_ATTR = "rules";
	/** The SCOPE_ATTR. */
	String SCOPE_ATTR = "scope";
	/** The SCOPE_COLGROUP_VALUE. */
	String SCOPE_COLGROUP_VALUE = "colgroup";
	/** The SCRIPT_ELEM. */
	String SCRIPT_ELEM = "script";
	/** The SCRIPT_ELEM_DEFER_ATTR. */
	String SCRIPT_ELEM_DEFER_ATTR = "defer";
	/** The SCRIPT_LANGUAGE_ATTR. */
	String SCRIPT_LANGUAGE_ATTR = "language";
	/** The SCRIPT_LANGUAGE_JAVASCRIPT. */
	String SCRIPT_LANGUAGE_JAVASCRIPT = "JavaScript";
	/** The SCRIPT_TYPE_TEXT_JAVASCRIPT. */
	String SCRIPT_TYPE_TEXT_JAVASCRIPT = "text/javascript";
	/** The SELECT_ELEM. */
	String SELECT_ELEM = "select";
	/** The SIZE_ATTR. */
	String SIZE_ATTR = "size";
	/** The SPAN_ELEM. */
	String SPAN_ELEM = "span";
	/** The SRC_ATTR. */
	String SRC_ATTR = "src";
	/** The STYLE_ATTR. */
	String STYLE_ATTR = "style";
	/** The STYLE_CLASS_ATTR. */
	String STYLE_CLASS_ATTR = "styleClass";
	/** The STYLE_ELEM. */
	String STYLE_ELEM = "style";
	/** The STYLE_TYPE_TEXT_CSS. */
	String STYLE_TYPE_TEXT_CSS = "text/css";
	/** The STYLESHEE t_ value. */
	String STYLESHEET_VALUE = "stylesheet";
	/** The SUMMARY_ATTR. */
	String SUMMARY_ATTR = "summary";
	/** The TABINDEX_ATTR. */
	String TABINDEX_ATTR = "tabindex";
	/** The TABLE_ELEM. */
	String TABLE_ELEM = "table";
	/** The TBODY_ELEM. */
	String TBODY_ELEM = "tbody";
	/** The TD_ELEM. */
	String TD_ELEM = "td";
	/** The TEXTAREA_ELEM. */
	String TEXTAREA_ELEM = "textarea";
	/** The TFOOT_ELEM. */
	String TFOOT_ELEM = "tfoot";
	/** The TH_ELEM. */
	String TH_ELEM = "th";
	/** The THEAD_ELEM. */
	String THEAD_ELEM = "thead";
	/** The TITLE_ATTR. */
	String TITLE_ATTR = "title";
	/** The TR_ELEM. */
	String TR_ELEM = "tr";
	/** The TYPE_ATTR. */
	String TYPE_ATTR = "type";
	/** The UL_ELEM. */
	String UL_ELEM = "ul";
	/** The UNIVERSAL_ATTRIBUTES_WITHOUT_STYLE. */
	String[] UNIVERSAL_ATTRIBUTES_WITHOUT_STYLE = { DIR_ATTR, LANG_ATTR,
			TITLE_ATTR, };
	String[] UNIVERSAL_ATTRIBUTES_WITHOUT_TITLE_AND_STYLE = { DIR_ATTR,
			LANG_ATTR };
	String VALIDATOR_ATTR = "validator";
	/** The VALUE_ATTR */
	String VALUE_ATTR = "value";
	/*The FOR_ATTR*/
	String FOR_ATTR = "for";
	String VALUE_CHANGE_LISTENER_ATTR = "valueChangeListener";
	/** The WIDTH_ATTR. */
	String WIDTH_ATTR = "width";
	/**CLIENTID_ATTR */
	String CLIENTID_ATTR = "clientId";
	/**LEGEND_ATTR */
	String LEGEND_ATTR = "legend";
	/**FIELDSET_ELEM */
	String FIELDSET_ELEM = "fieldset";
	//ARRAYS now
	/** The EVENT_HANDLER_ATTRIBUTES_WITHOUT_ONCLICK. */
	String[] EVENT_HANDLER_ATTRIBUTES_WITHOUT_ONCLICK = { ONDBLCLICK_ATTR,
			ONMOUSEDOWN_ATTR, ONMOUSEUP_ATTR, ONMOUSEOVER_ATTR,
			ONMOUSEMOVE_ATTR, ONMOUSEOUT_ATTR, ONKEYPRESS_ATTR, ONKEYDOWN_ATTR,
			ONKEYUP_ATTR };
	String[] INPUTTEXT_BEHAVIOUR_ATTRIBUTES = { BINDING_ATTR, RENDERED_ATTR,
			ONCHANGE_ATTR, READONLY_ATTR, ONSELECT_ATTR, ONFOCUS_ATTR,
			ONBLUR_ATTR, DISABLED_ATTR, ALT_ATTR, ACCESSKEY_ATTR,
			VALUE_CHANGE_LISTENER_ATTR, VALIDATOR_ATTR, REQUIRED_ATTR,
			CONVERTER_ATTR, TABINDEX_ATTR, IMMEDIATE_ATTR, INPUT_TYPE_TEXT,
			MAXLENGTH_ATTR, SIZE_ATTR };
	String[] EVENT_HANDLER_ATTRIBUTES = (String[]) concat(
			EVENT_HANDLER_ATTRIBUTES_WITHOUT_ONCLICK,
			new String[] { ONCLICK_ATTR });
	String[] INPUTTEXT_BEHAVIOUS_AND_EVENT_HANDLER_ATTRIBUTES = (String[]) concat(
			INPUTTEXT_BEHAVIOUR_ATTRIBUTES, EVENT_HANDLER_ATTRIBUTES);
	/** The UNIVERSAL_ATTRIBUTES. */
	String[] UNIVERSAL_ATTRIBUTES = (String[]) concat(
			UNIVERSAL_ATTRIBUTES_WITHOUT_STYLE, new String[] { STYLE_ATTR,
					STYLE_CLASS_ATTR });
	/** The Suggested InputText pass through attributes. without style, value, title and id attributes*/
	String[] SUGGESTED_OR_EASE_INPUTTEXT_PASSTHROUGH_ATTRIBUTES = (String[]) concat(
			INPUTTEXT_BEHAVIOUS_AND_EVENT_HANDLER_ATTRIBUTES,
			UNIVERSAL_ATTRIBUTES_WITHOUT_TITLE_AND_STYLE);
	/** The TABL e_ attributes. */
	String[] TABLE_ATTRIBUTES = { ALIGN_ATTR, BGCOLOR_ATTR, BORDER_ATTR,
			CELLPADDING_ATTR, CELLSPACING_ATTR, DATAFLD_ATTR, DATASRC_ATTR,
			DATAFORMATAS_ATTR, FRAME_ATTR, RULES_ATTR, SUMMARY_ATTR, WIDTH_ATTR };
	String[] COMMON_PASSTROUGH_ATTRIBUTES = (String[]) concat(
			EVENT_HANDLER_ATTRIBUTES, UNIVERSAL_ATTRIBUTES);
	String[] TABLE_PASSTHROUGH_ATTRIBUTES = (String[]) concat(TABLE_ATTRIBUTES,
			COMMON_PASSTROUGH_ATTRIBUTES);
}
/**
 *  Modification History:
 *
 *  $Log: JsfHtmlAttributes.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.10  2012/08/18 00:49:52  mwrrv3
 *  Code clean up and fixed PMD issues.
 *
 *  Revision 1.9  2011/06/10 23:13:15  mwyxg1
 *  move ArrayUtils from ui package to fw package
 *
 *  Revision 1.8  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.7  2010/06/30 18:34:09  mwskd2
 *  FORM_ID is added
 *
 *  Revision 1.6  2010/06/21 23:00:49  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.4.2.1  2010/06/20 18:07:00  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.5  2010/06/17 16:28:34  mwskd2
 *  tabindex attribute is added to render
 *
 *  Revision 1.4  2010/05/27 19:52:46  mwskd2
 *  added Suggested and ease pass through attributes
 *
 *  Revision 1.3  2010/05/04 00:09:44  mwpxp2
 *  Added fixme
 *
 *  Revision 1.2  2010/03/22 23:58:42  mwpxp2
 *  Fixed file footer
 *
 */
