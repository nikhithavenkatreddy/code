/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.OfficeCityCode;
import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;
import gov.ca.dmv.ease.ui.component.impl.SuggestedSelectItem;
import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;
import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;
import gov.ca.dmv.ease.ui.util.impl.HtmlRendererUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.el.ValueBinding;

/**
 * Description: This class is the extension of @see CodedInputTextRenderer with an additional feature of showing the
 * suggestions as the user enters the CodeSetName object names with respect to the code set name attribute. To accomplish 
 * this feature, it builds code set text depending upon the entry by the user. 
 * File: SuggestedInputTextRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.renderer.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SuggestedInputTextRenderer extends CodedInputTextRenderer {
	/**
	 * Build the code set text that will ultimately be used to build the selections.
	 * @param clientId the client id
	 * @param codeSetName the code set name
	 * @param highlightMatch the highlight match
	 * @param popupWidth the popup width
	 * @return the text
	 */
	@SuppressWarnings("unchecked")
	private String buildCodeSetText(String clientId, String codeSetNames,
			boolean highlightMatch, String popupWidth, String officeId) {
		StringBuilder codeSetsSb = new StringBuilder();
		codeSetsSb.append("[").append(clientId).append(";").append(
				highlightMatch ? "Y" : "N").append(";").append(
				popupWidth == null ? "" : popupWidth).append("[");
		//If the code set name is city code then process differently.
		if ("CityCode".equalsIgnoreCase(codeSetNames)) {
			if (officeId != null) {
				List <OfficeCityCode> officeCityCodeList = (List <OfficeCityCode>) FacesUtils
						.getApplicationScope().get(officeId);
				if (officeCityCodeList != null) {
					//Sort the list based on the city code.
					Collections.sort(officeCityCodeList);
					for (OfficeCityCode officeCityCode : officeCityCodeList) {
						String codesetLabel = officeCityCode.getCityCode()
								+ " - " + officeCityCode.getCityName();
						codeSetsSb.append("[").append(
								officeCityCode.getCityCode()).append(";")
								.append(codesetLabel).append("]");
					}
				}
			}
		}
		else {
			//Split the code set names with comma separated values.
			String[] csName = codeSetNames.split(",");
			//This list holds all the select items related to one or more code sets.
			List <SuggestedSelectItem> totalSelectItemsList = new ArrayList <SuggestedSelectItem>();
			for (String codeSetName : csName) {
				//Add all the select items to the total list
				if ((List <SuggestedSelectItem>) FacesUtils
						.getApplicationScope().get(codeSetName) != null) {
					totalSelectItemsList
							.addAll((List <SuggestedSelectItem>) FacesUtils
									.getApplicationScope().get(codeSetName));
				}
			}
			if (totalSelectItemsList != null) {
				//Sort the list based on the select item label.
				Collections.sort(totalSelectItemsList);
				for (SuggestedSelectItem selectItem : totalSelectItemsList) {
					String code = "";
					if (selectItem.getValue() instanceof CodeSetElement) {
						CodeSetElement value = (CodeSetElement) selectItem
								.getValue();
						code = value.getCode();
					}
					else {
						code = (String) selectItem.getValue();
					}
					String label = selectItem.getLabel();
					codeSetsSb.append("[").append(code).append(";").append(
							label).append("]");
				}
			}
		}
		codeSetsSb.append("]]");
		return codeSetsSb.toString();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextRenderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		HtmlSuggestedInputText inputText = (HtmlSuggestedInputText) component;
		String codeSetName = inputText.getCodeSetName();
		//If the code set name is not hard coded then get the value from 
		//value binding object. e.g: SSN VERIF Code set name is dynamic.
		if (codeSetName == null) {
			ValueBinding valueBinding = component
					.getValueBinding("codeSetName");
			if (valueBinding != null) {
				codeSetName = (String) valueBinding.getValue(context);
			}
		}
		boolean highlightMatch = inputText.isHighlightMatch();
		String popupWidth = inputText.getPopupWidth();
		String clientId = inputText.getClientId(context);
		ValueBinding valueBinding = component.getValueBinding("officeId");
		String officeId = "";
		if (valueBinding != null) {
			officeId = (String) valueBinding.getValue(context);
		}
		ResponseWriter writer = context.getResponseWriter();
		Map <String, Object> attrs = component.getAttributes();
		boolean hasErrors = hasMessages(context, inputText);
		Object value = "";
		String msgSummary = getMessageSummary(clientId, component, inputText);
		String title = (attrs.get(JsfHtmlAttributes.TITLE_ATTR) != null) ? (String) attrs
				.get(JsfHtmlAttributes.TITLE_ATTR)
				: "";
		if (attrs.get(JsfHtmlAttributes.VALUE_ATTR) != null) {
			if (hasErrors) {
				value = "" + inputText.getSubmittedValue();
			}
			else {
				value = (attrs.get(JsfHtmlAttributes.VALUE_ATTR) instanceof CodeSetElement) ? ((CodeSetElement) attrs
						.get(JsfHtmlAttributes.VALUE_ATTR)).getCode()
						: attrs.get(JsfHtmlAttributes.VALUE_ATTR);
			}
		}
		else {
			if (hasErrors) {
				value = "" + inputText.getSubmittedValue();
			}
			else {
				value = "";
			}
		}
		if (value == null)
			value = "";
		writer.startElement(JsfHtmlAttributes.INPUT_ELEM, inputText);
		HtmlRendererUtils
				.renderHtmlAttributes(
						writer,
						component,
						JsfHtmlAttributes.SUGGESTED_OR_EASE_INPUTTEXT_PASSTHROUGH_ATTRIBUTES);
		String styleClass = (String) component.getAttributes().get(
				JsfHtmlAttributes.STYLE_CLASS_ATTR);
		HtmlRendererUtils.writeIdIfNecessary(writer, component, context);
		writer.writeAttribute(JsfHtmlAttributes.NAME_ATTR, clientId, null);
		if (styleClass != null) {
			if (hasErrors) {
				styleClass += " " + PageConstants.REQUIRED_STYLE_CLASS;
			}
			writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR, styleClass,
					null);
		}
		else if (hasErrors) {
			writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR,
					PageConstants.REQUIRED_STYLE_CLASS, null);
		}
		if (hasErrors) {
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, msgSummary,
					null);
		}
		else {
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, title, null);
		}
		writer.writeAttribute(JsfHtmlAttributes.VALUE_ATTR, value, null);
		writer.endElement(JsfHtmlAttributes.INPUT_ELEM);
		if (hasErrors) {
			writer.startElement(JsfHtmlAttributes.IMG_ELEM, inputText);
			writer.writeAttribute(JsfHtmlAttributes.ID_ATTR, clientId
					+ "ErrorImage", null);
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, msgSummary,
					null);
			writer.writeAttribute(JsfHtmlAttributes.ALT_ATTR, "", null);
			writer.writeAttribute(JsfHtmlAttributes.HEIGHT_ATTR, "20px", null);
			writer.writeAttribute(JsfHtmlAttributes.STYLE_ATTR,
					"vertical-align: middle;", null);
			writer.writeAttribute(JsfHtmlAttributes.SRC_ATTR,
					"../images/req_arrow.jpg", null);
			writer.endElement(JsfHtmlAttributes.IMG_ELEM);
			//Add the message summary to the faces context to display the error 
			//message at the bottom of the screen.
			if (!msgSummary.endsWith("uiErrorMsg")) {
				FacesUtils.addErrorMessage(clientId, msgSummary);
			}
		}
		writer.startElement(JsfHtmlAttributes.SPAN_ELEM, inputText);
		writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR, "suggest-hidden",
				null);
		String text = buildCodeSetText(clientId, codeSetName, highlightMatch,
				popupWidth, officeId);
		writer.writeText(text, null);
		writer.endElement(JsfHtmlAttributes.SPAN_ELEM);
		writer.flush();
	}

	/**
	 * 
	 * @param componentId
	 * @param uiFormComponent
	 * @param uiInput
	 * @return
	 */
	private String getMessageSummary(String componentId,
			UIComponent uiFormComponent, UIInput uiInput) {
		String messageSummary = "";
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages(componentId);
		while (messages.hasNext()) {
			FacesMessage facesMessage = (FacesMessage) messages.next();
			messageSummary = facesMessage.getSummary();
			break;
		}
		return messageSummary;
	}

	@SuppressWarnings("unchecked")
	private boolean hasMessages(FacesContext context, UIComponent component) {
		if (component == null) {
			return false;
		}
		String compId = component.getClientId(context);
		Iterator <String> clientIds = context.getClientIdsWithMessages();
		boolean found = false;
		while (clientIds.hasNext()) {
			String clientId = clientIds.next();
			if (clientId != null && clientId.equals(compId)) {
				found = true;
				break;
			}
		}
		return found;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SuggestedInputTextRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.18  2012/08/02 01:06:24  mwrrv3
 *  Added sorting for the city codes and code set elements (Defect# 7141).
 *
 *  Revision 1.17  2011/12/03 02:25:35  mwrrv3
 *  Updated the code to fix defect# 6930 (don't display SSN VERI code).
 *
 *  Revision 1.16  2010/10/08 20:50:59  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.15  2010/08/26 20:38:10  mwrrv3
 *  Added check for null pointer exception.
 *
 *  Revision 1.14  2010/08/25 21:13:21  mwrrv3
 *  Updated the buildCodeSetText method to support multiple code set elements.
 *
 *  Revision 1.13  2010/07/17 23:32:50  mwrrv3
 *  Added null check for value.
 *
 *  Revision 1.12  2010/07/08 02:04:41  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.11  2010/06/21 23:00:46  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.9.2.2  2010/06/20 18:06:56  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.10  2010/06/08 17:18:31  mwrrv3
 *  Modified the code to support UI and BR error messages.
 *
 *  Revision 1.9  2010/05/27 19:53:05  mwskd2
 *  attribute values pulling from jsfHtmlAttributes interface
 *
 *  Revision 1.8  2010/05/13 20:05:16  mwrpk
 *  bug fix
 *
 *  Revision 1.5  2010/05/08 01:33:31  mwskd2
 *  added available attributes while rendering
 *
 *  Revision 1.4  2010/05/07 01:00:40  mwskd2
 *  altered the renderer to render and image adjacent to it.
 *
 *  Revision 1.3  2010/03/31 16:44:31  mwrrv3
 *  Added check for null code set values.
 *
 *  Revision 1.2  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
