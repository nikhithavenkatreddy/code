/**
 *
 */
package gov.ca.dmv.ease.ui.page.impl;

import gov.ca.dmv.ease.app.context.impl.SessionContext;
import gov.ca.dmv.ease.app.session.impl.SessionData;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.handler.IActionsHandler;
import gov.ca.dmv.ease.ui.handler.impl.ActionsHandler;

import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Description: I am abstract superclass for ui backing beans, often referred to as "pages".
 *
 * File: AbstractBackingBean.java
 * Module:  gov.ca.dmv.ease.ui.constants
 * Created: Sep 26, 2012
 * @author mwpxp2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class AbstractBackingBean implements PageConstants, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6901512477272316593L;

	/**
	 * Instantiates a new abstract backing bean.
	 */
	protected AbstractBackingBean() {
		super();
	}

	/**
	 * Gets the actions handler bean.
	 *
	 * @return the actions handler bean
	 */
	protected IActionsHandler getActionsHandlerFromAppContext() {
		ApplicationContext aCtx = getApplicationContextFromFaces();
		if (aCtx != null) {
			IActionsHandler actionsHandler = (IActionsHandler) getApplicationContextFromFaces()
					.getBean(ACTIONS_HANDLER);
			return actionsHandler;
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the application context.
	 *
	 * @return the application context
	 */
	protected ApplicationContext getApplicationContextFromFaces() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if (facesContext != null) {
			ServletContext servletContext = (ServletContext) facesContext
					.getExternalContext().getContext();
			ApplicationContext applicationContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(servletContext);
			return applicationContext;
		}
		return null;
	}

	/**
	 * Gets the session context bean.
	 *
	 * @return the session context bean
	 */
	protected SessionContext getSessionContextBean() {
		ApplicationContext aCtx = getApplicationContextFromFaces();
		if (aCtx != null) {
			return (SessionContext) EaseProxyUtils.getProxyObject(aCtx
					.getBean(SESSION_CONTEXT));
		}
		else {
			return null;
		}
	}

	/**
	 * Gets the session data bean.
	 *
	 * @return the session data bean
	 */
	protected SessionData getSessionDataBean() {
		ApplicationContext aCtx = getApplicationContextFromFaces();
		if (aCtx != null) {
			return (SessionData) EaseProxyUtils
					.getProxyObject(getApplicationContextFromFaces().getBean(
							SESSION_DATA));
		}
		else {
			return null;
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractBackingBean.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/09/27 00:51:11  mwpxp2
 *  Added a number of null checks
 *
 *  Revision 1.1  2012/09/27 00:46:38  mwpxp2
 *  Initial - added common utility methods for accessing actions handler, context, etc.
 *
 */
