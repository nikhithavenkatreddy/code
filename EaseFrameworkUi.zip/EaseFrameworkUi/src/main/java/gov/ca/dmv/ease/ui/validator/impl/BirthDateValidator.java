/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.date.impl.CurrentDateProvider;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.Date;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: BirthDateValidator is a custom validator which validates
 * the customer birth date.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: BirthDateValidator.java 
 * Created: May 06, 2012
 * @author MWSXV5
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class BirthDateValidator extends ValidatorBase {
	private static final String ERROR_DATE_MESSAGE = "DATE MUST BE EQUAL OR PRIOR TO CURRENT DATE";
	/**
	 * Instantiates a new BirthDateValidator.
	 */
	public BirthDateValidator() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		String valueString = null;
		Date bithDate = null;
		if (value == null) {
			return;
		}
		if (value instanceof Date) {
			bithDate = (Date) value;
		}
		if (value instanceof String) {
			valueString = (String) value;
		}
		// Validate the birth date against current system date.
		// If the birth date is future date then throw validation error message 
		Date systemDate = CurrentDateProvider.getInstance().getSystemDate();
		if (bithDate != null && systemDate != null
				&& bithDate.after(systemDate)) {
			throw new ValidatorException(FacesUtils.createErrorMessage(
					valueString, ERROR_DATE_MESSAGE));
		}
	}
}
/**
 * Modification History:
 * 
 * $Log: BirthDateValidator.java,v $
 * Revision 1.1  2012/10/01 02:58:06  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.1  2012/05/06 21:09:18  mwsxv5
 * Initial Commit - Birth Date Validator.
 *
 */
