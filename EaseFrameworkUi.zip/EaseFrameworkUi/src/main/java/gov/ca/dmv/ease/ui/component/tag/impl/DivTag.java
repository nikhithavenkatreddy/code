package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.UiDiv;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.webapp.UIComponentTag;

/**
 * Description: //TODO - provide description!
 * File: DivTag.java
 * Module:  gov.ca.dmv.ease.ui.component.tag.impl
 * Created: 2009
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class DivTag extends UIComponentTag {
	/** The style class. */
	private String styleClass;

	/**
	 * Instantiates a new div tag.
	 */
	public DivTag() {
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return UiDiv.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return UiDiv.RENDERER_TYPE;
	}

	/**
	 * Gets the styleclass.
	 * 
	 * @return the styleclass
	 */
	public String getStyleclass() {
		return styleClass;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	public void setProperties(UIComponent component) {
		super.setProperties(component);
		setStringProperty(component, "styleclass", styleClass);
	}

	/**
	 * Sets the string property.
	 * 
	 * @param component the component
	 * @param name the name
	 * @param value the value
	 */
	private void setStringProperty(UIComponent component, String name,
			String value) {
		if (value == null) {
			return;
		}
		if (isValueReference(value)) {
			component.setValueBinding(name, FacesContext.getCurrentInstance()
					.getApplication().createValueBinding(value));
		}
		else {
			component.getAttributes().put(name, value);
		}
	}

	/**
	 * Sets the styleclass.
	 * 
	 * @param styleClass the new styleclass
	 */
	public void setStyleclass(String styleClass) {
		this.styleClass = styleClass;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: DivTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:53:20  mwpxp2
 *  Added class header, javadoc
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/22 16:55:02  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/22 00:40:40  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/21 23:51:33  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.3  2009/08/03 22:22:03  mwbvc
 *  custom JSF component for DIV tag - to use the DIV with rendered attribute
 *
*/
