/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;

import javax.faces.component.UIComponent;

/**
 * Description: This class is the extension of @see CodedInputTextTag with some additonal setters and getters
 * used to show up the suggestion.
 * File: SuggestedInputTextTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SuggestedInputTextTag extends CodedInputTextTag {
	/** The highlight match. */
	private String highlightMatch = null;
	/** The popup width. */
	private String popupWidth = null;
	/**
	 * Instantiates a new suggested input text tag.
	 */
	public SuggestedInputTextTag() {
		super();
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return HtmlSuggestedInputText.COMPONENT_TYPE;
	}

	/**
	 * Gets the highlight match.
	 * 
	 * @return highlight match
	 */
	public String getHighlightMatch() {
		return highlightMatch;
	}

	/**
	 * Gets the popup width.
	 * 
	 * @return the popup width
	 */
	public String getPopupWidth() {
		return popupWidth;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.SuggestedInputText";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#release()
	 */
	@Override
	public void release() {
		super.release();
		highlightMatch = null;
		popupWidth = null;
	}

	/**
	 * Sets the highlight match.
	 * 
	 * @param highlightMatch the new highlight match
	 */
	public void setHighlightMatch(String highlightMatch) {
		this.highlightMatch = highlightMatch;
	}

	/**
	 * Sets the popup width.
	 * 
	 * @param popupWidth the new popup width
	 */
	public void setPopupWidth(String popupWidth) {
		this.popupWidth = popupWidth;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		HtmlSuggestedInputText inputText = (HtmlSuggestedInputText) component;
		inputText.setHighlightMatch(Boolean.valueOf(highlightMatch));
		inputText.setPopupWidth(popupWidth);
	}
}
/**
 *  Modification History:
 *
 *  $Log: SuggestedInputTextTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/08 20:50:58  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
