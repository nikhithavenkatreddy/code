/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.ID_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.INPUT_ELEM;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.INPUT_TYPE_HIDDEN;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.NAME_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TYPE_ATTR;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.VALUE_ATTR;
import gov.ca.dmv.ease.ui.component.impl.HtmlSynchronizedForm;
import gov.ca.dmv.ease.ui.handler.impl.ActionsHandler;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.component.UIComponent;
import javax.faces.component.UIForm;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.faces.render.Renderer;
import javax.servlet.http.HttpSession;

/**
 * Description: This class is the extension of @see Renderer with a change in the behaviour the way 
 * it Renders as this component has an extra feature of rendering the tokens for every request.
 * File: SynchronizedFormRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 14, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SynchronizedFormRenderer extends Renderer {
	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#decode(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void decode(FacesContext context, UIComponent component) {
		getFormRenderer(context).decode(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws IOException {
		getFormRenderer(context).encodeBegin(context, component);
		String token = getToken(context);
		if (token != null) {
			HtmlSynchronizedForm form = (HtmlSynchronizedForm) component;
			String clientId = form.getClientId(context);
			ResponseWriter writer = context.getResponseWriter();
			//token hidden element
			writer.startElement(INPUT_ELEM, form);
			writer.writeAttribute(NAME_ATTR, clientId + ":token", null);
			writer.writeAttribute(TYPE_ATTR, INPUT_TYPE_HIDDEN, null);
			writer.writeAttribute(VALUE_ATTR, token, null);
			writer.endElement(INPUT_ELEM);
			
			//contextPathName hidden element
			writer.startElement(INPUT_ELEM, form);
			writer.writeAttribute(NAME_ATTR, clientId + ":contextPathName",
					null);
			writer.writeAttribute(ID_ATTR, clientId + ":contextPathName", null);
			writer.writeAttribute(TYPE_ATTR, INPUT_TYPE_HIDDEN, null);
			writer
					.writeAttribute(VALUE_ATTR, getContextPathName(context),
							null);
			writer.endElement(INPUT_ELEM);
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeChildren(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeChildren(FacesContext context, UIComponent component)
			throws IOException {
		getFormRenderer(context).encodeChildren(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		getFormRenderer(context).encodeEnd(context, component);
	}

	/**
	 * 
	 * @param context
	 * @return
	 */
	private String getContextPathName(FacesContext context) {
		String contextPathName = null;
		HttpSession session = (HttpSession) context.getExternalContext()
				.getSession(false);
		if (session != null) {
			ActionsHandler handler = (ActionsHandler) session
					.getAttribute("actionsHandler");
			if (handler != null) {
				contextPathName = handler.getContextPath();
			}
		}
		return contextPathName;
	}

	/**
	 * Gets the default renderer type of an HTML Form component
	 * 
	 * @param context the context
	 * 
	 * @return the form renderer
	 */
	protected Renderer getFormRenderer(FacesContext context) {
		RenderKitFactory rkFactory = (RenderKitFactory) FactoryFinder
				.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
		RenderKit defaultRenderKit = rkFactory.getRenderKit(context,
				RenderKitFactory.HTML_BASIC_RENDER_KIT);
		return defaultRenderKit.getRenderer(UIForm.COMPONENT_FAMILY,
				"javax.faces.Form");
	}

	/**
	 * Gets the token number for every request. if already existed, this method will return the existed token else
	 * generates a new token and returns it.
	 * 
	 * @param context the context
	 * 
	 * @return the token
	 */
	private String getToken(FacesContext context) {
		String token = null;
		HttpSession session = (HttpSession) context.getExternalContext()
				.getSession(false);
		if (session != null) {
			ActionsHandler handler = (ActionsHandler) session
					.getAttribute("actionsHandler");
			if (handler != null) {
				token = handler.generateToken();
			}
		}
		return token;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SynchronizedFormRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/09/07 02:19:26  mwrrv3
 *  Replaced literals with constants and code clean up.
 *
 *  Revision 1.6  2011/10/03 16:35:03  mwrrv3
 *  Remove code related to HELP content.
 *
 *  Revision 1.5.40.1  2011/09/30 23:22:36  mwrrv3
 *  Remove code related to HELP content.
 *
 *  Revision 1.5  2010/05/04 00:11:34  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.4  2010/05/02 18:26:36  mwskd2
 *  Help text content
 *
 *  Revision 1.3  2010/03/22 23:51:39  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
