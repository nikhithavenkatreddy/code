/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlSynchronizedForm;

import javax.faces.component.UIComponent;

/**
 * Description: This class is the extension of @see AbstractBaseTag with some more setter and getter properties that are
 * related to a basic HTML Form.
 * File: SynchronizedFormTag.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 14, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SynchronizedFormTag extends AbstractBaseTag {
	/** The accept. */
	private String accept;
	/** The accept charset. */
	private String acceptCharset;
	/** The enctype. */
	private String enctype;
	/** The onreset. */
	private String onreset;
	/** The onsubmit. */
	private String onsubmit;
	/** The target. */
	private String target;

	/**
	 * Instantiates a new synchronized form tag.
	 */
	public SynchronizedFormTag() {
		super();
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	@Override
	public String getComponentType() {
		return HtmlSynchronizedForm.COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return "gov.ca.dmv.ease.SynchronizedForm";
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.tag.impl.AbstractBaseTag#release()
	 */
	@Override
	public void release() {
		super.release();
		accept = null;
		acceptCharset = null;
		enctype = null;
		onreset = null;
		onsubmit = null;
		target = null;
	}

	/**
	 * Sets the accept.
	 * 
	 * @param accept the new accept
	 */
	public void setAccept(String accept) {
		this.accept = accept;
	}

	/**
	 * Sets the accept charset.
	 * 
	 * @param acceptCharset the new accept charset
	 */
	public void setAcceptCharset(String acceptCharset) {
		this.acceptCharset = acceptCharset;
	}

	/**
	 * Sets the enctype.
	 * 
	 * @param enctype the new enctype
	 */
	public void setEnctype(String enctype) {
		this.enctype = enctype;
	}

	/**
	 * Sets the onreset.
	 * 
	 * @param onreset the new onreset
	 */
	public void setOnreset(String onreset) {
		this.onreset = onreset;
	}

	/**
	 * Sets the onsubmit.
	 * 
	 * @param onsubmit the new onsubmit
	 */
	public void setOnsubmit(String onsubmit) {
		this.onsubmit = onsubmit;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.tag.impl.AbstractBaseTag#setProperties(javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		HtmlSynchronizedForm form = (HtmlSynchronizedForm) component;
		form.setAccept(accept);
		form.setAcceptcharset(acceptCharset);
		form.setEnctype(enctype);
		form.setOnreset(onreset);
		form.setOnsubmit(onsubmit);
		form.setTarget(target);
	}

	/**
	 * Sets the target.
	 * 
	 * @param target the new target
	 */
	public void setTarget(String target) {
		this.target = target;
	}
}
/**
 *  Modification History:
 *
 *  $Log: SynchronizedFormTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
