/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import java.io.Serializable;
import java.util.List;

/**
 * Description: AttachedListStateWrapper is used to save the state
 * Module: gov.ca.dmv.ease.ui.validator.impl.AttachedListStateWrapper 
 * Created: Oct 19, 2009
 * @author mwbvc
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/10/18 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
class AttachedListStateWrapper implements Serializable {
	private static final long serialVersionUID = -9104415031466106764L;
	private List wrappedStateList;

	public AttachedListStateWrapper(List wrappedStateList) {
		wrappedStateList = wrappedStateList;
	}

	public List getWrappedStateList() {
		return wrappedStateList;
	}
}
