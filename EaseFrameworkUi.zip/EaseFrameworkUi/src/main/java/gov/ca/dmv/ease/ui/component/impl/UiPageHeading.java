/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

/**
 * Description: I represent UI page heading
 * File: UiPageHeading.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: 2009 
 * @author NN  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class UiPageHeading extends UIComponentBase {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.Output";

	/**
	 * Gets the value.
	 * 
	 * @param value the value
	 * 
	 * @return the value
	 * 
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	private static String getValue(String value)
			throws UnsupportedEncodingException {
		if (value != null) {
			if (value.indexOf("   ") > 0) {
				value = value.replaceAll("   ", "&nbsp;&nbsp;&nbsp;");
			}
			if (value.indexOf("  ") > 0) {
				value = value.replaceAll("  ", "&nbsp;&nbsp;");
			}
		}
		return value;
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.UIComponentBase#encodeBegin(javax.faces.context.FacesContext)
	 * 	 * If our rendered property is true, 
	 * render the beginning of the current state of this UIComponent to the response 
	 * contained in the specified FacesContext.
	 */
	@Override
	public void encodeBegin(FacesContext context) throws IOException {
		ResponseWriter writer = context.getResponseWriter();
		String pageHeading = (String) getAttributes().get("pageHeading");
		if (pageHeading != null) {
			pageHeading = getValue(pageHeading);
			writer.write(pageHeading);
		}
		else {
			writer.writeText("", null);
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.component.UIComponent#getFamily()
	 */
	@Override
	public String getFamily() {
		return "PageHeadingFamily";
	}
}
/**
 * Modification History:
 * 
 * $Log: UiPageHeading.java,v $
 * Revision 1.1  2012/10/01 02:58:06  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.2  2010/03/22 23:48:27  mwpxp2
 * Added class header
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.2  2009/10/27 00:19:50  mwgxk2
 * Added Commit.
 *
 * Revision 1.1  2009/10/22 16:55:01  mwbvc
 * Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 * Revision 1.1  2009/10/22 00:40:41  mwbvc
 * Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 * Revision 1.1  2009/10/21 23:51:34  mwbvc
 * changed the package names and refactored the code
 *
 * Revision 1.2  2009/08/27 00:29:29  mwskd2
 * extended abstractBaseClass to get use of some attributes
 *
 * Revision 1.1  2009/08/11 18:23:36  mwbvc
 * Component classes to support pageHeading Tag
 * Revision 1.3 2009/08/03 22:22:03 mwbvc custom JSF
 * component for DIV tag - to use the DIV with rendered attribute
 * 
 */
