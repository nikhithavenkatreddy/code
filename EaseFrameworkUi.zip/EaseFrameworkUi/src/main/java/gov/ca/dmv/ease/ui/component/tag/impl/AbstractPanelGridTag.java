/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;

import javax.faces.component.UIComponent;

/**
 * Description: I am this and that File: AbstractPanelGridTag.java
 * Module: gov.ca.dmv.ease.ui.component.impl.panel 
 * Created: Sep 17, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/17 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public abstract class AbstractPanelGridTag extends AbstractBaseTag {
	// attributes for panelGrid component
	/** The align. */
	private String align;
	/** The bgcolor. */
	private String bgcolor;
	/** The border. */
	private String border;
	/** The cellpadding. */
	private String cellpadding;
	/** The cellspacing. */
	private String cellspacing;
	/** The column classes. */
	private String columnClasses;
	/** The columns. */
	private String columns;
	/** The datafld. */
	private String datafld;
	/** The dataformatas. */
	private String dataformatas;
	/** The datasrc. */
	private String datasrc;
	/** The footer class. */
	private String footerClass;
	/** The frame. */
	private String frame;
	/** The header class. */
	private String headerClass;
	/** The row classes. */
	private String rowClasses;
	/** The rules. */
	private String rules;
	/** The summary. */
	private String summary;
	/** The width. */
	private String width;

	/**
	 * Sets null to all attributes and releases from the state.
	 */
	@Override
	public void release() {
		super.release();
		align = null;
		border = null;
		bgcolor = null;
		cellpadding = null;
		cellspacing = null;
		datafld = null;
		datasrc = null;
		dataformatas = null;
		frame = null;
		rules = null;
		summary = null;
		width = null;
		columnClasses = null;
		columns = null;
		footerClass = null;
		headerClass = null;
		rowClasses = null;
	}

	/**
	 * Sets the table align attribute value.
	 * 
	 * @param align the align
	 */
	public void setAlign(String align) {
		this.align = align;
	}

	/**
	 * Sets the table background attribute value.
	 * 
	 * @param bgcolor the bgcolor
	 */
	public void setBgcolor(String bgcolor) {
		this.bgcolor = bgcolor;
	}

	/**
	 * Sets the Table border attribute value.
	 * 
	 * @param border the border
	 */
	public void setBorder(String border) {
		this.border = border;
	}

	/**
	 * Sets the table cell padding attribute value.
	 * 
	 * @param cellpadding the cellpadding
	 */
	public void setCellpadding(String cellpadding) {
		this.cellpadding = cellpadding;
	}

	/**
	 * Sets the table cell spacing attribute value.
	 * 
	 * @param cellspacing the cellspacing
	 */
	public void setCellspacing(String cellspacing) {
		this.cellspacing = cellspacing;
	}

	/**
	 * Sets the Table column style classes.
	 * 
	 * @param columnClasses the column classes
	 */
	public void setColumnClasses(String columnClasses) {
		this.columnClasses = columnClasses;
	}

	/**
	 * Sets the number of columns for a table.
	 * 
	 * @param columns the columns
	 */
	public void setColumns(String columns) {
		this.columns = columns;
	}

	/**
	 * Sets the table data filed attribute.
	 * 
	 * @param datafld the datafld
	 */
	public void setDatafld(String datafld) {
		this.datafld = datafld;
	}

	/**
	 * Sets the Table data format.
	 * 
	 * @param dataformatas the dataformatas
	 */
	public void setDataformatas(String dataformatas) {
		this.dataformatas = dataformatas;
	}

	/**
	 * Sets the table data source attribute.
	 * 
	 * @param datasrc the datasrc
	 */
	public void setDatasrc(String datasrc) {
		this.datasrc = datasrc;
	}

	/**
	 * Sets the CSS style classes for Table Footer.
	 * 
	 * @param footerClass the footer class
	 */
	public void setFooterClass(String footerClass) {
		this.footerClass = footerClass;
	}

	/**
	 * Sets the frame attribute of a Table.
	 * 
	 * @param frame the frame
	 */
	public void setFrame(String frame) {
		this.frame = frame;
	}

	/**
	 * Sets the CSS style classes for Table Header.
	 * 
	 * @param headerClass the header class
	 */
	public void setHeaderClass(String headerClass) {
		this.headerClass = headerClass;
	}

	/**
	 * Sets the PanelGrid component properties.
	 * 
	 * @param component the component
	 */
	@Override
	protected void setProperties(UIComponent component) {
		super.setProperties(component);
		addAttribute(component, JsfHtmlAttributes.ALIGN_ATTR, align);
		addAttribute(component, JsfHtmlAttributes.BORDER_ATTR, border);
		addAttribute(component, JsfHtmlAttributes.BGCOLOR_ATTR, bgcolor);
		addAttribute(component, JsfHtmlAttributes.CELLPADDING_ATTR, cellpadding);
		addAttribute(component, JsfHtmlAttributes.CELLSPACING_ATTR, cellspacing);
		addAttribute(component, JsfHtmlAttributes.DATAFLD_ATTR, datafld);
		addAttribute(component, JsfHtmlAttributes.DATASRC_ATTR, datasrc);
		addAttribute(component, JsfHtmlAttributes.DATAFORMATAS_ATTR,
				dataformatas);
		addAttribute(component, JsfHtmlAttributes.FRAME_ATTR, frame);
		addAttribute(component, JsfHtmlAttributes.RULES_ATTR, rules);
		addAttribute(component, JsfHtmlAttributes.SUMMARY_ATTR, summary);
		addAttribute(component, JsfHtmlAttributes.WIDTH_ATTR, width);
		addAttribute(component, JsfHtmlAttributes.COLUMN_CLASSES_ATTR,
				columnClasses);
		addAttribute(component, JsfHtmlAttributes.COLUMNS_ATTR, columns);
		addAttribute(component, JsfHtmlAttributes.FOOTER_CLASS_ATTR,
				footerClass);
		addAttribute(component, JsfHtmlAttributes.HEADER_CLASS_ATTR,
				headerClass);
		addAttribute(component, JsfHtmlAttributes.ROW_CLASSES_ATTR, rowClasses);
	}

	/**
	 * Sets the CSS style classes for Table Rows.
	 * 
	 * @param rowClasses the row classes
	 */
	public void setRowClasses(String rowClasses) {
		this.rowClasses = rowClasses;
	}

	/**
	 * Sets the Table Rules attribute.
	 * 
	 * @param rules the rules
	 */
	public void setRules(String rules) {
		this.rules = rules;
	}

	/**
	 * Sets the Table summary attribute.
	 * 
	 * @param summary the summary
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Sets the Table width.
	 * 
	 * @param width the width
	 */
	public void setWidth(String width) {
		this.width = width;
	}
}
/**
 *  Modification History:
 *
 *  $Log: AbstractPanelGridTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
