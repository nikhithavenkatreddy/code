/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.converter.impl;

import static gov.ca.dmv.ease.fw.util.impl.EaseUtil.isNullOrBlank;
import static gov.ca.dmv.ease.ui.constants.PageConstants.DEFAULT_DATE_PATTERN;
import static gov.ca.dmv.ease.ui.constants.PageConstants.RESOURCE_APPLICATION_MESSAGES;
import static gov.ca.dmv.ease.ui.util.impl.FacesUtils.getLabelValue;
import static javax.faces.application.FacesMessage.SEVERITY_ERROR;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;
import javax.faces.convert.DateTimeConverter;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This class is the extension of @see DateTimeConverter 
 * with an additional feature of checking the century entered by the user. 
 * In the Basic DateTimeConverter class by default if user does not enters the 
 * century, "00" will be automatically filled. This class will prevent the 
 * automatic filling and throws "Field Incomplete" error message.
 * File: EaseDateTimeConverter.java
 * Module:  gov.ca.dmv.ease.ui.converter.impl
 * Created: Oct 12, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseDateTimeConverter extends DateTimeConverter {
	/** The Constant LOGGER. */
	protected static final Log LOGGER = LogFactory
			.getLog(EaseDateTimeConverter.class);
	/**
	 * Constant for JSF minimum length.
	 */
	private static final String VALIDATOR_MINIMUM_LENGTH = "javax.faces.validator.LengthValidator.MINIMUM";
	/**
	 * Constant for JSF  invalid alphanumeric characters.
	 */
	private static final String INVALID_ALPHA_NUMERIC_CHARS = "javax.faces.invalidAlphaNumericCharacters";
	/**
	 * Constant for JSF invalid characters (only numbers allowed).
	 */
	private static final String FIELD_MAY_CONTAIN_NUMBERS = "javax.faces.fieldMayContainNumbers";
	/**
	 * Constant for JSF date time validator.
	 */
	private static final String VALIDATOR_DATE_TIME = "javax.faces.validator.DateTime";
	
	/** The application messages. */
	private static final ResourceBundle APP_MESSAGES = ResourceBundle
			.getBundle(RESOURCE_APPLICATION_MESSAGES);
	/** The Date pattern. */
	private String pattern;

	/**
	 * Instantiates a new ease date time converter.
	 */
	public EaseDateTimeConverter() {
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.DateTimeConverter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 */
	@Override
	public Object getAsObject(FacesContext facesContext,
			UIComponent uiComponent, String strDate) {
		if (strDate == null || strDate.equals("")) {
			return null;
		}
		try {
			EaseDateTimeConverter converter = (EaseDateTimeConverter) uiComponent
					.getAttributes().get("converter");
			if (converter.getPattern() != null) {
				setPattern(converter.getPattern());
			}
			DateFormat dateFormat = new SimpleDateFormat(pattern, Locale.US);
			if (getPattern().length() == 8) {
				if (strDate.length() == 8) {
					return validateDateValue(facesContext, uiComponent,
							strDate, dateFormat);
				}
				else {
					throw new ConverterException(getCustomizedFacesMessage(
							strDate, getErrorMessage(VALIDATOR_MINIMUM_LENGTH),
							facesContext, uiComponent));
				}
			}
			else if (getPattern().length() == 6) {
				if (strDate.length() == 6) {
					return validateSixDigitDate(facesContext, uiComponent,
							strDate);
				}
				else {
					throw new ConverterException(getCustomizedFacesMessage(
							strDate, getErrorMessage(VALIDATOR_MINIMUM_LENGTH),
							facesContext, uiComponent));
				}
			}
			else {
				throw new ConverterException(getCustomizedFacesMessage(strDate,
						getErrorMessage(VALIDATOR_DATE_TIME), facesContext,
						uiComponent));
			}
		}
		catch (ParseException e) {
			LOGGER.debug("getAsObject() ParseException: " + e.getMessage());
			throw new ConverterException(getCustomizedFacesMessage(strDate,
					getErrorMessage(VALIDATOR_DATE_TIME), facesContext,
					uiComponent));
		}
	}

	/**
	 * @param facesContext
	 * @param uiComponent
	 * @param strDate
	 * @return
	 * @throws ParseException
	 */
	private Object validateSixDigitDate(FacesContext facesContext,
			UIComponent uiComponent, String strDate) throws ParseException {
		if (StringUtils.isNumeric(strDate)) {
			DateFormat dateFormat = new SimpleDateFormat(pattern, Locale.US);
			Date convertedDate = dateFormat.parse(strDate);
			if (this.isLegalDate(strDate)) {
				return convertedDate;
			}
			else {
				throw new ConverterException(
						getCustomizedFacesMessage(
								strDate,
								getErrorMessage(VALIDATOR_DATE_TIME),
								facesContext, uiComponent));
			}
		}
		else {
			throw new ConverterException(getCustomizedFacesMessage(
					strDate,
					getErrorMessage(INVALID_ALPHA_NUMERIC_CHARS),
					facesContext, uiComponent));
		}
	}

	/**
	 * @param facesContext
	 * @param uiComponent
	 * @param strDate
	 * @param dateFormat
	 * @return
	 * @throws ParseException
	 */
	private Object validateDateValue(FacesContext facesContext,
			UIComponent uiComponent, String strDate, DateFormat dateFormat)
			throws ParseException {
		if (StringUtils.isNumeric(strDate)) {
			if (!isValidDate(dateFormat.parse(strDate))) {
				throw new ConverterException(getCustomizedFacesMessage(strDate,
						getErrorMessage(VALIDATOR_DATE_TIME), facesContext,
						uiComponent));
			}
			else if (Integer.parseInt(strDate.substring(4, 5)) != 0) {
				Date convertedDate = dateFormat.parse(strDate);
				if (this.isLegalDate(strDate)) {
					return convertedDate;
				}
				else {
					throw new ConverterException(getCustomizedFacesMessage(
							strDate, getErrorMessage(VALIDATOR_DATE_TIME),
							facesContext, uiComponent));
				}
			}
			else {
				throw new ConverterException(getCustomizedFacesMessage(strDate,
						getErrorMessage(VALIDATOR_DATE_TIME), facesContext,
						uiComponent));
			}
		}
		else {
			if (strDate.contains("%") || strDate.contains("'")
					|| strDate.contains(".")) {
				throw new ConverterException(getCustomizedFacesMessage(strDate,
						getErrorMessage(FIELD_MAY_CONTAIN_NUMBERS),
						facesContext, uiComponent));
			}
			else {
				throw new ConverterException(getCustomizedFacesMessage(strDate,
						getErrorMessage(INVALID_ALPHA_NUMERIC_CHARS),
						facesContext, uiComponent));
			}
		}
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.DateTimeConverter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public String getAsString(FacesContext facesContext,
			UIComponent uiComponent, Object strDate) {
		DateFormat formatter = null;
		if (!isNullOrBlank(strDate)) {
			String strFinalDate = "";
			try {
				EaseDateTimeConverter converter = (EaseDateTimeConverter) uiComponent
						.getAttributes().get("converter");
				if (converter.getPattern() != null) {
					setPattern(converter.getPattern());
				}
				if (strDate instanceof String)
					strFinalDate = (String) strDate;
				else {
					formatter = new SimpleDateFormat(pattern);
					strFinalDate = formatter.format(strDate);
				}
				return strFinalDate;
			}
			catch (Exception e) {
				LOGGER.debug("EaseDateTimeConverter getAsString(): "
						+ e.getMessage());
				return strDate.toString();
			}
		}
		return "";
	}

	/**
	 * This method customizes the faces message that to be thrown. 
	 * 
	 * @param value the value as string
	 * @param errorMsg the error message
	 * @param facesContext the faces context
	 * @param uiComponent the UI component
	 * 
	 * @return the customized faces message
	 */
	private FacesMessage getCustomizedFacesMessage(String value,
			String errorMsg, FacesContext facesContext, UIComponent uiComponent) {
		return new FacesMessage(SEVERITY_ERROR, errorMsg, getLabelValue(
				uiComponent.getClientId(facesContext), uiComponent)
				+ value);
	}

	/**
	 * This method returns the error message for the argument key from the 
	 * application message resource bundle.
	 * @param key the key
	 * 
	 * @return the error message
	 */
	private String getErrorMessage(String key) {
		return APP_MESSAGES.getString(key);
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.DateTimeConverter#getPattern()
	 */
	@Override
	public String getPattern() {
		if (pattern == null) {
			return DEFAULT_DATE_PATTERN;
		}
		else {
			return pattern;
		}
	}

	/**
	 * Checks if is legal date.
	 * 
	 * @param s the s
	 * 
	 * @return true, if is legal date
	 */
	private boolean isLegalDate(String s) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		sdf.setLenient(false);
		return sdf.parse(s, new ParsePosition(0)) != null;
	}

	/**
	 * 
	 * @param bithDate
	 * @return
	 */
	private Boolean isValidDate(Date bithDate) {
		Calendar oldCalendar = Calendar.getInstance();
		oldCalendar.set(1849, 12, 31);
		Calendar newCalendar = Calendar.getInstance();
		newCalendar.setTime(bithDate);
		if (newCalendar.after(oldCalendar)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.DateTimeConverter#setPattern(java.lang.String)
	 */
	@Override
	public void setPattern(String aDatePattern) {
		pattern = aDatePattern;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseDateTimeConverter.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/09/07 02:19:26  mwrrv3
 *  Replaced literals with constants and code clean up.
 *
 *  Revision 1.15  2012/08/14 20:37:06  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.14  2011/06/09 18:37:27  mwyxg1
 *  clean up
 *
 *  Revision 1.13  2011/06/03 00:49:44  mwark
 *  Added . and ' to the list of charecters that should not be in the date field.
 *
 *  Revision 1.12  2011/05/31 22:03:28  mwark
 *  Updated for the field may contain only numbers message.
 *
 *  Revision 1.11  2010/12/02 00:14:57  mwhys
 *  Moved EaseUtil to .impl package.
 *
 *  Revision 1.10  2010/08/24 20:49:35  mwhys
 *  Fixed a bug that arises when using AspectJ development tool.
 *
 *  Revision 1.9  2010/08/24 17:25:30  mwlft1
 *  Rolled back simple ineffective fix
 *
 *  Revision 1.7  2010/08/16 21:05:04  mwpxp2
 *  Added DEFAULT_DATE_PATTERN and changed initialization of "pattern" to lazy in a getter; added fixmes
 *
 *  Revision 1.6  2010/08/16 18:27:19  mwrrv3
 *  Added code for date validation.
 *
 *  Revision 1.5  2010/06/21 23:00:48  mwcsj3
 *  Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 *  Revision 1.3.10.2  2010/06/20 18:06:59  mwakg
 *  Rebased to June 20, 2010
 *
 *  Revision 1.4  2010/06/07 23:12:29  mwskd2
 *  invalid date logic modified checking for "0" instead of  "00"
 *
 *  Revision 1.3  2010/04/22 19:27:04  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/23 00:00:13  mwpxp2
 *  Fixed file footer
 *
 */
