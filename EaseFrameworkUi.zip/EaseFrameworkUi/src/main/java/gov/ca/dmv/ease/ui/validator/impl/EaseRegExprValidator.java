/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.validator.ValidatorException;

/**
 * Description: EaseRegExprValidator is a custom validator which validates
 * the regular expression
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: EaseRegExprValidator 
 * Created: Oct 19, 2009
 * @author mwbvc
 * @version $Revision: 1.1 $ 
 * Last Changed: $Date: 2012/10/01 02:58:06 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseRegExprValidator extends ValidatorBase {
	/** The Constant VALIDATOR_ID. */
	public static final String VALIDATOR_ID = "gov.ca.dmv.ease.validator.RegExpr";
	/** The regex. */
	private String regex = null;

	/**
	 * Instantiates a new ease reg expr validator.
	 */
	public EaseRegExprValidator() {
	}

	/**
	 * Gets the regex.
	 * 
	 * @return the regex
	 */
	public String getRegex() {
		if (regex != null) {
			return regex;
		}
		ValueBinding valueBinding = getValueBinding("regex");
		return valueBinding != null ? (String) valueBinding.getValue(FacesUtils
				.getFacesContext()) : null;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
		regex = (String) values[1];
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[2];
		values[0] = super.saveState(context);
		values[1] = regex;
		return values;
	}

	/**
	 * Sets the regex.
	 * 
	 * @param regex the new regex
	 */
	public void setRegex(String regex) {
		this.regex = regex;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		Pattern pattern = Pattern.compile(getRegex());
		Matcher matcher = pattern.matcher(((String) value).toUpperCase());
		if (!matcher.matches()) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString().toUpperCase(), getSummaryMessage()));
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseRegExprValidator.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2010/08/05 21:21:49  mwcsj3
 *  Updated header
 *
 *  Revision 1.3  2010/08/03 21:06:42  mwskd2
 *  value to be validated changed to upperCase
 *  **** NOTE: assuming all the characters in the application to be uppercase ****
 *
 *  Revision 1.2  2010/03/23 00:06:50  mwpxp2
 *  Fixed javadoc, file footer
 *
 */
