/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import javax.servlet.http.HttpSessionEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.util.HttpSessionMutexListener;


/**
 * Description: I am this and that
 * File: EASEHttpSessionListener.java
 * Module:  gov.ca.dmv.ease.listeners
 * Created: Mar 19, 2012 
 * @author MWKKC  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseHttpSessionListener extends HttpSessionMutexListener {
	/** Logger */
	private static final Log LOGGER = LogFactory
			.getLog(EaseHttpSessionListener.class);
	public EaseHttpSessionListener(){		
	}
	public void sessionCreated(HttpSessionEvent event){
		super.sessionCreated(event);
		LOGGER.info("EASE DL Session Created");
	}
    
	public void sessionDestroyed(HttpSessionEvent event){
		LOGGER.info("EASE DL Session Destroyed");
		super.sessionDestroyed(event);
	}	 	
}

/**
 *  Modification History:
 *
 *  $$Log: EaseHttpSessionListener.java,v $
 *  $Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  $Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *  $
 *  $Revision 1.18  2012/08/16 20:35:41  mwkzn
 *  $Renamed Class Name to be in camel casing
 *  $$
 */