/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;
import gov.ca.dmv.ease.ui.util.impl.HtmlRendererUtils;

import java.io.IOException;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.render.Renderer;

import org.apache.commons.lang.StringUtils;

/**
 * Description: This class is the extension of @see CodedInputTextRenderer with an additional feature of showing the
 * suggestions as the user enters the CodeSetName object names with respect to the codesetname attribute. To accomplish 
 * this feature, it builds codeset text depending upon the entry by the user. 
 * File: SuggestedInputTextRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SuggestedOutputTextRenderer extends Renderer {
	/**
	 * 
	 * @param codesetElements
	 * @return
	 */
	private String buildCodeSetElementsAsString(
			List <CodeSetElement> codesetElements) {
		StringBuilder builder = new StringBuilder("");
		String text = "";
		for (CodeSetElement element : codesetElements) {
			if (StringUtils.isEmpty(element.getCode())) {
				builder.append(" ");
			}
			else {
				builder.append(element.getCode()).append(",");
			}
		}
		if (builder.toString().trim().endsWith(",")) {
			text = builder.toString().substring(0,
					builder.toString().lastIndexOf(","));
		}
		return text;
	}

	/**
	 * Build the code set text that will ultimately be used to build the selections.
	 * @param clientId the client id
	 * @param codeSetName the code set name
	 * @param highlightMatch the highlight match
	 * @param popupWidth the popup width
	 * @return the text
	 */
	private String buildCodeSetText(CodeSetElement codeSetElement) {
		String codeSetCode = "";
		if (codeSetElement != null && codeSetElement.getCode() != null) {
			codeSetCode = codeSetElement.getCode();
		}
		return codeSetCode;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.CodedInputTextRenderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		super.encodeEnd(context, component);
		
		String tempString1 = "" ;
		String tempString2 = "" ;
		String tempString3 = "" ;
		
		HtmlOutputText outputText = (HtmlOutputText) component;
		String clientId = component.getClientId(context);
		ResponseWriter writer = context.getResponseWriter();
		if("MAIN_FORM:panelGrid_recordConditions".equalsIgnoreCase(clientId)) {
			writer.startElement(JsfHtmlAttributes.TABLE_ELEM, component);
			HtmlRendererUtils.writeIdIfNecessary(writer, component,
					context);
			HtmlRendererUtils.renderHtmlAttributes(writer, component,
					JsfHtmlAttributes.TABLE_PASSTHROUGH_ATTRIBUTES);
			writer.writeAttribute(JsfHtmlAttributes.WIDTH_ATTR, "80%", null);
			writer.flush();
			writer.startElement(JsfHtmlAttributes.TBODY_ELEM, component);
			writer.startElement(JsfHtmlAttributes.TR_ELEM, component);
			writer.write("<"+JsfHtmlAttributes.TD_ELEM+" class='width35' valign='top'>");
			writer.write("<"+JsfHtmlAttributes.OL_ELEM+" class='recordConditions1'>");

			List<String> value = (List<String>) outputText.getValue();
			for(int i=0; i <value.size(); i++) {
				
				if(i%3 == 0){
					tempString1 += "<"+JsfHtmlAttributes.LI_ELEM + " class='recordConditions'>" + value.get(i) +"</"+JsfHtmlAttributes.LI_ELEM + ">";
				}
				if(i%3 == 1){
					tempString2 += "<"+JsfHtmlAttributes.LI_ELEM + " class='recordConditions'>" + value.get(i) +"</"+JsfHtmlAttributes.LI_ELEM + ">";
				}
				if(i%3 == 2){
					tempString3 += "<"+JsfHtmlAttributes.LI_ELEM + " class='recordConditions'>" + value.get(i) +"</"+JsfHtmlAttributes.LI_ELEM + ">";
				}
			}
			writer.write(tempString1);
			writer.endElement(JsfHtmlAttributes.OL_ELEM);
			writer.endElement(JsfHtmlAttributes.TD_ELEM);
			
			writer.write("<"+JsfHtmlAttributes.TD_ELEM+" class='width35' valign='top'>");
			writer.write("<"+JsfHtmlAttributes.OL_ELEM+" class='recordConditions1'>");
			writer.write(tempString2);
			writer.endElement(JsfHtmlAttributes.OL_ELEM);
			writer.endElement(JsfHtmlAttributes.TD_ELEM);
			
			writer.write("<"+JsfHtmlAttributes.TD_ELEM+" class='width35' valign='top'>");
			writer.write("<"+JsfHtmlAttributes.OL_ELEM+" class='recordConditions1'>");
			writer.write(tempString3);
			writer.endElement(JsfHtmlAttributes.OL_ELEM);
			writer.endElement(JsfHtmlAttributes.TD_ELEM);
			
			writer.endElement(JsfHtmlAttributes.TR_ELEM);
			writer.endElement(JsfHtmlAttributes.TBODY_ELEM);
			writer.endElement(JsfHtmlAttributes.TABLE_ELEM);
		} else {
			writer.startElement(JsfHtmlAttributes.SPAN_ELEM, outputText);
			Object obj = outputText.getValue();
			String text = "";
			if (obj instanceof List) {
				text = buildCodeSetElementsAsString((List<CodeSetElement>) obj);
			} else if (obj instanceof CodeSetElement) {
				CodeSetElement codeSetElement = (CodeSetElement) outputText
						.getValue();
				text = buildCodeSetText(codeSetElement);
			} else if(obj instanceof String) {
				text = (String) outputText.getValue();
			}
			String styleClass = (component.getAttributes().get("styleClass") != null) ? (String) component
					.getAttributes().get("styleClass")
					: "";
			writer.writeAttribute("class", styleClass, null);
			writer.writeText(text, null);
			writer.endElement(JsfHtmlAttributes.SPAN_ELEM);
		}
	}
}
