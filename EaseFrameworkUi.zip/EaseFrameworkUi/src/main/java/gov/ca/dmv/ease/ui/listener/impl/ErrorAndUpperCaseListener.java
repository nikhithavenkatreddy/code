/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.listener.impl;

import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.FORM_ID;
import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.TABINDEX_ATTR;
import gov.ca.dmv.ease.ui.component.impl.HtmlEaseInputText;
import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;
import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIGraphic;
import javax.faces.component.UIInput;
import javax.faces.component.UIViewRoot;
import javax.faces.component.html.HtmlForm;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.component.html.HtmlInputSecret;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.apache.commons.lang.StringUtils;

import com.ibm.faces.component.html.HtmlInputHelperSetFocus;

/**
 * Description: This is the JSF phase listener class and this is used to validate
 * the UI components and change the characters from lower case to upper case except
 * for password field. This listener is registered in the JSF configuration file.
 * File: ErrorAndUpperCaseListener.java
 * Module:  gov.ca.dmv.ease.ui.listener.impl
 * Created: Jun 25, 2009
 * @author MWSKD2  
 * @version $Revision: 1.3 $
 * Last Changed: $Date: 2013/04/26 23:19:14 $
 * Last Changed By: $Author: mwsec2 $
 */
public class ErrorAndUpperCaseListener implements PhaseListener, PageConstants {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -689712212643730024L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
	 */
	public void afterPhase(PhaseEvent phaseEvent) {
		FacesContext facesContext = phaseEvent.getFacesContext();
		UIComponent uiFormComponent = null;
		// if (facesContext.getMessages().hasNext()) { // this condition is
		// removed for updating the image render value
		for (Object aComponentObject : facesContext.getViewRoot().getChildren()) {
			if (aComponentObject instanceof HtmlForm) {
				uiFormComponent = (UIComponent) aComponentObject;
				setComponentErrorStyles(facesContext, uiFormComponent,
						uiFormComponent);
				setFocus(facesContext, uiFormComponent);
			}
			else {
				UIComponent uiComponent = (UIComponent) aComponentObject;
				Iterator <?> childComponents = uiComponent.getChildren()
						.iterator();
				while (childComponents.hasNext()) {
					Object childComponent = childComponents.next();
					if (childComponent instanceof HtmlForm) {
						uiFormComponent = (UIComponent) childComponent;
						setComponentErrorStyles(facesContext, uiFormComponent,
								uiFormComponent);
						setFocus(facesContext, uiFormComponent);
					}
				}
			}
		}
		// }
	}

	/**
	 * 
	 * @param root
	 */
	public void makeDlIdGroupMandatoryForInquiryPage(UIViewRoot root) {
		HtmlInputText firstNameText = (HtmlInputText) root
				.findComponent(FORM_ID + ":firstName");
		HtmlInputText lastNameText = (HtmlInputText) root
				.findComponent(FORM_ID
				+ ":lastName");
		HtmlInputText birthDateText = (HtmlInputText) root
				.findComponent(FORM_ID + ":birthDate");
		HtmlInputText licenseNumberText = (HtmlInputText) root
				.findComponent(FORM_ID + ":licenseNumber");
		firstNameText.setRequired(false);
		lastNameText.setRequired(false);
		birthDateText.setRequired(false);
		licenseNumberText.setRequired(true);
		String licenseNumberTextValue = (licenseNumberText.getSubmittedValue() != null) ? licenseNumberText
				.getSubmittedValue().toString()
				: (String)licenseNumberText.getValue();
		/*
		 * if (firstNameText.getStyleClass() != null &&
		 * firstNameText.getStyleClass
		 * ().contains(REQUIRED_STYLE_CLASS)){
		 * firstNameText.setStyleClass
		 * (firstNameText.getStyleClass().substring(0,
		 * firstNameText.getStyleClass().lastIndexOf(" ")));
		 * firstNameText.setSubmittedValue(""); firstNameText.setValue(null); }
		 */
		if (lastNameText.getStyleClass() != null
				&& lastNameText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			lastNameText.setStyleClass(lastNameText.getStyleClass().substring(
					0, lastNameText.getStyleClass().lastIndexOf(" ")));
		}
		lastNameText.setSubmittedValue("");
		lastNameText.setValue(null);
		if (birthDateText.getStyleClass() != null
				&& birthDateText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			birthDateText.setStyleClass(birthDateText.getStyleClass()
					.substring(0,
							birthDateText.getStyleClass().lastIndexOf(" ")));
		}
		birthDateText.setSubmittedValue("");
		birthDateText.setValue(null);
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":firstName")).setSubmittedValue("");
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":firstName")).setValue(null);
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":middleName")).setSubmittedValue("");
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":middleName")).setValue(null);
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":cityCode")).setSubmittedValue("");
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":cityCode")).setValue(null);
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":cityName")).setSubmittedValue("");
		((HtmlInputText) root.findComponent(FORM_ID
				+ ":cityName")).setValue(null);
		((HtmlSuggestedInputText) root.findComponent(FORM_ID
				+ ":state")).setSubmittedValue("");
		((HtmlSuggestedInputText) root.findComponent(FORM_ID
				+ ":state")).setValue(null);
		((HtmlSelectOneMenu) root.findComponent(FORM_ID
				+ ":suffix")).setSubmittedValue("");
		((HtmlSelectOneMenu) root.findComponent(FORM_ID
				+ ":suffix")).setValue(null);
		if ("".equals(licenseNumberTextValue)
				&& licenseNumberText.getStyleClass() != null
				&& !licenseNumberText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			licenseNumberText.setStyleClass(licenseNumberText.getStyleClass()
					.toString()
					+ " " + REQUIRED_STYLE_CLASS);
			((HtmlGraphicImage) root.findComponent(FORM_ID
					+ ":licenseNumberErrorImage")).setRendered(true);
		}
		// ((HtmlGraphicImage)root.findComponent(FORM_ID+
		// ":firstNameErrorImage")).setRendered(false);
		((HtmlGraphicImage) root.findComponent(FORM_ID
				+ ":lastNameErrorImage")).setRendered(false);
		((HtmlGraphicImage) root
				.findComponent(FORM_ID
				+ ":birthDateErrorImage")).setRendered(false);
	}

	/**
	 * 
	 * @param root
	 */
	public void makeDlNameGroupMandatoryForInquryPage(UIViewRoot root) {
		HtmlInputText lastNameText = (HtmlInputText) root
				.findComponent(FORM_ID
				+ ":lastName");
		HtmlInputText birthDateText = (HtmlInputText) root
				.findComponent(FORM_ID + ":birthDate");
		HtmlInputText licenseNumberText = (HtmlInputText) root
				.findComponent(FORM_ID + ":licenseNumber");
		// firstNameText.setRequired(true);
		lastNameText.setRequired(true);
		birthDateText.setRequired(true);
		licenseNumberText.setRequired(false);
		String lastNameTextValue = (lastNameText.getSubmittedValue() != null) ? lastNameText
				.getSubmittedValue().toString()
				: lastNameText.getValue().toString();
		String birthDateTextValue = (birthDateText.getSubmittedValue() != null) ? birthDateText
				.getSubmittedValue().toString()
				: (birthDateText.getValue() != null) ? birthDateText.getValue()
						.toString() : "";		
		if ("".equals(lastNameTextValue)
				&& lastNameText.getStyleClass() != null
				&& !lastNameText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			lastNameText.setStyleClass(lastNameText.getStyleClass().toString()
					+ " " + REQUIRED_STYLE_CLASS);
			((HtmlGraphicImage) root.findComponent(FORM_ID
					+ ":lastNameErrorImage")).setRendered(true);
		}
		if ("".equals(birthDateTextValue)
				&& birthDateText.getStyleClass() != null
				&& !birthDateText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			birthDateText.setStyleClass(birthDateText.getStyleClass()
					.toString()
					+ " " + REQUIRED_STYLE_CLASS);
			((HtmlGraphicImage) root.findComponent(FORM_ID
					+ ":birthDateErrorImage")).setRendered(true);
		}
		if (licenseNumberText.getStyleClass() != null
				&& licenseNumberText.getStyleClass().contains(
						REQUIRED_STYLE_CLASS)) {
			licenseNumberText
					.setStyleClass(licenseNumberText.getStyleClass().substring(
							0,
							licenseNumberText.getStyleClass().lastIndexOf(" ")));
		}
		licenseNumberText.setSubmittedValue("");
		licenseNumberText.setValue(null);
		((HtmlGraphicImage) root.findComponent(FORM_ID
				+ ":licenseNumberErrorImage")).setRendered(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
	 */
	public void beforePhase(PhaseEvent phaseEvent) {
		FacesContext facesContext = phaseEvent.getFacesContext();
		// Logic to handle dynamic mandatory fields with asterisk is coded here.
		// Currently this scenario is applicable only to Inquiry screen.
		// Code is valid until the logic ends
		UIViewRoot root = facesContext.getViewRoot();
		HtmlInputHidden pageNameComponent = (HtmlInputHidden) root
				.findComponent(FORM_ID + ":PageName");
		if (pageNameComponent != null) {
			String pageName = pageNameComponent.getValue().toString();
			//TTC - DL/ID HQ Inquiry Response screen -> Counselor Inquiry Button
			if ("inquiryResponse".equalsIgnoreCase(pageName)) {
				HtmlInputText acceptRecordIndicator = (HtmlInputText) root
						.findComponent(FORM_ID
								+ ":acceptRecordIndicator");
				HtmlInputHidden counselorInqFlag = (HtmlInputHidden) root
						.findComponent(FORM_ID
								+ ":processCounselorInq");
				if (counselorInqFlag != null) {
					if ("yes".equalsIgnoreCase((String) counselorInqFlag
							.getSubmittedValue())
							&& acceptRecordIndicator != null) {
						acceptRecordIndicator.setRequired(false);
						//Reset the values for some other action
						counselorInqFlag.setValue("");
						counselorInqFlag.setSubmittedValue("");
					}
				}
			}
			//TTC - PRF Proof Filing Inquiry Response --> Counselor Inquiry Button
			else if ("proofFilingInquiryResponsePage"
					.equalsIgnoreCase(pageName)) {
				HtmlInputText typeCertIndicator = (HtmlInputText) root
						.findComponent(FORM_ID + ":typeInsCoCertCode");
				HtmlInputHidden counselorInqFlag = (HtmlInputHidden) root
						.findComponent(FORM_ID + ":processCounselorInq");
				if (counselorInqFlag != null) {
					if ("yes".equalsIgnoreCase((String) counselorInqFlag
							.getSubmittedValue())
							&& typeCertIndicator != null) {
						typeCertIndicator.setRequired(false);
						//Reset the values for some other action
						counselorInqFlag.setValue("");
						counselorInqFlag.setSubmittedValue("");
					}
				}
			}			
			if ("inquiry".equalsIgnoreCase(pageName)
					|| "proofFilingInquiryPage".equalsIgnoreCase(pageName)) {
				String licenseNumber = "";
				String firstName = "";
				String lastName = "";
				String middleName = "";
				String birthDate = "";
				String suffix = "";
				String cityCode = "";
				String cityName = "";
				String state = "";
				HtmlInputText licenseNumberComponent = getComponent(root,
						"licenseNumber");
				HtmlInputText firstNameComponent = getComponent(root,
						"firstName");
				HtmlInputText lastNameComponent = getComponent(root, "lastName");
				HtmlInputText middleNameComponent = getComponent(root,
						"middleName");
				HtmlInputText birthDateComponent = getComponent(root,
						"birthDate");
				HtmlInputText cityCodeComponent = getComponent(root, "cityCode");
				HtmlInputText cityNameComponent = getComponent(root, "cityName");
				HtmlInputText stateComponent = getComponent(root, "state");
				HtmlSelectOneMenu suffixComponent = (HtmlSelectOneMenu) root
						.findComponent(FORM_ID + ":suffix");
				//License Number
				if (licenseNumberComponent != null) {
					if (licenseNumberComponent.getSubmittedValue() != null) {
						licenseNumber = licenseNumberComponent
								.getSubmittedValue().toString();
					}
					else if (licenseNumberComponent.getValue() != null) {
						licenseNumber = licenseNumberComponent.getValue()
								.toString();
					}
				}
				//First Name
				if (firstNameComponent != null) {
					if (firstNameComponent.getSubmittedValue() != null) {
						firstName = firstNameComponent.getSubmittedValue()
								.toString();
					}
					else if (firstNameComponent.getValue() != null) {
						firstName = firstNameComponent.getValue().toString();
					}
				}
				//Last Name
				if (lastNameComponent != null) {
					if (lastNameComponent.getSubmittedValue() != null) {
						lastName = lastNameComponent.getSubmittedValue()
								.toString();
					}
					else if (lastNameComponent.getValue() != null) {
						lastName = lastNameComponent.getValue().toString();
					}
				}
				//Middle Name
				if (middleNameComponent != null) {
					if (middleNameComponent.getSubmittedValue() != null) {
						middleName = middleNameComponent.getSubmittedValue()
								.toString();
					}
					else if (middleNameComponent.getValue() != null) {
						middleName = middleNameComponent.getValue().toString();
					}
				}
				//Birth Date				
				if (birthDateComponent != null) {
					if (birthDateComponent.getSubmittedValue() != null) {
						birthDate = birthDateComponent.getSubmittedValue()
								.toString();
					}
					else if (birthDateComponent.getValue() != null) {
						birthDate = birthDateComponent.getValue().toString();
					}
				}
				//City Code
				if (cityCodeComponent != null) {
					if (cityCodeComponent.getSubmittedValue() != null) {
						cityCode = cityCodeComponent.getSubmittedValue()
								.toString();
					}
					else if (cityCodeComponent.getValue() != null) {
						cityCode = cityCodeComponent.getValue().toString();
					}
				}
				//City Name
				if (cityNameComponent != null) {
					if (cityNameComponent.getSubmittedValue() != null) {
						cityName = cityNameComponent.getSubmittedValue()
								.toString();
					}
					else if (cityNameComponent.getValue() != null) {
						cityName = cityNameComponent.getValue().toString();
					}
				}
				//State
				if (stateComponent != null) {
					if (stateComponent.getSubmittedValue() != null) {
						state = stateComponent.getSubmittedValue().toString();
					}
					else if (stateComponent.getValue() != null) {
						state = stateComponent.getValue().toString();
					}
				}
				//Suffix
				if (suffixComponent != null) {
					if (suffixComponent.getSubmittedValue() != null) {
						suffix = suffixComponent.getSubmittedValue().toString();
					}
					else if (suffixComponent.getValue() != null) {
						suffix = suffixComponent.getValue().toString();
					}
				}
				//For 38U name fields are null so no need to perform the following loop.
				if (lastNameComponent != null && firstNameComponent != null
						&& birthDateComponent != null) {
					if ("".equals(licenseNumber) && "".equals(firstName)
							&& "".equals(lastName) && "".equals(middleName)
							&& "".equals(birthDate) && "".equals(cityName)
							&& "".equals(cityCode) && "".equals(suffix)
							&& "".equals(state)) {
						makeDlIdGroupMandatoryForInquiryPage(root);
					}
					else if ("".equals(licenseNumber)
							&& (!"".equals(firstName) || !"".equals(lastName)
									|| !"".equals(middleName)
									|| !"".equals(birthDate)
									|| !"".equals(cityName)
									|| !"".equals(cityCode)
									|| !"".equals(suffix) || !"".equals(state))) {
						makeDlNameGroupMandatoryForInquryPage(root);
					}
					else {
						makeDlIdGroupMandatoryForInquiryPage(root);
					}
				}
				else {
					//For 38U TTC we need license number & 3 POS Name are required.
					licenseNumberComponent.setRequired(true);
					HtmlInputText threePosNameComponent = getComponent(root,
							"threePosName");
					if (threePosNameComponent != null) {
						threePosNameComponent.setRequired(true);
					}
				}
			}
		}// logic end here
		UIComponent uiFormComponent = null;
		for (Object aComponentObject : facesContext.getViewRoot().getChildren()) {
			if (aComponentObject instanceof HtmlForm) {
				uiFormComponent = (UIComponent) aComponentObject;
				setComponentToUpperCase(facesContext, uiFormComponent);
			}
			else {
				UIComponent uiComponent = (UIComponent) aComponentObject;
				Iterator <?> childComponents = uiComponent.getChildren()
						.iterator();
				while (childComponents.hasNext()) {
					Object childComponent = childComponents.next();
					if (childComponent instanceof HtmlForm) {
						uiFormComponent = (UIComponent) childComponent;
						setComponentToUpperCase(facesContext, uiFormComponent);
					}
				}
			}
		}
	}

	/**
	 * Gets the Error message summary for the error component.
	 * 
	 * @param componentId
	 *            the component id
	 * @param uiFormComponent
	 *            the ui form component
	 * @param uiInput
	 *            the ui input
	 * 
	 * @return the message summary
	 */
	private String getMessageSummary(String componentId,
			UIComponent uiFormComponent, UIInput uiInput) {
		String messageSummary = "";
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages(componentId);
		while (messages.hasNext()) {
			// String labelValue = FacesUtils.getLabelValue(componentId,
			// uiFormComponent);
			FacesMessage facesMessage = (FacesMessage) messages.next();
			if (facesMessage.getSummary() != null) {
				messageSummary = facesMessage.getSummary();
			}
			// Add the message summary to the faces context to display the error
			// message at the bottom of the screen.
			if (!messageSummary.endsWith("uiErrorMsg"))
				FacesUtils.addErrorMessage(uiInput.getClientId(FacesContext
						.getCurrentInstance()), messageSummary);
			break;
			// getFormattedMessage(facesMessage.getSummary(), labelValue,
			// uiInput);
		}
		return messageSummary;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.faces.event.PhaseListener#getPhaseId()
	 */
	public PhaseId getPhaseId() {
		return PhaseId.PROCESS_VALIDATIONS;
	}

	/**
	 * Gets the new style class for components which has errors.
	 * 
	 * @param componentId
	 *            the component id
	 * @param styleClass
	 *            the style class
	 * 
	 * @return newStyleClass for a component
	 */
	private String getUpdatedStyleClass(String componentId, String styleClass) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages(componentId);
		if (messages.hasNext()) {
			if (styleClass != null
					&& !styleClass.contains(REQUIRED_STYLE_CLASS)) {
				styleClass = styleClass + " " + REQUIRED_STYLE_CLASS;
			}
		}
		else {
			if (styleClass != null && styleClass.contains(REQUIRED_STYLE_CLASS)) {
				styleClass = styleClass.substring(0, styleClass
						.lastIndexOf(" "));
			}
		}
		return styleClass;
	}

	/**
	 * Determines and sets whether the graphic Image is rendered or not.
	 * 
	 * @param componentId
	 *            the component id
	 * @param mesgSummary
	 *            the mesg summary
	 */
	private void renderErrorImageWithTitle(String componentId,
			String mesgSummary) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		UIGraphic uiGraphic = (UIGraphic) facesContext.getViewRoot()
				.findComponent(componentId + LABEL_ERROR_IMAGE);
		HtmlGraphicImage htmlGraphicImage = (HtmlGraphicImage) uiGraphic;
		Iterator <?> messages = facesContext.getMessages(componentId);
		// If there are messages for the component...
		if (messages.hasNext() && htmlGraphicImage != null) {
			htmlGraphicImage.setRendered(true);
			htmlGraphicImage.setStyle("vertical-align: middle;");
			htmlGraphicImage.setHeight("20px");
			htmlGraphicImage.setTitle(mesgSummary);
		}
		else if (htmlGraphicImage != null) {
			htmlGraphicImage.setRendered(false);
			htmlGraphicImage.setTitle("");
		}
	}

	/**
	 * Sets the error message and renders an image for error component. Sets the
	 * title for component with error message.
	 * 
	 * @param facesContext
	 *            the faces context
	 * @param uiFormComponent
	 *            the ui form component
	 * @param uiComponent
	 *            the ui component
	 */
	private void setComponentErrorStyles(FacesContext facesContext,
			UIComponent uiFormComponent, UIComponent uiComponent) {
		if (uiComponent instanceof HtmlInputText
				&& !(uiComponent instanceof HtmlSuggestedInputText)
				&& !(uiComponent instanceof HtmlEaseInputText)) {
			HtmlInputText htmlInputText = (HtmlInputText) uiComponent;
			String inputTextId = htmlInputText.getClientId(facesContext);
			String inputTextStyleClass = htmlInputText.getStyleClass();
			String styleClass = getUpdatedStyleClass(inputTextId,
					inputTextStyleClass);
			htmlInputText.setStyleClass(styleClass);
			String mesgSummary = getMessageSummary(inputTextId,
					uiFormComponent, htmlInputText);
			htmlInputText.setTitle(mesgSummary);
			renderErrorImageWithTitle(inputTextId, mesgSummary);
			return;
		}
		if (uiComponent instanceof HtmlSelectOneMenu) {
			HtmlSelectOneMenu htmlSelectOneMenu = (HtmlSelectOneMenu) uiComponent;
			String selectOneMenuId = htmlSelectOneMenu
					.getClientId(facesContext);
			String selectOneMenuStyleClass = htmlSelectOneMenu.getStyleClass();
			String styleClass = getUpdatedStyleClass(selectOneMenuId,
					selectOneMenuStyleClass);
			htmlSelectOneMenu.setStyleClass(styleClass);
			String mesgSummary = getMessageSummary(selectOneMenuId,
					uiFormComponent, htmlSelectOneMenu);
			htmlSelectOneMenu.setTitle(mesgSummary);
			renderErrorImageWithTitle(selectOneMenuId, mesgSummary);
			return;
		}
		if (uiComponent instanceof HtmlInputSecret) {
			HtmlInputSecret htmlInputSecret = (HtmlInputSecret) uiComponent;
			String inputSecretId = htmlInputSecret.getClientId(facesContext);
			String inputSecretStyleClass = htmlInputSecret.getStyleClass();
			String styleClass = getUpdatedStyleClass(inputSecretId,
					inputSecretStyleClass);
			htmlInputSecret.setStyleClass(styleClass);
			String mesgSummary = getMessageSummary(inputSecretId,
					uiFormComponent, htmlInputSecret);
			htmlInputSecret.setTitle(mesgSummary);
			renderErrorImageWithTitle(inputSecretId, mesgSummary);
			return;
		}
		if (uiComponent.getChildCount() == 0) {
			return;
		}
		// Recursive call to iterate the children
		for (Object uiComponentChild : uiComponent.getChildren()) {
			setComponentErrorStyles(facesContext, uiFormComponent,
					(UIComponent) uiComponentChild);
		}
	}

	/**
	 * Sets the component to upper case.
	 * 
	 * @param facesContext
	 *            the faces context
	 * @param uiComponent
	 *            the ui component
	 */
	private void setComponentToUpperCase(FacesContext facesContext,
			UIComponent uiComponent) {
		if (uiComponent instanceof HtmlInputText) {
			HtmlInputText htmlInputText = (HtmlInputText) uiComponent;
			if (htmlInputText.getSubmittedValue() != null) {
				if (!("lastName".equalsIgnoreCase(htmlInputText.getId()) || "threePosName"
						.equalsIgnoreCase(htmlInputText.getId()))) {
					htmlInputText.setSubmittedValue(StringUtils
							.upperCase(StringUtils.trim((String) htmlInputText
									.getSubmittedValue())));
				}
				else {
					htmlInputText.setSubmittedValue(StringUtils
							.upperCase((String) htmlInputText
									.getSubmittedValue()));
				}
			}
			return;
		}
		if (uiComponent.getChildCount() == 0) {
			return;
		}
		// Recursive call
		for (Object uiComponentChild : uiComponent.getChildren()) {
			setComponentToUpperCase(facesContext,
					(UIComponent) uiComponentChild);
		}
	}

	/**
	 * Display messages in the bottom of the page and set rendered is true for
	 * expand and collapse Sets the focus on error component.
	 * 
	 * @param facesContext
	 *            the faces context
	 * @param uiFormComponent
	 *            the ui form component
	 */
	private void setFocus(FacesContext facesContext, UIComponent uiFormComponent) {
		HtmlInputHelperSetFocus setFocus = (HtmlInputHelperSetFocus) uiFormComponent
				.findComponent("focus");
		
		//In order to fix the defect #s 152 & 4656 following code added.
		//Elements in the facesContext.getClientIdsWithMessages() is 
		//random list, not in the order. There is no guarantee that focus 
		//will set to the first error form field (random order). So based on TABINDEX
		//get the first component and set the focus.
		Iterator <?> clientIds = facesContext.getClientIdsWithMessages();
		UIViewRoot root = facesContext.getViewRoot();
		List <Integer> tabIndexList = new ArrayList <Integer>();
		Map <Integer, Object> componentsMap = new HashMap <Integer, Object>(5);
		while (clientIds.hasNext()) {
			String clientId = (String) clientIds.next();
			UIComponent uiComponent = null;
			if (clientId != null
					&& clientId.startsWith(FORM_ID)) {
				uiComponent = root.findComponent(clientId);
			}
			else {
				uiComponent = root.findComponent(FORM_ID
						+ ":" + clientId);
			}
			if (uiComponent != null) {
				String tabIndex = (String) uiComponent.getAttributes().get(
						TABINDEX_ATTR);
				if (tabIndex != null) {
					try {
						tabIndexList.add(new Integer(tabIndex));
						componentsMap.put(new Integer(tabIndex), uiComponent);
					}
					catch (NumberFormatException e) {
						//If the tab index is not number then continue with the next components.
						continue;
					}
				}
			}
		}
		//Sort the tab index for the error components.
		Collections.sort(tabIndexList);
		//Get the component for the first tab index after sorting and set the focus.
		if (tabIndexList.size() > 0 && tabIndexList.get(0) != null) {
			UIComponent uiComponent = (UIComponent) componentsMap
					.get(tabIndexList.get(0));
			String clientId = uiComponent.getClientId(facesContext);
			if (setFocus != null) {
				setFocus.setTarget(clientId);
				return;
			}
		}		
		//In order to fix the defect #s 152 & 4656 following code added.
		//Iterate the form elements and check for child elements and iterate all
		//the child elements and check the form element id exists in the facesContext.getClientIdsWithMessages()
		//list and if exists then set the focus and return. This will fix the focusing issue (focus to the first 
		//error field) for all UI validation rules.
		for (Object aComponentObject : uiFormComponent.getChildren()) {
			//Check for children and iterate the form elements
			int childCount = ((UIComponent) aComponentObject).getChildCount();
			if (childCount > 0) {
				for (Object childComponentObject : ((UIComponent) aComponentObject)
						.getChildren()) {
					int grandChildCount = ((UIComponent) childComponentObject)
							.getChildCount();
					//Check for children and iterate the form elements
					if (grandChildCount > 0) {
						for (Object grandChildComponentObject : ((UIComponent) childComponentObject)
								.getChildren()) {
							String clientId = ((UIComponent) grandChildComponentObject)
									.getClientId(facesContext);
							if (checkClientIdInErrorsList(clientId,
									facesContext)) {
								if (setFocus != null) {
									setFocus.setTarget(clientId);
									return;
								}
							}
						}
					}
					else {
						String clientId = ((UIComponent) childComponentObject)
								.getClientId(facesContext);
						if (checkClientIdInErrorsList(clientId, facesContext)) {
							if (setFocus != null) {
								setFocus.setTarget(clientId);
								return;
							}
						}
					}
				}
			}
			else {
				String clientId = ((UIComponent) aComponentObject)
						.getClientId(facesContext);
				if (checkClientIdInErrorsList(clientId, facesContext)) {
					if (setFocus != null) {
						setFocus.setTarget(clientId);
						return;
					}
				}
			}
		}
		//If any of the above logic doesn't return then set the focus to the first
		//element in the facesContext.getClientIdsWithMessages() (random list). There is no guarantee 
		//that focus will set to the first error form field (random order).
		clientIds = facesContext.getClientIdsWithMessages();
		if (clientIds.hasNext()) {
			if (setFocus != null) {
				setFocus.setTarget((String) clientIds.next());
			}
		}
	}

	/**
	 * 
	 * @param clientId
	 * @param facesContext
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean checkClientIdInErrorsList(String clientId,
			FacesContext facesContext) {
		Iterator <String> clientIds = facesContext.getClientIdsWithMessages();
		while (clientIds.hasNext()) {
			String componentClientId = (String) clientIds.next();
			if (componentClientId != null
					&& componentClientId.equalsIgnoreCase(clientId)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Find the component in the UIViewRoot and return.
	 * @param root
	 * @param clientId
	 * @return
	 */
	private HtmlInputText getComponent(UIViewRoot root, String clientId) {
		return (HtmlInputText) root.findComponent(FORM_ID
				+ ":" + clientId);
	}
}
/**
 * Modification History:
 * 
 * $Log: ErrorAndUpperCaseListener.java,v $
 * Revision 1.3  2013/04/26 23:19:14  mwsec2
 * null safety added
 *
 * Revision 1.2  2013/04/25 23:08:59  mwsec2
 * added null checking to getMessageSummary
 *
 * Revision 1.1  2012/10/01 02:58:07  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.26  2012/08/14 20:38:06  mwrrv3
 * Code clean up and fixed PMD issues.
 *
 * Revision 1.25  2012/07/17 23:46:07  mwrrv3
 * Fixed defect# 1168, based on the button name (Counselor Inq) setting the required true or false.
 *
 * Revision 1.24  2011/10/12 00:40:57  mwrrv3
 * Updated for datatable elements focus field.
 *
 * Revision 1.22  2011/05/19 23:28:31  mwrrv3
 * Added null checks for the input components and updated the logic for required attribute for the UI component.
 *
 * Revision 1.21  2011/03/25 02:19:30  mwrrv3
 * Updated the setFocus to fix the defect# 152 and 4656, order of focus issue.
 *
 * Revision 1.20  2011/01/20 23:20:40  mwrrv3
 * Added condition for threePosName to not trim the value.
 *
 * Revision 1.19  2011/01/07 20:16:14  mwrrv3
 * Code formatted and updated the logic to support counselor inquiry button in the inquiry response page.
 *
 * Revision 1.18  2010/10/08 20:50:59  mwrrv3
 * Implemented office city codes based on the office id.
 *
 * Revision 1.17  2010/09/17 18:00:51  mwgxk2
 * Added for ProofFilling Inquiry Page.
 *
 * Revision 1.16  2010/07/09 18:42:02  mwskd2
 * updated
 *
 * Revision 1.14  2010/06/30 18:33:57  mwskd2
 * inquiry page toggle logic is removed
 *
 * Revision 1.13  2010/06/25 21:06:14  mwskd2
 * inquiry page intra field validation logic is included
 *
 * Revision 1.12  2010/06/21 23:00:47  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.8.6.2  2010/06/20 18:06:58  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.11  2010/06/15 18:20:26  mwrrv3
 * Added comments.
 *
 * Revision 1.10  2010/06/15 18:12:21  mwrrv3
 * Commented the code for password field upper case.
 *
 * Revision 1.9  2010/06/08 17:17:55  mwrrv3
 * Modified the code to support UI and BR error messages.
 *
 * Revision 1.8  2010/05/07 01:01:23  mwskd2
 * component error style should not set for suggested controls as they are rendered using renderer
 *
 * Revision 1.7  2010/04/22 19:28:36  mwpxp2
 * Fixed class comment; bulk cleanup
 *
 * Revision 1.6  2010/04/11 00:17:33  mwskd2
 * code to update the image render value after validation phase successfully done.
 *
 * Revision 1.5  2010/03/23 00:01:23  mwpxp2
 * Bulk cleanup
 *
 * Revision 1.4  2010/03/11 22:22:16  mwcsj3
 * Made changes to accommodate multiple transitions
 *
 * Revision 1.2  2009/12/25 00:28:46  mwbvc
 * increased the size of error image
 *
 * Revision 1.1  2009/11/23 16:22:52  mwrsk
 * Intial commit
 *
 * Revision 1.4  2009/10/27 21:44:02  mwbvc
 * changes on messages
 *
 * Revision 1.3  2009/10/24 00:27:38  mwbvc
 * changed the messages
 *
 * Revision 1.2  2009/10/22 16:55:02  mwbvc
 * Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 * Revision 1.1  2009/10/22 00:40:50  mwbvc
 * Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 * Revision 1.1  2009/10/21 23:52:36  mwbvc
 * changed the package names and refactored the code
 *
 * Revision 1.12  2009/10/06 20:53:48  mwbvc
 * changed the getLabelValue method to get the correct labelName
 *
 * Revision 1.11  2009/09/17 00:04:27  mwbvc
 * added to check sleectonemenu error
 *
 * Revision 1.10  2009/08/31 19:14:41  mwbvc
 * checking condition whether page has any errors. Also added customization for IBM validation errors
 *
 * Revision 1.9  2009/08/29 01:06:40  mwbvc
 * updated labelValue method
 *
 * Revision 1.8  2009/08/28 18:17:48  mwbvc
 * error messages with label value
 *
 * Revision 1.7  2009/08/28 17:16:52  mwskd2
 * updated
 *
 * Revision 1.6  2009/08/28 01:37:40  mwbvc
 * removed the before phase and removed the unnecessary code
 *
 * Revision 1.5  2009/08/26 16:08:39  mwskd2
 * Updated to remove the white spaces(trimmed) and storing null values for empty strings for each input control values
 *
 * Revision 1.4  2009/08/20 01:52:24  mwpxm2
 * Recursive call for UpperCasing too
 *
 * Revision 1.3  2009/08/19 16:22:54  mwpxm2
 * Recursive call
 *
 * Revision 1.2  2009/08/12 01:29:50  mwbvc
 * Commented code to not show the expand/collapse feature for JSF validation error messages
 *
 * Revision 1.1  2009/08/09 21:37:05  mwskd2
 * file renamed
 *
 * Revision 1.3  2009/08/06 22:52:13  mwbvc
 * transforming input to uppercase
 *
 * Revision 1.2  2009/08/06 22:17:52  mwbvc
 * code changes for Setting focus on a field after error processing
 * Revision 1.1 2009/08/03 22:22:34
 * mwbvc Copied from jsf package to listener package
 * 
 * Revision 1.2 2009/07/30 21:40:53 mwbvc updated the error handling
 * 
 * Revision 1.1 2009/07/29 22:40:01 mwbvc Custom DIV Component and Error
 * Handling
 * 
 */
