/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import java.io.Serializable;

/**
* Description: AttachedStateWrapper is used to save the state
* Module: gov.ca.dmv.ease.ui.validator.impl.AttachedStateWrapper 
* Created: Oct 19, 2009
* @author mwbvc
* @version $Revision: 1.1 $ 
* Last Changed: $Date: 2012/10/01 02:58:06 $ 
* Last Changed By: $Author: mwpxp2 $
*/
class AttachedStateWrapper implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2736288934154453573L;
	/** The var class. */
	private Class <?> varClass;
	/** The wrapped state object. */
	private Object wrappedStateObject;

	/**
	 * Instantiates a new attached state wrapper.
	 *
	 * @param clazz null means wrappedStateObject is a List of state objects
	 * @param anObject the an object
	 */
	public AttachedStateWrapper(Class <?> clazz, Object anObject) {
		if (wrappedStateObject != null && !(anObject instanceof Serializable)) {
			throw new IllegalArgumentException(
					"Attached state for Object of type " + clazz + " (Class "
							+ anObject.getClass().getName()
							+ ") is not serializable");
		}
		varClass = clazz;
		wrappedStateObject = anObject;
	}

	/**
	 * Gets the clazz.
	 *
	 * @return the clazz
	 */
	public Class <?> getClazz() {
		return varClass;
	}

	/**
	 * Gets the wrapped state object.
	 *
	 * @return the wrapped state object
	 */
	public Object getWrappedStateObject() {
		return wrappedStateObject;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: AttachedStateWrapper.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2012/08/25 18:06:08  mwpxp2
 *  Fixed faulty constructor; fixed class header; added class footer
 *
 */
