/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.renderer.impl;

import gov.ca.dmv.ease.ui.component.impl.HtmlEaseInputText;
import gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes;
import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;
import gov.ca.dmv.ease.ui.util.impl.HtmlRendererUtils;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.faces.FactoryFinder;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.ValueBinding;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.faces.render.Renderer;

import org.apache.commons.lang.StringUtils;

/**
 * Description: This class is the extension of @see Renderer
 * File: EaseInputTextRenderer.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: May 06, 2009
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseInputTextRenderer extends Renderer {
	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#decode(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void decode(FacesContext context, UIComponent component) {
		getTextRenderer(context).decode(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeBegin(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeBegin(FacesContext context, UIComponent component)
			throws IOException {
		getTextRenderer(context).encodeBegin(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeChildren(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@Override
	public void encodeChildren(FacesContext context, UIComponent component)
			throws IOException {
		getTextRenderer(context).encodeChildren(context, component);
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#encodeEnd(javax.faces.context.FacesContext, javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void encodeEnd(FacesContext context, UIComponent component)
			throws IOException {
		HtmlEaseInputText inputText = (HtmlEaseInputText) component;
		String clientId = inputText.getClientId(context);
		ResponseWriter writer = context.getResponseWriter();
		Map <String, Object> attrs = component.getAttributes();
		boolean hasErrors = hasMessages(context, inputText);
		Object value = "";
		String msgSummary = getMessageSummary(clientId, component, inputText);
		String title = (attrs.get(JsfHtmlAttributes.TITLE_ATTR) != null) ? (String) attrs
				.get(JsfHtmlAttributes.TITLE_ATTR)
				: "";
		if (attrs.get(JsfHtmlAttributes.VALUE_ATTR) != null) {
			if (hasErrors) {
				value = "" + inputText.getSubmittedValue();
			}
			else {
				if (attrs.get(JsfHtmlAttributes.VALUE_ATTR) instanceof Date) {
					value = inputText.getConverter().getAsString(context,
							component, attrs.get(JsfHtmlAttributes.VALUE_ATTR));
				}
				else {
					value = attrs.get(JsfHtmlAttributes.VALUE_ATTR);
					if (FacesContext.getCurrentInstance().getExternalContext()
							.getRequestParameterMap().get(clientId) != null) {
						value = FacesContext.getCurrentInstance()
								.getExternalContext().getRequestParameterMap()
								.get(clientId).toString();
					}
					else {
						value = attrs.get(JsfHtmlAttributes.VALUE_ATTR);
					}
				}
			}
		}
		else {
			if (hasErrors) {
				value = "" + inputText.getSubmittedValue();
			}
			else {
				if (FacesContext.getCurrentInstance().getExternalContext()
						.getRequestParameterMap().get(clientId) != null) {
					value = FacesContext.getCurrentInstance()
							.getExternalContext().getRequestParameterMap().get(
									clientId).toString();
				}
				else {
					value = "";
				}
			}
		}
		writer.startElement(JsfHtmlAttributes.INPUT_ELEM, inputText);
		HtmlRendererUtils
				.renderHtmlAttributes(
						writer,
						component,
						JsfHtmlAttributes.SUGGESTED_OR_EASE_INPUTTEXT_PASSTHROUGH_ATTRIBUTES);
		String styleClass = (String) component.getAttributes().get(
				JsfHtmlAttributes.STYLE_CLASS_ATTR);
		HtmlRendererUtils.writeIdIfNecessary(writer, component, context);
		writer.writeAttribute(JsfHtmlAttributes.NAME_ATTR, clientId, null);
		if (styleClass != null) {
			if (hasErrors) {
				styleClass += " " + PageConstants.REQUIRED_STYLE_CLASS;
			}
			writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR, styleClass,
					null);
		}
		else if (hasErrors) {
			writer.writeAttribute(JsfHtmlAttributes.CLASS_ATTR,
					PageConstants.REQUIRED_STYLE_CLASS, null);
		}
		if (hasErrors) {
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, msgSummary,
					null);
		}
		else {
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, title, null);
		}
		writer.writeAttribute("value", value, null);
		writer.endElement(JsfHtmlAttributes.INPUT_ELEM);
		if (hasErrors) {
			writer.startElement(JsfHtmlAttributes.IMG_ELEM, inputText);
			writer.writeAttribute(JsfHtmlAttributes.ID_ATTR, clientId
					+ "ErrorImage", null);
			writer.writeAttribute(JsfHtmlAttributes.TITLE_ATTR, msgSummary,
					null);
			writer.writeAttribute(JsfHtmlAttributes.ALT_ATTR, "", null);
			writer.writeAttribute(JsfHtmlAttributes.HEIGHT_ATTR, "20px", null);
			writer.writeAttribute(JsfHtmlAttributes.STYLE_ATTR,
					"vertical-align: middle;", null);
			writer.writeAttribute(JsfHtmlAttributes.SRC_ATTR,
					"../images/req_arrow.jpg", null);
			writer.endElement(JsfHtmlAttributes.IMG_ELEM);
			//Add the message summary to the faces context to display the error 
			//message at the bottom of the screen.
			if (!msgSummary.endsWith("uiErrorMsg")) {
				FacesUtils.addErrorMessage(clientId, msgSummary);
			}
		}
		writer.flush();
	}

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getConvertedValue(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	@Override
	public Object getConvertedValue(FacesContext context,
			UIComponent component, Object submittedValue)
			throws ConverterException {
		ValueBinding valueBinding = component.getValueBinding("value");
		if (valueBinding == null) {
			return null;
		}
		Class <?> valueType = valueBinding.getType(context);
		if (valueType == null) {
			return null;
		}
		// Validate against the code set if bound to a String
		if (valueType != null && valueType.equals(String.class)) {
			if (submittedValue == null) {
				return null;
			}
			else {
				String valueString = submittedValue.toString();
				if (valueString == null || valueString.trim().equals("")) {
					return null;
				}
				submittedValue = StringUtils.upperCase(valueString);				
			}
		}
		Converter converter = ((UIInput) component).getConverter();
		if (converter == null) {
			converter = context.getApplication().createConverter(valueType);
		}
		if (converter != null) {
			return converter.getAsObject(context, component,
					(String) submittedValue);
		}
		else {
			return submittedValue;
		}
	}

	/**
	 * 
	 * @param componentId
	 * @param uiFormComponent
	 * @param uiInput
	 * @return
	 */
	private String getMessageSummary(String componentId,
			UIComponent uiFormComponent, UIInput uiInput) {
		String messageSummary = "";
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages(componentId);
		while (messages.hasNext()) {
			messageSummary = ((FacesMessage) messages.next()).getSummary();
			break;
		}
		return messageSummary;
	}

	/**
	 * Gets the default renderer type of an HTML Input component
	 * @param context the context
	 * @return the text renderer
	 */
	protected Renderer getTextRenderer(FacesContext context) {
		RenderKitFactory rkFactory = (RenderKitFactory) FactoryFinder
				.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
		RenderKit defaultRenderKit = rkFactory.getRenderKit(context,
				RenderKitFactory.HTML_BASIC_RENDER_KIT);
		return defaultRenderKit.getRenderer(UIInput.COMPONENT_FAMILY,
				"javax.faces.Text");
	}

	/**
	 * Return true if faces context has error messages.
	 * @param context
	 * @param component
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean hasMessages(FacesContext context, UIComponent component) {
		if (component == null) {
			return false;
		}
		String compId = component.getClientId(context);
		Iterator <String> clientIds = context.getClientIdsWithMessages();
		while (clientIds.hasNext()) {
			String clientId = clientIds.next();
			if (clientId != null && clientId.equals(compId)) {
				return true;
			}
		}
		return false;
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseInputTextRenderer.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.9  2011/08/09 18:04:45  mwrrv3
 *  Fixed the convert to upper case issue and code formatted and added comments.
 *
 *  Revision 1.8  2010/08/03 21:10:21  mwskd2
 *  error messages are not displaying bug fixed
 *
 *  Revision 1.7  2010/07/08 02:04:42  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.6  2010/05/27 19:53:05  mwskd2
 *  attribute values pulling from jsfHtmlAttributes interface
 *
 *  Revision 1.5  2010/05/10 02:09:00  mwsyk1
 *  Checking for Integer instance
 *
 *  Revision 1.4  2010/05/08 01:33:23  mwskd2
 *  added available attributes while rendering
 *
 *  Revision 1.3  2010/05/07 00:59:46  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *
 *  Revision 1.1  2010/05/07 00:52:18  mwskd2
 *  EaseInputText component for special cases to use inside loops
 *  
 */
