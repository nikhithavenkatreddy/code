/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.component.UIPanel;

/**
 * Description: custom JSF component for DIV tag - to use the DIV with rendered attribute <p>
 * File: UiDiv.java
 * Module:  gov.ca.dmv.ease.ui.jsf
 * Created: Oct 14, 2009 
 * @author MWRPK  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class UiDiv extends UIPanel {
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.ui.jsf.Panel";
	public static final String RENDERER_TYPE = "gov.ca.dmv.ease.ui.jsf.Div";

	/**
	 * No Args constructor
	 */
	public UiDiv() {
		setRendererType(RENDERER_TYPE);
	}
}
/**
 *  Modification History:
 * 
 *  $Log: UiDiv.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/27 23:29:07  mwrpk
 *  Adding comments
 *
 *  Revision 1.3  2009/08/03 22:22:03  mwbvc
 *  custom JSF component for DIV tag - to use the DIV with rendered attribute
 *
*/
