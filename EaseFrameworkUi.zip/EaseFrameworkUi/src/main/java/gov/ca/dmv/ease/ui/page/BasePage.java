/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.page;

import static gov.ca.dmv.ease.ui.constants.JsfHtmlAttributes.FORM_ID;
import gov.ca.dmv.ease.app.context.impl.ProcessContext;
import gov.ca.dmv.ease.aspect.util.impl.EaseProxyUtils;
import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.OfficeCityCode;
import gov.ca.dmv.ease.bo.user.impl.UserContext;
import gov.ca.dmv.ease.fw.error.IErrorCollector;
import gov.ca.dmv.ease.fw.process.ISessionContext;
import gov.ca.dmv.ease.fw.service.IRequest;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.ui.component.impl.SuggestedSelectItem;
import gov.ca.dmv.ease.ui.handler.impl.ActionsHandler;
import gov.ca.dmv.ease.ui.page.impl.AbstractBackingBean;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This class is the base class for all page backing beans
 * File: BasePage.java
 * Module: gov.ca.dmv.ease.ui.page
 * Created: 2009
 * @author MWRRV3
 * @version $Revision: 1.4 $
 * Last Changed: $Date: 2017/11/09 16:31:03 $
 * Last Changed By: $Author: mwskh1 $
 */
public abstract class BasePage extends AbstractBackingBean implements IRequest {
	/** The application labels. */
	private static ResourceBundle applicationLabels = ResourceBundle
			.getBundle(RESOURCE_APPLICATION_LABELS);
	/** The BROWSER_RESOURCE_FILE_EXT. */
	public static final String BROWSER_RESOURCE_FILE_EXT = ".browserTitle";
	/** The CDA_RESOURCE_FILE_EXT. */
	public static final String CDA_RESOURCE_FILE_EXT = ".cda";
	/** The Constant COLON. */
	private static final String COLON = ":";
	/** Counter Mode. */
	protected static final String COUNTER_MODE = "C";
	/** The DAF_RESOURCE_FILE_EXT. */
	public static final String DAF_RESOURCE_FILE_EXT = ".daf";
	/** Default Function - Work Type. */
	public static final String DEFAULT_FUNCTION_WORK_TYPE_DRIVER_LICENSE = "D";
	/** Default Operation - Process Type. */
	public static final String DEFAULT_OPERATION_PROCESS_TYPE_COUNTER = "C";
	/** The DLA_RESOURCE_FILE_EXT. */
	public static final String DLA_RESOURCE_FILE_EXT = ".dla";
	/** Logger for this class. */
	/** The Constant LOGGER. */
	protected static final Log LOGGER = LogFactory.getLog(BasePage.class);
	/** Mail Mode. */
	protected static final String MAIL_MODE = "P";
	/** Manual Mode. */
	protected static final String MANUAL_MODE = "M";
	/** The Constant NO. */
	protected static final String NO = "N";
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5740968262468207982L;
	/** Travel Mode. */
	protected static final String TRAVEL_MODE = "T";
	/** The 04M TTC - reissue fee payment. */
	public static final String TTC_04M_RESOURCE_FILE_EXT = ".04m";
	/** The 05M TTC - medical report update. */
	public static final String TTC_05M_RESOURCE_FILE_EXT = ".05m";
	/** The 06M TTC - special certificate payment. */
	public static final String TTC_06M_RESOURCE_FILE_EXT = ".06m";
	/** The 07M TTC - transit training payment. */
	public static final String TTC_07M_RESOURCE_FILE_EXT = ".07m";
	/** The 38U TTC - DL/ID Address Change. */
	public static final String TTC_07Q_RESOURCE_FILE_EXT = ".07q";
	/** The 12M TTC - add court restriction payment. */
	public static final String TTC_12M_RESOURCE_FILE_EXT = ".12m";
	/** The 13M TTC - remove court restriction payment. */
	public static final String TTC_13M_RESOURCE_FILE_EXT = ".13m";
	/** The 14M TTC - FR penalty fee payment. */
	public static final String TTC_14M_RESOURCE_FILE_EXT = ".14m";
	/** The 22M TTC - automated DL 22. */
	public static final String TTC_22M_RESOURCE_FILE_EXT = ".22m";
	/** The 38U TTC - DL/ID Address Change. */
	public static final String TTC_38U_RESOURCE_FILE_EXT = ".38u";
	/** The 60U TTC - service of order inquiry. */
	public static final String TTC_60U_RESOURCE_FILE_EXT = ".60u";
	/** The FCP TTC - FTA/FTP fine payment/clearance inquiry. */
	public static final String TTC_FCP_RESOURCE_FILE_EXT = ".fcp";
	/** The TTC Map for merged panel browser title. */
	private final static Map <String, String> TTC_MAP = new HashMap <String, String>();
	/** The Proof Filing inquiry. */
	public static final String TTC_PRF_RESOURCE_FILE_EXT = ".prf";
	/** The Constant YES. */
	protected static final String YES = "Y";
	protected static final String BLANK = "";
	static {
		//DLA TTC
		TTC_MAP.put(DRIVER_LICENSE_APPLICATION, DLA_RESOURCE_FILE_EXT);
		//CDA TTC
		TTC_MAP.put(CONTINUE_DRIVING_APPLICATION, CDA_RESOURCE_FILE_EXT);
		//DAF TTC
		TTC_MAP.put(DAILY_APPLICATION_FILE, DAF_RESOURCE_FILE_EXT);
		//13M TTC
		TTC_MAP.put(REMOVE_COURT_RESTRICTION_PAYMENT, TTC_13M_RESOURCE_FILE_EXT);
		//07M TTC
		TTC_MAP.put(TRANSIT_TRAINING_PAYMENT, TTC_07M_RESOURCE_FILE_EXT);
		//14M TTC
		TTC_MAP.put(FR_PENALTY_PAYMENT, TTC_14M_RESOURCE_FILE_EXT);
		//04M TTC
		TTC_MAP.put(REISSUE_FEE_PAYMENT, TTC_04M_RESOURCE_FILE_EXT);
		//06M TTC
		TTC_MAP.put(SPECIAL_CERTIFICATE_PAYMENT, TTC_06M_RESOURCE_FILE_EXT);
		//12M TTC
		TTC_MAP.put(ADD_COURT_RESTRICTION_PAYMENT, TTC_12M_RESOURCE_FILE_EXT);
		//05M TTC
		TTC_MAP.put(MEDICAL_REPORT_UPDATE, TTC_05M_RESOURCE_FILE_EXT);
		//22M TTC
		TTC_MAP.put(AUTOMATED_DL_22, TTC_22M_RESOURCE_FILE_EXT);
		//60U TTC
		TTC_MAP.put(SERVICE_OF_ORDER_INQUIRY, TTC_60U_RESOURCE_FILE_EXT);
		//FCP TTC
		TTC_MAP.put(FTA_FTP_FINE_PMT_CLEARANCE_INQUIRY,
				TTC_FCP_RESOURCE_FILE_EXT);
		//38U TTC
		TTC_MAP.put(DL_ID_ADDRESS_CHANGE_INQUIRY, TTC_38U_RESOURCE_FILE_EXT);
		//07Q TTC
		TTC_MAP.put(COUNSELOR_INQUIRY, TTC_07Q_RESOURCE_FILE_EXT);
		//PRF TTC
		TTC_MAP.put(PROOF_FILING_INQUIRY, TTC_PRF_RESOURCE_FILE_EXT);
	}

	/**
	 * Gets the resource file extension for selected TTC.
	 * @param aTtc the a TTC
	 * @return the resource file extension for TTC
	 */
	protected static String getResourceFileExtensionForTtc(String aTtc) {
		if (TTC_MAP.containsKey(aTtc)) {
			return TTC_MAP.get(aTtc);
		}
		return BROWSER_RESOURCE_FILE_EXT;
	}

	/** The actions handler. */
	private ActionsHandler actionsHandler;
	/** The browser title. */
	private String browserTitle;
	/** City Code For Current Office Id. */
	public String cityCodeForCurrentOfficeId;
	/** The session context. */
	private ISessionContext sessionContext;

	/**
	 * Get the code set element from the list based on the index passed.
	 *
	 * @param codeSetList
	 *            the code set list
	 * @param index
	 *            the index
	 *
	 * @return the code set element
	 */
	public CodeSetElement codeSetListConverterForGet(
			List <CodeSetElement> codeSetList, int index) {
		try {
			if ((codeSetList != null) && (codeSetList.size() > (index - 1))) {
				return codeSetList.get(index - 1);
			}
		}
		catch (Exception e) {
			this.errorMessage(e);
		}
		return new CodeSetElement("", "", "");
	}

	/**
	 * Log the error with message, method name and class name.
	 *
	 * @param e
	 *            the e
	 */
	public void errorMessage(Exception e) {
		/*LOGGER.error("\""
				+ e.getMessage()
				+ "\" occurred at "
				+ e.getStackTrace()[0].getMethodName() + "()  "
				+ e.getStackTrace()[1].getMethodName()
				+ "() in "
				+ e.getStackTrace()[1].getClassName().getClass()
						.getSimpleName());*/
		LOGGER.error(e.getMessage());
		if (LOGGER.isWarnEnabled()) {
			logExceptionDetails(e);
		}
	}

	/**
	 * Gets the backing name.
	 *
	 * @return the backing name
	 */
	public String getBackingName() {
		return "";
	}

	/**
	 * Gets the browser title.
	 *
	 * @return the browser title
	 */
	public String getBrowserTitle() {
		return this.browserTitle;
	}

	/**
	 * Gets the browser title for TTC.
	 *
	 * @param aTtc
	 *            the a TTC
	 *
	 * @return the browser title for TTC
	 */
	protected String getBrowserTitleForTtc(String aTtc) {
		String aPageName = FacesUtils.getPageName();
		String applicationLabelKey = FacesUtils.getPageName().substring(
				aPageName.lastIndexOf("/") + 1, aPageName.indexOf(".jspx"));
		String anExtension = getResourceFileExtensionForTtc(aTtc);
		Enumeration <String> keys = applicationLabels.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			if (key.equalsIgnoreCase(applicationLabelKey + anExtension)) {
				return applicationLabels.getString(applicationLabelKey
						+ anExtension);
			}
		}
		return applicationLabels.getString(applicationLabelKey
				+ BROWSER_RESOURCE_FILE_EXT);
	}

	/**
	 * Gets the bundle.
	 *
	 * @return the bundle
	 */
	public ResourceBundle getBundle() {
		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();
		return ResourceBundle.getBundle(this.getBundleName(), this.getRequest()
				.getLocale(), classLoader);
	}

	/**
	 * Gets the bundle name.
	 *
	 * @return the bundle name
	 */
	public String getBundleName() {
		return this.getFacesContext().getApplication().getMessageBundle();
	}

	/**
	 * Get the city code for the current logged in office.
	 *
	 * @return the city code for current office id
	 */
	@SuppressWarnings("unchecked")
	public String getCityCodeForCurrentOfficeId() {
		String officeId = getCurrentProcessContext().getUserContext()
				.getOfficeId();
		// Get the existing city codes list from the Servlet context.
		List <OfficeCityCode> officeCityCodeList = (List <OfficeCityCode>) getServletContext()
				.getAttribute(officeId);
		StringBuilder cityCodes = new StringBuilder("");
		if (officeCityCodeList != null) {
			int counter = 1;
			for (OfficeCityCode officeCityCode : officeCityCodeList) {
				cityCodes.append(officeCityCode.getCityCode()).append(":")
						.append(officeCityCode.getCityName()).append(":")
						.append("CA:").append(officeCityCode.getZipCode())
						.append(":").append(officeCityCode.getCountyCode());
				if (counter < officeCityCodeList.size()) {
					cityCodes.append(";");
				}
				counter++;
			}
		}
		return cityCodes.toString();
	}

	/**
	 * Get the code set element based on the code set name and code set element
	 * code. Gets the code set element by code.
	 * @param codeSetName the code set name
	 * @param code the code
	 * @return the code set element by code
	 */
	@SuppressWarnings("unchecked")
	protected CodeSetElement getCodeSetElementByCode(String codeSetName,
			String code) {
		List <SuggestedSelectItem> incAppList = (List <SuggestedSelectItem>) FacesUtils
				.getApplicationScope().get(codeSetName);
		for (SuggestedSelectItem selectItem : incAppList) {
			if (selectItem != null && selectItem.getValue() != null) {
				if (selectItem.getValue() instanceof CodeSetElement) {
					CodeSetElement codeSetElement = (CodeSetElement) selectItem
							.getValue();
					if (codeSetElement.getCode().equals(code)) {
						return codeSetElement;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Gets the current process context.
	 *
	 * @return the current process context
	 */
	public ProcessContext getCurrentProcessContext() {
		return (ProcessContext) EaseProxyUtils.getProxyObject(this
				.getSessionContext().getCurrentProcessContext());
	}

	/**
	 * Returns the current screen name.
	 *
	 * @return the current screen name
	 */
	public String getCurrentScreenName() {
		String viewId = FacesUtils.getFacesContext().getViewRoot().getViewId();
		return viewId.substring(viewId.lastIndexOf("/") + 1,
				viewId.indexOf(".jspx"));
	}

	/**
	 * Gets the faces context.
	 *
	 * @return the faces context
	 */
	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	/**
	 * Default method for focus.
	 * @return the focusField
	 */
	public String getFocusField() {
		return getFocusField("");
	}

	/**
	 * Get the UI focus field for the first business rule validation.
	 * If there is no BR validation error then return the default focus.
	 *
	 * @param defaultFocus the default focus
	 * @return the focusField
	 */
	public String getFocusField(String defaultFocus) {
		//Iterate the error messages until UI focus field is not null.
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Iterator <?> messages = facesContext.getMessages();
		while (EaseUtil.isNotNull(messages) && messages.hasNext()) {
			FacesMessage facesMessage = (FacesMessage) messages.next();
			if (facesMessage != null
					&& !EaseUtil.isNullOrBlank(facesMessage.getDetail())
					&& !facesMessage.getDetail().contains(BR_ERROR_MSG_IND)) {
				String focusField = facesMessage.getDetail();
				if (!focusField.startsWith(FORM_ID)) {
					return FORM_ID + COLON + focusField;
				}
				return focusField;
			}
		}
		return defaultFocus;
	}

	/**
	 * Return the managed bean with the given name.
	 *
	 * @param beanName
	 *            the name of the managed bean to retrieve
	 *
	 * @return the managed bean
	 */
	public Object getManagedBean(String beanName) {
		String expression = "#{" + beanName + "}";
		return this.resolveExpression(expression);
	}

	/**
	 * Return the log on office id from user context.
	 * @return
	 */
	public String getOfficeId() {
		return getUserContext().getOfficeId();
	}

	/**
	 * Get the Process Type Mode (C or M, or T or P).
	 *
	 * @return the process type mode
	 */
	public String getProcessTypeMode() {
		return getCurrentProcessContext().getUserContext().getOperationalMode()
				.getCode();
	}

	/**
	 * Servlet API Convenience method.
	 *
	 * @return HttpServletRequest from the FacesContext
	 */
	public HttpServletRequest getRequest() {
		return (HttpServletRequest) this.getFacesContext().getExternalContext()
				.getRequest();
	}

	/**
	 * Servlet API Convenience method.
	 *
	 * @return the ServletContext form the FacesContext
	 */
	public ServletContext getServletContext() {
		return (ServletContext) this.getFacesContext().getExternalContext()
				.getContext();
	}

	/**
	 * Gets the session context.
	 *
	 * @return the sessionContext
	 */
	public ISessionContext getSessionContext() {
		return this.sessionContext;
	}

	/**
	 * Return system preferences object.
	 *
	 * @return SystemPref
	 */
	public SystemPreferences getSystemPref() {
		return (SystemPreferences) this.getManagedBean(SYSTEM_PREF_BEAN);
	}

	/**
	 * Get the technician current office ID from the user context.
	 *
	 * @return the tech office id
	 */
	public String getTechOfficeId() {
		return getCurrentProcessContext().getUserContext().getOfficeId();
	}

	/**
	 * Gets the user context.
	 *
	 * @return the user context
	 */
	public UserContext getUserContext() {
		return (UserContext) this.getCurrentProcessContext().getUserContext();
	}

	/**
	 * Logs relevant details of an exception occurrence (when the logger's logging level is set to WARN or lower) 
	 * @param e
	 */
	private void logExceptionDetails(Exception e) {
		ProcessContext processContext = (ProcessContext) getCurrentProcessContext();
		StringBuilder logMessage = new StringBuilder();
		logMessage.append("\nERROR DETAILS\n");
		logMessage.append("REQUEST URI: ")
				.append(FacesUtils.getRequest().getRequestURI()).append("\n");
		logMessage.append("CURRENT ACTIVITY: ")
				.append(processContext.getCurrentActivity().getActivityName())
				.append("\n");
		logMessage.append("CURRENT TTC: ")
				.append(processContext.getUserContext().getTtc()).append("\n");
		logMessage.append("PROCESS CONTEXT CLASS: ")
				.append(processContext.getClass().getSimpleName()).append("\n");
		logMessage.append("EXCEPTION CLASS: ")
				.append(e.getClass().getSimpleName()).append("\n");
		logMessage.append("EXCEPTION MESSAGE: ").append(e.getMessage())
				.append("\n");
		logMessage.append("STACKTRACE: ")
				.append(ExceptionUtils.getStackTrace(e)).append("\n");
		logMessage.append("USER INFO: ")
				.append(processContext.getUserContext().toString())
				.append("\n");
		LOGGER.warn(logMessage.toString());
	}

	/**
	 * Render pre-processing.
	 */
	public void renderPreProcessing() {
	}

	/**
	 * Return the result of the resolved expression.
	 *
	 * @param expression
	 *            the expression
	 *
	 * @return the object
	 */
	private Object resolveExpression(String expression) {
		Object value = null;
		if ((expression.indexOf("#{") != -1)
				&& (expression.indexOf("#{") < expression.indexOf('}'))) {
			value = this.getFacesContext().getApplication()
					.createValueBinding(expression)
					.getValue(this.getFacesContext());
		}
		else {
			value = expression;
		}
		return value;
	}

	/**
	 * Sets the actions handler.
	 *
	 * @param actionsHandler
	 *            the new actions handler
	 */
	public void setActionsHandler(ActionsHandler actionsHandler) {
		this.actionsHandler = actionsHandler;
	}

	/**
	 * Sets the browser title.
	 *
	 * @param browserTitle the browserTitle to set
	 */
	public void setBrowserTitle(String browserTitle) {
		this.browserTitle = EaseUtil.convertBlankToNull(browserTitle);
	}

	/**
	 * Sets the browser title from resource bundle.
	 */
	public void setBrowserTitleFromResourceBundle() {
		this.browserTitle = this.getBrowserTitleForTtc(this
				.getCurrentProcessContext().getUserContext().getTtc());
	}

	/**
	 * Sets the city code for current office id.
	 *
	 * @param cityCodeForCurrentOfficeId the cityCodeForCurrentOfficeId to set
	 */
	public void setCityCodeForCurrentOfficeId(String cityCodeForCurrentOfficeId) {
		this.cityCodeForCurrentOfficeId = EaseUtil
				.convertBlankToNull(cityCodeForCurrentOfficeId);
	}

	/**
	 * Sets the session context.
	 *
	 * @param sessionContext
	 *            the sessionContext to set
	 */
	public void setSessionContext(ISessionContext sessionContext) {
		this.sessionContext = sessionContext;
	}

	/**
	 * Set the technician current office ID in the user context.
	 *
	 * @param officeId the new tech office id
	 */
	public void setTechOfficeId(String officeId) {
	}

	/**
	 * Submit pre processing.
	 */
	public void submitPreProcessing() {
	}

	/**
	 * Super render pre processing.
	 */
	public void superRenderPreProcessing() {
		this.actionsHandler.setupButtons();
		this.setBrowserTitleFromResourceBundle();
		this.renderPreProcessing();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see gov.ca.dmv.ease.fw.validate.IValidatable#validate()
	 */
	public IErrorCollector validate() {
		// Subclasses should override to implement appropriate validation
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * gov.ca.dmv.ease.fw.validate.IValidatable#validateUsing(gov.ca.dmv.ease
	 * .fw.error.IErrorCollector)
	 */
	public void validateUsing(IErrorCollector aCollector) {
		// Subclasses should override to implement appropriate validation
	}
}
/**
 * Modification History:
 *
 * $Log: BasePage.java,v $
 * Revision 1.4  2017/11/09 16:31:03  mwskh1
 * Real ID - Merge to HEAD
 *
 * Revision 1.3.2.1  2017/07/20 16:57:53  mwskh1
 * Real ID - 2.2.1 - added logic to the Backing beans to support the new Real ID DL/ID class codes
 *
 * Revision 1.3  2017/05/11 16:26:46  mwskh1
 * WAS 8.5.5, Java 7 setting changes
 *
 * Revision 1.2.4.1  2017/03/20 17:22:35  mwjmf6
 * Convert any blank values to null in setter methods.
 * EaseUtil.convertBlankToNull( )
 *
 * Revision 1.2.4.1  2017/03/20 17:22:35  mwjmf6
 * Convert any blank values to null in setter methods.
 * EaseUtil.convertBlankToNull( )
 *
 * Revision 1.2  2013/04/25 23:07:05  mwsec2
 * added logExceptionDetails method
 *
 * Revision 1.1  2012/10/01 02:58:07  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.47  2012/09/27 00:57:03  mwpxp2
 * Formatted
 *
 * Revision 1.46  2012/09/27 00:52:50  mwpxp2
 * Inherited from AbstractBackingBean; removed unnecessary imports
 *
 * Revision 1.45  2012/08/31 22:11:26  mwrrv3
 * Added getOfficeId().
 *
 * Revision 1.44  2012/08/18 00:49:51  mwrrv3
 * Code clean up and fixed PMD issues.
 *
 * Revision 1.43  2012/08/14 20:39:48  mwrrv3
 * Code clean up and fixed PMD issues.
 *
 * Revision 1.42  2012/08/09 23:52:41  mwrrv3
 * Code clean up (removed unwanted code) and used constants.
 *
 * Revision 1.41  2011/12/07 23:45:07  mwrrv3
 * Added code to support the browser title for 07Q and PRF.
 *
 * Revision 1.40  2011/09/27 16:48:22  mwrrv3
 * Updated the code to fix browser title for 38U and clean up the code.
 *
 * Revision 1.39  2011/06/27 21:34:47  mwhys
 * Updated getFocusField(). Committing on behalf of Raghava Vaka (mwrrv3).
 *
 * Revision 1.38  2011/05/24 00:21:18  mwrrv3
 * Updated getFocusField() method, defect# 782 related to focus issue.
 *
 * Revision 1.37  2011/05/18 23:07:20  mwrrv3
 * Updated the getFocusField() method for better business rule focus. Defect# 6024.
 *
 * Revision 1.36  2010/12/31 00:09:52  mwrrv3
 * Added getter and setter for CityCodeForCurrentOfficeId field.
 *
 * Revision 1.35  2010/12/08 00:51:15  mwgxk2
 * Fix on propertyfile exception.
 *
 * Revision 1.34  2010/12/04 19:18:49  mwrrv3
 * Added getFocusField method.
 *
 * Revision 1.33  2010/12/03 21:02:06  mwrrv3
 * Update the code to support business rule validation field focus.
 *
 * Revision 1.32  2010/11/14 02:04:11  mwrrv3
 * Added new method getCodeSetElementByCode to get the code set element.
 *
 * Revision 1.31  2010/11/07 22:38:02  mwrrv3
 * Added setBrowserTitle method to set the new browser title.
 *
 * Revision 1.30  2010/10/27 20:22:31  mwrrv3
 * Added constants for mode 1 (process type) codes.
 *
 * Revision 1.29  2010/10/22 00:20:27  mwrrv3
 * Updated the getErrorMessage method.
 *
 * Revision 1.28  2010/10/21 15:33:37  mwrrv3
 * Fixed the error message format.
 *
 * Revision 1.27  2010/10/08 20:51:13  mwrrv3
 * Implemented office city codes based on the office id.
 *
 * Revision 1.26  2010/09/15 18:59:38  mwcsj3
 * Updated class header
 *
 * Revision 1.25  2010/08/04 00:01:52  mwazg5
 * Added two static strings for default operation and function codes
 *
 * Revision 1.24  2010/08/03 22:03:21  mwazg5
 * Changed superRenderPreProcessing for mode selection modification
 *
 * Revision 1.23  2010/07/21 21:15:53  mwrrv3
 * Group 5 Initial commit.
 *
 * Revision 1.22  2010/07/13 17:11:02  mwkfh
 * relocated session restore packages
 *
 * Revision 1.21  2010/07/10 01:09:23  mwrrv3
 * Added method getBackingName().
 *
 * Revision 1.20  2010/06/21 23:00:47  mwcsj3
 * Merged SUB_BUSINESS_PROCESS_IMPLEMENTATION branch to HEAD
 *
 * Revision 1.17.2.2  2010/06/20 18:06:58  mwakg
 * Rebased to June 20, 2010
 *
 * Revision 1.19  2010/06/09 18:18:56  mwrrv3
 * getResourceFileExtensionForTtc metho return values changed
 *
 * Revision 1.18  2010/06/08 16:34:19  mwvkm
 * duplicate setter for sessionContext is removed.
 *
 * Revision 1.17  2010/05/28 17:36:32  mwrpk
 * changing mode_Selection to modeSelection
 *
 * Revision 1.16  2010/05/14 04:45:40  mwvkm
 * Bulk Check-in for the migration of LogProcessor and the integration of EaseListener
 *
 * Revision 1.15  2010/05/10 22:18:24  mwrpk
 * SLTT work
 * Revision 1.14 2010/05/05 18:23:17 mwskd2 return code
 * in catch block to get .browsertitle by default
 *
 * Revision 1.13 2010/05/05 00:09:44 mwvkm Chnaged the sessionContext type to
 * ISessionContext
 *
 * Revision 1.12 2010/05/03 20:02:36 mwpxp2 Simplified implementation of
 * setBrowserTitleFromResourceBundle; added todos
 *
 * Revision 1.11 2010/05/01 19:08:30 mwsxv5 Added browser Title instead of page
 * title.
 *
 * Revision 1.10 2010/04/26 17:32:49 mwskd2 dyanamic browser title logic is
 * added
 *
 * Revision 1.9 2010/04/22 19:29:58 mwpxp2 Bulk cleanup
 *
 * Revision 1.8 2010/04/04 23:53:57 mwakg Removed ChangeRecord and ChangeTracker
 * as they are not used anymore
 *
 * Revision 1.7 2010/04/01 00:11:44 mwakg Removed usage of
 * EaseHttpSessionListener. UserContext and SessionContext are now spring beans
 * with session scope and they are initialized using spring init-method and
 * destroy-method tags. They are injected where required
 *
 * Revision 1.6 2010/03/31 17:50:55 mwrrv3 Updated the convert method for get
 * methods.
 *
 * Revision 1.5 2010/03/30 00:48:06 mwrrv3 Modified the code set converter for
 * get methods.
 *
 * Revision 1.4 2010/03/24 17:11:00 mwrrv3 Added public method to base page to
 * convert get code set list.
 *
 * Revision 1.3 2010/03/23 00:03:22 mwpxp2 Bulk cleanup
 *
 * Revision 1.2 2010/01/14 18:31:23 mwpzs3 move to JCL logging
 *
 * Revision 1.1 2009/11/23 16:22:52 mwrsk Intial commit
 *
 * Revision 1.32 2009/10/26 17:32:54 mwskd2 PageConstant variable added
 *
 * Revision 1.31 2009/10/22 00:40:45 mwbvc Gopi Changes - for tab support and
 * separating the inquiry to court and dcs
 *
 * Revision 1.30 2009/10/21 23:52:37 mwbvc changed the package names and
 * refactored the code
 *
 * Revision 1.29 2009/10/07 19:09:02 mwsmg6 added IRequest as the interface
 * pages must implement
 *
 * Revision 1.28 2009/10/03 21:42:46 mwpxp2 Adjusted imports for fw, apph
 * refactorings; bulk cleanup
 *
 * Revision 1.27 2009/10/03 19:47:32 mwpxp2 Added file decorators, javadoc;
 * adjusted imports for ChangeEvent location
 *
 */
