/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import java.io.Serializable;

import javax.faces.model.SelectItem;

/**
 * Description: This class is is used to get the selected items from the 
 * suggested input text box and also place the values in ascending order.
 * File: SuggestedSelectItem.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author mwbvc
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class SuggestedSelectItem extends SelectItem implements
		Comparable <SuggestedSelectItem>, Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1171084806834586991L;
	/** The description. */
	private String description = null;
	/** The disabled. */
	private boolean disabled = false;
	/** The escape. */
	private boolean escape;
	/** The label. */
	private String label = null;
	/** The value. */
	private Object value = null;

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 */
	public SuggestedSelectItem() {
		super();
	}

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 * 
	 * @param value Value to be delivered to the model if this item is selected by the user
	 */
	public SuggestedSelectItem(Object value) {
		this(value, value == null ? null : value.toString(), null, false, true);
	}

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 * 
	 * @param value Value to be delivered to the model if this item is selected by the user
	 * @param label Label to be rendered for this item in the response
	 */
	public SuggestedSelectItem(Object value, String label) {
		this(value, label, null, false, true);
	}

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 * 
	 * @param value Value to be delivered to the model if this item is selected by the user
	 * @param label Label to be rendered for this item in the response
	 * @param description Description of this item, for use in tools
	 */
	public SuggestedSelectItem(Object value, String label, String description) {
		this(value, label, description, false, true);
	}

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 * 
	 * @param value Value to be delivered to the model if this item is selected by the user
	 * @param label Label to be rendered for this item in the response
	 * @param description Description of this item, for use in tools
	 * @param disabled Flag indicating that this option is disabled
	 */
	public SuggestedSelectItem(Object value, String label, String description,
			boolean disabled) {
		this(value, label, description, disabled, true);
	}

	/**
	 * Construct a SuggestSelectItem instance with the specified
	 * property values.
	 * 
	 * @param value Value to be delivered to the model if this item is selected by the user
	 * @param label Label to be rendered for this item in the response
	 * @param description Description of this item, for use in tools
	 * @param disabled Flag indicating that this option is disabled
	 * @param escape Flag indicating that the text of this option should be escaped when rendered.
	 */
	public SuggestedSelectItem(Object value, String label, String description,
			boolean disabled, boolean escape) {
		super();
		setValue(value);
		setLabel(label);
		setDescription(description);
		setDisabled(disabled);
		setEscape(escape);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public final int compareTo(SuggestedSelectItem suggestedSelectItem) {
		return this.label.compareToIgnoreCase(suggestedSelectItem.label);
	}

	/**
	 * Return a description of this item, for use in development tools.
	 * 
	 * @return description
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * Return the label of this item, to be rendered visibly for the user.
	 * 
	 * @return the label value
	 */
	@Override
	public String getLabel() {
		return label;
	}

	/**
	 * Return the value of this item, to be delivered to the model
	 * if this item is selected by the user.
	 * 
	 * @return the Object
	 */
	@Override
	public Object getValue() {
		return value;
	}

	/**
	 * Return the disabled flag for this item, which should modify the
	 * rendered output to make this item unavailable for selection by the user
	 * if set to true.
	 * 
	 * @return the disabled flag
	 */
	@Override
	public boolean isDisabled() {
		return disabled;
	}

	/**
	 * Getter for property escape.
	 * 
	 * @return Value of property escape.
	 */
	public boolean isEscape() {
		return escape;
	}

	/**
	 * Set the description of this item, for use in development tools.
	 * 
	 * @param description The new description
	 */
	@Override
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Set the disabled flag for this item, which should modify the
	 * rendered output to make this item unavailable for selection by the user
	 * if set to true.
	 * 
	 * @param disabled The new disabled flag
	 */
	@Override
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	/**
	 * Setter for property escape.
	 * 
	 * @param escape New value of property escape
	 */
	public void setEscape(boolean escape) {
		this.escape = escape;
	}

	/**
	 * Set the label of this item, to be rendered visibly for the user.
	 * 
	 * @param label The new label
	 */
	@Override
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * Set the value of this item, to be delivered to the model
	 * if this item is selected by this user.
	 * 
	 * @param value The new value
	 */
	@Override
	public void setValue(Object value) {
		this.value = value;
	}
}
/**
 *  Modification History:
 * 
 *  $Log: SuggestedSelectItem.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 *  Revision 1.1  2009/11/23 16:22:52  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/11/05 01:00:53  mwbvc
 *  chnage dtom instance of a SelctItem
 *
 *  Revision 1.1  2009/11/03 21:23:26  mwbvc
 *  New Class to select the items and putting them in ascending order for suggested input box
 *
 *
*/
