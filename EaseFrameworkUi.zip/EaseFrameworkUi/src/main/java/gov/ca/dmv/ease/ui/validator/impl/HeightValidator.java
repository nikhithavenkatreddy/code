/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: HeightValidator is a custom validator which validates
 * the height in feet value.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: HeightValidator 
 * Created: Oct 19, 2009
 * @author mwbvc
 * @version $Revision: 1.1 $ 
 * Last Changed: $Date: 2012/10/01 02:58:06 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class HeightValidator extends ValidatorBase {
	private static final String ERROR_MESSAGE = "DATA NOT WITHIN SPECIFIED RANGE";
	private static final String CONVERSION_ERROR_MESSAGE = "INVALID CHARACTER IN ALPHA/NUMERIC FIELD";
	/**
	 * Instantiates a new Height validator.
	 */
	public HeightValidator() {
	}


	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		//Convert String to Integer and if the value is greater than 11 then throw an error.
		try {
			int heightInInches = new Integer((String) value).intValue();
			if (heightInInches < 0 || heightInInches > 11) {
				throw new ValidatorException(FacesUtils.createErrorMessage(value
						.toString(), ERROR_MESSAGE));
			}
		} catch (NumberFormatException e) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString(), CONVERSION_ERROR_MESSAGE));
		}
	}
}

/**
 *  Modification History:
 * 
 *  $Log: HeightValidator.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/08/14 20:41:45  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.1  2010/09/13 22:06:18  mwrrv3
 *  New validator for the height field.
 *
 */