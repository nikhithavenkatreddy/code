/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.converter.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.bo.code.impl.OfficeCityCode;
import gov.ca.dmv.ease.fw.exception.impl.EaseConversionException;
import gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText;
import gov.ca.dmv.ease.ui.component.impl.SuggestedSelectItem;
import gov.ca.dmv.ease.ui.constants.PageConstants;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.el.ValueBinding;

/**
 * Description: JSF converter for CodeSetElement and all its subclasses
 * File: CodeSetConverter.java
 * Module:  gov.ca.dmv.ease.ui.converter.impl
 * Created: Aug 8, 2009
 * 
 * @author MWPXM2
 * @version $Revision: 1.2 $
 * Last Changed: $Date: 2017/12/14 21:13:31 $
 * Last Changed By: $Author: mwskh1 $
 */
public class CodeSetConverter implements Converter {
	/** The CODESET value pattern. */
	protected static Pattern CODE_SET_VAL_PATTERN = Pattern
			.compile("(\\w*);(\\w*)");
	/** The CODESET value pattern. */
	protected static Pattern CODE_SET_VALUE_PATTERN = Pattern
			.compile("([A-Z0-9\\*]*)");

	/**
	 * Decode code set name.
	 * 
	 * @param encodedName Encoded name
	 * 
	 * @return decoded name
	 */
	private String decodeCodeSetName(String encodedName) {
		String name = "";
		try {
			if (encodedName.length() % 2 == 0) {
				int length = encodedName.length() / 2;
				byte[] byteCodes = new byte[length];
				for (int i = 0; i < length; i++) {
					int start = i * 2;
					String byteCodeString = encodedName.substring(start,
							start + 2);
					byte byteCode = Byte.parseByte(byteCodeString, 16);
					byteCodes[i] = byteCode;
				}
				name = new String(byteCodes, "ASCII");
			}
		}
		catch (UnsupportedEncodingException e) {
			throw new EaseConversionException(e);
		}
		return name;
	}

	/**
	 * Encode code set name.
	 * 
	 * @param name Name to be encoded
	 * 
	 * @return Encoded name
	 */
	private String encodeCodeSetName(String name) {
		if (name == null) {
			return "";
		}
		String encodedName = "";
		try {
			byte[] byteCodes = name.getBytes("ASCII");
			for (byte byteCode : byteCodes) {
				encodedName += Integer.toHexString(byteCode);
			}
		}
		catch (UnsupportedEncodingException e) {
			throw new EaseConversionException(e);
		}
		return encodedName.toUpperCase();
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 * Convert the specified string value, which is associated with the specified UIComponent, into a model data object 
	 * that is appropriate for being stored during the Apply Request Values phase of the request processing lifecycle
	 */
	@SuppressWarnings("unchecked")
	public Object getAsObject(FacesContext facesContext, UIComponent component,
			String valueString) {
		if (valueString == null || valueString.equals("")) {
			return null;
		}
		String codeSetName = null;
		String codeSetValue = null;
		if (component instanceof HtmlCodedInputText) {
			codeSetName = ((HtmlCodedInputText) component).getCodeSetName();
			//If the code set name is not hard coded then get the value from 
			//value binding object. e.g: SSN VERIF Code set name is dynamic.
			if (codeSetName == null) {
				ValueBinding valueBinding = component
						.getValueBinding("codeSetName");
				if (valueBinding != null) {
					codeSetName = (String) valueBinding.getValue(facesContext);
				}
			}
			codeSetValue = valueString.toUpperCase();
			if (codeSetValue != null) {
				Matcher matcher = CODE_SET_VALUE_PATTERN.matcher(codeSetValue);
				if (!matcher.matches()) {
					throw new ConverterException(FacesUtils.createErrorMessage(
							valueString,
							PageConstants.INVALID_CHARACTER_IN_ALPHA_NUMERIC));
				}
			}
		}
		else {
			Matcher matcher = CODE_SET_VAL_PATTERN.matcher(valueString);
			if (!matcher.matches()) {
				throw new ConverterException(FacesUtils.createErrorMessage(
						valueString,
						PageConstants.DATA_DOES_NOT_MATCH_VALID_CODES));
			}
			codeSetName = decodeCodeSetName(matcher.group(1));
			codeSetValue = matcher.group(2);
		}
		if ("CityCode".equalsIgnoreCase(codeSetName)) {
			String officeId = "";
			ValueBinding officeValueBinding = component
					.getValueBinding("officeId");
			if (officeValueBinding != null) {
				officeId = (String) officeValueBinding.getValue(facesContext);
			}
			if (officeId != null) {
				List <OfficeCityCode> officeCityCodeList = (List <OfficeCityCode>) FacesUtils
						.getApplicationScope().get(officeId);
				if (officeCityCodeList != null) {
					for (OfficeCityCode officeCityCode : officeCityCodeList) {
						if (officeCityCode.getCityCode().equals(codeSetValue)) {
							return officeCityCode.getCityCode();
						}
					}
				}
			}
		}
		else {
			// Split the code set names with comma separated values.
			String[] csNames = codeSetName.split(",");
			// This list holds all the select items related to one or more code
			// sets.
			List <SuggestedSelectItem> totalSelectItemsList = new ArrayList <SuggestedSelectItem>();
			for (String csName : csNames) {
				// Add all the select items to the total list
				if ((List <SuggestedSelectItem>) FacesUtils
						.getApplicationScope().get(csName) != null) {
					totalSelectItemsList
							.addAll((List <SuggestedSelectItem>) FacesUtils
									.getApplicationScope().get(csName));
				}
			}
			//If the code set values are empty then throw data doesn't match valid code error.
			if (totalSelectItemsList == null) {
				throw new ConverterException(FacesUtils.createErrorMessage(
						valueString,
						PageConstants.DATA_DOES_NOT_MATCH_VALID_CODES));
			}
			//If the entered value is not exists in the total list then throw data 
			//doesn't match valid code error.
			for (SuggestedSelectItem selectItem : totalSelectItemsList) {
				Object value = selectItem.getValue();
				if (((CodeSetElement) value).getCode().equals(codeSetValue)) {
					return new CodeSetElement((CodeSetElement) value);
				}
			}
		}
		throw new ConverterException(FacesUtils.createErrorMessage(valueString,
				PageConstants.DATA_DOES_NOT_MATCH_VALID_CODES));
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 * Convert the specified model object value, which is associated with the specified UIComponent, into a 
	 * String that is suitable for being included in the response generated during the 
	 * Render Response phase of the request processing lifeycle
	 */
	public String getAsString(FacesContext facesContext, UIComponent component,
			Object object) {
		if (object == null || (object instanceof String && object.equals(""))) {
			return "";
		}
		if (!(object instanceof CodeSetElement)) {
			return "";
		}
		CodeSetElement element = (CodeSetElement) object;
		if (component instanceof HtmlCodedInputText) {
			return element.getCode();
		}
		String codeSetName = encodeCodeSetName(element.getCodeCategory());
		return codeSetName + ";" + ((CodeSetElement) object).getCode();
	}
}
/**
 *  Modification History:
 * 
 *  $Log: CodeSetConverter.java,v $
 *  Revision 1.2  2017/12/14 21:13:31  mwskh1
 *  Real ID - merge REAL_ID_EASE_2_8_1_1 branch to head for 2.8.1.3
 *
 *  Revision 1.1.10.1  2017/12/01 22:25:37  mwxxw
 *  Fix defect 45. Allow the drop down field to be 1 or 2 characters instead of only allow 2.
 *
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.14  2011/12/03 02:25:34  mwrrv3
 *  Updated the code to fix defect# 6930 (don't display SSN VERI code).
 *
 *  Revision 1.13  2011/06/13 18:18:33  mwyxg1
 *  clean up
 *
 *  Revision 1.12  2011/03/16 22:33:31  mwrrv3
 *  passing copy constructor of codesetelment by rama
 *
 *  Revision 1.11  2011/01/15 22:56:59  mwgxk2
 *  Null pointer exception Fix.
 *
 *  Revision 1.10  2010/10/08 20:50:58  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.9  2010/08/27 23:53:42  mwrrv3
 *  Modified the code to support multiple code set names for single field.
 *
 *  Revision 1.8  2010/04/13 23:51:57  mwrrv3
 *  Modified the regular expression to accepts * from the test results drop down values.
 *
 *  Revision 1.7  2010/04/02 00:31:21  mwakg
 *  Getting codeset name from codeCategory instead of codeset
 *
 *  Revision 1.6  2010/03/29 22:44:50  mwcsj3
 *  Reverting changes made to getAsString() method
 *
 *  Revision 1.5  2010/03/26 21:19:10  mwcsj3
 *  Moved singletons to Spring bean and made changes to read the singletons from application context
 *
 *  Revision 1.4  2010/03/23 21:06:48  mwpxp2
 *  Switched to using EaseConversionException
 *
 *  Revision 1.3  2010/03/23 00:00:38  mwpxp2
 *  Adjusted imports for exception mods; fixed javadoc
 *
 *  Revision 1.2  2009/12/02 02:29:34  mwbvc
 *  fixed the bug
 *
 *  Revision 1.6  2009/12/02 02:25:50  mwbvc
 *  fixed the bug
 *
 *  Revision 1.5  2009/11/03 21:33:10  mwbvc
 *  changed SelectItem to SuggestedSelectItem to sort the select items
 *
 *  Revision 1.4  2009/10/27 21:44:02  mwbvc
 *  changes on messages
 *
 *  Revision 1.3  2009/10/27 00:18:37  mwgxk2
 *  Added Comments.
 *
 *  Revision 1.2  2009/10/22 16:55:02  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.1  2009/10/22 00:40:41  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.4  2009/10/21 23:52:17  mwbvc
 *  changed the package names and refactored the code
 *
 *  Revision 1.1  2009/09/10 20:36:41  mwpxm2
 *  CodeSet design change
 *
 *  Revision 1.2  2009/08/20 00:04:00  mwpxm2
 *  CodedInputText tag
 *
 *  Revision 1.1  2009/08/08 23:10:23  mwpxm2
 *  CodeSetConverter implementation
 *
*/
