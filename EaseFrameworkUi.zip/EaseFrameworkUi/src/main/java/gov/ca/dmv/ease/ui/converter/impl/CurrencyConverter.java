/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.converter.impl;

import java.text.DecimalFormat;
import java.text.ParseException;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description: This class converts a Double to a double-digit String (and vise-versa) by
 * BeanUtils when copying properties.
 * File: CurrencyConverter.java
 * Module:  gov.ca.dmv.ease.ui.converter.impl
 * Created: Oct 27, 2009 
 * @author MWSKD2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class CurrencyConverter implements Converter {
	/** Logger for this class. */
	private static final Log LOGGER = LogFactory
			.getLog(CurrencyConverter.class);
	/** The formatter. */
	private DecimalFormat formatter = new DecimalFormat("###,###.00");

	/**
	 * Convert a String to a Double and a Double to a String.
	 * 
	 * @param type the class type to output
	 * @param value the object to convert
	 * 
	 * @return object the converted object (Double or String)
	 */
	public final Object convert(@SuppressWarnings("rawtypes") final Class type, final Object value) {
		// for a null value, return null
		if (value == null) {
			return null;
		}
		else {
			if (value instanceof String) {
				LOGGER.debug("value (" + value + ") instance of String");
				try {
					if (StringUtils.isBlank(String.valueOf(value))) {
						return null;
					}
					LOGGER.debug("converting '" + value + "' to a decimal");
					// formatter.setDecimalSeparatorAlwaysShown(true);
					Number num = formatter.parse(String.valueOf(value));
					return num.doubleValue();
				}
				catch (ParseException pe) {
					pe.printStackTrace();
				}
			}
			else if (value instanceof Double) {
				LOGGER.debug("value (" + value + ") instance of Double");
				LOGGER.debug("returning double: " + formatter.format(value));
				return formatter.format(value);
			}
		}
		throw new ConversionException("Could not convert " + value + " to "
				+ type.getName() + ".");
	}

	/**
	 * Sets the decimal formatter.
	 * 
	 * @param df the new decimal formatter
	 */
	public void setDecimalFormatter(DecimalFormat decimalFormat) {
		this.formatter = decimalFormat;
	}
}
/**
 *  Modification History:
 *
 *  $Log: CurrencyConverter.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.7  2012/08/25 18:26:28  mwpxp2
 *  Fixed raw type warnings
 *
 *  Revision 1.6  2011/06/13 18:20:27  mwyxg1
 *  clean up
 *
 *  Revision 1.5  2011/03/23 23:46:57  mwyxk
 *  Removed if statements for LOGGOR.isDebugEnabled/isInfoEnabled unit test coverage.
 *
 *  Revision 1.4  2010/04/22 19:27:04  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.3  2010/03/22 23:59:30  mwpxp2
 *  Fixed file footer
 *
 */
