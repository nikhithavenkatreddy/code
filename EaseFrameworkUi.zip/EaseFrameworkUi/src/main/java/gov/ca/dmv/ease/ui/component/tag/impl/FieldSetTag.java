/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.tag.impl;

import gov.ca.dmv.ease.ui.component.impl.FieldSet;
import gov.ca.dmv.ease.ui.component.renderer.impl.FieldSetRenderer;

import javax.faces.component.UIComponent;
import javax.faces.el.ValueBinding;
import javax.faces.webapp.UIComponentTag;

/**
 * Description: Custom JSF component for fieldSet 
 * Module: gov.ca.dmv.ease.ui.component.impl.fieldset 
 * Created: Sep 16, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/16 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class FieldSetTag extends UIComponentTag {
	private String legend;

	/**
	 * Gets the FieldSet component type
	 * @return fieldSet Component Type
	 */
	@Override
	public String getComponentType() {
		return FieldSet.COMPONENT_TYPE;
	}

	/**
	 * Gets the FieldSet renderer type
	 * @return fieldSet Renderer Type
	 */
	@Override
	public String getRendererType() {
		return FieldSetRenderer.RENDERER_TYPE;
	}

	/**
	 * Sets null to all attributes and releases from the state.
	 */
	@Override
	public void release() {
		super.release();
		this.legend = null;
	}

	/**
	 * sets the legend property value
	 * @param legend
	 */
	public void setLegend(String legend) {
		this.legend = legend;
	}

	/**
	 * Sets the FieldSet component properties
	 * @param uiComponent
	 */
	@Override
	protected void setProperties(UIComponent uiComponent) {
		super.setProperties(uiComponent);
		setStringProperty(uiComponent, "legend", legend);
	}

	/**
	 * Sets the value to FieldSet property which is of type String
	 * @param uiComponent
	 * @param propName
	 * @param value
	 */
	private void setStringProperty(UIComponent uiComponent, String propName,
			String value) {
		if (value != null) {
			if (isValueReference(value)) {
				ValueBinding valueBinding = getFacesContext().getApplication()
						.createValueBinding(value);
				uiComponent.setValueBinding(propName, valueBinding);
			}
			else {
				uiComponent.getAttributes().put(propName, value);
			}
		}
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldSetTag.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/04/22 19:27:03  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.2  2010/03/22 23:57:30  mwpxp2
 *  Fixed file footer
 *
 */
