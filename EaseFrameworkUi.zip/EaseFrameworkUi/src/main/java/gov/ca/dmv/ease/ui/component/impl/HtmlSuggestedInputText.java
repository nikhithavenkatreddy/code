/**
 * This source code contains State of California's confidential
 * and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import javax.faces.context.FacesContext;

/**
 * Description: This class is the extension of @see HtmlCodedInputText with a capability of handling alphanumeric and
 * codesetname with suggestions.
 * File: HtmlSuggestedInputText.java
 * Module:  gov.ca.dmv.ease.ui.component.impl
 * Created: Sep 15, 2009
 * @author MWPXM2
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HtmlSuggestedInputText extends HtmlCodedInputText {
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.SuggestedInputText";
	/** The highlight match. */
	private Boolean highlightMatch = null;
	/** The popup width. */
	private String popupWidth = null;
	/**
	 * Instantiates a new html suggested input text.
	 */
	public HtmlSuggestedInputText() {
		setRendererType("gov.ca.dmv.ease.SuggestedInputText");
	}

	/**
	 * Gets the popup width.
	 * 
	 * @return the pop-up width
	 */
	public String getPopupWidth() {
		return popupWidth;
	}

	/**
	 * Checks if is highlight match.
	 * 
	 * @return the highlightMatch type
	 */
	public boolean isHighlightMatch() {
		return highlightMatch;
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext _context, Object _state) {
		Object values[] = (Object[]) _state;
		super.restoreState(_context, values[0]);
		highlightMatch = (Boolean) values[1];
		popupWidth = (String) values[2];
		setOfficeId((String) values[3]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.component.impl.HtmlCodedInputText#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext _context) {
		Object values[] = new Object[4];
		values[0] = super.saveState(_context);
		values[1] = highlightMatch;
		values[2] = popupWidth;
		values[3] = getOfficeId();
		return values;
	}

	/**
	 * Sets the highlight match.
	 * 
	 * @param highlightMatch the new highlightMatch boolean
	 */
	public void setHighlightMatch(boolean highlightMatch) {
		this.highlightMatch = highlightMatch;
	}

	/**
	 * Sets the popup width.
	 * 
	 * @param popupWidth the new pop-up width
	 */
	public void setPopupWidth(String popupWidth) {
		this.popupWidth = popupWidth;
	}
}
/**
 *  Modification History:
 *
 *  $Log: HtmlSuggestedInputText.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.3  2010/10/08 20:50:59  mwrrv3
 *  Implemented office city codes based on the office id.
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
