/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009-2012
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.handler.impl;

import gov.ca.dmv.ease.ui.handler.IHandlerTokenData;

/**
 * Description: I am implementation of IHandlerTokenData
 * File: HandlerTokenData.java
 * Module:  gov.ca.dmv.ease.ui.handler
 * Created: Mar 27, 2012 
 * @author mwpxp2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class HandlerTokenData implements IHandlerTokenData {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2344950916991662414L;
	/** The token. */
	private String token;
	/** The view id. */
	private String viewId;

	/**
	 * Instantiates a new handler token data.
	 */
	private HandlerTokenData() {
		super();
	}

	/**
	 * Instantiates a new handler token data.
	 *
	 * @param aToken the a token
	 * @param aViewId the a view id
	 */
	public HandlerTokenData(String aToken, String aViewId) {
		super();
		setToken(aToken);
		setViewId(aViewId);
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Gets the view id.
	 *
	 * @return the viewId
	 */
	public String getViewId() {
		return viewId;
	}

	/**
	 * Sets the token.
	 *
	 * @param token the token to set
	 */
	protected void setToken(String token) {
		this.token = token;
	}

	/**
	 * Sets the view id.
	 *
	 * @param viewId the viewId to set
	 */
	protected void setViewId(String viewId) {
		this.viewId = viewId;
	}
}
/**
 *  Modification History:
 *
 *  $Log: HandlerTokenData.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.1  2012/03/27 22:56:39  mwpxp2
 *  Initial
 *
 */
