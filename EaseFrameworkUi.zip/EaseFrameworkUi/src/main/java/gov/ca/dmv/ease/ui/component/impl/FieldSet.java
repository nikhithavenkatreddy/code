/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.component.impl;

import gov.ca.dmv.ease.ui.component.renderer.impl.FieldSetRenderer;

import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

/**
 * Description: FieldSet defines the html fieldset tag while rendering the JSF
 * This class is the custom component class for JSF tag 'fieldSet' 
 * Module: gov.ca.dmv.ease.ui.component.impl.fieldset 
 * Created: Sep 16, 2009
 * @author MWBVC
 * @version $Revision: 1.1 $ Last Changed: $Date: 2009/09/16 10:02:34 
 * 			$ Last Changed By: $Author: mwpxp2 $
 */
public class FieldSet extends UIComponentBase {
	/** The Constant COMPONENT_FAMILY. */
	public static final String COMPONENT_FAMILY = "javax.faces.Output";
	// define default types for FieldSet Component
	/** The Constant COMPONENT_TYPE. */
	public static final String COMPONENT_TYPE = "gov.ca.dmv.ease.FieldSet";
	/** The Constant DEFAULT_RENDERER_TYPE. */
	private static final String DEFAULT_RENDERER_TYPE = FieldSetRenderer.RENDERER_TYPE;
	/** The legend. */
	private String legend = null;

	/**
	 * Constructor.
	 */
	public FieldSet() {
		setRendererType(DEFAULT_RENDERER_TYPE);
	}

	/**
	 * Gets the FieldSet component Family.
	 * 
	 * @return fieldSet component family
	 */
	@Override
	public String getFamily() {
		return COMPONENT_FAMILY;
	}

	/**
	 * Gets the legend attribute value of a FieldSet.
	 * 
	 * @return legend attribute value
	 */
	public String getLegend() {
		if (legend != null) {
			return legend;
		}
		ValueBinding valueBinding = getValueBinding("legend");
		return valueBinding != null ? (String) valueBinding
				.getValue(getFacesContext()) : null;
	}

	/**
	 * gets the FieldSet component object.
	 * 
	 * @return fieldSet object
	 */
	public Object getValue() {
		return "fieldset";
	}

	/**
	 * Restores the component State.
	 * 
	 * @param facesContext the faces context
	 * @param state of FieldSet
	 */
	@Override
	public void restoreState(FacesContext facesContext, Object state) {
		Object values[] = (Object[]) state;
		super.restoreState(facesContext, values[0]);
		legend = (String) values[1];
	}

	/**
	 * Saves the FieldSet component State with the attribute values.
	 * 
	 * @param facesContext the faces context
	 * 
	 * @return Object of type FieldSet
	 */
	@Override
	public Object saveState(FacesContext facesContext) {
		Object values[] = new Object[2];
		values[0] = super.saveState(facesContext);
		values[1] = legend;
		return values;
	}

	/**
	 * Sets the legend attribute value for FieldSet component.
	 * 
	 * @param legend the legend
	 */
	public void setLegend(String legend) {
		this.legend = legend;
	}
}
/**
 *  Modification History:
 *
 *  $Log: FieldSet.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/22 23:49:05  mwpxp2
 *  Fixed class footer, javaodc
 *
 */
