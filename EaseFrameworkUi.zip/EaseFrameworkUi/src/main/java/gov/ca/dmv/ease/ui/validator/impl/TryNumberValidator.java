/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2010
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: TryNumberValidator is a custom validator which validates
 * the try number value.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: TryNumberValidator.java 
 * Created: Oct 18, 2010
 * @author mwarb3
 * @version $Revision: 1.1 $ 
 * Last Changed: $Date: 2012/10/01 02:58:06 $ 
 * Last Changed By: $Author: mwpxp2 $
 */
public class TryNumberValidator extends ValidatorBase {
	
	/** The Constant ERROR_MESSAGE. */
	private static final String ERROR_MESSAGE = "FIELD MAY ONLY CONTAIN NUMBERS";
	
	/** The Constant RANGE_ERROR_MESSAGE. */
	private static final String RANGE_ERROR_MESSAGE = "DATA NOT WITHIN SPECIFIED RANGE";

	/**
	 * Instantiates a new try number validator.
	 */
	public TryNumberValidator() {
	}


	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		//Convert String to Integer and if the value is greater than 15 or less than 1 then throw an error.
		try {
			int tryNumber = Integer.valueOf((String) value).intValue();
			if (tryNumber < 1 || tryNumber > 15) {
				throw new ValidatorException(FacesUtils.createErrorMessage(value
						.toString(), RANGE_ERROR_MESSAGE));
			}
		} catch (NumberFormatException e) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString(), ERROR_MESSAGE));
		}
	}
}

/**
 *  Modification History:
 * 
 *  $Log: TryNumberValidator.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2012/08/14 20:41:45  mwrrv3
 *  Fixed PMD issues.
 *
 *  Revision 1.1  2010/10/19 01:58:15  mwrrv3
 *  Defect # 2185 Fix
 *
 *
 */