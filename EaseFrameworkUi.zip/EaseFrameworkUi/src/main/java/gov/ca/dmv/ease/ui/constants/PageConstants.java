/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 *
 * Copyright State of California (c) 2008
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.constants;

/**
 * Description: constants relevant to UI.
 * File: PageConstants.java
 * Module: gov.ca.dmv.ease.ui.constants
 * Created: Oct 14, 2009
 *
 * @author MWRPK
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:06 $
 * Last Changed By: $Author: mwpxp2 $
 */
public interface PageConstants {
	/** The ACTIONS HANDLER Constant. */
	String ACTIONS_HANDLER = "actionsHandler";
	/** The 12M TTC - add court restriction payment. */
	String ADD_COURT_RESTRICTION_PAYMENT = "12M";
	/** The AUTOMATED_DL_22. */
	String AUTOMATED_DL_22 = "22M";
	/** The business rule BR_ERROR_FIELD. */
	String BR_ERROR_FIELD = "brErrorField";
	/** The business rule BR_ERROR_MSG_IND. */
	String BR_ERROR_MSG_IND = "-brErrorMsg";
	/** The business rule BR_STYLE_CLS. */
	String BR_STYLE_CLS = "brErrorMessage";
	/** The Constant COMPONENT_UIINPUT_CONVERSION. */
	String COMPONENT_UIINPUT_CONVERSION = "javax.faces.component.UIInput.CONVERSION";
	/** The Constant COMPONENT_UIINPUT_REQUIRED. */
	String COMPONENT_UIINPUT_REQUIRED = "javax.faces.component.UIInput.REQUIRED";
	/** The Constant COMPONENT_UISELECTMANY_INVALID. */
	String COMPONENT_UISELECTMANY_INVALID = "javax.faces.component.UISelectMany.INVALID";
	/** The Constant COMPONENT_UISELECTONE_INVALID. */
	String COMPONENT_UISELECTONE_INVALID = "javax.faces.component.UISelectOne.INVALID";
	/** The Constant CONSTRAINT_VALIDATOR_10. */
	String CONSTRAINT_VALIDATOR_10 = "ConstraintValidator.Validation_Error._10";
	/** The Constant CONTINUE_DRIVING_APPLICATION. */
	String CONTINUE_DRIVING_APPLICATION = "CDA";
	/** Constant for COUNSELOR_INQUIRY. */
	String COUNSELOR_INQUIRY = "07Q";
	/** The Constant DAILY_APPLICATION_FILE. */
	String DAILY_APPLICATION_FILE = "DAF";
	/** The Constant DATA_DOES_NOT_MATCH_VALID_CODES. */
	String DATA_DOES_NOT_MATCH_VALID_CODES = "DATA DOES NOT MATCH VALID CODES";
	/** Default Date Pattern*/
	String DEFAULT_DATE_PATTERN = "MMddyyyy";
	/** Constant for DL_ID_ADDRESS_CHANGE_INQUIRY. */
	String DL_ID_ADDRESS_CHANGE_INQUIRY = "38U";
	/** Constant for PROOF_FILLING_INQUIRY */
	String PROOF_FILLING_INQUIRY = "PRF";
	/** The Constant DRIVER_LICENSE_APPLICATION. */
	String DRIVER_LICENSE_APPLICATION = "DLA";
	/** The Constant DRIVER_LICENSE_PENDING. */
	String DRIVER_LICENSE_PENDING = "DLP";
	/** The Constant EASE_VALIDATOR_REGEX18. */
	String EASE_VALIDATOR_REGEX18 = "gov.ca.dmv.ease.validator.RegExValidator.regEx18";
	/** The Constant ERROR_MESG_FIRST_OUTPUT_ID. */
	String ERROR_MESG_FIRST_OUTPUT_ID = "ERROR_MESG_FIRST_OUTPUT_ID";
	/** The Constant ERROR_MESG_SECOND_OUTPUT_ID. */
	String ERROR_MESG_SECOND_OUTPUT_ID = "ERROR_MESG_SECOND_OUTPUT_ID";
	/** The Constant ERROR_MESSAGE_STYLE_CLASS. */
	String ERROR_MESSAGE_STYLE_CLASS = "ERROR_MESSAGE_STYLE_CLASS";
	/** The Constant ERROR_MESSAGES_PANEL_ID. */
	String ERROR_MESSAGES_PANEL_ID = "ERROR_MESSAGES_PANEL_ID";
	/** The Constant ERROR_MESSAGES_SHOWHIDE_CONTENT_DIV_ID. */
	String ERROR_MESSAGES_SHOWHIDE_CONTENT_DIV_ID = "ERROR_MESSAGES_SHOWHIDE_CONTENT_DIV_ID";
	/** The Constant ERROR_MESSAGES_SHOWHIDE_HEADER_DIV_ID. */
	String ERROR_MESSAGES_SHOWHIDE_HEADER_DIV_ID = "ERROR_MESSAGES_SHOWHIDE_HEADER_DIV_ID";
	/** The Constant ERROR_TEXT. */
	String ERROR_TEXT = "has an Error. Save Failed!";
	/** The Constant FIELD_INCOMPLETE. */
	String FIELD_INCOMPLETE = "FIELD INCOMPLETE";
	/** The 14M TTC - FR penalty fee payment. */
	String FR_PENALTY_PAYMENT = "14M";
	/** The FTA_FTP_FINE_PMT_CLEARANCE_INQUIRY. */
	String FTA_FTP_FINE_PMT_CLEARANCE_INQUIRY = "FCP";
	/** The Constant HEIGHT_INCHES. */
	String HEIGHT_INCHES = "HEIGHT INCHES";
	/** The Constant INVALID_CHARACTER_IN_ALPHA_NUMERIC. */
	String INVALID_CHARACTER_IN_ALPHA_NUMERIC = "INVALID CHARACTER IN ALPHA/NUMERIC FIELD";
	/** The Constant INVALID_DATE. */
	String INVALID_DATE = "INVALID DATE";
	/** The Constant INVALID_YEAR. */
	String INVALID_YEAR = "INVALID DATE";
	/** The Constant LABEL_ATTRIBUTE_FOR. */
	String LABEL_ATTRIBUTE_FOR = "for";
	/** The Constant LABEL_COLON. */
	String LABEL_COLON = ":";
	/** The Constant LABEL_ERROR_IMAGE. */
	String LABEL_ERROR_IMAGE = "ErrorImage";
	/** The Constant LABEL_IPHEN. */
	String LABEL_IPHEN = "-";
	/** The MEDICAL_REPORT_UPDATE. */
	String MEDICAL_REPORT_UPDATE = "05M";
	/*The Constant for NONE text*/
	/** The NONE_TXT. */
	String NONE_TXT = "NONE";
	/** The PAGE TOKEN Constant. */
	String PAGE_TOKEN = "MAIN_FORM:token";
	/** The Constant PHOTO_LINK_INFO. */
	String PHOTO_LINK_INFO = "photo";
	/** Constant for PROOF_FILING_INQUIRY. */
	String PROOF_FILING_INQUIRY = "PRF";
	/** The 04M TTC - reissue fee payment. */
	String REISSUE_FEE_PAYMENT = "04M";
	/** The 13M TTC - remove court restriction payment. */
	String REMOVE_COURT_RESTRICTION_PAYMENT = "13M";
	/** The Constant REQUIRED_STYLE_CLASS. */
	String REQUIRED_STYLE_CLASS = "requiredStyle";
	/** The Constant RESOURCE_APPLICATION_LABELS. */
	String RESOURCE_APPLICATION_LABELS = "applicationLabels";
	/** The Constant RESOURCE_APPLICATION_MESSAGES. */
	String RESOURCE_APPLICATION_MESSAGES = "applicationMessages";
	/** The SERVICE_OF_ORDER_INQUIRY. */
	String SERVICE_OF_ORDER_INQUIRY = "60U";
	/** The SESSIO n_ context. */
	String SESSION_CONTEXT = "sessionContext";
	/** The SESSIO n_ data. */
	String SESSION_DATA = "sessionData";
	/** The 06M TTC - special certificate payment. */
	String SPECIAL_CERTIFICATE_PAYMENT = "06M";
	/** The Constant SYSTEM_PREF_BEAN. */
	String SYSTEM_PREF_BEAN = "systemPreferencesBean";
	/** The 07M TTC - transit training payment. */
	String TRANSIT_TRAINING_PAYMENT = "07M";
	/** The User Interface UI_ERROR_MSG_IND. */
	String UI_ERROR_MSG_IND = "-uiErrorMsg";
	/** The User Interface UI_STYLE_CLS. */
	String UI_STYLE_CLS = "uiErrorMessage";
	/** The Constant VALIDATOR_DOUBLE_RANGE_MAXIMUM. */
	String VALIDATOR_DOUBLE_RANGE_MAXIMUM = "javax.faces.validator.DoubleRangeValidator.MAXIMUM";
	/** The Constant VALIDATOR_DOUBLE_RANGE_MINIMUM. */
	String VALIDATOR_DOUBLE_RANGE_MINIMUM = "javax.faces.validator.DoubleRangeValidator.MINIMUM";
	/** The Constant VALIDATOR_DOUBLE_RANGE_TYPE. */
	String VALIDATOR_DOUBLE_RANGE_TYPE = "javax.faces.validator.DoubleRangeValidator.TYPE";
	/** The Constant VALIDATOR_LENGTH_MAXIMUM. */
	String VALIDATOR_LENGTH_MAXIMUM = "javax.faces.validator.LengthValidator.MAXIMUM";
	/** The Constant VALIDATOR_LENGTH_MINIMUM. */
	String VALIDATOR_LENGTH_MINIMUM = "javax.faces.validator.LengthValidator.MINIMUM";
	/** The Constant VALIDATOR_LONG_RANGE_MAXIMUM. */
	String VALIDATOR_LONG_RANGE_MAXIMUM = "javax.faces.validator.LongRangeValidator.MAXIMUM";
	/** The Constant VALIDATOR_LONG_RANGE_MINIMUM. */
	String VALIDATOR_LONG_RANGE_MINIMUM = "javax.faces.validator.LongRangeValidator.MINIMUM";
	/** The Constant VALIDATOR_LONG_RANGE_TYPE. */
	String VALIDATOR_LONG_RANGE_TYPE = "javax.faces.validator.LongRangeValidator.TYPE";
	/** The Constant VALIDATOR_NOT_IN_RANGE. */
	String VALIDATOR_NOT_IN_RANGE = "javax.faces.validator.NOT_IN_RANGE";
}
/**
 *  Modification History:
 *
 *  $Log: PageConstants.java,v $
 *  Revision 1.1  2012/10/01 02:58:06  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.16  2012/09/27 18:22:50  mwrrv3
 *  Added constant for PROOF_FILLING_INQUIRY.
 *
 *  Revision 1.15  2012/09/27 00:43:09  mwpxp2
 *  Added SESSION_DATA
 *
 *  Revision 1.14  2012/09/27 00:41:04  mwpxp2
 *  Added SESSION_CONTEXT  constant
 *
 *  Revision 1.13  2012/09/25 20:32:19  mwrrv3
 *  Added constant PHOTO_LINK_INFO for photo (404 from PROD Logs).
 *
 *  Revision 1.12  2012/09/07 02:19:26  mwrrv3
 *  Replaced literals with constants and code clean up.
 *
 *  Revision 1.11  2012/08/18 00:49:52  mwrrv3
 *  Code clean up and fixed PMD issues.
 *
 *  Revision 1.10  2012/08/09 23:52:03  mwrrv3
 *  Added constants ACTIONS_HANDLER, PAGE_TOKEN.
 *
 *  Revision 1.9  2011/12/07 23:41:22  mwrrv3
 *  Added constant for PRF.
 *
 *  Revision 1.8  2011/12/07 22:39:18  mwrrv3
 *  Added constant for COUNSELOR_INQUIRY.
 *
 *  Revision 1.7  2011/10/22 00:44:44  mwrrv3
 *  Added constant for NONE_TXT.
 *
 *  Revision 1.6  2011/09/29 00:15:52  mwrrv3
 *  Added DL_ID_ADDRESS_CHANGE_INQUIRY for 38U TTC.
 *
 *  Revision 1.5  2010/07/21 21:15:53  mwrrv3
 *  Group 5 Initial commit.
 *
 *  Revision 1.4  2010/05/04 00:11:03  mwpxp2
 *  Removed redundant "public static final "
 *
 *  Revision 1.3  2010/04/26 17:31:35  mwskd2
 *  added some constant variables
 *
 *  Revision 1.2  2010/03/22 23:58:27  mwpxp2
 *  Fixed file footer
 *
 */
