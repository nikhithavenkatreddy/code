package gov.ca.dmv.ease.ui.handler.impl;

import java.io.Serializable;

import gov.ca.dmv.ease.app.action.impl.Action;

/**
 * Description: //TODO - provide description!
 * File: UiActionDecorator.java
 * Module:  gov.ca.dmv.ease.ui.handler.impl
 * Created: Nov 23, 2009 
 * @author mwrsk  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:58:07 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class UiActionDecorator implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4690480577405413697L;
	/** The action. */
	private Action action;
	/** The button index. */
	private Integer buttonIndex;
	/** The bypass validation. */
	private Boolean bypassValidation;
	/** The label. */
	private String label;

	/**
	 * Instantiates a new ui action decorator.
	 */
	public UiActionDecorator() {
		super();
	}

	/**
	 * Instantiates a new ui action decorator.
	 * 
	 * @param action the action
	 */
	public UiActionDecorator(Action action) {
		setAction(action);
	}

	/**
	 * Gets the action.
	 * 
	 * @return the action
	 */
	public Action getAction() {
		return action;
	}

	/**
	 * Gets the button index.
	 * 
	 * @return the button index
	 */
	public Integer getButtonIndex() {
		return buttonIndex;
	}

	/**
	 * Gets the bypass validation.
	 * 
	 * @return the bypass validation
	 */
	public Boolean getBypassValidation() {
		return bypassValidation;
	}

	/**
	 * Gets the label.
	 * 
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * Sets the action.
	 * 
	 * @param action the new action
	 */
	public void setAction(Action action) {
		this.action = action;
	}

	/**
	 * Sets the button index.
	 * 
	 * @param buttonIndex the new button index
	 */
	public void setButtonIndex(Integer buttonIndex) {
		this.buttonIndex = buttonIndex;
	}

	/**
	 * Sets the bypass validation.
	 * 
	 * @param bypassValidation the new bypass validation
	 */
	public void setBypassValidation(Boolean bypassValidation) {
		this.bypassValidation = bypassValidation;
	}

	/**
	 * Sets the label.
	 * 
	 * @param label the new label
	 */
	public void setLabel(String label) {
		this.label = label;
	}
}
/**
 *  Modification History:
 *
 *  $Log: UiActionDecorator.java,v $
 *  Revision 1.1  2012/10/01 02:58:07  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.4  2011/06/14 22:06:48  mwpxp2
 *  Implemented serializable
 *
 *  Revision 1.3  2011/06/14 21:58:35  mwpxp2
 *  Added missing class header; removed unnecessary this~
 *
 *  Revision 1.2  2010/03/23 00:01:00  mwpxp2
 *  Bulk cleanup
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.1  2009/10/22 00:40:40  mwbvc
 *  Gopi Changes - for tab support and separating the inquiry to court and dcs
 *
 *  Revision 1.2  2009/10/03 21:36:50  mwpxp2
 *  Adjusted imports for fw, apph refactorings; added javadoc
 *
 */
