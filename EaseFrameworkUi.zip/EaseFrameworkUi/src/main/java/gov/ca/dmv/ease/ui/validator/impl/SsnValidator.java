/**
 * This source code contains State of California's confidential and trade secret information.
 * Any use of this code other than for backup is strictly prohibited.
 * Copyright State of California (c) 2009
 * http://www.california.gov
 */
package gov.ca.dmv.ease.ui.validator.impl;

import gov.ca.dmv.ease.bo.code.impl.CodeSetElement;
import gov.ca.dmv.ease.fw.util.impl.ArrayUtils;
import gov.ca.dmv.ease.fw.util.impl.EaseUtil;
import gov.ca.dmv.ease.ui.component.impl.HtmlSuggestedInputText;
import gov.ca.dmv.ease.ui.util.impl.FacesUtils;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

/**
 * Description: SsnValidator.java is a custom validator which validates
 * the Social Security Number (SSN) value.
 * Module: gov.ca.dmv.ease.ui.validator.impl
 * File: SsnValidator.java 
 * Created: Dec 28, 2010
 * @author MWNRK
 * @version $Revision: 1.1 $ 
 * Last Changed: $Date: 2012/10/01 02:58:06 $ 
 * Last Changed By: $
 */
public class SsnValidator extends ValidatorBase {
	/** The Constant CONVERSION_ERROR_MESSAGE. */
	private static final String CONVERSION_ERROR_MESSAGE = "FIELD MAY ONLY CONTAIN NUMBERS";
	/** The Constant DATA_NOT_WITHIN_RANGE. */
	private static final String DATA_NOT_WITHIN_RANGE = "DATA NOT WITHIN SPECIFIED RANGE";
	/** The Constant SSN_VERIFICATION_CODES. */
	private static final String[] SSN_VERIFICATION_CODES = { "D", "X", "T",
			"I", "R", "A", "" };

	/**
	 * Instantiates a new SSN validator.
	 */
	public SsnValidator() {
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#restoreState(javax.faces.context.FacesContext, java.lang.Object)
	 */
	@Override
	public void restoreState(FacesContext context, Object state) {
		Object[] values = (Object[]) state;
		super.restoreState(context, values[0]);
	}

	/* (non-Javadoc)
	 * @see gov.ca.dmv.ease.ui.validator.impl.ValidatorBase#saveState(javax.faces.context.FacesContext)
	 */
	@Override
	public Object saveState(FacesContext context) {
		Object values[] = new Object[1];
		values[0] = super.saveState(context);
		return values;
	}

	/* (non-Javadoc)
	 * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public void validate(FacesContext facesContext, UIComponent uiComponent,
			Object value) throws ValidatorException {
		if (value == null) {
			return;
		}
		// Convert String to Integer and if the value is greater than 11 then
		// throw an error.
		try {
			String existingUserVerifiedSsnCode = "";
			String currentSsnVerifiedInd = "";
			UIComponent ssnComponent = uiComponent
					.findComponent("socialSecurityNumber");
			if (ssnComponent != null && ssnComponent.getParent() != null) {
				UIComponent uiChildComponent = ssnComponent.getParent()
						.findComponent("existingSsnVerifiedInd");
				UIComponent currentSsnVerifComp = uiComponent
						.findComponent("currentSsnVerifiedInd");
				if (currentSsnVerifComp != null
						&& currentSsnVerifComp instanceof HtmlSuggestedInputText) {
					CodeSetElement codeSetElement = (CodeSetElement) ((HtmlSuggestedInputText) currentSsnVerifComp)
							.getValue();
					if (codeSetElement != null) {
						currentSsnVerifiedInd = codeSetElement.getCode();
					}
				}
				if (uiChildComponent != null
						&& uiChildComponent instanceof HtmlInputHidden) {
					existingUserVerifiedSsnCode = (String) ((HtmlInputHidden) uiChildComponent)
							.getValue();
				}
			}
			String ssnNumber = value.toString();
			if (currentSsnVerifiedInd != null && currentSsnVerifiedInd != ""
					&& ssnNumber != null
					&& ssnNumber.equalsIgnoreCase("*********")) {
				return;
			}
			else if (!EaseUtil.isNullOrBlank(existingUserVerifiedSsnCode)
					&& ArrayUtils.contains(SSN_VERIFICATION_CODES,
							existingUserVerifiedSsnCode) && ssnNumber != null
					&& ssnNumber.equalsIgnoreCase("*********")) {
				return;
			}
			/**
			 * INVALID SSN NUMBERS
			 * SSN = '666666666', '999999999', '123456789' or '000112222' 
			 */
			if (isNumeric(ssnNumber)) {
				long ssnValue = new Long(ssnNumber).longValue();
				if (ssnValue == 666666666 || ssnValue == 123456789
						|| ssnValue == 112222) {
					throw new ValidatorException(FacesUtils.createErrorMessage(
							value.toString(), DATA_NOT_WITHIN_RANGE));
				}
				//INVALID DATA RANGE
				if (ssnValue <= 0 || ssnValue > 999999998) {
					throw new ValidatorException(FacesUtils.createErrorMessage(
							value.toString(), DATA_NOT_WITHIN_RANGE));
				}
			}
		}
		catch (NumberFormatException e) {
			throw new ValidatorException(FacesUtils.createErrorMessage(value
					.toString(), CONVERSION_ERROR_MESSAGE));
		}
	}

	/**
	 * Check if the SSN number is numeric or not.
	 *
	 * @param str the str
	 * @return true, if is numeric
	 */
	private static boolean isNumeric(String str) {
		try {
			Integer.parseInt(str);
		}
		catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
}
/**

 * Modification History:
 * 
 * $Log: SsnValidator.java,v $
 * Revision 1.1  2012/10/01 02:58:06  mwpxp2
 * Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 * Revision 1.15  2012/08/14 20:41:45  mwrrv3
 * Fixed PMD issues.
 *
 * Revision 1.14  2012/08/07 22:48:26  mwrrv3
 * Updated with comments and refractored (Similar Defect# 1417).
 *
 * Revision 1.13  2011/12/03 02:25:35  mwrrv3
 * Updated the code to fix defect# 6930 (don't display SSN VERI code).
 *
 * Revision 1.12  2011/11/15 22:50:39  mwrrv3
 * Reverted to previous version.
 *
 * Revision 1.11  2011/11/15 02:25:27  mwrrv3
 * Added validation for FIELD MAY ONLY CONTAIN NUMBERS.
 *
 * Revision 1.10  2011/06/13 18:27:23  mwyxg1
 * clean up
 *
 * Revision 1.9  2011/06/10 23:13:14  mwyxg1
 * move ArrayUtils from ui package to fw package
 *
 * Revision 1.8  2011/01/24 02:05:44  mwgxk2
 * Defect ID : 43242 Fix for SSN Pattern match.
 *
 * Revision 1.7  2011/01/22 21:38:33  mwgxd3
 * We should not display "FIELD MAY ONLY CONTAIN NUMBERS" for SSN when is masked by astericks and the verification code is blank. This situation happen only on Fallback and "Modify App Data when SSN is already present.
 *
 * Gopi's fix.
 *
 * Revision 1.6  2011/01/22 19:40:25  mwgxk2
 * Defect ID : 4342 SSN Number Validation.
 *
 * Revision 1.5  2011/01/12 01:21:43  mwgxk2
 * Added Blank for SSNVerification Code also.
 *
 * Revision 1.4  2011/01/04 01:18:57  mwnrk
 * Fix for SocialsecurityNumber.
 *
 * Revision 1.3  2010/12/31 23:24:45  mwnrk
 * Modified validations.
 *
 * Revision 1.2  2010/12/31 00:41:03  mwnrk
 * Modified validator condition.
 *
 * Revision 1.1  2010/12/28 21:43:39  mwnrk
 * To Validate the SSN.
 *
 * Revision 
*/
